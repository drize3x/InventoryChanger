

#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <d3d11_1.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <atomic>
#include <mutex>
#include <thread>
#include <chrono>
#include <cstring>
#include <fstream>
#include <sstream>
#include <locale>
#include <filesystem>
#include <memory>
#include <array>
#include <deque>
#include "MinHook.h"
#include "menu_gpu_draw.h"
#include "inventory_background_gpu.h"
#include "profile_gpu.h"
#include "presets_overlay_gpu.h"
#include "presets_gpu.h"
#include "world_view_ui.h"
#include "search_color_editor.h"
#include "search_native_editor.h"
#include "profile_image_win32.h"
#include "ambience_host_win32.h"
#include "host_dpi_win32.h"
#include "host_telemetry_win32.h"
#include "hitsound_audio_win32.h"
#include "game_context_win32.h"
#include "hitsound_events_win32.h"
#include "world_camera_win32.h"
#include "world_hud_overlay_gpu.h"
#include "inventory_apply_win32.h"
#include "inventory_knife_plan.h"
#include "inventory_local_charm_win32.h"
#include "inventory_local_agent.h"
#include "dt_demo_indicator_gpu.h"
#include "game_hud_win32.h"
#include "players_native_preview_win32.h"
#include "preview_image_cache_win32.h"
#include "startup_gpu.h"
#include "watermark_gpu.h"
#include "watermark_interaction.h"
#include "presets_storage_win32.h"
#include "rendersystem_swapchain_win32.h"
#include "menu_toggle_input.h"
#include "menu_cursor_win32.h"
#include "menu_input_routing.h"
#include "menu_fade_capture_win32.h"
#include "inventory_preview_win32.h"
namespace {
using Microsoft::WRL::ComPtr;
namespace fs = std::filesystem;
using Present = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);
using Resize = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
HMODULE module = nullptr;
Present nextPresent = nullptr;
Resize nextResize = nullptr;
void* presentAddress = nullptr;
void* resizeAddress = nullptr;
menu::RenderSystemDx11Swapchain engineSwapchain;
menu::RenderSystemChain selectedEngineChain;
std::atomic<bool> stopping{false}, visible{false}, startupPending{true}, startupReady{false};
std::atomic<unsigned> active{0};
std::atomic<HWND> gameWindow{nullptr};
std::atomic<WNDPROC> previousProc{nullptr};
struct InputEvent {
    UINT msg;
    WPARAM value;
    bool control = false, repeat = false, clipboard = false;
    std::string text;
    bool shift = false;
    int x = 0, y = 0;
};
std::deque<InputEvent> uiInput;
std::recursive_mutex renderMutex;
fs::path root;
menu::MenuToggleInput menuToggleInput;
menu::WatermarkNativeHud nativeHud;
menu::NativePlayerPreview nativePreview;
menu::WorldScoreboard nativeScoreboard;
menu::WorldNativeCamera nativeCamera;
menu::HitSoundEvents nativeHitSound;
menu::InventoryNativeApply nativeInventory;
menu::InventoryLocalCharm nativeLocalCharm;
menu::InventoryPreviewRuntime inventoryPreview;
menu::AmbienceImageReadback inventoryArtworkReadback;
bool inventoryContentStarted = false;
UINT clipboardMessage = 0;
std::mutex clipboardMutex;
std::string clipboardCopy;
menu::MenuCursorWin32 menuCursor;
std::atomic<bool> cursorMessagePending{false};

std::atomic<bool> apiDocsQueued{false};
std::atomic<bool> acceptPaste{false}, textInput{false};
void Check(HRESULT hr, const char* text) {
    if (FAILED(hr))
        throw std::runtime_error(std::string(text) +
                                 " HRESULT=" + std::to_string(static_cast<unsigned long>(hr)));
}
struct Callback {
    Callback() {
        ++active;
    }
    ~Callback() {
        --active;
    }
};
std::u32string Text(const wchar_t* s) {
    std::u32string out;
    for (std::size_t i = 0; s[i]; ++i) {
        std::uint32_t c = s[i];
        if (c >= 0xd800 && c <= 0xdbff && s[i + 1] >= 0xdc00 && s[i + 1] <= 0xdfff)
            c = 0x10000 + ((c - 0xd800) << 10) + (s[++i] - 0xdc00);
        out.push_back(c);
    }
    return out;
}

struct ClipboardScope {
    explicit ClipboardScope(HWND window) {
        if (!OpenClipboard(window))
            throw std::runtime_error("Cannot open clipboard");
    }
    ~ClipboardScope() {
        CloseClipboard();
    }
};
void WriteClipboardASCII(HWND window, const std::string& code) {
    if (code.empty() || code.size() > 65543 ||
        std::any_of(code.begin(), code.end(), [](unsigned char c) { return c == 0 || c > 127; }))
        throw std::runtime_error("Invalid local preset code");
    ClipboardScope clipboard(window);
    const SIZE_T bytes = (code.size() + 1) * sizeof(wchar_t);
    HGLOBAL mem = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (!mem)
        throw std::runtime_error("Cannot allocate clipboard text");
    auto data = static_cast<wchar_t*>(GlobalLock(mem));
    if (!data) {
        GlobalFree(mem);
        throw std::runtime_error("Cannot lock clipboard text");
    }
    for (std::size_t i = 0; i < code.size(); ++i)
        data[i] = wchar_t(static_cast<unsigned char>(code[i]));
    data[code.size()] = 0;
    GlobalUnlock(mem);
    if (!EmptyClipboard() || !SetClipboardData(CF_UNICODETEXT, mem)) {
        GlobalFree(mem);
        throw std::runtime_error("Cannot copy local preset code");
    }
}
std::string ReadClipboardASCII(HWND window) {
    ClipboardScope clipboard(window);
    HANDLE handle = GetClipboardData(CF_UNICODETEXT);
    const SIZE_T count = handle ? GlobalSize(handle) / sizeof(wchar_t) : 0;
    if (!count || count > 65544)
        throw std::runtime_error("Clipboard preset is missing or too large");
    auto data = static_cast<const wchar_t*>(GlobalLock(handle));
    if (!data)
        throw std::runtime_error("Cannot read clipboard text");
    std::string code;
    bool valid = false;

    try {
        for (SIZE_T i = 0; i < count; ++i) {
            if (!data[i]) {
                valid = true;
                break;
            }
            if (data[i] > 127)
                break;
            code += char(data[i]);
        }
    } catch (...) {
        GlobalUnlock(handle);
        throw;
    }
    GlobalUnlock(handle);
    if (!valid || code.empty())
        throw std::runtime_error("Clipboard does not contain an ASCII preset code");
    return code;
}

std::string ReadClipboardText(HWND window) {
    ClipboardScope clip(window);
    HANDLE handle = GetClipboardData(CF_UNICODETEXT);
    SIZE_T count = handle ? GlobalSize(handle) / sizeof(wchar_t) : 0;
    if (!count || count > 65544)
        throw std::runtime_error("Clipboard text is missing or too large");
    auto data = static_cast<const wchar_t*>(GlobalLock(handle));
    if (!data)
        throw std::runtime_error("Cannot read clipboard text");
    std::string text;
    try {
        SIZE_T n = 0;
        while (n < count && data[n])
            ++n;
        if (n == count)
            throw std::runtime_error("Unterminated clipboard text");
        text = menu::EncodeUTF8(Text(data));
    } catch (...) {
        GlobalUnlock(handle);
        throw;
    }
    GlobalUnlock(handle);
    return text;
}
void WriteClipboardText(HWND window, const std::string& text) {
    auto decoded = menu::DecodeUTF8(text);
    if (decoded.size() > 65543)
        throw std::runtime_error("Clipboard text too large");
    std::wstring value;
    for (auto c : decoded) {
        if (c > 0xffff) {
            c -= 0x10000;
            value += wchar_t(0xd800 + (c >> 10));
            value += wchar_t(0xdc00 + (c & 1023));
        } else
            value += wchar_t(c);
    }
    ClipboardScope clip(window);
    HGLOBAL mem = GlobalAlloc(GMEM_MOVEABLE, (value.size() + 1) * sizeof(wchar_t));
    if (!mem)
        throw std::runtime_error("Cannot allocate clipboard text");
    auto data = GlobalLock(mem);
    if (!data) {
        GlobalFree(mem);
        throw std::runtime_error("Cannot lock clipboard text");
    }
    std::memcpy(data, value.c_str(), (value.size() + 1) * sizeof(wchar_t));
    GlobalUnlock(mem);
    if (!EmptyClipboard() || !SetClipboardData(CF_UNICODETEXT, mem)) {
        GlobalFree(mem);
        throw std::runtime_error("Cannot copy text");
    }
}
LRESULT CALLBACK Input(HWND window, UINT msg, WPARAM w, LPARAM l) {
    Callback callback;
    auto previous = previousProc.load();

    if (msg == WM_KILLFOCUS) {
        menuToggleInput.Cancel();
        menuCursor.Release();
    }
    if (!stopping && (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) && w == VK_INSERT) {
        DWORD process = 0;
        GetWindowThreadProcessId(GetForegroundWindow(), &process);
        bool allowed = process == GetCurrentProcessId() && !(visible.load() && textInput.load());
        if (allowed) {
            menuToggleInput.KeyDown((static_cast<ULONG_PTR>(l) & (ULONG_PTR(1) << 30)) != 0, true);
            return 0;
        }
    }
    if (clipboardMessage && msg == clipboardMessage) {
        if (w == 2) {
            cursorMessagePending = false;
            const bool focused = GetForegroundWindow() == window;
            const bool wantMenu = !stopping.load() && visible.load() && startupReady.load() && focused;
            menuCursor.ApplyMode(wantMenu, wantMenu);
            return 0;
        }
        if (w == 1) {

            if (apiDocsQueued.exchange(false) && !stopping) {
                auto result =
                    ShellExecuteA(nullptr, nullptr, menu::ExtensionsApiURL, nullptr, nullptr, SW_SHOW);
                if (reinterpret_cast<INT_PTR>(result) <= 32) {
                    std::lock_guard<std::recursive_mutex> lock(renderMutex);
                    if (uiInput.size() < 256)
                        uiInput.push_back(
                            {clipboardMessage, 0, false, false, false, "Cannot open API documentation"});
                }
            }
            return 0;
        }
        std::string copy;
        {
            std::lock_guard<std::mutex> lock(clipboardMutex);
            copy.swap(clipboardCopy);
        }
        if (!stopping && !copy.empty())
            try {
                if (std::all_of(copy.begin(), copy.end(), [](unsigned char c) { return c > 0 && c < 128; }))
                    WriteClipboardASCII(window, copy);
                else
                    WriteClipboardText(window, copy);
            } catch (const std::exception& e) {
                std::lock_guard<std::recursive_mutex> lock(renderMutex);
                if (uiInput.size() < 256)
                    uiInput.push_back({clipboardMessage, 0, false, false, false, e.what()});
            }
        return 0;
    }
    if (!stopping && visible && startupReady) {
        if ((msg == WM_RBUTTONDOWN || msg == WM_RBUTTONUP || msg == WM_CHAR || msg == WM_KEYDOWN ||
             msg == WM_MOUSEWHEEL || msg == WM_KILLFOCUS || msg == WM_CAPTURECHANGED) &&
            !(msg == WM_KEYDOWN && !textInput.load() && menu::IsDefaultMovementKey(unsigned(w)))) {
            InputEvent event{msg,
                             w,
                             (GetKeyState(VK_CONTROL) & 0x8000) != 0,
                             (static_cast<ULONG_PTR>(l) & (ULONG_PTR(1) << 30)) != 0,
                             false,
                             {}};
            if (msg == WM_RBUTTONDOWN || msg == WM_RBUTTONUP) {
                event.x = GET_X_LPARAM(l);
                event.y = GET_Y_LPARAM(l);
            }
            event.shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
            if (msg == WM_KEYDOWN && w == 'V' && event.control && !event.repeat && acceptPaste.load()) {
                try {
                    event.text = textInput.load() ? ReadClipboardText(window) : ReadClipboardASCII(window);
                    event.clipboard = true;
                } catch (const std::exception& e) {
                    event.msg = clipboardMessage;
                    event.text = e.what();
                }
            }
            std::lock_guard<std::recursive_mutex> lock(renderMutex);
            if (uiInput.size() < 256)
                uiInput.push_back(std::move(event));
        }
        if (msg == WM_SETCURSOR) {
            SetCursor(LoadCursorW(nullptr, IDC_ARROW));
            return TRUE;
        }
        if (msg == WM_INPUT) {
            RAWINPUT input{};
            UINT size = sizeof(input);
            if (GetRawInputData(reinterpret_cast<HRAWINPUT>(l), RID_INPUT, &input, &size,
                                sizeof(RAWINPUTHEADER)) != UINT(-1) &&
                input.header.dwType == RIM_TYPEKEYBOARD &&
                menu::PassGameKeyboard(textInput.load(), (input.data.keyboard.Flags & RI_KEY_BREAK) != 0,
                                       input.data.keyboard.VKey))
                return previous ? CallWindowProcW(previous, window, msg, w, l)
                                : DefWindowProcW(window, msg, w, l);
            return DefWindowProcW(window, msg, w, l);
        }
        if (msg == WM_KEYDOWN || msg == WM_KEYUP || msg == WM_SYSKEYDOWN || msg == WM_SYSKEYUP) {
            const bool release = msg == WM_KEYUP || msg == WM_SYSKEYUP;
            if (menu::PassGameKeyboard(textInput.load(), release, unsigned(w)))
                return previous ? CallWindowProcW(previous, window, msg, w, l)
                                : DefWindowProcW(window, msg, w, l);
            return 0;
        }
        if ((msg >= WM_MOUSEFIRST && msg <= WM_MOUSELAST) || (msg >= WM_KEYFIRST && msg <= WM_KEYLAST))
            return 0;
    }
    return previous ? CallWindowProcW(previous, window, msg, w, l) : DefWindowProcW(window, msg, w, l);
}

struct PipelineGuard {
    ID3D11DeviceContext1* context;
    ComPtr<ID3DDeviceContextState> previous;
    PipelineGuard(ID3D11DeviceContext1* c, ID3DDeviceContextState* own) : context(c) {
        context->SwapDeviceContextState(own, previous.GetAddressOf());
    }
    ~PipelineGuard() {
        context->ClearState();
        context->SwapDeviceContextState(previous.Get(), nullptr);
    }
};
struct Overlay {
    ComPtr<IDXGISwapChain> chain;
    ComPtr<ID3D11Device> device;
    ComPtr<ID3D11DeviceContext> context;
    ComPtr<ID3D11DeviceContext1> context1;
    ComPtr<ID3DDeviceContextState> ownState;
    ComPtr<ID3D11RenderTargetView> target;
    wm::RendererDX11 renderer;
    menu::PreviewImageCache previewImage;
    menu::MenuFadeCapture menuFadeCapture;
    menu::PresetMotion menuOpacity;
    bool previewTerrorist = false;
    menu::Settings cfg;
    menu::State state;
    menu::ProfileUI profile;
    menu::ProfileGPUCache profileGPU;
    std::vector<std::string> startupImages;
    bool startupImageListBuilt = false;
    ULONGLONG startupAssetsStarted = 0, startupNextAssetCheck = 0;
    menu::InventoryBackgroundGPU inventoryBackground;
    menu::PresetsUI presets;
    menu::SearchColorEditor searchColor;
    menu::SearchNativeEditor searchNative;
    menu::WorldViewUI world;
    menu::StartupUI startup;
    menu::WatermarkUI watermark;
    menu::WatermarkHostTelemetry hardwareTelemetry;
    menu::DTDemoIndicator dtDemo;
    menu::HitSoundAudio hitSoundAudio;
    menu::GameContextSource gameContext;
    menu::HudOverlayRenderer hudOverlay;
    menu::HudOverlayGPU hudGPU;
    ULONGLONG scoreboardNextCollect = 0, spectatorsNextCollect = 0;
    menu::WatermarkInteraction watermarkInput;
    fs::path pendingAvatar, pendingLogo;
    menu::PresetsGPUCache presetsGPU;
    menu::PresetsPaintGPUCache worldPaint{36}, watermarkPaint{52}, keybindPaint{68};
    menu::PresetChangeTracker cachedPresentation;
    bool escapeDown = false;
    std::unique_ptr<menu::Fonts> fonts;
    std::unique_ptr<menu::Canvas> overlay;
    menu::MenuDrag drag;
    std::array<float, 11> cachedAnimations{};
    int cachedSelected = -1, cachedChild = -1;
    bool dirty = true, mouseDown = false, wasFocused = true;
    int width = 0, height = 0;
    std::chrono::steady_clock::time_point last = std::chrono::steady_clock::now();
    explicit Overlay(IDXGISwapChain* source) : chain(source) {
        menuOpacity.Snap(0.f);
        Check(chain->GetDevice(IID_PPV_ARGS(&device)), "DX11 swap-chain device");
        device->GetImmediateContext(&context);
        ComPtr<ID3D11Device1> device1;
        Check(device.As(&device1), "D3D11.1 device required");
        Check(context.As(&context1), "D3D11.1 context required");
        D3D_FEATURE_LEVEL level = device->GetFeatureLevel(), chosen{};
        Check(device1->CreateDeviceContextState(0, &level, 1, D3D11_SDK_VERSION, __uuidof(ID3D11Device),
                                                &chosen, &ownState),
              "isolated context state");
        renderer.Init(device.Get(), context.Get(), (root / L"shaders/menu_material.hlsl").c_str());
        fonts = std::make_unique<menu::Fonts>(root / L"assets/fonts");
        const auto ini = root / L"OverlayMenu.ini";
        cfg.scale =
            std::clamp(GetPrivateProfileIntW(L"Preview", L"ScalePercent", 100, ini.c_str()), 50u, 200u) /
            100.f;
        cfg.windowsScale =
            int(std::clamp(GetPrivateProfileIntW(L"Preview", L"WindowsScaleIndex", 0, ini.c_str()), 0u, 5u));
        cfg.blur = GetPrivateProfileIntW(L"Material", L"Blur", 1, ini.c_str()) != 0;
        cfg.sigma =
            std::clamp(GetPrivateProfileIntW(L"Material", L"SigmaTenths", 50, ini.c_str()), 1u, 65u) / 10.f;
        cfg.theme =
            int(std::clamp(GetPrivateProfileIntW(L"Material", L"BasePalette", 0, ini.c_str()), 0u, 1u));
        cfg.demoBackground = false;
        wchar_t value[32768]{};
        GetPrivateProfileStringW(L"Profile", L"Username", L"Cheusol", value, DWORD(std::size(value)),
                                 ini.c_str());
        cfg.userName = Text(value);
        GetPrivateProfileStringW(L"Profile", L"Branch", L"", value, DWORD(std::size(value)), ini.c_str());
        if (value[0])
            cfg.aboutBranch = Text(value);
        GetPrivateProfileStringW(L"Profile", L"Detail", L"Lifetime", value, DWORD(std::size(value)),
                                 ini.c_str());
        cfg.userDetail = Text(value);
        GetPrivateProfileStringW(L"Profile", L"LifetimeText", L"Lifetime", value, DWORD(std::size(value)),
                                 ini.c_str());
        cfg.lifetimeText = Text(value);
        GetPrivateProfileStringW(L"Profile", L"SubscriptionEndUnix", L"", value, DWORD(std::size(value)),
                                 ini.c_str());
        if (value[0])
            cfg.subscriptionEnd = std::stoll(value);
        GetPrivateProfileStringW(L"Profile", L"AvatarFile", L"assets/profile/noavatar.png", value,
                                 DWORD(std::size(value)), ini.c_str());
        if (value[0]) {
            fs::path path(value);
            pendingAvatar = path.is_absolute() ? path : root / path;
        }
        const auto aboutLogo = root / L"assets/logos/about-logo.png";
        pendingLogo = aboutLogo;
        menu::ConfigureAmbienceSkyHost(world.misc.ambience, root);
        startup.Begin(4);
        startup.languages = &profile.languages;
        last = std::chrono::steady_clock::now();
        state.Tick(.2f);
    }
    void AdvanceStartup() {
        if (!startup.Loading())
            return;
        try {
            switch (startup.current) {
            case 4:
                if (!pendingAvatar.empty())
                    cfg.avatar = menu::LoadProfileAvatar(pendingAvatar);
                startup.SetProgress(5);
                break;
            case 5:
                if (fs::exists(pendingLogo))
                    cfg.aboutLogo = menu::LoadProfileImage(pendingLogo);
                startup.SetProgress(6);
                break;
            case 6:
                profile.Storage(root / L"langs");
                if (profile.languages.selected)
                    profile.ApplyLanguage(cfg);
                presets.languages = &profile.languages;
                world.languages = &profile.languages;
                startup.SetProgress(7);
                break;
            case 7: {
                auto storage = menu::PresetStorageForHost(root);
                presets.Storage(storage.directory, cfg);

                startup.SetProgress(8);
                break;
            }
            case 8:
                profile.Measure(*fonts, cfg);
                startup.SetProgress(9);
                break;
            case 9: {
                const auto now = GetTickCount64();
                if (!startupAssetsStarted)
                    startupAssetsStarted = now ? now : 1;
                auto fail = [&](const std::string& detail) { startup.Fail(U"Inventory loading failed."); };

                if (now >= startupAssetsStarted && now - startupAssetsStarted > 120000) {
                    fail("timed out waiting for schema, Panorama or startup images");
                    break;
                }
                if (!menu::InventorySharedContent().Ready()) {
                    startup.SetTask(U"", 0, 1);
                    break;
                }
                auto cat = menu::InventorySharedContent().Catalog();
                if (!cat || !cat->loaded) {
                    fail("inventory schema unavailable: " + menu::InventorySharedContent().Diagnostic());
                    break;
                }
                if (nativePreview.State() == menu::NativePlayerPreview::Status::Fault) {
                    fail("Panorama preview bridge failed");
                    break;
                }
                if (!nativePreview.StartupArtworkReady() || !nativePreview.StartupRootReady()) {
                    startup.SetTask(U"", 0, 1);
                    break;
                }
                if (!startupImageListBuilt) {
                    startupImages = menu::InventoryStartupImagePaths(*cat, cfg);
                    startupImageListBuilt = true;
                    if (startupImages.empty() || startupImages.size() > 192) {
                        fail("invalid startup image manifest (empty or exceeds safe cache budget)");
                        break;
                    }
                }
                if (now < startupNextAssetCheck)
                    break;
                startupNextAssetCheck = now + 100;
                const auto images =
                    menu::InventoryCheckStartupImages(startupImages, menu::InventoryArtworkClock());
                startup.SetTask(U"", images.ready, images.total);
                if (!images.missing.empty()) {
                    fail("image unavailable: " + images.missing);
                    break;
                }
                if (images.total && images.ready == images.total) {
                    startup.Complete();
                }
                break;
            }
            default:
                break;
            }
        } catch (const std::exception& e) {
            startup.Fail();
        }
    }
    void ReleaseBackbuffer() {
        previewImage.Reset();
        menuFadeCapture.Reset();
        target.Reset();
        PipelineGuard guard(context1.Get(), ownState.Get());
        renderer.ReleaseSizeResources();
        overlay.reset();
        profileGPU.Reset();
        presetsGPU.Reset();
        worldPaint.Reset();
        watermarkPaint.Reset();
        keybindPaint.Reset();
        dirty = true;
        width = height = 0;
    }
    void CancelUIInput() {
        world.binds.hotkeyWindow.dragging = false;
        world.binds.spectatorsWindow.dragging = false;
        watermarkInput.Cancel(watermark, true);
        drag.Stop();
        profile.CancelPress();
        presets.held = -1;
        presets.CancelInput();
        world.CancelInput();
        state.held = -1;
        acceptPaste = false;
        textInput = false;
    }
    void FlushPresets(bool exiting) {
        if (!presets.store.automatic || !presets.Active())
            return;
        try {
            if (exiting || menu::PresetCapture(cfg) != presets.Active()->values) {
                presets.store.Save(presets.store.selected, cfg);
                presets.dirtySeconds = 0;
            }
        } catch (const std::exception& e) {
            presets.Notify(e.what());
        }
    }
    void CopyPreset() {
        if (presets.TakeApiDocsRequest()) {
            apiDocsQueued = true;
            if (!clipboardMessage || !PostMessageW(gameWindow.load(), clipboardMessage, 1, 0)) {
                apiDocsQueued = false;
                presets.Notify("Cannot queue API documentation");
            }
        }
        if (!world.binds.clipboardOut.empty()) {
            presets.clipboardOut = std::move(world.binds.clipboardOut);
            world.binds.clipboardOut.clear();
        }

        if (!world.misc.ambience.clipboardOut.empty()) {
            presets.clipboardOut = std::move(world.misc.ambience.clipboardOut);
            world.misc.ambience.clipboardOut.clear();
        }
        if (presets.clipboardOut.empty())
            return;
        {
            std::lock_guard<std::mutex> lock(clipboardMutex);
            clipboardCopy = std::move(presets.clipboardOut);
            presets.clipboardOut.clear();
        }
        if (!PostMessageW(gameWindow.load(), clipboardMessage, 0, 0)) {
            std::lock_guard<std::mutex> lock(clipboardMutex);
            clipboardCopy.clear();
            presets.Notify("Cannot queue clipboard copy");
        }
    }
    void MeasureWorld(const menu::Layout& layout) {
        world.Measure(*fonts, cfg, state, layout, presets.headerLine, width, height,
                      profile.open || presets.open, presets.selector);
    }
    void PresetsEvent(const InputEvent& event) {
        if (event.msg == clipboardMessage) {
            presets.Notify(event.text);
            return;
        }
        if (!presets.mainSearch && event.msg == WM_KEYDOWN && event.control && event.value == 'S' &&
            !event.repeat) {
            menu::PresetHit hit{};
            hit.action = 2;
            presets.Activate(hit, cfg);
            return;
        }
        if (!presets.open)
            return;
        if (event.msg == WM_CHAR) {
            presets.UTF16(char16_t(event.value));
            return;
        }
        if (event.msg == WM_MOUSEWHEEL) {
            presets.Wheel(GET_WHEEL_DELTA_WPARAM(event.value) / 120.f);
            return;
        }
        if (event.msg != WM_KEYDOWN)
            return;
        if (presets.EditKey(int(event.value), event.control, event.shift)) {
            CopyPreset();
            return;
        }
        if (event.repeat)
            return;
        if (presets.mainSearch) {
            if (event.value == 'V' && event.control && event.clipboard)
                presets.PasteText(event.text);
            return;
        }
        if (event.value == VK_RETURN)
            presets.Enter();
        else if (event.value == VK_F2)
            presets.StartRename(presets.store.selected);
        else if (event.value == VK_TAB) {
            presets.FocusSearch();
        } else if (event.value == 'V' && event.control && event.clipboard) {
            if (presets.Editing())
                presets.PasteText(event.text);
            else
                presets.Import(event.text);
        } else if (event.value == 'A' && event.control && !presets.renaming.empty())
            presets.renameSelectAll = true;
    }
    void Draw() {
        ComPtr<ID3D11Texture2D> back;
        Check(chain->GetBuffer(0, IID_PPV_ARGS(&back)), "GetBuffer");
        D3D11_TEXTURE2D_DESC desc{};
        back->GetDesc(&desc);
        if (desc.SampleDesc.Count != 1 ||
            (desc.Format != DXGI_FORMAT_R8G8B8A8_UNORM && desc.Format != DXGI_FORMAT_B8G8R8A8_UNORM))
            throw std::runtime_error(
                "Only DX11 single-sample RGBA8/BGRA8 UNORM supported; not Vulkan/HDR/MSAA");
        if (!target)
            Check(device->CreateRenderTargetView(back.Get(), nullptr, &target), "backbuffer RTV");
        if (width != int(desc.Width) || height != int(desc.Height)) {
            width = int(desc.Width);
            height = int(desc.Height);
            dirty = true;
        }
        auto now = std::chrono::steady_clock::now();
        float elapsed = std::chrono::duration<float>(now - last).count();
        float dt = std::min(.1f, elapsed);
        last = now;
        hitSoundAudio.Pump();
        if (world.hitSound.pendingPreview >= 0) {
            hitSoundAudio.Play(root, world.hitSound.pendingPreview, 100);
            world.hitSound.pendingPreview = -1;
        }
        if (world.hitSound.pendingOpenFolder) {
            world.hitSound.pendingOpenFolder = false;
            std::error_code error;
            const auto folder = root / L"assets" / L"hitsounds";
            fs::create_directories(folder, error);
            if (!error)
                ShellExecuteW(nullptr, L"open", folder.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
        }
        watermark.Frame();
        hardwareTelemetry.Poll(watermark.data);
        startup.Tick(elapsed);
        startupReady = startup.MenuReady();
        const auto scoreboard =
            startup.MenuReady() ? menu::ScoreboardReadConfig(cfg) : menu::ScoreboardConfig{};
        const bool scoreboardNeedsPlayers = scoreboard.Wanted() && scoreboard.NeedsPlayers();
        auto hud = startup.MenuReady() ? menu::HudOverlayReadConfig(cfg) : menu::HudOverlayConfig{};
        hud.inaccuracy.on = false;
        menu::ViewConfig view;
        view.showViewmodel = false;
        view.forceViewmodelFov = false;
        view.scopeOverlay = hud.scope.mode;
        menu::HitSoundConfig sound;
        if (startup.MenuReady() && cfg.hitSoundEnabled) {
            sound.sound = cfg.hitSoundForType;
            sound.volume = cfg.hitSoundVolume;
        }
        gameContext.Poll(scoreboardNeedsPlayers || view.WantsCamera() || hud.Wanted() || sound.Wanted());
        std::optional<menu::ScoreboardFrame> scoreboardFrame;
        const auto scoreboardTick = GetTickCount64();
        if (scoreboardNeedsPlayers && scoreboardTick >= scoreboardNextCollect) {
            scoreboardNextCollect = scoreboardTick + menu::world_scoreboard::CollectIntervalMs;
            scoreboardFrame = gameContext.ScoreboardSample(scoreboard);
        }
        nativeScoreboard.Submit(scoreboard, scoreboardFrame ? &*scoreboardFrame : nullptr);
        bool scoped = false;
        if (startup.MenuReady() && (view.WantsCamera() || hud.Wanted() || nativeCamera.Wanted())) {
            const auto sample = gameContext.ViewSample();
            const auto read = [](std::uintptr_t at, auto& value) {
                return menu::LocalReadBytes(at, &value, sizeof(value));
            };
            const auto frame = menu::ViewResolve(read, sample, true);
            nativeCamera.Configure(menu::CameraLayout{sample.viewPunch, sample.cameraFov, sample.ownerHandle,
                                                      sample.scene, sample.absOrigin,
                                                      sample.aimPunchServices});
            scoped = frame.valid && frame.pawn && frame.scoped;
            const auto probe = hud.Probe(scoped);
            if ((view.WantsCamera() || probe.Any()) && frame.valid && frame.pawn)
                nativeCamera.Submit(view,
                                    menu::CameraFrame{frame.pawn, frame.pawnHandle, frame.desired,
                                                      frame.zoomLevel, frame.scoped, frame.weapon},
                                    probe);
            else
                nativeCamera.Clear();
        } else {
            nativeCamera.Clear();
        }
        if (sound.Wanted())
            nativeHitSound.Submit(gameContext.SoundSample(), sound);
        else
            nativeHitSound.Clear();
        std::vector<menu::HitSoundEvent> soundEvents;
        nativeHitSound.DrainSounds(soundEvents);
        if (sound.Wanted())
            for (const auto& event : soundEvents)
                hitSoundAudio.Play(root, event.sound, event.volume);
        if (hud.Wanted()) {
            menu::HudOverlayInput input;
            input.width = width;
            input.height = height;
            input.now = double(scoreboardTick) * .001;
            input.scoped = scoped;
            if (hud.scope.Lines() && hud.scope.gradient) {
                menu::ProbeSample probe;
                if (nativeCamera.Probe(probe)) {
                    input.hasProbe = true;
                    input.probe = probe;
                }
                if (const auto matrix = gameContext.ViewMatrix()) {
                    input.hasMatrix = true;
                    input.matrix = *matrix;
                }
            }
            hudOverlay.Build(hud, input);
            PipelineGuard guard(context1.Get(), ownState.Get());
            hudGPU.Draw(renderer, target.Get(), width, height, hudOverlay.sprites);
        } else if (!hudOverlay.sprites.empty() || hudOverlay.discRadius) {
            hudOverlay.Release();
            hudGPU.Reset();
        }
        menuOpacity.Tick(visible.load() && startup.MenuReady() ? 1.f : 0.f, elapsed, .2f);
        cfg.hostDpi = MenuStudioWindowDpi(gameWindow.load());
        watermark.HostClock();
        if (auto p = presets.Active())
            watermark.data.text[2] = menu::DecodeUTF8(p->name);
        else
            watermark.data.text[2].clear();
        bool bindFocused = GetForegroundWindow() == gameWindow.load();
        world.binds.Poll(
            cfg, [](int key) { return (GetAsyncKeyState(key) & 0x8000) != 0; }, bindFocused,
            startup.BlocksMenu() || profile.open || presets.open || world.Editing() ||
                watermarkInput.settings.Editing(),
            presets.store.selected);
        {
            menu::KeybindOverrideGuard bindEarly(cfg, world.binds.runtime);
            // Resolve after temporary keybind overrides, even with menu hidden.
            // Keep this source independent from scoreboard/ESP being enabled.
            const bool spectatorsWanted = startup.MenuReady() &&
                menu::HotkeySetting(cfg, "spectators") != 0;
            if (spectatorsWanted) {
                gameContext.Poll(true);
                if (spectatorsNextCollect == 0 || scoreboardTick >= spectatorsNextCollect) {
                    spectatorsNextCollect = scoreboardTick + 50;
                    world.binds.spectatorsWindow.Update(gameContext.SpectatorsSample());
                }
            } else {
                spectatorsNextCollect = 0;
                world.binds.spectatorsWindow.Update({});
            }
            watermark.Tick(elapsed, cfg, startup.MenuReady());
            // Also runs when the menu is hidden; Submit(0) restores original HUD
            // position on other anchors, startup, and at the end of fade-out.
            nativeHud.Submit(menu::WatermarkGameHudOffset(cfg, watermark, height, startup.MenuReady()));
            dtDemo.Tick(elapsed, cfg, startup.MenuReady());
            if (startup.BlocksMenu() || (!visible && menuOpacity.value <= 0.f)) {
                nativePreview.Submit({});
                previewImage.Reset();
                world.binds.Tick(dt);
                world.languages = &profile.languages;
                world.ConfigureKeybinds();
                {
                    PipelineGuard guard(context1.Get(), ownState.Get());
                    if (startup.MenuReady())
                        menu::DrawDTDemoGPU(renderer, back.Get(), target.Get(), width, height, *fonts, cfg,
                                            dtDemo);
                    if (startup.MenuReady())
                        menu::DrawWatermarkGPU(renderer, back.Get(), target.Get(), width, height, *fonts, cfg,
                                               watermark);
                    world.binds.MeasureHUD(*fonts, cfg, width, height, false);
                    if (startup.MenuReady())
                        menu::DrawPresetsGPU(renderer, back.Get(), target.Get(), width, height, *fonts, cfg,
                                             world.binds.hudPaint, 0, &keybindPaint);
                    menu::DrawStartupGPU(renderer, back.Get(), target.Get(), width, height, *fonts, cfg,
                                         startup);
                }
                AdvanceStartup();
                startupReady = startup.MenuReady();
                startupPending = startup.Active();
                return;
            }
        }

        auto layout = menu::AnimatedLayout(width, height, cfg, state, -drag.offsetX, -drag.offsetY);
        drag.Constrain(layout, width, height);
        layout = menu::AnimatedLayout(width, height, cfg, state, -drag.offsetX, -drag.offsetY);
        POINT mouse{};
        GetCursorPos(&mouse);
        ScreenToClient(gameWindow.load(), &mouse);
        bool focused = visible.load() && GetForegroundWindow() == gameWindow.load();
        profile.SetHostFocused(focused);
        if (focused && !wasFocused && profile.editLanguage > 0) {
            try {
                profile.languages.Reload(profile.editLanguage);
                profile.ApplyLanguage(cfg);
                ++profile.revision;
                dirty = true;
            } catch (const std::exception& e) {
                profile.error = e.what();
                ++profile.revision;
            }
        }
        wasFocused = focused;
        profile.Measure(*fonts, cfg);
        profile.SetMenuLayout(layout);
        presets.Measure(*fonts, cfg, layout, width, height);
        MeasureWorld(layout);
        bool down = focused && (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        watermarkInput.Measure(*fonts, cfg, width, height, true, &profile.languages);
        bool watermarkAllowed = focused && !profile.open && !presets.open && !world.PopupOpen();
        if (!watermarkAllowed)
            watermarkInput.Cancel(watermark, true);
        bool watermarkOwned = watermarkInput.Capturing(watermark);
        bool consumed = watermarkInput.Move(*fonts, cfg, watermark, width, height, float(mouse.x),
                                            float(mouse.y), down, watermarkAllowed);
        if (focused && down != mouseDown && (down || watermarkOwned))
            consumed =
                watermarkInput.Click(*fonts, cfg, watermark, width, height, float(mouse.x), float(mouse.y),
                                     down, watermarkAllowed, (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0) ||
                consumed;
        if (!focused) {
            searchColor.Close();
            searchNative.Close();
            CancelUIInput();
            uiInput.clear();
            consumed = true;
        } else if (down != mouseDown && !consumed) {
            if (searchNative.Active() && presets.mainSearch)
                consumed = searchNative.Click(float(mouse.x), float(mouse.y), down, cfg,
                                              (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0);
            if (!consumed && searchColor.active && presets.mainSearch) {
                consumed = searchColor.Click(float(mouse.x), float(mouse.y), down, cfg);
            }
            if (!consumed && down) {
                consumed =
                    profile.Click(layout, cfg, state, float(mouse.x), float(mouse.y), true, width, height);
                if (consumed)
                    presets.Close();
                else {
                    if (!presets.open && world.PopupOpen())
                        consumed = world.Click(float(mouse.x), float(mouse.y), true, cfg,
                                               (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0);
                    if (!consumed)
                        consumed = presets.Click(float(mouse.x), float(mouse.y), true, cfg);
                    if (!consumed)
                        consumed = world.Click(float(mouse.x), float(mouse.y), true, cfg,
                                               (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0);
                }
            } else if (!consumed) {
                if (!profile.open && !presets.open && (world.PopupOpen() || world.Capturing()))
                    consumed = world.Click(float(mouse.x), float(mouse.y), false, cfg);
                if (!consumed && !profile.open)
                    consumed = presets.Click(float(mouse.x), float(mouse.y), false, cfg);
                if (!consumed)
                    consumed = profile.Click(layout, cfg, state, float(mouse.x), float(mouse.y), false, width,
                                             height);
                if (!consumed && !profile.open && !presets.open)
                    consumed = world.Click(float(mouse.x), float(mouse.y), false, cfg);
                CopyPreset();
            }
            if (consumed) {
                dirty = true;
                state.held = -1;
                drag.Stop();
            }
        }
        if (presets.mainSearchNativeRequest >= 0) {
            searchColor.Close();
            searchNative.Open(presets, cfg, &profile.languages, &world.misc.ambience);
            presets.mainSearchNativeRequest = -1;
        }
        if (presets.mainSearchColorRequest >= 0) {
            searchNative.Close();
            searchColor.Open(presets, cfg, &profile.languages);
            presets.mainSearchColorRequest = -1;
        }
        if (presets.mainSearchTarget >= 0) {
            state.Select(presets.mainSearchTarget);
            presets.mainSearchTarget = -1;
            dirty = true;
        }
        if (profile.action == 1) {
            profile.action = 0;
            ShellExecuteW(gameWindow.load(), L"open", L"https://neverlose.cc/product?type=cs2", nullptr,
                          nullptr, SW_SHOWNORMAL);
        }
        bool esc = focused && (GetAsyncKeyState(VK_ESCAPE) & 0x8000) != 0;
        if (esc && !escapeDown) {
            if (watermarkInput.Active())
                watermarkInput.settings.Key(VK_ESCAPE, cfg);
            else if (profile.open)
                profile.Escape(state);
            else if (searchNative.Active())
                searchNative.Key(VK_ESCAPE, cfg, false, false);
            else if (searchColor.active) {
                if (!searchColor.Key(VK_ESCAPE, cfg, false))
                    searchColor.Close();
            } else if (presets.open)
                presets.Escape();
            else
                world.Key(VK_ESCAPE, cfg);
            dirty = true;
        }
        escapeDown = esc;
        while (!uiInput.empty()) {
            auto event = std::move(uiInput.front());
            uiInput.pop_front();
            if (!focused)
                continue;
            if (event.msg == WM_KILLFOCUS || event.msg == WM_CAPTURECHANGED) {
                CancelUIInput();
                consumed = true;
                continue;
            }
            if (event.msg == WM_RBUTTONDOWN &&
                watermarkInput.Context(*fonts, cfg, watermark, width, height, float(event.x), float(event.y),
                                       watermarkAllowed)) {
                dirty = true;
                continue;
            }
            if (watermarkInput.Active()) {
                if (event.msg == WM_CHAR)
                    watermarkInput.settings.Character(char16_t(event.value));
                else if (event.msg == WM_MOUSEWHEEL)
                    watermarkInput.settings.Wheel(GET_WHEEL_DELTA_WPARAM(event.value) / 120.f, cfg);
                else if (event.msg == WM_KEYDOWN && event.value != VK_ESCAPE)
                    watermarkInput.settings.Key(int(event.value), cfg, event.shift, event.control);
                dirty = true;
                continue;
            }
            if (searchNative.Active() && presets.mainSearch &&
                ((event.msg == WM_CHAR && searchNative.Character(char16_t(event.value))) ||
                 (event.msg == WM_KEYDOWN && event.value != VK_ESCAPE &&
                  searchNative.Key(int(event.value), cfg, event.shift, event.control)) ||
                 (event.msg == WM_MOUSEWHEEL &&
                  searchNative.Wheel(GET_WHEEL_DELTA_WPARAM(event.value) / 120.f, cfg)))) {
                dirty = true;
                continue;
            }
            if (searchColor.active && presets.mainSearch && event.msg == WM_CHAR &&
                searchColor.picker.Character(char16_t(event.value))) {
                dirty = true;
                continue;
            }
            if (searchColor.active && presets.mainSearch && event.msg == WM_KEYDOWN && event.value != VK_ESCAPE &&
                searchColor.Key(int(event.value), cfg, event.control)) {
                dirty = true;
                continue;
            }
            if (event.msg == clipboardMessage)
                presets.Notify(event.text);
            else if (profile.open) {
                if (event.msg == WM_KEYDOWN &&
                    !profile.FormEditKey(int(event.value), event.control, event.shift))
                    profile.ColorEditKey(int(event.value), event.control);
                if (event.msg == WM_CHAR)
                    profile.UTF16(char16_t(event.value));
                if (event.msg == WM_KEYDOWN && event.value == VK_TAB)
                    profile.Tab(event.shift);
                if (event.msg == WM_KEYDOWN && event.value == VK_RETURN && profile.pickerField >= 0)
                    profile.ApplyColorInput(cfg);
                if (event.msg == WM_MOUSEWHEEL)
                    profile.Wheel(cfg, GET_WHEEL_DELTA_WPARAM(event.value) / 120.f);
            } else if (!profile.open && !presets.open && event.msg == WM_RBUTTONDOWN &&
                       world.players.Context(float(event.x), float(event.y))) {
            } else if (!profile.open && !presets.open && event.msg == WM_RBUTTONUP &&
                       world.Context(float(event.x), float(event.y), cfg)) {
            } else if (!presets.open && event.msg == WM_CHAR && world.Character(char16_t(event.value))) {
            } else if (!presets.open && event.msg == WM_MOUSEWHEEL) {
                UINT wheelLines = 3;
                if (SystemParametersInfoW(SPI_GETWHEELSCROLLLINES, 0, &wheelLines, 0))
                    world.rage.wheelLines = wheelLines;
                world.Wheel(GET_WHEEL_DELTA_WPARAM(event.value) / 120.f, cfg);
            }

            else if (!presets.open && event.msg == WM_KEYDOWN && event.value != VK_ESCAPE &&
                     (!event.control || world.Editing()) &&
                     world.Key(int(event.value), cfg, event.shift, event.control)) {
                CopyPreset();
            } else
                PresetsEvent(event);
            dirty = true;
        }

        if (profile.action == 3 || profile.action == 4) {
            int link = profile.action - 3;
            profile.action = 0;
            ShellExecuteA(gameWindow.load(), "open", menu::AboutURLs[link], nullptr, nullptr, SW_SHOW);
        }
        if (profile.action == 2) {
            profile.action = 0;
            int i = profile.editLanguage;
            if (i > 0 && i < int(profile.languages.entries.size())) {
                auto file = profile.languages.root / (profile.languages.entries[i].shortName + ".json");
                auto result =
                    ShellExecuteW(gameWindow.load(), L"open", file.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
                if (reinterpret_cast<INT_PTR>(result) <= 32) {
                    profile.error = "No application is associated with JSON files.";
                    ++profile.revision;
                }
            }
        }
        if (focused && (profile.held == 300 || profile.held == 301) && down) {
            profile.EditColor(cfg, float(mouse.x), float(mouse.y), cfg);
            dirty = true;
        }
        const bool themePaletteChanged = cfg.themePalette.Tick(cfg.theme, dt);
        const bool settingsPresentationChanged = cachedPresentation.Observe(cfg);
        if (themePaletteChanged || settingsPresentationChanged) {
            dirty = true;
            ++profile.revision;
            profileGPU.Reset();
        }
        layout = menu::AnimatedLayout(width, height, cfg, state, -drag.offsetX, -drag.offsetY);
        drag.Constrain(layout, width, height);
        layout = menu::AnimatedLayout(width, height, cfg, state, -drag.offsetX, -drag.offsetY);
        profile.Measure(*fonts, cfg);
        profile.SetMenuLayout(layout);
        profile.viewportW = width;
        profile.viewportH = height;
        profile.Clamp(cfg);
        profile.Move(cfg, focused ? float(mouse.x) : -1.f, focused ? float(mouse.y) : -1.f);
        profile.Tick(dt);
        if (!profile.open && !searchColor.active && !searchNative.Active())
            presets.Move(focused ? float(mouse.x) : -1.f, focused ? float(mouse.y) : -1.f, &cfg);
        else
            presets.Move(-1, -1);
        presets.Tick(dt, cfg);
        if (!presets.mainSearch) {
            searchColor.Close();
            searchNative.Close();
        } else if (searchColor.active) {
            searchColor.Move(focused ? float(mouse.x) : -1.f, focused ? float(mouse.y) : -1.f, cfg);
            searchColor.picker.Tick(dt);
        }
        searchColor.Tick(dt);
        searchNative.Move(focused ? float(mouse.x) : -1.f, focused ? float(mouse.y) : -1.f, cfg);
        searchNative.Tick(dt, cfg);
        world.Move(focused ? float(mouse.x) : -1.f, focused ? float(mouse.y) : -1.f, cfg);
        menu::KeybindOverrideGuard bindValues(cfg, world.binds.runtime);
        world.Tick(dt, cfg);
        watermarkInput.Tick(dt, cfg);
        watermarkInput.Measure(*fonts, cfg, width, height, true, &profile.languages);
        if (down && !mouseDown && !consumed && !profile.open && !presets.open)
            drag.Begin(layout, float(mouse.x), float(mouse.y));
        drag.Update(layout, float(mouse.x), float(mouse.y), down, focused, width, height);
        layout = menu::AnimatedLayout(width, height, cfg, state, -drag.offsetX, -drag.offsetY);
        int hit = focused && !drag.active && !profile.open && !presets.open && !consumed
                      ? menu::Hit(layout, float(mouse.x), float(mouse.y))
                      : -1;
        state.hover = hit;
        state.profileHover = focused && !drag.active &&
                             menu::ProfileBox(layout, cfg.scale).Contains(float(mouse.x), float(mouse.y));
        if (down && !mouseDown && !consumed)
            state.held = hit;
        if (!down && mouseDown) {
            if (!consumed && !profile.open && !presets.open && focused && hit >= 0 && state.held == hit) {
                if (hit == 7)
                    profile.OpenExtensions(layout, cfg, state, width, height);
                else
                    state.Select(hit);
                dirty = true;
            }
            state.held = -1;
        }
        mouseDown = down;
        state.Tick(dt);
        layout = menu::AnimatedLayout(width, height, cfg, state, -drag.offsetX, -drag.offsetY);
        if (presets.mainSearch) {
            auto& items = presets.mainSearchItems;
            items.clear();
            auto add = [&](const std::u32string& label, const std::u32string& group, int target,
                           menu::MainSearchSource source, int index, bool check, bool numeric, bool enabled,
                           float minimum, float maximum, const std::string& tooltip) {
                if (label.empty())
                    return;
                items.push_back({label, group, target, source, index, check, numeric, enabled, minimum, maximum});
                if (!tooltip.empty() &&
                    (menu::DefaultLanguageStrings().count(tooltip) ||
                     (presets.languages && presets.languages->entries.at(std::size_t(presets.languages->selected))
                                                   .strings.count(tooltip))))
                    items.back().description = presets.Label(tooltip.c_str());
            };
            auto tooltipKey = [](const char* key) {
                return std::string(key) == "enabled" ? std::string{} : std::string(key) + "_tooltip";
            };
            auto path = [](const std::u32string& first, const std::u32string& second) {
                return second.empty() ? first : first + U"  " + second;
            };
            const auto rage = path(presets.Label("section_aimbot"), presets.Label("tab_ragebot"));
            const auto visuals = presets.Label("tab_visuals");
            const auto players = path(visuals, presets.Label("tab_visuals_players"));
            const auto worldLabel = path(visuals, presets.Label("tab_visuals_world"));
            const std::array<const char*, 4> rageGroups{{"group_ragebot_main", "group_ragebot_selection",
                                                         "group_ragebot_other", "group_ragebot_antiaim"}};
            const std::array<const char*, 4> playerGroups{{"group_visuals_enemies_options",
                                                          "group_visuals_enemies_model",
                                                          "group_visuals_teammate_options",
                                                          "group_visuals_teammate_model"}};
            for (std::size_t i = 0; i < menu::RageSpecs.size(); ++i) {
                const auto& d = menu::RageSpecs[i];
                auto group = path(rage, world.rage.Label(rageGroups[std::size_t(d.group)]));
                int root = menu::RageUI::Root(d.popup);
                if (root >= 0 && root != menu::AntiAimEnabled)
                    group = path(group, world.rage.Label(menu::RageSpecs[std::size_t(root)].key));
                add(world.rage.Label(d.key), group, 0, menu::MainSearchSource::Rage, int(i),
                    d.kind == menu::RageKind::Check,
                    d.kind == menu::RageKind::Integer || d.kind == menu::RageKind::Decimal,
                    world.rage.EnabledField(int(i), cfg), d.minimum, d.maximum, d.tooltip);
                if (!items.empty() && items.back().source == menu::MainSearchSource::Rage &&
                    items.back().index == int(i)) {
                    if (menu::RageUI::Detail(int(i)) >= 0 && int(i) != menu::AntiAimEnabled)
                        items.back().detailGroup = path(group, items.back().label);
                    if (items.back().numeric)
                        items.back().display = world.rage.ValueLabel(int(i), cfg);
                    if (int(i) == menu::PeekColor || int(i) == menu::OverrideColor) {
                        items.back().colorSlot = int(i) == menu::PeekColor ? 0 : 1;
                        items.back().colorCount = int(i) == menu::PeekColor ? 1 : 2;
                    }
                    if (d.kind == menu::RageKind::Choice || d.kind == menu::RageKind::Multi) {
                        items.back().options = world.rage.Options(int(i));
                        items.back().multi = d.kind == menu::RageKind::Multi;
                    }
                }
            }
            for (std::size_t i = 0; i < menu::PlayersSpecs.size(); ++i) {
                const auto& d = menu::PlayersSpecs[i];
                auto group = path(players, world.players.Label(playerGroups[std::size_t(d.group)]));
                if (d.parent >= 0)
                    group = path(group, world.players.Label(menu::PlayersSpecs[std::size_t(d.parent)].key));
                add(world.players.Label(d.key), group, 5, menu::MainSearchSource::Players, int(i),
                    d.kind == menu::WorldKind::Check,
                    d.kind == menu::WorldKind::Integer || d.kind == menu::WorldKind::Decimal,
                    world.players.Enabled(int(i), cfg), d.minimum, d.maximum, tooltipKey(d.key));
                if (!items.empty() && items.back().source == menu::MainSearchSource::Players &&
                    items.back().index == int(i) && d.color >= 0) {
                    items.back().colorSlot = d.color;
                    items.back().colorCount = 1;
                }
                if (!items.empty() && items.back().source == menu::MainSearchSource::Players &&
                    items.back().index == int(i) &&
                    (d.kind == menu::WorldKind::Choice || d.kind == menu::WorldKind::Multi)) {
                    for (const auto& k : menu::PlayersOptions(int(i)))
                        items.back().options.push_back(world.players.Label(k));
                    items.back().multi = d.kind == menu::WorldKind::Multi;
                }
            }
            const auto viewGroup = path(worldLabel, world.Label("group_visuals_world_view"));
            const auto espGroup = path(worldLabel, world.Label("group_visuals_world_worldesp"));
            const auto hudGroup = path(worldLabel, world.Label("group_visuals_world_hud"));
            const auto miscGroup = path(worldLabel, world.Label("group_visuals_world_miscellaneous"));
            for (std::size_t i = 0; i < menu::WorldViewSpecs.size(); ++i) {
                const auto& d = menu::WorldViewSpecs[i];
                auto group = path(viewGroup, world.Label(std::string("visuals_world_view_") +
                                                         menu::WorldViewUI::PanelKeys[std::size_t(d.page)]));
                add(world.Label(d.key), group, 6, menu::MainSearchSource::WorldView, int(i),
                    d.kind == menu::WorldKind::Check,
                    d.kind == menu::WorldKind::Integer || d.kind == menu::WorldKind::Decimal,
                    world.Enabled(int(i), cfg), d.minimum, d.maximum, tooltipKey(d.key));
                if (!items.empty() && items.back().source == menu::MainSearchSource::WorldView &&
                    items.back().index == int(i) &&
                    (d.kind == menu::WorldKind::Choice || d.kind == menu::WorldKind::Multi)) {
                    for (const auto& k : menu::WorldViewUI::Options(int(i)))
                        items.back().options.push_back(world.Label(k));
                    items.back().multi = d.kind == menu::WorldKind::Multi;
                }
            }
            for (std::size_t i = 0; i < menu::WorldESPSpecs.size(); ++i) {
                const auto& d = menu::WorldESPSpecs[i];
                auto group = d.page >= 0 && d.page < int(menu::WorldESPPageKeys.size())
                                 ? path(espGroup, world.Label(menu::WorldESPPageKeys[std::size_t(d.page)]))
                                 : espGroup;
                add(world.Label(d.key), group, 6, menu::MainSearchSource::WorldESP, int(i),
                    d.kind == menu::WorldESPKind::Check,
                    d.kind == menu::WorldESPKind::Integer || d.kind == menu::WorldESPKind::Decimal,
                    menu::WorldESPEnabled(int(i), cfg.worldESP), d.minimum, d.maximum, tooltipKey(d.key));
                if (!items.empty() && items.back().source == menu::MainSearchSource::WorldESP &&
                    items.back().index == int(i) && d.color >= 0) {
                    items.back().colorSlot = d.color;
                    items.back().colorCount = d.count;
                }
                if (!items.empty() && items.back().source == menu::MainSearchSource::WorldESP &&
                    items.back().index == int(i) &&
                    (d.kind == menu::WorldESPKind::Choice || d.kind == menu::WorldESPKind::Multi)) {
                    for (const auto& k : menu::WorldESPOptions(int(i)))
                        items.back().options.push_back(world.esp.Label(k));
                    items.back().multi = d.kind == menu::WorldESPKind::Multi;
                }
            }
            for (std::size_t i = 0; i < menu::WorldHudSpecs.size(); ++i) {
                const auto& d = menu::WorldHudSpecs[i];
                auto group = d.page >= 0 && d.page < 5
                                 ? path(hudGroup, world.Label(menu::WorldHudUI::MainKeys[std::size_t(d.page + 1)]))
                                 : hudGroup;
                add(world.Label(d.key), group, 6, menu::MainSearchSource::WorldHud, int(i),
                    d.kind == menu::WorldKind::Check,
                    d.kind == menu::WorldKind::Integer || d.kind == menu::WorldKind::Decimal,
                    world.hud.Enabled(int(i), cfg), d.minimum, d.maximum, tooltipKey(d.key));
                if (!items.empty() && items.back().source == menu::MainSearchSource::WorldHud &&
                    items.back().index == int(i) &&
                    (d.kind == menu::WorldKind::Choice || d.kind == menu::WorldKind::Multi)) {
                    for (const auto& k : menu::WorldHudUI::Options(int(i)))
                        items.back().options.push_back(world.hud.Label(k));
                    items.back().multi = d.kind == menu::WorldKind::Multi;
                }
            }
            for (std::size_t i = 0; i < menu::WorldMiscSpecs.size(); ++i) {
                const auto& d = menu::WorldMiscSpecs[i];
                auto group = d.page >= 0 && d.page < 6
                                 ? path(miscGroup, world.Label(menu::WorldMiscUI::Keys[std::size_t(d.page)]))
                                 : miscGroup;
                std::vector<int> parents;
                for (int parent = d.parent; parent >= 0 && std::size_t(parent) < menu::WorldMiscSpecs.size();
                     parent = menu::WorldMiscSpecs[std::size_t(parent)].parent)
                    parents.push_back(parent);
                for (auto it = parents.rbegin(); it != parents.rend(); ++it)
                    group = path(group, world.misc.Label(menu::WorldMiscSpecs[std::size_t(*it)].key));
                add(world.Label(d.key), group, 6, menu::MainSearchSource::WorldMisc, int(i),
                    d.kind == menu::WorldKind::Check && !WorldMiscDetailsOnly(int(i)) &&
                        !WorldMiscColorOnly(int(i)),
                    d.kind == menu::WorldKind::Integer || d.kind == menu::WorldKind::Decimal,
                    world.misc.Enabled(int(i), cfg), d.minimum, d.maximum, tooltipKey(d.key));
                if (!items.empty() && items.back().source == menu::MainSearchSource::WorldMisc &&
                    items.back().index == int(i) &&
                    ::WorldMiscDetailsButton(d.page, int(i)))
                    items.back().detailGroup = path(group, items.back().label);
                if (!items.empty() && items.back().source == menu::MainSearchSource::WorldMisc &&
                    items.back().index == int(i) && d.color >= 0) {
                    items.back().colorSlot = d.color;
                    items.back().colorCount = d.count;
                }
                if (!items.empty() && items.back().source == menu::MainSearchSource::WorldMisc &&
                    items.back().index == int(i) &&
                    (d.kind == menu::WorldKind::Choice || d.kind == menu::WorldKind::Multi)) {
                    items.back().options = world.misc.Options(int(i));
                    items.back().multi = d.kind == menu::WorldKind::Multi;
                }
            }
            auto& ambience = world.misc.ambience;
            const auto ambienceGroup = path(miscGroup, ambience.Label("visuals_world_miscellaneous_ambience"));
            const auto effectsGroup = path(ambienceGroup, ambience.Label("group_visuals_world_miscellaneous_ambience_effects"));
            for (std::size_t i = 0; i < menu::AmbienceSpecs.size(); ++i) {
                const auto& d = menu::AmbienceSpecs[i];
                auto group = effectsGroup;
                std::vector<int> parents;
                for (int parent = d.parent; parent >= 0 && std::size_t(parent) < menu::AmbienceSpecs.size();
                     parent = menu::AmbienceSpecs[std::size_t(parent)].parent)
                    parents.push_back(parent);
                for (auto it = parents.rbegin(); it != parents.rend(); ++it)
                    group = path(group, ambience.RowLabel(*it));
                add(ambience.RowLabel(int(i)), group, 6, menu::MainSearchSource::Ambience, int(i),
                    d.kind == menu::AmbienceKind::Switch || d.kind == menu::AmbienceKind::Check,
                    d.kind == menu::AmbienceKind::Integer || d.kind == menu::AmbienceKind::Decimal,
                    ambience.Enabled(int(i), cfg), d.minimum, d.maximum, d.tooltip);
                if (!items.empty() && items.back().source == menu::MainSearchSource::Ambience &&
                    items.back().index == int(i)) {
                    items.back().profile = ambience.ProfileIndex(cfg);
                    if (menu::WorldAmbienceUI::HasDetails(int(i)) ||
                        (d.kind == menu::AmbienceKind::Opener && menu::WorldAmbienceUI::HasWindow(int(i))))
                        items.back().detailGroup = path(group, items.back().label);
                    if (d.color >= 0) {
                        items.back().colorSlot = d.color;
                        items.back().colorCount = d.count;
                    }
                    if (items.back().numeric)
                        items.back().display = ambience.ValueText(int(i), cfg);
                    if (d.kind == menu::AmbienceKind::Choice)
                        items.back().options = ambience.Options(int(i));
                }
            }
        }
        presets.Measure(*fonts, cfg, layout, width, height);
        if (presets.mainSearchOpacity.value > 0.f) {
            searchColor.Draw(presets, *fonts, cfg, width, height);
            searchNative.Draw(presets, *fonts, cfg, layout, width, height);
        }
        MeasureWorld(layout);
        acceptPaste = focused && !profile.open && presets.open;
        textInput = focused &&
                    (watermarkInput.settings.Editing() || world.Editing() ||
                     (!profile.open && presets.open && (presets.searchFocus || !presets.renaming.empty())) ||
                     (profile.open && ((profile.modal == 1 && profile.field >= 0 && profile.field <= 2) ||
                                       (profile.modal == 4 && profile.chatFocus && profile.ChatActive()) ||
                                       (profile.picker && profile.pickerField >= 0))));
        menu::NativePreviewRequest previewRequest;

        if (world.players.visible) {
            auto b = world.players.previewBox;
            auto colors = menu::CurrentPalette(cfg);
            auto a = colors[9].a * .7f;
            previewRequest.terrorist = world.players.page == 1;
            previewRequest.enabled = true;
            previewRequest.x = b.x;
            previewRequest.y = b.y;
            previewRequest.w = b.w;
            previewRequest.h = b.h;
            previewRequest.screenW = width;
            previewRequest.screenH = height;
            previewRequest.red = colors[9].r * a + colors[6].r * (1 - a);
            previewRequest.green = colors[9].g * a + colors[6].g * (1 - a);
            previewRequest.blue = colors[9].b * a + colors[6].b * (1 - a);
        }
        if (previewTerrorist != previewRequest.terrorist) {
            previewImage.Reset();
            previewTerrorist = previewRequest.terrorist;
        }
        nativePreview.Submit(previewRequest);
        int layerW = int(std::ceil(layout.outer.w)), layerH = int(std::ceil(layout.outer.h));
        if (!overlay || overlay->width != layerW || overlay->height != layerH) {
            overlay = std::make_unique<menu::Canvas>(layerW, layerH);
            dirty = true;
        }
        std::array<float, 11> animations{};
        std::copy(state.anim.begin(), state.anim.end(), animations.begin());
        animations[8] = state.profileAnim;
        animations[9] = state.visualHeight.value;
        animations[10] = state.visualAlpha.value;
        bool upload = dirty || animations != cachedAnimations || cachedSelected != state.selected ||
                      cachedChild != state.selectedVisual;

        if (upload) {
            auto local = menu::TranslateLayout(layout, -layout.outer.x, -layout.outer.y);
            menu::Render(*overlay, *fonts, cfg, state, local, true);
            cachedAnimations = animations;
            cachedSelected = state.selected;
            cachedChild = state.selectedVisual;
            dirty = false;
        }
        PipelineGuard guard(context1.Get(), ownState.Get());

        menu::DrawDTDemoGPU(renderer, back.Get(), target.Get(), width, height, *fonts, cfg, dtDemo);
        menu::DrawWatermarkGPU(renderer, back.Get(), target.Get(), width, height, *fonts, cfg, watermark);

        const float menuAlpha = std::clamp(menuOpacity.value, 0.f, 1.f);
        const bool fadeCaptured =
            menuAlpha < 1.f && menuFadeCapture.Capture(device.Get(), context.Get(), back.Get());

        renderer.PrepareBackdrop(back.Get(), wm::MainMenuBlurSigma(cfg.scale), cfg.blur);
        menu::DrawMenuGPU(renderer, target.Get(), width, height, *overlay, cfg, state, layout, upload,
                          layout.outer.x, layout.outer.y);
        if (world.inventory.visible)
            inventoryBackground.Draw(renderer, target.Get(), width, height, layout.content, 16 * cfg.scale,
                                     world.inventory.BackgroundMix(), state.contentTransition.renderAlpha);
        if (previewRequest.enabled) {
            const auto child = world.players.previewBox, box = world.players.boundingBox;
            const auto size = preview_research::OriginalGeometry(box.w);
            if (size.width > 0 && size.height > 0) {
                const float x = box.x + box.w * .5f - size.halfWidth;
                const float y = box.y + box.h * .5f - size.halfHeight;

                const auto previewNow = GetTickCount64();
                if (nativePreview.Confirmed(previewRequest))
                    nativePreview.WithFrame(
                        [&](ID3D11ShaderResourceView* source, const std::array<float, 4>& uv) {
                            return previewImage.Copy(context.Get(), source, uv, previewNow);
                        });
                if (auto* source = previewImage.View(previewNow)) {
                    auto pageClip = menu::PresetIntersect(child, layout.content);
                    renderer.SetClip(pageClip.x, pageClip.y, pageClip.w, pageClip.h);
                    renderer.DrawExternalTexture(
                        target.Get(), source, width, height, x, y, float(size.width), float(size.height),
                        previewImage.UV(), wm::TextureAlpha::Straight, state.contentTransition.renderAlpha);
                    renderer.ClearClip();
                }
            } else
                previewImage.Reset();
        } else
            previewImage.Reset();
        presetsGPU.Draw(renderer, back.Get(), target.Get(), width, height, *fonts, cfg, presets, 1);
        menu::DrawPresetsGPU(renderer, back.Get(), target.Get(), width, height, *fonts, cfg, world.paint, 0,
                             &worldPaint);
        presetsGPU.Draw(renderer, back.Get(), target.Get(), width, height, *fonts, cfg, presets, 2);
        profileGPU.Draw(renderer, back.Get(), target.Get(), width, height, *fonts, cfg, profile, dirty);
        menu::DrawPresetsGPU(renderer, back.Get(), target.Get(), width, height, *fonts,
                             menu::WatermarkInteraction::Presentation(cfg), watermarkInput.settings.paint, 0,
                             &watermarkPaint);
        if (fadeCaptured) {
            renderer.ClearClip();
            renderer.DrawExternalTexture(target.Get(), menuFadeCapture.View(), width, height, 0, 0,
                                         float(width), float(height), {0, 0, 1, 1}, wm::TextureAlpha::Opaque,
                                         1.f - menuAlpha);
        }
        menu::DrawStartupGPU(renderer, back.Get(), target.Get(), width, height, *fonts, cfg, startup);
        startupPending = startup.Active();
    }
};
std::unique_ptr<Overlay> overlay;
bool failed = false;
HRESULT STDMETHODCALLTYPE OnPresent(IDXGISwapChain* chain, UINT sync, UINT flags) {
    Callback callback;
    if (!stopping && !(flags & DXGI_PRESENT_TEST)) {
        std::lock_guard<std::recursive_mutex> lock(renderMutex);

        if (!failed && (visible || startupPending || overlay) &&
            engineSwapchain.Current(selectedEngineChain, reinterpret_cast<std::uintptr_t>(chain)))
            try {

                if (overlay && overlay->chain.Get() != chain) {
                    DXGI_SWAP_CHAIN_DESC replacement{};
                    Check(chain->GetDesc(&replacement), "replacement swapchain description");
                    ComPtr<ID3D11Device> replacementDevice;
                    Check(chain->GetDevice(IID_PPV_ARGS(&replacementDevice)), "replacement swapchain device");
                    if (replacement.OutputWindow != gameWindow.load() ||
                        replacementDevice.Get() != overlay->device.Get())
                        throw std::runtime_error("Engine swapchain changed HWND/device; rendering stopped, "
                                                 "reload overlay for the new device/window");

                    inventoryPreview.Reset();
                    nativePreview.ResetArtwork(inventoryArtworkReadback);
                    overlay->ReleaseBackbuffer();
                    overlay->CancelUIInput();
                    uiInput.clear();
                    overlay->chain = chain;
                    overlay->last = std::chrono::steady_clock::now();
                }
                if (!overlay) {
                    DXGI_SWAP_CHAIN_DESC desc{};
                    Check(chain->GetDesc(&desc), "swapchain description");
                    DWORD process = 0;
                    GetWindowThreadProcessId(desc.OutputWindow, &process);

                    if (reinterpret_cast<std::uintptr_t>(desc.OutputWindow) == selectedEngineChain.window &&
                        IsWindow(desc.OutputWindow) && process == GetCurrentProcessId() &&
                        GetAncestor(desc.OutputWindow, GA_ROOT) == desc.OutputWindow &&
                        !(GetWindowLongPtrW(desc.OutputWindow, GWL_STYLE) & WS_CHILD)) {
                        auto next = std::make_unique<Overlay>(chain);
                        gameWindow = desc.OutputWindow;
                        auto before =
                            reinterpret_cast<WNDPROC>(GetWindowLongPtrW(desc.OutputWindow, GWLP_WNDPROC));
                        if (!before)
                            throw std::runtime_error("Original WndProc unavailable");
                        previousProc = before;
                        SetLastError(0);
                        auto old = reinterpret_cast<WNDPROC>(SetWindowLongPtrW(
                            desc.OutputWindow, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(Input)));
                        if (!old && GetLastError() != 0) {
                            previousProc = nullptr;
                            gameWindow = nullptr;
                            throw std::runtime_error("WndProc subclass failed");
                        }
                        if (old)
                            previousProc = old;
                        overlay = std::move(next);
                    }
                }
                nativeInventory.NoteEnginePresent();
                if (overlay && overlay->chain.Get() == chain) {
                    DWORD process = 0;
                    GetWindowThreadProcessId(GetForegroundWindow(), &process);
                    if (menuToggleInput.Take(process == GetCurrentProcessId())) {
                        visible = !visible.load();
                        if (!visible)
                            nativePreview.Submit({});
                        uiInput.clear();
                        acceptPaste = false;
                        textInput = false;
                        if (!visible)
                            overlay->FlushPresets(false);
                        overlay->CancelUIInput();
                        overlay->mouseDown = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
                        overlay->last = std::chrono::steady_clock::now();
                    }
                    if (nativePreview.ArtworkNeedsPump(overlay->device.Get(), inventoryArtworkReadback)) {
                        PipelineGuard guard(overlay->context1.Get(), overlay->ownState.Get());
                        nativePreview.PumpArtwork(overlay->device.Get(), overlay->context.Get(),
                                                  inventoryArtworkReadback);
                    }

                    if (clipboardMessage && !cursorMessagePending.exchange(true)) {
                        if (!PostMessageW(gameWindow.load(), clipboardMessage, 2, 0))
                            cursorMessagePending = false;
                    }
                    {
                        menu::InventoryPreviewFrame inventoryFrame(
                            inventoryPreview, nativePreview, overlay->world.inventory, overlay->context.Get(),
                            visible.load() && overlay->startup.MenuReady());
                        overlay->Draw();
                    }
                    std::vector<menu::local_weapons::Spec> localWeapons;
                    std::array<menu::knife_autoequip::Desired, 2> localKnives{};
                    std::vector<menu::local_autoequip::Desired> localEquips;
                    std::array<menu::local_weapons::Spec, 2> localMusic{}, localMedals{};
                    std::array<bool, 2> hasMusic{}, hasMedal{};
                    unsigned missingPaint = 0, invalidDecorations = 0;

                    overlay->world.inventory.RefreshCatalog();
                    const auto& cat = overlay->world.inventory.Cat();
                    if (cat.loaded) {
                        auto addLocal = [&](const menu::local_weapons::Spec& v) {
                            if (std::find(localWeapons.begin(), localWeapons.end(), v) ==
                                    localWeapons.end() &&
                                localWeapons.size() < 70)
                                localWeapons.push_back(v);
                        };
                        for (int side = 0; side < 2; ++side) {
                            const auto& team = overlay->cfg.inventory.teams[std::size_t(side)];
                            for (const auto& item : team.items) {

                                if (!menu::InventorySelectedForLocalCopy(team, side, item.index))
                                    continue;
                                const bool weapon = menu::InventoryWeapon(item.index) != nullptr;
                                const bool special =
                                    menu::InventoryKnife(item.index) || menu::InventoryGlove(item.index);
                                if ((!weapon && !special) || (weapon && item.paintKit <= 0) ||
                                    item.paintKit < 0)
                                    continue;
                                const auto* paint = item.paintKit ? cat.Paint(item.paintKit) : nullptr;
                                if (item.paintKit && !paint) {
                                    ++missingPaint;
                                    continue;
                                }
                                menu::local_weapons::Spec v;
                                v.definition = item.index;
                                v.paint = item.paintKit;
                                v.seed = std::clamp(item.seed, 0, 1000);
                                v.wear = paint ? menu::InventoryWearFloat(item.wearTier, item.wearValue,
                                                                          paint->wearMin, paint->wearMax)
                                               : 0.f;
                                v.rarity =
                                    paint
                                        ? std::clamp(
                                              overlay->world.inventory.DisplayRarity(item.index, paint), 1, 7)
                                    : special ? 6
                                              : 1;
                                v.statTrak = item.statTrak && !menu::InventoryGlove(item.index)
                                                 ? std::max(0, item.statTrakValue)
                                                 : -1;
                                if (weapon) {
                                    for (std::size_t i = 0; i < v.decorations.stickers.size(); ++i) {
                                        const auto& x = item.stickers[i];
                                        v.decorations.stickers[i] = {x.id, x.x, x.y, x.rotation};
                                    }
                                    v.decorations.charm = {item.charm.id, item.charm.pattern, item.charm.x,
                                                           item.charm.y, item.charm.z};
                                }
                                if (!menu::local_decorations::Valid(v.decorations)) {
                                    ++invalidDecorations;
                                    continue;
                                }
                                addLocal(v);
                                if (menu::InventoryKnife(item.index) && item.index == team.knife)
                                    localKnives[std::size_t(side)] = {true, v};
                                if (weapon || menu::InventoryGlove(item.index)) {
                                    int slotHint = -1;
                                    if (weapon) {
                                        const auto it =
                                            std::find(team.slots.begin(), team.slots.end(), item.index);
                                        if (it != team.slots.end()) {
                                            const int card = int(it - team.slots.begin());
                                            slotHint = card < 5    ? 2 + card
                                                       : card < 10 ? 8 + card - 5
                                                                   : 14 + card - 10;
                                        }
                                    }
                                    localEquips.push_back({side == 0 ? 3 : 2,
                                                           weapon ? menu::local_autoequip::Category::Weapon
                                                                  : menu::local_autoequip::Category::Gloves,
                                                           v, slotHint});
                                }
                            }

                            for (int index : {team.knife, team.gloves})
                                if (index > 0 && !team.Find(index) &&
                                    (menu::InventoryKnife(index) || menu::InventoryGlove(index))) {
                                    menu::local_weapons::Spec v;
                                    v.definition = index;
                                    v.rarity = 6;
                                    addLocal(v);
                                    if (index == team.knife && menu::InventoryKnife(index))
                                        localKnives[std::size_t(side)] = {true, v};
                                    if (menu::InventoryGlove(index))
                                        localEquips.push_back(
                                            {side == 0 ? 3 : 2, menu::local_autoequip::Category::Gloves, v});
                                }
                            menu::local_weapons::Spec agentCopy;
                            if (menu::InventorySelectedLocalAgent(cat, team, side, agentCopy)) {
                                addLocal(agentCopy);
                                localEquips.push_back(
                                    {side == 0 ? 3 : 2, menu::local_autoequip::Category::Agent, agentCopy});
                            }
                            for (const auto& medal : cat.medals)
                                if (medal.id == team.medal && medal.id > 0 && medal.id <= 65535) {
                                    menu::local_weapons::Spec v;
                                    v.kind = menu::local_weapons::Kind::Medal;
                                    v.definition = medal.id;
                                    v.rarity = std::clamp(medal.rarity, 1, 7);
                                    addLocal(v);
                                    localMedals[std::size_t(side)] = v;
                                    hasMedal[std::size_t(side)] = true;
                                    break;
                                }
                            for (const auto& music : cat.music)
                                if (music.id == team.music && music.id > 0 && music.id <= 65535) {
                                    menu::local_weapons::Spec v;
                                    v.kind = menu::local_weapons::Kind::Music;
                                    v.definition = 1314;
                                    v.paint = music.id;
                                    v.rarity = std::clamp(music.rarity, 1, 7);
                                    addLocal(v);
                                    localMusic[std::size_t(side)] = v;
                                    hasMusic[std::size_t(side)] = true;
                                    break;
                                }
                        }

                        auto globalEquip = [&](const auto& specs, const auto& selected,
                                               menu::local_autoequip::Category kind) {
                            if (selected[0] && selected[1] && !(specs[0] == specs[1]))
                                return;
                            const int side = selected[0] ? 0 : selected[1] ? 1 : -1;
                            if (side >= 0)
                                localEquips.push_back({0, kind, specs[std::size_t(side)]});
                        };
                        globalEquip(localMusic, hasMusic, menu::local_autoequip::Category::Music);
                        globalEquip(localMedals, hasMedal, menu::local_autoequip::Category::Medal);
                        (void)invalidDecorations;
                        nativeLocalCharm.SubmitWeapons(std::move(localWeapons), missingPaint,
                                                       std::move(localKnives), std::move(localEquips));
                        nativeInventory.SubmitKnifePlan(
                            menu::knife_experiment::MakePlan(cat, overlay->cfg.inventory));
                        nativeInventory.SubmitGlovePlan(
                            menu::glove_inmatch::MakePlan(cat, overlay->cfg.inventory));
                        nativeInventory.SubmitGunPlan(
                            menu::weapon_inmatch::MakePlan(cat, overlay->cfg.inventory));
                    }

                    nativeInventory.Submit(overlay->cfg.inventory, false);
                }
            } catch (const std::exception& e) {
                failed = true;
                visible = false;
                acceptPaste = false;
                textInput = false;
                nativePreview.Submit({});
                nativeCamera.Clear();
                nativeHitSound.Clear();
                if (overlay)
                    overlay->FlushPresets(false);
                if (clipboardMessage && !cursorMessagePending.exchange(true)) {
                    if (!PostMessageW(gameWindow.load(), clipboardMessage, 2, 0))
                        cursorMessagePending = false;
                }
            }
    }
    return nextPresent(chain, sync, flags);
}
HRESULT STDMETHODCALLTYPE OnResize(IDXGISwapChain* chain, UINT count, UINT w, UINT h, DXGI_FORMAT format,
                                   UINT flags) {
    Callback callback;
    std::lock_guard<std::recursive_mutex> lock(renderMutex);

    if (overlay && overlay->chain.Get() == chain)
        try {
            nativePreview.Submit({});
            inventoryPreview.Reset();
            nativePreview.ResetArtwork(inventoryArtworkReadback);
            overlay->ReleaseBackbuffer();
        } catch (const std::exception& e) {
            failed = true;
            visible = false;
            acceptPaste = false;
            textInput = false;
            nativePreview.Submit({});
            if (overlay)
                overlay->FlushPresets(false);
            if (clipboardMessage && !cursorMessagePending.exchange(true)) {
                if (!PostMessageW(gameWindow.load(), clipboardMessage, 2, 0))
                    cursorMessagePending = false;
            }
        }
    return nextResize(chain, count, w, h, format, flags);
}
bool EngineWindow(std::uintptr_t handle) {
    auto window = reinterpret_cast<HWND>(handle);
    DWORD process = 0;
    GetWindowThreadProcessId(window, &process);
    return IsWindow(window) && process == GetCurrentProcessId() && GetAncestor(window, GA_ROOT) == window &&
           !(GetWindowLongPtrW(window, GWL_STYLE) & WS_CHILD);
}
bool SampleEngineChain(menu::RenderSystemChain& chain, std::string& diagnostic) {
    chain = {};
    if (!engineSwapchain.Resolve()) {
        diagnostic = engineSwapchain.Diagnostic();
        return false;
    }
    menu::RenderSystemChains sample;
    const char* reason = nullptr;
    if (!engineSwapchain.Sample(sample, reason) ||
        !menu::SelectRenderSystemChain(sample, EngineWindow, chain, reason)) {
        diagnostic = reason ? reason : "engine registry unavailable";
        return false;
    }
    diagnostic = reason;
    return true;
}
void GetHookAddresses() {
    const auto deadline = GetTickCount64() + 120000;
    ULONGLONG nextReport = 0;
    std::string diagnostic;
    while (!stopping && GetTickCount64() < deadline) {
        DWORD process = 0;
        GetWindowThreadProcessId(GetForegroundWindow(), &process);
        if (process == GetCurrentProcessId() && (GetAsyncKeyState(VK_DELETE) & 0x8000))
            throw std::runtime_error("Engine swapchain wait cancelled by Delete.");
        menu::RenderSystemChain chain;
        const bool sampled = SampleEngineChain(chain, diagnostic);
        if (sampled && engineSwapchain.PinMethods(chain)) {
            selectedEngineChain = chain;
            presentAddress = reinterpret_cast<void*>(chain.present);
            resizeAddress = reinterpret_cast<void*>(chain.resize);
            return;
        }
        if (sampled)
            diagnostic = "engine candidate changed or DXGI code owners could not be pinned; retrying";
        if (engineSwapchain.Unsupported())
            throw std::runtime_error(engineSwapchain.Diagnostic());
        if (GetTickCount64() >= nextReport) {
            nextReport = GetTickCount64() + 3000;
        }
        Sleep(100);
    }
    throw std::runtime_error(
        "Engine DX11 swapchain not ready after 120s; no dummy fallback (Vulkan/changed ABI unsupported).");
}
void HookCheck(MH_STATUS status, const char* step) {
    if (status != MH_OK)
        throw std::runtime_error(std::string(step) + ": " + MH_StatusToString(status));
}
DWORD WINAPI Worker(void*) {
    bool initialized = false, createdPresent = false, createdResize = false;
    try {
        wchar_t path[32768]{};
        auto n = GetModuleFileNameW(module, path, DWORD(std::size(path)));
        if (!n || n >= std::size(path))
            throw std::runtime_error("DLL path unavailable");
        root = fs::path(path).parent_path();
        clipboardMessage = RegisterWindowMessageW(L"MenuStudioOverlay.Clipboard");
        if (!clipboardMessage)
            throw std::runtime_error("Clipboard registration failed");
        GetHookAddresses();
        HookCheck(MH_Initialize(), "MinHook init");
        initialized = true;
        HookCheck(MH_CreateHook(presentAddress, reinterpret_cast<void*>(OnPresent),
                                reinterpret_cast<void**>(&nextPresent)),
                  "Present hook");
        createdPresent = true;
        HookCheck(MH_CreateHook(resizeAddress, reinterpret_cast<void*>(OnResize),
                                reinterpret_cast<void**>(&nextResize)),
                  "Resize hook");
        createdResize = true;
        HookCheck(MH_QueueEnableHook(presentAddress), "queue Present");
        HookCheck(MH_QueueEnableHook(resizeAddress), "queue Resize");
        HookCheck(MH_ApplyQueued(), "enable hooks");
        nativePreview.Attach(nativeHud);
        nativeScoreboard.Attach(nativeHud);
        nativeHitSound.Attach(nativeHud);
        nativeInventory.Attach(nativeHud);
        nativeLocalCharm.Attach(nativeHud);
        ULONGLONG nextProbe = 0, nextChainProbe = 0;
        bool deleteWasDown = false;
        while (!stopping) {
            const auto now = GetTickCount64();
            if (now >= nextChainProbe) {
                nextChainProbe = now + 250;
                menu::RenderSystemChain chain;
                std::string diagnostic;
                bool ready = SampleEngineChain(chain, diagnostic);
                if (ready && (chain.present != reinterpret_cast<std::uintptr_t>(presentAddress) ||
                              chain.resize != reinterpret_cast<std::uintptr_t>(resizeAddress)))
                    ready = false;
                std::lock_guard<std::recursive_mutex> lock(renderMutex);
                selectedEngineChain = ready ? chain : menu::RenderSystemChain{};
            }
            nativePreview.PumpInventoryAssets();
            if (now >= nextProbe) {
                nextProbe = now + 1000;
                nativePreview.TryStart();
                nativeScoreboard.TryStart();
                nativeHitSound.TryStart();
                nativeCamera.TryStart();
                nativeInventory.TryStart();
                nativeLocalCharm.TryStart();
                nativeHud.TryStart();
                if (!inventoryContentStarted)
                    if (auto client = GetModuleHandleW(L"client.dll")) {
                        wchar_t clientPath[32768]{};
                        const auto length =
                            GetModuleFileNameW(client, clientPath, DWORD(std::size(clientPath)));
                        if (length && length < std::size(clientPath)) {
                            menu::InventorySharedContent().Start(
                                menu::InventoryGuessCsgoDir(fs::path(clientPath)));
                            inventoryContentStarted = true;
                        }
                    }
            }
            DWORD process = 0;
            GetWindowThreadProcessId(GetForegroundWindow(), &process);
            bool del = process == GetCurrentProcessId() && (GetAsyncKeyState(VK_DELETE) & 0x8000) != 0;
            if (del && !deleteWasDown && !(visible.load() && textInput.load())) {
                std::lock_guard<std::recursive_mutex> lock(renderMutex);
                bool assigned =
                    overlay && std::any_of(overlay->cfg.keybinds.begin(), overlay->cfg.keybinds.end(),
                                           [](const auto& b) { return b.key == VK_DELETE; });
                if (!assigned)
                    stopping = true;
            }
            deleteWasDown = del;
            Sleep(10);
        }
    } catch (...) {
        stopping = true;
    }
    menuToggleInput.Cancel();
    visible = false;
    acceptPaste = false;
    textInput = false;
    {
        std::lock_guard<std::recursive_mutex> lock(renderMutex);
        uiInput.clear();
        if (overlay) {
            overlay->CancelUIInput();
            overlay->FlushPresets(true);
        }
    }
    {
        std::lock_guard<std::mutex> lock(clipboardMutex);
        clipboardCopy.clear();
    }
    bool cameraSafe = nativeCamera.Stop();
    bool soundSafe = nativeHitSound.Stop();
    bool scoreboardSafe = nativeScoreboard.Stop();
    bool previewSafe = nativePreview.Stop();
    bool inventorySafe = nativeInventory.Stop();
    bool localCharmSafe = inventorySafe && nativeLocalCharm.Stop();
    menu::InventorySharedContent().Wait();
    bool hudSafe = nativeHud.StopAndRestore();
    bool safe = previewSafe && hudSafe && inventorySafe && localCharmSafe && scoreboardSafe && cameraSafe &&
                soundSafe;
    if (createdPresent) {
        auto status = MH_DisableHook(presentAddress);
        if (status != MH_OK && status != MH_ERROR_DISABLED)
            safe = false;
    }
    if (createdResize) {
        auto status = MH_DisableHook(resizeAddress);
        if (status != MH_OK && status != MH_ERROR_DISABLED)
            safe = false;
    }
    HWND window = gameWindow.load();
    auto old = previousProc.load();
    bool cursorRestoreAcknowledged = true;
    if (window && old && IsWindow(window) && clipboardMessage) {
        DWORD_PTR result = 0;
        if (!SendMessageTimeoutW(window, clipboardMessage, 2, 0, SMTO_ABORTIFHUNG | SMTO_BLOCK, 2000,
                                 &result)) {
            cursorRestoreAcknowledged = false;
            safe = false;
        }
    }
    if (window && old && IsWindow(window) && cursorRestoreAcknowledged) {
        if (reinterpret_cast<WNDPROC>(GetWindowLongPtrW(window, GWLP_WNDPROC)) == Input) {
            SetLastError(0);
            if (!SetWindowLongPtrW(window, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(old)))
                safe = false;
        } else
            safe = false;
    }
    if (!safe)
        return 0;
    while (active.load() != 0)
        Sleep(10);
    Sleep(100);
    while (active.load() != 0)
        Sleep(10);
    {
        std::lock_guard<std::recursive_mutex> lock(renderMutex);
        inventoryPreview.Reset();
        nativePreview.ResetArtwork(inventoryArtworkReadback);
        overlay.reset();
    }
    if (createdResize && MH_RemoveHook(resizeAddress) != MH_OK)
        return 0;
    if (createdPresent && MH_RemoveHook(presentAddress) != MH_OK)
        return 0;
    nativeHud.SetFrameObserver(nullptr);
    nativeHud.SetScoreboardFrameObserver(nullptr);
    nativeHud.SetMarkerFrameObserver(nullptr);
    nativeHud.SetInventoryFrameObserver(nullptr);
    nativeHud.SetLocalCharmFrameObserver(nullptr);
    if (!nativeHud.RemoveHook())
        return 0;
    if (!nativeCamera.RemoveHook())
        return 0;
    if (initialized && MH_Uninitialize() != MH_OK)
        return 0;
    engineSwapchain.ReleaseAfterHooks();
    FreeLibraryAndExitThread(module, 0);
}
}
BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        module = instance;
        DisableThreadLibraryCalls(instance);
        HANDLE thread = CreateThread(nullptr, 0, Worker, nullptr, 0, nullptr);
        if (!thread)
            return FALSE;
        CloseHandle(thread);
    }
    return TRUE;
}
