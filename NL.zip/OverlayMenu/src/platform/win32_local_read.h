#pragma once
#if defined(_WIN32) || defined(MENU_STUDIO_AMBIENCE_TEST) || defined(MENU_STUDIO_MODEL_EFFECTS_TEST) ||      \
    defined(MENU_STUDIO_IMPACTS_TEST) || defined(MENU_STUDIO_HITMARKER_TEST) ||                              \
    defined(MENU_STUDIO_KILL_EFFECT_TEST) || defined(MENU_STUDIO_SCOREBOARD_TEST) ||                         \
    defined(MENU_STUDIO_INVENTORY_TEST)
#include <windows.h>
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace menu {
#if defined(MENU_STUDIO_LOCAL_COPY_TEST)

bool LocalReadTestCopy(std::uintptr_t, void*, std::size_t);
bool LocalWriteTestCopy(std::uintptr_t, const void*, std::size_t);
#endif
inline bool LocalReadUserRange(std::uintptr_t at, std::size_t size) {
    constexpr std::uintptr_t last = 0x00007fffffffffffULL;
    return size && at >= 0x10000 && at <= last && size - 1 <= last - at;
}

inline bool LocalReadBytes(std::uintptr_t at, void* out, std::size_t size) {
    if (!out || !LocalReadUserRange(at, size))
        return false;
#if defined(MENU_STUDIO_LOCAL_COPY_TEST)
    return LocalReadTestCopy(at, out, size);
#elif defined(MENU_STUDIO_AMBIENCE_TEST) || defined(MENU_STUDIO_SOUNDS_TEST_STUB) ||                         \
    defined(MENU_STUDIO_ESP_TEST_STUB) || defined(MENU_STUDIO_KD_TEST_STUB) ||                               \
    defined(MENU_STUDIO_CHAMS_TEST_STUB) || defined(MENU_STUDIO_HITMARKER_TEST) ||                           \
    defined(MENU_STUDIO_KILL_EFFECT_TEST) || defined(MENU_STUDIO_IMPACTS_TEST)

    SIZE_T got = 0;
    return ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(at), out, size, &got) &&
           got == size;
#elif defined(_MSC_VER)
    __try {
        std::memcpy(out, reinterpret_cast<const void*>(at), size);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
#else
#error In-process local reads require MSVC SEH or explicit synthetic tests.
#endif
}

inline bool LocalWriteBytes(std::uintptr_t at, const void* data, std::size_t size) {
    if (!data || !LocalReadUserRange(at, size))
        return false;
#if defined(MENU_STUDIO_LOCAL_COPY_TEST)
    return LocalWriteTestCopy(at, data, size);
#elif defined(MENU_STUDIO_AMBIENCE_TEST) || defined(MENU_STUDIO_SOUNDS_TEST_STUB) ||                         \
    defined(MENU_STUDIO_ESP_TEST_STUB) || defined(MENU_STUDIO_KD_TEST_STUB) ||                               \
    defined(MENU_STUDIO_CHAMS_TEST_STUB) || defined(MENU_STUDIO_HITMARKER_TEST) ||                           \
    defined(MENU_STUDIO_KILL_EFFECT_TEST) || defined(MENU_STUDIO_IMPACTS_TEST)
    return false;
#elif defined(_MSC_VER)
    __try {
        std::memcpy(reinterpret_cast<void*>(at), data, size);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
#else
#error In-process local writes require MSVC SEH or explicit synthetic tests.
#endif
}
inline const char* LocalReadBackend() {
#if defined(MENU_STUDIO_LOCAL_COPY_TEST)
    return "registered-local-copy";
#elif defined(MENU_STUDIO_AMBIENCE_TEST) || defined(MENU_STUDIO_SOUNDS_TEST_STUB) ||                         \
    defined(MENU_STUDIO_ESP_TEST_STUB) || defined(MENU_STUDIO_KD_TEST_STUB) ||                               \
    defined(MENU_STUDIO_CHAMS_TEST_STUB) || defined(MENU_STUDIO_HITMARKER_TEST) ||                           \
    defined(MENU_STUDIO_KILL_EFFECT_TEST) || defined(MENU_STUDIO_IMPACTS_TEST)
    return "legacy-fixture-RPM";
#else
    return "local-seh";
#endif
}
}
#endif
