#pragma once

#include <windows.h>
#include <shellapi.h>
#include <filesystem>
#include <string>
#include <system_error>
#include "profile_image_win32.h"
#include "world_ambience_ui.h"
namespace menu {

inline std::string AmbienceIniText(const std::filesystem::path& ini, const wchar_t* key,
                                   const wchar_t* fallback) {
    wchar_t value[256]{};
    GetPrivateProfileStringW(L"Ambience", key, fallback, value, DWORD(std::size(value)), ini.c_str());
    std::string out;
    for (const wchar_t* p = value; *p; ++p) {
        if (*p > 0x7f)
            return {};
        out += char(*p);
    }
    while (!out.empty() && (out.back() == ' ' || out.back() == '\t'))
        out.pop_back();
    std::size_t lead = 0;
    while (lead < out.size() && (out[lead] == ' ' || out[lead] == '\t'))
        ++lead;
    return out.substr(lead);
}

inline std::shared_ptr<ProfileImage> LoadAmbienceMapImage(const std::filesystem::path& folder,
                                                          const std::string& name) {
    if (!WorldAmbienceValues::ValidMap(name) || name.front() == '<')
        return {};
    for (const char* suffix : {".png", "_png.png", ".jpg", ".jpeg"}) {
        std::error_code error;
        const auto file = folder / (name + suffix);
        if (!std::filesystem::is_regular_file(file, error))
            continue;
        try {
            return LoadProfileImage(file);
        } catch (const std::exception&) {
            return {};
        }
    }
    return {};
}

inline void ConfigureAmbienceSkyHost(WorldAmbienceUI& ui, const std::filesystem::path& root) {
    const auto folder = root / L"assets/ambience/skyboxes";
    auto cache = std::make_shared<std::map<std::string, AmbienceImageResult<ProfileImage>>>();
    ui.skyRefresh = [cache] { cache->clear(); };
    ui.skyImageQuery = [folder, cache](const std::string& id) {
        auto it = cache->find(id);
        if (it != cache->end())
            return it->second;
        AmbienceImageResult<ProfileImage> r;
        r.state = AmbienceImageState::Missing;
        if (AmbienceSkyIndex(id) <= 0)
            return r;
        auto image = LoadAmbienceMapImage(folder, id);
        if (image) {
            r.image = std::move(image);
            r.revision = 1;
            r.state = AmbienceImageState::Ready;
        }
        (*cache)[id] = r;
        return r;
    };
    ui.skyOpenFolder = [folder] {
        std::error_code error;
        std::filesystem::create_directories(folder, error);
        if (!error)
            ShellExecuteW(nullptr, L"open", folder.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    };
}
inline void ConfigureAmbienceHost(WorldAmbienceUI& ui, const std::filesystem::path& root) {
    ConfigureAmbienceSkyHost(ui, root);
    const auto ini = root / L"MenuStudio.ini";
    const auto map = AmbienceIniText(ini, L"CurrentMap", L"");
    ui.currentMap = WorldAmbienceValues::ValidMap(map) ? map : std::string{};
    wchar_t images[32768]{};
    GetPrivateProfileStringW(L"Ambience", L"MapImages", L"assets/ambience/maps", images,
                             DWORD(std::size(images)), ini.c_str());
    if (!images[0]) {
        ui.mapImageLoader = nullptr;
        return;
    }
    std::filesystem::path folder(images);
    if (!folder.is_absolute())
        folder = root / folder;
    ui.mapImageLoader = [folder](const std::string& name) { return LoadAmbienceMapImage(folder, name); };
}
}
