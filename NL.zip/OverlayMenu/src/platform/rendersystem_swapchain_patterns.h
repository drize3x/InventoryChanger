#pragma once
#include "watermark_hud_patterns.h"
namespace menu {
namespace rendersystem_swapchain_patterns {

inline constexpr char Device[] = "48 8B 3D ? ? ? ? F7 87 D4 06 00 00 FF FF FF 7F 75 ? 41 8B FF EB ? 48 8B BF "
                                 "D8 06 00 00 48 63 C2 48 03 C0 48 8B 7C C7 F0";
inline constexpr char List[] =
    "8B 97 E0 06 00 00 83 FA FF 74 ? 44 8B 87 D4 06 00 00 41 0F BA F0 1F 90 49 8B C2 45 85 C0 74 ? 48 8B 87 "
    "D8 06 00 00 48 63 CA 48 03 C9 48 8B 04 C8 48 39 58 40";
inline constexpr char Next[] = "48 8B 97 D8 06 00 00 8B 54 CA 0C 83 FA FF 75 ?";
inline constexpr char Remove[] = "43 89 74 F8 0C 43 89 74 F8 08 FF 8B EC 06 00 00 F7 02 FF FF FF 7F";
inline constexpr char Constructor[] =
    "48 8D 05 ? ? ? ? 48 89 B9 F8 01 00 00 40 88 79 50 48 89 01 66 89 B9 60 01 00 00 48 89 B9 68 01 00 00 48 "
    "89 B9 70 01 00 00 48 89 B9 80 01 00 00";
inline constexpr char Destructor[] =
    "48 89 5C 24 08 48 89 74 24 18 57 48 83 EC 20 48 8D 05 ? ? ? ? 8B FA 48 89 01 48 8B D9 E8 ? ? ? ? 48 8B "
    "8B 70 01 00 00 33 F6 48 85 C9 74 ? 89 74 24 38 48 8D 54 24 38 48 8B 01 45 33 C0 FF 50 58";
inline constexpr char Release[] = "48 8B 8B 70 01 00 00 48 8B 01 FF 50 10 48 89 B3 70 01 00 00";
inline constexpr char Resize[] =
    "48 8B 8F 70 01 00 00 48 8D 55 E0 48 8B 01 FF 50 70 85 C0 79 ? 48 8D 15 ? ? ? ? 8B C8 E8 ? ? ? ? 48 8B "
    "8F 70 01 00 00 45 33 C9 45 33 C0 33 D2 48 8B 01 4C 8B 50 68 8B 87 00 02 00 00 89 44 24 28 89 5C 24 20 "
    "41 FF D2 85 C0 79 ? 48 8D 15 ? ? ? ? 8B C8 E8 ? ? ? ?";
inline constexpr char Window[] = "49 8B D4 48 8B 43 10 49 8B CD 48 89 44 24 70 8B 47 04";
}
struct RenderSystemSwapchainBindings {
    std::uintptr_t deviceGlobal = 0, deviceVtable = 0, wrapperVtable = 0;
    std::uint32_t registry = 0, window = 0, dxgi = 0;
};
inline bool ResolveRenderSystemSwapchain(const HudScanImage& image, RenderSystemSwapchainBindings& result,
                                         std::string& diagnostic) {
    result = {};
    RenderSystemSwapchainBindings b;
    std::ostringstream log;
    log << "RenderSystem swapchain: ";
    auto fail = [&](const char* reason) {
        diagnostic = log.str() + "FAIL " + reason;
        return false;
    };
    auto unique = [&](const char* name, const char* pattern, std::uintptr_t& at) {
        auto hits = image.Find(pattern, true, 2);
        log << name << '=' << hits.size() << "; ";
        if (hits.size() != 1)
            return false;
        at = hits[0];
        return true;
    };
    using namespace rendersystem_swapchain_patterns;
    std::uintptr_t device = 0, list = 0, next = 0, remove = 0, ctor = 0, dtor = 0, release = 0, resize = 0,
                   window = 0;
    if (!unique("device", Device, device) || !unique("list", List, list) || !unique("next", Next, next) ||
        !unique("remove", Remove, remove) || !unique("ctor", Constructor, ctor) ||
        !unique("dtor", Destructor, dtor) || !unique("release", Release, release) ||
        !unique("resize", Resize, resize) || !unique("window", Window, window))
        return fail("unsupported/ambiguous native code");
    if (next <= list || next - list > 128 || release <= dtor || release - dtor > 128)
        return fail("independent ABI witnesses disagree");
    b.deviceGlobal = image.Rip(device);
    if (!image.Contains(b.deviceGlobal, 8, 0x80000000, 0x20000000))
        return fail("device global is not writable module data");
    auto devices = image.Vtables(".?AVCRenderDeviceDx11@@"), wrappers = image.Vtables(".?AVCSwapChainDx11@@");
    if (devices.size() != 1 || wrappers.size() != 1)
        return fail("primary native RTTI must be unique");
    b.deviceVtable = devices[0];
    b.wrapperVtable = wrappers[0];
    std::uintptr_t destructor = 0;
    if (!image.Read(b.wrapperVtable, destructor) || destructor != dtor ||
        image.Rip(dtor + 15) != b.wrapperVtable || image.Rip(ctor) != b.wrapperVtable)
        return fail("wrapper constructor/destructor/RTTI ownership");
    if (!image.Text(image.Rip(resize + 21), "m_pSwapChain->ResizeTarget( &modeDescClosestMatch )") ||
        !image.Text(image.Rip(resize + 78),
                    "m_pSwapChain->ResizeBuffers( 0, 0, 0, DXGI_FORMAT_UNKNOWN, m_nActualCreateFlags )"))
        return fail("DXGI resize witnesses");

    b.registry = 0x6d0;
    b.window = 0x10;
    b.dxgi = 0x170;
    result = b;
    diagnostic = log.str() + "RIP + primary RTTI + ctor/release/ResizeBuffers verified; no dummy device";
    return true;
}
}