#pragma once

#if defined(_WIN32) || defined(MENU_STUDIO_HITMARKER_TEST)
#include <windows.h>
#include <atomic>
#include <chrono>
#include <mutex>
#include "hitsound_event_types.h"
#include "hitsound_logic.h"
#include "hitsound_event_patterns.h"
#include "game_hud_win32.h"
#include "win32_local_read.h"
#if defined(MENU_STUDIO_HITMARKER_TEST)
#define MENU_HITMARKER_TRY try
#define MENU_HITMARKER_EXCEPT catch (...)
#elif defined(_MSC_VER)
#define MENU_HITMARKER_TRY __try
#define MENU_HITMARKER_EXCEPT __except (EXCEPTION_EXECUTE_HANDLER)
#else
#error Hit Marker events require MSVC SEH or the explicit synthetic test shim.
#endif
namespace menu {

inline double HitmarkerClock() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
class HitSoundEvents {
#if defined(MENU_STUDIO_HITMARKER_TEST)
public:
#endif
    struct Listener {
        HitSoundEvents* owner = nullptr;
        virtual ~Listener() = default;
        virtual void FireGameEvent(void* event) noexcept {
            if (owner)
                owner->Event(event);
        }
        virtual int GetEventDebugID() {
            return 42;
        }
    };
    struct Request {
        HitSoundContext context{};
        HitSoundConfig sound{};
        ULONGLONG at = 0;
    };
    struct Active {
        HitSoundEvents& self;
        explicit Active(HitSoundEvents& s) : self(s) {
            ++s.active_;
        }
        ~Active() {
            --self.active_;
        }
    };
    static constexpr std::size_t QueueCapacity = 64;
    inline static HitSoundEvents* instance_ = nullptr;
    mutable std::recursive_mutex mutex_;
    std::mutex requestMutex_, queueMutex_;
    Request request_{};
    std::array<HitSoundEvent, QueueCapacity> sounds_{};
    std::size_t soundHead_ = 0, soundCount_ = 0;
    std::atomic<bool> closing_{false}, ack_{false}, fault_{false}, wanted_{false};
    std::atomic<unsigned> active_{0};
    Listener listener_;
    HitmarkerEventBindings b_{};
    HMODULE client_ = nullptr;
    std::uintptr_t eventManager_ = 0;
    bool bound_ = false, registered_ = false, hurtRegistered_ = false, registrationAttempted_ = false;
    ULONGLONG nextBind_ = 0, nextVerify_ = 0;
    std::string detail_ = "waiting for Hit Sound to be enabled";
    static bool Bytes(std::uintptr_t a, void* out, std::size_t n) {
        return LocalReadBytes(a, out, n);
    }
    template <class T> static bool Read(std::uintptr_t a, T& out) {
        return Bytes(a, &out, sizeof(out));
    }
    static bool Typed(std::uintptr_t object, std::uintptr_t table) {
        std::uintptr_t v = 0;
        return object && Read(object, v) && v == table;
    }
    static bool Code(std::uintptr_t at) {
        MEMORY_BASIC_INFORMATION m{};
        return at && VirtualQuery(reinterpret_cast<LPCVOID>(at), &m, sizeof m) && m.State == MEM_COMMIT &&
               !(m.Protect & (PAGE_GUARD | PAGE_NOACCESS)) && (m.Protect & (0x10 | 0x20 | 0x40 | 0x80));
    }
    static bool Add(std::uintptr_t fn, std::uintptr_t system, Listener* listener, const char* name) {
        MENU_HITMARKER_TRY {
            reinterpret_cast<int(__fastcall*)(void*, void*, const char*, bool)>(fn)(
                reinterpret_cast<void*>(system), listener, name, false);
            return true;
        }
        MENU_HITMARKER_EXCEPT {
            return false;
        }
    }
    static bool Has(std::uintptr_t fn, std::uintptr_t system, Listener* listener, const char* name,
                    bool& yes) {
        MENU_HITMARKER_TRY {
            yes = reinterpret_cast<bool(__fastcall*)(void*, void*, const char*)>(fn)(
                reinterpret_cast<void*>(system), listener, name);
            return true;
        }
        MENU_HITMARKER_EXCEPT {
            yes = false;
            return false;
        }
    }
    static bool Remove(std::uintptr_t fn, std::uintptr_t system, Listener* listener) {
        MENU_HITMARKER_TRY {
            reinterpret_cast<void(__fastcall*)(void*, void*)>(fn)(reinterpret_cast<void*>(system), listener);
            return true;
        }
        MENU_HITMARKER_EXCEPT {
            return false;
        }
    }
    static bool EventName(std::uintptr_t fn, void* event, const char*& out) {
        MENU_HITMARKER_TRY {
            out = reinterpret_cast<const char*(__fastcall*)(void*)>(fn)(event);
            return true;
        }
        MENU_HITMARKER_EXCEPT {
            out = nullptr;
            return false;
        }
    }
    static bool EventInt(std::uintptr_t fn, void* event, const SoundEventKey* key, int fallback, int& out) {
        MENU_HITMARKER_TRY {
            out = reinterpret_cast<int(__fastcall*)(void*, const SoundEventKey*, int)>(fn)(event, key,
                                                                                           fallback);
            return true;
        }
        MENU_HITMARKER_EXCEPT {
            out = fallback;
            return false;
        }
    }
    static bool EventController(std::uintptr_t fn, void* event, const SoundEventKey* key,
                                std::uintptr_t& out) {
        MENU_HITMARKER_TRY {
            out = reinterpret_cast<std::uintptr_t(__fastcall*)(void*, const SoundEventKey*)>(fn)(event, key);
            return true;
        }
        MENU_HITMARKER_EXCEPT {
            out = 0;
            return false;
        }
    }
    static bool InGame(std::uintptr_t object, bool& yes) {
        std::uintptr_t vt = 0, fn = 0;
        if (!Read(object, vt) || !Read(vt + 39 * 8, fn) || !Code(fn)) {
            yes = false;
            return false;
        }
        MENU_HITMARKER_TRY {
            yes = reinterpret_cast<bool(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(object));
            return true;
        }
        MENU_HITMARKER_EXCEPT {
            yes = false;
            return false;
        }
    }
    void Fault(const char* reason) {
        fault_ = true;
        detail_ = reason;
    }
    void PushSound(const HitSoundEvent& e) {
        if (e.sound < 0 || e.volume <= 0)
            return;
        std::lock_guard<std::mutex> lock(queueMutex_);
        if (soundCount_ == QueueCapacity) {
            soundHead_ = (soundHead_ + 1) % QueueCapacity;
            --soundCount_;
        }
        sounds_[(soundHead_ + soundCount_) % QueueCapacity] = e;
        ++soundCount_;
    }
    void ClearQueue() {
        std::lock_guard<std::mutex> lock(queueMutex_);
        soundHead_ = soundCount_ = 0;
    }
    bool RemoveRegistration() {
        if (!registrationAttempted_)
            return true;
        std::uintptr_t current = 0;
        if (!Read(b_.eventGlobal, current) || current != eventManager_ ||
            !Typed(current, b_.eventManagerTable)) {
            Fault("event-manager ownership changed; DLL retained");
            return false;
        }

        if (!Remove(b_.removeListener, eventManager_, &listener_)) {
            Fault("listener removal fault; DLL retained");
            return false;
        }
        for (const char* name : {"player_hurt"}) {
            bool still = false;
            if (!Has(b_.findListener, eventManager_, &listener_, name, still) || still) {
                Fault("listener removal not acknowledged; DLL retained");
                return false;
            }
        }
        registered_ = hurtRegistered_ = registrationAttempted_ = false;
        eventManager_ = 0;
        return true;
    }
    bool Register() {
        if (registered_)
            return true;
        std::uintptr_t current = 0;
        if (!Read(b_.eventGlobal, current) || !Typed(current, b_.eventManagerTable)) {
            detail_ = "waiting for native event manager";
            return false;
        }
        listener_.owner = this;
        eventManager_ = current;
        registrationAttempted_ = true;
        if (!Add(b_.addListener, current, &listener_, "player_hurt")) {
            Fault("listener registration fault; DLL retained");
            return false;
        }
        bool hurt = false;
        if (!Has(b_.findListener, current, &listener_, "player_hurt", hurt)) {
            Fault("listener verification fault; DLL retained");
            return false;
        }
        hurtRegistered_ = hurt;
        registered_ = hurt;
        if (!registered_) {
            registrationAttempted_ = false;
            eventManager_ = 0;
            detail_ = "player_hurt listener rejected";
            return false;
        }
        detail_ = "listening for player_hurt";
        return true;
    }

    void Verify() {
        if (!registered_)
            return;
        const auto now = GetTickCount64();
        if (now < nextVerify_)
            return;
        nextVerify_ = now + 1000;
        std::uintptr_t current = 0;
        if (!Read(b_.eventGlobal, current) || current != eventManager_ ||
            !Typed(current, b_.eventManagerTable)) {
            Fault("event-manager ownership changed; DLL retained");
            return;
        }
        bool hurt = false;
        if (hurtRegistered_ && !Has(b_.findListener, current, &listener_, "player_hurt", hurt)) {
            Fault("listener verification fault; DLL retained");
            return;
        }
        if (hurtRegistered_ && !hurt) {
            hurtRegistered_ = false;
        }
        if (!hurtRegistered_) {
            registered_ = false;
            registrationAttempted_ = false;
            eventManager_ = 0;
            detail_ = "listener lost; re-registering";
        }
    }
    void Tick() {
        std::lock_guard<std::recursive_mutex> lock(mutex_);
        if (closing_) {
            if (RemoveRegistration() && !fault_)
                ack_ = true;
            return;
        }
        if (!bound_ || fault_)
            return;
        if (registered_) {
            Verify();
            return;
        }
        if (wanted_)
            Register();
    }
    void Event(void* event) noexcept {
        Active active(*this);
        try {
            if (closing_ || fault_ || !wanted_)
                return;
            Request request;
            {
                std::lock_guard<std::mutex> lock(requestMutex_);
                request = request_;
            }
            const auto now = GetTickCount64();
            if (!request.sound.Wanted() || !request.context.valid || now < request.at ||
                now - request.at > 1000) {
                return;
            }
            std::unique_lock<std::recursive_mutex> lock(mutex_, std::try_to_lock);
            if (!lock.owns_lock() || closing_ || fault_ || !registered_ ||
                !Typed(reinterpret_cast<std::uintptr_t>(event), b_.eventTable))
                return;
            const char* name = nullptr;
            if (!EventName(b_.getName, event, name)) {
                Fault("event name failed");
                return;
            }
            const auto read = [](std::uintptr_t a, auto& out) { return Read(a, out); };
            if (!WatermarkKdStringEquals(read, reinterpret_cast<std::uintptr_t>(name), "player_hurt"))
                return;
            bool inGame = false;
            if (!InGame(request.context.engineObject, inGame) || !inGame)
                return;
            const auto damageKey = SoundKey("dmg_health"), attackerKey = SoundKey("attacker"),
                       userKey = SoundKey("userid");
            int damage = 0;
            if (!EventInt(b_.getInt, event, &damageKey, 0, damage)) {
                Fault("event integer failed");
                return;
            }
            if (damage <= 0)
                return;
            std::uintptr_t attacker = 0, victim = 0;
            if (!EventController(b_.getController, event, &attackerKey, attacker) ||
                !EventController(b_.getController, event, &userKey, victim)) {
                Fault("event controller failed");
                return;
            }
            if (!attacker || !victim || attacker == victim)
                return;
            const auto local = WatermarkKdLocalController(
                read, request.context.entities, request.context.localGlobal, request.context.localFlag);
            std::uintptr_t root = 0, page = 0;
            if (!local.ok || !read(request.context.entities, root) || !root || !read(root + 0x10, page) ||
                !page || !SoundControllerPresent(read, page, attacker) ||
                !SoundControllerPresent(read, page, victim))
                return;
            const bool outgoing = attacker == local.value, incoming = victim == local.value;
            if (outgoing || incoming) {
                int health = -1, hitgroup = 0;
                const auto healthKey = SoundKey("health"), groupKey = SoundKey("hitgroup");
                if (!EventInt(b_.getInt, event, &healthKey, -1, health) ||
                    !EventInt(b_.getInt, event, &groupKey, 0, hitgroup)) {
                    Fault("sound event failed");
                    return;
                }
                PushSound(
                    HitSoundSelect(request.sound, HitSoundHurtType(outgoing, incoming, health, hitgroup)));
            }
        } catch (...) {
            fault_ = true;
        }
    }
    static void Frame(void*, const HudResolvedBindings&) {
        auto self = instance_;
        if (!self)
            return;
        Active active(*self);
        try {
            self->Tick();
        } catch (...) {
            self->fault_ = true;
        }
    }

public:
    void Attach(WatermarkNativeHud& hud) {
        listener_.owner = this;
        instance_ = this;
        hud.SetMarkerFrameObserver(Frame);
    }
    void Submit(const HitSoundContext& context, const HitSoundConfig& sound) {
        std::lock_guard<std::mutex> lock(requestMutex_);
        request_ = {context, sound, GetTickCount64()};
        wanted_ = sound.Wanted() && context.valid;
    }
    void Clear() {
        Submit({}, {});
    }
    void DrainSounds(std::vector<HitSoundEvent>& out) {
        std::lock_guard<std::mutex> lock(queueMutex_);
        for (std::size_t i = 0; i < soundCount_; ++i)
            out.push_back(sounds_[(soundHead_ + i) % QueueCapacity]);
        soundHead_ = soundCount_ = 0;
    }
    void TryStart() {
        std::lock_guard<std::recursive_mutex> lock(mutex_);
        if (closing_ || fault_ || bound_ || !wanted_ || GetTickCount64() < nextBind_)
            return;
        nextBind_ = GetTickCount64() + 5000;
        const HMODULE module = GetModuleHandleW(L"client.dll");
        if (!module) {
            detail_ = "waiting for client.dll";
            return;
        }
        HudScanImage image;
        WatermarkKdModule parsed;
        if (!WatermarkKdLoadModule([](std::uintptr_t a, auto& v) { return Read(a, v); },
                                   reinterpret_cast<std::uintptr_t>(module), parsed) ||
            !image.Load(parsed, Bytes)) {
            detail_ = "client.dll image is unreadable";
            return;
        }
        HitmarkerEventBindings bindings;
        if (!ResolveHitmarkerEvents(image, bindings, detail_))
            return;
        HMODULE held = nullptr;
        if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS, reinterpret_cast<LPCWSTR>(module),
                                &held)) {
            detail_ = "client.dll retention failed";
            return;
        }
        client_ = held;
        b_ = bindings;
        bound_ = true;
        detail_ = "bound; awaiting game-frame listener setup";
    }

    bool Stop(DWORD timeout = 2000) {
        closing_ = true;
        wanted_ = false;
        {
            std::lock_guard<std::recursive_mutex> lock(mutex_);
            if (!registrationAttempted_ && !fault_)
                ack_ = true;
        }
        const auto end = GetTickCount64() + timeout;
        while ((!ack_ || active_) && GetTickCount64() < end)
            Sleep(1);
        if (!ack_ || active_ || fault_)
            return false;
        std::lock_guard<std::recursive_mutex> lock(mutex_);
        if (client_) {
            FreeLibrary(client_);
            client_ = nullptr;
        }
        bound_ = false;
        ClearQueue();
        detail_ = "stopped; listener removed";
        return true;
    }
};
}
#undef MENU_HITMARKER_TRY
#undef MENU_HITMARKER_EXCEPT
#endif
