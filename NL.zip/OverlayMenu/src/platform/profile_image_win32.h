#pragma once
#include <wincodec.h>
#include <wrl/client.h>
#include "menu_core.h"
namespace menu {

inline std::shared_ptr<ProfileImage> LoadProfileImage(const std::filesystem::path& path) {
    using Microsoft::WRL::ComPtr;
    const HRESULT com = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    struct Cleanup {
        bool active;
        ~Cleanup() {
            if (active)
                CoUninitialize();
        }
    } cleanup{SUCCEEDED(com)};
    auto check = [](HRESULT hr) {
        if (FAILED(hr))
            throw std::runtime_error("Image file cannot be decoded (WIC)");
    };
    ComPtr<IWICImagingFactory> factory;
    check(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory)));
    ComPtr<IWICBitmapDecoder> decoder;
    check(factory->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ,
                                             WICDecodeMetadataCacheOnLoad, &decoder));
    ComPtr<IWICBitmapFrameDecode> frame;
    check(decoder->GetFrame(0, &frame));
    UINT w = 0, h = 0;
    check(frame->GetSize(&w, &h));
    if (!w || !h || w > 4096 || h > 4096)
        throw std::runtime_error("Image dimensions must be 1..4096 pixels");
    ComPtr<IWICFormatConverter> converter;
    check(factory->CreateFormatConverter(&converter));
    check(converter->Initialize(frame.Get(), GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr,
                                0, WICBitmapPaletteTypeCustom));
    auto image = std::make_shared<ProfileImage>();
    image->width = int(w);
    image->height = int(h);
    image->rgba.resize(std::size_t(w) * h * 4);
    check(converter->CopyPixels(nullptr, w * 4, UINT(image->rgba.size()), image->rgba.data()));
    return image;
}
inline std::shared_ptr<ProfileImage> LoadProfileAvatar(const std::filesystem::path& path) {
    if (path.empty())
        return {};

    return LoadProfileImage(path);
}

}
