#pragma once
#include "rendersystem_swapchain_patterns.h"
#include <array>
namespace menu {
inline constexpr unsigned RenderSystemSwapchainLimit = 64, RenderSystemSwapchainIndexLimit = 4096;
inline bool SwapchainUserRange(std::uintptr_t at, std::size_t size) {
    constexpr std::uintptr_t last = 0x00007fffffffffffULL;
    return size && at >= 0x10000 && at <= last && size - 1 <= last - at;
}
template <class Reader, class T> bool SwapchainRead(Reader& read, std::uintptr_t at, T& value) {
    return SwapchainUserRange(at, sizeof(T)) && read(at, value);
}
struct RenderSystemChainList {
    std::int32_t indexLimit = 0;
    std::uint32_t flags = 0;
    std::uintptr_t entries = 0;
    std::int32_t head = -1, tail = -1, free = -1, count = 0;
};
struct RenderSystemChainNode {
    std::uintptr_t wrapper = 0;
    std::int32_t previous = -1, next = -1;
};
static_assert(sizeof(RenderSystemChainList) == 32 && sizeof(RenderSystemChainNode) == 16,
              "native x64 list ABI");
inline bool SameSwapchainList(const RenderSystemChainList& a, const RenderSystemChainList& b) {
    return a.indexLimit == b.indexLimit && a.flags == b.flags && a.entries == b.entries && a.head == b.head &&
           a.tail == b.tail && a.free == b.free && a.count == b.count;
}
inline bool SameSwapchainNode(const RenderSystemChainNode& a, const RenderSystemChainNode& b) {
    return a.wrapper == b.wrapper && a.previous == b.previous && a.next == b.next;
}
struct RenderSystemChain {
    std::uintptr_t device = 0, node = 0, wrapper = 0, window = 0, chain = 0, table = 0, present = 0,
                   resize = 0;
    RenderSystemChainList list;
    RenderSystemChainNode entry;
};
struct RenderSystemChains {
    std::array<RenderSystemChain, RenderSystemSwapchainLimit> items{};
    unsigned count = 0;
};

template <class Reader>
bool RenderSystemChainCurrent(Reader&& read, const RenderSystemSwapchainBindings& b,
                              const RenderSystemChain& c, std::uintptr_t callbackChain) {
    if (!callbackChain || c.chain != callbackChain || c.entry.wrapper != c.wrapper ||
        !SwapchainUserRange(c.node, sizeof(c.entry)) ||
        !SwapchainUserRange(c.device, b.registry + sizeof(c.list)) ||
        !SwapchainUserRange(c.wrapper, b.dxgi + 8) || !SwapchainUserRange(c.table, 14 * 8))
        return false;
    std::uintptr_t device = 0, vt = 0, window = 0, chain = 0, table = 0, present = 0, resize = 0;
    RenderSystemChainList list;
    RenderSystemChainNode node;
    if (!SwapchainRead(read, b.deviceGlobal, device) || device != c.device ||
        !SwapchainRead(read, device, vt) || vt != b.deviceVtable ||
        !SwapchainRead(read, device + b.registry, list) || !SameSwapchainList(list, c.list) ||
        !SwapchainRead(read, c.node, node) || !SameSwapchainNode(node, c.entry) ||
        !SwapchainRead(read, c.wrapper, vt) || vt != b.wrapperVtable ||
        !SwapchainRead(read, c.wrapper + b.window, window) || window != c.window ||
        !SwapchainRead(read, c.wrapper + b.dxgi, chain) || chain != callbackChain ||
        !SwapchainRead(read, chain, table) || table != c.table ||
        !SwapchainRead(read, table + 8 * 8, present) || present != c.present ||
        !SwapchainRead(read, table + 13 * 8, resize) || resize != c.resize)
        return false;

    return SwapchainRead(read, c.wrapper, vt) && vt == b.wrapperVtable &&
           SwapchainRead(read, c.wrapper + b.dxgi, chain) && chain == callbackChain &&
           SwapchainRead(read, c.node, node) && SameSwapchainNode(node, c.entry) &&
           SwapchainRead(read, device + b.registry, list) && SameSwapchainList(list, c.list) &&
           SwapchainRead(read, b.deviceGlobal, device) && device == c.device;
}
template <class Reader>
bool SampleRenderSystemChains(Reader&& read, const RenderSystemSwapchainBindings& b,
                              RenderSystemChains& result, const char*& reason) {
    result = {};
    RenderSystemChains sample;
    RenderSystemChainList list;
    std::uintptr_t device = 0, vt = 0;
    auto fail = [&](const char* why) {
        reason = why;
        return false;
    };
    if (!b.deviceGlobal || b.registry != 0x6d0 || b.window != 0x10 || b.dxgi != 0x170)
        return fail("unresolved/unsupported bindings");
    if (!SwapchainRead(read, b.deviceGlobal, device) ||
        !SwapchainUserRange(device, b.registry + sizeof(list)) || !SwapchainRead(read, device, vt) ||
        vt != b.deviceVtable || !SwapchainRead(read, device + b.registry, list))
        return fail("render device not ready");
    if (list.indexLimit < 0 || list.indexLimit > int(RenderSystemSwapchainIndexLimit) || list.count < 0 ||
        list.count > int(RenderSystemSwapchainLimit) || list.count > list.indexLimit)
        return fail("registry bounds");
    if (!list.count) {
        if (list.head != -1 || list.tail != -1)
            return fail("inconsistent empty registry");
        RenderSystemChainList after;
        std::uintptr_t root = 0;
        if (!SwapchainRead(read, device + b.registry, after) || !SameSwapchainList(list, after) ||
            !SwapchainRead(read, b.deviceGlobal, root) || root != device)
            return fail("registry changed");
        reason = "waiting for engine swapchain";
        return true;
    }
    if (!(list.flags & 0x7fffffff) || !SwapchainUserRange(list.entries, std::size_t(list.indexLimit) * 16))
        return fail("registry storage");
    std::array<std::int32_t, RenderSystemSwapchainLimit> visited{};
    unsigned nodes = 0;
    std::int32_t index = list.head, previous = -1;
    while (index != -1) {
        if (index < 0 || index >= list.indexLimit || nodes >= unsigned(list.count))
            return fail("registry cycle/index");
        for (unsigned i = 0; i < nodes; ++i)
            if (visited[i] == index)
                return fail("registry cycle");
        visited[nodes++] = index;
        RenderSystemChain c;
        c.device = device;
        c.node = list.entries + std::uintptr_t(index) * 16;
        c.list = list;
        if (!SwapchainRead(read, c.node, c.entry) || c.entry.previous != previous ||
            !SwapchainUserRange(c.entry.wrapper, b.dxgi + 8))
            return fail("registry node");
        c.wrapper = c.entry.wrapper;
        if (!SwapchainRead(read, c.wrapper, vt) || vt != b.wrapperVtable ||
            !SwapchainRead(read, c.wrapper + b.window, c.window) ||
            !SwapchainRead(read, c.wrapper + b.dxgi, c.chain))
            return fail("wrapper not ready/type changed");
        if (c.chain && c.window) {
            if (!SwapchainRead(read, c.chain, c.table) || !SwapchainUserRange(c.table, 14 * 8) ||
                !SwapchainRead(read, c.table + 8 * 8, c.present) ||
                !SwapchainRead(read, c.table + 13 * 8, c.resize) || !SwapchainUserRange(c.present, 1) ||
                !SwapchainUserRange(c.resize, 1) || c.present == c.resize)
                return fail("DXGI table not ready");
            sample.items[sample.count++] = c;
        }
        previous = index;
        index = c.entry.next;
    }
    if (nodes != unsigned(list.count) || previous != list.tail)
        return fail("registry length/tail");
    for (unsigned i = 0; i < sample.count; ++i)
        if (!RenderSystemChainCurrent(read, b, sample.items[i], sample.items[i].chain))
            return fail("swapchain changed during sample");
    RenderSystemChainList after;
    std::uintptr_t root = 0;
    if (!SwapchainRead(read, device + b.registry, after) || !SameSwapchainList(list, after) ||
        !SwapchainRead(read, b.deviceGlobal, root) || root != device)
        return fail("registry changed");
    result = sample;
    reason = sample.count ? "engine registry sampled" : "waiting for initialized engine swapchain";
    return true;
}

template <class Eligible>
bool SelectRenderSystemChain(const RenderSystemChains& sample, Eligible&& eligible, RenderSystemChain& result,
                             const char*& reason) {
    result = {};
    unsigned count = 0;
    RenderSystemChain selected;
    for (unsigned i = 0; i < sample.count; ++i)
        if (eligible(sample.items[i].window)) {
            selected = sample.items[i];
            ++count;
        }
    if (count != 1) {
        reason = count ? "ambiguous top-level engine swapchains" : "waiting for top-level engine swapchain";
        return false;
    }
    result = selected;
    reason = "unique top-level engine swapchain";
    return true;
}
}