#pragma once
#include "ambience_native_patterns.h"
namespace menu {

struct AmbienceSourceSnapshot {
    std::uintptr_t srv = 0;
    int width = 0, height = 0;
};
template <class Read>
bool ReadAmbienceImageSource(const AmbienceNativeBindings& b, std::uintptr_t panel, Read&& read,
                             AmbienceSourceSnapshot& out) {
    out = {};
    std::uintptr_t vt = 0, client = 0, proxy = 0, data = 0, texture = 0, handle = 0, resource = 0, srv = 0;
    unsigned state = 0;
    unsigned char ready = 0;
    int w = 0, h = 0;
    if (!panel || !read(panel, vt) || vt != b.bridge.panelVtable ||
        !read(panel + b.bridge.clientOffset, client) || !client || !read(client, vt) ||
        vt != b.imagePanelVtable || !read(client + b.ImageProxy, proxy) || !proxy || !read(proxy, vt) ||
        vt != b.proxyVtable || !read(proxy + b.ProxyData, data) || !data || !read(data, vt) ||
        vt != b.dataVtable || !read(data + 0x10, state) || state != 7 ||
        !read(data + b.DataTexture, texture) || !texture || !read(texture, vt) || vt != b.textureVtable ||
        !read(texture + 0x10, ready) || ready == 0 || !read(texture + 0x30, w) || !read(texture + 0x34, h) ||
        w < 64 || h < 32 || w > 4096 || h > 4096 || !read(texture + b.TextureHandle, handle) || !handle ||
        !read(handle, resource) || !resource || !read(resource, vt) || vt != b.dxTextureVtable ||
        !read(resource + b.TextureSRV, srv) || !srv)
        return false;
    out = {srv, w, h};
    return true;
}
}
