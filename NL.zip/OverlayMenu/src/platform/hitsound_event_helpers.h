#pragma once
#include "watermark_hud_patterns.h"
namespace menu {
namespace kill_patterns {
inline constexpr char EventOwner[] = "48 89 5C 24 18 55 48 83 EC 20 48 8D 05 ? ? ? ? 48 89 7C 24 38 48 89 01 "
                                     "48 8B D9 E8 ? ? ? ? 33 ED 48 39 1D ? ? ? ? 75 07 48 89 2D";
inline bool At(const HudScanImage& i, std::uintptr_t at, const char* pattern) {
    const auto p = HudPattern(pattern);
    if (!i.Contains(at, p.size(), 0x20000000))
        return false;
    for (std::size_t j = 0; j < p.size(); ++j) {
        unsigned char x = 0;
        if (!i.Read(at + j, x) || (p[j] >= 0 && x != p[j]))
            return false;
    }
    return true;
}
inline bool Has(const HudScanImage& i, std::uintptr_t start, std::size_t n, const char* pattern) {
    const auto p = HudPattern(pattern);
    if (!i.Contains(start, n, 0x20000000))
        return false;
    for (std::size_t at = 0; at + p.size() <= n; ++at)
        if (At(i, start + at, pattern))
            return true;
    return false;
}
inline std::uintptr_t Unique(const HudScanImage& i, const char* p) {
    const auto found = i.Find(p, true, 2);
    return found.size() == 1 ? found[0] : 0;
}
inline std::uintptr_t Table(const HudScanImage& i, const char* name) {
    const auto v = i.Vtables(name);
    return v.size() == 1 ? v[0] : 0;
}
inline std::uintptr_t Slot(const HudScanImage& i, std::uintptr_t table, unsigned slot) {
    std::uintptr_t fn = 0;
    return table && i.Read(table + slot * 8, fn) && i.Contains(fn, 1, 0x20000000) ? fn : 0;
}
}
}
