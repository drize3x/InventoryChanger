#pragma once

#include <windows.h>
#include <cstdint>
#include <cstring>
#include "win32_local_read.h"
#include "menu_cursor_lease.h"
namespace menu {
class MenuCursorWin32 {
    using Factory = void*(__cdecl*)(const char*, int*);
    using SetRelative = void(__fastcall*)(void*, bool);
    using GetRelative = bool(__fastcall*)(void*);
    void* system_ = nullptr;
    SetRelative set_ = nullptr;
    GetRelative get_ = nullptr;
    MenuCursorLease lease_;
    static bool Inside(std::uintptr_t address, std::uintptr_t base, std::size_t size) {
        return address >= base && address - base < size;
    }
    static bool Code(std::uintptr_t address, const unsigned char* expected, std::size_t len) {
        unsigned char bytes[32]{};
        return len <= sizeof(bytes) && LocalReadBytes(address, bytes, len) &&
               std::memcmp(bytes, expected, len) == 0;
    }
    bool Bind() {
        if (system_)
            return true;
        HMODULE module = GetModuleHandleW(L"inputsystem.dll");
        if (!module)
            return false;
        auto factory = reinterpret_cast<Factory>(GetProcAddress(module, "CreateInterface"));
        if (!factory)
            return false;
        void* object = factory("InputSystemVersion001", nullptr);
        if (!object)
            return false;
        std::uintptr_t table = 0, setter = 0, getter = 0;
        auto base = reinterpret_cast<std::uintptr_t>(module);
        if (!LocalReadBytes(reinterpret_cast<std::uintptr_t>(object), &table, sizeof(table)) ||
            !LocalReadBytes(table + 0x260, &setter, sizeof(setter)) ||
            !LocalReadBytes(table + 0x268, &getter, sizeof(getter)))
            return false;
        IMAGE_DOS_HEADER dos{};
        IMAGE_NT_HEADERS64 pe{};
        if (!LocalReadBytes(base, &dos, sizeof(dos)) || dos.e_magic != IMAGE_DOS_SIGNATURE ||
            dos.e_lfanew <= 0 || dos.e_lfanew > 0x100000 ||
            !LocalReadBytes(base + dos.e_lfanew, &pe, sizeof(pe)) || pe.Signature != IMAGE_NT_SIGNATURE ||
            pe.OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC)
            return false;
        if (!Inside(setter, base, pe.OptionalHeader.SizeOfImage) ||
            !Inside(getter, base, pe.OptionalHeader.SizeOfImage))
            return false;
        static constexpr unsigned char setAnchor[] = {0x48, 0x89, 0x6c, 0x24, 0x10, 0x48, 0x89, 0x74, 0x24,
                                                      0x18, 0x48, 0x89, 0x7c, 0x24, 0x20, 0x41, 0x56, 0x48,
                                                      0x83, 0xec, 0x20, 0x0f, 0xb6, 0xf2, 0x88, 0x51, 0x54};
        static constexpr unsigned char getAnchor[] = {0x0f, 0xb6, 0x41, 0x54, 0xc3};
        if (!Code(setter, setAnchor, sizeof(setAnchor)) || !Code(getter, getAnchor, sizeof(getAnchor)))
            return false;
        system_ = object;
        set_ = reinterpret_cast<SetRelative>(setter);
        get_ = reinterpret_cast<GetRelative>(getter);
        return true;
    }

public:
    bool Apply(bool enabled) {
        return ApplyMode(enabled, true);
    }

    bool ApplyMode(bool enabled, bool showCursor) {
        return lease_.Apply(
            enabled, [this]() { return Bind(); }, [this]() { return get_(system_); },
            [this](bool value) { set_(system_, value); },
            [](bool value) { return ShowCursor(value ? TRUE : FALSE); }, showCursor);
    }
    void Release() {
        Apply(false);
    }
    bool Active() const {
        return lease_.Active();
    }
};
}
