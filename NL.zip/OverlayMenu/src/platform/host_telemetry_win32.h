#pragma once

#ifdef _WIN32
#include <windows.h>
#include <pdh.h>
#include <pdhmsg.h>
#include <powrprof.h>
#include <dxgi1_2.h>
#include <atomic>
#include <cstddef>
#include <chrono>
#include <condition_variable>
#include <mutex>
#include <thread>
#include "watermark_telemetry.h"
namespace menu {
class WatermarkHostTelemetry {
    struct Counters {

        struct ProcessorPowerRecord {
            ULONG Number, MaxMhz, CurrentMhz, MhzLimit, MaxIdleState, CurrentIdleState;
        };
        static_assert(sizeof(ULONG) == 4, "Windows ULONG must be 32-bit");
        static_assert(sizeof(ProcessorPowerRecord) == 24, "ProcessorInformation record must be 24 bytes");
        static_assert(offsetof(ProcessorPowerRecord, CurrentMhz) == 8, "CurrentMhz ABI offset must be 8");
        PDH_HQUERY query = nullptr;
        PDH_HCOUNTER cpu = nullptr, gpu = nullptr, frequency = nullptr, performance = nullptr;
        unsigned long baseMhz = 0;
        bool baseline = false, adaptersKnown = false;
        std::vector<std::uint64_t> adapters;
        Counters() {

            IDXGIFactory1* factory = nullptr;
            if (SUCCEEDED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), reinterpret_cast<void**>(&factory)))) {
                adaptersKnown = true;
                for (UINT i = 0; i < 256; ++i) {
                    IDXGIAdapter1* adapter = nullptr;
                    HRESULT hr = factory->EnumAdapters1(i, &adapter);
                    if (hr == DXGI_ERROR_NOT_FOUND)
                        break;
                    if (FAILED(hr) || !adapter) {
                        adaptersKnown = false;
                        break;
                    }
                    DXGI_ADAPTER_DESC1 desc{};
                    if (SUCCEEDED(adapter->GetDesc1(&desc)) && !(desc.Flags & DXGI_ADAPTER_FLAG_SOFTWARE) &&
                        desc.VendorId != 0x1414)
                        adapters.push_back(
                            (std::uint64_t(static_cast<std::uint32_t>(desc.AdapterLuid.HighPart)) << 32) |
                            desc.AdapterLuid.LowPart);
                    adapter->Release();
                }
                factory->Release();
            }

            SYSTEM_INFO system{};
            GetSystemInfo(&system);
            DWORD count = system.dwNumberOfProcessors;
            if (count && count <= 4096) {
                std::vector<ProcessorPowerRecord> power(count);
                if (CallNtPowerInformation(ProcessorInformation, nullptr, 0, power.data(),
                                           ULONG(power.size() * sizeof(power[0]))) == 0) {
                    unsigned long long sum = 0;
                    for (const auto& core : power)
                        sum += core.CurrentMhz;
                    baseMhz = static_cast<unsigned long>(sum / count);
                }
            }
            if (PdhOpenQueryW(nullptr, 0, &query) != ERROR_SUCCESS) {
                query = nullptr;
                return;
            }

            if (PdhAddEnglishCounterW(query, L"\\Processor Information(*)\\% Processor Utility", 0, &cpu) !=
                ERROR_SUCCESS)
                cpu = nullptr;
            if (PdhAddEnglishCounterW(query, L"\\Processor Information(*)\\Processor Frequency", 0,
                                      &frequency) != ERROR_SUCCESS)
                frequency = nullptr;
            if (PdhAddEnglishCounterW(query, L"\\Processor Information(*)\\% Processor Performance", 0,
                                      &performance) != ERROR_SUCCESS)
                performance = nullptr;
            if (PdhAddEnglishCounterW(query, L"\\GPU Engine(*)\\Utilization Percentage", 0, &gpu) !=
                ERROR_SUCCESS)
                gpu = nullptr;
        }
        ~Counters() {
            if (query)
                PdhCloseQuery(query);
        }
        static std::vector<std::pair<std::wstring, double>> Values(PDH_HCOUNTER counter,
                                                                   bool integer = false) {
            if (!counter)
                return {};
            DWORD bytes = 0, count = 0;
            const DWORD format = integer ? PDH_FMT_LARGE : PDH_FMT_DOUBLE;
            if (PdhGetFormattedCounterArrayW(counter, format, &bytes, &count, nullptr) != PDH_MORE_DATA ||
                !bytes || bytes > 32 * 1024 * 1024)
                return {};
            std::vector<unsigned char> storage(bytes);
            auto values = reinterpret_cast<PDH_FMT_COUNTERVALUE_ITEM_W*>(storage.data());
            if (PdhGetFormattedCounterArrayW(counter, format, &bytes, &count, values) != ERROR_SUCCESS)
                return {};
            std::vector<std::pair<std::wstring, double>> out;
            out.reserve(count);
            for (DWORD i = 0; i < count; ++i)
                if (values[i].szName && (values[i].FmtValue.CStatus == PDH_CSTATUS_VALID_DATA ||
                                         values[i].FmtValue.CStatus == PDH_CSTATUS_NEW_DATA))
                    out.emplace_back(values[i].szName, integer ? double(values[i].FmtValue.largeValue)
                                                               : values[i].FmtValue.doubleValue);
            return out;
        }
        void Sample(WatermarkHostSample& out) {
            if (!query || PdhCollectQueryData(query) != ERROR_SUCCESS) {
                baseline = false;
                return;
            }
            if (!baseline) {
                baseline = true;
                return;
            }
            std::map<WatermarkProcessorKey, float> ordered;
            for (const auto& entry : Values(cpu)) {
                auto key = WatermarkProcessorInstance(entry.first);
                if (key && std::isfinite(entry.second) && entry.second >= 0)
                    ordered[*key] = float(std::clamp(entry.second, 0., 100.) / 100.);
            }
            std::vector<float> cores;
            cores.reserve(ordered.size());
            for (const auto& item : ordered)
                cores.push_back(item.second);
            WatermarkCpuSample(out, cores);
            WatermarkNativeFrequency(out, Values(frequency, true), Values(performance), baseMhz);
            out.gpuLoad =
                adaptersKnown ? WatermarkGpuEngineLoad(Values(gpu), &adapters) : std::optional<float>{};
        }
    };
    std::thread worker;
    std::mutex sampleMutex, waitMutex;
    std::condition_variable wake;
    std::atomic<bool> stopping{false};
    WatermarkHostSample latest;
    bool published = false, copied = false;
    std::chrono::steady_clock::time_point lastCopy{};
    static void Memory(WatermarkHostSample& sample) {
        MEMORYSTATUSEX memory{};
        memory.dwLength = sizeof(memory);
        if (GlobalMemoryStatusEx(&memory) && memory.ullTotalPhys &&
            memory.ullAvailPhys <= memory.ullTotalPhys) {

            sample.memoryTotalGB = float(double(memory.ullTotalPhys >> 20) / 1024.);
            sample.memoryUsedGB =
                float(double((memory.ullTotalPhys >> 20) - (memory.ullAvailPhys >> 20)) / 1024.);
        }
    }
    void Run() noexcept {
        try {
            Counters counters;
            while (!stopping.load()) {
                WatermarkHostSample sample;
                Memory(sample);
                counters.Sample(sample);
                {
                    std::lock_guard<std::mutex> lock(sampleMutex);
                    latest = std::move(sample);
                    published = true;
                }
                std::unique_lock<std::mutex> lock(waitMutex);
                if (wake.wait_for(lock, std::chrono::milliseconds(100), [this] { return stopping.load(); }))
                    break;
            }
        } catch (...) {
            std::lock_guard<std::mutex> lock(sampleMutex);
            latest = {};
            published = true;
        }
    }

public:
    WatermarkHostTelemetry() = default;
    WatermarkHostTelemetry(const WatermarkHostTelemetry&) = delete;
    WatermarkHostTelemetry& operator=(const WatermarkHostTelemetry&) = delete;
    ~WatermarkHostTelemetry() {
        stopping.store(true);
        wake.notify_all();
        if (worker.joinable())
            worker.join();
    }
    void Poll(WatermarkData& data) {

        if (!worker.joinable()) {
            try {
                worker = std::thread([this] { Run(); });
            } catch (const std::exception&) {
                return;
            }
        }

        const auto now = std::chrono::steady_clock::now();
        if (copied && now - lastCopy < std::chrono::seconds(1))
            return;
        std::unique_lock<std::mutex> lock(sampleMutex, std::try_to_lock);
        if (lock.owns_lock() && published) {
            latest.Apply(data);
            lastCopy = now;
            copied = true;
        }
    }
};
}
#endif
