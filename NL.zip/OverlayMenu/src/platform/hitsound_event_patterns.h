#pragma once

#include "hitsound_event_helpers.h"
namespace menu {
struct HitmarkerEventBindings {
    std::uintptr_t eventGlobal = 0, eventManagerTable = 0, eventTable = 0;
    std::uintptr_t addListener = 0, findListener = 0, removeListener = 0;
    std::uintptr_t getName = 0, getInt = 0, getFloat = 0, getController = 0;
};
namespace hitmarker_patterns {

inline constexpr char FloatThunk[] = "48 83 EC 38 8B 02 48 83 C1 58 89 44 24 20 8B 42 04 89 44 24 24 48 8B "
                                     "42 08 48 8D 54 24 20 48 89 44 24 28 E8";
inline constexpr char FloatCallee[] =
    "40 53 48 83 EC 40 44 8B 42 04 48 8B D9 8B 0A 4C 8B 4A 08 0F 29 74 24 30 0F 28 F2";
inline constexpr std::uintptr_t FloatCallOffset = 0x23;
}
inline bool ResolveHitmarkerEvents(const HudScanImage& image, HitmarkerEventBindings& out,
                                   std::string& diagnostic) {
    using namespace kill_patterns;
    HitmarkerEventBindings b;
    const auto fail = [&](const char* why) {
        diagnostic = why;
        return false;
    };
    b.eventManagerTable = Table(image, ".?AVCGameEventManager@@");
    b.eventTable = Table(image, ".?AVCGameEvent@@");
    if (!b.eventManagerTable || !b.eventTable)
        return fail("ambiguous/missing native event RTTI");
    const auto owner = Unique(image, EventOwner);
    if (!owner || image.Rip(owner + 10) != b.eventManagerTable)
        return fail("event-manager ownership instructions changed");
    b.eventGlobal = image.Rip(owner + 35);
    if (!image.Contains(b.eventGlobal, 8, 0x80000000, 0x20000000))
        return fail("event-manager global is not writable module data");
    b.addListener = Slot(image, b.eventManagerTable, 3);
    b.findListener = Slot(image, b.eventManagerTable, 4);
    b.removeListener = Slot(image, b.eventManagerTable, 5);
    b.getName = Slot(image, b.eventTable, 1);
    b.getInt = Slot(image, b.eventTable, 7);
    b.getFloat = Slot(image, b.eventTable, 9);
    b.getController = Slot(image, b.eventTable, 16);
    if (!At(image, b.addListener, "48 89 5C 24 10 48 89 6C 24 18 56 57 41 56 48 83 EC 20 41 0F B6 E9") ||
        !At(image, b.findListener, "48 89 5C 24 10 48 89 6C 24 18 48 89 74 24 20 57 48 83 EC 20") ||
        !At(image, b.removeListener, "41 56 48 83 EC 30 48 89 74 24 58 4C 8D B1 E0 00 00 00") ||
        !At(image, b.getName, "8B 41 14 0F BA E0 1E 73 05 48 8D 41 18 C3") ||
        !At(image, b.getInt, "48 83 EC 38 8B 02 48 83 C1 58 89 44 24 20 8B 42 04 89 44 24 24 48 8B 42 08") ||
        !At(image, b.getController, "48 83 EC 38 8B 02 4C 8D 44 24 20 89 44 24 20 8B 42 04") ||
        !Has(image, b.getController, 0x38, "FF 50 78"))
        return fail("Source 2 event/listener ABI changed");
    if (!b.getFloat || b.getFloat == b.getInt || !At(image, b.getFloat, hitmarker_patterns::FloatThunk))
        return fail("event float getter thunk changed");
    const auto callee = image.Rip(b.getFloat + hitmarker_patterns::FloatCallOffset, 1, 5);
    if (!callee || !At(image, callee, hitmarker_patterns::FloatCallee))
        return fail("event float getter body changed");
    out = b;
    diagnostic = "typed event listener + float getter ABI resolved";
    return true;
}
}
