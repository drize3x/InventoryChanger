#pragma once
#include <windows.h>

inline float MenuStudioWindowDpi(HWND window) {
    using DpiForWindow = UINT(WINAPI*)(HWND);
    static auto query =
        reinterpret_cast<DpiForWindow>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow"));
    if (window && query) {
        UINT dpi = query(window);
        if (dpi)
            return float(dpi);
    }
    HDC dc = GetDC(window);
    if (!dc)
        return 96.f;
    int dpi = GetDeviceCaps(dc, LOGPIXELSX);
    ReleaseDC(window, dc);
    return dpi > 0 ? float(dpi) : 96.f;
}
