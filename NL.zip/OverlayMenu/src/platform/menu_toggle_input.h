#pragma once
#include <atomic>
namespace menu {
class MenuToggleInput {
    std::atomic<unsigned> pending_{0};

public:
    bool KeyDown(bool repeat, bool allowed) noexcept;
    bool Take(bool focused) noexcept;
    void Cancel() noexcept;
};
}
