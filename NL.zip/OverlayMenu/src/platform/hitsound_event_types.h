#pragma once
#include "watermark_speed_delay.h"
#include <cstdint>
#include <string>
namespace menu {
inline std::uint32_t SoundKeyHash(const char* text) {
    std::string name = text;
    for (auto& c : name)
        if (c >= 'A' && c <= 'Z')
            c = char(c - 'A' + 'a');
    constexpr std::uint32_t m = 0x5bd1e995;
    auto h = std::uint32_t(name.size()) ^ 0x31415926u;
    std::size_t i = 0;
    for (; i + 4 <= name.size(); i += 4) {
        std::uint32_t k = 0;
        for (unsigned b = 0; b < 4; ++b)
            k |= std::uint32_t(static_cast<unsigned char>(name[i + b])) << (8 * b);
        k *= m;
        k ^= k >> 24;
        k *= m;
        h = h * m ^ k;
    }
    auto n = name.size() - i;
    if (n) {
        if (n >= 3)
            h ^= std::uint32_t(static_cast<unsigned char>(name[i + 2])) << 16;
        if (n >= 2)
            h ^= std::uint32_t(static_cast<unsigned char>(name[i + 1])) << 8;
        h ^= static_cast<unsigned char>(name[i]);
        h *= m;
    }
    h ^= h >> 13;
    h *= m;
    h ^= h >> 15;
    return h;
}
struct SoundEventKey {
    std::uint32_t hash = 0, index = 0xffffffffu;
    const char* text = nullptr;
};
static_assert(sizeof(SoundEventKey) == 16);
inline SoundEventKey SoundKey(const char* name) {
    return {SoundKeyHash(name), 0xffffffffu, name};
}
struct HitSoundContext {
    std::uintptr_t entities = 0, localGlobal = 0, engineObject = 0;
    std::uint32_t localFlag = 0;
    bool valid = false;
};
template <class R> bool SoundControllerPresent(R&& read, std::uintptr_t page, std::uintptr_t controller) {
    if (!controller)
        return false;
    for (unsigned i = 1; i <= 64; ++i) {
        std::uintptr_t current = 0;
        if (!read(page + 0x70 * i, current))
            return false;
        if (current == controller)
            return true;
    }
    return false;
}
}
