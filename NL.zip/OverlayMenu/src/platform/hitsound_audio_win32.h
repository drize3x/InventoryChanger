#pragma once
#include <windows.h>
#include <mmsystem.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <list>
#include <memory>
#include <vector>
#pragma comment(lib, "winmm.lib")
namespace menu {
class HitSoundAudio {
    struct Voice {
        HWAVEOUT device = nullptr;
        WAVEHDR header{};
        bool prepared = false;
        std::vector<std::int16_t> pcm;
        ~Voice() {
            if (device) {
                waveOutReset(device);
                if (prepared)
                    waveOutUnprepareHeader(device, &header, sizeof header);
                waveOutClose(device);
            }
        }
    };
    std::list<std::unique_ptr<Voice>> voices_;
    static std::uint32_t U32(const unsigned char* p) {
        return std::uint32_t(p[0]) | (std::uint32_t(p[1]) << 8) | (std::uint32_t(p[2]) << 16) |
               (std::uint32_t(p[3]) << 24);
    }
    static std::uint16_t U16(const unsigned char* p) {
        return std::uint16_t(p[0]) | std::uint16_t(p[1] << 8);
    }

public:
    void Pump() {
        for (auto i = voices_.begin(); i != voices_.end();)
            if ((*i)->header.dwFlags & WHDR_DONE)
                i = voices_.erase(i);
            else
                ++i;
    }
    bool Play(const std::filesystem::path& root, int sound, int volume) {
        static const wchar_t* names[] = {
            L"default.wav",   L"switch.wav",     L"killcard.wav",    L"bodydamage.wav", L"bodybreak.wav",
            L"woodplank.wav", L"coinpickup.wav", L"rankneutral.wav", L"press.wav",      L"levelup.wav"};
        Pump();
        if (sound < 0 || sound >= 10 || volume <= 0 || voices_.size() >= 16)
            return false;
        try {
            std::ifstream f(root / L"assets" / L"hitsounds" / names[sound], std::ios::binary | std::ios::ate);
            if (!f)
                return false;
            auto length = f.tellg();
            if (length < 44 || length > 4 * 1024 * 1024)
                return false;
            f.seekg(0);
            std::vector<unsigned char> b(static_cast<std::size_t>(length));
            if (!f.read(reinterpret_cast<char*>(b.data()), static_cast<std::streamsize>(b.size())))
                return false;
            if (std::memcmp(b.data(), "RIFF", 4) || std::memcmp(b.data() + 8, "WAVE", 4))
                return false;
            const unsigned char* data = nullptr;
            std::size_t dataSize = 0;
            bool format = false;
            for (std::size_t p = 12; p + 8 <= b.size();) {
                std::uint32_t n = U32(&b[p + 4]);
                if (n > b.size() - p - 8)
                    return false;
                const auto* chunk = &b[p + 8];
                if (!std::memcmp(&b[p], "fmt ", 4) && n >= 16)
                    format = U16(chunk) == 1 && U16(chunk + 2) == 1 && U32(chunk + 4) == 44100 &&
                             U16(chunk + 14) == 16;
                if (!std::memcmp(&b[p], "data", 4)) {
                    data = chunk;
                    dataSize = n;
                }
                p += 8 + std::size_t(n) + (n & 1u);
            }
            if (!format || !data || !dataSize || dataSize % 2)
                return false;
            auto v = std::make_unique<Voice>();
            v->pcm.resize(dataSize / 2);
            const int gain = std::clamp(volume, 0, 300);
            for (std::size_t i = 0; i < v->pcm.size(); ++i) {
                int s = static_cast<std::int16_t>(U16(data + 2 * i));
                v->pcm[i] = static_cast<std::int16_t>(std::clamp(s * gain / 100, -32768, 32767));
            }
            WAVEFORMATEX wf{};
            wf.wFormatTag = WAVE_FORMAT_PCM;
            wf.nChannels = 1;
            wf.nSamplesPerSec = 44100;
            wf.wBitsPerSample = 16;
            wf.nBlockAlign = 2;
            wf.nAvgBytesPerSec = 88200;
            if (waveOutOpen(&v->device, WAVE_MAPPER, &wf, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
                v->device = nullptr;
                return false;
            }
            v->header.lpData = reinterpret_cast<LPSTR>(v->pcm.data());
            v->header.dwBufferLength = static_cast<DWORD>(dataSize);
            if (waveOutPrepareHeader(v->device, &v->header, sizeof v->header) != MMSYSERR_NOERROR)
                return false;
            v->prepared = true;
            if (waveOutWrite(v->device, &v->header, sizeof v->header) != MMSYSERR_NOERROR)
                return false;
            voices_.push_back(std::move(v));
            return true;
        } catch (...) {
            return false;
        }
    }
};
}
