#pragma once
#ifdef _WIN32
#include <windows.h>
#include <MinHook.h>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <string>
#include "world_camera_engine.h"
#include "world_camera_patterns.h"
#include "world_view_patterns.h"
#include "win32_local_read.h"

#if defined(MENU_STUDIO_VIEW_TEST_STUB)
#define MENU_CAM_TRY try
#define MENU_CAM_EXCEPT catch (...)
#elif defined(_MSC_VER)
#define MENU_CAM_TRY __try
#define MENU_CAM_EXCEPT                                                                                      \
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER                   \
                                                               : EXCEPTION_CONTINUE_SEARCH)
#else
#error The camera HUD probes require MSVC SEH or explicit synthetic tests.
#endif
namespace menu {

class WorldNativeCamera {
public:
    enum class Status { Waiting, Idle, Ready, Unsupported, Fault, Stopped };
    using CalcViewFn = void(__fastcall*)(void*, float*, float*, float*);
    using LandingFn = void(__fastcall*)(void*, float*, bool);
    using ProjectionFn = void(__fastcall*)(void*);
    using AimPunchFn = float*(__fastcall*)(void*, float*);
    using SwayFn = void(__fastcall*)(void*, float*, float*);
    using FlagFn = bool(__fastcall*)(void*);
    using FovFn = float(__fastcall*)(void*);
    using PostFn = std::uint64_t(__fastcall*)(void*, void*, std::uint64_t, std::uint64_t, void*);
    using GetInaccuracyFn = float(__fastcall*)(void*, float*, float*);
    using GetSpreadFn = float(__fastcall*)(void*);
    using SetupViewFn = void(__fastcall*)(void*, void*);
#if defined(MENU_STUDIO_VIEW_TEST_STUB)
public:
#else
private:
#endif
    static constexpr unsigned Hooks = world_camera_hook::Count, Signatures = world_camera_hook::Signatures;
    struct Slot {
        std::uintptr_t target = 0;
        bool found = false, failed = false, created = false, enabled = false;
    };
    struct ScopeSlot {
        std::atomic<DWORD> thread{0};
        std::atomic<std::uint32_t> bits{0};
        std::atomic<std::uintptr_t> value{0};
    };

    struct PendingFov {
        std::atomic<DWORD> thread{0};
        std::atomic<float> fin{0.f}, desired{0.f}, shift{0.f};
        std::atomic<std::uint32_t> flags{0};
        void Set(float f, float d, float sh, bool scoped, bool rest) {
            fin.store(f, std::memory_order_relaxed);
            desired.store(d, std::memory_order_relaxed);
            shift.store(sh, std::memory_order_relaxed);
            flags.store((scoped ? 1u : 0u) | (rest ? 2u : 0u), std::memory_order_relaxed);
            thread.store(GetCurrentThreadId(), std::memory_order_release);
        }
        void Clear() {
            thread.store(0, std::memory_order_release);
        }
        bool Get(float& f, float& d, float& sh, bool& scoped, bool& rest) const {
            if (thread.load(std::memory_order_acquire) != GetCurrentThreadId())
                return false;
            f = fin.load(std::memory_order_relaxed);
            d = desired.load(std::memory_order_relaxed);
            sh = shift.load(std::memory_order_relaxed);
            const auto bits = flags.load(std::memory_order_relaxed);
            scoped = (bits & 1u) != 0;
            rest = (bits & 2u) != 0;
            return true;
        }
    };
    inline static std::atomic<WorldNativeCamera*> instance_{nullptr};
    inline static std::array<std::atomic<void*>, Hooks> original_{};
    std::atomic<Status> status_{Status::Waiting};
    std::atomic<bool> closing_{false}, wanted_{false};
    std::atomic<unsigned> active_{0};
    std::atomic<std::uint32_t> probeMode_{0};

    std::array<std::atomic<unsigned long long>, Signatures> calls_{}, mine_{}, applied_{};
    std::atomic<unsigned long long> probeRejected_{0}, probeFailed_{0}, frames_{0}, ownerRejected_{0},
        aspectSkipped_{0}, aspectReleased_{0}, pendingSets_{0};
    ProbeShared probe_;
    std::atomic<std::uint32_t> lastOwner_{0}, lastExpected_{0};
    std::atomic<std::uintptr_t> flagView_{0};
    std::array<ScopeSlot, 6> scope_{};
    PendingFov pending_;
    std::atomic<std::uint32_t> zoomLatch_{0};

    std::atomic<float> restFov_{0.f}, restLast_{0.f};
    std::atomic<std::uint32_t> restStable_{0};
    std::atomic<float> fovGame_{0.f}, fovOut_{0.f}, fovBase_{0.f};
    std::atomic<std::uint32_t> fovDesired_{0}, fovZoom_{0}, fovSource_{0}, fovScoped_{0};
    std::atomic<unsigned long long> fovScopedCalls_{0}, fovScopedChanged_{0};
    void ResetFovRest() {
        restFov_ = 0.f;
        restLast_ = 0.f;
        restStable_ = 0;
    }
    std::atomic<bool> knifeCapture_{false};
    std::atomic<std::uint64_t> knifeFovs_{0};
    std::atomic<ULONGLONG> knifeFovsAt_{0};
    std::atomic<float> vmRest_{0.f};
    std::array<std::atomic<std::uint32_t>, 6> layout_{};
    ViewSharedConfig config_;
    CameraSharedFrame frame_;
    std::array<Slot, Signatures> slot_{};
    HMODULE module_ = nullptr, retained_ = nullptr;
    bool attempted_ = false;
    std::string diagnostic_;
    static bool Bytes(std::uintptr_t at, void* out, std::size_t size) {
        return LocalReadBytes(at, out, size);
    }
    template <class T> static bool Read(std::uintptr_t at, T& out) {
        return Bytes(at, &out, sizeof(out));
    }
    template <class T> static bool Write(std::uintptr_t at, const T& value) {
        return LocalWriteBytes(at, &value, sizeof(value));
    }
    template <class Fn> static Fn Original(unsigned i) {
        return reinterpret_cast<Fn>(original_[i].load(std::memory_order_acquire));
    }
    struct PatternInfo {
        const char* name;
        const char* pattern;
        unsigned size;
    };
    static const PatternInfo& Info(unsigned i) {
        static const PatternInfo table[Signatures] = {
            {"CalcView", world_camera_patterns::CalcView, world_camera_patterns::CalcViewSize},
            {"Landing", world_camera_patterns::Landing, world_camera_patterns::LandingSize},
            {"Projection", world_camera_patterns::Projection, world_camera_patterns::ProjectionSize},
            {"AimPunch", world_camera_patterns::AimPunch, world_camera_patterns::AimPunchSize},
            {"ViewmodelSway", world_camera_patterns::ViewmodelSway, world_camera_patterns::ViewmodelSwaySize},
            {"HasBurst", world_camera_patterns::HasBurst, world_camera_patterns::HasBurstSize},
            {"HideViewmodel", world_camera_patterns::HideViewmodel, world_camera_patterns::HideViewmodelSize},
            {"ViewmodelFov", world_camera_patterns::ViewmodelFov, world_camera_patterns::ViewmodelFovSize},
            {"PostProcess", world_camera_patterns::PostProcess, world_camera_patterns::PostProcessSize},
            {"SetupView", world_camera_patterns::SetupView, world_camera_patterns::SetupViewSize},
            {"GetInaccuracy", world_camera_patterns::Inaccuracy, world_camera_patterns::InaccuracySize},
            {"GetSpread", world_camera_patterns::Spread, world_camera_patterns::SpreadSize}};
        return table[i];
    }
    static void* DetourOf(unsigned i) {
        switch (i) {
        case world_camera_hook::CalcView:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnCalcView);
        case world_camera_hook::Landing:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnLanding);
        case world_camera_hook::Projection:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnProjection);
        case world_camera_hook::AimPunch:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnAimPunch);
        case world_camera_hook::Sway:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnSway);
        case world_camera_hook::HasBurst:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnHasBurst);
        case world_camera_hook::HideViewmodel:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnHideViewmodel);
        case world_camera_hook::ViewmodelFov:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnViewmodelFov);
        case world_camera_hook::PostProcess:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnPostProcess);
        case world_camera_hook::SetupView:
            return reinterpret_cast<void*>(&WorldNativeCamera::OnSetupView);
        default:
            return nullptr;
        }
    }

    bool Current(CameraFrame& frame, ViewConfig& config) const {
        if (closing_.load(std::memory_order_relaxed) || !wanted_.load(std::memory_order_acquire))
            return false;
        if (!frame_.Load(frame, GetTickCount64()))
            return false;
        config = config_.Load();
        return true;
    }
    std::uint32_t Layout(unsigned i) const {
        return layout_[i].load(std::memory_order_relaxed);
    }

    class ScopeGuard {
        WorldNativeCamera* owner_;
        ScopeSlot* slot_ = nullptr;

    public:
        ScopeGuard(WorldNativeCamera* owner, std::uint32_t bits, std::uintptr_t value = 0) : owner_(owner) {
            if (!owner || !bits)
                return;
            const DWORD me = GetCurrentThreadId();
            for (auto& s : owner->scope_) {
                DWORD expected = 0;
                if (s.thread.compare_exchange_strong(expected, me)) {
                    s.value.store(value, std::memory_order_release);
                    s.bits.store(bits, std::memory_order_release);
                    slot_ = &s;
                    return;
                }
            }
        }
        void Leave() {
            if (slot_) {
                slot_->bits.store(0, std::memory_order_release);
                slot_->value.store(0, std::memory_order_release);
                slot_->thread.store(0, std::memory_order_release);
                slot_ = nullptr;
            }
        }
        ~ScopeGuard() {
            Leave();
        }
        ScopeGuard(const ScopeGuard&) = delete;
        ScopeGuard& operator=(const ScopeGuard&) = delete;
    };
    bool InScope(std::uint32_t mask) const {
        const DWORD me = GetCurrentThreadId();
        for (const auto& s : scope_)
            if (s.thread.load(std::memory_order_acquire) == me &&
                (s.bits.load(std::memory_order_acquire) & mask))
                return true;
        return false;
    }

    std::uintptr_t ScopeValue(std::uint32_t mask) const {
        const DWORD me = GetCurrentThreadId();
        for (const auto& s : scope_)
            if (s.thread.load(std::memory_order_acquire) == me &&
                (s.bits.load(std::memory_order_acquire) & mask))
                return s.value.load(std::memory_order_acquire);
        return 0;
    }
    static bool SamePointer(std::uintptr_t at, std::uintptr_t expected) {
        std::uintptr_t value = 0;
        return expected && Read(at, value) && value == expected;
    }
    float PawnAbsZ(std::uintptr_t pawn) const {
        const auto scene = Layout(3), origin = Layout(4);
        std::uintptr_t node = 0;
        float z = 0;
        if (!scene || !origin || !Read(pawn + scene, node) || !node || !Read(node + origin + 8, z) ||
            !std::isfinite(z))
            return std::numeric_limits<float>::quiet_NaN();
        return z;
    }

    static bool SameHandle(std::uint32_t value, std::uint32_t expected) {
        const auto invalid = [](std::uint32_t h) { return h == 0u || h == 0xFFFFFFFFu || h == 0xFFFFFFFEu; };
        if (invalid(value) || invalid(expected))
            return false;
        return value == expected || ((value ^ expected) & 0x7FFFu) == 0u;
    }
    bool OwnedByLocal(const void* entity, const CameraFrame& frame) {
        const auto owner = Layout(2);
        std::uint32_t handle = 0;
        if (!owner || !frame.pawnHandle || !entity ||
            !Read(reinterpret_cast<std::uintptr_t>(entity) + owner, handle))
            return false;
        lastOwner_.store(handle, std::memory_order_relaxed);
        lastExpected_.store(frame.pawnHandle, std::memory_order_relaxed);
        if (SameHandle(handle, frame.pawnHandle))
            return true;
        ++ownerRejected_;
        return false;
    }

    void DoCalcView(CalcViewFn next, void* self, float* origin, float* angles, float* fov) {
        ++calls_[world_camera_hook::CalcView];
        CameraFrame frame;
        ViewConfig cfg;
        const auto selfAddress = reinterpret_cast<std::uintptr_t>(self);
        const bool local = Current(frame, cfg) &&
                           SamePointer(selfAddress + world_camera_layout::CameraServicesPawn, frame.pawn);
        const bool mine = local && cfg.WantsCalcView();
        if (mine)
            ++mine_[world_camera_hook::CalcView];
        const auto punchOffset = Layout(0);
        const std::uintptr_t punchAt = selfAddress + punchOffset;
        float savedPunch[3] = {0, 0, 0};
        bool punchZeroed = false;
        if (mine && (cfg.recoil & world_view_recoil::NoShake) && punchOffset) {
            const float zero[3] = {0, 0, 0};
            if (Bytes(punchAt, savedPunch, sizeof savedPunch) && CameraFinite(savedPunch, 3) &&
                LocalWriteBytes(punchAt, zero, sizeof zero)) {
                punchZeroed = true;
                ++applied_[world_camera_hook::CalcView];
            }
        }
        {
            ScopeGuard guard(
                this, mine && (cfg.recoil & world_view_recoil::NoRecoil) ? world_camera_scope::Camera : 0u);
            if (next)
                next(self, origin, angles, fov);
        }
        if (punchZeroed) {
            float now[3] = {1, 1, 1};
            if (Bytes(punchAt, now, sizeof now) && now[0] == 0.f && now[1] == 0.f && now[2] == 0.f)
                LocalWriteBytes(punchAt, savedPunch, sizeof savedPunch);
        }
        if (local) {
            const auto mode = probeMode_.load(std::memory_order_relaxed);
            if (mode)
                SampleProbe(frame, mode);
        }
        const bool fovWanted = cfg.fov || cfg.scopeFov || cfg.instantScope;
        if (local && fov && (fovWanted || cfg.WantsScopedViewmodelFov()))
            ApplyFov(frame, cfg, selfAddress, fov, fovWanted);
    }

    void ApplyFov(const CameraFrame& frame, const ViewConfig& cfg, std::uintptr_t selfAddress, float* fov,
                  bool fovWanted) {
        const float game = *fov;
        if (!std::isfinite(game))
            return;
        FovInput in;
        in.game = game;
        in.scoped = frame.scoped;

        FovRestState rest{restFov_.load(std::memory_order_relaxed), restLast_.load(std::memory_order_relaxed),
                          restStable_.load(std::memory_order_relaxed)};
        rest = FovRestObserve(rest, game, frame.scoped, frame.zoomLevel);
        restFov_.store(rest.rest, std::memory_order_relaxed);
        restLast_.store(rest.last, std::memory_order_relaxed);
        restStable_.store(rest.stable, std::memory_order_relaxed);
        FovBaseSource source = FovBaseSource::Game;
        in.desired = FovBaseFor(frame.desired, rest.rest, game, frame.scoped, source);
        const auto latch =
            ScopeZoomLatch(zoomLatch_.load(std::memory_order_relaxed), frame.zoomLevel, game, in.desired);
        zoomLatch_.store(latch, std::memory_order_relaxed);
        in.zoomLevel = latch;
        const auto fovOffset = Layout(1);
        std::uint32_t target = 0;
        if (fovOffset && Read(selfAddress + fovOffset, target) && target <= 170u)
            in.instantTarget = target;
        FovResult result;
        result.fov = game;
        if (fovWanted)
            result = FovCompute(cfg, in);
        if (result.changed) {
            *fov = result.fov;
            ++applied_[world_camera_hook::CalcView];
        }
        fovGame_.store(game, std::memory_order_relaxed);
        fovOut_.store(result.fov, std::memory_order_relaxed);
        fovBase_.store(in.desired, std::memory_order_relaxed);
        fovDesired_.store(frame.desired, std::memory_order_relaxed);
        fovZoom_.store(in.zoomLevel, std::memory_order_relaxed);
        fovSource_.store(std::uint32_t(source), std::memory_order_relaxed);
        fovScoped_.store(frame.scoped ? 1u : 0u, std::memory_order_relaxed);
        if (frame.scoped) {
            ++fovScopedCalls_;
            if (result.changed)
                ++fovScopedChanged_;
        }
        if (InScope(world_camera_scope::SetupView)) {
            const bool rest = !frame.scoped && FovBaseKnown(in.desired) && game >= in.desired - .01f;
            pending_.Set(result.fov, in.desired, result.overrideShift, frame.scoped, rest);
            ++pendingSets_;
        }
    }

#if defined(MENU_STUDIO_VIEW_TEST_STUB)
    inline static GetInaccuracyFn testInaccuracy_ = nullptr;
    inline static GetSpreadFn testSpread_ = nullptr;
    inline static AimPunchFn testPunch_ = nullptr;
    static bool CallInaccuracy(std::uintptr_t, void* weapon, float& out) {
        if (!testInaccuracy_)
            return false;
        MENU_CAM_TRY {
            out = testInaccuracy_(weapon, nullptr, nullptr);
            return true;
        }
        MENU_CAM_EXCEPT {
            return false;
        }
    }
    static bool CallSpread(std::uintptr_t, void* weapon, float& out) {
        if (!testSpread_)
            return false;
        MENU_CAM_TRY {
            out = testSpread_(weapon);
            return true;
        }
        MENU_CAM_EXCEPT {
            return false;
        }
    }
    static bool CallPunch(std::uintptr_t, void* services, float* out) {
        if (!testPunch_)
            return false;
        MENU_CAM_TRY {
            return testPunch_(services, out) == out;
        }
        MENU_CAM_EXCEPT {
            return false;
        }
    }
#else
    static bool CallInaccuracy(std::uintptr_t fn, void* weapon, float& out) {
        MENU_CAM_TRY {
            out = reinterpret_cast<GetInaccuracyFn>(fn)(weapon, nullptr, nullptr);
            return true;
        }
        MENU_CAM_EXCEPT {
            return false;
        }
    }
    static bool CallSpread(std::uintptr_t fn, void* weapon, float& out) {
        MENU_CAM_TRY {
            out = reinterpret_cast<GetSpreadFn>(fn)(weapon);
            return true;
        }
        MENU_CAM_EXCEPT {
            return false;
        }
    }
    static bool CallPunch(std::uintptr_t fn, void* services, float* out) {
        MENU_CAM_TRY {
            return reinterpret_cast<AimPunchFn>(fn)(services, out) == out;
        }
        MENU_CAM_EXCEPT {
            return false;
        }
    }
#endif

    void SampleProbe(const CameraFrame& frame, std::uint32_t mode) {
        using namespace world_camera_hook;
        using namespace world_camera_probe;
        ++calls_[InaccuracyFn];
        const auto& inaccuracy = slot_[InaccuracyFn];
        const auto& spread = slot_[SpreadFn];
        const auto now = GetTickCount64();
        if (!(mode & 1u) || !frame.weapon || !inaccuracy.found || !spread.found ||
            closing_.load(std::memory_order_relaxed) || now < frame.at || now - frame.at > MaxAgeMs / 2) {
            probe_.Clear();
            return;
        }
        std::uintptr_t table = 0, slotInaccuracy = 0, slotSpread = 0;
        if (!Read(frame.weapon, table) || !table || !Read(table + InaccuracySlot, slotInaccuracy) ||
            slotInaccuracy != inaccuracy.target || !Read(table + SpreadSlot, slotSpread) ||
            slotSpread != spread.target) {
            ++probeRejected_;
            probe_.Clear();
            return;
        }
        ProbeSample sample;
        sample.weapon = frame.weapon;
        void* const weapon = reinterpret_cast<void*>(frame.weapon);
        if (!CallInaccuracy(slotInaccuracy, weapon, sample.inaccuracy) ||
            !CallSpread(slotSpread, weapon, sample.spread) ||
            !ProbePlausible(sample.inaccuracy, sample.spread)) {
            ++probeFailed_;
            probe_.Clear();
            return;
        }
        if (mode & 2u) {
            std::uintptr_t services = 0;
            float punch[3] = {0.f, 0.f, 0.f};
            const auto offset = Layout(5);
            const auto& aim = slot_[AimPunch];
            if (offset && aim.found && Read(frame.pawn + offset, services) && services &&
                CallPunch(aim.target, reinterpret_cast<void*>(services), punch) &&
                ProbePunchPlausible(punch)) {
                sample.hasPunch = true;
                sample.punchPitch = punch[0];
                sample.punchYaw = punch[1];
            }
        }
        probe_.Store(sample, now);
        ++applied_[InaccuracyFn];
    }
    void DoLanding(LandingFn next, void* pawn, float* origin, bool update) {
        ++calls_[world_camera_hook::Landing];
        CameraFrame frame;
        ViewConfig cfg;
        const bool mine = origin && Current(frame, cfg) && cfg.landing &&
                          reinterpret_cast<std::uintptr_t>(pawn) == frame.pawn;
        if (mine)
            ++mine_[world_camera_hook::Landing];
        const float z = mine ? origin[2] : 0.f;
        const bool saved = mine && std::isfinite(z);
        if (next)
            next(pawn, origin, update);
        if (saved) {
            origin[2] = z;
            ++applied_[world_camera_hook::Landing];
        }
    }

    void DoProjection(ProjectionFn next, void* renderView) {
        ++calls_[world_camera_hook::Projection];
        CameraFrame frame;
        ViewConfig cfg;
        const bool mine = renderView && Current(frame, cfg) && cfg.aspect;
        if (mine)
            ++mine_[world_camera_hook::Projection];
        ScopeGuard guard(
            this,
            (mine || knifeCapture_.load(std::memory_order_relaxed)) ? world_camera_scope::RenderStart : 0u,
            reinterpret_cast<std::uintptr_t>(renderView));
        if (next)
            next(renderView);
    }

    void ReleaseAspectFlag(std::uintptr_t onlyView = 0) {
        auto view = flagView_.load(std::memory_order_acquire);
        if (!view || (onlyView && onlyView != view))
            return;
        if (!flagView_.compare_exchange_strong(view, 0, std::memory_order_acq_rel))
            return;
        std::uint8_t flags = 0;
        if (Read(view + world_camera_layout::SetupFlags, flags) &&
            (flags & world_camera_layout::SetupAspectFlag) &&
            Write(view + world_camera_layout::SetupFlags,
                  std::uint8_t(flags & ~world_camera_layout::SetupAspectFlag)))
            ++aspectReleased_;
    }
    bool ApplyAspect(std::uintptr_t view, const ViewConfig& cfg) {
        using namespace world_camera_layout;
        std::uint8_t flags = 0;
        float native = 0, fov = 0, vm = 0;
        if (!Read(view + SetupFlags, flags) || !Read(view + SetupAspect, native) ||
            !Read(view + SetupFov, fov) || !Read(view + SetupViewmodelFov, vm))
            return false;
        if (flags & SetupAspectFlag) {
            ++aspectSkipped_;
            return false;
        }
        const auto plan = AspectCompute(cfg, native, fov, vm);
        if (!plan.apply || (std::fabs(plan.aspect - native) < 1e-4f && std::fabs(plan.fov - fov) < 1e-3f &&
                            std::fabs(plan.viewmodelFov - vm) < 1e-3f))
            return false;
        bool wroteAspect = Write(view + SetupAspect, plan.aspect),
             wroteFov = wroteAspect && Write(view + SetupFov, plan.fov),
             wroteVm = wroteFov && Write(view + SetupViewmodelFov, plan.viewmodelFov);
        if (!wroteVm || !Write(view + SetupFlags, std::uint8_t(flags | SetupAspectFlag))) {
            if (wroteVm)
                Write(view + SetupViewmodelFov, vm);
            if (wroteFov)
                Write(view + SetupFov, fov);
            if (wroteAspect)
                Write(view + SetupAspect, native);
            return false;
        }
        flagView_.store(view, std::memory_order_release);
        ++applied_[world_camera_hook::SetupView];
        return true;
    }
    void DoSetupView(SetupViewFn next, void* mode, void* view) {
        ++calls_[world_camera_hook::SetupView];
        ReleaseAspectFlag(reinterpret_cast<std::uintptr_t>(view));
        pending_.Clear();
        {
            ScopeGuard guard(this, world_camera_scope::SetupView);
            if (next)
                next(mode, view);
        }
        pending_.Clear();
        CameraFrame frame;
        ViewConfig cfg;
        const auto renderView = ScopeValue(world_camera_scope::RenderStart);
        if (!view || !renderView ||
            reinterpret_cast<std::uintptr_t>(view) != renderView + world_camera_layout::RenderViewSetup)
            return;
        if (Current(frame, cfg) && cfg.aspect) {
            ++mine_[world_camera_hook::SetupView];
            ApplyAspect(reinterpret_cast<std::uintptr_t>(view), cfg);
        }
        if (knifeCapture_.load(std::memory_order_relaxed)) {
            float world = 0, vm = 0;
            const auto address = reinterpret_cast<std::uintptr_t>(view);
            if (Read(address + world_camera_layout::SetupFov, world) &&
                Read(address + world_camera_layout::SetupViewmodelFov, vm) && std::isfinite(world) &&
                std::isfinite(vm) && world > 5.f && world < 175.f && vm > 5.f && vm < 175.f) {
                std::uint32_t a = 0, b = 0;
                std::memcpy(&a, &world, 4);
                std::memcpy(&b, &vm, 4);
                knifeFovs_.store(std::uint64_t(a) | (std::uint64_t(b) << 32), std::memory_order_release);
                knifeFovsAt_.store(GetTickCount64(), std::memory_order_release);
            }
        }
    }
    void DoSway(SwayFn next, void* vm, float* origin, float* angles) {
        ++calls_[world_camera_hook::Sway];
        CameraFrame frame;
        ViewConfig cfg;
        const bool mine =
            origin && angles && Current(frame, cfg) && cfg.WantsSway() && OwnedByLocal(vm, frame);
        if (mine)
            ++mine_[world_camera_hook::Sway];
        std::uint32_t bits = 0;
        if (mine) {
            if (cfg.recoil & world_view_recoil::NoViewmodelRecoil)
                bits |= world_camera_scope::Viewmodel;
            if (cfg.recoil & world_view_recoil::NoBurstSway)
                bits |= world_camera_scope::Burst;
        }
        {
            ScopeGuard guard(this, bits);
            if (next)
                next(vm, origin, angles);
        }
        if (!mine || !(cfg.ModifiersActive() || cfg.viewmodelAngles))
            return;
        SwayState state;
        float absZ = std::numeric_limits<float>::quiet_NaN();
        if (cfg.ModifiersActive()) {
            unsigned char raw[world_camera_layout::SwayBlockBytes];
            if (!Bytes(reinterpret_cast<std::uintptr_t>(vm) + world_camera_layout::SwayBlock, raw,
                       sizeof raw) ||
                !SwayDecode(raw, state))
                return;
            absZ = PawnAbsZ(frame.pawn);
        }
        if (SwayAdjust(cfg, state, absZ, origin, angles))
            ++applied_[world_camera_hook::Sway];
    }
    bool DoHideViewmodel(void* weapon, bool value) {
        ++calls_[world_camera_hook::HideViewmodel];
        CameraFrame frame;
        ViewConfig cfg;
        if (!value || !Current(frame, cfg) || !cfg.WantsScopedViewmodel() || !OwnedByLocal(weapon, frame))
            return value;
        ++mine_[world_camera_hook::HideViewmodel];
        ++applied_[world_camera_hook::HideViewmodel];
        return false;
    }

    float DoViewmodelFov(float value) {
        ++calls_[world_camera_hook::ViewmodelFov];
        CameraFrame frame;
        ViewConfig cfg;
        if (!std::isfinite(value) || value < 1.f || value > 179.f ||
            !InScope(world_camera_scope::SetupView) || !Current(frame, cfg))
            return value;
        float fin = 0, desired = 0, shift = 0;
        bool scoped = false, rest = false;
        if (!pending_.Get(fin, desired, shift, scoped, rest))
            return value;
        ++mine_[world_camera_hook::ViewmodelFov];
        if (rest)
            vmRest_.store(value, std::memory_order_relaxed);
        float result = value - shift;
        if (scoped && cfg.WantsScopedViewmodelFov()) {
            const float held = vmRest_.load(std::memory_order_relaxed);
            result = (held >= 1.f && held <= 179.f ? held : value) - (fin - desired);
        }
        if (!std::isfinite(result) || std::fabs(result) >= 1000.f || result == value)
            return value;
        ++applied_[world_camera_hook::ViewmodelFov];
        return result;
    }
    std::uint64_t DoPostProcess(PostFn next, void* a, void* context, std::uint64_t h1, std::uint64_t h2,
                                void* params) {
        ++calls_[world_camera_hook::PostProcess];
        CameraFrame frame;
        ViewConfig cfg;
        const auto at = reinterpret_cast<std::uintptr_t>(params) + 4;
        std::uint8_t flag = 0;
        bool zeroed = false;
        if (params && Current(frame, cfg) && cfg.WantsScopePass() && Read(at, flag) && flag != 0) {
            zeroed = Write(at, std::uint8_t(0));
            if (zeroed)
                ++applied_[world_camera_hook::PostProcess];
        }
        const auto result = next ? next(a, context, h1, h2, params) : 0;
        if (zeroed)
            Write(at, flag);
        return result;
    }

    static void __fastcall OnCalcView(void* self, float* origin, float* angles, float* fov) {
        auto* camera = instance_.load();
        const auto next = Original<CalcViewFn>(world_camera_hook::CalcView);
        if (!camera) {
            if (next)
                next(self, origin, angles, fov);
            return;
        }
        ++camera->active_;
        camera->DoCalcView(next, self, origin, angles, fov);
        --camera->active_;
    }
    static void __fastcall OnLanding(void* pawn, float* origin, bool update) {
        auto* camera = instance_.load();
        const auto next = Original<LandingFn>(world_camera_hook::Landing);
        if (!camera) {
            if (next)
                next(pawn, origin, update);
            return;
        }
        ++camera->active_;
        camera->DoLanding(next, pawn, origin, update);
        --camera->active_;
    }
    static void __fastcall OnProjection(void* view) {
        auto* camera = instance_.load();
        const auto next = Original<ProjectionFn>(world_camera_hook::Projection);
        if (!camera) {
            if (next)
                next(view);
            return;
        }
        ++camera->active_;
        camera->DoProjection(next, view);
        --camera->active_;
    }
    static float* __fastcall OnAimPunch(void* self, float* out) {
        auto* camera = instance_.load();
        const auto next = Original<AimPunchFn>(world_camera_hook::AimPunch);
        if (!camera)
            return next ? next(self, out) : out;
        ++camera->active_;
        float* result = next ? next(self, out) : out;
        ++camera->calls_[world_camera_hook::AimPunch];
        if (out && result == out &&
            camera->InScope(world_camera_scope::Camera | world_camera_scope::Viewmodel) &&
            !camera->closing_.load(std::memory_order_relaxed)) {
            out[0] = out[1] = out[2] = 0.f;
            ++camera->applied_[world_camera_hook::AimPunch];
        }
        --camera->active_;
        return result;
    }
    static void __fastcall OnSway(void* vm, float* origin, float* angles) {
        auto* camera = instance_.load();
        const auto next = Original<SwayFn>(world_camera_hook::Sway);
        if (!camera) {
            if (next)
                next(vm, origin, angles);
            return;
        }
        ++camera->active_;
        camera->DoSway(next, vm, origin, angles);
        --camera->active_;
    }
    static bool __fastcall OnHasBurst(void* weapon) {
        auto* camera = instance_.load();
        const auto next = Original<FlagFn>(world_camera_hook::HasBurst);
        if (!camera)
            return next ? next(weapon) : false;
        ++camera->active_;
        const bool value = next ? next(weapon) : false;
        ++camera->calls_[world_camera_hook::HasBurst];
        const bool suppressed = value && camera->InScope(world_camera_scope::Burst) &&
                                !camera->closing_.load(std::memory_order_relaxed);
        if (suppressed)
            ++camera->applied_[world_camera_hook::HasBurst];
        --camera->active_;
        return suppressed ? false : value;
    }
    static bool __fastcall OnHideViewmodel(void* weapon) {
        auto* camera = instance_.load();
        const auto next = Original<FlagFn>(world_camera_hook::HideViewmodel);
        if (!camera)
            return next ? next(weapon) : false;
        ++camera->active_;
        const bool value = next ? next(weapon) : false;
        const bool result = camera->DoHideViewmodel(weapon, value);
        --camera->active_;
        return result;
    }
    static float __fastcall OnViewmodelFov(void* self) {
        auto* camera = instance_.load();
        const auto next = Original<FovFn>(world_camera_hook::ViewmodelFov);
        if (!camera)
            return next ? next(self) : 0.f;
        ++camera->active_;
        const float value = next ? next(self) : 0.f;
        const float result = camera->DoViewmodelFov(value);
        --camera->active_;
        return result;
    }
    static void __fastcall OnSetupView(void* mode, void* view) {
        auto* camera = instance_.load();
        const auto next = Original<SetupViewFn>(world_camera_hook::SetupView);
        if (!camera) {
            if (next)
                next(mode, view);
            return;
        }
        ++camera->active_;
        camera->DoSetupView(next, mode, view);
        --camera->active_;
    }
    static std::uint64_t __fastcall OnPostProcess(void* a, void* context, std::uint64_t h1, std::uint64_t h2,
                                                  void* params) {
        auto* camera = instance_.load();
        const auto next = Original<PostFn>(world_camera_hook::PostProcess);
        if (!camera)
            return next ? next(a, context, h1, h2, params) : 0;
        ++camera->active_;
        const auto result = camera->DoPostProcess(next, a, context, h1, h2, params);
        --camera->active_;
        return result;
    }

    bool Scan(HMODULE module) {
        WatermarkKdModule info;
        HudScanImage image;
        if (!WatermarkKdLoadModule([](std::uintptr_t at, auto& value) { return Read(at, value); },
                                   reinterpret_cast<std::uintptr_t>(module), info) ||
            !image.Load(info, Bytes)) {
            diagnostic_ = "Camera: cannot snapshot loaded client module";
            return false;
        }
        unsigned found = 0;
        std::string missing;
        for (unsigned i = 0; i < Signatures; ++i) {
            const char* pattern = Info(i).pattern;

            if (info.timestamp == 0x6af4a59cu && info.size == 0x298a000u) {
                if (i == world_camera_hook::InaccuracyFn)
                    pattern = world_camera_patterns::InaccuracyClient202611;
                else if (i == world_camera_hook::SpreadFn)
                    pattern = world_camera_patterns::SpreadClient202611;
            }
            const auto address = world_view_patterns::Unique(image, pattern);
            if (address && image.Contains(address, Info(i).size, 0x20000000)) {
                slot_[i].target = address;
                slot_[i].found = true;
                ++found;
            } else {
                slot_[i] = Slot{};
                missing += std::string(missing.empty() ? "" : ",") + Info(i).name;
            }
        }
        diagnostic_ =
            "Camera [camera-v2]: " + std::to_string(found) + "/" + std::to_string(Signatures) +
            " signatures unique" +
            (missing.empty() ? std::string() : "; missing/ambiguous (feature disabled): " + missing);
        return found != 0;
    }
    bool Install(unsigned i) {
        if (i >= Hooks)
            return false;
        auto& s = slot_[i];
        if (s.created || s.failed || !s.found)
            return false;
#ifndef MENU_STUDIO_VIEW_TEST_STUB
        if (!retained_ && !GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
                                              reinterpret_cast<LPCWSTR>(s.target), &retained_)) {
            s.failed = true;
            diagnostic_ += "; " + std::string(Info(i).name) + ": cannot retain loaded client module";
            return false;
        }
#endif
        void* trampoline = nullptr;
        if (MH_CreateHook(reinterpret_cast<void*>(s.target), DetourOf(i), &trampoline) != MH_OK ||
            !trampoline) {
            s.failed = true;
            diagnostic_ += "; " + std::string(Info(i).name) + ": MH_CreateHook failed, no hook installed";
            return false;
        }
        original_[i].store(trampoline, std::memory_order_release);
        instance_ = this;
        s.created = true;
        if (MH_EnableHook(reinterpret_cast<void*>(s.target)) != MH_OK) {
            s.failed = true;
            diagnostic_ +=
                "; " + std::string(Info(i).name) + ": MH_EnableHook failed, retained until cleanup";
            return false;
        }
        s.enabled = true;
        return true;
    }

public:
    void SetKnifeTrailCapture(bool enabled) {
        knifeCapture_.store(enabled, std::memory_order_relaxed);
        if (!enabled)
            knifeFovsAt_.store(0, std::memory_order_release);
    }
    bool KnifeTrailFovs(float& world, float& vm) const {
        const auto at = knifeFovsAt_.load(std::memory_order_acquire), now = GetTickCount64();
        if (!at || now < at || now - at > 250)
            return false;
        const auto bits = knifeFovs_.load(std::memory_order_acquire);
        std::uint32_t a = std::uint32_t(bits), b = std::uint32_t(bits >> 32);
        std::memcpy(&world, &a, 4);
        std::memcpy(&vm, &b, 4);
        return std::isfinite(world) && std::isfinite(vm) && world > 5 && world < 175 && vm > 5 && vm < 175;
    }
    Status State() const {
        return status_.load();
    }
    bool Wanted() const {
        return wanted_.load();
    }
    bool Installed(unsigned hook) const {
        return hook < Hooks && slot_[hook].enabled;
    }
    unsigned InstalledCount() const {
        unsigned n = 0;
        for (const auto& s : slot_)
            if (s.enabled)
                ++n;
        return n;
    }

    std::string Diagnostic() const {
        std::string text = diagnostic_ + "; status=" + std::to_string(unsigned(State())) + " hooks:";
        for (unsigned i = 0; i < Signatures; ++i) {
            const auto& s = slot_[i];
            text += std::string(" ") + Info(i).name + "=" +
                    (s.enabled  ? "on"
                     : s.failed ? "failed"
                     : s.found  ? "idle"
                                : "missing") +
                    "(" + std::to_string(calls_[i].load()) + "/" + std::to_string(mine_[i].load()) + "/" +
                    std::to_string(applied_[i].load()) + ")";
        }
        char owner[96];
        std::snprintf(owner, sizeof owner, "; frames=%llu owner rejected=%llu last=0x%X expected=0x%X",
                      frames_.load(), ownerRejected_.load(), lastOwner_.load(), lastExpected_.load());
        return text + owner + "; aspect skipped=" + std::to_string(aspectSkipped_.load()) +
               " released=" + std::to_string(aspectReleased_.load()) +
               "; fov hand-overs=" + std::to_string(pendingSets_.load()) + FovDiagnostic() +
               "; read=" + LocalReadBackend();
    }

    std::string FovDiagnostic() const {
        char text[256];
        std::snprintf(text, sizeof text,
                      "; fov: game=%.1f out=%.1f base=%.1f(%s) desired=%u rest=%.1f scoped=%u zoom=%u scoped "
                      "calls=%llu changed=%llu",
                      double(fovGame_.load()), double(fovOut_.load()), double(fovBase_.load()),
                      FovBaseSourceName(FovBaseSource(fovSource_.load())), fovDesired_.load(),
                      double(restFov_.load()), fovScoped_.load(), fovZoom_.load(), fovScopedCalls_.load(),
                      fovScopedChanged_.load());
        return text;
    }

    void Configure(const CameraLayout& layout) {
        layout_[0] = layout.viewPunch;
        layout_[1] = layout.cameraFov;
        layout_[2] = layout.ownerHandle;
        layout_[3] = layout.scene;
        layout_[4] = layout.absOrigin;
        layout_[5] = layout.aimPunchServices;
    }

    void Submit(const ViewConfig& config, const CameraFrame& frame,
                const ProbeRequest& probe = ProbeRequest{}) {
        if (closing_ || !frame.pawn || !(config.WantsCamera() || probe.Any())) {
            Clear();
            return;
        }
        config_.Store(config);
        frame_.Store(frame, GetTickCount64());
        ++frames_;
        probeMode_.store((probe.inaccuracy ? 1u : 0u) | (probe.punch ? 2u : 0u), std::memory_order_relaxed);
        if (!probe.Any())
            probe_.Clear();
        wanted_.store(true, std::memory_order_release);
    }
    void Clear() {
        wanted_.store(false, std::memory_order_release);
        config_.Clear();
        frame_.Clear();
        probeMode_.store(0, std::memory_order_relaxed);
        probe_.Clear();
    }

    bool Probe(ProbeSample& out, std::uint64_t maxAge = world_camera_probe::MaxAgeMs) const {
        return !closing_.load(std::memory_order_relaxed) && probe_.Load(out, GetTickCount64(), maxAge);
    }

    unsigned long long ProbeCalls() const {
        return calls_[world_camera_hook::InaccuracyFn].load();
    }
    unsigned long long ProbePublished() const {
        return applied_[world_camera_hook::InaccuracyFn].load();
    }
    unsigned long long ProbeRejected() const {
        return probeRejected_.load();
    }
    unsigned long long ProbeFailed() const {
        return probeFailed_.load();
    }
    std::string ProbeDiagnostic() const {
        return "probe calls/published/rejected/failed=" + std::to_string(ProbeCalls()) + "/" +
               std::to_string(ProbePublished()) + "/" + std::to_string(ProbeRejected()) + "/" +
               std::to_string(ProbeFailed());
    }

    void TryStart() {
        if (closing_)
            return;
        auto module = GetModuleHandleW(L"client.dll");
        if (!module)
            return;
        if (!attempted_ || module != module_) {
            if (attempted_ && module == module_)
                return;
            attempted_ = true;
            module_ = module;
            status_ = Status::Unsupported;
            if (!Scan(module))
                return;
        }
        Install(world_camera_hook::CalcView);
        Install(world_camera_hook::PostProcess);
        status_ = InstalledCount() ? Status::Ready : Status::Idle;
    }
    bool Stop(DWORD timeout = 2000) {
        closing_ = true;
        Clear();
        bool ok = true;
        for (unsigned i = 0; i < Hooks; ++i) {
            auto& s = slot_[i];
            if (!s.created)
                continue;
            const auto result = MH_DisableHook(reinterpret_cast<void*>(s.target));
            if (result == MH_OK || result == MH_ERROR_DISABLED)
                s.enabled = false;
            else
                ok = false;
        }
        if (!ok)
            return false;
        const auto deadline = GetTickCount64() + timeout;
        while (active_ && GetTickCount64() < deadline)
            Sleep(1);
        if (active_)
            return false;
        ReleaseAspectFlag();
        status_ = Status::Stopped;
        return true;
    }
    bool RemoveHook() {
        if (!closing_ || active_)
            return false;
        for (const auto& s : slot_)
            if (s.enabled)
                return false;
        bool ok = true;
        for (unsigned i = 0; i < Hooks; ++i) {
            auto& s = slot_[i];
            if (!s.created)
                continue;
            if (MH_RemoveHook(reinterpret_cast<void*>(s.target)) == MH_OK)
                s.created = false;
            else
                ok = false;
        }
        if (!ok)
            return false;
        instance_ = nullptr;
        for (auto& o : original_)
            o.store(nullptr);
#ifndef MENU_STUDIO_VIEW_TEST_STUB
        if (retained_) {
            FreeLibrary(retained_);
            retained_ = nullptr;
        }
#endif
        return true;
    }
};
}
#endif
