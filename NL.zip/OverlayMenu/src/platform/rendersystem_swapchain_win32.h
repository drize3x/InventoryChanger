#pragma once
#if defined(_WIN32) || defined(MENU_STUDIO_SWAPCHAIN_TEST)
#include <windows.h>
#include "rendersystem_swapchain.h"
#include "win32_local_read.h"
namespace menu {
class RenderSystemDx11Swapchain {
    HMODULE renderer_ = nullptr, presentOwner_ = nullptr, resizeOwner_ = nullptr;
    RenderSystemSwapchainBindings bindings_;
    bool attempted_ = false, resolved_ = false;
    std::uintptr_t present_ = 0, resize_ = 0;
    std::string diagnostic_ = "waiting for rendersystemdx11.dll";
    static bool Bytes(std::uintptr_t at, void* out, std::size_t size) {
        return LocalReadBytes(at, out, size);
    }
    template <class T> static bool Read(std::uintptr_t at, T& value) {
        return Bytes(at, &value, sizeof(value));
    }
    static bool Executable(std::uintptr_t at) {
        MEMORY_BASIC_INFORMATION page{};
        return SwapchainUserRange(at, 1) &&
               VirtualQuery(reinterpret_cast<LPCVOID>(at), &page, sizeof(page)) == sizeof(page) &&
               page.State == MEM_COMMIT && !(page.Protect & (PAGE_GUARD | PAGE_NOACCESS)) &&
               (page.Protect & 0xf0);
    }
    static bool Pin(std::uintptr_t at, HMODULE& owner) {
        return Executable(at) &&
               GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS, reinterpret_cast<LPCWSTR>(at),
                                  &owner) &&
               owner;
    }

public:
    bool Resolve() {
        if (attempted_)
            return resolved_;
        auto renderer = GetModuleHandleW(L"rendersystemdx11.dll");
        if (!renderer)
            return false;
        if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS, reinterpret_cast<LPCWSTR>(renderer),
                                &renderer_)) {
            diagnostic_ = "cannot retain rendersystemdx11.dll";
            return false;
        }
        if (GetModuleHandleW(L"rendersystemdx11.dll") != renderer_) {
            FreeLibrary(renderer_);
            renderer_ = nullptr;
            diagnostic_ = "renderer changed while retaining module";
            return false;
        }
        attempted_ = true;
        WatermarkKdModule module;
        HudScanImage image;
        auto reader = [](std::uintptr_t at, auto& value) { return Read(at, value); };
        if (!WatermarkKdLoadModule(reader, reinterpret_cast<std::uintptr_t>(renderer_), module) ||
            !image.Load(module, Bytes)) {
            diagnostic_ = "invalid/unreadable loaded rendersystemdx11 PE";
            return false;
        }
        resolved_ = ResolveRenderSystemSwapchain(image, bindings_, diagnostic_);
        return resolved_;
    }
    bool Sample(RenderSystemChains& sample, const char*& reason) const {
        sample = {};
        if (!resolved_) {
            reason = "renderer bindings unavailable";
            return false;
        }
        return SampleRenderSystemChains([](std::uintptr_t at, auto& value) { return Read(at, value); },
                                        bindings_, sample, reason);
    }
    bool PinMethods(const RenderSystemChain& chain) {
        if (presentOwner_ || resizeOwner_)
            return chain.present == present_ && chain.resize == resize_;
        if (!RenderSystemChainCurrent([](std::uintptr_t at, auto& value) { return Read(at, value); },
                                      bindings_, chain, chain.chain))
            return false;
        if (!Pin(chain.present, presentOwner_))
            return false;
        if (!Pin(chain.resize, resizeOwner_)) {
            FreeLibrary(presentOwner_);
            presentOwner_ = nullptr;
            return false;
        }
        if (!RenderSystemChainCurrent([](std::uintptr_t at, auto& value) { return Read(at, value); },
                                      bindings_, chain, chain.chain)) {
            FreeLibrary(resizeOwner_);
            FreeLibrary(presentOwner_);
            resizeOwner_ = presentOwner_ = nullptr;
            return false;
        }
        present_ = chain.present;
        resize_ = chain.resize;
        return true;
    }
    bool Current(const RenderSystemChain& chain, std::uintptr_t callbackChain) const {
        return resolved_ && chain.present == present_ && chain.resize == resize_ &&
               RenderSystemChainCurrent([](std::uintptr_t at, auto& value) { return Read(at, value); },
                                        bindings_, chain, callbackChain);
    }
    const std::string& Diagnostic() const {
        return diagnostic_;
    }
    bool Unsupported() const {
        return attempted_ && !resolved_;
    }

    void ReleaseAfterHooks() {
        if (resizeOwner_) {
            FreeLibrary(resizeOwner_);
            resizeOwner_ = nullptr;
        }
        if (presentOwner_) {
            FreeLibrary(presentOwner_);
            presentOwner_ = nullptr;
        }
        if (renderer_) {
            FreeLibrary(renderer_);
            renderer_ = nullptr;
        }
        bindings_ = {};
        present_ = resize_ = 0;
        resolved_ = false;
        attempted_ = false;
    }
};
}
#endif