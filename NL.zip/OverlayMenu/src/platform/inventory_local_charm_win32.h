#pragma once

#include "menu_core.h"
#include "game_hud_win32.h"
#include "inventory_local_patterns.h"
#include "inventory_local_charm_core.h"
#include "inventory_local_weapons_core.h"
#include "inventory_knife_autoequip.h"
#include "inventory_autoequip.h"
#include <mutex>
#include <atomic>
#include <cstring>
#include <string>
#if defined(MENU_STUDIO_INVENTORY_TEST)
#define MS_CHARM_TRY try
#define MS_CHARM_EXCEPT catch (...)
#elif defined(_MSC_VER)
#define MS_CHARM_TRY __try
#define MS_CHARM_EXCEPT __except (EXCEPTION_EXECUTE_HANDLER)
#else
#error Requires MSVC SEH or the synthetic test shim
#endif
namespace menu {
class InventoryLocalCharm : private local_weapons::Adapter,
                            private knife_autoequip::Adapter,
                            private local_autoequip::Adapter {
#if defined(MENU_STUDIO_INVENTORY_TEST)
    friend struct InventoryLocalCharmTest;
#endif
    using Owner = local_charm::Owner;
    using Snapshot = local_charm::Snapshot;
    using Item = local_charm::Item;
    inline static InventoryLocalCharm* instance_ = nullptr;
    local_inventory_probe::Bindings b_{};
    std::uintptr_t managerVt_ = 0, inventoryVt_ = 0, cacheVt_ = 0, itemVt_ = 0, destructor_ = 0,
                   loadoutGetter_ = 0, itemViewVt_ = 0;
    local_charm::Controller controller_, stickerController_;
    local_weapons::Controller weapons_;
    knife_autoequip::Controller knifeEquip_;
    bool knifeSlotVerified_ = false;
    std::array<knife_autoequip::Desired, 2> knives_{};
    std::atomic<unsigned> knifeEquipStage_{0}, knifeEquipCount_{0};
    local_autoequip::Controller autoEquip_;
    std::vector<local_autoequip::Desired> autoWanted_;
    std::atomic<unsigned> autoEquipStage_{0}, autoEquipCount_{0}, autoEquipUnmatched_{0};
    std::atomic<int> gloveCtSlotCheck_{-1}, gloveTSlotCheck_{-1};
    ULONGLONG nextGloveSlotCheck_ = 0;
    bool autoStickerPending_ = true;
    ULONGLONG nextStickerTry_ = 0;
    std::atomic<unsigned> stickerRequest_{0}, stickerState_{0}, stickerHeld_{0}, charmHeld_{0};
    std::mutex wantedMutex_;
    std::vector<local_weapons::Spec> wanted_;
    ULONGLONG nextWeaponTick_ = 0;
    std::atomic<unsigned> weaponState_{0}, weaponCount_{0}, weaponWanted_{0}, weaponMissingPaint_{0},
        weaponFailureStage_{0};
    std::atomic<bool> ready_{false}, closing_{false}, ack_{false}, dispatched_{false};
    std::atomic<unsigned> createStage_{0}, createAttr_{0}, frameCount_{0};
    std::atomic<unsigned> request_{0}, state_{0};
    DWORD thread_ = 0;
    HMODULE seen_ = nullptr;

    std::string detail_ = "waiting for client.dll";
    static bool Bytes(std::uintptr_t p, void* out, std::size_t n) {
        SIZE_T got = 0;
        return p && ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(p), out, n, &got) &&
               got == n;
    }
    template <class T> static bool Read(std::uintptr_t p, T& v) {
        return Bytes(p, &v, sizeof v);
    }
    static bool Write(std::uintptr_t p, const void* v, std::size_t n) {
        MEMORY_BASIC_INFORMATION m{};
        if (!p || !v || !VirtualQuery(reinterpret_cast<LPCVOID>(p), &m, sizeof m) || m.State != MEM_COMMIT ||
            m.Protect & (PAGE_GUARD | PAGE_NOACCESS))
            return false;
        auto start = reinterpret_cast<std::uintptr_t>(m.BaseAddress);
        auto prot = m.Protect & 0xff;
        if (p < start || p - start > m.RegionSize || n > m.RegionSize - (p - start) ||
            !(prot == PAGE_READWRITE || prot == PAGE_WRITECOPY || prot == PAGE_EXECUTE_READWRITE ||
              prot == PAGE_EXECUTE_WRITECOPY))
            return false;
        MS_CHARM_TRY {
            std::memcpy(reinterpret_cast<void*>(p), v, n);
            return true;
        }
        MS_CHARM_EXCEPT {
            return false;
        }
    }
    template <class T> static bool Put(std::uintptr_t p, const T& v) {
        return Write(p, &v, sizeof v);
    }
    static bool Call0(std::uintptr_t fn, std::uintptr_t& result) {
        MS_CHARM_TRY {
            result = reinterpret_cast<std::uintptr_t(__fastcall*)()>(fn)();
            return true;
        }
        MS_CHARM_EXCEPT {
            result = 0;
            return false;
        }
    }
    static bool CallLoadout(std::uintptr_t fn, std::uintptr_t inv, int team, int slot,
                            std::uintptr_t& result) {
        result = 0;
        MS_CHARM_TRY {
            result = reinterpret_cast<std::uintptr_t(__fastcall*)(void*, int, int)>(fn)(
                reinterpret_cast<void*>(inv), team, slot);
            return result != 0;
        }
        MS_CHARM_EXCEPT {
            result = 0;
            return false;
        }
    }
    static bool CallThis(std::uintptr_t fn, std::uintptr_t p, std::uintptr_t& result) {
        MS_CHARM_TRY {
            result = reinterpret_cast<std::uintptr_t(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(p));
            return true;
        }
        MS_CHARM_EXCEPT {
            result = 0;
            return false;
        }
    }
    static bool CallFind(std::uintptr_t fn, std::uintptr_t p, int id, std::uintptr_t& result) {
        MS_CHARM_TRY {
            result =
                reinterpret_cast<std::uintptr_t(__fastcall*)(void*, int)>(fn)(reinterpret_cast<void*>(p), id);
            return true;
        }
        MS_CHARM_EXCEPT {
            result = 0;
            return false;
        }
    }
    static bool CallSet(std::uintptr_t fn, std::uintptr_t item, std::uintptr_t def, const void* value) {
        MS_CHARM_TRY {
            reinterpret_cast<void(__fastcall*)(void*, void*, const void*)>(fn)(
                reinterpret_cast<void*>(item), reinterpret_cast<void*>(def), value);
            return true;
        }
        MS_CHARM_EXCEPT {
            return false;
        }
    }
    static bool CallBool(std::uintptr_t fn, std::uintptr_t a, std::uintptr_t b, bool& result) {
        MS_CHARM_TRY {
            result = reinterpret_cast<bool(__fastcall*)(void*, void*)>(fn)(reinterpret_cast<void*>(a),
                                                                           reinterpret_cast<void*>(b));
            return true;
        }
        MS_CHARM_EXCEPT {
            return false;
        }
    }

    static bool CallRemove(std::uintptr_t fn, std::uintptr_t cache, std::uintptr_t item, bool& ok) {
        MS_CHARM_TRY {
            auto result = reinterpret_cast<std::uintptr_t(__fastcall*)(void*, void*)>(fn)(
                reinterpret_cast<void*>(cache), reinterpret_cast<void*>(item));
            ok = result == item;
            return true;
        }
        MS_CHARM_EXCEPT {
            ok = false;
            return false;
        }
    }
    static bool CallNotify(std::uintptr_t fn, std::uintptr_t inv, const Owner& owner, std::uintptr_t item) {
        MS_CHARM_TRY {
            reinterpret_cast<void(__fastcall*)(void*, const Owner*, void*, int)>(fn)(
                reinterpret_cast<void*>(inv), &owner, reinterpret_cast<void*>(item), 4);
            return true;
        }
        MS_CHARM_EXCEPT {
            return false;
        }
    }
    static bool CallDelete(std::uintptr_t fn, std::uintptr_t item) {
        MS_CHARM_TRY {
            reinterpret_cast<void(__fastcall*)(void*, bool)>(fn)(reinterpret_cast<void*>(item), true);
            return true;
        }
        MS_CHARM_EXCEPT {
            return false;
        }
    }
    bool Vt(std::uintptr_t object, std::uintptr_t vt) const {
        std::uintptr_t got = 0;
        return object && Read(object, got) && got == vt;
    }
    bool Function(std::uintptr_t vt, unsigned slot, std::uintptr_t& out) const {
        return Read(vt + slot * sizeof(std::uintptr_t), out) && out;
    }
    bool Capture(Snapshot& s) override {
        s = {};
        std::uintptr_t m = 0, fn = 0, inventory = 0, sc = 0, cache = 0;
        if (!Call0(b_.managerGetter, m) || !Vt(m, managerVt_) || !Function(managerVt_, 72, fn) ||
            !CallThis(fn, m, inventory) || !Vt(inventory, inventoryVt_) || !Read(inventory + 0x10, s.owner) ||
            !s.owner.id || !s.owner.type || !Read(inventory + 0x68, sc) || !sc ||
            !CallFind(b_.findItemCache, sc, 1, cache) || !Vt(cache, cacheVt_))
            return false;
        std::int32_t count = 0;
        std::uintptr_t list = 0;
        if (!Read(cache + 8, count) || count < 0 || count > 100000 || !Read(cache + 0x10, list) ||
            (count && !list))
            return false;
        s.objects.resize(std::size_t(count));
        if (count && !Bytes(list, s.objects.data(), std::size_t(count) * sizeof(std::uintptr_t)))
            return false;
        s.inventory = inventory;
        s.cache = cache;
        return true;
    }
    bool ItemInfo(std::uintptr_t p, Item& i) override {
        return Vt(p, itemVt_) && Read(p + 0x10, i.id) && Read(p + 0x2c, i.position);
    }
    std::uintptr_t Create(std::uint64_t id, std::uint32_t position, std::uint32_t account, int charm,
                          int seed) override {
        std::uintptr_t schema = 0, idDef = 0, seedDef = 0, p = 0;
        if (charm <= 0 || seed < 0 || !Call0(b_.schemaGetter, schema) || !schema ||
            !CallFind(b_.attributeLookup, schema, 299, idDef) || !idDef ||
            !CallFind(b_.attributeLookup, schema, 306, seedDef) || !seedDef || !Call0(b_.itemFactory, p) ||
            !Vt(p, itemVt_))
            return 0;
        const std::uint16_t definition = 1355, flags = std::uint16_t((4u << 5) | (3u << 11));
        const std::uint64_t original = 0;
        if (!Put(p + 0x10, id) || !Put(p + 0x18, original) || !Put(p + 0x28, account) ||
            !Put(p + 0x2c, position) || !Put(p + 0x30, definition) || !Put(p + 0x32, flags) ||
            !CallSet(b_.dynamicSetter, p, idDef, &charm) || !CallSet(b_.dynamicSetter, p, seedDef, &seed)) {
            CallDelete(destructor_, p);
            return 0;
        }
        return p;
    }

    std::uintptr_t CreateSticker(std::uint64_t id, std::uint32_t position, std::uint32_t account,
                                 int kit) override {
        std::uintptr_t schema = 0, kitDef = 0, p = 0;
        if (kit <= 0 || !Call0(b_.schemaGetter, schema) || !schema ||
            !CallFind(b_.attributeLookup, schema, 113, kitDef) || !kitDef || !Call0(b_.itemFactory, p) ||
            !Vt(p, itemVt_))
            return 0;
        const std::uint16_t definition = 1209, flags = std::uint16_t((4u << 5) | (3u << 11));
        const std::uint64_t original = 0;
        if (!Put(p + 0x10, id) || !Put(p + 0x18, original) || !Put(p + 0x28, account) ||
            !Put(p + 0x2c, position) || !Put(p + 0x30, definition) || !Put(p + 0x32, flags) ||
            !CallSet(b_.dynamicSetter, p, kitDef, &kit)) {
            CallDelete(destructor_, p);
            return 0;
        }
        return p;
    }
    std::uintptr_t CreateWeapon(std::uint64_t id, std::uint32_t position, std::uint32_t account,
                                const local_weapons::Spec& s) override {
        createStage_ = 1;
        createAttr_ = 0;
        if (s.definition <= 0 || s.definition > 65535 || s.paint < 0 || s.seed < 0 || s.seed > 1000 ||
            s.rarity < 1 || s.rarity > 7 || !std::isfinite(s.wear) || s.wear < 0.f || s.wear > 1.f ||
            !local_decorations::Valid(s.decorations))
            return 0;
        struct WriteAttr {
            int index;
            std::uint32_t bits;
        };
        std::vector<WriteAttr> attrs;
        auto integer = [&](int index, int v) { attrs.push_back({index, std::uint32_t(v)}); };
        auto real = [&](int index, float v) {
            std::uint32_t bits;
            std::memcpy(&bits, &v, sizeof bits);
            attrs.push_back({index, bits});
        };
        if (s.kind == local_weapons::Kind::Painted) {
            if (s.paint > 0) {
                real(6, float(s.paint));
                real(7, float(s.seed));
                real(8, s.wear);
            }
            if (s.statTrak >= 0) {
                integer(80, s.statTrak);
                integer(81, 0);
            }
            local_decorations::ForEachAttribute(s.decorations, integer, real);
        } else if (s.kind == local_weapons::Kind::Music) {
            if (s.definition != 1314 || s.paint <= 0)
                return 0;
            integer(166, s.paint);
        } else if (s.kind == local_weapons::Kind::Medal || s.kind == local_weapons::Kind::Agent) {
            if (s.paint != 0 || (s.kind == local_weapons::Kind::Agent && s.statTrak != -1))
                return 0;
        } else
            return 0;
        std::uintptr_t schema = 0, p = 0;
        createStage_ = 2;
        if (!Call0(b_.schemaGetter, schema) || !schema)
            return 0;
        createStage_ = 3;
        std::vector<std::uintptr_t> defs(attrs.size());
        for (std::size_t i = 0; i < attrs.size(); ++i) {
            createAttr_ = unsigned(attrs[i].index);
            if (!CallFind(b_.attributeLookup, schema, attrs[i].index, defs[i]) || !defs[i])
                return 0;
        }
        createAttr_ = 0;
        createStage_ = 4;
        if (!Call0(b_.itemFactory, p) || !Vt(p, itemVt_))
            return 0;
        const std::uint16_t definition = std::uint16_t(s.definition),
                            flags =
                                std::uint16_t(((unsigned(s.rarity) & 15u) << 11) |
                                              ((s.statTrak >= 0 ? 9u
                                                                : (s.kind == local_weapons::Kind::Painted &&
                                                                           (InventoryIsKnife(s.definition) ||
                                                                            InventoryIsGlove(s.definition))
                                                                       ? 3u
                                                                       : 4u))
                                               << 5) |
                                              (1u << 9));
        const std::uint64_t original = 0;
        createStage_ = 5;
        if (!Put(p + 0x10, id) || !Put(p + 0x18, original) || !Put(p + 0x28, account) ||
            !Put(p + 0x2c, position) || !Put(p + 0x30, definition) || !Put(p + 0x32, flags)) {
            CallDelete(destructor_, p);
            return 0;
        }
        createStage_ = 6;
        for (std::size_t i = 0; i < attrs.size(); ++i) {
            createAttr_ = unsigned(attrs[i].index);
            if (!CallSet(b_.dynamicSetter, p, defs[i], &attrs[i].bits)) {
                CallDelete(destructor_, p);
                return 0;
            }
        }
        createAttr_ = 0;
        createStage_ = 0;
        return p;
    }
    bool Add(std::uintptr_t cache, std::uintptr_t p, bool& ok) override {
        std::uintptr_t f = 0;
        return Vt(cache, cacheVt_) && Vt(p, itemVt_) && Function(cacheVt_, 1, f) && CallBool(f, cache, p, ok);
    }
    bool Notify(std::uintptr_t inv, const Owner& owner, std::uintptr_t p, bool created) override {
        std::uintptr_t f = 0;
        return Vt(inv, inventoryVt_) && Vt(p, itemVt_) && Function(inventoryVt_, created ? 0 : 2, f) &&
               CallNotify(f, inv, owner, p);
    }
    bool Remove(std::uintptr_t cache, std::uintptr_t p, bool& ok) override {
        std::uintptr_t f = 0;
        return Vt(cache, cacheVt_) && Vt(p, itemVt_) && Function(cacheVt_, 3, f) &&
               CallRemove(f, cache, p, ok);
    }
    bool Destroy(std::uintptr_t p) override {
        return Vt(p, itemVt_) && CallDelete(destructor_, p);
    }
    bool ReadSlot(std::uintptr_t inv, int team, knife_autoequip::Slot& out) override {
        if (!knifeSlotVerified_ || !Vt(inv, inventoryVt_) || (team != 2 && team != 3))
            return false;
        const auto p = inv + 0x90 + std::uintptr_t(team) * 58 * 16;
        return Read(p, out.id) && Read(p + 8, out.def);
    }
    bool WriteSlot(std::uintptr_t inv, int team, const knife_autoequip::Slot& value) override {
        if (!knifeSlotVerified_ || !Vt(inv, inventoryVt_) || (team != 2 && team != 3))
            return false;
        const auto p = inv + 0x90 + std::uintptr_t(team) * 58 * 16;

        unsigned char data[10]{};
        std::memcpy(data, &value.id, 8);
        std::memcpy(data + 8, &value.def, 2);
        return Write(p, data, sizeof data);
    }
    bool ItemDefinition(std::uintptr_t p, std::uint16_t& def) override {
        return Vt(p, itemVt_) && Read(p + 0x30, def);
    }
    bool ReadEquipSlot(std::uintptr_t inv, int team, int slot, local_autoequip::Slot& out) override {
        if (!knifeSlotVerified_ || !Vt(inv, inventoryVt_) || team < 0 || team > 3 || slot < 0 || slot >= 58)
            return false;
        const auto p = inv + 0x90 + (std::uintptr_t(team) * 58 + std::uintptr_t(slot)) * 16;
        return Read(p, out.id) && Read(p + 8, out.def);
    }
    bool ResolvedDefinition(std::uintptr_t inv, int team, int slot, std::uint16_t& def) override {
        def = 0;
        if (!knifeSlotVerified_ || !loadoutGetter_ || !itemViewVt_ || !Vt(inv, inventoryVt_) || team < 2 ||
            team > 3 || slot < 2 || slot > 37)
            return false;
        std::uintptr_t view = 0;
        return CallLoadout(loadoutGetter_, inv, team, slot, view) && Vt(view, itemViewVt_) &&
               Read(view + 0x1ba, def) && def != 0;
    }
    bool NativeLoadoutAvailable() const override {
        return knifeSlotVerified_ && loadoutGetter_ && itemViewVt_;
    }
    bool ResolvedIdentity(std::uintptr_t inv, int team, int slot, std::uint16_t& def,
                          std::uint64_t& id) override {
        def = 0;
        id = 0;
        if (!NativeLoadoutAvailable() || !Vt(inv, inventoryVt_) || team < 2 || team > 3 ||
            !((slot >= 2 && slot <= 18) || slot == 41))
            return false;
        std::uintptr_t view = 0;
        std::uint32_t high = 0, low = 0;
        if (!CallLoadout(loadoutGetter_, inv, team, slot, view) || !Vt(view, itemViewVt_) ||
            !Read(view + 0x1ba, def) || !Read(view + 0x1d0, high) || !Read(view + 0x1d4, low))
            return false;
        id = (std::uint64_t(high) << 32) | low;
        return true;
    }
    bool WriteEquipSlot(std::uintptr_t inv, int team, int slot, const local_autoequip::Slot& value) override {
        if (!knifeSlotVerified_ || !Vt(inv, inventoryVt_) || team < 0 || team > 3 || slot < 0 || slot >= 58)
            return false;
        const auto p = inv + 0x90 + (std::uintptr_t(team) * 58 + std::uintptr_t(slot)) * 16;
        unsigned char data[10]{};
        std::memcpy(data, &value.id, 8);
        std::memcpy(data + 8, &value.def, 2);
        return Write(p, data, sizeof data);
    }
    void Tick() {
        ++frameCount_;
        dispatched_ = true;
        if (!ready_.load(std::memory_order_acquire)) {
            if (closing_)
                ack_ = true;
            return;
        }
        auto t = GetCurrentThreadId();
        if (!thread_)
            thread_ = t;
        if (thread_ != t) {
            state_ = 5;
            return;
        }
        if (closing_) {
            auto r = controller_.Erase(*this);
            state_ = unsigned(r);
            auto sr = stickerController_.Erase(*this);
            stickerState_ = unsigned(sr);
            stickerHeld_ = stickerController_.Holding();
            charmHeld_ = controller_.Holding();

            if (!knifeEquip_.Before(*this, {}) || !autoEquip_.Before(*this, {})) {
                knifeEquipStage_ = knifeEquip_.Stage();
                knifeEquipCount_ = knifeEquip_.Count();
                autoEquipStage_ = autoEquip_.Stage();
                autoEquipCount_ = autoEquip_.Count();
                return;
            }
            knifeEquipStage_ = knifeEquip_.Stage();
            knifeEquipCount_ = knifeEquip_.Count();
            auto start = GetTickCount64();
            local_charm::Result w = local_charm::Result::Idle;
            for (unsigned n = 0; n < 8; ++n) {
                w = weapons_.Step(*this, {});
                if (w != local_charm::Result::Removed || GetTickCount64() - start >= 4)
                    break;
            }
            weaponState_ = unsigned(w);
            weaponCount_ = unsigned(weapons_.Size());
            weaponFailureStage_ = weapons_.FailureStage();
            if ((r == local_charm::Result::Removed || r == local_charm::Result::Idle) &&
                !controller_.Uncertain() &&
                (sr == local_charm::Result::Removed || sr == local_charm::Result::Idle) &&
                !stickerController_.Uncertain() && weapons_.Empty() && !weapons_.Uncertain())
                ack_ = true;
            return;
        }
        auto now = GetTickCount64();
        if (now >= nextWeaponTick_) {
            std::vector<local_weapons::Spec> copy;
            std::array<knife_autoequip::Desired, 2> knives;
            std::vector<local_autoequip::Desired> equips;
            {
                std::lock_guard<std::mutex> lock(wantedMutex_);
                copy = wanted_;
                knives = knives_;
                equips = autoWanted_;
            }
            auto w = local_charm::Result::Unavailable;
            if (knifeEquip_.Before(*this, knives) && autoEquip_.Before(*this, equips)) {
                w = weapons_.Step(*this, copy);
                if (!weapons_.Uncertain() && knifeSlotVerified_) {
                    knifeEquip_.After(*this, weapons_, knives);
                    autoEquip_.After(*this, weapons_, equips);
                }
            }
            autoEquipStage_ = knifeSlotVerified_ ? autoEquip_.Stage() : 100;
            autoEquipCount_ = autoEquip_.Count();
            autoEquipUnmatched_ = autoEquip_.Unmatched();
            if (now >= nextGloveSlotCheck_) {
                gloveCtSlotCheck_ = autoEquip_.GloveSlotCheck(*this, 3);
                gloveTSlotCheck_ = autoEquip_.GloveSlotCheck(*this, 2);
                nextGloveSlotCheck_ = now + 1000;
            }
            knifeEquipStage_ = knifeSlotVerified_ ? knifeEquip_.Stage() : 100;
            knifeEquipCount_ = knifeEquip_.Count();
            weaponState_ = unsigned(w);
            weaponCount_ = unsigned(weapons_.Size());
            weaponFailureStage_ = weapons_.FailureStage();
            nextWeaponTick_ = now + ((w == local_charm::Result::Unavailable ||
                                      w == local_charm::Result::Fault || w == local_charm::Result::Conflict)
                                         ? 1000
                                         : 100);
        }
        if (request_.exchange(0, std::memory_order_acq_rel)) {
            auto r = controller_.Holding() ? controller_.Erase(*this) : controller_.Insert(*this);
            state_ = unsigned(r);
            charmHeld_ = controller_.Holding();
        }
        const bool toggleSticker = stickerRequest_.exchange(0, std::memory_order_acq_rel) != 0;
        if (toggleSticker)
            autoStickerPending_ = false;
        if (toggleSticker || (autoStickerPending_ && now >= nextStickerTry_)) {
            const auto r = stickerController_.Holding() ? stickerController_.Erase(*this)
                                                        : stickerController_.InsertSticker(*this, 1);
            stickerState_ = unsigned(r);
            stickerHeld_ = stickerController_.Holding();
            nextStickerTry_ = now + 1000;
            if (r != local_charm::Result::Unavailable)
                autoStickerPending_ = false;
        }
    }
    static void Frame(void*, const HudResolvedBindings&) {
        if (instance_)
            try {
                instance_->Tick();
            } catch (...) {
                instance_->state_ = 5;
            }
    }

public:
    static bool GloveIdentity(int team, int def, int paint, int seed, float wear, std::uint64_t& id,
                              std::uint32_t& account) {
        auto* self = instance_;
        id = 0;
        account = 0;
        if (!self || !self->ready_.load() || self->closing_.load() || !self->thread_ ||
            self->thread_ != GetCurrentThreadId())
            return false;
        return self->autoEquip_.GloveIdentity(*self, team, def, paint, seed, wear, id, account);
    }

    static bool GloveFlags(int team, int def, int paint, int seed, float wear, std::uint64_t id,
                           std::uint32_t account, std::uint8_t& material, std::uint8_t& soc) {
        auto* self = instance_;
        std::uint64_t expected = 0;
        std::uint32_t owner = 0;
        if (!GloveIdentity(team, def, paint, seed, wear, expected, owner) || expected != id ||
            owner != account || !self->NativeLoadoutAvailable())
            return false;
        std::uintptr_t mgr = 0, fn = 0, inv = 0, view = 0;
        std::uint16_t actualDef = 0;
        std::uint32_t hi = 0, lo = 0;
        if (!Call0(self->b_.managerGetter, mgr) || !self->Vt(mgr, self->managerVt_) ||
            !self->Function(self->managerVt_, 72, fn) || !CallThis(fn, mgr, inv) ||
            !self->Vt(inv, self->inventoryVt_) || !CallLoadout(self->loadoutGetter_, inv, team, 41, view) ||
            !self->Vt(view, self->itemViewVt_) || !Read(view + 0x1ba, actualDef) || !Read(view + 0x1d0, hi) ||
            !Read(view + 0x1d4, lo) || actualDef != def || ((std::uint64_t(hi) << 32) | lo) != id ||
            !Read(view + 0x1b8, material) || !Read(view + 0x1e9, soc) || material > 1 || soc > 1)
            return false;
        return true;
    }
    void Attach(WatermarkNativeHud& hud) {
        instance_ = this;
        hud.SetLocalCharmFrameObserver(Frame);
    }
    void SubmitWeapons(std::vector<local_weapons::Spec> v, unsigned missingPaint,
                       std::array<knife_autoequip::Desired, 2> knives,
                       std::vector<local_autoequip::Desired> equips) {
        std::lock_guard<std::mutex> lock(wantedMutex_);
        weaponWanted_ = unsigned(v.size());
        weaponMissingPaint_ = missingPaint;
        wanted_ = std::move(v);
        knives_ = std::move(knives);
        autoWanted_ = std::move(equips);
    }
    std::string DebugSnapshot() const {
        return "ready=" + std::to_string(ready_.load()) +
               " dispatched=" + std::to_string(dispatched_.load()) +
               " closing=" + std::to_string(closing_.load()) + " ack=" + std::to_string(ack_.load()) +
               " frames=" + std::to_string(frameCount_.load()) +
               " state=" + std::to_string(weaponState_.load()) +
               " count=" + std::to_string(weaponCount_.load()) +
               " wanted=" + std::to_string(weaponWanted_.load()) +
               " knife-equip-count=" + std::to_string(knifeEquipCount_.load()) +
               " knife-equip-stage=" + std::to_string(knifeEquipStage_.load()) +
               " auto-equip-count=" + std::to_string(autoEquipCount_.load()) +
               " auto-equip-stage=" + std::to_string(autoEquipStage_.load()) +
               " auto-equip-native-view=" + std::to_string(loadoutGetter_ != 0) +
               " auto-equip-unmatched=" + std::to_string(autoEquipUnmatched_.load()) +
               " glove-slot-ct=" + std::to_string(gloveCtSlotCheck_.load()) +
               " glove-slot-t=" + std::to_string(gloveTSlotCheck_.load()) +
               " missing-paint=" + std::to_string(weaponMissingPaint_.load()) +
               " weapon-failure-stage=" + std::to_string(weaponFailureStage_.load()) +
               " create-stage=" + std::to_string(createStage_.load()) +
               " create-attr=" + std::to_string(createAttr_.load()) +
               " charm-state=" + std::to_string(state_.load()) +
               " charm-held=" + std::to_string(charmHeld_.load()) +
               " sticker-state=" + std::to_string(stickerState_.load()) +
               " sticker-held=" + std::to_string(stickerHeld_.load());
    }
    unsigned WeaponState() const {
        return weaponState_.load();
    }
    unsigned WeaponCount() const {
        return weaponCount_.load();
    }
    unsigned WeaponWanted() const {
        return weaponWanted_.load();
    }
    unsigned WeaponMissingPaint() const {
        return weaponMissingPaint_.load();
    }
    void Toggle() {
        if (ready_ && !closing_)
            request_ = 1;
    }
    void ToggleSticker() {
        if (ready_ && !closing_)
            stickerRequest_ = 1;
    }
    unsigned StickerState() const {
        return stickerState_.load();
    }
    unsigned State() const {
        return state_.load();
    }
    const std::string& Binding() const {
        return detail_;
    }
    void TryStart() {
        if (ready_ || closing_)
            return;
        auto c = GetModuleHandleW(L"client.dll");
        if (!c || c == seen_)
            return;
        seen_ = c;
        WatermarkKdModule mod;
        auto read = [](std::uintptr_t a, auto& v) { return Read(a, v); };
        HudScanImage image;
        if (!WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(c), mod) ||
            !image.Load(mod, [](std::uintptr_t a, void* p, std::size_t n) { return Bytes(a, p, n); })) {
            detail_ = "client snapshot failed";
            return;
        }
        if (!local_inventory_probe::Resolve(image, b_, detail_))
            return;
        auto i = image.Vtables(".?AVCEconItem@@"), v = image.Vtables(".?AVCCSPlayerInventory@@"),
             m = image.Vtables(".?AVCCSInventoryManager@@"),
             sc = image.Vtables(".?AVCGCClientSharedObjectTypeCache@GCSDK@@");
        if (i.size() != 1 || v.size() != 1 || m.size() != 1 || sc.size() != 1 ||
            image.Rip(b_.itemFactory + 19) != i[0]) {
            detail_ = "RTTI/factory mismatch";
            return;
        }
        itemVt_ = i[0];
        inventoryVt_ = v[0];
        managerVt_ = m[0];
        cacheVt_ = sc[0];
        std::uintptr_t type = 0, local = 0;
        unsigned char typeCode[6]{}, localCode[8]{}, dtorCode[6]{};
        std::uintptr_t add = 0, remove = 0, created = 0, destroyed = 0;
        if (!image.Read(itemVt_, destructor_) || !image.Read(itemVt_ + 8, type) ||
            !image.Bytes(type, typeCode, 6) || std::memcmp(typeCode, "\xb8\x01\x00\x00\x00\xc3", 6) ||
            !image.Read(managerVt_ + 72 * 8, local) || !image.Bytes(local, localCode, 8) ||
            std::memcmp(localCode, "\x48\x8b\x81\xd0\x28\x05\x00\xc3", 8) ||
            !image.Contains(destructor_, 1, 0x20000000, 0) || !image.Bytes(destructor_, dtorCode, 6) ||
            std::memcmp(dtorCode, "\x40\x57\x48\x83\xec\x20", 6) || image.Rip(destructor_ + 6) != itemVt_ ||
            !image.Read(cacheVt_ + 8, add) || !image.Read(cacheVt_ + 24, remove) ||
            !image.Read(inventoryVt_, created) || !image.Read(inventoryVt_ + 16, destroyed) ||
            !image.Contains(add, 1, 0x20000000, 0) || !image.Contains(remove, 1, 0x20000000, 0) ||
            !image.Contains(created, 1, 0x20000000, 0) || !image.Contains(destroyed, 1, 0x20000000, 0)) {
            detail_ = "unsupported method ABI";
            return;
        }

        unsigned char head[10]{}, jump = 0, workerHead[9]{}, workerReturn[3]{};
        std::uintptr_t worker = 0;
        if (!image.Bytes(remove, head, sizeof head) ||
            std::memcmp(head, "\x48\x89\x5c\x24\x10\x57\x48\x83\xec\x20", 10) ||
            !image.Bytes(remove + 0x7a, &jump, 1) || jump != 0xe9 ||
            (worker = image.Rip(remove + 0x7a, 1, 5)) == 0 ||
            !image.Bytes(worker, workerHead, sizeof workerHead) ||
            std::memcmp(workerHead, "\x40\x53\x55\x41\x54\x41\x57\x48\x83", 9) ||
            !image.Bytes(worker + 0x1ea, workerReturn, sizeof workerReturn) ||
            std::memcmp(workerReturn, "\x49\x8b\xc4", 3)) {
            detail_ = "unsupported cache remove pointer-return ABI";
            return;
        }

        auto getters =
            image.Find("40 55 48 83 EC 30 49 63 E8 83 FD 39 0F 87 ? ? ? ? 83 FA 03 0F 87 ? ? ? ? 48 89 74 24 "
                       "48 4C 89 64 24 58 4C 8D 25 ? ? ? ? 4C 89 7C 24 20 48 63 C2 4C 6B F8 3A 48 89 5C 24 "
                       "40 4C 03 FD 48 89 7C 24 50 4C 89 74 24 28 49 8D 77 09 48 C1 E6 04 48 03 F1 48 8B 16",
                       true, 2);
        std::uintptr_t getterVt = 0;
        knifeSlotVerified_ =
            getters.size() == 1 && image.Read(inventoryVt_ + 8 * 8, getterVt) && getterVt == getters[0];

        auto views = image.Vtables(".?AVC_EconItemView@@");
        if (knifeSlotVerified_ && views.size() == 1) {
            std::uintptr_t staticDef = 0, fn = 0, idFn = 0;
            unsigned char jump = 0, defCode[7]{}, idCode[20]{};
            if (image.Read(views[0] + 0x80, fn) && image.Bytes(fn, &jump, 1) && jump == 0xe9 &&
                (staticDef = image.Rip(fn, 1, 5)) && image.Bytes(staticDef + 0x90, defCode, 7) &&
                !std::memcmp(defCode, "\x0f\xb7\x96\xba\x01\x00\x00", 7) &&
                image.Read(views[0] + 18 * 8, idFn) && image.Bytes(idFn, idCode, 20) &&
                !std::memcmp(
                    idCode,
                    "\x8b\x81\xd0\x01\x00\x00\x8b\x89\xd4\x01\x00\x00\x48\xc1\xe0\x20\x48\x0b\xc1\xc3", 20)) {
                itemViewVt_ = views[0];
                loadoutGetter_ = getterVt;
            }
        }
        detail_ = knifeSlotVerified_
                      ? "inventory and knife loadout getter signatures matched; runtime not verified"
                      : "inventory matched; knife autoequip disabled: getter mismatch";
        ready_.store(true, std::memory_order_release);
    }
    bool Stop(DWORD timeout = 10000) {
        closing_ = true;
        if (!dispatched_)
            return true;
        auto until = GetTickCount64() + timeout;
        while (!ack_ && GetTickCount64() < until)
            Sleep(10);
        return ack_.load();
    }
};
}
#undef MS_CHARM_TRY
#undef MS_CHARM_EXCEPT
