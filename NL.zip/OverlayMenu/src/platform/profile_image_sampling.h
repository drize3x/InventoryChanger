#pragma once

inline void BuildProfileImageMips(ProfileImage& image) {
    image.mips.clear();
    if (image.width < 1 || image.height < 1 ||
        image.rgba.size() != std::size_t(image.width) * image.height * 4)
        return;
    const ProfileImageLevel* source = &image;
    while (source->width > 1 || source->height > 1) {
        ProfileImageLevel next;
        next.width = std::max(1, source->width / 2);
        next.height = std::max(1, source->height / 2);
        next.rgba.resize(std::size_t(next.width) * next.height * 4);
        for (int y = 0; y < next.height; ++y)
            for (int x = 0; x < next.width; ++x) {
                double x0 = double(x) * source->width / next.width,
                       x1 = double(x + 1) * source->width / next.width,
                       y0 = double(y) * source->height / next.height,
                       y1 = double(y + 1) * source->height / next.height;
                double rgba[4]{}, total = (x1 - x0) * (y1 - y0);
                for (int sy = int(y0); sy < int(std::ceil(y1)); ++sy)
                    for (int sx = int(x0); sx < int(std::ceil(x1)); ++sx) {
                        double w = std::max(0., std::min(x1, double(sx + 1)) - std::max(x0, double(sx))) *
                                   std::max(0., std::min(y1, double(sy + 1)) - std::max(y0, double(sy)));
                        const auto* p = source->rgba.data() + 4 * (std::size_t(sy) * source->width + sx);
                        double a = p[3] / 255.;
                        for (int k = 0; k < 3; ++k)
                            rgba[k] += p[k] * a * w;
                        rgba[3] += a * w;
                    }
                auto* p = next.rgba.data() + 4 * (std::size_t(y) * next.width + x);
                for (int k = 0; k < 3; ++k)
                    p[k] =
                        rgba[3] > 0
                            ? static_cast<unsigned char>(std::clamp(std::round(rgba[k] / rgba[3]), 0., 255.))
                            : 0;
                p[3] = static_cast<unsigned char>(std::clamp(std::round(rgba[3] / total * 255), 0., 255.));
            }
        image.mips.push_back(std::move(next));
        source = &image.mips.back();
    }
}
