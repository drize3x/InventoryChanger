#pragma once

#include <limits>
#include "game_hud_win32.h"
#include "win32_local_read.h"
#include "watermark_kd_schema.h"
#include "watermark_speed_delay.h"
#include "players_live_patterns.h"
#include "inventory_apply.h"
#include "inventory_knife_experiment.h"
#include "inventory_knife_skin.h"
#include "inventory_knife_skin_patterns.h"
#include "inventory_buy_hud_schedule.h"
#include "inventory_glove_plan.h"
#include "inventory_local_charm_win32.h"
#include "inventory_glove_bodygroup_patterns.h"
#include "inventory_glove_material_probe.h"
#include "inventory_glove_builder_patterns.h"
#include "inventory_weapon_inmatch.h"
#include "inventory_weapon_patterns.h"
#include "inventory_weapon_mesh.h"
#include "inventory_frost_patterns.h"
#include "inventory_frost_environment.h"
#include "inventory_frost_targets.h"
#if defined(_MSC_VER)
#include <intrin.h>
#endif
#include "inventory_weapon_hud.h"
#include <atomic>
#include <mutex>
#include <sstream>
#include <string>
#if defined(MENU_STUDIO_INVENTORY_TEST)
#define MENU_INVENTORY_TRY try
#define MENU_INVENTORY_EXCEPT catch (...)
#elif defined(_MSC_VER)
#define MENU_INVENTORY_TRY __try
#define MENU_INVENTORY_EXCEPT __except (EXCEPTION_EXECUTE_HANDLER)
#else
#error Inventory runtime needs MSVC SEH (or the synthetic test shim).
#endif
namespace menu {
namespace inventory_runtime {
inline constexpr ULONGLONG ConfigMaxAgeMs = 1000;
}
class InventoryNativeApply {
public:
    void NoteEnginePresent() {
        presentFrames_.fetch_add(1, std::memory_order_relaxed);
    }
    enum class Status { Waiting, Unsupported, Ready, Applied, Idle, Fault, Stopped };

private:
#if defined(MENU_STUDIO_INVENTORY_TEST)
    friend struct InventoryNativeApplyTest;
#endif
    inline static InventoryNativeApply* instance_ = nullptr;
    static bool Bytes(std::uintptr_t at, void* out, std::size_t n) {
        return LocalReadBytes(at, out, n);
    }
    template <class T> static bool Read(std::uintptr_t at, T& out) {
        return Bytes(at, &out, sizeof out);
    }
    static bool Code(std::uintptr_t at) {
        MEMORY_BASIC_INFORMATION m{};
        return at && VirtualQuery(reinterpret_cast<LPCVOID>(at), &m, sizeof m) && m.State == MEM_COMMIT &&
               !(m.Protect & (PAGE_GUARD | PAGE_NOACCESS)) && (m.Protect & 0xF0);
    }
    static bool Writable(std::uintptr_t at, std::size_t n) {
        MEMORY_BASIC_INFORMATION m{};
        if (!at || !VirtualQuery(reinterpret_cast<LPCVOID>(at), &m, sizeof m))
            return false;
        const auto base = reinterpret_cast<std::uintptr_t>(m.BaseAddress);
        return m.State == MEM_COMMIT && !(m.Protect & (PAGE_GUARD | PAGE_NOACCESS)) &&
               (m.Protect &
                (PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) &&
               at >= base && at - base < m.RegionSize && n <= m.RegionSize - (at - base);
    }
    static std::uintptr_t Virtual(void* p, unsigned slot) {
        std::uintptr_t v = 0, f = 0;
        return Read(reinterpret_cast<std::uintptr_t>(p), v) && v && Read(v + slot * 8, f) && Code(f) ? f : 0;
    }

    static bool FactoryCall(std::uintptr_t fn, const char* name, void*& out) {
        out = nullptr;
        MENU_INVENTORY_TRY {
            out = reinterpret_cast<void* (*)(const char*, int*)>(fn)(name, nullptr);
            return out != nullptr;
        }
        MENU_INVENTORY_EXCEPT {
            out = nullptr;
            return false;
        }
    }
    static bool ScopeCall(std::uintptr_t fn, void* system, void*& out) {
        out = nullptr;
        MENU_INVENTORY_TRY {
            out = reinterpret_cast<void* (*)(void*, const char*, void*)>(fn)(system, "client.dll", nullptr);
            return out != nullptr;
        }
        MENU_INVENTORY_EXCEPT {
            out = nullptr;
            return false;
        }
    }
    static bool ClassCall(std::uintptr_t fn, void* scope, const char* name, void*& out) {
        out = nullptr;
        MENU_INVENTORY_TRY {
            reinterpret_cast<void (*)(void*, void**, const char*)>(fn)(scope, &out, name);
            return out != nullptr;
        }
        MENU_INVENTORY_EXCEPT {
            out = nullptr;
            return false;
        }
    }

    static bool HudFindCall(std::uintptr_t fn, std::uintptr_t& out) {
        out = 0;
        MENU_INVENTORY_TRY {
            out = reinterpret_cast<std::uintptr_t(__fastcall*)(const char*)>(fn)("HudWeaponSelection");
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool HudClearCall(std::uintptr_t fn, std::uintptr_t hud, int index) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<std::int64_t(__fastcall*)(void*, int, std::int64_t)>(fn)(
                reinterpret_cast<void*>(hud), index, 0);
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool HudRefreshCall(std::uintptr_t fn, std::uintptr_t hud) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(hud));
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool SkinAllocate(std::uintptr_t fn, std::uintptr_t allocator, std::size_t size,
                             std::uintptr_t& result) {
        result = 0;
        MENU_INVENTORY_TRY {
            result = reinterpret_cast<std::uintptr_t(__fastcall*)(void*, std::size_t)>(fn)(
                reinterpret_cast<void*>(allocator), size);
            return result != 0;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool SkinFree(std::uintptr_t fn, std::uintptr_t allocator, std::uintptr_t p) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*, void*)>(fn)(reinterpret_cast<void*>(allocator),
                                                                  reinterpret_cast<void*>(p));
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool SkinContainerCall(std::uintptr_t fn, std::uintptr_t manager, std::uintptr_t& out) {
        out = 0;
        MENU_INVENTORY_TRY {
            out = reinterpret_cast<std::uintptr_t(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(manager));
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool SkinRefreshCalls(std::uintptr_t reset, std::uintptr_t paint, std::uintptr_t refresh,
                                 std::uintptr_t entity, std::uintptr_t view) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*, bool)>(reset)(reinterpret_cast<void*>(entity + 0x610),
                                                                    true);
            bool flag = reinterpret_cast<bool(__fastcall*)(void*)>(paint)(reinterpret_cast<void*>(view));
            reinterpret_cast<void(__fastcall*)(void*, void*, bool, bool, void*)>(refresh)(
                reinterpret_cast<void*>(entity), reinterpret_cast<void*>(view), false, flag, nullptr);
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool WeaponCharmCall(std::uintptr_t fn, std::uintptr_t entity, std::uintptr_t view) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*, void*, bool)>(fn)(reinterpret_cast<void*>(entity),
                                                                        reinterpret_cast<void*>(view), false);
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool MeshGroupCall(std::uintptr_t fn, std::uintptr_t node, std::uint64_t mask) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*, std::uint64_t)>(fn)(reinterpret_cast<void*>(node),
                                                                          mask);
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool GloveBodyGroupCall(std::uintptr_t fn, std::uintptr_t pawn) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*, const char*, unsigned)>(fn)(
                reinterpret_cast<void*>(pawn), "first_or_third_person", 1u);
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool GloveDefaultPredicateCall(std::uintptr_t fn, std::uintptr_t pawn, bool& out) {
        out = false;
        MENU_INVENTORY_TRY {
            out = reinterpret_cast<bool(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(pawn));
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool GloveHideDefaultCall(std::uintptr_t fn, std::uintptr_t pawn) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*, bool)>(fn)(reinterpret_cast<void*>(pawn), false);
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }

    static bool GloveModelCall(std::uintptr_t fn, std::uintptr_t pawn, std::uintptr_t& out) {
        out = 0;
        MENU_INVENTORY_TRY {
            auto* r = reinterpret_cast<std::uintptr_t*(__fastcall*)(void*, std::uintptr_t*)>(fn)(
                reinterpret_cast<void*>(pawn), &out);
            return r == &out;
        }
        MENU_INVENTORY_EXCEPT {
            out = 0;
            return false;
        }
    }
    static bool GlovePaintCall(std::uintptr_t fn, std::uintptr_t view, int& out) {
        out = -1;
        MENU_INVENTORY_TRY {
            out = reinterpret_cast<int(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(view));
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            out = -1;
            return false;
        }
    }
    static bool ClearItemDescriptionCall(std::uintptr_t fn, std::uintptr_t view) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(view));
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool ModelCall(std::uintptr_t fn, std::uintptr_t p, const char* name) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*, const char*)>(fn)(reinterpret_cast<void*>(p), name);
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    static bool SubclassCall(std::uintptr_t fn, std::uintptr_t p) {
        MENU_INVENTORY_TRY {
            reinterpret_cast<void(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(p));
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    struct ColorContext {
        inventory_color::Palette palette{};
        bool emitted = false;
        int def = 0, paint = 0;
    };
    inline static thread_local ColorContext* colorContext_ = nullptr;
    struct ColorScope {
        ColorContext* previous;
        explicit ColorScope(ColorContext& context) : previous(colorContext_) {
            colorContext_ = context.palette.mask ? &context : nullptr;
        }
        ~ColorScope() { colorContext_ = previous; }
    };
    struct Memory : knife_experiment::Adapter, knife_skin::Adapter {
        std::uintptr_t setModel = 0, updateSubclass = 0, hudFind = 0, hudClear = 0, hudRefresh = 0,
                       hudVtable = 0, hudSubVtable = 0, clearItemDescription = 0;
        std::atomic<unsigned> nameCacheClears{0}, nameCacheFailures{0};
        knife_skin::Bindings skinBindings{};
        knife_skin::Controller skin;
        inventory_color::Palette palette{};
        int paletteDef = 0, palettePaint = 0;
        std::uintptr_t allocator = 0, allocate = 0, free = 0;
        std::uint32_t listOffset = 0, attrOffset = 0;
        ULONGLONG skinTry = 0;
        int skinState = 1;
        std::atomic<int> skinCheck{0}, skinMatA{-1}, skinMatB{-1};
        std::uintptr_t Allocate(std::size_t n) override {
            std::uintptr_t p = 0;
            return SkinAllocate(allocate, allocator, n, p) ? p : 0;
        }
        bool Release(std::uintptr_t p) override {
            return SkinFree(free, allocator, p);
        }
        bool Ready(std::uintptr_t p, std::uintptr_t view) override {
            std::uintptr_t vt = 0, managerTable = 0, getter = 0, container = 0;
            std::int32_t n = 0, m = 0;
            skinCheck = 1;
            if (!skinBindings.knifeTable || !allocator || !allocate || !free || !listOffset || !attrOffset)
                return false;
            skinCheck = 2;
            if (view != p + 0x12e0 || !InventoryNativeApply::Read(p, vt) || vt != skinBindings.knifeTable)
                return false;
            skinCheck = 3;
            if (!InventoryNativeApply::Read(p + 0xab0, n) || !InventoryNativeApply::Read(p + 0xac8, m))
                return false;
            skinMatA = n;
            skinMatB = m;
            if (n < 0 || n > 256 || m < 0 || m > 256)
                return false;

            std::uintptr_t data = 0, last = 0;
            if (n && (!InventoryNativeApply::Read(p + 0xab8, data) || !data ||
                      !InventoryNativeApply::Read(data + std::uintptr_t(n - 1) * 8, last)))
                return false;
            if (m && (!InventoryNativeApply::Read(p + 0xad0, data) || !data ||
                      !InventoryNativeApply::Read(data + std::uintptr_t(m - 1) * 8, last)))
                return false;
            skinCheck = 4;
            if (!InventoryNativeApply::Read(p + 0x1268, managerTable) ||
                managerTable != skinBindings.hasAttributesTable ||
                !InventoryNativeApply::Read(managerTable + 24, getter) || !Code(getter) ||
                !SkinContainerCall(getter, p + 0x1268, container) || container != p + 0x1290)
                return false;
            skinCheck = 0;
            return true;
        }
        bool Refresh(std::uintptr_t p, std::uintptr_t view) override {
            return SkinRefreshCalls(skinBindings.releaseMaterials, skinBindings.hasPaint,
                                    skinBindings.refreshMaterials, p, view);
        }
        void SetPaintPalette(const inventory_color::Palette& p, int def, int paint) override {
            palette = p;
            paletteDef = def;
            palettePaint = paint;
        }
        int Skin(std::uintptr_t p, std::uintptr_t view, const InventoryWeaponTarget& t) override {
            const auto now = GetTickCount64();
            if (skinState && skinTry && now >= skinTry && now - skinTry < 1000)
                return skinState;
            skinTry = now;
            ColorContext context{palette, false, paletteDef, palettePaint};
            ColorScope scope(context);
            skinState = skin.Apply(*this, p, view, listOffset, attrOffset, t);
            return skinState;
        }
        bool RefreshPaintPalette(std::uintptr_t p, std::uintptr_t view) override {
            ColorContext context{palette, false, paletteDef, palettePaint};
            ColorScope scope(context);
            return skin.RefreshOwned(*this, p, view);
        }
        bool RestoreSkin(std::uintptr_t p, std::uintptr_t view) override {
            const bool ok = skin.Restore(*this, p, view);
            skinState = 1;
            skinTry = 0;
            return ok;
        }
        void RefreshRestored(std::uintptr_t p, std::uintptr_t view) override {
            if (Ready(p, view))
                Refresh(p, view);
        }
        void ForgetSkin() override {
            skin.Forget();
            skinState = 1;
            skinTry = 0;
        }
        bool ClearKnifeDescription(std::uint32_t handle, const InventoryOffsets& o) {
            if (!clearItemDescription || !skinBindings.knifeTable || o.attributeManager != 0x1290 ||
                o.item != 0x50 || !handle)
                return false;
            const auto p = Entity(handle);
            std::uintptr_t vt = 0;
            if (!p || !InventoryNativeApply::Read(p, vt) || vt != skinBindings.knifeTable)
                return false;
            const auto view = p + o.attributeManager + o.item;
            if (!ClearItemDescriptionCall(clearItemDescription, view)) {
                ++nameCacheFailures;
                return false;
            }
            ++nameCacheClears;
            return true;
        }
        bool RefreshIcon(std::uint32_t handle) {
            if (!hudFind || !hudClear || !hudRefresh || !hudVtable || !hudSubVtable || !handle)
                return false;
            std::uintptr_t sub = 0, base = 0, vt = 0, data = 0;
            std::int32_t count = 0;
            if (!HudFindCall(hudFind, sub) || sub < 0x98)
                return false;
            base = sub - 0x98;
            if (!InventoryNativeApply::Read(base, vt) || vt != hudVtable ||
                !InventoryNativeApply::Read(sub, vt) || vt != hudSubVtable ||
                !InventoryNativeApply::Read(base + 0x50, count) || count <= 0 || count > 64 ||
                !InventoryNativeApply::Read(base + 0x58, data) || !data)
                return false;
            const auto target = Entity(handle);
            if (!target)
                return false;
            for (int i = count - 1; i >= 0; --i) {
                std::uint32_t h = 0;
                if (!InventoryNativeApply::Read(data + std::uintptr_t(i) * 72 + 0x38, h))
                    return false;
                if (h && h != 0xffffffffu && Entity(h) == target) {
                    if (!HudClearCall(hudClear, base, i))
                        return false;
                    return HudRefreshCall(hudRefresh, base);
                }
            }
            return false;
        }
        bool Rebuild(std::uintptr_t p, const std::string& path) override {
            return setModel && ModelCall(setModel, p, path.c_str());
        }
        bool Subclass(std::uintptr_t p) override {
            return updateSubclass && SubclassCall(updateSubclass, p);
        }
        std::uintptr_t entities = 0;
        bool Read(std::uintptr_t at, void* out, std::size_t n) override {
            return LocalReadBytes(at, out, n);
        }
        bool Write(std::uintptr_t at, const void* in, std::size_t n) override {
            return Writable(at, n) && LocalWriteBytes(at, in, n);
        }
        std::uintptr_t Entity(std::uint32_t handle) override {
            auto read = [](std::uintptr_t a, auto& v) { return LocalReadBytes(a, &v, sizeof v); };
            auto e = WatermarkPawn(read, entities, handle);
            return e ? *e : 0;
        }
    };

    std::mutex mutex_;
    InventoryValues config_;
    knife_experiment::Plan knifePlan_;
    bool knifeEnabled_ = false;
    std::uint32_t subclassOffset_ = 0;
    knife_experiment::Controller knife_;
    knife_experiment::Stats knifeLast_{};
    bool enabled_ = false;
    ULONGLONG configAt_ = 0;
    std::atomic<Status> state_{Status::Waiting};
    std::atomic<bool> ready_{false}, closing_{false}, ack_{false}, dispatched_{false};
    InventoryOffsets offsets_{};
    LiveESPAddresses addresses_{};
    std::uint32_t localFlag_ = 0;
    InventoryApplier applier_;
    Memory memory_{};
    inline static thread_local unsigned previewScriptDepth_ = 0;
    using ColorAppendFn = int(__fastcall*)(void*, inventory_color::LooseVariable*);
    void* colorHook_ = nullptr;
    ColorAppendFn nextColor_ = nullptr;
    bool colorCreated_ = false;
    std::atomic<bool> colorEnabled_{false};
    std::atomic<bool> gloveColorVerified_{false};
    std::atomic<unsigned> colorActive_{0}, colorAppended_{0}, colorCalls_{0}, colorAllocationFailures_{0};
    std::atomic<unsigned> previewScriptCalls_{0}, previewScriptWear_{0};
    std::atomic<unsigned> colorVerified_{0}, colorFadeBuilds_{0}, colorFadeAppended_{0},
        colorFadeVerified_{0}, colorFadeMask_{0};
    std::atomic<int> colorLastDef_{0}, colorLastPaint_{0};
    std::atomic<unsigned> colorLastMask_{0};
    static bool IsWearInput(inventory_color::LooseVariable* in) {
        std::uintptr_t name = 0;
        std::int32_t type = 0;
        char text[15]{};
        auto p = reinterpret_cast<std::uintptr_t>(in);
        return p && Read(p, name) && Read(p + 0x40, type) && type == 5 && name &&
               Bytes(name, text, sizeof text) && std::memcmp(text, "g_flWearAmount", sizeof text) == 0;
    }

    static bool ColorEntryVerified(void* vector, int index, const char* expected, std::uint32_t color) {
        if (!vector || index < 0 || index >= 256)
            return false;
        auto v = reinterpret_cast<std::uintptr_t>(vector);
        std::int32_t count = 0, type = 0;
        std::uintptr_t data = 0, name = 0;
        std::uint32_t rgba = 0;
        char text[10]{};
        if (v > std::numeric_limits<std::uintptr_t>::max() - 8 || !Read(v, count) || count <= index ||
            count > 256 || !Read(v + 8, data) || !data)
            return false;
        auto offset = std::uintptr_t(index) * sizeof(inventory_color::LooseVariable);
        if (data > std::numeric_limits<std::uintptr_t>::max() - offset - 0x90)
            return false;
        auto entry = data + offset;
        return Read(entry, name) && name && Bytes(name, text, sizeof text) &&
               std::memcmp(text, expected, sizeof text) == 0 && Read(entry + 0x40, type) && type == 9 &&
               Read(entry + 0x8c, rgba) && rgba == color;
    }
    static int __fastcall OnColorAppend(void* vector, inventory_color::LooseVariable* input) {
        auto* self = instance_;
        if (!self || !self->nextColor_)
            return -1;
        self->colorActive_.fetch_add(1, std::memory_order_acq_rel);
        if (previewScriptDepth_ && IsWearInput(input))
            ++self->previewScriptWear_;
        auto* ctx = colorContext_;
        const bool inject = ctx && !ctx->emitted && ctx->palette.mask && vector && IsWearInput(input) &&
                            !self->closing_.load();
        if (inject)
            ctx->emitted = true;
        auto next = self->nextColor_;
        const int result = next(vector, input);
        if (inject) {
            ++self->colorCalls_;
            self->colorLastDef_ = ctx->def;
            self->colorLastPaint_ = ctx->paint;
            self->colorLastMask_ = ctx->palette.mask;
            const bool fade = ctx->def == 9 && ctx->paint == 1026;
            if (fade) {
                ++self->colorFadeBuilds_;
                self->colorFadeMask_ = ctx->palette.mask;
            }
            for (unsigned i = 0; i < 4; ++i)
                if (ctx->palette.mask & (1u << i)) {
                    char key[] = "g_vColor0";
                    key[8] = char('0' + i);
                    std::uintptr_t name = 0;
                    if (!SkinAllocate(self->memory_.allocate, self->memory_.allocator, sizeof key, name)) {
                        ++self->colorAllocationFailures_;
                        continue;
                    }
                    std::memcpy(reinterpret_cast<void*>(name), key, sizeof key);
                    inventory_color::LooseVariable var{};
                    var.name = reinterpret_cast<char*>(name);
                    var.type = 9;
                    var.color = ctx->palette.rgba[i];
                    const int index = next(vector, &var);
                    if (var.name)
                        SkinFree(self->memory_.free, self->memory_.allocator,
                                 reinterpret_cast<std::uintptr_t>(var.name));
                    else {
                        ++self->colorAppended_;
                        if (fade)
                            ++self->colorFadeAppended_;
                        if (ColorEntryVerified(vector, index, key, ctx->palette.rgba[i])) {
                            ++self->colorVerified_;
                            if (fade)
                                ++self->colorFadeVerified_;
                        }
                    }
                }
        }
        self->colorActive_.fetch_sub(1, std::memory_order_acq_rel);
        return result;
    }
    void InstallColorHook(const HudScanImage& image) {
        if (!memory_.allocate || !memory_.free || !memory_.allocator)
            return;
        auto p = inventory_color::ResolveAppend(image, memory_.skinBindings.refreshMaterials);
        if (!p || !Code(p))
            return;
        gloveColorVerified_ = inventory_color::GloveUsesAppend(image, glove_builder::Resolve(image), p);
        colorHook_ = reinterpret_cast<void*>(p);
        if (MH_CreateHook(colorHook_, reinterpret_cast<void*>(&OnColorAppend),
                          reinterpret_cast<void**>(&nextColor_)) != MH_OK) {
            colorHook_ = nullptr;
            return;
        }
        colorCreated_ = true;
        if (nextColor_ && MH_EnableHook(colorHook_) == MH_OK)
            colorEnabled_ = true;
    }
    bool StopColorHook(DWORD timeout) {
        if (!colorCreated_)
            return true;
        if (colorEnabled_) {
            auto r = MH_DisableHook(colorHook_);
            if (r != MH_OK && r != MH_ERROR_DISABLED)
                return false;
            colorEnabled_ = false;
        }
        auto end = GetTickCount64() + timeout;
        while (colorActive_.load() && GetTickCount64() < end)
            Sleep(1);
        if (colorActive_)
            return false;
        Sleep(50);
        if (colorActive_)
            return false;
        if (MH_RemoveHook(colorHook_) != MH_OK)
            return false;
        colorCreated_ = false;
        colorHook_ = nullptr;
        return true;
    }
    struct GunMemory : weapon_inmatch::Adapter, weapon_mesh::Adapter {
        Memory* m = nullptr;
        inventory_color::Palette palette{};
        int paletteDef = 0, palettePaint = 0;
        std::map<std::uint32_t, std::uintptr_t> hudChanges;
        std::map<int, weapon_inmatch::Tables> tables;
        weapon_mesh::Layout meshLayout{};
        weapon_mesh::Controller mesh;
        std::uintptr_t meshSetter = 0, charmUpdater = 0;
        std::uint32_t uiWeaponOffset = 0;
        std::atomic<unsigned> charmCalls{0}, charmFailures{0};
        std::atomic<int> charmBindStage{0};
        std::atomic<unsigned> charmSchemaDef{0}, charmSchemaSeed{0}, charmSchemaUI{0};
        std::atomic<unsigned> meshCalls{0}, meshFailures{0}, meshNodes{0};
        std::atomic<int> gunCheck{0};
        explicit GunMemory(Memory* p) : m(p) {}
        bool Read(std::uintptr_t p, void* o, std::size_t n) override {
            return m->Read(p, o, n);
        }
        bool Write(std::uintptr_t p, const void* i, std::size_t n) override {
            return m->Write(p, i, n);
        }
        std::uintptr_t Entity(std::uint32_t h) override {
            return m->Entity(h);
        }
        bool EntityMatches(std::uint32_t h, std::uintptr_t e) override {
            std::uintptr_t identity = 0;
            std::uint32_t raw = 0, flags = 0;
            if (!e || !h || h >= 0xfffffffeu || !Read(e + 0x10, &identity, sizeof identity) || !identity ||
                !Read(identity + 0x10, &raw, sizeof raw) || raw == 0xffffffffu ||
                !Read(identity + 0x30, &flags, sizeof flags))
                return false;
            return ((((raw >> 15) - (flags & 1u)) << 15) | (raw & 0x7fffu)) == h;
        }
        bool IsDropped(std::uint32_t h, std::uintptr_t e) override {
            std::uint32_t owner = 0;
            return meshLayout.ownerHandle && EntityMatches(h, e) &&
                   Read(e + meshLayout.ownerHandle, &owner, sizeof owner) &&
                   (owner == 0xffffffffu || owner == 0xfffffffeu);
        }
        std::uintptr_t Allocate(std::size_t n) override {
            return m->Allocate(n);
        }
        bool Release(std::uintptr_t p) override {
            return m->Release(p);
        }
        bool SetMesh(std::uintptr_t node, std::uint64_t mask) override {
            if (!meshSetter || !Code(meshSetter) || !Writable(node + 0x348, 8) ||
                !MeshGroupCall(meshSetter, node, mask)) {
                ++meshFailures;
                return false;
            }
            ++meshCalls;
            return true;
        }
        unsigned SetWeaponMesh(std::uintptr_t e, std::uintptr_t p, bool legacy) override {
            auto result = mesh.Tick(*this, meshLayout, e, p, legacy);
            meshNodes = result & 3u;
            return result;
        }
        void RestoreWeaponMesh(std::uintptr_t e, std::uintptr_t p) override {
            mesh.Restore(*this, meshLayout, e, p);
        }
        void ForgetWeaponMesh(std::uintptr_t e) override {
            mesh.Forget(e);
        }
        bool UpdateWeaponCharm(std::uintptr_t e, std::uintptr_t v) override {
            std::uint16_t d = 0;
            std::uint8_t ui = 0;
            if (!charmUpdater || uiWeaponOffset != 0x1b62 ||
                !InventoryNativeApply::Read(e + uiWeaponOffset, ui) || ui || !Code(charmUpdater) ||
                !InventoryNativeApply::Read(v + 0x1ba, d) || !GunReady(e, v, d) ||
                !WeaponCharmCall(charmUpdater, e, v)) {
                ++charmFailures;
                return false;
            }
            ++charmCalls;
            return true;
        }
        void WeaponHudChanged(std::uint32_t h, std::uintptr_t e, std::uintptr_t v) override {
            if (h && e && v == e + 0x12e0 && (hudChanges.size() < 64 || hudChanges.count(h)))
                hudChanges[h] = e;
        }
        bool GunReady(std::uintptr_t p, std::uintptr_t v, int def) override {
            std::uintptr_t vt = 0, mt = 0, fn = 0, container = 0, data = 0, last = 0;
            std::int32_t n = 0, k = 0;
            gunCheck = 1;
            if (!tables.count(def) || !m->allocator || !m->allocate || !m->free ||
                !m->skinBindings.refreshMaterials || v != p + 0x12e0)
                return false;
            gunCheck = 2;
            if (!InventoryNativeApply::Read(p, vt) || !InventoryNativeApply::Read(p + 0x1268, mt) ||
                !weapon_inmatch::MatchingGunPair(tables, def, vt, mt))
                return false;
            gunCheck = 3;
            if (!InventoryNativeApply::Read(mt + 24, fn) || !Code(fn) ||
                !SkinContainerCall(fn, p + 0x1268, container) || container != p + 0x1290)
                return false;
            gunCheck = 4;
            if (!InventoryNativeApply::Read(p + 0xab0, n) || !InventoryNativeApply::Read(p + 0xac8, k) ||
                n < 0 || k < 0 || n > 256 || k > 256)
                return false;
            if (n && (!InventoryNativeApply::Read(p + 0xab8, data) || !data ||
                      !InventoryNativeApply::Read(data + std::uintptr_t(n - 1) * 8, last)))
                return false;
            if (k && (!InventoryNativeApply::Read(p + 0xad0, data) || !data ||
                      !InventoryNativeApply::Read(data + std::uintptr_t(k - 1) * 8, last)))
                return false;
            gunCheck = 0;
            return true;
        }
        bool Ready(std::uintptr_t p, std::uintptr_t v) override {
            std::uint16_t d = 0;
            return InventoryNativeApply::Read(v + 0x1ba, d) && GunReady(p, v, d);
        }
        void SetPaintPalette(const inventory_color::Palette& p, int def, int paint) override {
            palette = p;
            paletteDef = def;
            palettePaint = paint;
        }
        bool Refresh(std::uintptr_t p, std::uintptr_t v) override {
            if (!Ready(p, v))
                return false;
            ColorContext context{palette, false, paletteDef, palettePaint};
            ColorScope scope(context);
            return m->Refresh(p, v);
        }
    };
    GunMemory gunMemory_{&memory_};
    weapon_hud::Queue gunHud_;
    std::atomic<unsigned> gunHudClears_{0}, gunHudSuccess_{0}, gunHudPending_{0};
    std::atomic<unsigned> gunTableCount_{0};
    weapon_inmatch::Controller guns_;
    weapon_inmatch::Plan gunPlan_;
    weapon_inmatch::Stats gunLast_{};

    struct GloveMemory : glove_inmatch::Adapter {
        Memory* memory = nullptr;
        glove_inmatch::Offsets offsets{};
        std::uintptr_t pawnVtable = 0, viewVtable = 0, paintGetter = 0, bodyGroup = 0, hideDefault = 0,
                       defaultPredicate = 0, modelGetter = 0;
        unsigned refreshRequests = 0, bodyCalls = 0, bodyFailures = 0, hideCalls = 0, hideFailures = 0;
        explicit GloveMemory(Memory* m) : memory(m) {}
        bool Read(std::uintptr_t p, void* out, std::size_t n) override {
            return InventoryNativeApply::Bytes(p, out, n);
        }
        bool Write(std::uintptr_t p, const void* in, std::size_t n) override {
            return Writable(p, n) && LocalWriteBytes(p, in, n);
        }
        std::uintptr_t Allocate(std::size_t n) override {
            return memory && memory->allocate ? memory->Allocate(n) : 0;
        }
        bool Release(std::uintptr_t p) override {
            return memory && memory->free && memory->Release(p);
        }
        bool Ready(std::uintptr_t p, std::uintptr_t v) override {
            std::uintptr_t vt = 0;
            return memory && memory->allocator && memory->allocate && memory->free && pawnVtable && p &&
                   v == p + offsets.view && InventoryNativeApply::Read(p, vt) && vt == pawnVtable &&
                   Writable(v + offsets.definition, 2) && Writable(v + offsets.quality, 4) &&
                   Writable(v + offsets.initialized, 1) &&
                   Writable(v + offsets.list + offsets.attributes, sizeof(knife_skin::Vector)) &&
                   Writable(p + offsets.reapply, 1);
        }
        bool EquippedIdentity(int team, const glove_inmatch::Choice& c,
                              glove_inmatch::Identity& out) override {
            return InventoryLocalCharm::GloveIdentity(team == InventoryCT ? 3 : 2, c.def,
                                                      c.hasFinish ? c.finish.paintKit : 0, c.finish.seed,
                                                      c.finish.wear, out.id, out.account);
        }
        bool EquippedFlags(int team, const glove_inmatch::Choice& c, glove_inmatch::Identity id,
                           std::uint8_t& material, std::uint8_t& soc) override {
            return InventoryLocalCharm::GloveFlags(team == InventoryCT ? 3 : 2, c.def,
                                                   c.hasFinish ? c.finish.paintKit : 0, c.finish.seed,
                                                   c.finish.wear, id.id, id.account, material, soc);
        }
        bool InvalidateDescription(std::uintptr_t p, std::uintptr_t v) override {
            std::uintptr_t vt = 0;
            return memory && memory->clearItemDescription && Code(memory->clearItemDescription) &&
                   viewVtable && Ready(p, v) && InventoryNativeApply::Read(v, vt) && vt == viewVtable &&
                   ClearItemDescriptionCall(memory->clearItemDescription, v);
        }

        bool PrepareAppearance(std::uintptr_t p, std::uintptr_t v) override {
            if (!bodyGroup || !Code(bodyGroup) || !Ready(p, v) || !GloveBodyGroupCall(bodyGroup, p)) {
                ++bodyFailures;
                return false;
            }
            ++bodyCalls;

            if (hideDefault && Code(hideDefault)) {
                if (!GloveHideDefaultCall(hideDefault, p)) {
                    ++hideFailures;
                    return false;
                }
                ++hideCalls;
            }
            return true;
        }
        bool Refresh(std::uintptr_t p, std::uintptr_t v) override {
            const std::uint8_t one = 1;
            if (!Ready(p, v) || !Write(p + offsets.reapply, &one, 1))
                return false;
            ++refreshRequests;
            return true;
        }
    };
    std::atomic<std::uint64_t> presentFrames_{0};
    unsigned materialProbeMatches_ = 0;
    std::uint32_t materialProbeOffset_ = 0;
    ULONGLONG materialProbeNext_ = 0;
    std::string materialProbeText_ = "unavailable";
    GloveMemory gloveMemory_{&memory_};
    glove_inmatch::Controller glove_;
    glove_inmatch::Plan glovePlan_{};
    std::uint32_t gloveHealth_ = 0;
    std::string gloveStage_ = "waiting";
    ULONGLONG glovePaintNext_ = 0;
    int gloveNativePaint_ = -1;
    std::uint32_t glovePaintHandle_ = 0;
    int glovePaintDef_ = -1, glovePaintChoice_ = -1;
    std::uint32_t lastKnifeNameHandle_ = 0;
    int lastKnifeNameSkin_ = 1;
    std::uint32_t hudPending_ = 0;
    ULONGLONG hudAttemptAt_ = 0;
    std::atomic<unsigned> hudSuccess_{0};
    std::uint32_t buyMenuOffset_ = 0;
    knife_buy_hud::Schedule buyHud_;
    std::atomic<unsigned> buyHudRefreshes_{0};
    std::atomic<DWORD> uiThread_{0};
    HMODULE seenClient_ = nullptr, seenSchema_ = nullptr;
    bool attempted_ = false;
    mutable std::mutex detailMutex_;
    std::string binding_ = "waiting for client.dll/schemasystem.dll";
    InventoryApplyStats last_{};
    std::atomic<unsigned long long> passes_{0}, writes_{0}, failures_{0}, stale_{0};
    void Fault() {
        ready_ = false;
        state_ = Status::Fault;
    }
    void SetBinding(std::string s) {
        std::lock_guard<std::mutex> lock(detailMutex_);
        binding_ = std::move(s);
    }
    std::uintptr_t Controller() {
        auto read = [](std::uintptr_t a, auto& v) { return LocalReadBytes(a, &v, sizeof v); };
        auto c = WatermarkKdLocalController(read, addresses_.entities, addresses_.local, localFlag_);
        return c.ok ? c.value : 0;
    }

    using FrostSetterFn = void(__fastcall*)(void*, std::uint32_t, const float*);
    void* frostHook_ = nullptr;
    FrostSetterFn nextFrost_ = nullptr;
    bool frostCreated_ = false;
    std::atomic<bool> frostEnabled_{false};
    std::atomic<unsigned> frostActive_{0}, frostCalls_{0}, frostApplied_{0}, frostItems_{0}, frostWorld_{0},
        frostHud_{0};
    std::atomic<int> frostLastStage_{0}, frostLastDetail_{0}, frostLastTeam_{-1}, frostLastDef_{0};
    inventory_frost::Bindings frostBindings_{};
    inventory_frost::SceneLayout frostLayout_{};

    static constexpr unsigned FrostDefLimit = 1024, FrostWords = FrostDefLimit / 64;
    static_assert(std::atomic<std::uint64_t>::is_always_lock_free, "frost requires lock-free 64-bit atomics");
    std::array<std::atomic<std::uint64_t>, 2 * FrostWords> frostBits_{};
    std::atomic<std::uint64_t> frostConfigAt_{0};

    using FrostUpdateFn = void(__fastcall*)(void*, void*, const float*);
    void* frostEnvironmentHook_ = nullptr;
    FrostUpdateFn nextFrostUpdate_ = nullptr;
    bool frostEnvironmentCreated_ = false;
    std::atomic<bool> frostEnvironmentEnabled_{false};
    std::atomic<unsigned> frostEnvironmentActive_{0}, frostEnvironmentSamples_{0},
        frostEnvironmentFailures_{0};
    std::atomic<std::uint32_t> frostEnvironmentBits_{0};
    std::atomic<std::uint64_t> frostEnvironmentAt_{0};
    std::atomic<int> frostEnvironmentSky_{-1};
    std::atomic_flag frostEnvironmentGuard_ = ATOMIC_FLAG_INIT;
    inventory_frost::Environment frostEnvironment_{};
    std::uintptr_t frostEnvironmentPawn_ = 0, frostSky_ = 0;
    static bool FrostSkyCall(std::uintptr_t fn, void* pawn, const float* pos, bool& out) {
        MENU_INVENTORY_TRY {
            out = reinterpret_cast<bool(__fastcall*)(void*, const float*)>(fn)(pawn, pos);
            return true;
        }
        MENU_INVENTORY_EXCEPT {
            return false;
        }
    }
    void FrostEnvironmentUpdate(void* state, void* object, const float* position) {
        if (closing_ || !ready_ || !state || !object || !position || !frostSky_)
            return;
        if (frostEnvironmentGuard_.test_and_set(std::memory_order_acquire))
            return;
        try {
            const auto now = GetTickCount64();
            const auto at = frostConfigAt_.load(std::memory_order_acquire);
            const auto controller = Controller();
            std::uint32_t handle = 0;
            std::uintptr_t pawn = 0;
            std::uint8_t team = 0;
            if (at && now >= at && now - at <= inventory_runtime::ConfigMaxAgeMs && controller &&
                Read(controller + offsets_.pawnHandle, handle) && handle && handle < 0xfffffffeu &&
                (pawn = memory_.Entity(handle)) && pawn == reinterpret_cast<std::uintptr_t>(object) &&
                reinterpret_cast<std::uintptr_t>(state) == pawn + 0x1720 &&
                Read(pawn + offsets_.team, team)) {
                const int side = team == 3 ? InventoryCT : team == 2 ? InventoryT : -1;
                bool any = false;
                if (side >= 0)
                    for (unsigned i = 0; i < FrostWords; ++i)
                        any |= frostBits_[std::size_t(side) * FrostWords + i].load(
                                   std::memory_order_relaxed) != 0;
                if (any && (frostEnvironment_.at == 0 || now < frostEnvironment_.at ||
                            now - frostEnvironment_.at >= 100)) {
                    float pos[3]{};
                    bool sky = false;
                    if (Bytes(reinterpret_cast<std::uintptr_t>(position), pos, sizeof pos) &&
                        std::isfinite(pos[0]) && std::isfinite(pos[1]) && std::isfinite(pos[2]) &&
                        FrostSkyCall(frostSky_, object, pos, sky)) {
                        if (frostEnvironmentPawn_ != pawn) {
                            frostEnvironment_ = {};
                            frostEnvironmentPawn_ = pawn;
                        }
                        if (frostEnvironment_.Step(sky, pos, now)) {
                            std::uint32_t bits = 0;
                            std::memcpy(&bits, &frostEnvironment_.level, 4);
                            frostEnvironmentBits_.store(bits, std::memory_order_release);
                            frostEnvironmentAt_.store(now, std::memory_order_release);
                            frostEnvironmentSky_ = sky ? 1 : 0;
                            ++frostEnvironmentSamples_;
                        }
                    } else
                        ++frostEnvironmentFailures_;
                }
            }
        } catch (...) {
            ++frostEnvironmentFailures_;
        }
        frostEnvironmentGuard_.clear(std::memory_order_release);
    }
    static void __fastcall OnFrostUpdate(void* state, void* object, const float* position) {
        auto* self = instance_;
        if (!self || !self->nextFrostUpdate_)
            return;
        self->frostEnvironmentActive_.fetch_add(1, std::memory_order_acq_rel);
        self->nextFrostUpdate_(state, object, position);
        self->FrostEnvironmentUpdate(state, object, position);
        self->frostEnvironmentActive_.fetch_sub(1, std::memory_order_acq_rel);
    }
    void InstallFrostEnvironment(const HudScanImage& client) {
        inventory_frost::EnvironmentBindings b;
        if (!inventory_frost::ResolveEnvironment(client, b) || !Code(b.update) || !Code(b.sky))
            return;
        frostSky_ = b.sky;
        frostEnvironmentHook_ = reinterpret_cast<void*>(b.update);
        if (MH_CreateHook(frostEnvironmentHook_, reinterpret_cast<void*>(&OnFrostUpdate),
                          reinterpret_cast<void**>(&nextFrostUpdate_)) != MH_OK) {
            frostEnvironmentHook_ = nullptr;
            frostSky_ = 0;
            return;
        }
        frostEnvironmentCreated_ = true;
        if (nextFrostUpdate_ && MH_EnableHook(frostEnvironmentHook_) == MH_OK)
            frostEnvironmentEnabled_ = true;
    }
    void PublishFrost(const InventoryValues& config, ULONGLONG now) {
        std::array<std::uint64_t, 2 * FrostWords> bits{};
        for (int side = 0; side < 2; ++side)
            for (const auto& team : config.teams)
                for (const auto& item : team.items) {
                    const int def = item.index;
                    if (def < 0 || def >= int(FrostDefLimit))
                        continue;
                    const auto* selected = InventoryResolveItem(config, side, def);
                    if (selected && selected->frost)
                        bits[std::size_t(side) * FrostWords + unsigned(def) / 64] |= std::uint64_t(1)
                                                                                     << (unsigned(def) % 64);
                }
        for (std::size_t i = 0; i < bits.size(); ++i)
            frostBits_[i].store(bits[i], std::memory_order_release);
        frostConfigAt_.store(now ? now : 1, std::memory_order_release);
    }
    bool FrostSelected(std::uintptr_t attrs) {
        const auto at = frostConfigAt_.load(std::memory_order_acquire);
        const auto now = GetTickCount64();
        if (!at || now < at || now - at > inventory_runtime::ConfigMaxAgeMs)
            return false;
        const auto controller = Controller();
        std::uint32_t ph = 0;
        std::uintptr_t pawn = 0, svc = 0, array = 0;
        std::uint8_t team = 0;
        std::int32_t count = 0;
        if (!controller || !Read(controller + offsets_.pawnHandle, ph) || !ph || ph >= 0xfffffffeu ||
            !(pawn = memory_.Entity(ph)) || !Read(pawn + offsets_.team, team) ||
            !Read(pawn + offsets_.weaponServices, svc) || !svc || !Read(svc + offsets_.myWeapons, count) ||
            count < 0 || count > 64 || !Read(svc + offsets_.myWeapons + 8, array) || (count && !array))
            return false;
        const int side = team == 3 ? InventoryCT : team == 2 ? InventoryT : -1;
        frostLastTeam_ = side;
        if (side < 0)
            return false;
        for (int i = 0; i < count; ++i) {
            std::uint32_t h = 0;
            std::uint16_t def = 0;
            if (!Read(array + std::uintptr_t(i) * 4, h) || !h || h >= 0xfffffffeu)
                continue;
            const auto weapon = memory_.Entity(h);
            if (!weapon || !gunMemory_.EntityMatches(h, weapon) ||
                !Read(weapon + offsets_.attributeManager + offsets_.item + offsets_.itemDefinition, def))
                continue;
            if (def >= FrostDefLimit ||
                !(frostBits_[std::size_t(side) * FrostWords + unsigned(def) / 64].load(
                      std::memory_order_acquire) &
                  (std::uint64_t(1) << (unsigned(def) % 64))))
                continue;
            ++frostItems_;
            frostLastDef_ = def;
            const auto targets = inventory_frost::Select(gunMemory_, frostLayout_, ph, h);
            frostLastStage_ = targets.stage;
            frostLastDetail_ = targets.detail;
            if (targets.worldFound)
                ++frostWorld_;
            if (targets.hudFound)
                ++frostHud_;
            if (std::find(targets.attributes.begin(), targets.attributes.end(), attrs) !=
                targets.attributes.end())
                return true;
        }
        return false;
    }
    void FrostDispatch(void* attrs, std::uint32_t key, const float* input, std::uintptr_t caller) {
        auto next = nextFrost_;
        if (!next)
            return;
        bool replace = false;
        float v[4]{};
        try {
            if (!closing_ && ready_ && attrs && input && key == 0xc7f65bacu &&
                (caller == frostBindings_.pawnSite + 52 || caller == frostBindings_.weaponSite + 50)) {
                ++frostCalls_;
                if (Bytes(reinterpret_cast<std::uintptr_t>(input), v, sizeof v) &&
                    FrostSelected(reinterpret_cast<std::uintptr_t>(attrs))) {
                    float level = 0.f;
                    const auto sampled = frostEnvironmentAt_.load(std::memory_order_acquire);
                    const auto now = GetTickCount64();
                    const auto bits = frostEnvironmentBits_.load(std::memory_order_acquire);
                    std::memcpy(&level, &bits, sizeof level);
                    level = inventory_frost::FreshLevel(level, sampled, now);
                    v[0] = level;
                    v[1] = level;
                    v[2] = 0.f;
                    v[3] = 0.f;
                    replace = true;
                    ++frostApplied_;
                }
            }
        } catch (...) {
            replace = false;
        }
        next(attrs, key, replace ? v : input);
    }
    static void __fastcall OnFrost(void* attrs, std::uint32_t key, const float* input) {
        auto* self = instance_;
        if (!self || !self->nextFrost_)
            return;
        self->frostActive_.fetch_add(1, std::memory_order_acq_rel);
#if defined(_MSC_VER)
        const auto caller = reinterpret_cast<std::uintptr_t>(_ReturnAddress());
#else
        const auto caller = reinterpret_cast<std::uintptr_t>(__builtin_return_address(0));
#endif
        self->FrostDispatch(attrs, key, input, caller);
        self->frostActive_.fetch_sub(1, std::memory_order_acq_rel);
    }
    void InstallFrostHook(const HudScanImage& client, void* scope, std::uint32_t render) {
        if (render != 0x338 || !gunMemory_.meshLayout.valid)
            return;
        inventory_frost::Bindings b;
        if (!inventory_frost::Resolve(client, b) || !Code(b.vectorSetter))
            return;
        auto scene = GetModuleHandleW(L"scenesystem.dll");
        WatermarkKdModule module;
        auto read = [](std::uintptr_t p, auto& v) { return Read(p, v); };
        if (!scene || !WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(scene), module))
            return;
        HudScanImage image;
        if (!image.Load(module, [](std::uintptr_t a, void* o, std::size_t n) { return Bytes(a, o, n); }))
            return;
        auto tables = image.Vtables(".?AVCSceneAnimatableObject@@");
        if (tables.size() != 1 || !scope)
            return;
        frostBindings_ = b;
        frostLayout_.mesh = gunMemory_.meshLayout;
        frostLayout_.render = render;
        frostLayout_.sceneObjectTable = tables[0];
        frostLayout_.valid = true;
        frostHook_ = reinterpret_cast<void*>(b.vectorSetter);
        if (MH_CreateHook(frostHook_, reinterpret_cast<void*>(&OnFrost),
                          reinterpret_cast<void**>(&nextFrost_)) != MH_OK) {
            frostHook_ = nullptr;
            frostLayout_.valid = false;
            return;
        }
        frostCreated_ = true;
        if (nextFrost_ && MH_EnableHook(frostHook_) == MH_OK) {
            frostEnabled_ = true;
            InstallFrostEnvironment(client);
        }
    }
    bool StopFrostHook(DWORD timeout) {
        if (frostEnvironmentCreated_) {
            if (frostEnvironmentEnabled_) {
                const auto r = MH_DisableHook(frostEnvironmentHook_);
                if (r != MH_OK && r != MH_ERROR_DISABLED)
                    return false;
                frostEnvironmentEnabled_ = false;
            }
            const auto end = GetTickCount64() + timeout;
            while (frostEnvironmentActive_.load() && GetTickCount64() < end)
                Sleep(1);
            if (frostEnvironmentActive_)
                return false;
            Sleep(50);
            if (frostEnvironmentActive_)
                return false;
            if (MH_RemoveHook(frostEnvironmentHook_) != MH_OK)
                return false;
            frostEnvironmentCreated_ = false;
        }
        if (!frostCreated_)
            return true;
        if (frostEnabled_) {
            const auto r = MH_DisableHook(frostHook_);
            if (r != MH_OK && r != MH_ERROR_DISABLED)
                return false;
            frostEnabled_ = false;
        }
        const auto end = GetTickCount64() + timeout;
        while (frostActive_.load() && GetTickCount64() < end)
            Sleep(1);
        if (frostActive_)
            return false;
        Sleep(50);
        if (frostActive_)
            return false;
        if (MH_RemoveHook(frostHook_) != MH_OK)
            return false;
        frostCreated_ = false;
        frostHook_ = nullptr;
        return true;
    }
    void Record(const InventoryApplyStats& s) {
        passes_ += 1;
        writes_ += s.writes;
        failures_ += s.failures;
        std::lock_guard<std::mutex> lock(detailMutex_);
        last_ = s;
    }
    void TickGloves(const glove_inmatch::Plan& plan, bool enabled, bool stageDriven = false) {
        const auto c = Controller();
        std::uint32_t ph = 0;
        std::uintptr_t pawn = 0;
        std::uint8_t team = 0;
        std::int32_t health = 0;

        if (!c || !Read(c + offsets_.pawnHandle, ph) || !ph || ph == 0xffffffffu ||
            !(pawn = memory_.Entity(ph)) || !Read(pawn + offsets_.team, team) || !gloveHealth_ ||
            !Read(pawn + gloveHealth_, health))
            return;
        if (health <= 0 || health > 200)
            enabled = false;
        const int side = team == 3 ? InventoryCT : team == 2 ? InventoryT : -1;
        const auto& o = gloveMemory_.offsets;
        std::uint8_t before = 0, after = 0, init = 0;
        std::uint16_t actual = 0;
        knife_skin::Vector attrs{};
        const bool beforeOK = o.reapply && Read(pawn + o.reapply, before);
        const auto now = GetTickCount64();

        std::uint32_t armsHandle = 0;
        std::uintptr_t armsNode = 0, arms = 0, vt = 0, owner = 0;
        const auto& ml = gunMemory_.meshLayout;
        if (ml.valid && Read(pawn + ml.arms, armsHandle) && armsHandle && armsHandle < 0xfffffffeu &&
            (arms = memory_.Entity(armsHandle)) && gunMemory_.EntityMatches(armsHandle, arms) &&
            Read(arms, vt) && vt == ml.armsTable && Read(arms + ml.scene, armsNode) && armsNode &&
            Read(armsNode + ml.nodeOwner, owner) && owner == arms) {
        } else {
            armsHandle = 0;
            armsNode = 0;
        }

        if (!materialProbeNext_ || now >= materialProbeNext_) {
            materialProbeNext_ = now + 1000;
            std::ostringstream mp;
            mp << "sig:" << materialProbeMatches_ << ",offset:" << materialProbeOffset_;
            auto inspect = [&](const char* label, std::uintptr_t object) {
                auto r = glove_material_probe::Inspect(
                    [](std::uintptr_t p, void* out, std::size_t n) { return Bytes(p, out, n); }, object,
                    materialProbeOffset_);
                mp << "," << label << ":" << r.state << "/" << r.count << "/" << r.magic16 << "/"
                   << r.magic20;
            };
            if (materialProbeOffset_ && armsHandle) {
                inspect("arms", arms);
                std::uintptr_t node = 0;
                std::set<std::uintptr_t> seen;
                if (Read(armsNode + ml.child, node))
                    for (unsigned i = 0; node && i < 32 && seen.insert(node).second; ++i) {
                        std::uintptr_t child = 0, childVt = 0, ownNode = 0, weapon = 0;
                        std::uint32_t h = 0;
                        if (Read(node + ml.nodeOwner, child) && child && Read(child, childVt) &&
                            childVt == ml.hudWeaponTable && Read(child + ml.scene, ownNode) &&
                            ownNode == node && Read(child + ml.ownerHandle, h) && h && h != 0xffffffffu &&
                            (weapon = memory_.Entity(h)) && gunMemory_.EntityMatches(h, weapon) &&
                            LocalGun(h, weapon) == 1) {
                            inspect("weapon", child);
                            break;
                        }
                        std::uintptr_t next = 0;
                        if (!Read(node + ml.next, next))
                            break;
                        node = next;
                    }
            }
            materialProbeText_ = mp.str();
        }
        const auto presentFrame = presentFrames_.load(std::memory_order_relaxed);
        glove_.Tick(gloveMemory_, o, ph, pawn, side, plan, enabled, now, armsHandle, armsNode,
                    stageDriven ? 0 : presentFrame);
        const bool afterOK = o.reapply && Read(pawn + o.reapply, after);
        const auto view = pawn + o.view;
        const bool viewOK = o.view && o.definition && o.initialized && o.list && o.attributes &&
                            Read(view + o.definition, actual) && Read(view + o.initialized, init) &&
                            Read(view + o.list + o.attributes, attrs);
        const int desiredDef = side >= 0 ? plan.side[std::size_t(side)].def : 0;
        const int desiredPaint = side >= 0 && plan.side[std::size_t(side)].hasFinish
                                     ? plan.side[std::size_t(side)].finish.paintKit
                                     : 0;
        if (glovePaintDef_ != desiredDef || glovePaintChoice_ != desiredPaint) {
            glovePaintDef_ = desiredDef;
            glovePaintChoice_ = desiredPaint;
            glovePaintNext_ = 0;
            gloveNativePaint_ = -1;
        }
        if (glovePaintHandle_ != ph) {
            glovePaintHandle_ = ph;
            glovePaintNext_ = 0;
            gloveNativePaint_ = -1;
        }
        if (!enabled || !viewOK || !init || !gloveMemory_.paintGetter || !gloveMemory_.viewVtable)
            gloveNativePaint_ = -1;
        else if (!glovePaintNext_ || now >= glovePaintNext_) {
            std::uintptr_t vt = 0;
            int paint = -1;
            gloveNativePaint_ = Read(view, vt) && vt == gloveMemory_.viewVtable &&
                                        GlovePaintCall(gloveMemory_.paintGetter, view, paint)
                                    ? paint
                                    : -1;
            glovePaintNext_ = now + 1000;
        }

        int identityLive = -1;
        if (enabled && side >= 0 && o.identity) {
            glove_inmatch::Identity expected{};
            std::uint64_t id = 0;
            std::uint32_t high = 0, low = 0, account = 0;
            if (gloveMemory_.EquippedIdentity(side, plan.side[std::size_t(side)], expected) &&
                Read(view + o.identity, id) && Read(view + o.identity + 8, high) &&
                Read(view + o.identity + 12, low) && Read(view + o.identity + 16, account))
                identityLive = (id == expected.id && high == std::uint32_t(expected.id >> 32) &&
                                low == std::uint32_t(expected.id) && account == expected.account)
                                   ? 1
                                   : 0;
        }
        std::uint32_t lowNowHandle = 0xffffffffu;
        int lowNow = -1;

        if (builderEnabled_ && o.view == 0x17a0 && o.reapply == 0x179d)
            lowNow = LowresState(pawn + 0x15f8, lowNowHandle);
        const auto& gd = glove_.Diag();
        std::ostringstream diag;
        diag << glove_.Stage() << " glove-side=" << side
             << " glove-want=" << (side >= 0 ? plan.side[std::size_t(side)].def : 0) << " glove-paint="
             << (side >= 0 && plan.side[std::size_t(side)].hasFinish
                     ? plan.side[std::size_t(side)].finish.paintKit
                     : 0)
             << " glove-native-paint=" << gloveNativePaint_ << " glove-actual=" << (viewOK ? int(actual) : -1)
             << " glove-init=" << (viewOK ? int(init) : -1)
             << " glove-attrs=" << (viewOK ? static_cast<long long>(attrs.count) : -1)
             << " glove-reapply=" << (beforeOK ? int(before) : -1) << "/" << (afterOK ? int(after) : -1)
             << " glove-refresh-policy=present-burst-experiment-v1"
             << " glove-material-probe=" << materialProbeText_
             << " glove-builder=" << (builderEnabled_ ? "hooked" : "fallback")
             << " glove-builder-calls=" << builderCalls_.load()
             << " glove-builder-consumed=" << builderConsumed_.load()
             << " glove-builder-wrong-thread=" << builderWrongThread_.load()
             << " glove-builder-faults=" << builderFaults_.load() << " glove-lowres-now=" << lowNow << "/"
             << lowNowHandle << " glove-lowres-post=" << lowresPost_.load() << "/team:" << lowresTeam_.load()
             << "/handles:" << lowresBeforeHandle_.load() << "-" << lowresAfterHandle_.load()
             << " glove-lowres-ct=" << lowresCTLive_.load() << "/" << lowresCTMissing_.load()
             << " glove-lowres-t=" << lowresTLive_.load() << "/" << lowresTMissing_.load()
             << " glove-frame-stage=" << (stageEnabled_ ? "hooked" : "hud-fallback")
             << " glove-stage-calls=" << stageCalls_.load()
             << " glove-stage-wrong-thread=" << stageWrongThread_.load()
             << " glove-stage-faults=" << stageFaults_.load() << " glove-present=" << presentFrame
             << " glove-present-gated=" << (glove_.RenderGated() ? 1 : 0)
             << " glove-pending-frames=" << glove_.PendingAppearanceFrames() << " glove-starts=" << gd.starts
             << " glove-restores=" << gd.restores << " glove-pawn-changes=" << gd.pawnChanges
             << " glove-team-changes=" << gd.teamChanges << " glove-choice-changes=" << gd.choiceChanges
             << " glove-disabled=" << gd.disabled << " glove-identity-changes=" << gd.identityChanges
             << " glove-field-def=" << gd.defResets << " glove-field-quality=" << gd.qualityResets
             << " glove-field-init=" << gd.initResets << " glove-flags=" << glove_.FlagStatus() << "/"
             << glove_.FlagMaterial() << "/" << glove_.FlagSOC()
             << " glove-description=" << glove_.DescriptionStatus()
             << " glove-identity-binding=" << (o.identity ? 1 : 0)
             << " glove-identity-held=" << (glove_.IdentityHeld() ? 1 : 0)
             << " glove-identity-live=" << identityLive << " glove-arms-valid=" << (armsHandle ? 1 : 0)
             << " glove-arms-changes=" << glove_.ArmsChanges()
             << " glove-refresh-requests=" << gloveMemory_.refreshRequests
             << " glove-bodygroup-policy=native-named-v1"
             << " glove-guard-binding=" << (gloveMemory_.defaultPredicate ? "matched" : "missing")
             << " glove-guard=" << gloveGuardChecks_.load() << "/" << gloveGuardTriggered_.load() << "/"
             << gloveGuardResolved_.load() << "/" << gloveGuardFailures_.load()
             << " glove-preserve-binding=" << (gloveMemory_.modelGetter ? "matched" : "missing")
             << " glove-delete-preserved=" << gloveDeletePreserved_.load()
             << " glove-hide-binding=" << (gloveMemory_.hideDefault ? "matched" : "missing")
             << " glove-hide-calls=" << gloveMemory_.hideCalls
             << " glove-hide-failures=" << gloveMemory_.hideFailures
             << " glove-bodygroup-binding=" << (gloveMemory_.bodyGroup ? "matched" : "missing")
             << " glove-bodygroup-calls=" << gloveMemory_.bodyCalls
             << " glove-bodygroup-failures=" << gloveMemory_.bodyFailures;
        {
            std::lock_guard<std::mutex> lock(detailMutex_);
            gloveStage_ = diag.str();
        }
    }

    int LocalGun(std::uint32_t h, std::uintptr_t expected) {
        auto c = Controller();
        std::uint32_t ph = 0;
        std::uintptr_t p = 0, svc = 0, arr = 0;
        int n = 0;
        if (!c || !Read(c + offsets_.pawnHandle, ph) || !ph || ph == 0xffffffffu ||
            !(p = memory_.Entity(ph)) || !Read(p + offsets_.weaponServices, svc) || !svc ||
            !Read(svc + offsets_.myWeapons, n) || n < 0 || n > 64 ||
            !Read(svc + offsets_.myWeapons + 8, arr) || (n && !arr))
            return -1;
        bool found = false;
        for (int i = 0; i < n; ++i) {
            std::uint32_t v = 0;
            if (!Read(arr + std::uintptr_t(i) * 4, v))
                return -1;
            if (v == h)
                found = true;
        }
        return found && memory_.Entity(h) == expected ? 1 : 0;
    }
    void TickGunHud(std::uint64_t now) {
        for (const auto& e : gunMemory_.hudChanges)
            gunHud_.Push(e.first, e.second, now);
        gunMemory_.hudChanges.clear();
        gunHud_.Pump(
            now, [this](std::uint32_t h, std::uintptr_t e) { return LocalGun(h, e); },
            [this](std::uint32_t h, std::uintptr_t e) {
                if (!memory_.clearItemDescription || offsets_.attributeManager != 0x1290 ||
                    offsets_.item != 0x50 || memory_.Entity(h) != e)
                    return false;
                const auto v = e + offsets_.attributeManager + offsets_.item;
                std::uint16_t def = 0;
                if (!Read(v + offsets_.itemDefinition, def) || !gunMemory_.GunReady(e, v, def) ||
                    !ClearItemDescriptionCall(memory_.clearItemDescription, v))
                    return false;
                ++gunHudClears_;
                return true;
            },
            [this](std::uint32_t h) {
                if (!memory_.RefreshIcon(h))
                    return false;
                ++gunHudSuccess_;
                return true;
            });
        gunHudPending_ = static_cast<unsigned>(gunHud_.Size());
    }

    using BuilderFn = void(__fastcall*)(void*);
    void* builderHook_ = nullptr;
    BuilderFn nextBuilder_ = nullptr;
    bool builderCreated_ = false;
    std::atomic<bool> builderEnabled_{false};
    std::atomic<unsigned> builderActive_{0}, builderCalls_{0}, builderWrongThread_{0}, builderFaults_{0},
        builderConsumed_{0};

    std::atomic<int> lowresPost_{-1}, lowresTeam_{-1};
    std::atomic<unsigned> gloveGuardChecks_{0}, gloveGuardTriggered_{0}, gloveGuardResolved_{0},
        gloveGuardFailures_{0}, gloveDeletePreserved_{0};
    std::atomic<std::uint32_t> lowresBeforeHandle_{0xffffffffu}, lowresAfterHandle_{0xffffffffu};
    std::atomic<unsigned> lowresCTLive_{0}, lowresCTMissing_{0}, lowresTLive_{0}, lowresTMissing_{0};
    int LowresState(std::uintptr_t component, std::uint32_t& h) {
        if (!Read(component, h))
            return -1;
        if (!h || h >= 0xfffffffeu)
            return 0;

        const auto ent = memory_.Entity(h);
        std::uintptr_t id = 0;
        std::uint32_t raw = 0;
        return ent && Read(ent + 0x10, id) && id && Read(id + 0x10, raw) && raw == h ? 1 : 2;
    }
    std::atomic<ULONGLONG> builderLastAt_{0};
    bool BuilderRecent(ULONGLONG now) const {
        const auto t = builderLastAt_.load(std::memory_order_acquire);
        return t && now >= t && now - t <= 500;
    }
    bool BeforeBuilder(void* component, ColorContext& color) {
        if (!ready_.load(std::memory_order_acquire) || closing_.load() || builderFaults_.load())
            return false;
        const auto ui = uiThread_.load(std::memory_order_acquire);
        if (!ui || ui != GetCurrentThreadId()) {
            if (ui)
                ++builderWrongThread_;
            return false;
        }
        const auto c = Controller();
        std::uint32_t handle = 0;
        std::uintptr_t pawn = 0, owner = 0;
        if (!c || !Read(c + offsets_.pawnHandle, handle) || !handle || handle == 0xffffffffu ||
            !(pawn = memory_.Entity(handle)) ||
            !Read(reinterpret_cast<std::uintptr_t>(component) + 0xb0, owner) ||
            !glove_builder::IsLocal(reinterpret_cast<std::uintptr_t>(component), pawn, owner))
            return false;
        glove_inmatch::Plan plan;
        ULONGLONG at = 0;
        {
            std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
            if (!lock.owns_lock())
                return false;
            plan = glovePlan_;
            at = configAt_;
        }
        const auto now = GetTickCount64();
        const bool fresh = at && now >= at && now - at <= inventory_runtime::ConfigMaxAgeMs;
        if (!BuilderRecent(now))
            glove_.RequestStageRefresh();
        TickGloves(plan, fresh, true);

        std::uint8_t reapply = 1;
        std::uint32_t h = 0xffffffffu;
        if (fresh && glove_.Holding() && gloveMemory_.defaultPredicate && gloveMemory_.hideDefault &&
            Code(gloveMemory_.defaultPredicate) && Code(gloveMemory_.hideDefault) &&
            Read(pawn + gloveMemory_.offsets.reapply, reapply) && reapply == 0 &&
            LowresState(reinterpret_cast<std::uintptr_t>(component), h) == 1) {
            bool isDefault = false;
            ++gloveGuardChecks_;
            if (!GloveDefaultPredicateCall(gloveMemory_.defaultPredicate, pawn, isDefault))
                ++gloveGuardFailures_;
            else if (isDefault) {
                ++gloveGuardTriggered_;
                bool after = true;
                if (!GloveHideDefaultCall(gloveMemory_.hideDefault, pawn) ||
                    !GloveDefaultPredicateCall(gloveMemory_.defaultPredicate, pawn, after))
                    ++gloveGuardFailures_;
                else if (!after)
                    ++gloveGuardResolved_;
            }
        }
        ++builderCalls_;
        builderLastAt_.store(now ? now : 1, std::memory_order_release);
        const bool applied = fresh && glove_.Holding() && std::strcmp(glove_.Stage(), "applied") == 0;
        std::uint8_t team = 0;
        if (applied && gloveColorVerified_ && Read(pawn + offsets_.team, team)) {
            const int side = team == 3 ? InventoryCT : team == 2 ? InventoryT : -1;
            if (side >= 0) {
                const auto& choice = glove_.AppliedChoice();
                if (choice.def == plan.side[std::size_t(side)].def && choice.hasFinish)
                    color = {choice.palette, false, choice.def, choice.finish.paintKit};
            }
        }
        return applied;
    }

    bool PreserveGloveDelete(std::uintptr_t component, std::uintptr_t pawn, bool eligible) {
        const auto getter = gloveMemory_.modelGetter, predicate = gloveMemory_.defaultPredicate;
        if (!eligible || !getter || !predicate || !Code(getter) || !Code(predicate))
            return false;
        std::uint8_t apply = 1, team = 0;
        std::int32_t health = 0;
        std::uint32_t handle = 0xffffffffu;
        if (!Read(pawn + offsets_.team, team) || (team != 2 && team != 3) || !gloveHealth_ ||
            !Read(pawn + gloveHealth_, health) || health <= 0 || health > 200 ||
            !Read(pawn + gloveMemory_.offsets.reapply, apply) || apply || LowresState(component, handle) != 1)
            return false;
        bool isDefault = false;
        std::uintptr_t current = 0, cached = 0;
        if (!GloveDefaultPredicateCall(predicate, pawn, isDefault) || !isDefault ||
            !GloveModelCall(getter, pawn, current) || !Read(component + 0xa8, cached))
            return false;
        if (!glove_builder::PreserveDeleteBranch(eligible, true, isDefault, apply != 0, current != 0,
                                                 current == cached))
            return false;
        ++gloveDeletePreserved_;
        return true;
    }
    static void __fastcall OnGloveBuilder(void* component) {
        auto* self = instance_;
        if (!self)
            return;
        self->builderActive_.fetch_add(1);

        static thread_local bool applying = false;
        bool entered = false, localApplied = false, eligible = false;
        ColorContext gloveColor{};
        std::uint8_t before = 0, after = 0;
        std::uintptr_t pawn = 0;
        std::uint32_t lowBefore = 0xffffffffu;
        if (!applying && !self->closing_.load()) {
            applying = true;
            entered = true;
            const auto count = self->builderCalls_.load();
            try {
                eligible = self->BeforeBuilder(component, gloveColor);
            } catch (...) {
                ++self->builderFaults_;
                self->builderLastAt_ = 0;
            }
            localApplied = self->builderCalls_.load() != count;
            if (localApplied && Read(reinterpret_cast<std::uintptr_t>(component) + 0xb0, pawn)) {
                Read(pawn + self->gloveMemory_.offsets.reapply, before);
                if (before == 1)
                    Read(reinterpret_cast<std::uintptr_t>(component), lowBefore);
            }
        }
        bool preserve = false;
        if (localApplied && pawn && !self->closing_.load())
            try {
                preserve =
                    self->PreserveGloveDelete(reinterpret_cast<std::uintptr_t>(component), pawn, eligible);
            } catch (...) {
                ++self->builderFaults_;
            }
        const auto next = self->nextBuilder_;
        if (next && !preserve) {
            ColorScope scope(gloveColor);
            next(component);
        }
        if (localApplied && pawn && Read(pawn + self->gloveMemory_.offsets.reapply, after) && before == 1 &&
            after == 0) {
            ++self->builderConsumed_;
            std::uint32_t lowAfter = 0xffffffffu;
            std::uint8_t team = 0;
            const int state = self->LowresState(reinterpret_cast<std::uintptr_t>(component), lowAfter);
            Read(pawn + self->offsets_.team, team);
            self->lowresTeam_ = team;
            self->lowresBeforeHandle_ = lowBefore;
            self->lowresAfterHandle_ = lowAfter;
            self->lowresPost_ = state;
            if (state >= 0) {
                if (team == 3) {
                    if (state == 1)
                        ++self->lowresCTLive_;
                    else
                        ++self->lowresCTMissing_;
                } else if (team == 2) {
                    if (state == 1)
                        ++self->lowresTLive_;
                    else
                        ++self->lowresTMissing_;
                }
            }
        }
        if (entered)
            applying = false;
        self->builderActive_.fetch_sub(1);
    }
    void InstallGloveBuilder(const HudScanImage& image) {
        if (!gloveMemory_.pawnVtable || gloveMemory_.offsets.view != 0x17a0 ||
            gloveMemory_.offsets.reapply != 0x179d)
            return;
        auto fn = glove_builder::Resolve(image);
        if (!fn || !Code(fn))
            return;
        builderHook_ = reinterpret_cast<void*>(fn);
        if (MH_CreateHook(builderHook_, reinterpret_cast<void*>(&OnGloveBuilder),
                          reinterpret_cast<void**>(&nextBuilder_)) != MH_OK) {
            builderHook_ = nullptr;
            return;
        }
        builderCreated_ = true;
        if (nextBuilder_ && MH_EnableHook(builderHook_) == MH_OK)
            builderEnabled_ = true;
    }
    bool StopGloveBuilder(DWORD timeout) {
        if (!builderCreated_)
            return true;
        if (builderEnabled_) {
            auto r = MH_DisableHook(builderHook_);
            if (r != MH_OK && r != MH_ERROR_DISABLED)
                return false;
            builderEnabled_ = false;
        }
        const auto end = GetTickCount64() + timeout;
        while (builderActive_.load() && GetTickCount64() < end)
            Sleep(1);
        if (builderActive_)
            return false;
        Sleep(50);
        if (builderActive_)
            return false;
        if (MH_RemoveHook(builderHook_) != MH_OK)
            return false;
        builderCreated_ = false;
        builderHook_ = nullptr;
        return true;
    }

    using StageFn = void(__fastcall*)(void*, int);
    void* stageHook_ = nullptr;
    StageFn nextStage_ = nullptr;
    bool stageCreated_ = false;
    std::atomic<bool> stageEnabled_{false};
    std::atomic<unsigned> stageActive_{0}, stageCalls_{0}, stageWrongThread_{0}, stageFaults_{0};
    std::atomic<ULONGLONG> stageLastAt_{0};
    bool StageRecent(ULONGLONG now) const {
        const auto t = stageLastAt_.load(std::memory_order_acquire);
        return t && now >= t && now - t <= 500;
    }
    void StageGloves() {
        if (!ready_.load(std::memory_order_acquire) || closing_.load() || stageFaults_.load())
            return;
        const auto ui = uiThread_.load(std::memory_order_acquire);
        if (!ui || ui != GetCurrentThreadId()) {
            if (ui)
                ++stageWrongThread_;
            return;
        }
        glove_inmatch::Plan plan;
        ULONGLONG at = 0;
        {
            std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
            if (!lock.owns_lock())
                return;
            plan = glovePlan_;
            at = configAt_;
        }
        const auto now = GetTickCount64();
        const bool fresh = at && now >= at && now - at <= inventory_runtime::ConfigMaxAgeMs;
        if (BuilderRecent(now))
            return;
        if (!StageRecent(now))
            glove_.RequestStageRefresh();
        TickGloves(plan, fresh, true);
        ++stageCalls_;
        stageLastAt_.store(now ? now : 1, std::memory_order_release);
    }
    static void __fastcall OnStage(void* object, int stage) {
        auto* self = instance_;
        if (!self)
            return;
        self->stageActive_.fetch_add(1);
        if (stage == 7 && !self->closing_.load())
            try {
                self->StageGloves();
            } catch (...) {
                ++self->stageFaults_;
                self->stageLastAt_ = 0;
            }
        const auto next = self->nextStage_;
        if (next)
            next(object, stage);
        self->stageActive_.fetch_sub(1);
    }
    void InstallGloveStage(const HudScanImage& image, HMODULE client) {

        const auto hits = image.Find("48 89 5C 24 ? 48 89 6C 24 ? 57 48 83 EC 40 48 8B F9 33 ED", true, 2);
        auto factory = reinterpret_cast<std::uintptr_t>(GetProcAddress(client, "CreateInterface"));
        void* iface = nullptr;
        if (hits.size() != 1 || !Code(factory) || !FactoryCall(factory, "Source2Client002", iface) ||
            Virtual(iface, 36) != hits[0] || !Code(hits[0]))
            return;
        stageHook_ = reinterpret_cast<void*>(hits[0]);
        if (MH_CreateHook(stageHook_, reinterpret_cast<void*>(&OnStage),
                          reinterpret_cast<void**>(&nextStage_)) != MH_OK) {
            stageHook_ = nullptr;
            return;
        }
        stageCreated_ = true;
        if (!nextStage_)
            return;
        if (MH_EnableHook(stageHook_) == MH_OK)
            stageEnabled_ = true;
    }
    bool StopGloveStage(DWORD timeout) {
        if (!stageCreated_)
            return true;
        if (stageEnabled_) {
            const auto r = MH_DisableHook(stageHook_);
            if (r != MH_OK && r != MH_ERROR_DISABLED)
                return false;
            stageEnabled_ = false;
        }
        const auto end = GetTickCount64() + timeout;
        while (stageActive_.load() && GetTickCount64() < end)
            Sleep(1);
        if (stageActive_)
            return false;
        Sleep(50);
        if (stageActive_)
            return false;
        if (MH_RemoveHook(stageHook_) != MH_OK)
            return false;
        stageCreated_ = false;
        stageHook_ = nullptr;
        return true;
    }
    void Tick() {
        dispatched_ = true;
        if (closing_ && ack_)
            return;
        if (!ready_.load(std::memory_order_acquire)) {
            if (closing_)
                ack_ = true;
            return;
        }
        const DWORD thread = GetCurrentThreadId();
        if (!uiThread_)
            uiThread_ = thread;
        if (uiThread_ != thread) {
            Fault();
            if (closing_)
                ack_ = true;
            return;
        }
        if (closing_) {
            auto gs = guns_.Tick(gunMemory_, offsets_, memory_.listOffset, memory_.attrOffset, Controller(),
                                 {}, false);
            {
                std::lock_guard<std::mutex> lock(detailMutex_);
                gunLast_ = gs;
            }
            if (guns_.Holding())
                return;
            TickGloves({}, false);
            if (glove_.Holding())
                return;
            auto ks = knife_.Tick(memory_, offsets_, subclassOffset_, Controller(), {}, false);
            {
                std::lock_guard<std::mutex> lock(detailMutex_);
                knifeLast_ = ks;
            }
            Record(applier_.RestoreAll(memory_, offsets_, Controller()));
            ready_ = false;
            state_ = Status::Stopped;
            ack_ = true;
            return;
        }
        InventoryValues config;
        knife_experiment::Plan plan;
        glove_inmatch::Plan glovePlan;
        weapon_inmatch::Plan gunPlan;
        bool enabled = false, knifeEnabled = false;
        ULONGLONG at = 0;
        {
            std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
            if (!lock.owns_lock())
                return;
            config = config_;
            enabled = enabled_;
            plan = knifePlan_;
            glovePlan = glovePlan_;
            gunPlan = gunPlan_;
            knifeEnabled = knifeEnabled_;
            at = configAt_;
        }
        const ULONGLONG now = GetTickCount64();

        if (!at || now < at || now - at > inventory_runtime::ConfigMaxAgeMs) {
            ++stale_;
            enabled = false;
            knifeEnabled = false;
        }
        const bool gloveEnabled = at && now >= at && now - at <= inventory_runtime::ConfigMaxAgeMs;
        if (!BuilderRecent(now) && !StageRecent(now))
            TickGloves(glovePlan, gloveEnabled);
        auto gunStats = guns_.Tick(gunMemory_, offsets_, memory_.listOffset, memory_.attrOffset, Controller(),
                                   gunPlan, gloveEnabled, now);
        {
            std::lock_guard<std::mutex> lock(detailMutex_);
            gunLast_ = gunStats;
        }
        TickGunHud(now);
        auto stats = applier_.Tick(memory_, offsets_, Controller(), config, enabled);
        Record(stats);
        auto ks = knife_.Tick(memory_, offsets_, subclassOffset_, Controller(), plan, knifeEnabled, now);

        if (ks.handle &&
            (ks.changes || (ks.skin == 0 && (lastKnifeNameHandle_ != ks.handle || lastKnifeNameSkin_ != 0))))
            memory_.ClearKnifeDescription(ks.handle, offsets_);
        lastKnifeNameHandle_ = ks.handle;
        lastKnifeNameSkin_ = ks.skin;

        std::uint32_t pawnHandle = 0;
        std::uintptr_t pawn = 0;
        std::uint8_t buyOpen = 0;
        const auto controller = Controller();
        const bool buyValid = buyMenuOffset_ && controller &&
                              Read(controller + offsets_.pawnHandle, pawnHandle) && pawnHandle &&
                              pawnHandle != 0xffffffffu && (pawn = memory_.Entity(pawnHandle)) &&
                              Read(pawn + buyMenuOffset_, buyOpen) && buyOpen <= 1;
        const auto buyRefresh =
            buyHud_.Tick(now, pawn, buyValid, buyOpen != 0,
                         knifeEnabled && ks.handle && std::strcmp(ks.stage, "applied") == 0, ks.handle);
        if (buyRefresh) {
            memory_.ClearKnifeDescription(buyRefresh, offsets_);
            hudPending_ = buyRefresh;
            hudAttemptAt_ = 0;
            ++buyHudRefreshes_;
        }
        if (ks.changes) {
            hudPending_ = ks.handle;
            hudAttemptAt_ = 0;
        }
        if (!knifeEnabled || !ks.handle || ks.handle != hudPending_)
            hudPending_ = 0;
        if (hudPending_ && (!hudAttemptAt_ || now - hudAttemptAt_ >= 1000)) {
            hudAttemptAt_ = now;
            if (memory_.RefreshIcon(hudPending_)) {
                hudPending_ = 0;
                ++hudSuccess_;
            }
        }
        {
            std::lock_guard<std::mutex> lock(detailMutex_);
            knifeLast_ = ks;
        }
        state_ = applier_.Holding() ? Status::Applied : Status::Idle;
    }
    static void Frame(void*, const HudResolvedBindings&) {
        auto self = instance_;
        if (!self)
            return;
        try {
            self->Tick();
        } catch (...) {
            self->Fault();
        }
    }

public:
    static void PreviewItemScriptProbe(bool enter) {
        auto* self = instance_;
        if (enter) {
            ++previewScriptDepth_;
            if (self)
                ++self->previewScriptCalls_;
        } else if (previewScriptDepth_)
            --previewScriptDepth_;
    }
    void Attach(WatermarkNativeHud& hud) {
        instance_ = this;
        hud.SetInventoryFrameObserver(Frame);
    }
    void TryStart() {
        if (ready_ || closing_ || state_ == Status::Fault)
            return;
        auto client = GetModuleHandleW(L"client.dll"), schema = GetModuleHandleW(L"schemasystem.dll");
        if (!client || !schema) {
            state_ = Status::Waiting;
            return;
        }
        if (attempted_ && seenClient_ == client && seenSchema_ == schema)
            return;
        attempted_ = true;
        seenClient_ = client;
        seenSchema_ = schema;
        state_ = Status::Unsupported;
        auto read = [](std::uintptr_t a, auto& v) { return Read(a, v); };
        WatermarkKdModule module;
        if (!WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(client), module)) {
            SetBinding("invalid client PE");
            return;
        }
        HudScanImage image;
        std::string diag;
        if (!image.Load(module,
                        [](std::uintptr_t a, void* out, std::size_t n) { return Bytes(a, out, n); }) ||
            !LiveESPResolve(image, addresses_, diag)) {
            SetBinding("entity list: " + diag);
            return;
        }
        {
            auto hits = image.Find(glove_material_probe::Pattern, true, 2);
            materialProbeMatches_ = static_cast<unsigned>(hits.size());
            std::uint32_t off = 0;
            if (hits.size() == 1 && image.Read(hits[0] + 15, off) && off >= 0x40 && off <= 0x2000 &&
                (off & 7) == 0)
                materialProbeOffset_ = off;
        }
        void* system = nullptr;
        void* scope = nullptr;
        auto factory = reinterpret_cast<std::uintptr_t>(GetProcAddress(schema, "CreateInterface"));
        if (!Code(factory) || !FactoryCall(factory, "SchemaSystem_001", system) || !Virtual(system, 13) ||
            !ScopeCall(Virtual(system, 13), system, scope) || !Virtual(scope, 2)) {
            SetBinding("client schema scope unavailable");
            return;
        }
        std::string missing;
        auto field = [&](const char* cls, const char* name, bool required) -> std::uint32_t {
            void* info = nullptr;
            if (ClassCall(Virtual(scope, 2), scope, cls, info)) {
                auto v = WatermarkKdSchemaField(read, reinterpret_cast<std::uintptr_t>(info), cls, name);
                if (v && *v)
                    return *v;
            }
            if (required) {
                if (!missing.empty())
                    missing += ", ";
                missing += std::string(cls) + "::" + name;
            }
            return 0;
        };

        const auto buyOffset = field("C_CSPlayerPawn", "m_bIsBuyMenuOpen", false);
        buyMenuOffset_ = (buyOffset == 0x15ea ? buyOffset : 0);
        InventoryOffsets o;
        localFlag_ = field("CBasePlayerController", "m_bIsLocalPlayerController", true);
        o.pawnHandle = field("CCSPlayerController", "m_hPlayerPawn", true);
        o.steamId = field("CBasePlayerController", "m_steamID", false);
        o.weaponServices = field("C_BasePlayerPawn", "m_pWeaponServices", true);
        o.myWeapons = field("CPlayer_WeaponServices", "m_hMyWeapons", true);
        o.team = field("C_BaseEntity", "m_iTeamNum", true);
        o.attributeManager = field("C_EconEntity", "m_AttributeManager", true);
        o.item = field("C_AttributeContainer", "m_Item", true);
        o.itemDefinition = field("C_EconItemView", "m_iItemDefinitionIndex", true);
        o.entityQuality = field("C_EconItemView", "m_iEntityQuality", false);
        o.itemIdHigh = field("C_EconItemView", "m_iItemIDHigh", false);
        o.accountId = field("C_EconItemView", "m_iAccountID", false);
        o.customName = field("C_EconItemView", "m_szCustomName", false);
        o.fallbackPaintKit = field("C_EconEntity", "m_nFallbackPaintKit", true);
        o.fallbackSeed = field("C_EconEntity", "m_nFallbackSeed", false);
        o.fallbackWear = field("C_EconEntity", "m_flFallbackWear", false);
        o.fallbackStatTrak = field("C_EconEntity", "m_nFallbackStatTrak", false);
        o.originalOwnerLow = field("C_EconEntity", "m_OriginalOwnerXuidLow", false);
        o.originalOwnerHigh = field("C_EconEntity", "m_OriginalOwnerXuidHigh", false);
        o.inventoryServices = field("CCSPlayerController", "m_pInventoryServices", false);
        o.musicId = field("CCSPlayerController_InventoryServices", "m_unMusicID", false);
        if (!missing.empty() || !localFlag_ || !o.Required()) {
            SetBinding("schema missing: " + (missing.empty() ? std::string("required field") : missing));
            return;
        }
        offsets_ = o;
        memory_.entities = addresses_.entities;

        auto sub = image.Find("4C 8B DC 53 48 81 EC 90 01 00 00 48 8B 41 10 48 8B D9 8B 50 30", true, 2);
        auto model = image.Find(
            "40 53 48 83 EC 20 48 8B D9 4C 8B C2 48 8B 0D ? ? ? ? 48 8D 54 24 40 48 8B 01 FF 50 60", true, 2);
        auto schemaSubclass = field("C_BaseEntity", "m_nSubclassID", false);
        unsigned char op[3]{};
        std::uint32_t codeOffset = 0;
        if (sub.size() == 1 && model.size() == 1 && image.Bytes(sub[0] + 0x32, op, 3) &&
            std::memcmp(op, "\x44\x8b\x83", 3) == 0 && image.Read(sub[0] + 0x35, codeOffset) &&
            schemaSubclass && schemaSubclass == codeOffset) {
            subclassOffset_ = schemaSubclass;
            memory_.setModel = model[0];
            memory_.updateSubclass = sub[0];
        }

        auto list = field("C_EconItemView", "m_AttributeList", false),
             attrs = field("CAttributeList", "m_Attributes", false);
        auto di = field("CEconItemAttribute", "m_iAttributeDefinitionIndex", false),
             value = field("CEconItemAttribute", "m_flValue", false),
             initial = field("CEconItemAttribute", "m_flInitialValue", false);
        knife_skin::Bindings paintBindings;
        auto tier = GetModuleHandleW(L"tier0.dll");
        auto slot = tier ? reinterpret_cast<std::uintptr_t>(GetProcAddress(tier, "g_pMemAlloc")) : 0;
        std::uintptr_t allocator = 0, allocatorTable = 0, alloc = 0, freer = 0;
        if (o.attributeManager == 0x1290 && o.item == 0x50 && list == 0x208 && attrs == 8 && di == 0x30 &&
            value == 0x34 && initial == 0x38 && knife_skin::Resolve(image, paintBindings) && slot &&
            Read(slot, allocator) && Read(allocator, allocatorTable) && Read(allocatorTable + 8, alloc) &&
            Read(allocatorTable + 24, freer) && Code(alloc) && Code(freer)) {
            memory_.skinBindings = paintBindings;
            memory_.listOffset = list;
            memory_.attrOffset = attrs;
            memory_.allocator = allocator;
            memory_.allocate = alloc;
            memory_.free = freer;
        }
        if (memory_.skinBindings.knifeTable && o.itemDefinition == 0x1ba) {
            gunMemory_.tables = weapon_inmatch::ResolveTables(image);
            gunTableCount_ = unsigned(gunMemory_.tables.size());
        }

        {
            auto charmDef = field("C_KeychainModule", "m_nKeychainDefID", false),
                 charmSeed = field("C_KeychainModule", "m_nKeychainSeed", false),
                 uiWeapon = field("C_CSWeaponBase", "m_bUIWeapon", false);
            gunMemory_.charmSchemaDef = charmDef;
            gunMemory_.charmSchemaSeed = charmSeed;
            gunMemory_.charmSchemaUI = uiWeapon;
            gunMemory_.charmBindStage = charmDef != 0x1270    ? 1
                                        : charmSeed != 0x1274 ? 2
                                        : uiWeapon != 0x1b62  ? 3
                                                              : 4;
            if (gunMemory_.charmBindStage == 4) {
                gunMemory_.uiWeaponOffset = 0x1b62;
                gunMemory_.charmUpdater = weapon_inmatch::ResolveCharmUpdater(image);
                if (gunMemory_.charmUpdater)
                    gunMemory_.charmBindStage = 5;
            }
        }

        {
            weapon_mesh::Layout m;
            m.scene = field("C_BaseEntity", "m_pGameSceneNode", false);
            m.arms = field("C_CSPlayerPawn", "m_hHudModelArms", false);
            m.ownerHandle = field("C_BaseEntity", "m_hOwnerEntity", false);
            m.nodeOwner = field("CGameSceneNode", "m_pOwner", false);
            m.child = field("CGameSceneNode", "m_pChild", false);
            m.next = field("CGameSceneNode", "m_pNextSibling", false);
            m.model = field("CSkeletonInstance", "m_modelState", false);
            m.mask = field("CModelState", "m_MeshGroupMask", false);
            auto arms = image.Vtables(".?AVC_CS2HudModelArms@@"),
                 hud = image.Vtables(".?AVC_CS2HudModelWeapon@@"),
                 sk = image.Vtables(".?AVCSkeletonInstance@@"),
                 network =
                     image.Vtables(".?AVNetworkVar_m_skeletonInstance@CBodyComponentSkeletonInstance@@");
            auto fn = weapon_inmatch::ResolveMeshSetter(image);
            if (m.scene && m.arms && m.ownerHandle && m.nodeOwner == 0x30 && m.child && m.next &&
                m.model == 0x140 && m.mask == 0x208 && arms.size() == 1 && hud.size() == 1 &&
                sk.size() == 1 && network.size() == 1 && fn && Code(fn)) {
                m.armsTable = arms[0];
                m.hudWeaponTable = hud[0];
                m.skeletonBaseTable = sk[0];
                m.skeletonTable = network[0];
                m.valid = true;
                gunMemory_.meshSetter = fn;
                gunMemory_.meshLayout = m;
            }
        }

        const auto gloves = field("C_CSPlayerPawn", "m_EconGloves", false),
                   reapply = field("C_CSPlayerPawn", "m_bNeedToReApplyGloves", false);
        const auto init = field("C_EconItemView", "m_bInitialized", false),
                   health = field("C_BaseEntity", "m_iHealth", false);
        const auto pawnTables = image.Vtables(".?AVC_CSPlayerPawn@@");
        if (gloves == 0x17a0 && reapply == 0x179d && o.itemDefinition == 0x1ba && o.entityQuality == 0x1bc &&
            init == 0x1e8 && list == 0x208 && attrs == 8 && health && pawnTables.size() == 1) {
            gloveMemory_.offsets = {gloves, reapply, o.itemDefinition, o.entityQuality, init, list, attrs};
            if (field("C_EconItemView", "m_iItemID", false) == 0x1c8 && o.itemIdHigh == 0x1d0 &&
                field("C_EconItemView", "m_iItemIDLow", false) == 0x1d4 && o.accountId == 0x1d8)
                gloveMemory_.offsets.identity = 0x1c8;
            gloveMemory_.pawnVtable = pawnTables[0];
            gloveHealth_ = health;

            if (field("C_EconItemView", "m_bRestoreCustomMaterialAfterPrecache", false) == 0x1b8 &&
                field("C_EconItemView", "m_bDisallowSOC", false) == 0x1e9) {
                gloveMemory_.offsets.restoreMaterial = 0x1b8;
                gloveMemory_.offsets.disallowSOC = 0x1e9;
            }
            gloveMemory_.bodyGroup = glove_inmatch::ResolveBodyGroup(image);
            gloveMemory_.hideDefault = glove_builder::ResolveHideDefault(image);
            gloveMemory_.defaultPredicate = glove_builder::ResolveDefaultPredicate(image);
            gloveMemory_.modelGetter = glove_builder::ResolveModelGetterForPreserve(image);

            auto viewTables = image.Vtables(".?AVC_EconItemView@@");
            auto gloveTables = image.Vtables(".?AVNetworkVar_m_EconGloves@C_CSPlayerPawn@@");
            std::uintptr_t paintFn = 0, gloveFn = 0;
            unsigned char head[10]{};
            if (viewTables.size() == 1 && gloveTables.size() == 1 &&
                image.Read(viewTables[0] + 3 * 8, paintFn) && image.Read(gloveTables[0] + 3 * 8, gloveFn) &&
                paintFn == gloveFn && image.Bytes(paintFn, head, 10) &&
                !std::memcmp(head, "\x48\x89\x5c\x24\x08\x57\x48\x83\xec\x40", 10) && Code(paintFn)) {
                gloveMemory_.viewVtable = gloveTables[0];
                gloveMemory_.paintGetter = paintFn;
            }
        }

        auto descClear = image.Find(
            "48 89 5C 24 10 48 89 74 24 18 57 48 83 EC 20 48 8D B9 00 02 00 00 48 8B F1 48 8B 1F 48 85 DB",
            true, 2);
        if (descClear.size() == 1)
            memory_.clearItemDescription = descClear[0];

        auto hf = image.Find(
            "40 53 48 83 EC 20 48 8B 05 ? ? ? ? 48 8B D9 48 85 C0 74 ? 48 89 5C 24 ? 48 8D 88 58 02 00 00",
            true, 2);
        auto hc = image.Find("4C 8B DC 55 57 48 83 EC 48 48 63 41 68 48 8B F9 48 63 EA 49 89 5B 08 48 8B DD "
                             "49 89 73 10 48 8B 71 58",
                             true, 2);
        auto hr = image.Find(
            "48 89 5C 24 10 57 48 83 EC 30 33 FF 48 8B D9 39 79 38 0F 8E ? ? ? ? 48 89 74 24 40 33 F6", true,
            2);
        auto hv = image.Vtables(".?AVCCSGO_HudWeaponSelection@@"),
             hsv = image.Vtables(".?AVCCSGO_HudWeaponSelection@@", 0x98);
        if (hf.size() == 1 && hc.size() == 1 && hr.size() == 1 && hv.size() == 1 && hsv.size() == 1) {
            memory_.hudFind = hf[0];
            memory_.hudClear = hc[0];
            memory_.hudRefresh = hr[0];
            memory_.hudVtable = hv[0];
            memory_.hudSubVtable = hsv[0];
        }
        std::ostringstream s;
        s << "bound: " << diag << "; optional=" << (o.itemIdHigh ? "id " : "")
          << (o.accountId ? "account " : "") << (o.entityQuality ? "quality " : "")
          << (o.customName ? "name " : "") << (o.fallbackSeed ? "seed " : "")
          << (o.fallbackWear ? "wear " : "") << (o.fallbackStatTrak ? "stattrak " : "")
          << (o.originalOwnerLow ? "owner " : "") << (o.musicId && o.inventoryServices ? "music" : "");
        SetBinding(s.str());
        state_ = Status::Ready;
        ready_.store(true, std::memory_order_release);
        InstallGloveStage(image, client);
        InstallGloveBuilder(image);
        InstallColorHook(image);
        InstallFrostHook(image, scope, field("C_BaseEntity", "m_pRenderComponent", false));
    }

    void SubmitKnifePlan(knife_experiment::Plan plan) {
        std::lock_guard<std::mutex> lock(mutex_);
        knifePlan_ = std::move(plan);
        knifeEnabled_ = true;
    }
    void SubmitGunPlan(weapon_inmatch::Plan plan) {
        std::lock_guard<std::mutex> lock(mutex_);
        gunPlan_ = std::move(plan);
    }
    void SubmitGlovePlan(glove_inmatch::Plan plan) {
        std::lock_guard<std::mutex> lock(mutex_);
        glovePlan_ = std::move(plan);
    }
    void Submit(const InventoryValues& values, bool enabled) {
        std::lock_guard<std::mutex> lock(mutex_);
        config_ = values;
        enabled_ = enabled;
        const auto now = GetTickCount64();
        configAt_ = now ? now : 1;
        PublishFrost(values, now);
    }
    Status State() const {
        return state_.load();
    }
    std::string Diagnostic() const {
        static const char* names[] = {"waiting for modules",
                                      "unsupported (schema/entity list)",
                                      "ready",
                                      "applied",
                                      "idle",
                                      "fault: thread changed (stopped)",
                                      "stopped"};
        std::ostringstream s;
        InventoryApplyStats last;
        weapon_inmatch::Stats gunDiag;
        knife_experiment::Stats knifeDiag;
        std::string binding, gloveStage;
        {
            std::lock_guard<std::mutex> lock(detailMutex_);
            last = last_;
            gunDiag = gunLast_;
            knifeDiag = knifeLast_;
            binding = binding_;
            gloveStage = gloveStage_;
        }
        s << "Frost: hook=" << (frostEnabled_.load() ? "matched" : "missing")
          << " calls=" << frostCalls_.load() << " applied=" << frostApplied_.load()
          << " items=" << frostItems_.load() << " world=" << frostWorld_.load() << " hud=" << frostHud_.load()
          << " stage=" << frostLastStage_.load() << " detail=" << frostLastDetail_.load()
          << " team=" << frostLastTeam_.load() << " def=" << frostLastDef_.load()
          << " env-hook=" << (frostEnvironmentEnabled_.load() ? "matched" : "missing")
          << " env-samples=" << frostEnvironmentSamples_.load()
          << " env-failures=" << frostEnvironmentFailures_.load()
          << " env-sky=" << frostEnvironmentSky_.load()
          << "; Colors experimental: hook=" << (colorEnabled_.load() ? "matched" : "missing")
          << " glove-builder=" << (gloveColorVerified_ ? "matched" : "missing")
          << " builds=" << colorCalls_.load() << " appended=" << colorAppended_.load()
          << " alloc-fail=" << colorAllocationFailures_.load() << " verified=" << colorVerified_.load()
          << " last-def=" << colorLastDef_.load() << " last-paint=" << colorLastPaint_.load()
          << " last-mask=" << colorLastMask_.load() << " fade-builds=" << colorFadeBuilds_.load()
          << " fade-appended=" << colorFadeAppended_.load() << " fade-verified=" << colorFadeVerified_.load()
          << " fade-mask=" << colorFadeMask_.load() << " preview-scripts=" << previewScriptCalls_.load()
          << " preview-wear=" << previewScriptWear_.load() << "; Weapon skins: stage=" << gunDiag.stage
          << " team=" << gunDiag.team << " def=" << gunDiag.def << " paint=" << gunDiag.paint
          << " legacy=" << gunDiag.legacy << " skin=" << gunDiag.skin << " skip=" << gunDiag.skip
          << " attr-count=" << gunDiag.attrCount << " guard=" << gunMemory_.gunCheck.load()
          << " applied=" << gunDiag.applied << " restored=" << gunDiag.restored
          << " failures=" << gunDiag.failed << " tables=" << gunTableCount_.load()
          << " mesh-binding=" << (gunMemory_.meshSetter ? "matched" : "missing")
          << " mesh-nodes=" << gunMemory_.meshNodes.load() << " mesh-calls=" << gunMemory_.meshCalls.load()
          << " mesh-failures=" << gunMemory_.meshFailures.load() << " charm-id=" << gunDiag.charm
          << " charm-state=" << gunDiag.charmState << " sticker-state=" << gunDiag.stickerState
          << " charm-binding=" << (gunMemory_.charmUpdater ? "matched" : "missing")
          << " charm-bind-stage=" << gunMemory_.charmBindStage.load()
          << " charm-schema=" << gunMemory_.charmSchemaDef.load() << "," << gunMemory_.charmSchemaSeed.load()
          << "," << gunMemory_.charmSchemaUI.load() << " charm-calls=" << gunMemory_.charmCalls.load()
          << " charm-failures=" << gunMemory_.charmFailures.load()
          << " gun-name-clears=" << gunHudClears_.load() << " gun-hud-refresh=" << gunHudSuccess_.load()
          << " gun-hud-pending=" << gunHudPending_.load() << "; Knife experiment: stage=" << knifeDiag.stage
          << " team=" << knifeDiag.team << " from=" << knifeDiag.from << " to=" << knifeDiag.to
          << " changes=" << knifeDiag.changes << " failures=" << knifeDiag.failures
          << " models=" << knifeDiag.models << " token=" << knifeDiag.token
          << " expected=" << knifeDiag.expected << " skin-state=" << knifeDiag.skin
          << " skin-check=" << memory_.skinCheck.load() << " skin-materials=" << memory_.skinMatA.load()
          << "," << memory_.skinMatB.load()
          << " skin-binding=" << (memory_.skinBindings.knifeTable ? "matched" : "missing")
          << " name-cache=" << (memory_.clearItemDescription ? "matched" : "missing")
          << " name-clears=" << memory_.nameCacheClears.load()
          << " name-failures=" << memory_.nameCacheFailures.load() << " gloves=" << gloveStage
          << " glove-binding=" << (gloveMemory_.pawnVtable ? "matched" : "missing")
          << " buy-hud=" << (buyMenuOffset_ ? "matched" : "missing")
          << " buy-hud-refresh=" << buyHudRefreshes_.load() << " paint=" << knifeDiag.paint
          << " hud-binding=" << (memory_.hudFind ? "matched" : "missing")
          << " hud-refresh=" << hudSuccess_.load() << " binding=" << (subclassOffset_ ? "matched" : "missing")
          << "; Inventory state [inventory-v1]: " << names[unsigned(State())] << "; stage=" << last.stage
          << " team="
          << (last.team == InventoryCT  ? "CT"
              : last.team == InventoryT ? "T"
                                        : "-")
          << " weapons=" << last.weapons << " configured=" << last.configured << " applied=" << last.applied
          << " restored=" << last.restored << " music=" << (last.music ? 1 : 0)
          << "; passes=" << passes_.load() << " writes=" << writes_.load() << " failures=" << failures_.load()
          << " stale=" << stale_.load() << "; " << binding;
        return s.str();
    }

    bool Stop(DWORD timeout = 2000) {
        closing_ = true;
        const auto end = GetTickCount64() + timeout;
        while (dispatched_ && !ack_ && GetTickCount64() < end)
            Sleep(10);
        if (dispatched_ && !ack_)
            return false;
        if (!StopFrostHook(timeout))
            return false;
        if (!StopColorHook(timeout))
            return false;
        if (!StopGloveBuilder(timeout))
            return false;
        return StopGloveStage(timeout);
    }
};
}
#undef MENU_INVENTORY_TRY
#undef MENU_INVENTORY_EXCEPT
