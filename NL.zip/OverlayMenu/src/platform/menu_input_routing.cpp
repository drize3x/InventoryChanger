#include "menu_input_routing.h"
namespace menu {
bool IsDefaultMovementKey(unsigned key) noexcept {
    switch (key) {
    case 'W':
    case 'A':
    case 'S':
    case 'D':
    case 0x20:
    case 0x10:
    case 0xa0:
    case 0xa1:
    case 0x11:
    case 0xa2:
    case 0xa3:
    case 0x25:
    case 0x26:
    case 0x27:
    case 0x28:
        return true;
    default:
        return false;
    }
}
bool PassGameKeyboard(bool editing, bool release, unsigned key) noexcept {
    return release || (!editing && IsDefaultMovementKey(key));
}
}
