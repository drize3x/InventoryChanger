#pragma once
#include "watermark_hud.h"
#include "watermark_hud_patterns.h"
#include "watermark_kd_schema.h"
#include <windows.h>
#include <MinHook.h>
#include <atomic>
#include <string>
#include <sstream>
#if defined(MENU_STUDIO_HUD_TEST_STUB)
#define MENU_HUD_TRY try
#define MENU_HUD_EXCEPT catch (...)
#elif defined(_MSC_VER)
#define MENU_HUD_TRY __try
#define MENU_HUD_EXCEPT __except (EXCEPTION_EXECUTE_HANDLER)
#else
#error Native HUD adapter needs MSVC SEH (or the synthetic test shim).
#endif
#if defined(MENU_STUDIO_HUD_TEST_CALLS)
namespace menu {
bool HudTestApply(std::uintptr_t, std::uintptr_t, HudPosition*, bool);
bool HudTestRelease(std::uintptr_t, std::uintptr_t);
bool HudTestStyle(std::uintptr_t, std::uintptr_t, std::uintptr_t&);
bool HudTestHandle(std::uintptr_t, std::uintptr_t, std::uintptr_t, std::uint64_t&);
bool HudTestResolve(std::uintptr_t, std::uintptr_t, const std::uint64_t&, std::uintptr_t&);
}
#endif
namespace menu {

class WatermarkNativeHud {
public:
    using FrameObserver = void (*)(void*, const HudResolvedBindings&);
    enum class Status { Waiting, Unsupported, Ready, NoPanel, Applied, Restored, Conflict, Fault, Stopping };
#if defined(MENU_STUDIO_HUD_TEST_STUB)
public:
#else
private:
#endif
    using Frame = void(__fastcall*)(void*);
    inline static WatermarkNativeHud* instance_ = nullptr;
    std::atomic<FrameObserver> observer_{nullptr}, auxObserver_{nullptr}, effectObserver_{nullptr},
        modelObserver_{nullptr}, markerObserver_{nullptr}, impactObserver_{nullptr}, knifeObserver_{nullptr},
        lightningObserver_{nullptr}, scoreboardObserver_{nullptr}, inventoryObserver_{nullptr},
        localCharmObserver_{nullptr};
    Frame next_ = nullptr;
    void* hook_ = nullptr;
    bool created_ = false, enabled_ = false, attempted_ = false;
    HMODULE seenClient_ = nullptr, seenPanorama_ = nullptr;
    WatermarkKdModule client_{}, panorama_{};
    HudResolvedBindings bindings_{};
    std::atomic<float> requested_{0};
    std::atomic<ULONGLONG> submitted_{0};
    std::atomic<bool> closing_{false}, ack_{false};
    std::atomic<unsigned> active_{0};
    std::atomic<Status> status_{Status::Waiting};
    std::string binding_;
    DWORD uiThread_ = 0;
    std::uintptr_t engine_ = 0, panel_ = 0, style_ = 0, blockedPanel_ = 0;
    std::uint64_t handle_ = 0;
    bool owned_ = false, hadInline_ = false, fault_ = false;
    HudPosition original_{}, originalInline_{}, ours_{};
    static bool Bytes(std::uintptr_t address, void* out, std::size_t size) {
        SIZE_T count = 0;
        return address &&
               ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(address), out, size,
                                 &count) &&
               count == size;
    }
    template <class T> static bool Read(std::uintptr_t address, T& out) {
        return Bytes(address, &out, sizeof(out));
    }
    static bool Writable(std::uintptr_t address, std::size_t size) {
        MEMORY_BASIC_INFORMATION m{};
        if (!address || VirtualQuery(reinterpret_cast<LPCVOID>(address), &m, sizeof(m)) != sizeof(m) ||
            m.State != MEM_COMMIT || m.Protect & (PAGE_GUARD | PAGE_NOACCESS))
            return false;
        auto start = reinterpret_cast<std::uintptr_t>(m.BaseAddress);
        auto p = m.Protect & 0xff;
        return address >= start && address - start <= m.RegionSize &&
               size <= m.RegionSize - (address - start) &&
               (p == PAGE_READWRITE || p == PAGE_WRITECOPY || p == PAGE_EXECUTE_READWRITE ||
                p == PAGE_EXECUTE_WRITECOPY);
    }
    template <class T> static bool Write(std::uintptr_t address, const T& value) {
        if (!Writable(address, sizeof(T)))
            return false;
        MENU_HUD_TRY {
            std::memcpy(reinterpret_cast<void*>(address), &value, sizeof(value));
            return true;
        }
        MENU_HUD_EXCEPT {
            return false;
        }
    }
    static bool Exec(const WatermarkKdModule& m, std::uintptr_t p) {
        if (p < m.base)
            return false;
        auto rva = p - m.base;
        for (auto& s : m.sections)
            if ((s.flags & 0x20000000) && rva >= s.rva && rva - s.rva < s.size)
                return true;
        return false;
    }

    static bool Apply(std::uintptr_t fn, std::uintptr_t style, HudPosition* p, bool normal) {
#if defined(MENU_STUDIO_HUD_TEST_CALLS)
        return HudTestApply(fn, style, p, normal);
#else
        MENU_HUD_TRY {
            reinterpret_cast<void(__fastcall*)(void*, HudPosition*, bool)>(fn)(reinterpret_cast<void*>(style),
                                                                               p, normal);
            return true;
        }
        MENU_HUD_EXCEPT {
            return false;
        }
#endif
    }
    static bool Release(std::uintptr_t fn, std::uintptr_t property) {
#if defined(MENU_STUDIO_HUD_TEST_CALLS)
        return HudTestRelease(fn, property);
#else
        MENU_HUD_TRY {
            reinterpret_cast<void(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(property));
            return true;
        }
        MENU_HUD_EXCEPT {
            return false;
        }
#endif
    }
    static bool GetStyle(std::uintptr_t fn, std::uintptr_t panel, std::uintptr_t& result) {
#if defined(MENU_STUDIO_HUD_TEST_CALLS)
        return HudTestStyle(fn, panel, result);
#else
        MENU_HUD_TRY {
            result = reinterpret_cast<std::uintptr_t(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(panel));
            return true;
        }
        MENU_HUD_EXCEPT {
            return false;
        }
#endif
    }
    static bool GetHandle(std::uintptr_t fn, std::uintptr_t engine, std::uintptr_t panel,
                          std::uint64_t& result) {
#if defined(MENU_STUDIO_HUD_TEST_CALLS)
        return HudTestHandle(fn, engine, panel, result);
#else
        MENU_HUD_TRY {
            reinterpret_cast<std::uint64_t*(__fastcall*)(void*, std::uint64_t*, void*)>(fn)(
                reinterpret_cast<void*>(engine), &result, reinterpret_cast<void*>(panel));
            return true;
        }
        MENU_HUD_EXCEPT {
            return false;
        }
#endif
    }
    static bool Resolve(std::uintptr_t fn, std::uintptr_t engine, const std::uint64_t& handle,
                        std::uintptr_t& result) {
#if defined(MENU_STUDIO_HUD_TEST_CALLS)
        return HudTestResolve(fn, engine, handle, result);
#else
        MENU_HUD_TRY {
            result = reinterpret_cast<std::uintptr_t(__fastcall*)(void*, const std::uint64_t*)>(fn)(
                reinterpret_cast<void*>(engine), &handle);
            return true;
        }
        MENU_HUD_EXCEPT {
            return false;
        }
#endif
    }
    bool PropertyDeleter(std::uint8_t id, std::uintptr_t& descriptor, std::uintptr_t& deleter) {
        auto slot = bindings_.registry + std::uintptr_t(id) * bindings_.registryStride;
        return id != 255 && WatermarkKdDataAddress(panorama_, slot) && Read(slot, descriptor) && descriptor &&
               Read(descriptor + 0x20, deleter) && Exec(panorama_, deleter);
    }
    bool ReadProperty(std::uintptr_t property, std::uint8_t id, HudPosition& result) {
        return Read(property, result) && result.vtable == bindings_.positionVtable && result.id == id &&
               result.flag <= 1;
    }
    bool Position(std::uintptr_t style, bool inLine, HudPosition& value, bool& exists,
                  std::uintptr_t* address = nullptr) {
        std::uint8_t id = 0;
        if (!Read(bindings_.positionId, id) || id == 255)
            return false;
        exists = false;
        std::int32_t count = 0;
        std::uintptr_t list = 0, entries = 0;
        if (inLine) {
            if (!Read(style + bindings_.inlineList, list))
                return false;
            if (!list)
                return true;
            if (!Read(list, count) || !Read(list + 8, entries))
                return false;
        } else if (!Read(style + bindings_.computedCount, count) ||
                   !Read(style + bindings_.computedEntries, entries))
            return false;
        if (count < 0 || count > 512 || (count && !entries))
            return false;
        for (int i = 0; i < count; ++i) {
            HudPropertyEntry e{};
            if (!Read(entries + std::uintptr_t(i) * 16, e))
                return false;
            if (e.id != id)
                continue;
            if (exists || !ReadProperty(e.property, id, value))
                return false;
            exists = true;
            if (address)
                *address = e.property;
        }
        return true;
    }
    bool PanelStyle(std::uintptr_t panel, std::uintptr_t& style) {
        std::uintptr_t vt = 0, svt = 0, owner = 0;
        return Read(panel, vt) && vt == bindings_.panelVtable && GetStyle(bindings_.getStyle, panel, style) &&
               style && Read(style, svt) && svt == bindings_.styleVtable && Read(style + 8, owner) &&
               owner == panel;
    }
    void Fault() {
        fault_ = true;
        status_ = Status::Fault;
    }

    bool Restore() {
        if (!owned_)
            return true;
        std::uintptr_t live = 0, currentStyle = 0;
        if (!Resolve(bindings_.resolveHandle, engine_, handle_, live))
            return false;
        if (!live) {
            owned_ = false;
            panel_ = style_ = 0;
            return true;
        }
        if (live != panel_ || !PanelStyle(live, currentStyle) || currentStyle != style_)
            return false;
        HudPosition current{};
        bool exists = false;
        if (!Position(style_, true, current, exists))
            return false;
        if (!exists || !HudSamePosition(current, ours_)) {

            owned_ = false;
            blockedPanel_ = panel_;
            status_ = Status::Conflict;
            return true;
        }
        auto p = hadInline_ ? originalInline_ : original_;
        if (!Apply(bindings_.apply, style_, &p, p.flag == 0))
            return false;
        if (!hadInline_) {

            std::uintptr_t property = 0, list = 0, descriptor = 0, deleter = 0;
            if (!Position(style_, true, current, exists, &property) || !exists ||
                !Read(style_ + bindings_.inlineList, list) || !PropertyDeleter(p.id, descriptor, deleter))
                return false;
            std::int32_t count = 0;
            std::uintptr_t entries = 0;
            if (!Read(list, count) || count <= 0 || count > 512 || !Read(list + 8, entries) ||
                !Writable(list, sizeof(count)) || !Writable(entries, std::size_t(count) * 16))
                return false;
            auto read = [](std::uintptr_t a, auto& x) { return Read(a, x); };
            auto write = [](std::uintptr_t a, const auto& x) { return Write(a, x); };
            if (!HudDetachInline(read, write, list, p.id, property) || !Release(deleter, property))
                return false;
        }
        owned_ = false;
        panel_ = style_ = 0;
        status_ = Status::Restored;
        return true;
    }
    void Tick(void* object) {
        if (fault_)
            return;
        auto e = reinterpret_cast<std::uintptr_t>(object);
        std::uintptr_t vt = 0;
        if (!Read(e, vt) || vt != bindings_.engineVtable)
            return;
        if (!uiThread_)
            uiThread_ = GetCurrentThreadId();
        if (uiThread_ != GetCurrentThreadId())
            return;
        if (engine_ && engine_ != e) {
            if (owned_) {
                Fault();
                return;
            }
        }
        engine_ = e;
        float y = requested_.load();
        if (closing_ || GetTickCount64() - submitted_.load() > 500)
            y = 0;
        if (y == 0) {
            if (!Restore()) {
                Fault();
                return;
            }
            blockedPanel_ = 0;
            if (closing_) {
                status_ = Status::Stopping;
                ack_ = true;
            }
            return;
        }
        std::uintptr_t hud = 0, wrapper = 0, panel = 0, style = 0;
        if (!Read(bindings_.hudGlobal, hud) || !hud || !Read(hud + bindings_.hudBottom, wrapper) ||
            !wrapper || !Read(wrapper + 8, panel) || !panel) {
            if (!Restore())
                Fault();
            else
                status_ = Status::NoPanel;
            return;
        }
        if (!PanelStyle(panel, style)) {
            if (!Restore())
                Fault();
            else
                status_ = Status::NoPanel;
            return;
        }
        if (owned_ && (panel_ != panel || style_ != style)) {
            if (!Restore()) {
                Fault();
                return;
            }
        }
        if (blockedPanel_ == panel) {
            status_ = Status::Conflict;
            return;
        }
        if (!owned_) {
            bool exists = false;
            std::uint8_t id = 0;
            if (!Read(bindings_.positionId, id) || id == 255) {
                Fault();
                return;
            }
            original_ = {};
            original_.vtable = bindings_.positionVtable;
            original_.id = id;
            if (!Position(style, false, original_, exists) ||
                !Position(style, true, originalInline_, hadInline_) || !HudCanOffset(original_)) {
                status_ = Status::Conflict;
                blockedPanel_ = panel;
                return;
            }

            std::uintptr_t descriptor = 0, deleter = 0;
            if (!PropertyDeleter(id, descriptor, deleter)) {
                status_ = Status::Conflict;
                blockedPanel_ = panel;
                return;
            }
            if (!GetHandle(bindings_.getHandle, e, panel, handle_)) {
                Fault();
                return;
            }
            std::uintptr_t live = 0;
            if (!Resolve(bindings_.resolveHandle, e, handle_, live) || live != panel) {
                Fault();
                return;
            }
            panel_ = panel;
            style_ = style;
        } else {
            HudPosition current{};
            bool exists = false;
            if (!Position(style_, true, current, exists)) {
                Fault();
                return;
            }
            if (!exists || !HudSamePosition(current, ours_)) {
                owned_ = false;
                blockedPanel_ = panel;
                status_ = Status::Conflict;
                return;
            }
        }
        auto p = original_;
        p.flag = 0;
        p.y.value += y;
        if (owned_ && HudSamePosition(p, ours_)) {
            status_ = Status::Applied;
            return;
        }

        owned_ = true;
        if (!Apply(bindings_.apply, style_, &p, true)) {
            Fault();
            return;
        }
        bool exists = false;
        if (!Position(style_, true, ours_, exists) || !exists || !HudSamePosition(p, ours_)) {
            Fault();
            return;
        }
        status_ = Status::Applied;
    }
    static void __fastcall OnFrame(void* object) {
        auto self = instance_;
        self->active_.fetch_add(1);
        self->next_(object);
        try {
            self->Tick(object);
        } catch (...) {
            self->Fault();
        }

        if (auto observer = self->observer_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->observer_.store(nullptr, std::memory_order_release);
            }
        }

        if (auto observer = self->auxObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->auxObserver_.store(nullptr, std::memory_order_release);
            }
        }

        if (auto observer = self->effectObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->effectObserver_.store(nullptr, std::memory_order_release);
            }
        }

        if (auto observer = self->modelObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->modelObserver_.store(nullptr, std::memory_order_release);
            }
        }

        if (auto observer = self->markerObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->markerObserver_.store(nullptr, std::memory_order_release);
            }
        }

        if (auto observer = self->impactObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->impactObserver_.store(nullptr, std::memory_order_release);
            }
        }

        if (auto observer = self->knifeObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->knifeObserver_.store(nullptr, std::memory_order_release);
            }
        }
        if (auto observer = self->lightningObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->lightningObserver_.store(nullptr, std::memory_order_release);
            }
        }

        if (auto observer = self->scoreboardObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->scoreboardObserver_.store(nullptr, std::memory_order_release);
            }
        }

        if (auto observer = self->inventoryObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->inventoryObserver_.store(nullptr, std::memory_order_release);
            }
        }
        if (auto observer = self->localCharmObserver_.load(std::memory_order_acquire)) {
            try {
                observer(object, self->bindings_);
            } catch (...) {
                self->localCharmObserver_.store(nullptr, std::memory_order_release);
            }
        }
        self->active_.fetch_sub(1);
    }

public:
    void SetFrameObserver(FrameObserver f) {
        observer_.store(f, std::memory_order_release);
    }
    void SetAuxFrameObserver(FrameObserver f) {
        auxObserver_.store(f, std::memory_order_release);
    }
    void SetEffectFrameObserver(FrameObserver f) {
        effectObserver_.store(f, std::memory_order_release);
    }
    void SetModelFrameObserver(FrameObserver f) {
        modelObserver_.store(f, std::memory_order_release);
    }
    void SetMarkerFrameObserver(FrameObserver f) {
        markerObserver_.store(f, std::memory_order_release);
    }
    void SetImpactFrameObserver(FrameObserver f) {
        impactObserver_.store(f, std::memory_order_release);
    }
    void SetKnifeFrameObserver(FrameObserver f) {
        knifeObserver_.store(f, std::memory_order_release);
    }
    void SetLightningFrameObserver(FrameObserver f) {
        lightningObserver_.store(f, std::memory_order_release);
    }
    void SetScoreboardFrameObserver(FrameObserver f) {
        scoreboardObserver_.store(f, std::memory_order_release);
    }
    void SetInventoryFrameObserver(FrameObserver f) {
        inventoryObserver_.store(f, std::memory_order_release);
    }
    void SetLocalCharmFrameObserver(FrameObserver f) {
        localCharmObserver_.store(f, std::memory_order_release);
    }
    void Submit(float y) {
        requested_ = std::isfinite(y) && y <= 0 && y >= -4096 ? y : 0;
        submitted_ = GetTickCount64();
    }
    Status State() const {
        return status_.load();
    }
    std::string Diagnostic() const {
        static const char* names[] = {"waiting for modules",
                                      "unresolved signatures/ABI",
                                      "ready",
                                      "waiting for HudBottomCenter",
                                      "applied",
                                      "restored",
                                      "position conflict/unsupported unit",
                                      "fault: unload must be deferred",
                                      "stopping/restored"};
        return std::string("Native HUD: ") + names[unsigned(State())] + "; " + binding_;
    }
    void TryStart() {
        if (created_ || closing_)
            return;
        auto c = GetModuleHandleW(L"client.dll"), p = GetModuleHandleW(L"panorama.dll");
        if (!c || !p) {
            status_ = Status::Waiting;
            return;
        }
        if (attempted_ && seenClient_ == c && seenPanorama_ == p)
            return;
        attempted_ = true;
        seenClient_ = c;
        seenPanorama_ = p;
        auto read = [](std::uintptr_t a, auto& x) { return Read(a, x); };
        status_ = Status::Unsupported;
        if (!WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(c), client_) ||
            !WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(p), panorama_)) {
            binding_ = "invalid loaded PE";
            return;
        }
        std::ostringstream details;
        details << std::hex << "client timestamp=" << client_.timestamp << " size=" << client_.size
                << " panorama timestamp=" << panorama_.timestamp << " size=" << panorama_.size;
        binding_ = details.str();
        HudScanImage clientImage, panoramaImage;
        auto bytes = [](std::uintptr_t a, void* out, std::size_t n) { return Bytes(a, out, n); };
        if (!clientImage.Load(client_, bytes) || !panoramaImage.Load(panorama_, bytes)) {
            binding_ += "; module snapshot read failed";
            return;
        }
        std::string resolution;
        if (!HudResolveBindings(clientImage, panoramaImage, bindings_, resolution)) {
            binding_ += "; " + resolution;
            return;
        }
        binding_ += "; " + resolution;
        auto frame = bindings_.frame;
        hook_ = reinterpret_cast<void*>(frame);
        instance_ = this;
        auto result =
            MH_CreateHook(hook_, reinterpret_cast<void*>(OnFrame), reinterpret_cast<void**>(&next_));
        if (result != MH_OK) {
            binding_ += "; UI hook creation failed";
            return;
        }
        created_ = true;
        result = MH_EnableHook(hook_);
        if (result != MH_OK) {
            MH_RemoveHook(hook_);
            created_ = false;
            binding_ += "; UI hook enable failed";
            return;
        }
        enabled_ = true;
        status_ = Status::Ready;
    }
    bool StopAndRestore(DWORD timeout = 2000) {
        closing_ = true;
        Submit(0);
        if (!created_)
            return true;
        auto deadline = GetTickCount64() + timeout;
        while (!ack_ && GetTickCount64() < deadline)
            Sleep(10);
        if (!ack_)
            return false;
        if (enabled_) {
            auto r = MH_DisableHook(hook_);
            if (r != MH_OK && r != MH_ERROR_DISABLED)
                return false;
            enabled_ = false;
        }
        auto drainDeadline = GetTickCount64() + timeout;
        while (active_.load() && GetTickCount64() < drainDeadline)
            Sleep(1);
        if (active_)
            return false;
        Sleep(50);
        return active_.load() == 0;
    }
    bool RemoveHook() {
        if (!created_)
            return true;
        if (enabled_ || active_)
            return false;
        if (MH_RemoveHook(hook_) != MH_OK)
            return false;
        created_ = false;
        return true;
    }
};
}
#undef MENU_HUD_TRY
#undef MENU_HUD_EXCEPT
