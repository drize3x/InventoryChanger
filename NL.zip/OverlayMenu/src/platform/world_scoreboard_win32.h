#pragma once

#include "game_hud_win32.h"
#include "players_preview_bridge_patterns.h"
#include "win32_local_read.h"
#include "world_scoreboard_engine.h"
#include "world_scoreboard_patterns.h"
#include <array>
#include <atomic>
#include <mutex>
#include <sstream>
#include <string>
#if defined(MENU_STUDIO_SCOREBOARD_TEST)
#define MENU_SCOREBOARD_TRY try
#define MENU_SCOREBOARD_EXCEPT catch (...)
#elif defined(_MSC_VER)
#define MENU_SCOREBOARD_TRY __try
#define MENU_SCOREBOARD_EXCEPT __except (EXCEPTION_EXECUTE_HANDLER)
#else
#error The scoreboard runtime requires MSVC SEH (or the synthetic test shim).
#endif
namespace menu {
inline constexpr std::uint64_t ScoreboardScriptOrigin = 1;
class WorldScoreboard {
public:
    enum class Status { Waiting, Unsupported, Ready, NoRoot, Hidden, Applied, Idle, Fault, Stopped };
#if defined(MENU_STUDIO_SCOREBOARD_TEST)
public:
#else
private:
#endif
    inline static WorldScoreboard* instance_ = nullptr;
    std::atomic<Status> state_{Status::Waiting};
    std::atomic<bool> ready_{false}, closing_{false}, ack_{false}, dispatched_{false}, ranksReady_{false};
    std::atomic<unsigned> scripts_{0}, cleanups_{0}, rankWrites_{0}, rankFailures_{0}, rankEvents_{0},
        stale_{0};
    std::atomic<int> rankByte_{-1};
    std::atomic<bool> rankHeldView_{false};
    PreviewBridgeBindings bridge_{};
    ScoreboardRankBindings ranks_{};
    mutable std::mutex detailMutex_;
    std::string detail_, rankDetail_, frameDetail_;
    HMODULE seenClient_ = nullptr, seenPanorama_ = nullptr;
    bool attempted_ = false;
    std::uint64_t token_ = 0;

    std::mutex mutex_;
    ScoreboardConfig config_{};
    ScoreboardFrame frame_{};
    ULONGLONG configAt_ = 0, frameAt_ = 0;

    DWORD uiThread_ = 0;
    ULONGLONG nextScript_ = 0;
    std::uintptr_t root_ = 0, rootEngine_ = 0, rankObject_ = 0;
    std::uint64_t rootHandle_ = 0;
    bool held_ = false, rankHeld_ = false, rankEvent_ = false;
    static bool Bytes(std::uintptr_t a, void* out, std::size_t n) {
        return LocalReadBytes(a, out, n);
    }
    template <class T> static bool Read(std::uintptr_t a, T& out) {
        return Bytes(a, &out, sizeof(out));
    }
    template <class T> static bool Write(std::uintptr_t a, const T& v) {
        return LocalWriteBytes(a, &v, sizeof(v));
    }

    static bool Run(std::uintptr_t fn, std::uintptr_t engine, std::uintptr_t panel, const char* code) {
        MENU_SCOREBOARD_TRY {
            reinterpret_cast<void(__fastcall*)(void*, void*, const char*, const char*, std::uint64_t)>(fn)(
                reinterpret_cast<void*>(engine), reinterpret_cast<void*>(panel), code,
                "file://{resources}/layout/avatar.xml", ScoreboardScriptOrigin);
            return true;
        }
        MENU_SCOREBOARD_EXCEPT {
            return false;
        }
    }
    static bool Visible(std::uintptr_t fn, std::uintptr_t panel, bool& out) {
        MENU_SCOREBOARD_TRY {
            out = reinterpret_cast<bool(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(panel));
            return true;
        }
        MENU_SCOREBOARD_EXCEPT {
            out = false;
            return false;
        }
    }
    static bool Handle(std::uintptr_t fn, std::uintptr_t engine, std::uintptr_t panel, std::uint64_t& out) {
        MENU_SCOREBOARD_TRY {
            reinterpret_cast<std::uint64_t*(__fastcall*)(void*, std::uint64_t*, void*)>(fn)(
                reinterpret_cast<void*>(engine), &out, reinterpret_cast<void*>(panel));
            return true;
        }
        MENU_SCOREBOARD_EXCEPT {
            return false;
        }
    }
    static bool Resolve(std::uintptr_t fn, std::uintptr_t engine, const std::uint64_t& h,
                        std::uintptr_t& out) {
        MENU_SCOREBOARD_TRY {
            out = reinterpret_cast<std::uintptr_t(__fastcall*)(void*, const std::uint64_t*)>(fn)(
                reinterpret_cast<void*>(engine), &h);
            return true;
        }
        MENU_SCOREBOARD_EXCEPT {
            return false;
        }
    }
    void SetDetail(std::string text) {
        std::lock_guard<std::mutex> lock(detailMutex_);
        detail_ = std::move(text);
    }
    void Fault() {
        ready_ = false;
        state_ = Status::Fault;
    }

    std::uintptr_t WindowRoot(std::uintptr_t global, bool& visible) {
        visible = true;
        std::uintptr_t client = 0, panel = 0, vt = 0;
        if (!global || !Read(global, client) || !client || !Read(client + bridge_.hudRootOffset, panel) ||
            !panel)
            return 0;
        std::array<std::uintptr_t, 64> seen{};
        unsigned used = 0;
        while (panel && used < seen.size()) {
            for (unsigned i = 0; i < used; ++i)
                if (seen[i] == panel)
                    return 0;
            seen[used++] = panel;
            if (!Read(panel, vt) || vt != bridge_.panelVtable)
                return 0;
            bool shown = false;
            if (!Visible(bridge_.isVisible, panel, shown))
                return 0;
            if (!shown)
                visible = false;
            std::uintptr_t parent = 0;
            if (!Read(panel + bridge_.parentOffset, parent))
                return 0;
            if (!parent)
                return panel;
            panel = parent;
        }
        return 0;
    }

    void TickRanks(bool wanted) {
        if (!ranksReady_.load(std::memory_order_acquire))
            return;
        using namespace world_scoreboard_patterns;
        std::uintptr_t object = 0, vt = 0;
        std::uint8_t value = 0xff;
        if (!Read(ranks_.global, object) || !object || !Read(object, vt) || vt != ranks_.vtable ||
            !Read(object + ranks_.field, value)) {
            rankByte_ = -1;
            rankHeld_ = false;
            rankObject_ = 0;
            rankHeldView_ = false;
            return;
        }
        if (object != rankObject_) {
            rankHeld_ = false;
            rankObject_ = object;
        }
        rankByte_ = value;
        if (value == RevealNone && wanted) {
            if (!Write(object + ranks_.field, RevealOurs)) {
                ++rankFailures_;
                ranksReady_ = false;
                std::lock_guard<std::mutex> lock(detailMutex_);
                rankDetail_ += "; write refused (feature off)";
                return;
            }
            rankHeld_ = true;
            rankEvent_ = true;
            ++rankWrites_;
            rankByte_ = RevealOurs;
        } else if (value == RevealOurs && wanted)
            rankHeld_ = true;
        else if (value == RevealOurs && !wanted) {
            if (!Write(object + ranks_.field, RevealNone)) {
                ++rankFailures_;
                ranksReady_ = false;
                std::lock_guard<std::mutex> lock(detailMutex_);
                rankDetail_ += "; restore refused";
                return;
            }
            rankHeld_ = false;
            rankEvent_ = true;
            ++rankWrites_;
            rankByte_ = RevealNone;
        } else
            rankHeld_ = false;
        rankHeldView_ = rankHeld_;
    }

    bool CleanupOn(std::uintptr_t engine, const HudResolvedBindings& hud, std::uintptr_t root,
                   std::uint64_t handle, bool rankEvent) {
        std::uintptr_t live = 0, vt = 0;
        if (!root || !Resolve(hud.resolveHandle, engine, handle, live) || live != root || !Read(live, vt) ||
            vt != bridge_.panelVtable)
            return false;
        const auto code = BuildScoreboardScript(token_, {}, {}, true, rankEvent);
        if (!Run(bridge_.runScript, engine, live, code.c_str()))
            return false;
        ++cleanups_;
        if (rankEvent)
            ++rankEvents_;
        return true;
    }
    void ForgetRoot(std::uintptr_t engine, const HudResolvedBindings& hud) {
        if (held_ && root_ && rootEngine_ == engine)
            CleanupOn(engine, hud, root_, rootHandle_, false);
        root_ = rootEngine_ = 0;
        rootHandle_ = 0;
        held_ = false;
    }

    std::uintptr_t LiveRoot(std::uintptr_t engine, const HudResolvedBindings& hud, bool& visible,
                            std::uint64_t& handle) {
        handle = 0;
        auto root = WindowRoot(hud.hudGlobal, visible);
        std::uintptr_t live = 0;
        if (root && (!Handle(hud.getHandle, engine, root, handle) ||
                     !Resolve(hud.resolveHandle, engine, handle, live) || live != root))
            root = 0;
        return root;
    }
    void Release(std::uintptr_t engine, const HudResolvedBindings& hud) {
        TickRanks(false);
        if (held_ || rankEvent_) {
            bool visible = false;
            std::uint64_t handle = 0;
            auto root = LiveRoot(engine, hud, visible, handle);
            if (root && CleanupOn(engine, hud, root, handle, rankEvent_)) {
                held_ = false;
                rankEvent_ = false;
            } else if (held_ && root_ && rootEngine_ == engine &&
                       CleanupOn(engine, hud, root_, rootHandle_, rankEvent_)) {
                held_ = false;
                rankEvent_ = false;
            }
        }
        root_ = rootEngine_ = 0;
        rootHandle_ = 0;
    }
    void Tick(void* object, const HudResolvedBindings& hud) {
        dispatched_ = true;
        if (closing_ && ack_)
            return;
        if (!ready_.load(std::memory_order_acquire)) {
            if (closing_)
                ack_ = true;
            return;
        }
        const auto thread = GetCurrentThreadId();
        if (!uiThread_)
            uiThread_ = thread;
        const auto engine = reinterpret_cast<std::uintptr_t>(object);
        std::uintptr_t vt = 0;
        if (uiThread_ != thread || !Read(engine, vt) || vt != bridge_.engineVtable ||
            hud.engineVtable != vt) {
            Fault();
            if (closing_)
                ack_ = true;
            return;
        }
        if (closing_) {
            Release(engine, hud);
            ready_ = false;
            state_ = Status::Stopped;
            ack_ = true;
            return;
        }
        const auto now = GetTickCount64();
        ScoreboardConfig config;
        ULONGLONG configAt = 0, frameAt = 0;
        {
            std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
            if (!lock.owns_lock())
                return;
            config = config_;
            configAt = configAt_;
            frameAt = frameAt_;
        }
        if (!configAt || now < configAt || now - configAt > world_scoreboard::FrameMaxAgeMs) {
            ++stale_;
            return;
        }
        TickRanks(config.ranks);
        const bool js = config.Appearance() || config.money || config.equipment != 0 || config.atSync;
        if (!js && !held_ && !rankEvent_) {
            state_ = Status::Idle;
            return;
        }
        if (now < nextScript_)
            return;
        nextScript_ = now + world_scoreboard::ScriptIntervalMs;
        bool visible = false;
        std::uint64_t handle = 0;
        const auto root = LiveRoot(engine, hud, visible, handle);
        if (root != root_ || engine != rootEngine_ || (root && handle != rootHandle_)) {
            ForgetRoot(engine, hud);
            root_ = root;
            rootHandle_ = handle;
            rootEngine_ = engine;
        }
        if (!root) {
            state_ = Status::NoRoot;
            return;
        }
        if (js && !visible && !rankEvent_) {
            state_ = Status::Hidden;
            return;
        }
        ScoreboardFrame frame;
        if (js && config.NeedsPlayers() && frameAt && now >= frameAt &&
            now - frameAt <= world_scoreboard::FrameMaxAgeMs) {
            std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
            if (lock.owns_lock())
                frame = frame_;
        }
        const auto code = js ? BuildScoreboardScript(token_, config, frame, false, rankEvent_)
                             : BuildScoreboardScript(token_, {}, {}, true, rankEvent_);
        if (!Run(bridge_.runScript, engine, root, code.c_str())) {
            Fault();
            return;
        }
        if (js)
            ++scripts_;
        else
            ++cleanups_;
        if (rankEvent_)
            ++rankEvents_;
        rankEvent_ = false;
        held_ = js;
        state_ = js ? Status::Applied : Status::Idle;
    }
    static void Frame(void* object, const HudResolvedBindings& hud) {
        auto self = instance_;
        if (!self)
            return;
        try {
            self->Tick(object, hud);
        } catch (...) {
            self->Fault();
        }
    }

public:
    void Attach(WatermarkNativeHud& hud) {
        token_ =
            std::uint64_t(GetTickCount64()) ^ (std::uint64_t(reinterpret_cast<std::uintptr_t>(this)) << 8);
        if (!token_)
            token_ = 1;
        instance_ = this;
        hud.SetScoreboardFrameObserver(Frame);
    }
    void TryStart() {
        if (ready_ || closing_ || state_ == Status::Fault)
            return;
        auto c = GetModuleHandleW(L"client.dll"), p = GetModuleHandleW(L"panorama.dll");
        if (!c || !p) {
            state_ = Status::Waiting;
            return;
        }
        if (attempted_ && seenClient_ == c && seenPanorama_ == p)
            return;
        attempted_ = true;
        seenClient_ = c;
        seenPanorama_ = p;
        state_ = Status::Unsupported;
        WatermarkKdModule cm, pm;
        auto read = [](std::uintptr_t a, auto& x) { return Read(a, x); };
        if (!WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(c), cm) ||
            !WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(p), pm)) {
            SetDetail("invalid loaded PE");
            return;
        }
        HudScanImage ci, pi;
        auto bytes = [](std::uintptr_t a, void* out, std::size_t n) { return Bytes(a, out, n); };
        if (!ci.Load(cm, bytes) || !pi.Load(pm, bytes)) {
            SetDetail("module snapshot failed");
            return;
        }
        PreviewBridgeBindings bridge;
        std::string detail;
        if (!ResolvePreviewBridge(ci, pi, bridge, detail)) {
            SetDetail("bridge: " + detail);
            return;
        }
        ScoreboardRankBindings ranks;
        std::string rankDetail;
        const bool rankOk = ResolveScoreboardRanks(ci, ranks, rankDetail);
        {
            std::lock_guard<std::mutex> lock(detailMutex_);
            detail_ = "bridge: " + detail;
            rankDetail_ = rankDetail;
        }
        bridge_ = bridge;
        ranks_ = ranks;
        ranksReady_.store(rankOk, std::memory_order_release);
        state_ = Status::Ready;
        ready_.store(true, std::memory_order_release);
    }

    void Submit(const ScoreboardConfig& config, const ScoreboardFrame* frame) {
        const auto now = GetTickCount64();
        std::lock_guard<std::mutex> lock(mutex_);
        config_ = config;
        configAt_ = now ? now : 1;
        if (frame) {
            frame_ = *frame;
            frameAt_ = configAt_;
            std::ostringstream s;
            s << frame->stage << " rows=" << frame->players.size() << " controllers=" << frame->controllers
              << " pawns=" << frame->pawns << " weapons=" << frame->weapons << " unknown=" << frame->unknown
              << " torn=" << frame->torn << " foreign=" << frame->foreign
              << " inventory=" << frame->inventory;
            std::lock_guard<std::mutex> detail(detailMutex_);
            frameDetail_ = s.str();
        }
    }
    bool Held() const {
        return rankHeldView_.load() || state_.load() == Status::Applied;
    }
    Status State() const {
        return state_.load();
    }
    std::string Diagnostic() const {
        static const char* names[] = {"waiting for modules",
                                      "unresolved Panorama bridge",
                                      "ready",
                                      "no live HUD root",
                                      "HUD hidden",
                                      "applied",
                                      "idle",
                                      "fault: Panorama call failed or engine/thread changed (stopped)",
                                      "stopped"};
        std::ostringstream s;
        s << "Scoreboard state [scoreboard-v1]: " << names[unsigned(State())]
          << "; scripts=" << scripts_.load() << " cleanups=" << cleanups_.load() << " stale=" << stale_.load()
          << "; ranks=" << (ranksReady_.load() ? "bound" : "off") << " byte=" << rankByte_.load()
          << " held=" << (rankHeldView_.load() ? 1 : 0) << " writes=" << rankWrites_.load()
          << " failures=" << rankFailures_.load() << " events=" << rankEvents_.load();
        std::lock_guard<std::mutex> lock(detailMutex_);
        s << "; frame: " << (frameDetail_.empty() ? "none" : frameDetail_) << "; " << detail_
          << "; rank-bind: " << rankDetail_;
        return s.str();
    }
    bool Stop(DWORD timeout = 2000) {
        closing_ = true;
        if (!dispatched_)
            return true;
        const auto end = GetTickCount64() + timeout;
        while (!ack_ && GetTickCount64() < end)
            Sleep(10);
        return ack_.load();
    }
};
}
#undef MENU_SCOREBOARD_TRY
#undef MENU_SCOREBOARD_EXCEPT
