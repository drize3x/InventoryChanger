#pragma once
#include <d3d11.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <cstring>
#include "menu_core.h"
#include "ambience_image_cache.h"
#include "ambience_texture_codec.h"
#include "ambience_sky_shader.h"
namespace menu {

class AmbienceImageReadback {
#if defined(MENU_STUDIO_AMBIENCE_TEST)
    friend struct AmbienceReadbackTest;
#endif
    template <class T> using Ptr = Microsoft::WRL::ComPtr<T>;
    Ptr<ID3D11Device> device_;
    Ptr<ID3D11VertexShader> vs_;
    Ptr<ID3D11PixelShader> ps_, ycocg_, skyCube_;
    Ptr<ID3D11SamplerState> sampler_;
    Ptr<ID3D11RasterizerState> raster_;
    Ptr<ID3D11DepthStencilState> depth_;
    Ptr<ID3D11BlendState> blend_;
    Ptr<ID3D11Texture2D> render_, staging_;
    Ptr<ID3D11RenderTargetView> target_;
    Ptr<ID3D11Query> query_;
    Ptr<ID3D11Texture2D> rawColor_;
    Ptr<ID3D11ShaderResourceView> rawView_;
    AmbienceImageJob job_;
    std::uint64_t started_ = 0;
    UINT width_ = 0, height_ = 0;
    bool pending_ = false;
    static bool Supported(DXGI_FORMAT f, bool& srgb) {
        srgb = false;
        switch (f) {
        case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB:
        case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB:
        case DXGI_FORMAT_B8G8R8X8_UNORM_SRGB:
        case DXGI_FORMAT_BC1_UNORM_SRGB:
        case DXGI_FORMAT_BC2_UNORM_SRGB:
        case DXGI_FORMAT_BC3_UNORM_SRGB:
        case DXGI_FORMAT_BC7_UNORM_SRGB:
            srgb = true;
            return true;
        case DXGI_FORMAT_R8G8B8A8_UNORM:
        case DXGI_FORMAT_B8G8R8A8_UNORM:
        case DXGI_FORMAT_B8G8R8X8_UNORM:
        case DXGI_FORMAT_BC1_UNORM:
        case DXGI_FORMAT_BC2_UNORM:
        case DXGI_FORMAT_BC3_UNORM:
        case DXGI_FORMAT_BC7_UNORM:

        case DXGI_FORMAT_BC6H_UF16:
        case DXGI_FORMAT_BC6H_SF16:
        case DXGI_FORMAT_R16G16B16A16_FLOAT:
        case DXGI_FORMAT_R32G32B32A32_FLOAT:
        case DXGI_FORMAT_R11G11B10_FLOAT:
            return true;
        default:
            return false;
        }
    }
    static DXGI_FORMAT RawFormat(DXGI_FORMAT f) {
        switch (f) {
        case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB:
            return DXGI_FORMAT_R8G8B8A8_UNORM;
        case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB:
            return DXGI_FORMAT_B8G8R8A8_UNORM;
        case DXGI_FORMAT_B8G8R8X8_UNORM_SRGB:
            return DXGI_FORMAT_B8G8R8X8_UNORM;
        case DXGI_FORMAT_BC1_UNORM_SRGB:
            return DXGI_FORMAT_BC1_UNORM;
        case DXGI_FORMAT_BC2_UNORM_SRGB:
            return DXGI_FORMAT_BC2_UNORM;
        case DXGI_FORMAT_BC3_UNORM_SRGB:
            return DXGI_FORMAT_BC3_UNORM;
        case DXGI_FORMAT_BC7_UNORM_SRGB:
            return DXGI_FORMAT_BC7_UNORM;
        default:
            return f;
        }
    }
    bool Init(ID3D11Device* device) {
        if (device_.Get() == device && vs_ && ps_ && ycocg_ && sampler_ && raster_ && depth_ && blend_)
            return true;
        Reset();
        device_ = device;
        const auto shader = AmbienceReadbackShader;
        constexpr auto bytes = sizeof(AmbienceReadbackShader) - 1;
        Ptr<ID3DBlob> v, p, y, error;
        if (FAILED(D3DCompile(shader, bytes, "MenuStudio.Ambience", nullptr, nullptr, "vs", "vs_4_0",
                              D3DCOMPILE_ENABLE_STRICTNESS, 0, &v, &error)) ||
            FAILED(D3DCompile(shader, bytes, "MenuStudio.Ambience", nullptr, nullptr, "ps", "ps_4_0",
                              D3DCOMPILE_ENABLE_STRICTNESS, 0, &p, &error)) ||
            FAILED(D3DCompile(shader, bytes, "MenuStudio.Ambience", nullptr, nullptr, "ycocg", "ps_4_0",
                              D3DCOMPILE_ENABLE_STRICTNESS, 0, &y, &error)) ||
            FAILED(device->CreateVertexShader(v->GetBufferPointer(), v->GetBufferSize(), nullptr, &vs_)) ||
            FAILED(device->CreatePixelShader(p->GetBufferPointer(), p->GetBufferSize(), nullptr, &ps_)) ||
            FAILED(device->CreatePixelShader(y->GetBufferPointer(), y->GetBufferSize(), nullptr, &ycocg_)))
            return false;
        D3D11_SAMPLER_DESC s{};
        s.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
        s.AddressU = s.AddressV = s.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
        s.MaxAnisotropy = 1;
        s.MaxLOD = D3D11_FLOAT32_MAX;
        s.ComparisonFunc = D3D11_COMPARISON_NEVER;
        D3D11_RASTERIZER_DESC r{};
        r.FillMode = D3D11_FILL_SOLID;
        r.CullMode = D3D11_CULL_NONE;
        r.DepthClipEnable = TRUE;
        D3D11_DEPTH_STENCIL_DESC d{};
        d.DepthEnable = FALSE;
        d.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
        d.DepthFunc = D3D11_COMPARISON_ALWAYS;
        d.StencilReadMask = d.StencilWriteMask = 0xff;
        d.FrontFace.StencilFailOp = d.FrontFace.StencilDepthFailOp = d.FrontFace.StencilPassOp =
            D3D11_STENCIL_OP_KEEP;
        d.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
        d.BackFace = d.FrontFace;
        D3D11_BLEND_DESC b{};
        auto& blend = b.RenderTarget[0];
        blend.SrcBlend = blend.SrcBlendAlpha = D3D11_BLEND_ONE;
        blend.DestBlend = blend.DestBlendAlpha = D3D11_BLEND_ZERO;
        blend.BlendOp = blend.BlendOpAlpha = D3D11_BLEND_OP_ADD;
        blend.RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
        if (FAILED(device->CreateSamplerState(&s, &sampler_)) ||
            FAILED(device->CreateRasterizerState(&r, &raster_)) ||
            FAILED(device->CreateDepthStencilState(&d, &depth_)) ||
            FAILED(device->CreateBlendState(&b, &blend_)))
            return false;
        return true;
    }
    void ClearFlight() {
        query_.Reset();
        target_.Reset();
        render_.Reset();
        staging_.Reset();
        rawView_.Reset();
        rawColor_.Reset();
        pending_ = false;
        job_ = {};
        width_ = height_ = 0;
    }

public:
    struct Completion {
        AmbienceImageJob job;
        std::shared_ptr<ProfileImage> image;
    };
    bool Pending() const {
        return pending_;
    }
    AmbienceImageJob Job() const {
        return job_;
    }
    void Reset() {
        ClearFlight();
        vs_.Reset();
        ps_.Reset();
        ycocg_.Reset();
        skyCube_.Reset();
        sampler_.Reset();
        raster_.Reset();
        depth_.Reset();
        blend_.Reset();
        device_.Reset();
    }
    bool Begin(ID3D11Device* device, ID3D11DeviceContext* context, ID3D11ShaderResourceView* source,
               const AmbienceImageJob& job, std::uint64_t now,
               AmbienceTextureCodec codec = AmbienceTextureCodec::RGB, UINT maxWidth = 640,
               UINT maxHeight = 360) {
        if (!maxWidth || !maxHeight || maxWidth > 1024 || maxHeight > 1024 || pending_ || !device ||
            !context || !source ||
            (codec != AmbienceTextureCodec::RGB && codec != AmbienceTextureCodec::YCoCg &&
             codec != AmbienceTextureCodec::SkyCube))
            return false;
        const bool decode = codec == AmbienceTextureCodec::YCoCg,
                   cube = codec == AmbienceTextureCodec::SkyCube;
        Ptr<ID3D11Device> owner;
        source->GetDevice(&owner);
        if (owner.Get() != device)
            return false;
        D3D11_SHADER_RESOURCE_VIEW_DESC view{};
        source->GetDesc(&view);
        bool srgb = false;
        if (view.ViewDimension != (cube ? D3D11_SRV_DIMENSION_TEXTURECUBE : D3D11_SRV_DIMENSION_TEXTURE2D) ||
            !Supported(view.Format, srgb))
            return false;
        Ptr<ID3D11Resource> resource;
        source->GetResource(&resource);
        Ptr<ID3D11Texture2D> texture;
        if (FAILED(resource.As(&texture)))
            return false;
        D3D11_TEXTURE2D_DESC input{};
        texture->GetDesc(&input);
        const UINT mip = cube ? view.TextureCube.MostDetailedMip : view.Texture2D.MostDetailedMip;
        if (input.ArraySize != (cube ? 6u : 1u) || input.SampleDesc.Count != 1 || !input.Width ||
            !input.Height || input.Width > 16384 || input.Height > 16384 || input.MipLevels > 15 ||
            mip >= input.MipLevels)
            return false;
        if (cube && ((input.MiscFlags & D3D11_RESOURCE_MISC_TEXTURECUBE) == 0 || input.Width != input.Height))
            return false;
        UINT w = std::max(1u, input.Width >> mip), h = std::max(1u, input.Height >> mip);
        if (!Init(device))
            return false;
        if (cube && !skyCube_ &&
            FAILED(device->CreatePixelShader(AmbienceSkyPixelShader.data(), AmbienceSkyPixelShader.size(),
                                             nullptr, &skyCube_)))
            return false;
        float factor = std::min({1.f, float(maxWidth) / float(w), float(maxHeight) / float(h)});
        w = std::max(1u, UINT(float(w) * factor));
        h = std::max(1u, UINT(float(h) * factor));
        D3D11_TEXTURE2D_DESC desc{};
        desc.Width = w;
        desc.Height = h;
        desc.MipLevels = desc.ArraySize = 1;
        desc.Format = DXGI_FORMAT_R8G8B8A8_TYPELESS;
        desc.SampleDesc.Count = 1;
        desc.Usage = D3D11_USAGE_DEFAULT;
        desc.BindFlags = D3D11_BIND_RENDER_TARGET;
        ClearFlight();
        if (FAILED(device->CreateTexture2D(&desc, nullptr, &render_)))
            return false;
        D3D11_RENDER_TARGET_VIEW_DESC rt{};
        rt.Format = srgb && !decode && !cube ? DXGI_FORMAT_R8G8B8A8_UNORM_SRGB : DXGI_FORMAT_R8G8B8A8_UNORM;
        rt.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
        if (FAILED(device->CreateRenderTargetView(render_.Get(), &rt, &target_))) {
            ClearFlight();
            return false;
        }
        desc.Usage = D3D11_USAGE_STAGING;
        desc.BindFlags = 0;
        desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
        D3D11_QUERY_DESC q{};
        q.Query = D3D11_QUERY_EVENT;
        if (FAILED(device->CreateTexture2D(&desc, nullptr, &staging_)) ||
            FAILED(device->CreateQuery(&q, &query_))) {
            ClearFlight();
            return false;
        }
        if (decode && srgb) {

            auto raw = input;
            raw.Format = RawFormat(view.Format);
            raw.Usage = D3D11_USAGE_DEFAULT;
            raw.BindFlags = D3D11_BIND_SHADER_RESOURCE;
            raw.CPUAccessFlags = raw.MiscFlags = 0;
            auto rawDesc = view;
            rawDesc.Format = raw.Format;
            if (FAILED(device->CreateTexture2D(&raw, nullptr, &rawColor_)) ||
                FAILED(device->CreateShaderResourceView(rawColor_.Get(), &rawDesc, &rawView_))) {
                ClearFlight();
                return false;
            }
            source = rawView_.Get();
        }
        context->ClearState();
        if (rawColor_)
            context->CopyResource(rawColor_.Get(), resource.Get());
        ID3D11RenderTargetView* target = target_.Get();
        context->OMSetRenderTargets(1, &target, nullptr);
        float factors[4]{};
        context->OMSetBlendState(blend_.Get(), factors, 0xffffffff);
        context->OMSetDepthStencilState(depth_.Get(), 0);
        D3D11_VIEWPORT viewport{0, 0, float(w), float(h), 0, 1};
        context->RSSetViewports(1, &viewport);
        context->RSSetState(raster_.Get());
        context->IASetInputLayout(nullptr);
        context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        context->VSSetShader(vs_.Get(), nullptr, 0);
        context->PSSetShader(cube ? skyCube_.Get() : decode ? ycocg_.Get() : ps_.Get(), nullptr, 0);
        auto sampler = sampler_.Get();
        context->PSSetSamplers(0, 1, &sampler);
        context->PSSetShaderResources(0, 1, &source);
        context->Draw(3, 0);
        ID3D11ShaderResourceView* none = nullptr;
        context->PSSetShaderResources(0, 1, &none);
        context->OMSetRenderTargets(0, nullptr, nullptr);
        context->CopyResource(staging_.Get(), render_.Get());
        context->End(query_.Get());
        job_ = job;
        started_ = now;
        width_ = w;
        height_ = h;
        pending_ = true;
        return true;
    }
    bool Poll(ID3D11DeviceContext* context, std::uint64_t now, Completion& out) {
        out = {};
        if (!pending_)
            return false;
        if (now < started_ || now - started_ > 3000) {
            out.job = job_;
            ClearFlight();
            return true;
        }
        BOOL complete = FALSE;
        HRESULT hr =
            context->GetData(query_.Get(), &complete, sizeof(complete), D3D11_ASYNC_GETDATA_DONOTFLUSH);
        if (hr == S_FALSE || (hr == S_OK && !complete))
            return false;
        out.job = job_;
        if (FAILED(hr)) {
            ClearFlight();
            return true;
        }
        D3D11_MAPPED_SUBRESOURCE mapped{};
        hr = context->Map(staging_.Get(), 0, D3D11_MAP_READ, D3D11_MAP_FLAG_DO_NOT_WAIT, &mapped);
        if (hr == DXGI_ERROR_WAS_STILL_DRAWING)
            return false;
        if (SUCCEEDED(hr)) {
            if (mapped.pData && mapped.RowPitch >= width_ * 4) {

                try {
                    auto image = std::make_shared<ProfileImage>();
                    image->width = int(width_);
                    image->height = int(height_);
                    image->rgba.resize(std::size_t(width_) * height_ * 4);
                    for (UINT y = 0; y < height_; ++y)
                        std::memcpy(image->rgba.data() + std::size_t(y) * width_ * 4,
                                    static_cast<const unsigned char*>(mapped.pData) +
                                        std::size_t(y) * mapped.RowPitch,
                                    std::size_t(width_) * 4);
                    out.image = std::move(image);
                } catch (...) {
                    context->Unmap(staging_.Get(), 0);
                    ClearFlight();
                    throw;
                }
            }
            context->Unmap(staging_.Get(), 0);
        }
        ClearFlight();
        return true;
    }
};
}
