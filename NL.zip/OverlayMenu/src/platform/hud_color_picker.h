#pragma once
#include "presets_ui.h"
#include "popup_paint_transition.h"
#include "profile_popup.h"
#include <cstdio>
#include <cstring>
namespace menu {

inline void DrawPickerPoint(Canvas& image, Box b, float s, Color color) {
    for (int y = 0; y < image.height; ++y)
        for (int x = 0; x < image.width; ++x) {
            float coverage = std::clamp(.5f - BoxDistance(b, 4 * s, x + .5f, y + .5f), 0.f, 1.f);
            image.Blend(x, y, PickerOver(PickerChecker(x + .5f - b.x, y + .5f - b.y, b.h / 3), color),
                        coverage);
        }
}
struct HudColorPicker {

    struct RasterCache {
        std::vector<float> inputs;
        std::shared_ptr<Canvas> image;
        std::uint64_t stamp = 0, builds = 0;
        template <class Build> std::shared_ptr<Canvas> Get(std::initializer_list<float> next, Build build) {
            if (image && inputs.size() == next.size() &&
                std::equal(inputs.begin(), inputs.end(), next.begin()))
                return image;
            inputs.assign(next);
            stamp = 14695981039346656037ull;
            for (float v : inputs) {
                std::uint32_t bits = 0;
                std::memcpy(&bits, &v, sizeof bits);
                for (int i = 0; i < 4; ++i) {
                    stamp ^= (bits >> (i * 8)) & 255;
                    stamp *= 1099511628211ull;
                }
            }
            image = build();
            ++builds;
            return image;
        }
        void Clear() {
            image.reset();
            inputs.clear();
        }
    } svCache, barsCache;
    void DropRasters() {
        svCache.Clear();
        barsCache.Clear();
    }
    LanguageCatalog* languages = nullptr;

    int entryCount = 3;
    unsigned alphaLockMask = 0;
    bool AlphaLocked() const {
        return index >= 0 && index < 32 && ((alphaLockMask >> unsigned(index)) & 1u) != 0;
    }
    std::array<std::string, 3> entryLabels{{"visuals_world_hud_crosshairs_penetration_base",
                                            "visuals_world_hud_crosshairs_penetration_penetrable",
                                            "visuals_world_hud_crosshairs_penetration_ontarget"}};
    void ConfigureEntries(int count, const std::array<std::string, 3>& labels) {
        entryCount = std::clamp(count, 1, 3);
        entryLabels = labels;
    }
    float footerMetric = 18;
    void SetMetrics(Fonts& fonts, float s) {
        footerMetric = (fonts.PixelHeight(1, 12 * s) + 6 * s) / s;
    }

    bool externalMenuTransitions = false;
    PopupPaintTransition menuTransition;
    float mouseX = -1, mouseY = -1;
    Box saveBox{}, menuBox{};
    bool menuRelease = false;
    std::map<int, PresetMotion> hoverFill, pointExpand;
    std::array<NativeColorWidth, 8> widths{};
    std::array<std::string, 8> widthRGBA{};
    float Motion(int action) const {
        auto it = hoverFill.find(action);
        return it == hoverFill.end() ? 0.f : it->second.value;
    }
    void Tick(float dt, bool interactive = true) {
        menuTransition.Tick(interactive && (formatsOpen || headerOpen) ? 1.f : 0.f, dt);
        int a = interactive ? HitAt(mouseX, mouseY) : -1;
        for (const auto& t : hits) {
            bool open = (t.action == Header && headerOpen) || (t.action == Format && formatsOpen);
            bool point = (entries && t.action >= 340 && t.action < 340 + entryCount) ||
                         (scope && (t.action == 330 || t.action == 331));
            bool selected = point && (entries ? index == 5 + t.action - 340 : index == 1 + t.action - 330);
            float target = point ? (held == t.action ? 1.f
                                    : a == t.action  ? .75f
                                    : selected       ? .5f
                                                     : 0.f)
                                 : (open || held == t.action ? 1.f
                                    : a == t.action          ? .5f
                                                             : 0.f);
            hoverFill[t.action].Tick(interactive ? target : 0.f, dt);
            if (entries && point)
                pointExpand[t.action].Tick(selected ? 1.f : 0.f, dt);
        }
        for (auto& w : widths)
            w.Tick(dt);
    }

    std::u32string Label(const std::string& key) const {
        if (languages)
            return languages->Label(key);
        auto it = DefaultLanguageStrings().find(key);
        return DecodeUTF8(it == DefaultLanguageStrings().end() ? key : it->second);
    }
    enum { SV = 300, Hue = 301, Alpha = 302, Save = 304, Format = 310, AlphaField = 315, Header = 316 };
    struct Hit {
        Box box;
        int action;
    };
    std::vector<Hit> hits;
    Box box{}, sv{}, hueBar{}, alphaBar{}, formatBox{}, alphaField{}, headerBox{};
    std::array<Box, 3> fields{};
    int index = 0, format = 2, field = -1, held = -1;
    bool scope = false, entries = false, formatsOpen = false, headerOpen = false, selectAll = false;
    float h = 0, sat = 0, val = 0, scale = 1;
    std::string input;
    std::vector<Color> saved;
    std::uint64_t revision = 1;
    int syncedIndex = -1;
    Color synced{};
    static std::string Hex(Color c) {
        char t[12]{};
        std::snprintf(t, sizeof t, "%02X%02X%02X%02X", int(Canvas::Byte(c.r)), int(Canvas::Byte(c.g)),
                      int(Canvas::Byte(c.b)), int(Canvas::Byte(c.a)));
        return t;
    }
    static bool Same(Color a, Color b) {
        return Hex(a) == Hex(b);
    }
    void Reset(int i, bool isScope = false, bool isEntries = false) {
        menuTransition.Clear();
        alphaLockMask = 0;
        entryCount = 3;
        entryLabels = {{"visuals_world_hud_crosshairs_penetration_base",
                        "visuals_world_hud_crosshairs_penetration_penetrable",
                        "visuals_world_hud_crosshairs_penetration_ontarget"}};
        index = i;
        scope = isScope;
        entries = isEntries;
        field = held = -1;
        formatsOpen = headerOpen = false;
        menuRelease = false;
        menuBox = {};
        syncedIndex = -1;
        h = 0;
        mouseX = mouseY = -1;
        hoverFill.clear();
        pointExpand.clear();
        input.clear();
        ++revision;
    }
    void Sync(const Settings& cfg) {
        if (scope) {
            if (cfg.worldHud.scopeColorMode == 0)
                index = 0;
            else if (index != 1 && index != 2)
                index = 1;
        }
        auto c = cfg.worldHud.colors[std::size_t(index)];
        if (syncedIndex == index && Same(c, synced))
            return;
        float mx = std::max({c.r, c.g, c.b}), mn = std::min({c.r, c.g, c.b}), d = mx - mn;
        val = mx;
        sat = mx ? d / mx : 0;
        if (d > 0) {
            float q = mx == c.r ? (c.g - c.b) / d : mx == c.g ? 2 + (c.b - c.r) / d : 4 + (c.r - c.g) / d;
            h = std::fmod(q / 6 + 1, 1.f);
        }
        synced = c;
        syncedIndex = index;
        ++revision;
    }
    float Height(float s) const {
        return ((scope || entries ? 360.f : 322.f) - (AlphaLocked() ? 20.f : 0.f) + footerMetric +
                (saved.empty() ? 0.f : 8.f + 27.f * std::ceil(float(saved.size()) / 9))) *
               s;
    }
    bool Editing() const {
        return field >= 0;
    }
    int HitAt(float x, float y) const {
        for (auto i = hits.rbegin(); i != hits.rend(); ++i)
            if (i->box.Contains(x, y))
                return i->action;
        return -1;
    }
    std::string FieldText(int n, const Settings& cfg) const {
        auto c = cfg.worldHud.colors[std::size_t(index)];
        if (n == 3)
            return std::to_string(int(std::round(c.a * (format == 2 ? 100 : 255)))) +
                   (format == 2 ? "%" : "");
        if (format == 2)
            return AlphaLocked() ? Hex(c).substr(0, 6) : Hex(c);
        float v = format == 0 ? (n == 0   ? c.r
                                 : n == 1 ? c.g
                                          : c.b) *
                                    255
                              : (n == 0   ? h
                                 : n == 1 ? sat
                                          : val) *
                                    255;
        return std::to_string(int(std::round(v)));
    }
    bool Commit(Settings& cfg) {
        if (field < 0)
            return true;
        try {
            auto text = input;
            auto c = cfg.worldHud.colors[std::size_t(index)];
            if (field == 3) {
                if (AlphaLocked()) {
                    field = -1;
                    input.clear();
                    return true;
                }
                if (!text.empty() && text.back() == '%')
                    text.pop_back();
                std::size_t n = 0;
                float v = std::stof(text, &n);
                if (n != text.size() || !std::isfinite(v))
                    return false;
                c.a = std::clamp(v / (format == 2 ? 100.f : 255.f), 0.f, 1.f);
            } else if (format == 2) {
                if (!text.empty() && text.front() == '#')
                    text.erase(0, 1);
                if (text.size() != 6 && text.size() != 8)
                    return false;
                std::size_t n = 0;
                auto v = std::stoul(text, &n, 16);
                if (n != text.size())
                    return false;
                if (n == 6)
                    c = {float((v >> 16) & 255) / 255, float((v >> 8) & 255) / 255, float(v & 255) / 255,
                         c.a};
                else
                    c = {float((v >> 24) & 255) / 255, float((v >> 16) & 255) / 255,
                         float((v >> 8) & 255) / 255, float(v & 255) / 255};
            } else {
                std::size_t n = 0;
                float v = std::stof(text, &n);
                if (n != text.size() || !std::isfinite(v))
                    return false;
                if (format == 0) {
                    v = std::clamp(v / 255, 0.f, 1.f);
                    if (field == 0)
                        c.r = v;
                    else if (field == 1)
                        c.g = v;
                    else
                        c.b = v;
                } else {
                    if (field == 0)
                        h = std::clamp(v / 255, 0.f, 1.f);
                    else if (field == 1)
                        sat = std::clamp(v / 255, 0.f, 1.f);
                    else
                        val = std::clamp(v / 255, 0.f, 1.f);
                    auto a = c.a;
                    c = ProfileHSV(h, sat, val);
                    c.a = a;
                }
            }
            if (AlphaLocked())
                c.a = 1;
            cfg.worldHud.colors[std::size_t(index)] = c;
            syncedIndex = -1;
            Sync(cfg);
            field = -1;
            input.clear();
            ++revision;
            return true;
        } catch (...) {
            return false;
        }
    }
    void Drag(float x, float y, Settings& cfg) {
        auto c = cfg.worldHud.colors[std::size_t(index)];
        if (held == SV) {
            sat = std::clamp((x - sv.x) / sv.w, 0.f, 1.f);
            val = 1 - std::clamp((y - sv.y) / sv.h, 0.f, 1.f);
        } else if (held == Hue)
            h = std::clamp((x - hueBar.x) / hueBar.w, 0.f, .9999f);
        else if (held == Alpha) {
            if (AlphaLocked())
                return;
            c.a = std::clamp((x - alphaBar.x) / std::max(1.f, alphaBar.w - 1.f), 0.f, 1.f);
            cfg.worldHud.colors[std::size_t(index)] = c;
            synced = c;
            ++revision;
            return;
        } else
            return;
        auto a = AlphaLocked() ? 1.f : c.a;
        c = ProfileHSV(h, sat, val);
        c.a = a;
        cfg.worldHud.colors[std::size_t(index)] = c;
        synced = c;
        syncedIndex = index;
        ++revision;
    }
    bool Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        if (held == SV || held == Hue || held == Alpha) {
            Drag(x, y, cfg);
            return true;
        }
        return false;
    }
    bool Click(float x, float y, bool down, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        int a = HitAt(x, y);
        if (!down && menuRelease) {
            menuRelease = false;
            held = -1;
            return true;
        }
        if (down && (formatsOpen || headerOpen) &&
            !((a >= 320 && a < 323) || (a >= 340 && a < 342) || a == Format || a == Header)) {
            formatsOpen = headerOpen = false;
            held = -1;
            menuRelease = true;
            return true;
        }
        if (down) {
            if (a < 0) {
                if (formatsOpen || headerOpen) {
                    formatsOpen = headerOpen = false;
                    return true;
                }
                if (field >= 0)
                    Commit(cfg);
                return box.Contains(x, y);
            }
            if (field >= 0 && a != 400 + field && !Commit(cfg))
                return true;
            held = a;
            if (a == SV || a == Hue || a == Alpha)
                Drag(x, y, cfg);
            return true;
        }
        if (held == SV || held == Hue || held == Alpha) {
            Drag(x, y, cfg);
            held = -1;
            return true;
        }
        int was = held;
        held = -1;
        if (a < 0 || a != was)
            return was >= 0 || box.Contains(x, y);
        if (a == Format) {
            formatsOpen = !formatsOpen;
            headerOpen = false;
        } else if (a == Header) {
            headerOpen = !headerOpen;
            formatsOpen = false;
        } else if (a >= 320 && a < 323) {
            format = a - 320;
            formatsOpen = false;
            field = -1;
        } else if (a >= 340 && a < 343) {
            if (scope) {
                if (a == 341 && cfg.worldHud.value[1] != 1)
                    return true;
                cfg.worldHud.scopeColorMode = a - 340;
                index = cfg.worldHud.scopeColorMode ? 1 : 0;
            } else if (entries && a < 340 + entryCount)
                index = 5 + a - 340;
            headerOpen = false;
            field = -1;
            syncedIndex = -1;
            Sync(cfg);
        } else if (a == 330 || a == 331) {
            index = scope ? (cfg.worldHud.scopeColorMode ? 1 + (a - 330) : 0) : index;
            syncedIndex = -1;
            Sync(cfg);
        } else if (a >= 400 && a < 404) {
            if (a == 403 && AlphaLocked())
                return true;
            field = a - 400;
            input = FieldText(field, cfg);
            selectAll = true;
        } else if (a == Save) {
            if (!Commit(cfg))
                return true;
            auto c = cfg.worldHud.colors[std::size_t(index)];
            if (AlphaLocked())
                c.a = 1;
            saved.erase(std::remove_if(saved.begin(), saved.end(), [&](Color v) { return Same(v, c); }),
                        saved.end());
            saved.push_back(c);
        } else if (a >= 500 && a < 500 + int(saved.size())) {
            cfg.worldHud.colors[std::size_t(index)] = saved[std::size_t(a - 500)];
            if (AlphaLocked())
                cfg.worldHud.colors[std::size_t(index)].a = 1;
            syncedIndex = -1;
            Sync(cfg);
        }
        ++revision;
        return true;
    }
    bool Key(int k, Settings& cfg, bool ctrl = false) {
        if (k == 27) {
            if (field >= 0) {
                field = -1;
                input.clear();
                return true;
            }
            if (formatsOpen || headerOpen) {
                formatsOpen = headerOpen = false;
                return true;
            }
            return false;
        }
        if (field < 0)
            return false;
        if (k == 13)
            Commit(cfg);
        else if (ctrl && k == 'A')
            selectAll = true;
        else if (k == 8 || k == 46) {
            if (selectAll)
                input.clear();
            else if (!input.empty())
                input.pop_back();
            selectAll = false;
        }
        ++revision;
        return true;
    }
    bool Character(char16_t c) {
        if (field < 0)
            return false;
        if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f') || c == '#' ||
            c == '%' || c == '.') {
            if (selectAll) {
                input.clear();
                selectAll = false;
            }
            if (input.size() < 12)
                input += char(c);
            ++revision;
        }
        return true;
    }
    void Draw(PresetsUI& ui, int z, Fonts& fonts, const Settings& cfg, Box at) {
        Sync(cfg);
        SetMetrics(fonts, cfg.scale);
        float s = scale = cfg.scale, F = fonts.PixelHeight(1, 12 * s);
        box = {at.x, at.y, 265 * s, Height(s)};
        hits.clear();
        auto pal = CurrentPalette(cfg);
        auto& draws = ui.layers[std::size_t(z)].draw;
        auto clip = ui.layers[std::size_t(z)].box;
        auto rect = [&](Box b, Color c, float radius = 0, float stroke = 0) {
            PresetDraw d{b, c, radius, stroke, 15, {}, false};
            d.clipped = true;
            d.clip = clip;
            draws.push_back(std::move(d));
        };
        auto text = [&](Box b, const std::u32string& t, Color c, int f = 1, float px = 12) {
            PresetDraw d{b, c, 0, 0, 15, t, f == 3};
            d.font = f;
            d.textSize = px;
            d.clipped = true;
            d.clip = clip;
            draws.push_back(std::move(d));
        };
        auto hit = [&](Box b, int a) {
            b = PresetIntersect(b, clip);
            if (b.w > 0 && b.h > 0)
                hits.push_back({b, a});
        };
        auto raster = [&](Box b, std::shared_ptr<Canvas> image, std::uint64_t stamp) {
            PresetDraw d{b, {1, 1, 1, 1}, 0, 0, 15, {}, false};
            d.raster = image;
            d.rasterStamp = stamp;
            d.clipped = true;
            d.clip = clip;
            draws.push_back(std::move(d));
        };

        if (scope) {
            auto value = Label(cfg.worldHud.scopeColorMode ? "color_gradient" : "color_default");
            float hw = std::trunc(fonts.NativeTextSize(0, 13 * s, value).w + .95f) +
                       std::trunc(fonts.NativeTextSize(3, 13 * s, U"\uf107").w + .95f) + 15 * s;
            float hf = fonts.PixelHeight(0, 13 * s), hh = hf + 6 * s;
            headerBox = {at.x + 10 * s, at.y + 10 * s, hw, hh};
            Color base = pal[33];
            base.a *= .2f;
            rect(headerBox, Mix(base, pal[13], Motion(Header)), 6 * s);
            float af = fonts.PixelHeight(2, 11 * s), aw = fonts.NativeTextSize(3, 11 * s, U"\uf107").w;
            text({headerBox.x + 6 * s, headerBox.y + (hh - af) * .5f + s, aw, af}, U"\uf107", pal[0], 3, 11);
            text({headerBox.x + 9 * s + aw, headerBox.y + 3 * s, headerBox.w - 9 * s - aw, hf}, value,
                 Mix(pal[14], pal[2], Motion(Header)), 0, 13);
            hit(headerBox, Header);

            if (cfg.worldHud.scopeColorMode)
                for (int n = 0; n < 2; ++n) {
                    float ph = std::max(14 * s, hf) + 6 * s;
                    Box frame{at.x + (196.f + 33 * n) * s, at.y + 10 * s, 26 * s, ph};
                    Box b{frame.x + 6 * s, frame.y + (ph - 14 * s) * .5f, 14 * s, 14 * s};
                    int target = 1 + n;
                    rect(frame, PickerButtonFill(pal[33], Motion(330 + n)), 7.8f * s);
                    auto sample = std::make_shared<Canvas>(int(std::ceil(b.w)), int(std::ceil(b.h)));
                    DrawPickerPoint(*sample, {0, 0, b.w, b.h}, s, cfg.worldHud.colors[std::size_t(target)]);
                    raster(b, sample,
                           0x504f494e0000ull + std::uint64_t(target) * 0x100000000ull +
                               std::stoul(Hex(cfg.worldHud.colors[std::size_t(target)]), nullptr, 16));
                    hit(frame, 330 + n);
                }
        }

        if (entries) {
            const std::array<std::u32string, 3> labels{
                {Label(entryLabels[0]), Label(entryLabels[1]), Label(entryLabels[2])}};
            std::array<float, 3> bw{}, amount{};
            float total = float(entryCount - 1) * 7 * s;
            for (int n = 0; n < entryCount; ++n) {
                auto it = pointExpand.find(340 + n);
                amount[std::size_t(n)] = it == pointExpand.end() || !it->second.initialized
                                             ? (index == 5 + n ? 1.f : 0.f)
                                             : it->second.value;
                bw[std::size_t(n)] =
                    26 * s +
                    amount[std::size_t(n)] *
                        (labels[std::size_t(n)].empty()
                             ? 0.f
                             : 6 * s + std::trunc(fonts.NativeTextSize(0, 13 * s, labels[std::size_t(n)]).w +
                                                  .95f));
                total += bw[std::size_t(n)];
            }
            float x = at.x + 10 * s + (245 * s - total) * .5f,
                  ph = std::max(14 * s, fonts.PixelHeight(0, 13 * s)) + 6 * s;
            for (int n = 0; n < entryCount; ++n) {
                Box b{x, at.y + 10 * s, bw[std::size_t(n)], ph};
                rect(b, PickerButtonFill(pal[33], Motion(340 + n)), 7.8f * s);
                Box sample{b.x + 6 * s, b.y + (ph - 14 * s) * .5f, 14 * s, 14 * s};
                auto image = std::make_shared<Canvas>(int(std::ceil(sample.w)), int(std::ceil(sample.h)));
                DrawPickerPoint(*image, {0, 0, sample.w, sample.h}, s,
                                cfg.worldHud.colors[std::size_t(5 + n)]);
                raster(sample, image,
                       0x50454e000000ull + std::uint64_t(n) * 0x100000000ull +
                           std::stoul(Hex(cfg.worldHud.colors[std::size_t(5 + n)]), nullptr, 16));
                if (amount[std::size_t(n)] > 0) {
                    float tf = fonts.PixelHeight(0, 13 * s);
                    text({sample.x + 20 * s, b.y + (ph - tf) * .5f, std::max(0.f, b.w - 32 * s), tf},
                         labels[std::size_t(n)], pal[0], 0, 13);
                    draws.back().clip = PresetIntersect(clip, b);
                }
                hit(b, 340 + n);
                x += b.w + 7 * s;
            }
        }

        auto separator = [&](float y) {
            rect({at.x + 10 * s, y, 245 * s, s}, pal[34]);
            draws.back().pixelLine = true;
        };
        if (scope || entries)
            separator(at.y + 41 * s);
        sv = {at.x + 10 * s, at.y + (scope || entries ? 48 : 10) * s, 245 * s, 245 * s};
        hueBar = {sv.x, sv.y + sv.h + 12 * s, sv.w, 8 * s};
        const bool alphaVisible = !AlphaLocked();
        alphaBar = alphaVisible ? Box{sv.x, hueBar.y + hueBar.h + 12 * s, sv.w, 8 * s} : Box{};
        float barsBottom = alphaVisible ? alphaBar.y + alphaBar.h : hueBar.y + hueBar.h;
        float footer = barsBottom + 17 * s;
        separator(barsBottom + 7 * s);
        formatBox = {sv.x, footer, 49 * s, 18 * s};
        alphaField = {at.x + 194 * s, footer, 42 * s, 18 * s};
        auto c = cfg.worldHud.colors[std::size_t(index)];
        if (!alphaVisible)
            c.a = 1;
        float pad = 12 * s;
        Box svRaster{sv.x - pad, sv.y - pad, sv.w + 2 * pad, sv.h + 2 * pad};
        auto img = svCache.Get({s, h, sat, val, sv.x, sv.y, sv.w, sv.h}, [&] {
            auto img = std::make_shared<Canvas>(int(std::ceil(svRaster.w)), int(std::ceil(svRaster.h)));
            for (int y = 0; y < img->height; ++y)
                for (int x = 0; x < img->width; ++x) {
                    auto v = ProfileHSV(h, std::clamp((float(x) - pad) / sv.w, 0.f, 1.f),
                                        1 - std::clamp((float(y) - pad) / sv.h, 0.f, 1.f));
                    float cov = std::clamp(.5f - BoxDistance({pad, pad, sv.w, sv.h}, 8 * s, x + .5f, y + .5f),
                                           0.f, 1.f);
                    img->Blend(x, y, v, cov);
                }
            float mx = pad + std::clamp(std::round(sv.x + sat * sv.w) - sv.x, 2.f, sv.w - 2.f),
                  my = pad + std::clamp(std::round(sv.y + (1 - val) * sv.h) - sv.y, 2.f, sv.h - 2.f);
            DrawMenuCircleShadow(*img, mx, my, 8 * s, 2 * s, 2 * s, 10 * s, {0, 0, 0, 128.f / 255});
            img->RoundRect({mx - 8 * s, my - 8 * s, 16 * s, 16 * s}, 8 * s, {1, 1, 1, 1});
            img->RoundRect({mx - 6 * s, my - 6 * s, 12 * s, 12 * s}, 6 * s, ProfileHSV(h, sat, val));
            return img;
        });
        raster(svRaster, img, svCache.stamp);
        float barPad = 16 * s;
        Box rasterBars{hueBar.x - barPad, hueBar.y - 10 * s, hueBar.w + 2 * barPad,
                       barsBottom - hueBar.y + 20 * s};
        auto bars = barsCache.Get(
            {float(alphaVisible), s, h, c.r, c.g, c.b, c.a, hueBar.x, hueBar.y, hueBar.w, alphaBar.x,
             alphaBar.y, alphaBar.w, alphaBar.h},
            [&] {
                auto bars =
                    std::make_shared<Canvas>(int(std::ceil(rasterBars.w)), int(std::ceil(rasterBars.h)));
                for (int y = 0; y < bars->height; ++y)
                    for (int x = 0; x < bars->width; ++x) {
                        float gx = x + .5f - barPad, gy = rasterBars.y + y + .5f;
                        bool hue = gy >= hueBar.y && gy < hueBar.y + hueBar.h,
                             alpha = alphaVisible && gy >= alphaBar.y && gy < alphaBar.y + alphaBar.h;
                        if (!hue && !alpha)
                            continue;
                        Box bar{barPad, (hue ? hueBar.y : alphaBar.y) - rasterBars.y, hueBar.w, 8 * s};
                        float cov = std::clamp(.5f - BoxDistance(bar, 4 * s, x + .5f, y + .5f), 0.f, 1.f);
                        if (hue)
                            bars->Blend(x, y, ProfileHSV(std::clamp(gx / hueBar.w, 0.f, .9999f), 1, 1), cov);
                        else {
                            float a = std::clamp(gx / alphaBar.w, 0.f, 1.f);
                            auto col =
                                PickerOver(PickerChecker(gx, gy - alphaBar.y, alphaBar.h * .5f),
                                           {float(Canvas::Byte(c.r)) / 255, float(Canvas::Byte(c.g)) / 255,
                                            float(Canvas::Byte(c.b)) / 255, a});
                            bars->Blend(x, y, col, cov);
                        }
                    }
                float hx = std::round(hueBar.x + h * hueBar.w) - rasterBars.x,
                      hy = hueBar.y + 4 * s - rasterBars.y;
                bars->RoundRect({hx - 6 * s, hy - 10 * s, 12 * s, 20 * s}, 8 * s, {1, 1, 1, 1});
                bars->RoundRect({hx - 3 * s, hy - 7 * s, 6 * s, 14 * s}, 8 * s, ProfileHSV(h, 1, 1));
                if (alphaVisible) {
                    float ax = barPad + std::clamp(std::round(alphaBar.x + c.a * alphaBar.w) - alphaBar.x,
                                                   2 * s, alphaBar.w - 2 * s),
                          ay = alphaBar.y + 4 * s - rasterBars.y;
                    DrawPickerAlphaMarker(*bars, ax, ay, s);
                }
                return bars;
            });
        raster(rasterBars, bars, barsCache.stamp);

        hit(sv, SV);
        hit({hueBar.x - 6 * s, hueBar.y - 6 * s, hueBar.w + 12 * s, 20 * s}, Hue);
        if (!AlphaLocked())
            hit({alphaBar.x - 6 * s, alphaBar.y - 3 * s, alphaBar.w + 12 * s, 14 * s}, Alpha);

        auto fm = MeasurePickerFormat(fonts, s, format);
        float formatH = F + 6 * s;
        auto formatLabel = PickerFormatLabel(format);
        float formatArrow = fm.arrow;
        formatBox = {sv.x, footer, fm.opener, formatH};
        rect(formatBox, PickerButtonFill(pal[33], Motion(Format)), 6 * s);
        float arrowF = fonts.PixelHeight(2, 11 * s);
        text({formatBox.x + 6 * s, footer + (formatH - arrowF) * .5f + s, formatArrow, arrowF}, U"\uf107",
             pal[0], 3, 11);
        text({formatBox.x + 9 * s + formatArrow, footer + 3 * s, formatBox.w - 9 * s - formatArrow, F},
             formatLabel, Mix(pal[14], pal[2], Motion(Format)), 1, 12);
        hit(formatBox, Format);
        Box save = saveBox = {sv.x + sv.w - formatH, footer, formatH, formatH};
        rect(save, PickerButtonFill(pal[33], Motion(Save)), 6 * s);
        float iw = fonts.NativeTextSize(3, 12 * s, U"\ue197").w;
        text({save.x + (save.w - iw) * .5f, save.y + 3 * s, iw, F}, U"\ue197",
             Mix(pal[14], pal[2], Motion(Save)), 3);
        hit(save, Save);
        float componentW =
            std::trunc(fonts.NativeTextSize(1, 12 * s, format == 2 ? U"100%" : U"255").w + .95f) + 12 * s;
        alphaField = alphaVisible ? Box{save.x - 3 * s - componentW, footer, componentW, formatH} : Box{};
        const float componentRight = alphaVisible ? alphaField.x : save.x;
        if (format == 2) {
            auto run = ASCII(FieldText(0, cfg));
            float digits = std::trunc(fonts.NativeTextSize(1, 12 * s, run).w + .95f),
                  desired = 18 * s + 12 * s + fonts.NativeTextSize(1, 12 * s, U"#").w + 1 * s + digits;
            auto wi = std::size_t(index);
            auto rgba = Hex(c);
            widths[wi].Observe(desired, widthRGBA[wi] != rgba);
            widthRGBA[wi] = rgba;
            float w = widths[wi].value;
            fields[0] = {componentRight - 3 * s - w, footer, w, formatH};
            rect(fields[0], PickerFieldFill(pal[33], field == 0 ? 1.f : Motion(400)), 6 * s);
            {
                Box sb{fields[0].x + 6 * s, footer + (formatH - 12 * s) * .5f, 12 * s, 12 * s};
                auto sample = std::make_shared<Canvas>(int(std::ceil(sb.w)), int(std::ceil(sb.h)));
                for (int yy = 0; yy < sample->height; ++yy)
                    for (int xx = 0; xx < sample->width; ++xx) {
                        auto col = PickerOver(PickerChecker(xx + .5f, yy + .5f, sb.h / 3), c);
                        float coverage = std::clamp(
                            .5f - BoxDistance({0, 0, sb.w, sb.h}, 3 * s, xx + .5f, yy + .5f), 0.f, 1.f);
                        sample->Blend(xx, yy, col, coverage);
                    }
                raster(sb, sample,
                       0x53414d000000ull + (std::uint64_t(Canvas::Byte(c.r)) << 24) +
                           (std::uint64_t(Canvas::Byte(c.g)) << 16) +
                           (std::uint64_t(Canvas::Byte(c.b)) << 8) + Canvas::Byte(c.a));
            }
            text({fields[0].x + 24 * s, footer + 3 * s, fields[0].w - 27 * s, F},
                 ASCII(std::string("#") +
                       (field == 0 ? (!input.empty() && input.front() == '#' ? input.substr(1) : input)
                                   : FieldText(0, cfg))),
                 pal[14]);
            hit(fields[0], 400);
        } else {
            for (int n = 0; n < 3; ++n) {
                fields[std::size_t(n)] = {componentRight - float(3 - n) * (componentW + 3 * s), footer,
                                          componentW, formatH};
                rect(fields[std::size_t(n)], PickerFieldFill(pal[33], field == n ? 1.f : Motion(400 + n)),
                     6 * s);
                text({fields[std::size_t(n)].x + 6 * s, footer + 3 * s, componentW - 12 * s, F},
                     ASCII(field == n ? input : FieldText(n, cfg)), pal[14]);
                hit(fields[std::size_t(n)], 400 + n);
            }
        }
        if (alphaVisible) {
            rect(alphaField, PickerFieldFill(pal[33], field == 3 ? 1.f : Motion(403)), 6 * s);
            text({alphaField.x + 6 * s, footer + 3 * s, alphaField.w - 12 * s, F},
                 ASCII(field == 3 ? input : FieldText(3, cfg)), pal[14]);
            hit(alphaField, 403);
        }

        if (!saved.empty())
            separator(footer + formatH + 7 * s);
        for (int n = 0; n < int(saved.size()); ++n) {
            int order = int(saved.size()) - 1 - n;
            Box b{sv.x + float(n % 9) * 27 * s, footer + formatH + 15 * s + float(n / 9) * 27 * s, 20 * s,
                  20 * s};
            rect({b.x - 4 * s, b.y - 4 * s, b.w + 8 * s, b.h + 8 * s},
                 PickerButtonFill(pal[33], Motion(500 + order)), 6 * s);
            auto tile = std::make_shared<Canvas>(int(std::ceil(b.w)), int(std::ceil(b.h)));
            DrawPickerSaved(*tile, {0, 0, b.w, b.h}, s, saved[std::size_t(order)], pal[30]);
            raster(b, tile,
                   0x54494c450000ull + std::uint64_t(order) * 0x100000000ull +
                       std::uint64_t(Canvas::Byte(saved[std::size_t(order)].r)) * 0x1000000ull +
                       std::uint64_t(Canvas::Byte(saved[std::size_t(order)].g)) * 0x10000ull +
                       std::uint64_t(Canvas::Byte(saved[std::size_t(order)].b)) * 0x100ull +
                       Canvas::Byte(saved[std::size_t(order)].a));
            hit(b, 500 + order);
        }
    }
    void DrawMenus(PresetsUI& ui, Fonts& fonts, const Settings& cfg, int width, int height) {
        if (!formatsOpen && !headerOpen) {
            menuBox = {};
            if (!externalMenuTransitions)
                menuTransition.AppendClosing(ui);
            return;
        }
        auto menuStart = ui.layers.size();
        float s = cfg.scale, px = formatsOpen ? 12.f : 13.f;
        int font = formatsOpen ? 1 : 0;
        float F = fonts.PixelHeight(font, px * s), R = F + 14 * s;
        auto measured = [&](const std::u32string& v, int f) {
            return std::trunc(fonts.NativeTextSize(f, px * s, v).w + .95f);
        };
        float marker = measured(U"\uf00c", 3) + 12 * s;
        int count = formatsOpen ? 3 : 2;
        std::vector<std::u32string> labels;
        float intrinsic = 0;
        for (int n = 0; n < count; ++n) {
            auto label = formatsOpen ? (n == 0   ? U"RGB"
                                        : n == 1 ? U"HSV"
                                                 : U"HEX")
                                     : Label(n ? "color_gradient" : "color_default");
            labels.push_back(label);
            intrinsic = std::max(intrinsic, measured(label, font) + 24 * s + marker);
        }
        float w = std::trunc(intrinsic) + 14 * s;
        Box a = formatsOpen ? formatBox : headerBox;
        float h = float(count) * R + 14 * s;
        if (formatsOpen) {
            auto fm = MeasurePickerFormat(fonts, s, format);
            w = fm.width;
            R = fm.row;
            marker = fm.marker;
            h = float(count) * R + 14 * s;
        }
        Box b = PickerCompactPopup(a, w, h, s, float(width), float(height));
        menuBox = b;
        auto pal = CurrentPalette(cfg);
        ui.layers.push_back({b, 15 * s, true, {}});
        auto& d = ui.layers.back().draw;
        d.push_back({b, pal[8], 15 * s, 0, 15, {}, false});
        d.push_back({b, pal[11], 15 * s, s, 15, {}, false});
        for (int n = 0; n < count; ++n) {
            Box row{b.x + 7 * s, b.y + 7 * s + float(n) * R, b.w - 14 * s, R};
            int action = (formatsOpen ? 320 : 340) + n;
            bool disabled = headerOpen && scope && n == 1 && cfg.worldHud.value[1] != 1;
            float hv = disabled ? 0 : Motion(action), a2 = disabled ? .5f : 1.f;
            Color bg = PickerButtonFill(pal[33], hv);
            bg.a *= a2;
            d.push_back({row, bg, 15 * s / 1.6f, 0, 15, {}, false});
            bool selected = formatsOpen ? n == format : n == cfg.worldHud.scopeColorMode;
            auto text = [&](Box at, const std::u32string& label, Color col, int f) {
                col.a *= a2;
                PresetDraw v{at, col, 0, 0, 15, label, f == 3};
                v.font = f;
                v.textSize = px;
                v.clipped = true;
                v.clip = b;
                d.push_back(std::move(v));
            };
            if (selected)
                text({row.x + 12 * s, row.y + 7 * s, marker - 12 * s, F}, U"\uf00c", pal[0], 3);
            text({row.x + 12 * s + marker, row.y + 7 * s, row.w - 24 * s - marker, F}, labels[std::size_t(n)],
                 Mix(pal[14], pal[2], selected ? 1.f : hv), font);
            hits.push_back({row, action});
        }
        if (!externalMenuTransitions)
            menuTransition.FinishPaint(ui, menuStart);
    }
};
}
