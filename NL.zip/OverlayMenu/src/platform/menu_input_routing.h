#pragma once
namespace menu {
bool IsDefaultMovementKey(unsigned key) noexcept;
bool PassGameKeyboard(bool editing, bool release, unsigned key) noexcept;
}
