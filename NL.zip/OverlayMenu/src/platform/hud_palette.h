#pragma once
#include <array>
namespace wm {
namespace HudPalette {

inline constexpr std::array<float, 3> Body{214 / 255.f, 214 / 255.f, 219 / 255.f};
inline constexpr std::array<float, 3> Title{163 / 255.f, 163 / 255.f, 168 / 255.f};
inline constexpr std::array<float, 3> InitialAccent{79 / 255.f, 125 / 255.f, 1.f};
inline constexpr float FillAlpha = 128 / 255.f, RowAlpha = 64 / 255.f;
inline constexpr float OutlineAlpha = 26 / 255.f, ShadowAlpha = 204 / 255.f;
}
}
