#pragma once

#include <algorithm>
#include <cstdint>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
namespace menu {
inline bool AmbienceAssetName(const std::string& s) {
    if (s.empty() || s.size() > 64)
        return false;
    for (unsigned char c : s)
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' ||
              c == '-'))
            return false;
    return true;
}
inline std::string AmbienceCurrentMap(std::string s) {
    if (s.compare(0, 5, "maps/") == 0)
        s.erase(0, 5);
    if (s.size() > 4 && s.compare(s.size() - 4, 4, ".bsp") == 0)
        s.resize(s.size() - 4);

    return AmbienceAssetName(s) && s != "dedicated" ? s : std::string{};
}
enum class AmbienceImageState { Pending, Ready, Missing };
template <class Image> struct AmbienceImageResult {
    std::shared_ptr<Image> image;
    std::uint64_t revision = 0;
    AmbienceImageState state = AmbienceImageState::Pending;
};
struct AmbienceImageJob {
    std::string name;
    std::uint64_t ticket = 0;
};
template <class Image, bool (*Valid)(const std::string&) = AmbienceAssetName, std::size_t Limit = 80,
          std::size_t PlanLimit = 16>
class AmbienceImageCache {
    struct Entry {
        AmbienceImageResult<Image> result;
        std::uint64_t demand = 0, started = 0, retry = 0, ticket = 0;
        unsigned attempts = 0;
        bool claimed = false;
    };
    mutable std::mutex mutex_;
    std::map<std::string, Entry> entries_;
    std::uint64_t sequence_ = 0;
    static bool Recent(std::uint64_t now, std::uint64_t then) {
        return now >= then && now - then <= 1500;
    }
    void Retry(Entry& e, std::uint64_t now) {
        e.claimed = false;
        e.started = 0;
        e.ticket = ++sequence_;
        e.result.revision = ++sequence_;
        if (e.attempts >= 3) {
            e.result.state = AmbienceImageState::Missing;
            e.retry = now + 30000;
        } else {
            e.result.state = AmbienceImageState::Pending;
            e.retry = now + 1000;
        }
    }

public:
    AmbienceImageResult<Image> Query(const std::string& name, std::uint64_t now) {
        if (!Valid(name))
            return {{}, 0, AmbienceImageState::Missing};
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(name);
        if (it == entries_.end()) {
            if (entries_.size() >= Limit) {
                auto oldest = entries_.end();
                for (auto e = entries_.begin(); e != entries_.end(); ++e)
                    if (!Recent(now, e->second.demand) &&
                        (oldest == entries_.end() || e->second.demand < oldest->second.demand))
                        oldest = e;
                if (oldest == entries_.end())
                    return {{}, 0, AmbienceImageState::Missing};
                entries_.erase(oldest);
            }
            Entry e;
            e.ticket = ++sequence_;
            e.result.revision = ++sequence_;
            it = entries_.emplace(name, std::move(e)).first;
        }
        auto& e = it->second;
        e.demand = now;
        if (e.result.state == AmbienceImageState::Missing && now >= e.retry) {
            e.attempts = 0;
            e.retry = 0;
            e.result.state = AmbienceImageState::Pending;
            e.ticket = ++sequence_;
            e.result.revision = ++sequence_;
        }
        return e.result;
    }
    bool HasDemand(std::uint64_t now) const {
        std::lock_guard<std::mutex> lock(mutex_);
        for (const auto& item : entries_)
            if (item.second.result.state == AmbienceImageState::Pending && Recent(now, item.second.demand))
                return true;
        return false;
    }
    std::vector<AmbienceImageJob> Plan(std::uint64_t now) {
        std::lock_guard<std::mutex> lock(mutex_);
        std::vector<AmbienceImageJob> jobs;
        for (auto& item : entries_) {
            auto& e = item.second;
            if (e.result.state != AmbienceImageState::Pending)
                continue;
            if (e.started && now >= e.started && now - e.started > 5000)
                Retry(e, now);
            if (e.result.state != AmbienceImageState::Pending || !Recent(now, e.demand) || e.claimed ||
                now < e.retry || jobs.size() >= PlanLimit)
                continue;
            if (!e.started) {
                e.started = now ? now : 1;
                ++e.attempts;
            }
            jobs.push_back({item.first, e.ticket});
        }
        return jobs;
    }
    bool Claim(const AmbienceImageJob& job) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(job.name);
        if (it == entries_.end())
            return false;
        auto& e = it->second;
        if (e.ticket != job.ticket || e.result.state != AmbienceImageState::Pending || e.claimed)
            return false;
        e.claimed = true;
        return true;
    }
    bool Publish(const AmbienceImageJob& job, std::shared_ptr<Image> image) {
        if (!image)
            return false;
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(job.name);
        if (it == entries_.end())
            return false;
        auto& e = it->second;
        if (e.ticket != job.ticket || !e.claimed || e.result.state != AmbienceImageState::Pending)
            return false;
        e.result.image = std::move(image);
        e.result.state = AmbienceImageState::Ready;
        e.result.revision = ++sequence_;
        return true;
    }
    void Reject(const AmbienceImageJob& job, std::uint64_t now) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(job.name);
        if (it != entries_.end() && it->second.ticket == job.ticket &&
            it->second.result.state == AmbienceImageState::Pending)
            Retry(it->second, now);
    }

    void InvalidatePending() {
        std::lock_guard<std::mutex> lock(mutex_);
        for (auto& item : entries_) {
            auto& e = item.second;
            if (e.result.state != AmbienceImageState::Pending)
                continue;
            e.ticket = ++sequence_;
            e.result.revision = ++sequence_;
            e.started = e.retry = 0;
            e.claimed = false;
            e.attempts = 0;
        }
    }

    void Invalidate(const std::string& name) {
        std::lock_guard<std::mutex> lock(mutex_);
        entries_.erase(name);
        ++sequence_;
    }
    bool Live(const AmbienceImageJob& job) const {
        std::lock_guard<std::mutex> lock(mutex_);
        auto i = entries_.find(job.name);
        return i != entries_.end() && i->second.ticket == job.ticket &&
               i->second.result.state == AmbienceImageState::Pending;
    }
    std::string Stats() const {
        std::lock_guard<std::mutex> lock(mutex_);
        unsigned ready = 0, pending = 0, missing = 0;
        for (const auto& e : entries_) {
            if (e.second.result.state == AmbienceImageState::Ready)
                ++ready;
            else if (e.second.result.state == AmbienceImageState::Pending)
                ++pending;
            else
                ++missing;
        }
        return "images ready=" + std::to_string(ready) + " pending=" + std::to_string(pending) +
               " missing=" + std::to_string(missing);
    }
};
}
