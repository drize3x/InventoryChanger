#pragma once
#ifdef _WIN32
#include "world_scoreboard_win32.h"
#include "world_view_engine.h"
#include "hitsound_event_types.h"
#include "players_live_patterns.h"
#include "players_live_module_profile.h"
#include "win32_local_read.h"
#include "spectators_engine.h"
#include "spectator_avatars_win32.h"
#include <chrono>
#if defined(MENU_STUDIO_ESP_TEST_STUB)
#define MENU_ESP_TRY try
#define MENU_ESP_EXCEPT catch (...)
#elif defined(_MSC_VER)
#define MENU_ESP_TRY __try
#define MENU_ESP_EXCEPT __except (EXCEPTION_EXECUTE_HANDLER)
#else
#error Live game context requires MSVC SEH or the test shim
#endif
namespace menu {
class GameContextSource {
    using Clock = std::chrono::steady_clock;
    HMODULE client = nullptr, engine = nullptr, schema = nullptr;
    void *engineObject = nullptr, *schemaObject = nullptr, *scope = nullptr;
    LiveESPAddresses addresses{};
    LiveESPOffsets offsets{};
    SpectatorsOffsets spectatorOffsets{};
    SpectatorSteamAvatars spectatorAvatars;
    bool bound = false;
    Clock::time_point nextBind{};
    std::string diagnostic;
    static bool Bytes(std::uintptr_t at, void* out, SIZE_T size) {
        return LocalReadBytes(at, out, std::size_t(size));
    }
    template <class T> static bool Read(std::uintptr_t at, T& out) {
        return Bytes(at, &out, sizeof(out));
    }
    static bool Code(std::uintptr_t at) {
        MEMORY_BASIC_INFORMATION m{};
        return at && VirtualQuery(reinterpret_cast<LPCVOID>(at), &m, sizeof(m)) && m.State == MEM_COMMIT &&
               !(m.Protect & (PAGE_GUARD | PAGE_NOACCESS)) &&
               (m.Protect &
                (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY));
    }
    static std::uintptr_t Virtual(void* object, unsigned slot) {
        std::uintptr_t table = 0, fn = 0;
        if (!Read(reinterpret_cast<std::uintptr_t>(object), table) || !table ||
            !Read(table + slot * sizeof(void*), fn) || !Code(fn))
            return 0;
        return fn;
    }

    static bool FactoryCall(std::uintptr_t fn, const char* name, void*& out) {
        out = nullptr;
        MENU_ESP_TRY {
            out = reinterpret_cast<void* (*)(const char*, int*)>(fn)(name, nullptr);
            return out != nullptr;
        }
        MENU_ESP_EXCEPT {
            out = nullptr;
            return false;
        }
    }
    static bool ScopeCall(std::uintptr_t fn, void* object, void*& out) {
        out = nullptr;
        MENU_ESP_TRY {
            out = reinterpret_cast<void* (*)(void*, const char*, void*)>(fn)(object, "client.dll", nullptr);
            return out != nullptr;
        }
        MENU_ESP_EXCEPT {
            out = nullptr;
            return false;
        }
    }
    static bool ClassCall(std::uintptr_t fn, void* object, const char* name, void*& out) {
        out = nullptr;
        MENU_ESP_TRY {
            reinterpret_cast<void (*)(void*, void**, const char*)>(fn)(object, &out, name);
            return out != nullptr;
        }
        MENU_ESP_EXCEPT {
            out = nullptr;
            return false;
        }
    }
    static bool InGameCall(std::uintptr_t fn, void* object, bool& value) {
        value = false;
        MENU_ESP_TRY {
            value = reinterpret_cast<bool (*)(void*)>(fn)(object);
            return true;
        }
        MENU_ESP_EXCEPT {
            value = false;
            return false;
        }
    }
    static bool Factory(HMODULE module, const char* name, void*& out) {
        auto fn = reinterpret_cast<std::uintptr_t>(GetProcAddress(module, "CreateInterface"));
        return Code(fn) && FactoryCall(fn, name, out);
    }
    std::optional<std::uint32_t> Field(const char* cls, const char* field) {
        auto fn = Virtual(scope, 2);
        void* info = nullptr;
        if (!fn || !ClassCall(fn, scope, cls, info))
            return {};
        return WatermarkKdSchemaField([](std::uintptr_t at, auto& out) { return Read(at, out); },
                                      reinterpret_cast<std::uintptr_t>(info), cls, field);
    }
    std::optional<std::uint32_t> PawnField(const char* field) {
        for (auto cls : {"C_CSPlayerPawn", "C_CSPlayerPawnBase", "C_BasePlayerPawn", "C_BaseEntity"}) {
            auto value = Field(cls, field);
            if (value)
                return value;
        }
        return {};
    }
    bool Required(std::uint32_t& out, const char* cls, const char* field) {
        auto value = Field(cls, field);
        if (!value) {
            diagnostic = "ESP disabled: schema missing " + std::string(cls) + "::" + field;
            return false;
        }
        out = *value;
        return true;
    }
    bool Bind() {
        addresses = {};
        offsets = {};
        spectatorOffsets = {};
        engineObject = schemaObject = scope = nullptr;
        WatermarkKdModule module;
        auto read = [](std::uintptr_t at, auto& value) { return Read(at, value); };
        if (!WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(client), module))
            return false;
        HudScanImage image;
        if (!image.Load(module, [](std::uintptr_t at, void* out,
                                   std::size_t size) { return Bytes(at, out, size); }) ||
            !LiveESPResolve(image, addresses, diagnostic))
            return false;
        if (!Factory(engine, "Source2EngineToClient001", engineObject) ||
            !Factory(schema, "SchemaSystem_001", schemaObject))
            return false;
        auto query = Virtual(schemaObject, 13);
        if (!query || !ScopeCall(query, schemaObject, scope))
            return false;
        if (!Required(offsets.localFlag, "CBasePlayerController", "m_bIsLocalPlayerController") ||
            !Required(offsets.pawnHandle, "CCSPlayerController", "m_hPlayerPawn") ||
            !Required(offsets.team, "C_BaseEntity", "m_iTeamNum") ||
            !Required(offsets.life, "C_BaseEntity", "m_lifeState"))
            return false;
        offsets.health = Field("C_BaseEntity", "m_iHealth").value_or(0u);
        offsets.scene = Field("C_BaseEntity", "m_pGameSceneNode").value_or(0u);
        offsets.origin = Field("CGameSceneNode", "m_vecAbsOrigin").value_or(0u);
        offsets.scoped = PawnField("m_bIsScoped");
        offsets.desiredFov = Field("CBasePlayerController", "m_iDesiredFOV");
        offsets.zoomLevel = Field("C_CSWeaponBaseGun", "m_zoomLevel");
        offsets.viewPunch = Field("CPlayer_CameraServices", "m_vecCsViewPunchAngle");
        offsets.cameraFov = Field("CCSPlayerBase_CameraServices", "m_iFOV");
        offsets.aimPunchServices = PawnField("m_pAimPunchServices");
        offsets.weaponType = Field("CCSWeaponBaseVData", "m_WeaponType");
        offsets.steamID = Field("CBasePlayerController", "m_steamID");
        offsets.moneyServices = Field("CCSPlayerController", "m_pInGameMoneyServices");
        offsets.money = Field("CCSPlayerController_InGameMoneyServices", "m_iAccount");
        offsets.weaponServices = PawnField("m_pWeaponServices");
        offsets.activeWeapon = Field("CPlayer_WeaponServices", "m_hActiveWeapon");
        offsets.inventory = Field("CPlayer_WeaponServices", "m_hMyWeapons");
        offsets.identity = Field("CEntityInstance", "m_pEntity");
        offsets.designerName = Field("CEntityIdentity", "m_designerName");
        offsets.itemServices = PawnField("m_pItemServices");
        offsets.hasDefuser = Field("CCSPlayer_ItemServices", "m_bHasDefuser");
        offsets.hasHelmet = Field("CCSPlayer_ItemServices", "m_bHasHelmet");
        offsets.armor = PawnField("m_ArmorValue");
        offsets.ownerHandle = Field("C_BaseEntity", "m_hOwnerEntity");
        auto manager = Field("C_EconEntity", "m_AttributeManager"),
             item = Field("C_AttributeContainer", "m_Item"),
             index = Field("C_EconItemView", "m_iItemDefinitionIndex");
        if (manager && item && index && std::uint64_t(*manager) + *item + *index < 0x4000)
            offsets.itemDefinition = *manager + *item + *index;
        offsets.subclass = Field("C_BaseEntity", "m_nSubclassID");
        offsets.modelState = Field("CSkeletonInstance", "m_modelState");
        offsets.modelHandle = Field("CModelState", "m_hModel");
        offsets.hitboxSet = Field("CSkeletonInstance", "m_nHitboxSet");
        offsets.nativeLayoutVerified = LiveESPVerifyNativeLayout(read, module);
        if ((offsets.subclass && *offsets.subclass != 0x380) ||
            (offsets.modelState && *offsets.modelState != 0x140) ||
            (offsets.modelHandle && *offsets.modelHandle != 0xa0) ||
            (offsets.hitboxSet && *offsets.hitboxSet != 0x3fc))
            offsets.nativeLayoutVerified = false;
        // Optional subsystem: missing Spectators schema must not disable camera,
        // scoreboard, or hit sounds. No build-specific member offsets are used.
        auto& so = spectatorOffsets;
        so.localFlag = offsets.localFlag;
        so.pawnHandle = offsets.pawnHandle;
        so.team = offsets.team;
        so.observerPawn = Field("CCSPlayerController", "m_hObserverPawn").value_or(0u);
        so.controllerPawn = Field("CBasePlayerController", "m_hPawn");
        so.name = Field("CBasePlayerController", "m_iszPlayerName").value_or(0u);
        so.steamID = offsets.steamID;
        so.observerServices = PawnField("m_pObserverServices").value_or(0u);
        so.observerTarget = Field("CPlayer_ObserverServices", "m_hObserverTarget").value_or(0u);
        so.observerMode = Field("CPlayer_ObserverServices", "m_iObserverMode").value_or(0u);
        so.actualMoveType = PawnField("m_nActualMoveType");
        so.moveType = PawnField("m_MoveType");
        return true;
    }

public:
    void Poll(bool enabled) {
        if (!enabled)
            return;
        auto c = GetModuleHandleW(L"client.dll"), e = GetModuleHandleW(L"engine2.dll"),
             s = GetModuleHandleW(L"schemasystem.dll");
        if (c != client || e != engine || s != schema) {
            client = c;
            engine = e;
            schema = s;
            bound = false;
            addresses = {};
            offsets = {};
            spectatorOffsets = {};
            spectatorAvatars.Clear();
            engineObject = schemaObject = scope = nullptr;
            nextBind = {};
        }
        if (!client || !engine || !schema)
            return;
        auto now = Clock::now();
        if (!bound && now >= nextBind) {
            nextBind = now + std::chrono::seconds(1);
            bound = Bind();
        }
    }
    ViewContext ViewSample() {
        if (!bound)
            return {};
        bool active = false;
        auto fn = Virtual(engineObject, 39);
        if (!fn || !InGameCall(fn, engineObject, active) || !active)
            return {};
        ViewContext c;
        c.entities = addresses.entities;
        c.localGlobal = addresses.local;
        c.localFlag = offsets.localFlag;
        c.pawnHandle = offsets.pawnHandle;
        c.desiredFov = offsets.desiredFov.value_or(0u);
        c.scoped = offsets.scoped.value_or(0u);
        c.weaponServices = offsets.weaponServices.value_or(0u);
        c.activeWeapon = offsets.activeWeapon.value_or(0u);
        c.zoomLevel = offsets.zoomLevel.value_or(0u);
        c.viewPunch = offsets.viewPunch.value_or(0u);
        c.cameraFov = offsets.cameraFov.value_or(0u);
        c.ownerHandle = offsets.ownerHandle.value_or(0u);
        c.scene = offsets.scene;
        c.absOrigin = offsets.origin;
        c.aimPunchServices = offsets.aimPunchServices.value_or(0u);
        c.itemDefinition = offsets.itemDefinition.value_or(0u);
        c.life = offsets.life;
        c.health = offsets.health;
        if (offsets.nativeLayoutVerified && offsets.subclass && offsets.weaponType) {
            c.weaponSubclass = *offsets.subclass;
            c.weaponType = *offsets.weaponType;
        }
        c.valid = true;
        return c;
    }
    std::optional<LiveESPMatrix> ViewMatrix() {
        if (!bound)
            return {};
        bool active = false;
        auto fn = Virtual(engineObject, 39);
        if (!fn || !InGameCall(fn, engineObject, active) || !active)
            return {};
        LiveESPMatrix matrix;
        if (!Read(addresses.matrix, matrix))
            return {};
        for (float f : matrix.m)
            if (!std::isfinite(f))
                return {};
        return matrix;
    }
    HitSoundContext SoundSample() {
        if (!bound)
            return {};
        bool active = false;
        auto fn = Virtual(engineObject, 39);
        if (!fn || !InGameCall(fn, engineObject, active) || !active)
            return {};
        return {addresses.entities, addresses.local, reinterpret_cast<std::uintptr_t>(engineObject),
                offsets.localFlag, true};
    }
    SpectatorsFrame SpectatorsSample() {
        SpectatorsFrame frame;
        if (!bound || !spectatorOffsets.Valid()) {
            frame.stage = bound ? "Spectators schema incomplete" : "game modules not bound";
            return frame;
        }
        bool active = false;
        auto fn = Virtual(engineObject, 39);
        if (!fn || !InGameCall(fn, engineObject, active) || !active) {
            frame.stage = "not in game";
            return frame;
        }
        SpectatorsContext c{addresses.entities, addresses.local, spectatorOffsets, true};
        frame = SpectatorsCollect([](std::uintptr_t at, auto& out) { return Read(at, out); }, c);
        fn = Virtual(engineObject, 39);
        if (!fn || !InGameCall(fn, engineObject, active) || !active) {
            frame = {};
            frame.stage = "InGame changed during Spectators sample";
            return frame;
        }
        if (frame.valid)
            for (auto& entry : frame.entries)
                entry.avatar = spectatorAvatars.Get(entry.steamID);
        return frame;
    }
    ScoreboardFrame ScoreboardSample(const ScoreboardConfig& config) {
        ScoreboardFrame frame;
        if (!bound) {
            frame.stage = "game modules not bound";
            return frame;
        }
        bool active = false;
        auto fn = Virtual(engineObject, 39);
        if (!fn || !InGameCall(fn, engineObject, active) || !active) {
            frame.stage = "not in game";
            return frame;
        }
        ScoreboardContext c;
        c.entities = addresses.entities;
        c.localGlobal = addresses.local;
        auto& o = c.offsets;
        o.localFlag = offsets.localFlag;
        o.pawnHandle = offsets.pawnHandle;
        o.team = offsets.team;
        o.life = offsets.life;
        o.steamID = offsets.steamID.value_or(0u);
        o.moneyServices = offsets.moneyServices.value_or(0u);
        o.money = offsets.money.value_or(0u);
        o.weaponServices = offsets.weaponServices.value_or(0u);
        o.inventory = offsets.inventory.value_or(0u);
        o.activeWeapon = offsets.activeWeapon.value_or(0u);
        o.itemDefinition = offsets.itemDefinition.value_or(0u);
        o.identity = offsets.identity.value_or(0u);
        o.designerName = offsets.designerName.value_or(0u);
        o.itemServices = offsets.itemServices.value_or(0u);
        o.hasDefuser = offsets.hasDefuser.value_or(0u);
        o.hasHelmet = offsets.hasHelmet.value_or(0u);
        o.armor = offsets.armor.value_or(0u);
        o.ownerHandle = offsets.ownerHandle.value_or(0u);
        o.inventoryVerified = offsets.nativeLayoutVerified;
        c.valid = true;
        frame = ScoreboardCollect([](std::uintptr_t at, auto& out) { return Read(at, out); }, c, config);
        fn = Virtual(engineObject, 39);
        if (!fn || !InGameCall(fn, engineObject, active) || !active) {
            frame = ScoreboardFrame{};
            frame.stage = "InGame changed during sample";
        }
        return frame;
    }
};
}
#undef MENU_ESP_TRY
#undef MENU_ESP_EXCEPT
#endif
