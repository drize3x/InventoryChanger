#include "menu_toggle_input.h"
namespace menu {
bool MenuToggleInput::KeyDown(bool repeat, bool allowed) noexcept {
    if (repeat || !allowed)
        return false;
    pending_.fetch_xor(1u, std::memory_order_release);
    return true;
}
bool MenuToggleInput::Take(bool focused) noexcept {
    const auto pending = pending_.exchange(0u, std::memory_order_acq_rel);
    return focused && (pending & 1u) != 0;
}
void MenuToggleInput::Cancel() noexcept {
    pending_.store(0u, std::memory_order_release);
}
}
