#pragma once
namespace menu {

class MenuCursorLease {
    bool owned_ = false, wasRelative_ = false, shown_ = false;
    int showDelta_ = 0;
    template <class Show> void UndoVisibility(Show& show) {
        while (showDelta_ > 0) {
            show(false);
            --showDelta_;
        }
        while (showDelta_ < 0) {
            show(true);
            ++showDelta_;
        }
    }
    template <class Show> bool SetVisibility(bool shown, Show& show) {
        int result = shown ? -1 : 0;
        for (int i = 0; i < 32 && (shown ? result < 0 : result >= 0); ++i) {
            result = show(shown);
            showDelta_ += shown ? 1 : -1;
        }
        if (shown ? result < 0 : result >= 0) {
            UndoVisibility(show);
            return false;
        }
        shown_ = shown;
        return true;
    }

public:
    template <class Bind, class Get, class Set, class Show>
    bool Apply(bool enabled, Bind bind, Get get, Set set, Show show, bool shown = true) {
        if (!enabled) {
            if (owned_) {
                UndoVisibility(show);
                set(wasRelative_);
                owned_ = false;
                wasRelative_ = false;
            }
            return true;
        }
        if (!owned_) {
            if (!bind())
                return false;
            wasRelative_ = get();
            set(false);
            owned_ = true;
            if (!SetVisibility(shown, show)) {
                set(wasRelative_);
                owned_ = false;
                wasRelative_ = false;
                return false;
            }
        } else {
            if (get()) {
                wasRelative_ = true;
                set(false);
            }
            if (shown_ != shown) {
                UndoVisibility(show);
                if (!SetVisibility(shown, show)) {
                    set(wasRelative_);
                    owned_ = false;
                    wasRelative_ = false;
                    return false;
                }
            }
        }
        return true;
    }
    bool Active() const {
        return owned_;
    }
};
}
