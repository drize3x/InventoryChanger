#pragma once
#include <d3d11.h>
#include <wrl/client.h>
namespace menu {

class MenuFadeCapture {
    template <class T> using ComPtr = Microsoft::WRL::ComPtr<T>;
    ComPtr<ID3D11Texture2D> image_;
    ComPtr<ID3D11ShaderResourceView> view_;
    UINT w_ = 0, h_ = 0;
    DXGI_FORMAT format_ = DXGI_FORMAT_UNKNOWN;

public:
    void Reset() {
        view_.Reset();
        image_.Reset();
        w_ = h_ = 0;
        format_ = DXGI_FORMAT_UNKNOWN;
    }
    bool Capture(ID3D11Device* device, ID3D11DeviceContext* context, ID3D11Texture2D* source) {
        if (!device || !context || !source)
            return false;
        D3D11_TEXTURE2D_DESC d{};
        source->GetDesc(&d);
        if (!d.Width || !d.Height || d.SampleDesc.Count != 1 || d.ArraySize != 1)
            return false;
        if (!image_ || w_ != d.Width || h_ != d.Height || format_ != d.Format) {
            Reset();
            D3D11_TEXTURE2D_DESC out = d;
            out.MipLevels = 1;
            out.ArraySize = 1;
            out.Usage = D3D11_USAGE_DEFAULT;
            out.BindFlags = D3D11_BIND_SHADER_RESOURCE;
            out.CPUAccessFlags = 0;
            out.MiscFlags = 0;
            if (FAILED(device->CreateTexture2D(&out, nullptr, image_.GetAddressOf())) ||
                FAILED(device->CreateShaderResourceView(image_.Get(), nullptr, view_.GetAddressOf()))) {
                Reset();
                return false;
            }
            w_ = d.Width;
            h_ = d.Height;
            format_ = d.Format;
        }
        context->OMSetRenderTargets(0, nullptr, nullptr);
        context->CopySubresourceRegion(image_.Get(), 0, 0, 0, 0, source, 0, nullptr);
        return true;
    }
    ID3D11ShaderResourceView* View() const {
        return view_.Get();
    }
};
}
