#pragma once
#include <array>
#include <algorithm>
#include <cmath>
namespace wm {
enum class TextureAlpha { Premultiplied, Straight, Opaque };
struct alignas(16) ExternalTextureConstants {
    float rect[4]{};
    float uv[4]{0, 0, 1, 1};
    float options[4]{1, 0, 0, 0};
};
static_assert(sizeof(ExternalTextureConstants) == 48);
inline bool MakeExternalTextureConstants(float x, float y, float w, float h, const std::array<float, 4>& uv,
                                         float opacity, TextureAlpha alpha, ExternalTextureConstants& out) {
    for (float v : {x, y, w, h, opacity, uv[0], uv[1], uv[2], uv[3]})
        if (!std::isfinite(v))
            return false;
    if (!(w > 0 && h > 0 && opacity > 0) || !std::isfinite(x + w) || !std::isfinite(y + h) || uv[0] < 0 ||
        uv[1] < 0 || uv[2] > 1 || uv[3] > 1 || uv[2] <= uv[0] || uv[3] <= uv[1])
        return false;
    if (alpha != TextureAlpha::Premultiplied && alpha != TextureAlpha::Straight &&
        alpha != TextureAlpha::Opaque)
        return false;
    out = {{x, y, w, h},
           {uv[0], uv[1], uv[2], uv[3]},
           {std::min(1.f, opacity), alpha == TextureAlpha::Straight ? 1.f : 0.f,
            alpha == TextureAlpha::Opaque ? 1.f : 0.f, 0}};
    return true;
}
}
