#include "renderer_dx11.h"
#include <d3dcompiler.h>
#include <stdexcept>
#include <algorithm>
#include <utility>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <vector>
namespace wm {
static void Check(HRESULT hr, const char* what) {
    if (FAILED(hr))
        throw std::runtime_error(std::string(what) + " HRESULT=" + std::to_string((unsigned long)hr));
}
void RendererDX11::Init(ID3D11Device* d, ID3D11DeviceContext* c, const wchar_t* path) {
    dev_ = d;
    ctx_ = c;
    auto compile = [path](const char* entry, const char* profile) {
        ComPtr<ID3DBlob> code, error;
        HRESULT hr = D3DCompileFromFile(path, nullptr, D3D_COMPILE_STANDARD_FILE_INCLUDE, entry, profile,
                                        D3DCOMPILE_ENABLE_STRICTNESS, 0, &code, &error);
        if (FAILED(hr))
            throw std::runtime_error(
                error ? std::string((const char*)error->GetBufferPointer(), error->GetBufferSize())
                      : "Cannot open shader file");
        return code;
    };
    auto b = compile("FullscreenVS", "vs_5_0");
    Check(d->CreateVertexShader(b->GetBufferPointer(), b->GetBufferSize(), nullptr, &vs_), "vertex shader");
    auto createPS = [&](const char* entry, ComPtr<ID3D11PixelShader>& output) {
        auto code = compile(entry, "ps_5_0");
        Check(d->CreatePixelShader(code->GetBufferPointer(), code->GetBufferSize(), nullptr,
                                   output.ReleaseAndGetAddressOf()),
              entry);
    };
    auto loadOriginal = [&](const wchar_t* name, ComPtr<ID3D11PixelShader>& shader) {
        const auto file = std::filesystem::path(path).parent_path() / L"original" / name;
        std::ifstream in(file, std::ios::binary);
        if (!in)
            throw std::runtime_error("Missing original DXBC resource");
        std::vector<char> bytes((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        if (bytes.size() < 32 || std::memcmp(bytes.data(), "DXBC", 4) != 0)
            throw std::runtime_error("Invalid DXBC resource");
        Check(d->CreatePixelShader(bytes.data(), bytes.size(), nullptr, shader.ReleaseAndGetAddressOf()),
              "original pixel shader");
    };
    loadOriginal(L"blur_F3C840.dxbc", blurPS_);
    loadOriginal(L"ui_F3D2C0.dxbc", originalPS_);
    auto originalVertex = compile("OriginalQuadVS", "vs_5_0");
    Check(d->CreateVertexShader(originalVertex->GetBufferPointer(), originalVertex->GetBufferSize(), nullptr,
                                &originalVS_),
          "original-compatible VS");
    createPS("PanelPS", panelPS_);
    createPS("ScenePS", scenePS_);
    createPS("LayerPS", layerPS_);
    createPS("ExternalTexturePS", externalTexturePS_);
    D3D11_BUFFER_DESC cb{};
    cb.Usage = D3D11_USAGE_DEFAULT;
    cb.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    cb.ByteWidth = sizeof(BlurConstants);
    Check(d->CreateBuffer(&cb, nullptr, &blurCB_), "blur CB");
    cb.ByteWidth = sizeof(PanelConstants);
    Check(d->CreateBuffer(&cb, nullptr, &panelCB_), "panel CB");
    cb.ByteWidth = 32;
    Check(d->CreateBuffer(&cb, nullptr, &layerCB_), "layer CB");
    cb.ByteWidth = sizeof(ExternalTextureConstants);
    Check(d->CreateBuffer(&cb, nullptr, &externalTextureCB_), "external texture CB");
    cb.ByteWidth = 16;
    Check(d->CreateBuffer(&cb, nullptr, &originalCB_), "original display CB");
    Check(d->CreateBuffer(&cb, nullptr, &originalSdfCB_), "original SDF CB");
    cb.ByteWidth = 32;
    Check(d->CreateBuffer(&cb, nullptr, &originalQuadCB_), "original quad host CB");
    D3D11_BUFFER_DESC sb{};
    sb.ByteWidth = sizeof(OriginalPrimitive);
    sb.Usage = D3D11_USAGE_DEFAULT;
    sb.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    sb.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_STRUCTURED;
    sb.StructureByteStride = sizeof(OriginalPrimitive);
    Check(d->CreateBuffer(&sb, nullptr, &originalPrimitives_), "original primitive buffer");
    D3D11_SHADER_RESOURCE_VIEW_DESC sv{};
    sv.Format = DXGI_FORMAT_UNKNOWN;
    sv.ViewDimension = D3D11_SRV_DIMENSION_BUFFER;
    sv.Buffer.NumElements = 1;
    Check(d->CreateShaderResourceView(originalPrimitives_.Get(), &sv, &originalPrimitivesSRV_),
          "original primitive SRV");
    D3D11_SAMPLER_DESC sd{};
    sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sd.MaxLOD = D3D11_FLOAT32_MAX;
    sd.MaxAnisotropy = 1;
    sd.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
    Check(d->CreateSamplerState(&sd, &sampler_), "sampler");

    D3D11_BLEND_DESC bd{};
    auto& rt = bd.RenderTarget[0];
    rt.BlendEnable = TRUE;
    rt.SrcBlend = rt.SrcBlendAlpha = D3D11_BLEND_ONE;
    rt.DestBlend = rt.DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
    rt.BlendOp = rt.BlendOpAlpha = D3D11_BLEND_OP_ADD;
    rt.RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    Check(d->CreateBlendState(&bd, &blend_), "blend state");

    rt.SrcBlend = D3D11_BLEND_SRC_ALPHA;
    rt.SrcBlendAlpha = D3D11_BLEND_ONE;
    Check(d->CreateBlendState(&bd, &originalBlend_), "straight-alpha original PS blend");
    D3D11_RASTERIZER_DESC rd{};
    rd.FillMode = D3D11_FILL_SOLID;
    rd.CullMode = D3D11_CULL_NONE;
    rd.DepthClipEnable = TRUE;
    rd.ScissorEnable = TRUE;
    Check(d->CreateRasterizerState(&rd, &raster_), "rasterizer");
    D3D11_DEPTH_STENCIL_DESC dd{};
    dd.DepthEnable = FALSE;
    dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
    dd.DepthFunc = D3D11_COMPARISON_ALWAYS;
    dd.StencilEnable = FALSE;
    Check(d->CreateDepthStencilState(&dd, &depth_), "depth state");
}
void RendererDX11::ReleaseSizeResources() {
    if (ctx_) {
        ID3D11ShaderResourceView* empty[2] = {nullptr, nullptr};
        ctx_->PSSetShaderResources(0, 2, empty);
        ctx_->OMSetRenderTargets(0, nullptr, nullptr);
    }
    captureSRV_.Reset();
    pingSRV_.Reset();
    pongSRV_.Reset();
    pingRTV_.Reset();
    pongRTV_.Reset();
    capture_.Reset();
    ping_.Reset();
    pong_.Reset();
    width_ = height_ = 0;
    captureFormat_ = DXGI_FORMAT_UNKNOWN;
}
void RendererDX11::EnsureSize(int w, int h, DXGI_FORMAT format) {
    if (width_ == w && height_ == h && captureFormat_ == format)
        return;
    ReleaseSizeResources();
    D3D11_TEXTURE2D_DESC td{};
    td.Width = w;
    td.Height = h;
    td.MipLevels = td.ArraySize = 1;
    td.SampleDesc.Count = 1;
    td.Format = format;
    td.Usage = D3D11_USAGE_DEFAULT;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    Check(dev_->CreateTexture2D(&td, nullptr, &capture_), "capture texture");
    Check(dev_->CreateShaderResourceView(capture_.Get(), nullptr, &captureSRV_), "capture SRV");
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    td.BindFlags |= D3D11_BIND_RENDER_TARGET;
    Check(dev_->CreateTexture2D(&td, nullptr, &ping_), "ping texture");
    Check(dev_->CreateTexture2D(&td, nullptr, &pong_), "pong texture");
    Check(dev_->CreateShaderResourceView(ping_.Get(), nullptr, &pingSRV_), "ping SRV");
    Check(dev_->CreateShaderResourceView(pong_.Get(), nullptr, &pongSRV_), "pong SRV");
    Check(dev_->CreateRenderTargetView(ping_.Get(), nullptr, &pingRTV_), "ping RTV");
    Check(dev_->CreateRenderTargetView(pong_.Get(), nullptr, &pongRTV_), "pong RTV");
    width_ = w;
    height_ = h;
    captureFormat_ = format;
}
void RendererDX11::Setup(int w, int h, ID3D11RenderTargetView* output) {
    ID3D11ShaderResourceView* empty[2] = {nullptr, nullptr};
    ctx_->PSSetShaderResources(0, 2, empty);
    ctx_->OMSetRenderTargets(1, &output, nullptr);
    ctx_->OMSetBlendState(nullptr, nullptr, 0xffffffff);
    ctx_->OMSetDepthStencilState(depth_.Get(), 0);
    ctx_->RSSetState(raster_.Get());
    D3D11_VIEWPORT vp{0, 0, float(w), float(h), 0, 1};
    ctx_->RSSetViewports(1, &vp);
    D3D11_RECT sc{0, 0, w, h};
    if (clipEnabled_) {
        sc.left = std::max(sc.left, clip_.left);
        sc.top = std::max(sc.top, clip_.top);
        sc.right = std::min(sc.right, clip_.right);
        sc.bottom = std::min(sc.bottom, clip_.bottom);
    }
    ctx_->RSSetScissorRects(1, &sc);
    ctx_->IASetInputLayout(nullptr);
    ctx_->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    ctx_->VSSetShader(vs_.Get(), nullptr, 0);
    ctx_->GSSetShader(nullptr, nullptr, 0);
    ctx_->HSSetShader(nullptr, nullptr, 0);
    ctx_->DSSetShader(nullptr, nullptr, 0);
    auto* sampler = sampler_.Get();
    ctx_->PSSetSamplers(0, 1, &sampler);
}
void RendererDX11::BlurPass(ID3D11ShaderResourceView* source, ID3D11RenderTargetView* target, bool vertical,
                            float sigma) {
    Setup(width_, height_, target);
    auto k = MakeKernel(sigma, width_, height_, vertical);
    ctx_->UpdateSubresource(blurCB_.Get(), 0, nullptr, &k, 0, 0);
    auto* cb = blurCB_.Get();
    ctx_->PSSetConstantBuffers(0, 1, &cb);
    ctx_->PSSetShader(blurPS_.Get(), nullptr, 0);
    ctx_->PSSetShaderResources(0, 1, &source);
    ctx_->Draw(3, 0);
}
void RendererDX11::DrawDemoScene(ID3D11RenderTargetView* output, int w, int h, float time) {
    Setup(w, h, output);
    PanelConstants p{};
    p.screen[0] = float(w);
    p.screen[1] = float(h);
    p.screen[2] = time;
    auto* avatarSRV = avatarsSRV_.Get();
    ctx_->PSSetShaderResources(1, 1, &avatarSRV);
    ctx_->UpdateSubresource(panelCB_.Get(), 0, nullptr, &p, 0, 0);
    auto* cb = panelCB_.Get();
    ctx_->PSSetConstantBuffers(1, 1, &cb);
    ctx_->PSSetShader(scenePS_.Get(), nullptr, 0);
    ctx_->Draw(3, 0);
}
void RendererDX11::DrawPanel(ID3D11Texture2D* scene, ID3D11RenderTargetView* output, const PanelConstants& p,
                             float sigma, bool blur) {
    PrepareBackdrop(scene, sigma, blur);
    DrawPreparedPanel(output, p, blur);
}
void RendererDX11::PrepareBackdrop(ID3D11Texture2D* scene, float sigma, bool blur) {
    D3D11_TEXTURE2D_DESC td{};
    scene->GetDesc(&td);
    if ((td.Format != DXGI_FORMAT_R8G8B8A8_UNORM && td.Format != DXGI_FORMAT_B8G8R8A8_UNORM) ||
        td.SampleDesc.Count != 1 || td.MipLevels != 1 || td.ArraySize != 1)
        throw std::runtime_error("Panel needs single-sample RGBA8/BGRA8 UNORM, one mip, one slice");
    EnsureSize(int(td.Width), int(td.Height), td.Format);
    ID3D11ShaderResourceView* empty = nullptr;
    ctx_->PSSetShaderResources(0, 1, &empty);
    ctx_->OMSetRenderTargets(0, nullptr, nullptr);
    ctx_->CopyResource(capture_.Get(), scene);
    if (blur) {

        const bool savedClip = clipEnabled_;
        const auto savedRect = clip_;
        ClearClip();
        BlurPass(captureSRV_.Get(), pingRTV_.Get(), false, sigma);
        BlurPass(pingSRV_.Get(), pongRTV_.Get(), true, sigma);
        clipEnabled_ = savedClip;
        clip_ = savedRect;
    }
    ID3D11ShaderResourceView* unbind = nullptr;
    ctx_->PSSetShaderResources(0, 1, &unbind);
}
void RendererDX11::DrawPreparedPanel(ID3D11RenderTargetView* output, const PanelConstants& p, bool blur) {
    const bool hasHalo = p.shadow[0] > 0 && p.shadow[1] > 0;
    auto drawHalo = [&]() {
        auto halo = p;
        halo.screen[3] = 4;
        halo.fx[1] = 0;
        DrawPreparedPanel(output, halo, blur);
    };

    if (hasHalo && p.screen[3] == 1)
        drawHalo();
    ID3D11ShaderResourceView* empty = nullptr;
    Setup(width_, height_, output);
    auto* srv = blur ? pongSRV_.Get() : captureSRV_.Get();
    ctx_->PSSetShaderResources(0, 1, &srv);
    auto* avatarSRV = avatarsSRV_.Get();
    ctx_->PSSetShaderResources(1, 1, &avatarSRV);
    ctx_->UpdateSubresource(panelCB_.Get(), 0, nullptr, &p, 0, 0);
    auto* cb = panelCB_.Get();
    ctx_->PSSetConstantBuffers(1, 1, &cb);
    ctx_->PSSetShader(panelPS_.Get(), nullptr, 0);
    ctx_->OMSetBlendState(blend_.Get(), nullptr, 0xffffffff);
    const float pad = p.shadow[1] + std::max(std::abs(p.shadow[2]), std::abs(p.shadow[3])) + 2;
    D3D11_RECT sc{LONG(std::max(0.f, p.rect[0] - pad)), LONG(std::max(0.f, p.rect[1] - pad)),
                  LONG(std::min(float(width_), p.rect[0] + p.rect[2] + pad)),
                  LONG(std::min(float(height_), p.rect[1] + p.rect[3] + pad))};
    if (clipEnabled_) {
        sc.left = std::max(sc.left, clip_.left);
        sc.top = std::max(sc.top, clip_.top);
        sc.right = std::min(sc.right, clip_.right);
        sc.bottom = std::min(sc.bottom, clip_.bottom);
    }
    ctx_->RSSetScissorRects(1, &sc);
    ctx_->Draw(3, 0);
    ctx_->PSSetShaderResources(0, 1, &empty);
    ctx_->PSSetShaderResources(1, 1, &empty);
    if (hasHalo && p.screen[3] == 0)
        drawHalo();
}
void RendererDX11::DrawOriginalRect(ID3D11RenderTargetView* output, float x, float y, float w, float h,
                                    const std::array<float, 4>& color, float radius, float smoothing,
                                    float thickness, bool sampleBackdrop, bool blurred, float shadowSize,
                                    std::array<float, 4> shadowColor, unsigned cornerMask,
                                    float shadowOffsetX, float shadowOffsetY, bool innerShadow,
                                    float shadowSmoothing) {
    if (w <= 0 || h <= 0)
        return;
    auto primitive =
        innerShadow ? MakeOriginalInnerPrimitive(w, h, color, shadowColor, radius, shadowSize)
        : shadowSize > 0
            ? MakeOriginalShadowPrimitive(w, h, shadowColor, radius, shadowSize, shadowOffsetX, shadowOffsetY,
                                          shadowSmoothing)
            : MakeOriginalRectPrimitive(w, h, color, radius, smoothing, thickness, sampleBackdrop);
    for (unsigned corner = 0; corner < 4; ++corner)
        if (!(cornerMask & (1u << (corner < 2 ? corner : 5 - corner))))
            primitive.F(0xb0 + 4 * corner, 0);
    if (shadowSize > 0 && !innerShadow) {
        float px = shadowSize * .5f + std::abs(shadowOffsetX),
              py = shadowSize * .5f + std::abs(shadowOffsetY);
        x -= px;
        y -= py;
        w += 2 * px;
        h += 2 * py;
    }
    Setup(width_, height_, output);
    ctx_->UpdateSubresource(originalPrimitives_.Get(), 0, nullptr, &primitive, 0, 0);
    const float display[4] = {float(width_), float(height_), 0, 0};
    const unsigned sdf[4] = {1, 0, 0, 0};
    const float quad[8] = {x, y, w, h, float(width_), float(height_), 0, 0};
    ctx_->UpdateSubresource(originalCB_.Get(), 0, nullptr, display, 0, 0);
    ctx_->UpdateSubresource(originalSdfCB_.Get(), 0, nullptr, sdf, 0, 0);
    ctx_->UpdateSubresource(originalQuadCB_.Get(), 0, nullptr, quad, 0, 0);
    ID3D11Buffer* cb[2] = {originalCB_.Get(), originalSdfCB_.Get()};
    ctx_->PSSetConstantBuffers(0, 2, cb);
    auto* q = originalQuadCB_.Get();
    ctx_->VSSetConstantBuffers(3, 1, &q);
    ID3D11ShaderResourceView* resources[2] = {sampleBackdrop ? (blurred ? pongSRV_.Get() : captureSRV_.Get())
                                                             : nullptr,
                                              originalPrimitivesSRV_.Get()};
    ctx_->PSSetShaderResources(0, 2, resources);
    ctx_->VSSetShader(originalVS_.Get(), nullptr, 0);
    ctx_->PSSetShader(originalPS_.Get(), nullptr, 0);
    ctx_->OMSetBlendState(originalBlend_.Get(), nullptr, 0xffffffff);

    ctx_->Draw(6, 0);
    ID3D11ShaderResourceView* empty[2] = {nullptr, nullptr};
    ctx_->PSSetShaderResources(0, 2, empty);
}
void RendererDX11::DrawOriginalIndicatorLine(ID3D11RenderTargetView* output, float x, float y, float w,
                                             float h, const std::array<float, 4>& color, float radius,
                                             float shadow) {
    if (w <= 0 || h <= 0)
        return;
    auto pass = [&](float extent) {
        auto primitive = MakeOriginalIndicatorLine(w, h, color, radius, extent);
        Setup(width_, height_, output);
        ctx_->UpdateSubresource(originalPrimitives_.Get(), 0, nullptr, &primitive, 0, 0);
        const float display[4] = {float(width_), float(height_), 0, 0};
        const unsigned sdf[4] = {1, 0, 0, 0};
        const float quad[8] = {x - extent * .5f, y - extent * .5f, w + extent, h + extent,
                               float(width_),    float(height_),   0,          0};
        ctx_->UpdateSubresource(originalCB_.Get(), 0, nullptr, display, 0, 0);
        ctx_->UpdateSubresource(originalSdfCB_.Get(), 0, nullptr, sdf, 0, 0);
        ctx_->UpdateSubresource(originalQuadCB_.Get(), 0, nullptr, quad, 0, 0);
        ID3D11Buffer* cb[2] = {originalCB_.Get(), originalSdfCB_.Get()};
        ctx_->PSSetConstantBuffers(0, 2, cb);
        auto* q = originalQuadCB_.Get();
        ctx_->VSSetConstantBuffers(3, 1, &q);
        ID3D11ShaderResourceView* resources[2] = {nullptr, originalPrimitivesSRV_.Get()};
        ctx_->PSSetShaderResources(0, 2, resources);
        ctx_->VSSetShader(originalVS_.Get(), nullptr, 0);
        ctx_->PSSetShader(originalPS_.Get(), nullptr, 0);
        ctx_->OMSetBlendState(originalBlend_.Get(), nullptr, 0xffffffff);
        ctx_->Draw(6, 0);
        ID3D11ShaderResourceView* empty[2] = {nullptr, nullptr};
        ctx_->PSSetShaderResources(0, 2, empty);
    };

    pass(std::max(0.f, shadow));
}
void RendererDX11::DrawOriginalArc(ID3D11RenderTargetView* output, float cx, float cy, float diameter,
                                   const std::array<float, 4>& color, float thickness, float start,
                                   float end) {
    if (diameter <= 0 || thickness <= 0 || end <= start)
        return;
    auto primitive = MakeOriginalArcPrimitive(diameter, color, thickness, start, end);
    Setup(width_, height_, output);
    ctx_->UpdateSubresource(originalPrimitives_.Get(), 0, nullptr, &primitive, 0, 0);
    const float display[4] = {float(width_), float(height_), 0, 0};
    const unsigned sdf[4] = {1, 0, 0, 0};
    const float quad[8] = {cx - diameter * .5f, cy - diameter * .5f, diameter, diameter,
                           float(width_),       float(height_),      0,        0};
    ctx_->UpdateSubresource(originalCB_.Get(), 0, nullptr, display, 0, 0);
    ctx_->UpdateSubresource(originalSdfCB_.Get(), 0, nullptr, sdf, 0, 0);
    ctx_->UpdateSubresource(originalQuadCB_.Get(), 0, nullptr, quad, 0, 0);
    ID3D11Buffer* cb[2] = {originalCB_.Get(), originalSdfCB_.Get()};
    ctx_->PSSetConstantBuffers(0, 2, cb);
    auto* q = originalQuadCB_.Get();
    ctx_->VSSetConstantBuffers(3, 1, &q);
    ID3D11ShaderResourceView* resources[2] = {nullptr, originalPrimitivesSRV_.Get()};
    ctx_->PSSetShaderResources(0, 2, resources);
    ctx_->VSSetShader(originalVS_.Get(), nullptr, 0);
    ctx_->PSSetShader(originalPS_.Get(), nullptr, 0);
    ctx_->OMSetBlendState(originalBlend_.Get(), nullptr, 0xffffffff);
    ctx_->Draw(6, 0);
    ID3D11ShaderResourceView* empty[2] = {nullptr, nullptr};
    ctx_->PSSetShaderResources(0, 2, empty);
}
void RendererDX11::DrawOriginalHorizontalGradient(ID3D11RenderTargetView* output, float x, float y, float w,
                                                  float h, const std::array<float, 4>& left,
                                                  const std::array<float, 4>& right, float radius) {
    if (w <= 0 || h <= 0)
        return;
    auto primitive = MakeOriginalHorizontalGradient(w, h, left, right, radius);
    Setup(width_, height_, output);
    ctx_->UpdateSubresource(originalPrimitives_.Get(), 0, nullptr, &primitive, 0, 0);
    const float display[4] = {float(width_), float(height_), 0, 0};
    const unsigned sdf[4] = {1, 0, 0, 0};
    const float quad[8] = {x, y, w, h, float(width_), float(height_), 0, 0};
    ctx_->UpdateSubresource(originalCB_.Get(), 0, nullptr, display, 0, 0);
    ctx_->UpdateSubresource(originalSdfCB_.Get(), 0, nullptr, sdf, 0, 0);
    ctx_->UpdateSubresource(originalQuadCB_.Get(), 0, nullptr, quad, 0, 0);
    ID3D11Buffer* cb[2] = {originalCB_.Get(), originalSdfCB_.Get()};
    ctx_->PSSetConstantBuffers(0, 2, cb);
    auto* q = originalQuadCB_.Get();
    ctx_->VSSetConstantBuffers(3, 1, &q);
    ID3D11ShaderResourceView* resources[2] = {nullptr, originalPrimitivesSRV_.Get()};
    ctx_->PSSetShaderResources(0, 2, resources);
    ctx_->VSSetShader(originalVS_.Get(), nullptr, 0);
    ctx_->PSSetShader(originalPS_.Get(), nullptr, 0);
    ctx_->OMSetBlendState(originalBlend_.Get(), nullptr, 0xffffffff);
    ctx_->Draw(6, 0);
    ID3D11ShaderResourceView* empty[2] = {nullptr, nullptr};
    ctx_->PSSetShaderResources(0, 2, empty);
}
void RendererDX11::DrawLayer(ID3D11RenderTargetView* output, int sw, int sh, const unsigned char* rgba,
                             int tw, int th, float x, float y, float visible, float scroll, int cacheSlot,
                             bool upload) {
    auto& cache = layers_.at(size_t(cacheSlot));
    auto& layer_ = cache.texture;
    auto& layerSRV_ = cache.srv;
    auto& layerW_ = cache.width;
    auto& layerH_ = cache.height;
    if (tw != layerW_ || th != layerH_) {
        layerSRV_.Reset();
        layer_.Reset();
        D3D11_TEXTURE2D_DESC td{};
        td.Width = tw;
        td.Height = th;
        td.MipLevels = td.ArraySize = 1;
        td.SampleDesc.Count = 1;
        td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        td.Usage = D3D11_USAGE_DEFAULT;
        td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        Check(dev_->CreateTexture2D(&td, nullptr, &layer_), "text texture");
        Check(dev_->CreateShaderResourceView(layer_.Get(), nullptr, &layerSRV_), "text SRV");
        layerW_ = tw;
        layerH_ = th;
        upload = true;
    }
    Setup(sw, sh, output);
    if (upload)
        ctx_->UpdateSubresource(layer_.Get(), 0, nullptr, rgba, tw * 4, 0);
    const float constants[8] = {x, y, visible, float(th), float(tw), float(th), scroll, 1};
    ctx_->UpdateSubresource(layerCB_.Get(), 0, nullptr, constants, 0, 0);
    auto* cb = layerCB_.Get();
    ctx_->PSSetConstantBuffers(2, 1, &cb);
    auto* srv = layerSRV_.Get();
    ctx_->PSSetShaderResources(0, 1, &srv);
    ctx_->PSSetShader(layerPS_.Get(), nullptr, 0);
    ctx_->OMSetBlendState(blend_.Get(), nullptr, 0xffffffff);
    ctx_->Draw(3, 0);
    ID3D11ShaderResourceView* empty = nullptr;
    ctx_->PSSetShaderResources(0, 1, &empty);
}
bool RendererDX11::DrawExternalTexture(ID3D11RenderTargetView* output, ID3D11ShaderResourceView* source,
                                       int sw, int sh, float x, float y, float w, float h,
                                       const std::array<float, 4>& uv, TextureAlpha alpha, float opacity) {
    if (!output || !source || sw <= 0 || sh <= 0 || !ctx_ || !externalTexturePS_)
        return false;
    ExternalTextureConstants c{};
    if (!MakeExternalTextureConstants(x, y, w, h, uv, opacity, alpha, c))
        return false;
    if (x >= sw || y >= sh || x + w <= 0 || y + h <= 0)
        return false;
    D3D11_SHADER_RESOURCE_VIEW_DESC sd{};
    source->GetDesc(&sd);
    if (sd.ViewDimension != D3D11_SRV_DIMENSION_TEXTURE2D)
        return false;
    ComPtr<ID3D11Device> sourceDevice, outputDevice;
    source->GetDevice(&sourceDevice);
    output->GetDevice(&outputDevice);
    if (sourceDevice.Get() != dev_.Get() || outputDevice.Get() != dev_.Get())
        return false;
    ComPtr<ID3D11Resource> sourceResource, outputResource;
    source->GetResource(&sourceResource);
    output->GetResource(&outputResource);
    if (!sourceResource || !outputResource || sourceResource.Get() == outputResource.Get())
        return false;
    Setup(sw, sh, output);
    D3D11_RECT sc{LONG(std::floor(std::max(0.f, x))), LONG(std::floor(std::max(0.f, y))),
                  LONG(std::ceil(std::min(float(sw), x + w))), LONG(std::ceil(std::min(float(sh), y + h)))};
    if (clipEnabled_) {
        sc.left = std::max(sc.left, clip_.left);
        sc.top = std::max(sc.top, clip_.top);
        sc.right = std::min(sc.right, clip_.right);
        sc.bottom = std::min(sc.bottom, clip_.bottom);
    }
    if (sc.right <= sc.left || sc.bottom <= sc.top)
        return false;
    ctx_->RSSetScissorRects(1, &sc);
    ctx_->UpdateSubresource(externalTextureCB_.Get(), 0, nullptr, &c, 0, 0);
    auto* cb = externalTextureCB_.Get();
    ctx_->PSSetConstantBuffers(4, 1, &cb);
    ctx_->PSSetShaderResources(0, 1, &source);
    ctx_->PSSetShader(externalTexturePS_.Get(), nullptr, 0);

    ctx_->OMSetBlendState(blend_.Get(), nullptr, 0xffffffff);
    ctx_->Draw(3, 0);
    ID3D11ShaderResourceView* empty = nullptr;
    ctx_->PSSetShaderResources(0, 1, &empty);
    return true;
}
}
