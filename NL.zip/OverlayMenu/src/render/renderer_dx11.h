#pragma once
#include <d3d11.h>
#include <wrl/client.h>
#include <string>
#include <array>
#include "gaussian_kernel.h"
#include "hud_palette.h"
#include "original_primitive.h"
#include "external_texture_quad.h"
namespace wm {
using Microsoft::WRL::ComPtr;
struct alignas(16) PanelConstants {
    float screen[4]{};
    float rect[4]{};
    float topColor[4]{0.f, 0.f, 0.f, HudPalette::FillAlpha};
    float bottomColor[4]{0.f, 0.f, 0.f, HudPalette::FillAlpha};
    float radii[4]{16, 16, 16, 16};
    float fx[4]{1.f, 0.f, 1.f, 1.f};
    float shadow[4]{HudPalette::ShadowAlpha, 18.f, 0.f, 0.f};
    float shadowColor[4]{0.f, 0.f, 0.f, 1.f};
};
static_assert(sizeof(PanelConstants) == 128);

class RendererDX11 {
public:
    void Init(ID3D11Device*, ID3D11DeviceContext*, const wchar_t* shaderFile);
    void DrawDemoScene(ID3D11RenderTargetView*, int width, int height, float time);
    void DrawPanel(ID3D11Texture2D* scene, ID3D11RenderTargetView* output, const PanelConstants&, float sigma,
                   bool blur);
    void DrawLayer(ID3D11RenderTargetView*, int screenW, int screenH, const unsigned char* premultipliedRGBA,
                   int texW, int texH, float x, float y, float visibleWidth, float scroll, int cacheSlot = 0,
                   bool upload = true);

    void SetClip(float x, float y, float w, float h) {
        clipEnabled_ = true;
        clip_ = {LONG(x), LONG(y), LONG(x + w), LONG(y + h)};
    }
    void ClearClip() {
        clipEnabled_ = false;
    }
    void PrepareBackdrop(ID3D11Texture2D* scene, float sigma, bool blur);
    void DrawPreparedPanel(ID3D11RenderTargetView* output, const PanelConstants&, bool blur);
    void DrawOriginalRect(ID3D11RenderTargetView*, float x, float y, float w, float h,
                          const std::array<float, 4>& color, float radius, float smoothing = 0,
                          float thickness = 0, bool sampleBackdrop = false, bool blurred = true,
                          float shadowSize = 0, std::array<float, 4> shadowColor = {},
                          unsigned cornerMask = 15, float shadowOffsetX = 0, float shadowOffsetY = 0,
                          bool innerShadow = false, float shadowSmoothing = 1);
    void DrawOriginalIndicatorLine(ID3D11RenderTargetView*, float x, float y, float w, float h,
                                   const std::array<float, 4>& color, float radius, float shadow);
    void DrawOriginalArc(ID3D11RenderTargetView*, float cx, float cy, float diameter,
                         const std::array<float, 4>& color, float thickness, float start, float end);
    void DrawOriginalHorizontalGradient(ID3D11RenderTargetView*, float x, float y, float w, float h,
                                        const std::array<float, 4>& left, const std::array<float, 4>& right,
                                        float radius);

    bool DrawExternalTexture(ID3D11RenderTargetView* output, ID3D11ShaderResourceView* source, int screenW,
                             int screenH, float x, float y, float w, float h, const std::array<float, 4>& uv,
                             TextureAlpha alpha, float opacity = 1.f);

    void ReleaseSizeResources();

private:
    void EnsureSize(int width, int height, DXGI_FORMAT format);
    void Setup(int width, int height, ID3D11RenderTargetView*);
    void BlurPass(ID3D11ShaderResourceView*, ID3D11RenderTargetView*, bool vertical, float sigma);
    ComPtr<ID3D11Device> dev_;
    ComPtr<ID3D11DeviceContext> ctx_;
    ComPtr<ID3D11VertexShader> vs_, originalVS_;
    ComPtr<ID3D11PixelShader> blurPS_, panelPS_, scenePS_, layerPS_, originalPS_, externalTexturePS_;
    ComPtr<ID3D11Buffer> blurCB_, panelCB_, layerCB_, originalCB_, originalSdfCB_, originalQuadCB_,
        originalPrimitives_, externalTextureCB_;
    ComPtr<ID3D11ShaderResourceView> originalPrimitivesSRV_;
    ComPtr<ID3D11SamplerState> sampler_;
    ComPtr<ID3D11BlendState> blend_, originalBlend_;
    ComPtr<ID3D11RasterizerState> raster_;
    ComPtr<ID3D11DepthStencilState> depth_;
    ComPtr<ID3D11Texture2D> capture_, ping_, pong_;
    ComPtr<ID3D11ShaderResourceView> captureSRV_, pingSRV_, pongSRV_;
    ComPtr<ID3D11RenderTargetView> pingRTV_, pongRTV_;
    struct LayerCache {
        ComPtr<ID3D11Texture2D> texture;
        ComPtr<ID3D11ShaderResourceView> srv;
        int width = 0, height = 0;
    };
    std::array<LayerCache, 372> layers_{};
    ComPtr<ID3D11Texture2D> avatars_;
    ComPtr<ID3D11ShaderResourceView> avatarsSRV_;
    bool clipEnabled_ = false;
    D3D11_RECT clip_{};
    int width_{}, height_{};
    DXGI_FORMAT captureFormat_ = DXGI_FORMAT_UNKNOWN;
};
}
