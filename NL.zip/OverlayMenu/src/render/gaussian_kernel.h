#pragma once
#include <array>
#include <algorithm>
#include <cmath>
namespace wm {

struct alignas(16) BlurConstants {
    float resolution[2]{};
    float direction{};
    int pairs{};
    std::array<std::array<float, 4>, 11> offsets{};
    std::array<std::array<float, 4>, 11> weights{};
};
static_assert(sizeof(BlurConstants) == 368);

inline float MainMenuBlurSigma(float uiScale) {
    return 5.f * uiScale;
}
inline BlurConstants MakeKernel(float sigma, int width, int height, bool vertical) {
    BlurConstants out{};
    out.resolution[0] = float(std::max(width, 1));
    out.resolution[1] = float(std::max(height, 1));
    out.direction = vertical ? 1.f : 0.f;

    sigma = std::isfinite(sigma) ? std::max(sigma, .001f) : 5.f;
    constexpr int radius = 8;
    std::array<float, 9> w{};
    float sum = 0;
    for (int i = 0; i <= radius; ++i) {
        w[i] = std::exp(-float(i * i) / (2.f * sigma * sigma));
        sum += w[i] * (i == 0 ? 1.f : 2.f);
    }
    out.pairs = radius;
    for (int i = 0; i <= radius; ++i) {
        out.offsets[i][0] = float(i);
        out.weights[i][0] = w[i] / sum;
    }
    return out;
}
}
