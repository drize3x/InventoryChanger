#pragma once
#include <array>
#include "preview_idle_selector_bindings.h"
namespace menu {

inline constexpr int PreviewDesiredClipIndex = 2;
static_assert(PreviewDesiredClipIndex >= 0 && PreviewDesiredClipIndex < 4, "invalid preview clip index");
enum class PreviewSelectorStage : unsigned {
    Entry,
    Options,
    Clips,
    CachedState,
    PanelRecord,
    Owner,
    Weapon,
    WeaponGraph,
    WeaponIndex,
    WeaponTable,
    WeaponNode,
    WeaponValue,
    WeaponSymbol,
    WeaponMatch,
    ChildContext,
    NodeMember,
    ChildPath,
    SeedInput,
    Accepted,
    Count
};
inline const char* PreviewSelectorStageName(PreviewSelectorStage stage) {
    switch (stage) {
    case PreviewSelectorStage::Entry:
        return "entry";
    case PreviewSelectorStage::Options:
        return "options";
    case PreviewSelectorStage::Clips:
        return "clip-types/refcounts";
    case PreviewSelectorStage::CachedState:
        return "cached-state/refcount";
    case PreviewSelectorStage::PanelRecord:
        return "panel-record";
    case PreviewSelectorStage::Owner:
        return "serial-owner/mode/controller";
    case PreviewSelectorStage::Weapon:
        return "weapon-binding/symbol";
    case PreviewSelectorStage::WeaponGraph:
        return "weapon-graph";
    case PreviewSelectorStage::WeaponIndex:
        return "weapon-index";
    case PreviewSelectorStage::WeaponTable:
        return "weapon-node-table";
    case PreviewSelectorStage::WeaponNode:
        return "weapon-node-type";
    case PreviewSelectorStage::WeaponValue:
        return "weapon-value";
    case PreviewSelectorStage::WeaponSymbol:
        return "weapon-ssg08-symbol";
    case PreviewSelectorStage::WeaponMatch:
        return "weapon-value-mismatch";
    case PreviewSelectorStage::Count:
        return "count";
    case PreviewSelectorStage::ChildContext:
        return "child-context";
    case PreviewSelectorStage::NodeMember:
        return "node-membership";
    case PreviewSelectorStage::ChildPath:
        return "referenced-child-path";
    case PreviewSelectorStage::SeedInput:
        return "seed-input";
    case PreviewSelectorStage::Accepted:
        return "accepted";
    }
    return "unknown";
}
struct PreviewWeaponProbe {
    std::uintptr_t rootGraph = 0, bindingGraph = 0, table = 0, node = 0, vtable = 0, value = 0,
                   symbolAddress = 0, symbol = 0;
    std::int32_t count = 0;
    std::int16_t index = -1, seedIndex = -1;
};
struct PreviewSelectorScope {
    PreviewIdleOwner owner;
    std::uintptr_t graph = 0, targetClip = 0, activeClip = 0;
    std::int32_t cached = -1, targetIndex = PreviewDesiredClipIndex, optionCount = 4;
};

template <class Read>
bool ResolvePreviewSelectorScope(Read&& read, const PreviewIdleSelectorBindings& b, std::uintptr_t panel,
                                 std::uintptr_t node, std::uintptr_t context, PreviewSelectorScope& out,
                                 PreviewSelectorStage* stage = nullptr, bool choosing = false,
                                 PreviewWeaponProbe* probe = nullptr, bool terrorist = false) {
    if (probe)
        *probe = {};
    auto at = [&](PreviewSelectorStage value) {
        if (stage)
            *stage = value;
    };
    at(PreviewSelectorStage::Options);
    out = {};
    std::uintptr_t vt = 0, options = 0, controller = 0, records = 0, system = 0, chunk = 0, entity = 0;
    std::int32_t count = 0, active = -1, refs = 0;
    std::uint32_t capacity = 0, handle = 0;
    if (!panel || !node || context < 0x40 || !read(node, vt) || vt != b.selectorVtable ||
        !read(node + 0x28, count) || count != (terrorist ? 6 : 4) || !read(node + 0x2c, capacity))
        return false;
    capacity &= 0x7fffffffu;
    if (capacity < unsigned(terrorist ? 6 : 4) || capacity > 4096)
        return false;
    options = node + 0x30;
    if (capacity > 5 && (!read(options, options) || !options))
        return false;
    at(PreviewSelectorStage::Clips);
    const unsigned optionCount = terrorist ? 6 : 4;
    std::array<std::uintptr_t, 6> clips{};
    for (unsigned i = 0; i < optionCount; ++i)
        if (!read(options + i * 8, clips[i]) || !clips[i] || !read(clips[i], vt) || vt != b.clipVtable ||
            !read(clips[i] + 0x14, refs) || refs < 1)
            return false;
    PreviewSelectorScope s;
    s.optionCount = int(optionCount);
    s.targetIndex = terrorist ? 4 : PreviewDesiredClipIndex;
    at(PreviewSelectorStage::CachedState);
    if (!read(node + 0x14, refs) || refs != 1)
        return false;

    if (!choosing && (!read(node + 0x68, s.cached) || s.cached < 0 || s.cached >= s.optionCount ||
                      !read(node + 0x60, s.activeClip) || s.activeClip != clips[unsigned(s.cached)]))
        return false;

    at(PreviewSelectorStage::PanelRecord);
    const auto& t = b.owner.types;
    if (!read(panel, vt) || vt != t.panelVtable || !read(panel + 0x8ec, active) ||
        !read(panel + 0x8f0, count) || count < 1 || count > 64 || active < 0 || active >= count ||
        !read(panel + 0x8f8, records) || !records || !read(records + std::uintptr_t(active) * 0xa0, handle) ||
        handle >= 0xfffffffeu || !read(t.entitySystemGlobal, system) || !system)
        return false;
    const auto slot = handle & 0x7fffu;
    if (!read(system + std::uintptr_t(slot >> 9) * 8, chunk) || !chunk ||
        !read(chunk + std::uintptr_t(slot & 0x1ffu) * 0x70, entity) || !entity ||
        !read(entity + 0x37b8, controller) || !controller)
        return false;
    at(PreviewSelectorStage::Owner);
    if (!ResolvePreviewIdleOwner(read, t, panel, controller, s.owner))
        return false;

    PreviewWeaponProbe w;
    w.rootGraph = s.owner.graph;
    w.seedIndex = s.owner.index;
    w.symbolAddress = b.ssg08Symbol;
    auto save = [&]() {
        if (probe)
            *probe = w;
    };
    at(PreviewSelectorStage::WeaponGraph);
    if (!read(controller + PreviewIdleSelectorBindings::WeaponTypeGraphOffset, w.bindingGraph)) {
        save();
        return false;
    }
    save();
    if (w.bindingGraph != s.owner.graph)
        return false;
    at(PreviewSelectorStage::WeaponIndex);
    if (!read(controller + PreviewIdleSelectorBindings::WeaponTypeIndexOffset, w.index)) {
        save();
        return false;
    }
    save();
    if (w.index < 0)
        return false;
    at(PreviewSelectorStage::WeaponTable);
    if (!read(w.bindingGraph + 8, w.count)) {
        save();
        return false;
    }
    save();
    if (w.count < 1 || w.count > 4096 || w.index >= w.count || s.owner.index >= w.count)
        return false;
    if (!read(w.bindingGraph + 0x10, w.table)) {
        save();
        return false;
    }
    save();
    if (!w.table || !read(w.table + std::uintptr_t(w.index) * 8, w.node)) {
        save();
        return false;
    }
    save();
    if (!w.node)
        return false;
    at(PreviewSelectorStage::WeaponNode);
    if (!read(w.node, w.vtable)) {
        save();
        return false;
    }
    save();
    if (w.vtable != b.idVtable)
        return false;
    at(PreviewSelectorStage::WeaponValue);
    if (!read(w.node + 0x18, w.value)) {
        save();
        return false;
    }
    save();
    if (!w.value)
        return false;
    at(PreviewSelectorStage::WeaponSymbol);
    if (!read(b.ssg08Symbol, w.symbol)) {
        save();
        return false;
    }
    save();
    if (!w.symbol)
        return false;
    at(PreviewSelectorStage::WeaponMatch);
    if (w.value != w.symbol)
        return false;
    PreviewCtBinding ct;
    if (!ResolvePreviewCtBinding(read, b, s.owner, ct) || ct.value != (terrorist ? 0 : 1))
        return false;
    at(PreviewSelectorStage::ChildContext);
    s.graph = context - 0x40;

    if (s.graph == s.owner.graph)
        return false;
    auto member = [&](std::uintptr_t graph, std::uintptr_t candidate) {
        std::int32_t n = 0;
        std::uintptr_t table = 0, definition = 0, p = 0;
        std::uint16_t compiled = 0;
        return read(graph + 8, n) && n > 0 && n <= 4096 && read(graph + 0x10, table) && table &&
               read(candidate + 8, definition) && definition && read(definition + 8, compiled) &&
               compiled < unsigned(n) && read(table + std::uintptr_t(compiled) * 8, p) && p == candidate;
    };
    at(PreviewSelectorStage::NodeMember);
    if (!member(s.graph, node))
        return false;

    at(PreviewSelectorStage::ChildPath);
    std::array<std::uintptr_t, 32> queue{};
    queue[0] = s.owner.graph;
    unsigned used = 1;
    bool found = false;
    for (unsigned q = 0; q < used && !found; ++q) {
        std::int32_t n = 0;
        std::uintptr_t table = 0;
        if (!read(queue[q] + 8, n) || n < 1 || n > 4096 || !read(queue[q] + 0x10, table) || !table)
            return false;
        for (int i = 0; i < n; ++i) {
            std::uintptr_t p = 0, child = 0;
            if (!read(table + std::uintptr_t(i) * 8, p) || !p || !read(p, vt))
                return false;
            if (vt != b.referencedVtable)
                continue;
            if (!member(queue[q], p) || !read(p + 0x28, child) || !child)
                continue;
            if (child == s.graph) {
                found = true;
                break;
            }
            bool seen = false;
            for (unsigned j = 0; j < used; ++j)
                if (queue[j] == child) {
                    seen = true;
                    break;
                }
            if (!seen) {
                if (used == queue.size())
                    return false;
                queue[used++] = child;
            }
        }
    }
    if (!found)
        return false;

    at(PreviewSelectorStage::SeedInput);
    std::uintptr_t input = 0;
    if (!read(node + 0x58, input) || !input || !read(input, vt) || vt != t.floatVtable ||
        !read(input + 0x14, refs) || refs < 1 || !member(s.graph, input))
        return false;
    s.targetClip = clips[unsigned(s.targetIndex)];
    out = s;
    at(PreviewSelectorStage::Accepted);
    return true;
}
}
