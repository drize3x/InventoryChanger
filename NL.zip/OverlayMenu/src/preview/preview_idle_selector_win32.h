#pragma once
#include <atomic>
#include <mutex>
#include <string>
#include "preview_idle_selector_scope.h"
#ifndef MENU_STUDIO_IDLE_SELECTOR_TEST
#include <Windows.h>
#include <MinHook.h>
#endif
namespace menu {

class PreviewIdleSelectorLock {
    using WeaponSetter = void(__fastcall*)(void*, const void*);
    inline static WeaponSetter nextWeapon_ = nullptr;
    std::atomic<unsigned long long> ctApplied_{0};
    using Choose = int(__fastcall*)(void*, void*);
    using Update = void*(__fastcall*)(void*, void*, void*, void*);
    using Shutdown = void(__fastcall*)(void*, void*);
    using Initialize = void(__fastcall*)(void*, void*, const std::uint64_t*);
    using Valid = bool(__fastcall*)(void*);
    inline static std::atomic<PreviewIdleSelectorLock*> instance_{nullptr};
    inline static Choose nextChoose_ = nullptr;
    inline static Update nextUpdate_ = nullptr;
    inline static thread_local PreviewIdleSelectorLock* forcing_ = nullptr;
    inline static thread_local void* forcedNode_ = nullptr;
    inline static thread_local void* forcedContext_ = nullptr;
    inline static thread_local int forcedTarget_ = PreviewDesiredClipIndex, forcedCount_ = 4;
    std::atomic<bool> terrorist_{false};
    PreviewIdleSelectorBindings b_{};
    void* hooks_[3] = {nullptr, nullptr, nullptr};
    bool created_[3] = {false, false, false}, enabled_[3] = {false, false, false};
    std::atomic<bool> ready_{false}, stopping_{false}, fault_{false};
    std::atomic<unsigned> active_{0};
    std::atomic<std::uintptr_t> panel_{0};
    std::atomic<ULONGLONG> selectedAt_{0}, lastProbe_{0};
    std::atomic<unsigned long long> matches_{0}, reselected_{0}, forced_{0};
    std::atomic<int> choiceBefore_{-1}, choiceAfter_{-1}, cachedAfter_{-1};
    std::atomic<unsigned long long> updateEntries_{0}, choiceEntries_{0}, liveUpdates_{0}, liveChoices_{0},
        initialMatches_{0}, initialForced_{0};
    std::atomic<PreviewSelectorStage> updateStage_{PreviewSelectorStage::Entry},
        choiceStage_{PreviewSelectorStage::Entry};
    static constexpr std::size_t StageCount = static_cast<std::size_t>(PreviewSelectorStage::Count);
    std::array<std::atomic<unsigned long long>, StageCount> updateRejected_{}, choiceRejected_{};
    mutable std::mutex probeMutex_;
    PreviewWeaponProbe updateProbe_{}, choiceProbe_{};
    PreviewSelectorStage updateProbeStage_ = PreviewSelectorStage::Entry,
                         choiceProbeStage_ = PreviewSelectorStage::Entry;
    std::string setup_ = "not initialized";
    bool Scope(std::uintptr_t panel, std::uintptr_t node, std::uintptr_t context, PreviewSelectorScope& out,
               bool choosing) {
        auto read = [](std::uintptr_t a, auto& v) { return Read(a, v); };
        PreviewSelectorStage stage = PreviewSelectorStage::Entry;
        PreviewWeaponProbe probe;
        bool ok =
            ResolvePreviewSelectorScope(read, b_, panel, node, context, out, &stage, choosing, &probe, false);
        if (probe.rootGraph) {
            std::lock_guard<std::mutex> guard(probeMutex_);
            (choosing ? choiceProbe_ : updateProbe_) = probe;
            (choosing ? choiceProbeStage_ : updateProbeStage_) = stage;
        }
        (choosing ? choiceStage_ : updateStage_).store(stage);
        if (!ok)
            ++(choosing ? choiceRejected_ : updateRejected_)[static_cast<unsigned>(stage)];
        return ok;
    }
    static std::string Rejections(const std::array<std::atomic<unsigned long long>, StageCount>& counters) {
        std::string text;
        for (unsigned i = 0; i < counters.size(); ++i) {
            const auto count = counters[i].load();
            if (count) {
                if (!text.empty())
                    text += ",";
                text += PreviewSelectorStageName(static_cast<PreviewSelectorStage>(i));
                text += "=" + std::to_string(count);
            }
        }
        return text.empty() ? "none" : text;
    }
    std::string WeaponDiagnostic() const {
        PreviewWeaponProbe u, c;
        PreviewSelectorStage us, cs;
        {
            std::lock_guard<std::mutex> guard(probeMutex_);
            u = updateProbe_;
            c = choiceProbe_;
            us = updateProbeStage_;
            cs = choiceProbeStage_;
        }
        auto format = [&](const char* name, const PreviewWeaponProbe& w, PreviewSelectorStage stage) {
            std::ostringstream text;
            text << "; " << name << "={stage=" << PreviewSelectorStageName(stage) << "; index=" << w.index
                 << "; seed-index=" << w.seedIndex << "; count=" << w.count << std::hex << "; root=0x"
                 << w.rootGraph << "; binding=0x" << w.bindingGraph << "; node=0x" << w.node << "; vt=0x"
                 << w.vtable << "; expected-vt=0x" << b_.idVtable << "; value=0x" << w.value << "; ssg08=0x"
                 << w.symbol << "; symbol-address=0x" << w.symbolAddress << "}";
            return text.str();
        };
        return format("update-weapon", u, us) + format("choice-weapon", c, cs);
    }
    static bool Bytes(std::uintptr_t a, void* out, std::size_t n) {
        SIZE_T got = 0;
        return a && ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(a), out, n, &got) &&
               got == n;
    }
    template <class T> static bool Read(std::uintptr_t a, T& v) {
        return Bytes(a, &v, sizeof(v));
    }
    static bool ValidClip(std::uintptr_t fn, std::uintptr_t node) {
#ifdef MENU_STUDIO_IDLE_SELECTOR_TEST
        try {
            return reinterpret_cast<Valid>(fn)(reinterpret_cast<void*>(node));
        } catch (...) {
            return false;
        }
#else
        __try {
            return reinterpret_cast<Valid>(fn)(reinterpret_cast<void*>(node));
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
#endif
    }
    static bool NativeReenter(const PreviewIdleSelectorBindings& b, void* node, void* context) {

        const std::uint64_t zeroSync = 0;
#ifdef MENU_STUDIO_IDLE_SELECTOR_TEST
        try {
#else
        __try {
#endif
            reinterpret_cast<Shutdown>(b.shutdownWrapper)(node, context);
            reinterpret_cast<Initialize>(b.initialize)(node, context, &zeroSync);
            return true;
#ifdef MENU_STUDIO_IDLE_SELECTOR_TEST
        } catch (...) {
            return false;
        }
#else
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
#endif
    }
    bool Live(std::uintptr_t& panel) {
        if (!ready_.load(std::memory_order_acquire) || stopping_ || fault_)
            return false;
        panel = panel_.load(std::memory_order_acquire);
        const auto stamp = selectedAt_.load(), now = GetTickCount64();
        return panel && stamp && now >= stamp && now - stamp <= 350;
    }
    void Apply(void* object, void* context) {
        ++updateEntries_;
        std::uintptr_t panel = 0;
        if (forcing_ || !Live(panel))
            return;
        ++liveUpdates_;
        const auto node = reinterpret_cast<std::uintptr_t>(object),
                   ctx = reinterpret_cast<std::uintptr_t>(context);
        std::int32_t index = -1;

        if (!Read(node + 0x68, index) || index < 0 || index > 5) {
            updateStage_ = PreviewSelectorStage::CachedState;
            ++updateRejected_[static_cast<unsigned>(PreviewSelectorStage::CachedState)];
            return;
        }

        if (index == PreviewDesiredClipIndex) {
            const auto now = GetTickCount64(), old = lastProbe_.load();
            if (now >= old && now - old < 500)
                return;
            lastProbe_ = now;
        }
        auto read = [](std::uintptr_t a, auto& v) { return Read(a, v); };
        PreviewSelectorScope scope;
        if (!Scope(panel, node, ctx, scope, false))
            return;
        ++matches_;
        cachedAfter_ = scope.cached;
        if (scope.cached == scope.targetIndex)
            return;
        if (!ValidClip(b_.clipValid, scope.targetClip))
            return;

        PreviewSelectorScope current;
        std::uintptr_t currentPanel = 0;
        if (!Live(currentPanel) || currentPanel != panel ||
            !ResolvePreviewSelectorScope(read, b_, panel, node, ctx, current, nullptr, false, nullptr,
                                         false) ||
            current.owner.handle != scope.owner.handle || current.owner.entity != scope.owner.entity ||
            current.owner.controller != scope.owner.controller || current.graph != scope.graph ||
            current.targetClip != scope.targetClip || current.activeClip != scope.activeClip ||
            current.cached != scope.cached)
            return;
        forcing_ = this;
        forcedNode_ = object;
        forcedContext_ = context;
        forcedTarget_ = scope.targetIndex;
        forcedCount_ = scope.optionCount;
        const auto before = forced_.load();
        const bool ok = NativeReenter(b_, object, context);
        forcing_ = nullptr;
        forcedNode_ = forcedContext_ = nullptr;
        if (!ok) {
            fault_ = true;
            return;
        }
        std::int32_t refs = 0, cached = -1;
        std::uintptr_t active = 0;
        if (!Read(node + 0x14, refs) || refs != 1 || !Read(node + 0x68, cached) ||
            cached != scope.targetIndex || !Read(node + 0x60, active) || active != scope.targetClip ||
            forced_.load() == before) {
            fault_ = true;
            return;
        }
        cachedAfter_ = cached;
        ++reselected_;
    }
    static int ChooseBody(PreviewIdleSelectorLock* self, void* node, void* context) {
        const int result = nextChoose_(node, context);
        if (self && forcing_ == self && forcedNode_ == node && forcedContext_ == context && result >= 0 &&
            result < forcedCount_) {
            self->choiceBefore_ = result;
            self->choiceAfter_ = forcedTarget_;
            ++self->forced_;
            return forcedTarget_;
        }
        if (!self)
            return result;
        std::uintptr_t panel = 0;
        if (forcing_ || result < 0 || result >= 6 || !self->Live(panel))
            return result;
        ++self->liveChoices_;
        PreviewSelectorScope scope;
        const auto n = reinterpret_cast<std::uintptr_t>(node),
                   ctx = reinterpret_cast<std::uintptr_t>(context);
        if (!self->Scope(panel, n, ctx, scope, true) || result >= scope.optionCount ||
            !ValidClip(self->b_.clipValid, scope.targetClip))
            return result;

        PreviewSelectorScope current;
        std::uintptr_t again = 0;
        if (!self->Live(again) || again != panel || !self->Scope(panel, n, ctx, current, true) ||
            current.owner.handle != scope.owner.handle || current.owner.entity != scope.owner.entity ||
            current.owner.controller != scope.owner.controller || current.graph != scope.graph ||
            current.targetClip != scope.targetClip)
            return result;
        ++self->initialMatches_;
        if (result != scope.targetIndex)
            ++self->initialForced_;
        self->choiceBefore_ = result;
        self->choiceAfter_ = scope.targetIndex;
        return scope.targetIndex;
    }
    static int __fastcall ChooseHook(void* node, void* context) {
        auto* self = instance_.load(std::memory_order_acquire);
        if (!nextChoose_)
            return -1;
        if (!self)
            return nextChoose_(node, context);
        ++self->active_;
        ++self->choiceEntries_;
        int result = -1;
#ifdef MENU_STUDIO_IDLE_SELECTOR_TEST
        try {
            result = ChooseBody(self, node, context);
        } catch (...) {
            --self->active_;
            throw;
        }
        --self->active_;
#else
        __try {
            result = ChooseBody(self, node, context);
        } __finally {
            --self->active_;
        }
#endif
        return result;
    }
    static void* __fastcall UpdateHook(void* node, void* out, void* context, void* range) {
        auto* self = instance_.load(std::memory_order_acquire);
        if (!nextUpdate_)
            return out;
        if (!self)
            return nextUpdate_(node, out, context, range);
        ++self->active_;
        void* result = nullptr;
#ifdef MENU_STUDIO_IDLE_SELECTOR_TEST
        try {
            self->Apply(node, context);
            result = nextUpdate_(node, out, context, range);
        } catch (...) {
            --self->active_;
            throw;
        }
        --self->active_;
#else
        __try {
            self->Apply(node, context);
            result = nextUpdate_(node, out, context, range);
        } __finally {
            --self->active_;
        }
#endif
        return result;
    }
    static bool SetCtNative(std::uintptr_t fn, std::uintptr_t entity) {
#ifdef MENU_STUDIO_IDLE_SELECTOR_TEST
        try {
#else
        __try {
#endif
            reinterpret_cast<void(__fastcall*)(void*, bool)>(fn)(reinterpret_cast<void*>(entity), true);
            return true;
#ifdef MENU_STUDIO_IDLE_SELECTOR_TEST
        } catch (...) {
            return false;
        }
#else
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
#endif
    }
    void ApplyCtPose(void* object) {
        std::uintptr_t panel = 0;
        if (!terrorist_.load() || !Live(panel))
            return;
        auto read = [](std::uintptr_t a, auto& v) { return Read(a, v); };
        PreviewIdleOwner owner, current;
        PreviewCtBinding ct, again;
        const auto controller = reinterpret_cast<std::uintptr_t>(object);
        if (!ResolvePreviewIdleOwner(read, b_.owner.types, panel, controller, owner) ||
            !ResolvePreviewCtBinding(read, b_, owner, ct))
            return;
        if (ct.value == 1)
            return;
        std::uintptr_t weaponGraph = 0, table = 0, node = 0, vt = 0, value = 0, ssg = 0;
        std::int16_t index = -1;
        std::int32_t count = 0;
        if (!read(controller + PreviewIdleSelectorBindings::WeaponTypeGraphOffset, weaponGraph) ||
            weaponGraph != owner.graph ||
            !read(controller + PreviewIdleSelectorBindings::WeaponTypeIndexOffset, index) || index < 0 ||
            !read(weaponGraph + 8, count) || count < 1 || count > 4096 || index >= count ||
            !read(weaponGraph + 0x10, table) || !table || !read(table + std::uintptr_t(index) * 8, node) ||
            !node || !read(node, vt) || vt != b_.idVtable || !read(node + 0x18, value) ||
            !read(b_.ssg08Symbol, ssg) || !ssg || value != ssg)
            return;
        std::uintptr_t live = 0;
        if (!Live(live) || live != panel || !terrorist_.load() ||
            !ResolvePreviewIdleOwner(read, b_.owner.types, panel, controller, current) ||
            current.entity != owner.entity || current.handle != owner.handle ||
            current.graph != owner.graph || !ResolvePreviewCtBinding(read, b_, current, again) ||
            again.node != ct.node || again.index != ct.index)
            return;

        if (!SetCtNative(b_.ctSetter, current.entity)) {
            fault_ = true;
            return;
        }
        if (!ResolvePreviewCtBinding(read, b_, current, again) || again.node != ct.node || again.value != 1) {
            fault_ = true;
            return;
        }
        ++ctApplied_;
    }
    static void __fastcall WeaponHook(void* controller, const void* value) {
        auto self = instance_.load(std::memory_order_acquire);
        if (!nextWeapon_)
            return;
        if (!self) {
            nextWeapon_(controller, value);
            return;
        }
        ++self->active_;
#ifdef MENU_STUDIO_IDLE_SELECTOR_TEST
        try {
            nextWeapon_(controller, value);
            self->ApplyCtPose(controller);
        } catch (...) {
            --self->active_;
            throw;
        }
        --self->active_;
#else
        __try {
            nextWeapon_(controller, value);
            self->ApplyCtPose(controller);
        } __finally {
            --self->active_;
        }
#endif
    }
    bool StartResolved(const PreviewIdleSelectorBindings& b) {
        if (ready_)
            return true;
        if (created_[0] || created_[1] || created_[2] || instance_.load())
            return false;
        b_ = b;
        stopping_ = false;
        fault_ = false;
        hooks_[0] = reinterpret_cast<void*>(b.choice);
        hooks_[1] = reinterpret_cast<void*>(b.update);
        hooks_[2] = reinterpret_cast<void*>(b.weaponSetter);
        instance_.store(this, std::memory_order_release);
        void* detours[3] = {reinterpret_cast<void*>(ChooseHook), reinterpret_cast<void*>(UpdateHook),
                            reinterpret_cast<void*>(WeaponHook)};
        void* originals[3] = {nullptr, nullptr, nullptr};
        for (unsigned i = 0; i < 3; ++i) {
            if (MH_CreateHook(hooks_[i], detours[i], &originals[i]) != MH_OK) {
                setup_ += "; hook creation failed";
                Stop();
                return false;
            }
            created_[i] = true;
            if (i == 0)
                nextChoose_ = reinterpret_cast<Choose>(originals[i]);
            else if (i == 1)
                nextUpdate_ = reinterpret_cast<Update>(originals[i]);
            else
                nextWeapon_ = reinterpret_cast<WeaponSetter>(originals[i]);
        }
        for (unsigned i = 0; i < 3; ++i) {
            if (MH_EnableHook(hooks_[i]) != MH_OK) {
                setup_ += "; hook enabling failed";
                Stop();
                return false;
            }
            enabled_[i] = true;
        }
        ready_.store(true, std::memory_order_release);
        return true;
    }

public:
    bool Start(const HudScanImage& c, const HudScanImage& a, std::uintptr_t panelVtable,
               std::string& diagnostic) {
        if (ready_) {
            diagnostic = Diagnostic();
            return true;
        }
        PreviewIdleSelectorBindings b;
        if (!ResolvePreviewIdleSelector(c, a, panelVtable, b, setup_)) {
            diagnostic = setup_;
            return false;
        }
        const bool ok = StartResolved(b);
        diagnostic = Diagnostic();
        return ok;
    }
    void Select(std::uintptr_t panel, bool terrorist = false) {
        terrorist_.store(terrorist, std::memory_order_release);
        selectedAt_.store(panel ? GetTickCount64() : 0, std::memory_order_release);
        panel_.store(panel, std::memory_order_release);
    }

    void PrimeCtPose() {
        std::uintptr_t panel = 0;
        if (!terrorist_.load() || !Live(panel))
            return;
        ++active_;
        struct ActiveGuard {
            std::atomic<unsigned>& n;
            ~ActiveGuard() {
                --n;
            }
        } guard{active_};
        std::uintptr_t vt = 0, records = 0, system = 0, chunk = 0, entity = 0, controller = 0;
        std::int32_t active = -1, count = 0;
        std::uint32_t handle = 0;
        if (!Read(panel, vt) || vt != b_.owner.types.panelVtable || !Read(panel + 0x8ec, active) ||
            !Read(panel + 0x8f0, count) || count < 1 || count > 64 || active < 0 || active >= count ||
            !Read(panel + 0x8f8, records) || !records ||
            !Read(records + std::uintptr_t(active) * 0xa0, handle) || handle >= 0xfffffffeu ||
            !Read(b_.owner.types.entitySystemGlobal, system) || !system)
            return;
        const auto slot = handle & 0x7fffu;
        if (!Read(system + std::uintptr_t(slot >> 9) * 8, chunk) || !chunk ||
            !Read(chunk + std::uintptr_t(slot & 0x1ffu) * 0x70, entity) || !entity ||
            !Read(entity + 0x37b8, controller) || !controller)
            return;
        ApplyCtPose(reinterpret_cast<void*>(controller));
    }
    std::string Diagnostic() const {
        return std::string("Idle selector v5-shouldershrug: ") +
               (fault_   ? "native lifecycle fault/mismatch; disabled; unload blocked"
                : ready_ ? "owned native-choice + Update fallback armed"
                         : "not armed") +
               "; target-index=2; requested-clip=ct_main_menu_rifle_ssg08_shouldershrug; T-CT-pose-applied=" +
               std::to_string(ctApplied_.load()) +
               "; update-entries=" + std::to_string(updateEntries_.load()) +
               "; live-updates=" + std::to_string(liveUpdates_.load()) +
               "; choice-entries=" + std::to_string(choiceEntries_.load()) +
               "; live-choices=" + std::to_string(liveChoices_.load()) +
               "; initial-matches=" + std::to_string(initialMatches_.load()) +
               "; initial-forced=" + std::to_string(initialForced_.load()) +
               "; update-stage=" + PreviewSelectorStageName(updateStage_.load()) +
               "; choice-stage=" + PreviewSelectorStageName(choiceStage_.load()) + "; update-rejected={" +
               Rejections(updateRejected_) + "}; choice-rejected={" + Rejections(choiceRejected_) + "}" +
               "; matched-updates=" + std::to_string(matches_.load()) +
               "; reselected=" + std::to_string(reselected_.load()) +
               "; choice-original=" + std::to_string(choiceBefore_.load()) +
               "; choice-effective=" + std::to_string(choiceAfter_.load()) +
               "; cached-index=" + std::to_string(cachedAfter_.load()) +
               "; clip NAME/appearance NOT runtime-verified; " + setup_ + WeaponDiagnostic();
    }
    bool Stop() {
        stopping_ = true;
        ready_ = false;
        Select(0);
        auto disable = [&](unsigned i) {
            if (!enabled_[i])
                return true;
            auto status = MH_DisableHook(hooks_[i]);
            if (status != MH_OK && status != MH_ERROR_DISABLED)
                return false;
            enabled_[i] = false;
            return true;
        };

        if (!disable(2) || !disable(1))
            return false;
        auto until = GetTickCount64() + 2000;
        while (active_ && GetTickCount64() < until)
            Sleep(1);
        if (active_)
            return false;
        if (!disable(0))
            return false;
        until = GetTickCount64() + 2000;
        while (active_ && GetTickCount64() < until)
            Sleep(1);
        if (active_)
            return false;
        if (created_[0] || created_[1] || created_[2]) {
            Sleep(100);
            if (active_)
                return false;
        }
        for (unsigned i = 0; i < 3; ++i)
            if (created_[i]) {
                if (MH_RemoveHook(hooks_[i]) != MH_OK)
                    return false;
                created_[i] = false;
            }
        if (instance_.load() == this)
            instance_.store(nullptr, std::memory_order_release);
        return !fault_;
    }
#ifdef MENU_STUDIO_IDLE_SELECTOR_TEST
    bool TestStart(const PreviewIdleSelectorBindings& b) {
        setup_ = "synthetic test";
        return StartResolved(b);
    }
    static void TestWeapon(void* c, const void* v) {
        WeaponHook(c, v);
    }
    static int TestChoose(void* n, void* c) {
        return ChooseHook(n, c);
    }
    static void* TestUpdate(void* n, void* o, void* c, void* r) {
        return UpdateHook(n, o, c, r);
    }
    unsigned long long Reselected() const {
        return reselected_.load();
    }
#endif
};
}
