#pragma once
#include "equipment_icon_catalog.h"
#include "inventory_charm_attributes.h"
#include "inventory_decorations.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <sstream>
#include <locale>
#include <string>
#include <vector>
namespace menu {
enum class NativePreviewScene { Players = 0, InventoryLoadout = 1, InventoryGlock = 2 };
struct NativePreviewRequest {
    bool enabled = false;
    float x = 0, y = 0, w = 0, h = 0;
    int screenW = 0, screenH = 0;
    float red = .04f, green = .04f, blue = .05f;
    bool terrorist = false;
    bool icons = false;
    std::array<int, 5> premier{{-1, -1, -1, -1, -1}};
    local_decorations::Values decorations{};
    charm::Values charm{};
    int stickerLiveSlot = -1;
    bool stickerDragging = false;
    bool charmLive = false;
    bool charmPlacementProbe = false;
    unsigned itemWidth = 512, itemHeight = 384;
    int itemDefinition = 4, paintKit = 0, itemActiveIndex = 0;
    bool itemMusic = false;
    float yaw = 0, pitch = 0;
    NativePreviewScene scene = NativePreviewScene::Players;
};
inline bool PreviewIsItem(const NativePreviewRequest& r) {
    return r.scene == NativePreviewScene::InventoryGlock;
}
inline unsigned PreviewServiceWidth(const NativePreviewRequest& r) {
    return PreviewIsItem(r) ? r.itemWidth : 350u;
}
inline unsigned PreviewServiceHeight(const NativePreviewRequest& r) {
    return PreviewIsItem(r) ? r.itemHeight : 600u;
}
inline int PreviewSurfaceTag(const NativePreviewRequest& r) {
    return PreviewIsItem(r) ? 2 : r.terrorist ? 1 : 0;
}
inline bool PreviewItemValid(const NativePreviewRequest& r) {
    return r.stickerLiveSlot >= -1 && r.stickerLiveSlot < 5 && charm::Valid(r.charm) &&
           local_decorations::Valid(r.decorations) &&
           (!PreviewIsItem(r) ||
            ((r.itemDefinition > 0 && r.itemDefinition <= 65535) &&
             (!r.itemMusic || (r.itemDefinition == 1314 && r.paintKit > 0)) && r.itemWidth >= 32 &&
             r.itemWidth <= 4096 && r.itemWidth % 32 == 0 && r.itemHeight >= 32 && r.itemHeight <= 4096 &&
             r.itemHeight % 32 == 0 &&
             (r.itemActiveIndex == 0 || r.itemActiveIndex == 3 || r.itemActiveIndex == 4 ||
              r.itemActiveIndex == 7 || r.itemActiveIndex == 8) &&
             r.paintKit >= 0 && r.paintKit <= 65535 && std::isfinite(r.yaw) && std::isfinite(r.pitch) &&
             std::abs(r.yaw) <= 360 && std::abs(r.pitch) <= 85));
}
inline bool PreviewRequestValid(const NativePreviewRequest& r) {
    return r.enabled &&
           (r.scene == NativePreviewScene::Players || r.scene == NativePreviewScene::InventoryLoadout ||
            PreviewIsItem(r)) &&
           PreviewItemValid(r) && r.screenW > 0 && r.screenH > 0 && std::isfinite(r.x) &&
           std::isfinite(r.y) && std::isfinite(r.w) && std::isfinite(r.h) && r.w >= 16 && r.h >= 16 &&
           r.x >= 0 && r.y >= 0 && r.x + r.w <= r.screenW + .01f && r.y + r.h <= r.screenH + .01f;
}
inline bool PreviewSameGeometry(const NativePreviewRequest& a, const NativePreviewRequest& b) {
    return a.enabled == b.enabled && a.screenW == b.screenW && a.screenH == b.screenH && a.x == b.x &&
           a.y == b.y && a.w == b.w && a.h == b.h;
}
inline std::string PreviewHostId(std::uint64_t token) {
    return "MenuStudioPreview_" + std::to_string(token);
}
inline std::string PreviewItemPanelId(std::uint64_t generation) {
    return "nlpreview_" + std::to_string(generation);
}
inline std::uint64_t PreviewSideToken(std::uint64_t token, bool terrorist) {
    return token * 2 + (terrorist ? 1 : 0);
}
inline bool PreviewHasPremier(const NativePreviewRequest& r) {
    return PreviewIsItem(r) && r.itemActiveIndex == 3 &&
           std::any_of(r.premier.begin(), r.premier.end(), [](int v) { return v >= 0; });
}
inline bool PreviewHasDecorations(const NativePreviewRequest& r) {
    return r.charm.id > 0 || local_decorations::Any(r.decorations);
}
inline bool PreviewCharmSame(const charm::Values& a, const charm::Values& b) {
    return a.id == b.id && a.seed == b.seed && a.x == b.x && a.y == b.y && a.z == b.z;
}
inline std::uint64_t PreviewFauxCharmId(const NativePreviewRequest& r) {
    return 0xf000000000000000ULL | (std::uint64_t(255) << 32) | (std::uint64_t(r.paintKit) << 16) |
           std::uint64_t(r.itemDefinition);
}

inline std::string BuildPremierWarmupScript(const NativePreviewRequest& r) {
    if (!PreviewHasPremier(r))
        return {};
    return "(function(){try{InventoryAPI.GetFauxItemIDFromDefAndPaintIndex(" +
           std::to_string(r.itemDefinition) + ",0);}catch(e){}})();";
}

inline void PreviewStaticStickerPlacement(NativePreviewRequest& r, bool dragging, int slot,
                                          const local_decorations::Sticker& original) {
    r.stickerLiveSlot = -1;
    r.stickerDragging = false;
    if (dragging && slot >= 0 && slot < 5)
        r.decorations.stickers[std::size_t(slot)] = original;
}
inline local_decorations::Sticker PreviewBaseSticker(const NativePreviewRequest& r, int slot) {
    if (slot < 0 || slot >= 5 || slot == r.stickerLiveSlot)
        return {};
    return r.decorations.stickers[std::size_t(slot)];
}
inline bool PreviewStickerSceneSame(const NativePreviewRequest& a, const NativePreviewRequest& b) {
    if (a.stickerLiveSlot != b.stickerLiveSlot)
        return false;
    auto x = a.decorations, y = b.decorations;
    const int slot = a.stickerLiveSlot;
    if (slot >= 0 && slot < 5) {
        auto &sx = x.stickers[std::size_t(slot)], &sy = y.stickers[std::size_t(slot)];
        if (sx.id != sy.id)
            return false;
        sx.x = sy.x = 0;
        sx.y = sy.y = 0;
        sx.rotation = sy.rotation = 0;
    }
    return x == y;
}
inline bool PreviewSameScene(const NativePreviewRequest& a, const NativePreviewRequest& b) {
    return a.scene == b.scene &&
           (PreviewIsItem(a)
                ? a.itemDefinition == b.itemDefinition && a.paintKit == b.paintKit &&
                      a.itemMusic == b.itemMusic && a.itemActiveIndex == b.itemActiveIndex &&
                      a.premier == b.premier && a.itemWidth == b.itemWidth && a.itemHeight == b.itemHeight &&
                      PreviewStickerSceneSame(a, b) && a.charmPlacementProbe == b.charmPlacementProbe &&
                      a.charmLive == b.charmLive &&
                      (a.charmLive ? (a.charm.id == b.charm.id && a.charm.seed == b.charm.seed)
                                   : PreviewCharmSame(a.charm, b.charm))
                : a.terrorist == b.terrorist);
}
inline std::string PreviewRequestHostId(std::uint64_t token, const NativePreviewRequest& r) {
    if (PreviewIsItem(r))
        return PreviewHostId(token) + "_Glock";
    return PreviewHostId(PreviewSideToken(token, r.terrorist)) +
           (r.scene == NativePreviewScene::InventoryLoadout ? "_Inventory" : "");
}
inline const char* PreviewDefaultModel(bool terrorist) {
    return terrorist ? "agents/models/tm_phoenix/tm_phoenix.vmdl" : "agents/models/ctm_sas/ctm_sas.vmdl";
}
inline const char* PreviewAnimationMode(const NativePreviewRequest& r) {
    return r.scene == NativePreviewScene::InventoryLoadout ? "buy-menu" : "inventory-inspect";
}

inline const char* PreviewDefaultEquipment(const NativePreviewRequest& r) {
    return r.scene == NativePreviewScene::InventoryLoadout
               ? (r.terrorist ? "17293822569102704647" : "17293822569102704656")
               : "17293822569102704680";
}

inline std::string BuildEquipmentIconScript(std::uint64_t token, const std::vector<std::string>& missing,
                                            bool remove = false) {
    std::ostringstream s;
    s << "(function(){try{var root=$.GetContextPanel(),id='MenuStudioEquipmentIcons_" << token
      << "',h=root.FindChildTraverse(id);";
    if (remove) {
        s << "if(h&&h.IsValid())h.DeleteAsync(0);";
    } else {
        s << R"JS(if(!h){h=$.CreatePanel('Panel',root,id);h.hittest=false;h.hittestchildren=false;
 h.style.width='1px';h.style.height='1px';h.style.opacity='0';h.style.ignoreParentFlow='true';h.SetAttributeString('ms_lease',String(Date.now()));
 (function lease(){if(!h||!h.IsValid())return;if(Date.now()-Number(h.GetAttributeString('ms_lease','0'))>1500){h.DeleteAsync(0);return;}$.Schedule(.25,lease);})();}
 h.SetAttributeString('ms_lease',String(Date.now()));var names=[)JS";
        bool comma = false;
        for (const auto& name : missing) {
            bool allowed = false;
            for (auto n : LiveEquipmentIconNames)
                if (name == n) {
                    allowed = true;
                    break;
                }
            if (!allowed)
                continue;
            if (comma)
                s << ",";
            comma = true;
            s << "'" << name << "'";
        }
        s << R"JS(];names.forEach(function(name){var id='ms_icon_'+name,image=h.FindChildTraverse(id);
 if(!image){image=$.CreatePanel('Image',h,id);image.hittest=false;image.hittestchildren=false;image.style.ignoreParentFlow='true';image.style.width=name==='flair0'?'32px':'64px';image.style.height='32px';}
 var now=Date.now();if(now-Number(image.GetAttributeString('ms_request','0'))>2000){image.SetAttributeString('ms_request',String(now));image.SetImage('file://{images}/icons/equipment/'+name+'.svg');}});)JS";
    }
    s << "}catch(e){}})();";
    return s.str();
}

inline const char* PreviewItemCamera(int def) {
    switch (def) {
    case 31:
        return "cam_0";
    case 64:
        return "cam_1";
    case 2:
    case 30:
    case 61:
        return "cam_2";
    case 7:
    case 10:
    case 16:
    case 25:
    case 39:
        return "cam_4";
    case 11:
    case 28:
    case 35:
    case 38:
        return "cam_5";
    case 14:
    case 40:
    case 60:
        return "cam_6";
    case 9:
        return "cam_7";
    default:
        return "cam_3";
    }
}
inline void PreviewWriteItemState(std::ostringstream& s, const NativePreviewRequest& r,
                                  std::uint64_t generation) {

    s << "var wanted='" << PreviewItemPanelId(generation) << "',prev=h.GetAttributeString('ms_child','');"
      << "if(prev!==wanted){h.visible=false;var "
         "stale=prev?h.FindChildTraverse(prev):null;if(stale&&stale.IsValid()){stale.visible=false;stale."
         "DeleteAsync(0);}h.SetAttributeString('ms_child',wanted);h.SetAttributeString('ms_item','');h."
         "SetAttributeString('ms_camera','');}"
      << R"JS(var p=h.FindChildTraverse(wanted);
 if(!p||!p.IsValid()){
 p=$.CreatePanel('MapItemPreviewPanel',h,wanted,{
  'require-composition-layer':'true','map':'warehouse_vanity','camera':'cam_default',
  'initial_entity':'item','player':'false','auto_recenter':'true','workshop_preview':'false',
  'transparent-background':'true','mouse_rotate':'false','disable-depth-of-field':'true',
  'sticker_application_mode':')JS"
      << (r.stickerLiveSlot >= 0 ? "true" : "false") << R"JS(',
  'keychain_application_mode':')JS"
      << (r.charmPlacementProbe && r.charm.id > 0 ? "true" : "false") << R"JS(' 
 });
 if(!p||!p.IsValid())throw new Error('MapItemPreviewPanel factory returned no panel');
 ['SetHideStaticGeometry','SetHideParticles','SetTransparentBackground'].forEach(function(name){
  if(typeof p[name]!=='function')throw new Error('required item preview API missing: '+name);p[name](1);
 });
 p.hittest=false;p.hittestchildren=false;p.style.width='100%';p.style.height='100%';p.style.backgroundColor='transparent';
 h.SetAttributeString('ms_item','');h.SetAttributeString('ms_camera','');
 }
 )JS";
    s << "var root=$.GetContextPanel(),sx=root.actualuiscalex||1,sy=root.actualuiscaley||1;h.style.width=("
      << r.itemWidth << "/sx)+'px';h.style.height=(" << r.itemHeight << "/sy)+'px';";

    const char* camera = r.itemActiveIndex == 8   ? "cam_melee"
                         : r.itemActiveIndex == 7 ? "cam_gloves"
                         : r.itemActiveIndex == 3 ? "cam_display_close"
                         : r.itemMusic            ? "cam_musickit_close"
                                                  : PreviewItemCamera(r.itemDefinition);
    const int activeItem = r.itemMusic ? 4 : r.itemActiveIndex;
    s << "var itemKey='" << r.itemDefinition << ":" << r.paintKit << (r.itemMusic ? ":music" : "") << ":"
      << activeItem << "';if(h.GetAttributeString('ms_item','')!==itemKey){"
      << "if(typeof InventoryAPI==='undefined'||typeof "
         "InventoryAPI.GetFauxItemIDFromDefAndPaintIndex!=='function'||typeof "
         "p.SetItemItemId!=='function')throw new Error('item preview API unavailable');"
      << ((PreviewHasDecorations(r) || PreviewHasPremier(r))
              ? "var item='" + std::to_string(PreviewFauxCharmId(r)) + "';"
              : "var item=InventoryAPI.GetFauxItemIDFromDefAndPaintIndex(" +
                    std::to_string(r.itemDefinition) + "," + std::to_string(r.paintKit) + ");")
      << "if(typeof item!=='string'||!(/^[0-9]{1,20}$/).test(item)||item==='0')throw new Error('faux item ID "
         "is not a uint64 string');";

    if (r.itemMusic)
        s << "if(typeof InventoryAPI.GetItemDefinitionIndex!=='function'||typeof "
             "InventoryAPI.GetItemAttributeValue!=='function'||InventoryAPI.GetItemDefinitionIndex(item)!=="
             "1314)throw new Error('music definition unavailable');"
          << "var music=InventoryAPI.GetItemAttributeValue(item,'music id');if(!((typeof "
             "music==='number'&&isFinite(music))||(typeof "
             "music==='string'&&/^[0-9]+$/.test(music)))||Number(music)!=="
          << r.paintKit << ")throw new Error('music id did not roundtrip');";

    s << "if(typeof p.SetActiveItem!=='function')throw new Error('item slot API "
         "unavailable');p.SetActiveItem("
      << activeItem << ");"
      << "if(p.SetItemItemId(item,'')===false)throw new Error('item preview rejected "
         "item');h.SetAttributeString('ms_item',itemKey);}"
      << "if(h.GetAttributeString('ms_camera','')!=='" << camera << "'){"
      << "if(typeof p.TransitionToCamera!=='function')throw new Error('item camera API unavailable');"
      << (r.itemActiveIndex == 7 ? "" : "p.TransitionToCamera('" + std::string(camera) + "_intro',0);")
      << "p.TransitionToCamera('" << camera << "'," << (r.itemActiveIndex == 7 ? "0" : "0.75")
      << ");h.SetAttributeString('ms_camera','" << camera << "');}";
    if (r.itemActiveIndex != 7)
        s << "if(typeof p.SetRotation!=='function')throw new Error('item rotation API unavailable');"
          << "if(p.SetRotation(" << r.yaw << "," << r.pitch
          << ",0)===false)throw new Error('item rotation rejected');";
}
inline std::string BuildNativeItemStateScript(const NativePreviewRequest& r, std::uint64_t token,
                                              std::uint64_t generation = 0) {
    if (!PreviewRequestValid(r) || !PreviewIsItem(r))
        return {};
    std::ostringstream s;
    s.imbue(std::locale::classic());
    s.precision(9);
    s << "/* MenuStudio Glock state */(function(){var h=null;try{h=$.GetContextPanel().FindChildTraverse('"
      << PreviewRequestHostId(token, r) << "');if(!h||!h.IsValid())return;";
    PreviewWriteItemState(s, r, generation);
    s << "}catch(e){if(h&&h.IsValid()){h.visible=false;h.DeleteAsync(0);}}})();";
    return s.str();
}
inline std::string BuildNativeItemPreviewScript(const NativePreviewRequest& r, std::uint64_t token,
                                                std::uint64_t generation = 0) {
    std::ostringstream s;
    s.imbue(std::locale::classic());
    s.precision(9);
    s << "(function(){var h=null;try{var root=$.GetContextPanel();h=root.FindChildTraverse('"
      << PreviewRequestHostId(token, r) << "');if(!h){h=$.CreatePanel('Panel',root,'"
      << PreviewRequestHostId(token, r) << "');";
    s << R"JS(h.visible=false;h.hittest=false;h.hittestchildren=false;
 h.SetAttributeString('ms_lease',String(Date.now()));
 (function lease(){if(!h||!h.IsValid())return;if(Date.now()-Number(h.GetAttributeString('ms_lease','0'))>1200){h.visible=false;h.DeleteAsync(0);return;}$.Schedule(.2,lease);})();
 }
)JS";
    PreviewWriteItemState(s, r, generation);
    s << R"JS(var sx=root.actualuiscalex||1,sy=root.actualuiscaley||1;
 h.style.position='0px 0px 0px';
 h.style.backgroundColor='transparent';h.style.horizontalAlign='left';h.style.verticalAlign='top';
 h.style.ignoreParentFlow='true';h.style.zIndex='9999';h.style.overflow='clip';
 h.SetAttributeString('ms_lease',String(Date.now()));
 }catch(e){if(h&&h.IsValid()){h.visible=false;h.DeleteAsync(0);}}})();)JS";
    return s.str();
}
inline std::string BuildNativePreviewScript(const NativePreviewRequest& r, std::uint64_t token,
                                            bool remove = false, std::uint64_t generation = 0) {
    if (!remove && PreviewRequestValid(r) && PreviewIsItem(r))
        return BuildNativeItemPreviewScript(r, token, generation);
    std::ostringstream s;
    s.imbue(std::locale::classic());
    s.precision(9);
    s << "(function(){var root=$.GetContextPanel(), h=null;try {var id='" << PreviewRequestHostId(token, r)
      << "'; h=root.FindChildTraverse(id);";
    if (remove || !PreviewRequestValid(r)) {
        s << "if(h&&h.IsValid()){h.visible=false;h.DeleteAsync(0);} }catch(e){} })();";
        return s.str();
    }
    s << "var model='" << PreviewDefaultModel(r.terrorist) << "';";
    s << R"JS(
if(!h){
 h=$.CreatePanel('Panel',root,id);h.visible=false;h.hittest=false;h.hittestchildren=false;
 h.SetAttributeString('ms_lease',String(Date.now()));
 // This closure is engine-owned JS, with NO pointers/callbacks into this DLL.
 // It deletes the panel after a stopped Present, root change or failed unload.
 (function lease(){if(!h||!h.IsValid())return;
  if(Date.now()-Number(h.GetAttributeString('ms_lease','0'))>1200){h.visible=false;h.DeleteAsync(0);return;}
  $.Schedule(.2,lease);
 })();
 var p=$.CreatePanel('MapPlayerPreviewPanel',h,'nlpreview',{
  'require-composition-layer':'true','map':'ui/buy_menu','player':'true',
  'camera':'cam_loadoutmenu_ct','animgraphcharactermode':')JS"
      << PreviewAnimationMode(r) << R"JS(',
  'transparent-background':'true',
  'playername':'vanity_character','playermodel':model,
  'disable-depth-of-field':'true','mouse_rotate':'false','sync_spawn_addons':'true',
  'hide_while_waiting_for_composite_materials':'false'
 });
 if(!p||!p.IsValid())throw new Error('MapPlayerPreviewPanel factory returned no panel');
 if(typeof p.BLoadLayout!=='function')throw new Error('preview BLoadLayout API unavailable');
 var loaded=p.BLoadLayout('file://{resources}/layout/avatar.xml',false,false);
 if(loaded===false)throw new Error('preview avatar.xml layout load failed');
 // Per-side scene identity: CT SAS or T Phoenix is requested at creation.
 // Players retains inventory-inspect (native enum 5); Inventory uses buy-menu (native enum 2).
 // Asset loading and actual native clip still require in-game verification.
 ['SetHideStaticGeometry','SetHideParticles','SetTransparentBackground'].forEach(function(name){
  if(typeof p[name]!=='function')throw new Error('required preview API missing: '+name);
  p[name](1);
 });
 if(typeof p.EquipPlayerWithItem!=='function')throw new Error('preview equipment API unavailable');
 p.EquipPlayerWithItem(')JS"
      << PreviewDefaultEquipment(r) << R"JS('); // exact uint64 decimal STRING, never JS Number
 p.hittest=false;p.hittestchildren=false;
 p.style.width='100%';p.style.height='100%';p.style.backgroundColor='transparent';
}
)JS";
    if (r.icons) {
        s << R"JS(
// Decode original game SVGs into an invisible noninteractive loader. SetImage
// owns asynchronous IO; the native hooks copy only allowlisted alpha masks.
try {if(!h.GetAttributeInt('ms_icon_requests',0)){
 )JS";
        s << "[";
        for (std::size_t i = 0; i < LiveEquipmentIconCount; ++i) {
            if (i)
                s << ",";
            s << "'" << LiveEquipmentIconNames[i] << "'";
        }
        s << "].forEach(function(name){";
        s << R"JS(
  var image=h.FindChildTraverse('ms_icon_'+name)||$.CreatePanel('Image',h,'ms_icon_'+name);image.hittest=false;image.hittestchildren=false;
  image.style.opacity='0';image.style.ignoreParentFlow='true';
  image.SetImage('file://{images}/icons/equipment/'+name+'.svg');
 });
 h.SetAttributeInt('ms_icon_requests',1);
}}catch(iconError){}
)JS";
    }
    s << R"JS(
var sx=root.actualuiscalex||1,sy=root.actualuiscaley||1;
var rw=root.actuallayoutwidth/sx,rh=root.actuallayoutheight/sy;
if(!(rw>0&&rh>0))throw new Error('UI root has no layout extent');
)JS";
    s << "h.style.position='0px 0px 0px';h.style.width=(350/sx)+'px';h.style.height=(600/sy)+'px';";
    s << "h.style.backgroundColor='transparent';";
    s << R"JS(h.style.horizontalAlign='left';h.style.verticalAlign='top';h.style.ignoreParentFlow='true';h.style.zIndex='9999';h.style.overflow='clip'; // native controller enables visibility only after capture is armed
h.SetAttributeString('ms_lease',String(Date.now()));
}catch(e){if(h&&h.IsValid()){h.visible=false;h.DeleteAsync(0);}}
})();)JS";
    return s.str();
}

inline constexpr int NativePreviewPoolSize = 5;
inline NativePreviewRequest PreviewServiceRequest(NativePreviewRequest r = {}) {
    if (r.scene != NativePreviewScene::Players && r.scene != NativePreviewScene::InventoryLoadout &&
        !PreviewIsItem(r))
        r.scene = NativePreviewScene::Players;
    r.enabled = true;
    r.x = 0;
    r.y = 0;
    r.w = float(PreviewServiceWidth(r));
    r.h = float(PreviewServiceHeight(r));
    r.screenW = int(r.w);
    r.screenH = int(r.h);
    return r;
}
inline int PreviewPoolSlot(const NativePreviewRequest& r) {
    return PreviewIsItem(r)
               ? 4
               : (r.scene == NativePreviewScene::InventoryLoadout ? 2 : 0) + (r.terrorist ? 1 : 0);
}
inline NativePreviewRequest PreviewPoolRequest(const NativePreviewRequest& service, int slot) {
    auto r = service;
    r.scene = slot == 4   ? NativePreviewScene::InventoryGlock
              : slot >= 2 ? NativePreviewScene::InventoryLoadout
                          : NativePreviewScene::Players;
    r.terrorist = slot != 4 && (slot % 2) != 0;
    if (slot == 4 && !PreviewIsItem(service)) {
        r.itemDefinition = 4;
        r.paintKit = 0;
        r.itemMusic = false;
        r.itemActiveIndex = 0;
        r.yaw = r.pitch = 0;
    }
    r = PreviewServiceRequest(r);
    r.icons = false;
    return r;
}
enum class NativePreviewPoolAction { Renew, Park, Remove };
inline std::string BuildNativePreviewPoolStateScript(std::uint64_t token, int active,
                                                     NativePreviewPoolAction action) {
    const char* name = action == NativePreviewPoolAction::Renew  ? "renew"
                       : action == NativePreviewPoolAction::Park ? "park"
                                                                 : "remove";
    std::ostringstream s;
    s << "/* MenuStudio preview pool: " << name
      << " */(function(){try{var root=$.GetContextPanel(),active=" << active << ",ids=[";
    for (int i = 0; i < NativePreviewPoolSize; ++i) {
        if (i)
            s << ",";
        s << "'" << PreviewRequestHostId(token, PreviewPoolRequest({}, i)) << "'";
    }
    s << "],sx=root.actualuiscalex||1,sy=root.actualuiscaley||1;ids.forEach(function(id,i){var "
         "h=root.FindChildTraverse(id);if(!h||!h.IsValid())return;";
    if (action == NativePreviewPoolAction::Remove)
        s << "h.visible=false;h.DeleteAsync(0);";
    else if (action == NativePreviewPoolAction::Park)
        s << "h.visible=false;";
    else
        s << "if(i!==active)h.visible=false;if(i!==4){h.style.width=(350/sx)+'px';h.style.height=(600/"
             "sy)+'px';}h.SetAttributeString('ms_lease',String(Date.now()));";
    s << "});}catch(e){}})();";
    return s.str();
}
inline std::string BuildNativePreviewPoolScript(const NativePreviewRequest& service, std::uint64_t token,
                                                bool itemAvailable = true, std::uint64_t itemGeneration = 0) {
    std::string s;
    for (int i = 0; i < (itemAvailable ? NativePreviewPoolSize : 4); ++i)
        s += BuildNativePreviewScript(PreviewPoolRequest(service, i), token, false, itemGeneration);
    s += BuildNativePreviewPoolStateScript(token, PreviewPoolSlot(service), NativePreviewPoolAction::Renew);
    return s;
}
}
