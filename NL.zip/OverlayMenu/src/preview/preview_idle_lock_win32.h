#pragma once
#include <atomic>
#include <string>
#include "preview_idle_bindings.h"
#ifndef MENU_STUDIO_IDLE_NATIVE_TEST
#include <Windows.h>
#include <MinHook.h>
#endif
namespace menu {

class PreviewIdleSeedLock {
    using Native = void(__fastcall*)(void*);
    using SetFloat = void(__fastcall*)(void*, std::int16_t, const float*);
    inline static std::atomic<PreviewIdleSeedLock*> instance_{nullptr};
    inline static Native pass_[2] = {nullptr, nullptr};
    PreviewIdleBindings b_{};
    void* hooks_[2] = {nullptr, nullptr};
    Native originals_[2] = {nullptr, nullptr};
    bool created_[2] = {false, false}, enabled_[2] = {false, false};
    std::atomic<bool> ready_{false}, stopping_{false}, fault_{false};
    std::atomic<unsigned> active_{0};
    std::atomic<unsigned long long> applied_{0};
    std::atomic<std::uintptr_t> selected_{0};
    std::atomic<ULONGLONG> selectedAt_{0};
    std::string setup_ = "not initialized";
    static bool Bytes(std::uintptr_t a, void* out, std::size_t n) {
        SIZE_T k = 0;
        return a && ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(a), out, n, &k) &&
               k == n;
    }
    template <class T> static bool Read(std::uintptr_t a, T& x) {
        return Bytes(a, &x, sizeof(x));
    }
    static bool CallSetter(std::uintptr_t fn, const PreviewIdleOwner& o) {
        const float zero = 0.0f;
#ifdef MENU_STUDIO_IDLE_NATIVE_TEST
        try {
            reinterpret_cast<SetFloat>(fn)(reinterpret_cast<void*>(o.graph), o.index, &zero);
            return true;
        } catch (...) {
            return false;
        }
#else
        __try {
            reinterpret_cast<SetFloat>(fn)(reinterpret_cast<void*>(o.graph), o.index, &zero);
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
#endif
    }
    void Apply(void* object) {
        if (stopping_.load(std::memory_order_acquire) || fault_ || !ready_)
            return;
        const auto panel = selected_.load(std::memory_order_acquire);
        const auto stamp = selectedAt_.load(std::memory_order_acquire), now = GetTickCount64();
        if (!panel || !stamp || now < stamp || now - stamp > 350)
            return;
        const auto controller = reinterpret_cast<std::uintptr_t>(object);
        auto read = [](std::uintptr_t at, auto& v) { return Read(at, v); };
        PreviewIdleOwner owner;
        if (!ResolvePreviewIdleOwner(read, b_.types, panel, controller, owner))
            return;

        PreviewIdleOwner current;
        if (selected_.load(std::memory_order_acquire) != panel || stopping_ ||
            !ResolvePreviewIdleOwner(read, b_.types, panel, controller, current) ||
            current.entity != owner.entity || current.handle != owner.handle ||
            current.graph != owner.graph || current.node != owner.node || current.index != owner.index)
            return;
        if (CallSetter(b_.setFloat, current))
            ++applied_;
        else
            fault_ = true;
    }
    static void Dispatch(PreviewIdleSeedLock* self, Native next, void* object) {
        if (!next)
            return;
        if (!self) {
            next(object);
            return;
        }
        ++self->active_;
#ifdef MENU_STUDIO_IDLE_NATIVE_TEST
        try {
            next(object);
            self->Apply(object);
        } catch (...) {
            --self->active_;
            throw;
        }
        --self->active_;
#else
        __try {
            next(object);
            self->Apply(object);
        } __finally {
            --self->active_;
        }
#endif
    }
    static void __fastcall ResetHook(void* object) {
        Dispatch(instance_.load(std::memory_order_acquire), pass_[0], object);
    }
    static void __fastcall RefreshHook(void* object) {
        Dispatch(instance_.load(std::memory_order_acquire), pass_[1], object);
    }
    bool StartResolved(const PreviewIdleBindings& b) {
        if (ready_)
            return true;
        if (created_[0] || created_[1] || instance_.load())
            return false;
        b_ = b;
        stopping_ = false;
        fault_ = false;
        hooks_[0] = reinterpret_cast<void*>(b.reset);
        hooks_[1] = reinterpret_cast<void*>(b.refresh);
        instance_.store(this, std::memory_order_release);
        void* detours[2] = {reinterpret_cast<void*>(ResetHook), reinterpret_cast<void*>(RefreshHook)};
        for (unsigned i = 0; i < 2; ++i) {
            if (MH_CreateHook(hooks_[i], detours[i], reinterpret_cast<void**>(&originals_[i])) != MH_OK) {
                setup_ += "; idle hook creation failed";
                Stop();
                return false;
            }
            created_[i] = true;
            pass_[i] = originals_[i];
        }
        for (unsigned i = 0; i < 2; ++i) {
            if (MH_EnableHook(hooks_[i]) != MH_OK) {
                setup_ += "; idle hook enabling failed";
                Stop();
                return false;
            }
            enabled_[i] = true;
        }
        ready_.store(true, std::memory_order_release);
        return true;
    }

public:
    bool Start(const HudScanImage& c, const HudScanImage& a, std::uintptr_t playerVtable,
               std::string& diagnostic) {
        if (ready_) {
            diagnostic = Diagnostic();
            return true;
        }
        PreviewIdleBindings b;
        if (!ResolvePreviewIdleBindings(c, a, playerVtable, b, setup_)) {
            diagnostic = setup_;
            return false;
        }
        const bool ok = StartResolved(b);
        diagnostic = Diagnostic();
        return ok;
    }
    void Select(std::uintptr_t panel) {
        selectedAt_.store(panel ? GetTickCount64() : 0, std::memory_order_release);
        selected_.store(panel, std::memory_order_release);
    }
    std::string Diagnostic() const {
        return std::string("Idle seed: ") +
               (fault_   ? "native setter fault; override disabled"
                : ready_ ? "local override armed"
                         : "not armed") +
               "; seed=0; overrides=" + std::to_string(applied_.load()) +
               "; actual clip NOT runtime-verified; " + setup_;
    }
    bool Stop() {
        stopping_ = true;
        ready_ = false;
        Select(0);
        bool disabled = true;
        for (unsigned i = 0; i < 2; ++i)
            if (enabled_[i]) {
                auto s = MH_DisableHook(hooks_[i]);
                if (s == MH_OK || s == MH_ERROR_DISABLED)
                    enabled_[i] = false;
                else
                    disabled = false;
            }
        if (!disabled)
            return false;
        const auto end = GetTickCount64() + 2000;
        while (active_ && GetTickCount64() < end)
            Sleep(1);
        if (active_)
            return false;

        if (created_[0] || created_[1]) {
            Sleep(100);
            if (active_)
                return false;
        }
        for (unsigned i = 0; i < 2; ++i)
            if (created_[i]) {
                if (MH_RemoveHook(hooks_[i]) != MH_OK)
                    return false;
                created_[i] = false;
            }
        if (instance_.load() == this)
            instance_.store(nullptr, std::memory_order_release);
        return true;
    }
#ifdef MENU_STUDIO_IDLE_NATIVE_TEST
    bool TestStart(const PreviewIdleBindings& b) {
        setup_ = "synthetic test";
        return StartResolved(b);
    }
    void TestInvoke(unsigned i, void* controller) {
        Dispatch(this, originals_[i], controller);
    }
    unsigned long long Applied() const {
        return applied_.load();
    }
#endif
};
}
