#pragma once
#include <cstdint>
namespace menu {

class PreviewRootProbe {
    std::uintptr_t root_ = 0;
    std::uint64_t since_ = 0;
    bool showing_ = false;
    bool havePainted_ = false;
    std::uint64_t grace_ = 1800;

public:
    static constexpr std::uint64_t GraceMs = 1800;
    static constexpr std::uint64_t TransitionGraceMs = 450;
    std::uintptr_t Pick(std::uintptr_t hud, std::uintptr_t menu, bool hudHint, bool menuHint, bool show,
                        std::uint64_t now, std::uint64_t paint) {
        bool valid = root_ && (root_ == hud || root_ == menu);
        if (!valid) {
            root_ = hud && hudHint ? hud : menu && menuHint ? menu : hud ? hud : menu;
            since_ = now;
            grace_ = havePainted_ ? TransitionGraceMs : GraceMs;
        }
        if (show && !showing_) {
            since_ = now;
            grace_ = havePainted_ ? TransitionGraceMs : GraceMs;
        }
        showing_ = show;
        if (show && root_) {
            const bool fresh = paint && paint >= since_ && paint <= now;
            if (fresh) {
                havePainted_ = true;
                grace_ = TransitionGraceMs;
            }
            auto latest = fresh ? paint : since_;
            if (now >= latest && now - latest >= grace_) {
                auto other = root_ == hud ? menu : hud;

                if (other && other != root_) {
                    root_ = other;
                    since_ = now;
                    grace_ = GraceMs;
                }
            }
        }
        return root_;
    }
};
}
