#pragma once
#include "world_tooltip.h"
namespace menu {

struct PlayersPreviewHover {
    std::array<Box, 29> bounds{};
    std::array<PresetMotion, 29> glow{};
    struct Offset {
        float x = 0, y = 0;
    };

    struct Placement {
        Offset shown{}, target{};
        bool initialized = false;
    };
    using Slots = PlayersESPLayout;
    std::array<Slots, 2> slots{}, persisted{};
    Slots prior{};

    void Sync(const std::array<Slots, 2>& saved) {
        if (saved == persisted)
            return;
        Cancel();
        slots = saved;
        persisted = saved;
        placement = {};
        hot = tipItem = -1;
        seconds = 0;
        tipFade.Snap(0);
    }
    std::array<std::array<Placement, 29>, 2> placement{};
    std::array<Box, 29> natural{}, raw{};
    std::array<float, 29> advance{};
    std::array<float, 29> itemMargin{};
    float scale = 1, textMargin = 2;
    Box anchor{};
    Offset origin{};
    int dragging = -1, dragTeam = -1;
    Offset grab{}, press{}, pointer{};
    bool moved = false;
    Box clip{};
    int team = -1, hot = -1, tipItem = -1;
    float seconds = 0;
    PresetMotion tipFade;
    bool allowed = false;
    static bool IsBar(int i) {
        return i == 3 || i == 4 || i == 23;
    }
    static int DefaultSide(int i) {
        return i == 3 ? 0 : i == 1 ? 1 : (i >= 6 && i <= 20) || i == 27 ? 2 : 3;
    }
    int Side(int item) const {
        if (team < 0 || team > 1)
            return DefaultSide(item);
        for (int side = 0; side < 4; ++side)
            for (int i : slots[std::size_t(team)].list[std::size_t(side)])
                if (i == item)
                    return side;
        return DefaultSide(item);
    }
    static bool Vertical(int side) {
        return side == 0 || side == 2;
    }
    static Box Union(Box a, Box b) {
        if (a.w <= 0 || a.h <= 0)
            return b;
        if (b.w <= 0 || b.h <= 0)
            return a;
        float x = std::min(a.x, b.x), y = std::min(a.y, b.y);
        return {x, y, std::max(a.x + a.w, b.x + b.w) - x, std::max(a.y + a.h, b.y + b.h) - y};
    }

    static float Follow(float current, float target, float dt) {
        dt = std::clamp(dt, 0.f, .1f);
        float d = target - current;
        if (std::abs(d) > 1)
            current += std::copysign(std::max(std::abs(d) * 10, 1.f) * dt, d);
        return current;
    }

    Box Anchor(int side, bool centered, float w, float h, Offset stack) const {
        float l = anchor.x - origin.x, t = anchor.y - origin.y, r = l + anchor.w, b = t + anchor.h;
        float mid = std::trunc((l + r) * .5f + std::copysign(.49999997f, (l + r) * .5f));
        Box q{0, 0, w, h};
        if (side == 0) {
            q.x = l - w - 3 - stack.x;
            q.y = t + (centered ? stack.y : -stack.y);
        }
        if (side == 1) {
            q.x = centered ? mid - w * .5f - stack.x : l - stack.x;
            q.y = t - h - 3 - stack.y;
        }
        if (side == 2) {
            q.x = r + (centered ? 2 : 3) + stack.x;
            q.y = t + stack.y;
        }
        if (side == 3) {
            q.x = centered ? mid - w * .5f + stack.x : l + stack.x;
            q.y = b + (centered ? 2 : 3) + stack.y;
        }
        q.x = std::trunc(q.x);
        q.y = std::trunc(q.y);
        return q;
    }
    void SetAnchor(Box bbox) {
        anchor = bbox;
    }
    void Accumulate(Offset& stack, int side, int item, float extent) const {
        if (IsBar(item) && Vertical(side))
            stack.x += extent;
        else
            stack.y += extent;
    }

    int PickSide(float x, float y) const {
        if (y < anchor.y)
            return 1;
        if (y > anchor.y + anchor.h)
            return 3;
        if (x < origin.x)
            return 0;
        if (x > origin.x)
            return 2;
        return -1;
    }
    bool Capturing() const {
        return dragging >= 0;
    }
    void Cancel() {
        if (dragging >= 0 && dragTeam >= 0)
            slots[std::size_t(dragTeam)] = prior;
        dragging = dragTeam = -1;
        moved = false;
        seconds = 0;
        tipItem = -1;
        tipFade.Snap(0);
    }
    bool Press(float x, float y) {
        int i = At(x, y);
        if (i < 1)
            return false;
        dragging = i;
        dragTeam = team;
        grab = {x - raw[std::size_t(i)].x, y - raw[std::size_t(i)].y};
        press = pointer = {x, y};
        prior = slots[std::size_t(team)];
        moved = false;
        seconds = 0;
        tipItem = -1;
        tipFade.Snap(0);
        return true;
    }

    std::size_t Nearest(int side, float x, float y, const std::vector<int>& list) const {
        Offset stack{};
        float best = std::numeric_limits<float>::max();
        std::size_t index = 0;
        bool centered = !IsBar(dragging);
        for (std::size_t k = 0; k <= list.size(); ++k) {
            int i = k < list.size() ? list[k] : dragging;
            auto b = natural[std::size_t(i)];
            if (k < list.size() && (b.w <= 0 || b.h <= 0))
                continue;
            float a = advance[std::size_t(i)];
            bool text = !IsBar(i);
            if (text != centered && k < list.size()) {
                if (centered)
                    Accumulate(stack, side, i, a + Margin(i));
                continue;
            }
            Offset offset = stack;
            float sign = centered ? (side == 1 ? -1.f : 1.f) : (side < 2 ? -1.f : 1.f);
            if (centered || !Vertical(side))
                offset.y += sign * a * .5f;
            else
                offset.x += sign * a * .5f;
            auto q = Anchor(side, centered, a, text ? a : 0, offset);
            if (text)
                q.y -= std::trunc(a * .25f);
            if (!centered) {
                if (Vertical(side))
                    q.y = 0;
                else
                    q.x = 0;
            }
            float dx = x - origin.x - q.x, dy = y - origin.y - q.y, d = dx * dx + dy * dy;
            if (d < best) {
                best = d;
                index = k;
            }
            if (k < list.size())
                Accumulate(stack, side, i, a + Margin(i));
        }
        return index;
    }
    void Move(float x, float y) {
        if (dragging < 0 || dragTeam != team || !std::isfinite(x) || !std::isfinite(y)) {
            return;
        }
        pointer = {x, y};
        float dx = x - press.x, dy = y - press.y;
        if (!moved && dx * dx + dy * dy <= 1)
            return;
        moved = true;
        auto& state = slots[std::size_t(team)];
        state.active = true;
        int side = PickSide(x, y), old = Side(dragging);
        if (side >= 0) {
            if (IsBar(dragging) && Vertical(old) != Vertical(side))
                grab = Vertical(side) ? Offset{0, anchor.h * .5f} : Offset{anchor.w * .5f, 0};
            for (auto& list : state.list)
                list.erase(std::remove(list.begin(), list.end(), dragging), list.end());
            auto& list = state.list[std::size_t(side)];
            auto at = Nearest(side, x, y, list);
            list.insert(list.begin() + std::ptrdiff_t(at), dragging);

            std::stable_partition(list.begin(), list.end(), [](int i) { return IsBar(i); });
        }
        auto& p = placement[std::size_t(team)][std::size_t(dragging)];
        p.shown = {x - grab.x - origin.x, y - grab.y - origin.y};
        p.initialized = true;
    }
    bool Release(float x, float y, std::array<Slots, 2>* saved = nullptr) {
        if (dragging < 0)
            return false;
        Move(x, y);
        if (saved && moved && dragTeam >= 0 && dragTeam < 2 && slots[std::size_t(dragTeam)].Valid()) {
            const auto t = std::size_t(dragTeam);
            (*saved)[t] = slots[t];
            persisted[t] = slots[t];
        }
        dragging = dragTeam = -1;
        moved = false;
        seconds = 0;
        return true;
    }
    static void Mark(PresetLayer& layer, std::size_t start, int item) {
        for (std::size_t k = start; k < layer.draw.size(); ++k)
            layer.draw[k].previewItem = item;
    }
    void Apply(PresetsUI& paint, std::size_t start) {
        natural = raw;
        if (team < 0 || team > 1)
            return;
        auto& state = slots[std::size_t(team)];
        std::array<Offset, 29> shift{};
        for (int side = 0; side < 4; ++side) {
            Offset stack{};
            for (int item : state.list[std::size_t(side)]) {
                auto i = std::size_t(item);
                auto b = natural[i];
                if (b.w <= 0 || b.h <= 0)
                    continue;
                auto& p = placement[std::size_t(team)][i];
                auto q = state.active ? Anchor(side, !IsBar(item), b.w, b.h, stack)
                                      : Box{b.x - origin.x, b.y - origin.y, b.w, b.h};
                p.target = {q.x, q.y};
                if (!p.initialized || !state.active) {
                    p.shown = p.target;
                    p.initialized = true;
                }
                if (dragging == item && moved)
                    p.shown = {pointer.x - grab.x - origin.x, pointer.y - grab.y - origin.y};
                if (state.active) {
                    raw[i].x = origin.x + std::trunc(p.shown.x);
                    raw[i].y = origin.y + std::trunc(p.shown.y);
                }
                shift[i] = {raw[i].x - b.x, raw[i].y - b.y};
                bounds[i] = PresetIntersect(raw[i], clip);
                Accumulate(stack, side, item, advance[i] + Margin(item));
            }
        }
        for (std::size_t k = start; k < paint.layers.size(); ++k)
            for (auto& d : paint.layers[k].draw)
                if (d.previewItem >= 0) {
                    auto o = shift[std::size_t(d.previewItem)];
                    d.box.x += o.x;
                    d.box.y += o.y;
                }
    }
    void Reset() {
        Cancel();
        natural.fill({});
        raw.fill({});
        bounds.fill({});
        for (auto& m : glow)
            m.Snap(0);
        hot = tipItem = -1;
        seconds = 0;
        tipFade.Snap(0);
        allowed = false;
    }
    void Begin(Box child, int page, bool allow, float s = 1, bool universal = false) {
        scale = std::max(.01f, s);
        origin = {std::trunc(child.x + child.w * .5f),
                  std::trunc(std::trunc(child.y + child.h * .5f) - 25 * scale)};
        textMargin = 2 + .5f * (universal ? std::max(0, int((s - 1) * 4)) : 0);
        if (team != page) {
            Reset();
            team = page;
        }
        itemMargin.fill(textMargin);
        clip = child;
        allowed = allow;
        bounds.fill({});
        raw.fill({});
        advance.fill(0);
        if (!allow) {
            Cancel();
            hot = tipItem = -1;
            seconds = 0;
            tipFade.Snap(0);
            for (auto& m : glow)
                m.Snap(0);
        }
    }
    void Add(int item, Box box) {
        if (item == 0 || box.w <= 0 || box.h <= 0)
            return;
        raw.at(std::size_t(item)) = Union(raw.at(std::size_t(item)), box);
        advance.at(std::size_t(item)) = raw.at(std::size_t(item)).h;
        if (!allowed)
            return;
        auto b = PresetIntersect(box, clip);
        if (b.w > 0 && b.h > 0)
            bounds.at(std::size_t(item)) = Union(bounds.at(std::size_t(item)), b);
    }
    void Bar(int item, PresetLayer& layer, std::size_t start, Box bar, float step = 0) {
        Add(item, bar);
        advance[std::size_t(item)] = step > 0 ? step - Margin(item) : std::min(bar.w, bar.h) + 2;
        Mark(layer, start, item);
    }
    float Margin(int i) const {
        return i == 3 || i == 4 || i == 22 || i == 23 || i == 24 || i == 25 || i == 26
                   ? 2.f
                   : itemMargin[std::size_t(i)];
    }
    int At(float x, float y) const {
        if (!allowed || !clip.Contains(x, y))
            return -1;
        for (int i = 28; i >= 1; --i) {
            auto b = raw[std::size_t(i)];
            float m = Margin(i);
            if (b.w > 0 && b.h > 0 && Box{b.x - 3, b.y - m, b.w + 6, b.h + 2 * m}.Contains(x, y))
                return i;
        }
        return -1;
    }
    void Tick(float dt, int page, bool allow, float x, float y, const std::array<bool, 29>& enabled) {
        dt = std::max(0.f, dt);
        if (team != page || !allow) {
            Reset();
            team = page;
            return;
        }
        if (dragging >= 0 && !enabled[std::size_t(dragging)])
            Cancel();
        for (std::size_t i = 0; i < 29; ++i)
            if (int(i) != dragging) {
                auto& p = placement[std::size_t(page)][i];
                p.shown.x = Follow(p.shown.x, p.target.x, dt);
                p.shown.y = Follow(p.shown.y, p.target.y, dt);
            }
        int next = dragging >= 0 ? dragging : At(x, y);
        if (next >= 0 && !enabled[std::size_t(next)])
            next = -1;
        if (next != hot) {
            hot = next;
            seconds = 0;
            tipFade.Snap(0);
            tipItem = -1;
        } else if (hot >= 0)
            seconds += dt;
        for (std::size_t i = 0; i < glow.size(); ++i)
            glow[i].Tick(int(i) == hot ? 1.f : 0.f, dt, .2f);
        if (dragging < 0 && hot >= 0 && seconds >= .3f)
            tipItem = hot;
        tipFade.Tick(tipItem >= 0 && hot == tipItem ? 1.f : 0.f, dt, .2f);
    }
    PresetLayer Highlight(const Settings& cfg) const {
        PresetLayer l{clip, 0, false, {}};
        l.pixelAligned = true;
        if (!allowed)
            return l;
        auto accent = CurrentPalette(cfg)[31];
        for (std::size_t i = 0; i < bounds.size(); ++i) {
            auto b = raw[i];
            float a = glow[i].value;
            if (b.w <= 0 || b.h <= 0 || a <= .001f)
                continue;
            auto fill = accent;
            fill.a *= .375f * a;
            PresetDraw d{b, fill, 0, 0, 15, {}, false};
            d.clipped = true;
            d.clip = clip;
            l.draw.push_back(d);
            d.color = {0, 0, 0, 0};
            d.shadowSize = 15;
            d.shadowColor = accent;
            d.shadowColor.a *= .75f * a;
            l.draw.push_back(d);
        }
        return l;
    }
};
}
