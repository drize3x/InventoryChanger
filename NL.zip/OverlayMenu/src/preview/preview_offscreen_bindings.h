#pragma once
#include "players_native_preview_patterns.h"
namespace menu {
struct PreviewOffscreenBindings {
    PlayerPreviewNativeBindings native;
    std::uintptr_t deviceGlobal = 0, managerGlobal = 0;
    std::vector<std::uintptr_t> contextTables;
};
inline bool ResolvePreviewOffscreen(const HudScanImage& c, const HudScanImage& p, const HudScanImage& r,
                                    PreviewOffscreenBindings& result, std::string& diagnostic) {
    result = {};
    PreviewOffscreenBindings b;
    std::string native;
    if (!PlayerPreviewResolveNativeBindings(c, r, b.native, native)) {
        diagnostic = native;
        return false;
    }
    auto fail = [&](const char* why) {
        diagnostic = native + "; offscreen FAIL " + why;
        return false;
    };

    if (b.native.paintSlot != 0x2c0 || b.native.createTextureSlot != 0x198)
        return fail("virtual ABI changed");
    auto factory = p.Find("44 89 44 24 18 55 53 56 57 41 56 48 8D 6C 24 B0 48 81 EC 50 01 00 00 48 8B 05 ? ? "
                          "? ? 48 8B F9 48 8B 0D ? ? ? ? 48 8B F2 4C 8B 00 48 8B 01 49 8B 58 40",
                          true, 2);
    auto release = p.Find("48 85 D2 74 2D 4C 39 35 ? ? ? ? 74 24 F0 FF 4A 20 4C 39 35 ? ? ? ? 74 14 8B 4A 20 "
                          "85 C9 75 0D 48 8B 0D ? ? ? ? 48 8B 01 FF 50 10 4C 89 37",
                          true, 2);
    if (factory.size() != 1 || release.size() != 1)
        return fail("texture factory/ownership fingerprint");
    b.deviceGlobal = p.Rip(factory[0] + 23);
    b.managerGlobal = p.Rip(release[0] + 34);
    if (b.managerGlobal != p.Rip(release[0] + 5) || b.managerGlobal != p.Rip(release[0] + 18) ||
        !p.Contains(b.managerGlobal, 8, 0x80000000, 0x20000000) ||
        !p.Contains(b.deviceGlobal, 8, 0x80000000, 0x20000000))
        return fail("factory globals");

    auto lookup =
        c.Find("48 83 EC 18 8B 44 24 0C 4C 8D 1D ? ? ? ? 66 41 0F 6E C8 4C 8B D2 4C 89 0C 24 4C 8D 89 80 01 "
               "00 00 66 0F 70 C9 00 C7 44 24 08 FF FF FF FF 89 44 24 0C 0F 1F 40 00 66 0F 1F 84 00 00 00 00 "
               "00 33 C9 49 8B C1 66 66 66 0F 1F 84 00 00 00 00 00 66 0F 6F C1 66 0F 76 00 0F 50 D0 85 D2 75 "
               "? FF C1 48 83 C0 10 83 F9 02 72 ? EB ? 48 63 C2 41 8B 04 83 8D 14 88 83 FA 08 73 ? 83 FA FF "
               "75 ? 49 8B 81 A8 00 00 00 48 85 C0 74 ? 0F 1F 40 00 48 8D 50 10 33 C9 66 66 0F 1F 84 00 00 "
               "00 00 00 66 0F 6F C1 66 0F 76 02 44 0F 50 C0 45 85 C0 75 ? FF C1 48 83 C2 10 83 F9 02 72 ? "
               "EB ? 49 63 D0 41 8B 14 93 44 8D 04 8A 41 83 F8 08 73 ? 41 83 F8 FF 75 ? 48 8B 00 48 85 C0 75 "
               "? 4D 8B 89 A0 00 00 00 4D 85 C9 0F 85 ? ? ? ? 0F 28 04 24 49 8B C2 66 49 0F D6 02 48 83 C4 "
               "18 C3 48 63 CA 49 8B C2 48 83 C1 02 48 C1 E1 04 49 03 C9 0F 10 01 66 49 0F D6 02 48 83 C4 18 "
               "C3 49 63 C8 48 83 C1 03 48 C1 E1 04 48 03 C8 49 8B C2 0F 10 01 66 49 0F D6 02 48 83 C4 18 C3",
               true, 2);
    if (lookup.size() != 1)
        return fail("resource attribute layout fingerprint");

    for (const char* type : {".?AVCRenderContextBase@@", ".?AVCRenderContextDx11@@",
                             ".?AVCRenderContextDx11_SoftwareCommandLists@@"}) {
        auto v = r.Vtables(type);
        if (v.size() != 1)
            return fail("render context RTTI");
        std::uintptr_t getter = 0;
        unsigned char body[5]{};
        if (!r.Read(v[0] + 0x498, getter) || !r.Bytes(getter, body, 5) ||
            std::memcmp(body, "\x48\x8d\x41\x10\xc3", 5))
            return fail("resource table getter");
        b.contextTables.push_back(v[0]);
    }
    result = std::move(b);
    diagnostic = native + "; offscreen factory/ownership/context ABI resolved";
    return true;
}
}
