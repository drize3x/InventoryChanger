#pragma once
#include <cstdint>
namespace menu {

class PreviewImageAge {
    bool valid_ = false;
    std::uint64_t stamp_ = 0;

public:
    void Reset() {
        valid_ = false;
        stamp_ = 0;
    }
    void Publish(std::uint64_t now) {
        stamp_ = now;
        valid_ = true;
    }
    bool Current(std::uint64_t now, std::uint64_t maxAge = 500) const {
        return valid_ && now >= stamp_ && now - stamp_ <= maxAge;
    }
};
}
