#pragma once
#include "watermark_hud_patterns.h"
namespace menu {
namespace preview_patterns {

inline constexpr char Paint[] = "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 50 80 B9 B1 06 00 "
                                "00 00 49 8B F9 49 8B F0 48 8B EA 48 8B D9 0F 84 ? ? ? ?";
inline constexpr char PlayerUpdate[] =
    "48 89 5C 24 08 57 48 83 EC 20 48 8B 01 48 8B D9 FF 90 50 03 00 00 84 C0 74 ? 80 3D ? ? ? ? 00 74 ? 80 "
    "3D ? ? ? ? 00 74 ? 48 8B 03 48 8B CB FF 90 C8 02 00 00";
inline constexpr char CreateTexture[] =
    "44 88 4C 24 20 48 89 54 24 10 48 89 4C 24 08 55 56 57 41 56 41 57 48 8D AC 24 30 FF FF FF 48 81 EC D0 "
    "01 00 00 48 8B B5 20 01 00 00 4D 8B F8 4C 8B F2 8B 46 50 83 F8 FF 75 ?";
}

struct PlayerPreviewNativeBindings {
    std::uintptr_t playerVtable = 0, sceneVtable = 0, deviceVtable = 0, textureVtable = 0;
    std::uintptr_t paint = 0, update = 0, createTexture = 0;

    std::uint32_t paintSlot = 0, updateSlot = 0, createTextureSlot = 0;
};
inline bool PlayerPreviewResolveNativeBindings(const HudScanImage& client, const HudScanImage& renderer,
                                               PlayerPreviewNativeBindings& result, std::string& diagnostic) {
    result = {};
    PlayerPreviewNativeBindings b;
    std::ostringstream log;
    auto fail = [&](const char* why) {
        diagnostic = log.str() + "FAIL " + why;
        return false;
    };
    auto table = [&](const HudScanImage& image, const char* type, std::uintptr_t& out) {
        auto hits = image.Vtables(type);
        log << type << " tables=" << hits.size() << "; ";
        if (hits.size() != 1)
            return false;
        out = hits[0];
        return true;
    };
    auto unique = [&](const HudScanImage& image, const char* label, const char* pattern,
                      std::uintptr_t& out) {
        auto hits = image.Find(pattern, true, 2);
        log << label << " matches=" << hits.size() << "; ";
        if (hits.size() != 1)
            return false;
        out = hits[0];
        return true;
    };
    auto method = [&](const HudScanImage& image, std::uintptr_t vt, std::uintptr_t target,
                      std::uint32_t& slot) {
        unsigned matches = 0;
        std::uint32_t offset = 0;
        for (unsigned i = 0; i < 512; ++i) {
            std::uintptr_t f = 0;
            if (!image.Read(vt + std::uintptr_t(i) * 8, f) || !image.Contains(f, 1, 0x20000000))
                break;
            if (f == target) {
                ++matches;
                offset = i * 8;
            }
        }
        if (matches != 1)
            return false;
        slot = offset;
        return true;
    };
    if (!table(client, ".?AVCUI_Player3dPanel@@", b.playerVtable))
        return fail("player panel type");
    if (!table(client, ".?AVCUI_3dPanel@@", b.sceneVtable))
        return fail("scene panel type");
    if (!table(renderer, ".?AVCRenderDeviceDx11@@", b.deviceVtable))
        return fail("DX11 device type");
    if (!table(renderer, ".?AVCTextureDx11@@", b.textureVtable))
        return fail("DX11 texture type");
    if (!unique(client, "scene-paint", preview_patterns::Paint, b.paint))
        return fail("paint signature");
    if (!unique(client, "player-update", preview_patterns::PlayerUpdate, b.update))
        return fail("update signature");
    if (!unique(renderer, "create-texture", preview_patterns::CreateTexture, b.createTexture))
        return fail("texture signature");
    std::uint32_t baseSlot = 0;
    if (!method(client, b.playerVtable, b.paint, b.paintSlot) ||
        !method(client, b.sceneVtable, b.paint, baseSlot) || baseSlot != b.paintSlot)
        return fail("shared typed paint method");
    if (!method(client, b.playerVtable, b.update, b.updateSlot))
        return fail("typed player update method");
    if (!method(renderer, b.deviceVtable, b.createTexture, b.createTextureSlot))
        return fail("typed texture creation method");
    result = b;
    log << "resolved by code signatures + RTTI; discovery only, capture not enabled";
    diagnostic = log.str();
    return true;
}
}
