#pragma once
#include "watermark_hud_patterns.h"
namespace menu {
inline constexpr char PreviewRunScriptPattern[] =
    "4C 89 4C 24 20 4C 89 44 24 18 48 89 54 24 10 55 53 56 57 41 54 41 56 41 57 48 8D 6C 24 90 48 81 EC 70 "
    "01 00 00 48 8D 05 ? ? ? ?";
inline constexpr char PreviewNullableFindPattern[] =
    "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 48 89 7C 24 20 41 56 48 83 EC 20 48 8B EA 4C 8B F1 48 85 "
    "D2 74 ? 80 3A 00 74 ? 33 DB 48 8D 79 28 39 1F 7E ? 8B F3";
struct PreviewBridgeBindings {
    std::uintptr_t runScript = 0, engineVtable = 0, panelVtable = 0, playerVtable = 0, itemVtable = 0,
                   findChild = 0;
    std::uint32_t hudRootOffset = 0, clientOffset = 0, parentOffset = 0;
    std::uintptr_t mainMenuGlobal = 0, mainMenuVtable = 0, isVisible = 0;
};
inline bool ResolvePreviewBridge(const HudScanImage& c, const HudScanImage& p, PreviewBridgeBindings& out,
                                 std::string& diagnostic) {
    out = {};
    PreviewBridgeBindings b;
    std::ostringstream log;
    auto fail = [&](const char* s) {
        diagnostic = log.str() + "FAIL " + s;
        return false;
    };
    auto one = [&](const HudScanImage& im, const char* name, std::uintptr_t& target) {
        auto v = im.Vtables(name);
        log << name << " tables=" << v.size() << "; ";
        if (v.size() != 1)
            return false;
        target = v[0];
        return true;
    };
    if (!one(p, ".?AVCUIEngineSource2@panorama@@", b.engineVtable) ||
        !one(p, ".?AVCUIPanel@panorama@@", b.panelVtable) ||
        !one(c, ".?AVCUI_Player3dPanel@@", b.playerVtable))
        return fail("typed classes");

    auto itemTables = c.Vtables(".?AVCUI_Item3dPanel@@");
    if (itemTables.size() == 1)
        b.itemVtable = itemTables[0];
    log << "item panel tables=" << itemTables.size() << "; ";
    auto runs = p.Find(PreviewRunScriptPattern, true, 2);
    log << "RunScript matches=" << runs.size() << "; ";
    if (runs.size() != 1 || p.VirtualMatches(b.engineVtable, runs[0]) != 1)
        return fail("typed RunScript");
    b.runScript = runs[0];
    auto candidates = c.Find(hud_patterns::BottomCache);
    std::vector<std::uintptr_t> cache;
    if (candidates.size() >= 128)
        return fail("too many HUD lookup matches");
    for (auto at : candidates)
        if (c.Text(c.Rip(at + 4), "HudBottomCenter"))
            cache.push_back(at);
    if (cache.size() != 1)
        return fail("HUD child lookup callsite");
    std::uint8_t root = 0;
    std::uint32_t slot = 0;
    std::uintptr_t requiredLookup = 0;
    if (!c.Read(cache[0] + 3, root) || !root || !c.Read(cache[0] + 20, slot) || slot % 8 || slot > 4096 ||
        !p.Read(b.panelVtable + slot, requiredLookup) || !p.Contains(requiredLookup, 1, 0x20000000))
        return fail("HUD root/lookup ABI");
    b.hudRootOffset = root;

    auto finds = p.Find(PreviewNullableFindPattern, true, 2);
    if (finds.size() != 1 || p.VirtualMatches(b.panelVtable, finds[0]) != 1)
        return fail("typed nullable child lookup");
    b.findChild = finds[0];
    bool edge = false;
    for (unsigned i = 0; i + 12 < 240; ++i) {
        unsigned char q[4]{};
        if (p.Bytes(requiredLookup + i, q, 4) && q[0] == 0x48 && q[1] == 0x8b && q[2] == 0xd5 &&
            q[3] == 0xe8 && p.Rip(requiredLookup + i + 3, 1, 5) == b.findChild)
            edge = true;
    }
    if (!edge)
        return fail("required/nullable lookup cross-check");

    unsigned getters = 0;
    for (unsigned i = 0; i < 256; ++i) {
        std::uintptr_t fn = 0;
        if (!p.Read(b.panelVtable + i * 8, fn) || !p.Contains(fn, 1, 0x20000000))
            break;
        unsigned char body[5]{};
        if (p.Bytes(fn, body, 5) && body[0] == 0x48 && body[1] == 0x8b && body[2] == 0x41 && body[3] == 8 &&
            body[4] == 0xc3) {
            ++getters;
            b.clientOffset = body[3];
        }
    }
    if (getters != 1)
        return fail("reciprocal client-panel getter");

    if (!one(c, ".?AVCCSGO_MainMenu@@", b.mainMenuVtable))
        return fail("main menu RTTI");
    auto stores =
        c.Find("48 89 35 ? ? ? ? 48 8B 4E 08 48 8B 01 FF 50 78 48 8B 4E 08 48 8D 15 ? ? ? ?", true, 16);
    unsigned qualified = 0;
    for (auto a : stores) {
        bool typed = false;
        for (unsigned back = 7; back < 128 && a >= back; ++back) {
            auto q = a - back;
            unsigned char op[10]{};
            if (c.Bytes(q, op, 10) && op[0] == 0x48 && op[1] == 0x8d && op[2] == 5 &&
                c.Rip(q) == b.mainMenuVtable && op[7] == 0x48 && op[8] == 0x89 && op[9] == 6)
                typed = true;
        }
        if (typed) {
            auto g = c.Rip(a);
            if (!c.Contains(g, 8, 0x80000000, 0x20000000))
                return fail("menu singleton data");
            b.mainMenuGlobal = g;
            ++qualified;
        }
    }
    if (qualified != 1)
        return fail("typed menu singleton store");

    auto regs = c.Find("45 33 C0 48 8D 15 ? ? ? ? 48 8D 0D ? ? ? ? E8 ? ? ? ?", true, 4096);
    unsigned parents = 0;
    for (auto a : regs)
        if (c.Text(c.Rip(a + 10), "GetParent")) {
            auto fn = c.Rip(a + 3);
            unsigned char op[17]{};
            std::uint32_t slot = 0;
            std::uintptr_t getter = 0;
            if (!c.Bytes(fn, op, 17) || op[0] != 0x48 || op[1] != 0x83 || op[2] != 0xec || op[3] != 0x28 ||
                op[4] != 0x48 || op[5] != 0x8b || op[6] != 0x49 || op[7] != 8 || op[8] != 0x48 ||
                op[9] != 0x8b || op[10] != 1 || op[11] != 0xff || op[12] != 0x90 || !c.Read(fn + 13, slot) ||
                slot > 4096 || slot % 8 || !p.Read(b.panelVtable + slot, getter))
                return fail("GetParent wrapper ABI");
            unsigned char body[5]{};
            if (!p.Bytes(getter, body, 5) || body[0] != 0x48 || body[1] != 0x8b || body[2] != 0x41 ||
                body[4] != 0xc3 || body[3] < 16 || body[3] % 8)
                return fail("typed parent getter");
            b.parentOffset = body[3];
            ++parents;
        }
    if (parents != 1)
        return fail("named GetParent registration");

    auto props =
        c.Find("4C 8D 05 ? ? ? ? 48 89 5C 24 20 48 8D 15 ? ? ? ? 48 8D 0D ? ? ? ? E8 ? ? ? ?", true, 4096);
    auto visibleCode = p.Find("40 53 48 83 EC 20 0F BF 81 ? ? ? ? 48 8B D9 C1 E8 08 A8 01 74 ? 33 D2 E8 ? ? "
                              "? ? 0F B6 83 ? ? ? ? 24 01 48 83 C4 20 5B C3",
                              true, 2);
    unsigned visibles = 0;
    if (props.size() >= 4096 || visibleCode.size() != 1)
        return fail("visible getter code");
    for (auto a : props)
        if (c.Text(c.Rip(a + 19), "visible")) {
            auto fn = c.Rip(a + 12);
            unsigned char op[14]{};
            std::uint32_t slot = 0;
            std::uintptr_t getter = 0;
            if (!c.Bytes(fn, op, 14) || op[0] != 0x48 || op[1] != 0x8b || op[2] != 0x49 || op[3] != 8 ||
                op[4] != 0x48 || op[5] != 0x8b || op[6] != 1 || op[7] != 0x48 || op[8] != 0xff ||
                op[9] != 0xa0 || !c.Read(fn + 10, slot) || slot % 8 || slot > 4096 ||
                !p.Read(b.panelVtable + slot, getter) || getter != visibleCode[0])
                return fail("named visible wrapper ABI");
            b.isVisible = getter;
            ++visibles;
        }
    if (visibles != 1)
        return fail("named visible getter registration");
    out = b;
    diagnostic =
        log.str() + "resolved HUD/menu singleton + named parent/visible getters + RTTI; no fixed RVAs";
    return true;
}
}
