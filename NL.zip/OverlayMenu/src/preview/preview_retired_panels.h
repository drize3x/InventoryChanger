#pragma once
#include <array>
#include <atomic>
#include <cstdint>
namespace menu {

class PreviewRetiredPanels {
    struct Slot {
        std::atomic<std::uintptr_t> panel{0};
        std::atomic<std::uint64_t> until{0};
    };
    std::array<Slot, 64> slots_{};
    std::atomic<unsigned> cursor_{0};

public:
    void Retire(std::uintptr_t panel, std::uint64_t now) {
        if (!panel)
            return;
        auto& s = slots_[cursor_.fetch_add(1, std::memory_order_relaxed) % slots_.size()];
        s.panel.store(0, std::memory_order_release);
        s.until.store(now + 5000, std::memory_order_relaxed);
        s.panel.store(panel, std::memory_order_release);
    }
    bool Contains(std::uintptr_t panel, std::uint64_t now) const {
        if (!panel)
            return false;
        for (const auto& s : slots_)
            if (s.panel.load(std::memory_order_acquire) == panel &&
                now < s.until.load(std::memory_order_relaxed))
                return true;
        return false;
    }
};
}
