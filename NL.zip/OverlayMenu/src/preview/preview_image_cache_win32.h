#pragma once
#include <d3d11.h>
#include <wrl/client.h>
#include <array>
#include <cmath>
#include "preview_image_age.h"
namespace menu {

class PreviewImageCache {
    template <class T> using ComPtr = Microsoft::WRL::ComPtr<T>;
    ComPtr<ID3D11Texture2D> image_;
    ComPtr<ID3D11ShaderResourceView> view_;
    std::array<float, 4> uv_{};
    PreviewImageAge age_;
    UINT width_ = 0, height_ = 0;
    DXGI_FORMAT format_ = DXGI_FORMAT_UNKNOWN;
    DXGI_FORMAT viewFormat_ = DXGI_FORMAT_UNKNOWN;

public:
    void Reset() {
        age_.Reset();
        view_.Reset();
        image_.Reset();
        width_ = height_ = 0;
        format_ = viewFormat_ = DXGI_FORMAT_UNKNOWN;
        uv_ = {};
    }
    bool Copy(ID3D11DeviceContext* context, ID3D11ShaderResourceView* source, const std::array<float, 4>& uv,
              std::uint64_t now) {
        if (!context || !source)
            return false;
        for (float v : uv)
            if (!std::isfinite(v))
                return false;
        if (uv[0] < 0 || uv[1] < 0 || uv[2] > 1 || uv[3] > 1 || uv[2] <= uv[0] || uv[3] <= uv[1])
            return false;
        D3D11_SHADER_RESOURCE_VIEW_DESC sd{};
        source->GetDesc(&sd);
        if (sd.ViewDimension != D3D11_SRV_DIMENSION_TEXTURE2D || sd.Texture2D.MostDetailedMip != 0)
            return false;
        ComPtr<ID3D11Device> device, sourceDevice;
        context->GetDevice(&device);
        source->GetDevice(&sourceDevice);
        if (!device || device.Get() != sourceDevice.Get())
            return false;
        ComPtr<ID3D11Resource> resource;
        source->GetResource(&resource);
        ComPtr<ID3D11Texture2D> texture;
        if (!resource || FAILED(resource.As(&texture)))
            return false;
        D3D11_TEXTURE2D_DESC td{};
        texture->GetDesc(&td);
        if (!td.Width || !td.Height || td.ArraySize != 1 || td.SampleDesc.Count != 1)
            return false;
        ComPtr<ID3D11Texture2D> nextImage = image_;
        ComPtr<ID3D11ShaderResourceView> nextView = view_;
        const bool replace = !image_ || width_ != td.Width || height_ != td.Height || format_ != td.Format ||
                             viewFormat_ != sd.Format;
        if (replace) {
            nextImage.Reset();
            nextView.Reset();
            D3D11_TEXTURE2D_DESC out = td;
            out.MipLevels = 1;
            out.ArraySize = 1;
            out.Usage = D3D11_USAGE_DEFAULT;
            out.BindFlags = D3D11_BIND_SHADER_RESOURCE;
            out.CPUAccessFlags = 0;
            out.MiscFlags = 0;
            if (FAILED(device->CreateTexture2D(&out, nullptr, nextImage.GetAddressOf())))
                return false;
            D3D11_SHADER_RESOURCE_VIEW_DESC vd{};
            vd.Format = sd.Format;
            vd.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
            vd.Texture2D.MipLevels = 1;
            if (FAILED(device->CreateShaderResourceView(nextImage.Get(), &vd, nextView.GetAddressOf())))
                return false;
        }
        if (nextImage.Get() == texture.Get())
            return false;

        context->CopySubresourceRegion(nextImage.Get(), 0, 0, 0, 0, texture.Get(), 0, nullptr);
        image_ = nextImage;
        view_ = nextView;
        width_ = td.Width;
        height_ = td.Height;
        format_ = td.Format;
        viewFormat_ = sd.Format;
        uv_ = uv;
        age_.Publish(now);
        return true;
    }
    ID3D11ShaderResourceView* View(std::uint64_t now, std::uint64_t maxAge = 500) const {
        return age_.Current(now, maxAge) ? view_.Get() : nullptr;
    }
    const std::array<float, 4>& UV() const {
        return uv_;
    }
};
}
