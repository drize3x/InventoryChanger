#pragma once
#include <cstdint>
namespace menu {
struct PreviewIdleOwnerTypes {
    std::uintptr_t panelVtable = 0, entityVtable = 0, controllerVtable = 0, floatVtable = 0,
                   entitySystemGlobal = 0;
};
struct PreviewIdleOwner {
    std::uintptr_t entity = 0, controller = 0, graph = 0, node = 0, identity = 0, record = 0;
    std::uint32_t handle = 0;
    std::int16_t index = -1;
};

template <class Read>
bool ResolvePreviewIdleOwner(Read&& read, const PreviewIdleOwnerTypes& t, std::uintptr_t panel,
                             std::uintptr_t callbackController, PreviewIdleOwner& out) {
    out = {};
    if (!panel || !callbackController || !t.panelVtable || !t.entityVtable || !t.controllerVtable ||
        !t.floatVtable || !t.entitySystemGlobal)
        return false;
    std::uintptr_t vt = 0, records = 0, system = 0, chunk = 0;
    std::int32_t active = -1, count = 0, mode = -1;
    if (!read(panel, vt) || vt != t.panelVtable || !read(panel + 0x8ec, active) ||
        !read(panel + 0x8f0, count) || count < 1 || count > 64 || active < 0 || active >= count ||
        !read(panel + 0x8f8, records) || !records)
        return false;
    PreviewIdleOwner o;
    o.record = records + std::uintptr_t(active) * 0xa0;
    if (!read(o.record, o.handle) || o.handle >= 0xfffffffeu || !read(t.entitySystemGlobal, system) ||
        !system)
        return false;
    const auto slot = o.handle & 0x7fffu;
    if (!read(system + std::uintptr_t(slot >> 9) * 8, chunk) || !chunk)
        return false;
    o.identity = chunk + std::uintptr_t(slot & 0x1ffu) * 0x70;
    std::uint32_t serial = 0;
    if (!read(o.identity + 0x10, serial) || serial != o.handle || !read(o.identity, o.entity) || !o.entity ||
        !read(o.entity, vt) || vt != t.entityVtable || !read(o.entity + 0x3790, mode) || mode != 5 ||
        !read(o.entity + 0x37b8, o.controller) || o.controller != callbackController ||
        !read(o.controller, vt) || vt != t.controllerVtable || !read(o.controller + 0xc8, o.graph) ||
        !o.graph || !read(o.controller + 0xd0, o.index) || o.index < 0 || o.index >= 4096)
        return false;
    std::uintptr_t nodes = 0;
    if (!read(o.graph + 0x10, nodes) || !nodes || !read(nodes + std::uintptr_t(o.index) * 8, o.node) ||
        !o.node || !read(o.node, vt) || vt != t.floatVtable)
        return false;

    std::uintptr_t check = 0;
    std::uint32_t handle = 0;
    if (!read(o.record, handle) || handle != o.handle || !read(o.identity + 0x10, serial) ||
        serial != o.handle || !read(o.identity, check) || check != o.entity ||
        !read(o.entity + 0x37b8, check) || check != o.controller)
        return false;
    out = o;
    return true;
}
}
