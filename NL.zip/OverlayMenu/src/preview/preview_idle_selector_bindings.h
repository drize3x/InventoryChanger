#pragma once
#include "preview_idle_bindings.h"
namespace menu {
struct PreviewIdleSelectorBindings {

    static constexpr unsigned WeaponTypeGraphOffset = 0x1b8, WeaponTypeIndexOffset = 0x1c0;
    PreviewIdleBindings owner;
    std::uintptr_t weaponSetter = 0, ctSetter = 0, boolVtable = 0;
    std::uintptr_t choice = 0, update = 0, initialize = 0, shutdown = 0, shutdownWrapper = 0, clipValid = 0;
    std::uintptr_t selectorVtable = 0, clipVtable = 0, referencedVtable = 0, idVtable = 0, ssg08Symbol = 0;
};
namespace preview_selector_patterns {
inline constexpr char CtSetter[] =
    "48 89 5C 24 08 57 48 83 EC 20 0F B6 FA 48 8B D9 E8 ? ? ? ? 48 8B C8 4C 8B 00 41 FF 90 D0 00 00 00 3C 02 "
    "75 ? 48 8B 83 B8 37 00 00 48 85 C0 74 ? 48 8B 90 30 02 00 00 48 85 D2 74 ? 48 0F BF 88 38 02 00 00 66 "
    "85 C9 78 ? 48 8B 42 10 48 8B 0C C8 40 88 79 18";
inline constexpr char CtBinding[] = "48 8D 0D ? ? ? ? C7 83 20 02 00 00 FF FF 01 00 FF 15 ? ? ? ? 48 8B 74 "
                                    "24 38 48 89 83 28 02 00 00 48 8B C3 C7 83 38 02 00 00 FF FF 01 00";
inline constexpr char Choice[] =
    "48 8B C4 48 89 50 10 48 89 48 08 55 56 41 57 48 8D 68 A1 48 81 EC 90 00 00 00 8B 71 28";
inline constexpr char Update[] =
    "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 60 C6 02 FF 49 8B E9";
inline constexpr char Init[] = "40 53 56 57 41 55 41 56 48 83 EC 20 48 89 6C 24 50 4C 8B F2 4C 89 64 24 58 "
                               "48 8B D9 4C 89 7C 24 60 4D 8B F8 E8 ? ? ? ? 48 8B 4B 58 49 8B D6";
inline constexpr char Shutdown[] = "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 48 89 7C 24 20 41 56 48 83 "
                                   "EC 20 8B 69 28 45 33 F6 48 8B F2 48 8B D9";
inline constexpr char WeaponTypeSetter[] = "4C 8B 89 B8 01 00 00 4D 85 C9 74 1D 4C 0F BF 81 C0 01 00 00 66 "
                                           "45 85 C0 78 0F 49 8B 49 10 48 8B 02 4A 8B 14 C1 48 89 42 18 C3";

inline constexpr char WeaponTypeBinding[] =
    "48 8D 0D ? ? ? ? C7 83 A8 01 00 00 FF FF 01 00 FF 15 ? ? ? ? 48 89 83 B0 01 00 00 48 8D 0D ? ? ? ? C7 "
    "83 C0 01 00 00 FF FF 01 00";
inline constexpr char SymbolInit[] =
    "48 8D 0D ? ? ? ? 48 89 05 ? ? ? ? FF 15 ? ? ? ? 48 8D 0D ? ? ? ? 48 89 05 ? ? ? ?";
inline constexpr char RefChild[] =
    "48 8B 4B 28 4D 85 F6 74 ? 4D 8B C6 E8 ? ? ? ? EB ? 4D 8B 45 00 E8 ? ? ? ? 48 8B 43 28";
inline constexpr char Context[] = "49 8B 4E 30 49 8D 56 40 41 0F 11 86 70 03 00 00";
}
inline bool ResolvePreviewIdleSelector(const HudScanImage& c, const HudScanImage& a,
                                       std::uintptr_t panelVtable, PreviewIdleSelectorBindings& out,
                                       std::string& diagnostic) {
    out = {};
    PreviewIdleSelectorBindings b;
    std::ostringstream log;
    std::string ownerLog;
    auto fail = [&](const char* reason) {
        diagnostic = log.str() + " selector disabled: " + reason;
        return false;
    };
    if (!ResolvePreviewIdleBindings(c, a, panelVtable, b.owner, ownerLog))
        return fail("owner bindings");
    auto table = [&](const HudScanImage& im, const char* name, std::uintptr_t& v) {
        auto hits = im.Vtables(name);
        if (hits.size() != 1)
            return false;
        v = hits[0];
        return true;
    };
    if (!table(a, ".?AVCNmParameterizedClipSelectorNode@@", b.selectorVtable) ||
        !table(a, ".?AVCNmClipNode@@", b.clipVtable) ||
        !table(a, ".?AVCNmReferencedGraphNode@@", b.referencedVtable) ||
        !table(a, ".?AVCNmControlParameterIDNode@@", b.idVtable) ||
        !table(a, ".?AVCNmControlParameterBoolNode@@", b.boolVtable))
        return fail("typed node tables");
    auto unique = [&](const HudScanImage& im, const char* name, const char* pattern, std::uintptr_t& dst) {
        auto hits = im.Find(pattern, true, 2);
        log << name << "=" << hits.size() << "; ";
        if (hits.size() != 1)
            return false;
        dst = hits[0];
        return true;
    };
    if (!unique(a, "choice", preview_selector_patterns::Choice, b.choice))
        return fail("choice code");
    auto typed = [&](unsigned offset, const char* pattern, std::uintptr_t& dst) {
        if (!a.Read(b.selectorVtable + offset, dst))
            return false;
        auto hits = a.Find(pattern, true, 32);
        return hits.size() < 32 && std::find(hits.begin(), hits.end(), dst) != hits.end();
    };
    if (!typed(0x50, preview_selector_patterns::Update, b.update) ||
        !typed(0x48, preview_selector_patterns::Init, b.initialize) ||
        !typed(0x38, preview_selector_patterns::Shutdown, b.shutdown))
        return fail("typed selector lifecycle code");
    log << "typed-lifecycle=1; ";
    std::uintptr_t v = 0;
    b.shutdownWrapper = a.Rip(b.shutdown + 0x56, 1, 5);
    auto wrappers = a.Find("83 69 14 01 75 07 48 8B 01 48 FF 60 38 C3", true, 16);
    if (wrappers.size() >= 16 ||
        std::find(wrappers.begin(), wrappers.end(), b.shutdownWrapper) == wrappers.end())
        return fail("balanced shutdown wrapper");
    for (auto pair :
         {std::pair<unsigned, std::uintptr_t>{0x38, b.shutdown}, {0x48, b.initialize}, {0x50, b.update}})
        if (!a.Read(b.selectorVtable + pair.first, v) || v != pair.second)
            return fail("selector vtable/code ABI");

    if (a.Rip(b.initialize + 0x97, 1, 5) != b.choice)
        return fail("initialize -> choice edge");
    if (!a.Read(b.clipVtable + 8, b.clipValid) || !a.Contains(b.clipValid, 1, 0x20000000))
        return fail("clip validity method");
    auto at = [&](std::uintptr_t address, const char* pattern) {
        const auto bytes = HudPattern(pattern);
        for (std::size_t i = 0; i < bytes.size(); ++i) {
            unsigned char value = 0;
            if (!a.Read(address + i, value) || (bytes[i] >= 0 && value != bytes[i]))
                return false;
        }
        return true;
    };
    if (!at(a.Rip(b.initialize + 0x24, 1, 5),
            "FF 41 14 0F 57 C0 F3 0F 11 41 20 F3 0F 11 41 1C C7 41 18 00 00 00 00 C3") ||
        !at(b.clipValid, "40 53 48 83 EC 20 48 8B 51 28 48 8B D9 48 85 D2"))
        return fail("base init/clip-valid ABI");
    std::uintptr_t nodeTable = 0, nodeIndex = 0;
    if (!unique(a, "node-table", "48 8B 7B 10 48 63 43 08 48 8D 34 C7 48 3B FE", nodeTable) ||
        !unique(a, "definition-index", "48 8B 41 08 4C 63 72 78 44 0F B7 78 08", nodeIndex))
        return fail("node membership layout");
    std::uintptr_t weapon = 0, ref = 0, ctx = 0;
    if (!unique(c, "weapon-type-setter", preview_selector_patterns::WeaponTypeSetter, weapon) ||
        !unique(a, "referenced-child", preview_selector_patterns::RefChild, ref) ||
        !unique(a, "context", preview_selector_patterns::Context, ctx))
        return fail("graph/weapon layouts");
    auto typeBindings = c.Find(preview_selector_patterns::WeaponTypeBinding, true, 16);
    unsigned typeCount = 0;
    for (auto hit : typeBindings)
        if (c.Text(c.Rip(hit), "weapon_type"))
            ++typeCount;
    log << "weapon-type-name=" << typeCount << "; ";
    if (typeBindings.size() >= 16 || typeCount != 1)
        return fail("weapon_type name/field binding");
    auto candidates = c.Find(preview_selector_patterns::SymbolInit, true, 2048);
    unsigned count = 0;
    for (auto hit : candidates)
        if (c.Text(c.Rip(hit), "weapon_ssg08")) {

            b.ssg08Symbol = c.Rip(hit + 27);
            ++count;
        }
    log << "ssg08-symbol=" << count << "; ";
    if (candidates.size() >= 2048 || count != 1 || !c.Contains(b.ssg08Symbol, 8, 0x80000000, 0x20000000))
        return fail("SSG08 symbol initializer");
    b.weaponSetter = weapon;
    if (!unique(c, "preview-is-CT-setter", preview_selector_patterns::CtSetter, b.ctSetter))
        return fail("native is_CT setter");
    auto ctNames = c.Find(preview_selector_patterns::CtBinding, true, 4);
    unsigned ctCount = 0;
    for (auto hit : ctNames)
        if (c.Text(c.Rip(hit), "is_CT"))
            ++ctCount;
    if (ctNames.size() >= 4 || ctCount != 1)
        return fail("is_CT constructor binding");

    auto sequences = c.Find("48 8B 8B B8 37 00 00 48 8D 54 24 ? E8 ? ? ? ? 8B 93 90 37 00 00", true, 16);
    unsigned order = 0;
    for (auto hit : sequences)
        if (c.Rip(hit + 12, 1, 5) == weapon) {
            bool write = false;
            for (unsigned back = 4; back <= 128 && hit >= back; ++back) {
                unsigned char q[4]{};
                if (c.Bytes(hit - back, q, 4) && q[0] == 0x44 && q[1] == 0x88 && q[2] == 0x41 && q[3] == 0x18)
                    write = true;
            }
            if (write)
                ++order;
        }
    if (sequences.size() >= 16 || order != 2)
        return fail("is_CT before weapon_type refresh order");
    log << "is-CT-name=1; refresh-order=2; ";
    out = b;
    diagnostic = log.str() + "selector lifecycle signatures verified as data; runtime NOT verified";
    return true;
}
struct PreviewCtBinding {
    std::uintptr_t graph = 0, node = 0;
    std::int16_t index = -1;
    std::uint8_t value = 0;
};
template <class Read>
bool ResolvePreviewCtBinding(Read&& read, const PreviewIdleSelectorBindings& b, const PreviewIdleOwner& owner,
                             PreviewCtBinding& out) {
    out = {};
    PreviewCtBinding x;
    std::uintptr_t table = 0, vt = 0;
    std::int32_t count = 0;
    if (!read(owner.controller + 0x230, x.graph) || x.graph != owner.graph ||
        !read(owner.controller + 0x238, x.index) || x.index < 0 || !read(x.graph + 8, count) || count < 1 ||
        count > 4096 || x.index >= count || !read(x.graph + 0x10, table) || !table ||
        !read(table + std::uintptr_t(x.index) * 8, x.node) || !x.node || !read(x.node, vt) ||
        vt != b.boolVtable || !read(x.node + 0x18, x.value) || x.value > 1)
        return false;
    out = x;
    return true;
}
}
