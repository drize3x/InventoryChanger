#pragma once
#include "game_hud_win32.h"
#include "players_preview_bridge_patterns.h"
#include "players_native_preview_script.h"
#ifndef MENU_STUDIO_HUD_TEST_STUB
#include "inventory_charm_patterns.h"
#include "inventory_charm_position_pattern.h"
#include "inventory_charm_panel_diagnostic.h"
#include "inventory_premier_panel_diagnostic.h"
#include "inventory_premier_color.h"
#include "inventory_premier_scene_diag.h"
#include "inventory_premier_queue_diag.h"
#include "inventory_premier_trace_win32.h"
#endif
#include <mutex>
#include <cstdio>
#include "preview_root_probe.h"
#ifndef MENU_STUDIO_HUD_TEST_STUB
#include "preview_offscreen_win32.h"
#include "preview_idle_lock_win32.h"
#include "preview_charm_live_win32.h"
#include "preview_idle_selector_win32.h"
#include "players_preview_icons_win32.h"
#include "inventory_art_win32.h"
#include "inventory_live_rarity.h"
#endif
#if defined(MENU_STUDIO_HUD_TEST_STUB)
#define MENU_PREVIEW_TRY try
#define MENU_PREVIEW_EXCEPT catch (...)
#elif defined(_MSC_VER)
#define MENU_PREVIEW_TRY __try
#define MENU_PREVIEW_EXCEPT __except (EXCEPTION_EXECUTE_HANDLER)
#else
#error Preview requires MSVC SEH or a synthetic test shim.
#endif
namespace menu {
#if defined(MENU_STUDIO_PREVIEW_TEST_CALLS)
std::uint64_t PreviewTestPaint();
bool PreviewTestVisible(std::uintptr_t, std::uintptr_t, bool&);
bool PreviewTestScript(std::uintptr_t, std::uintptr_t, std::uintptr_t, const char*);
bool PreviewTestFind(std::uintptr_t, std::uintptr_t, const char*, std::uintptr_t&);
#endif

inline constexpr std::uint64_t NativePreviewScriptOrigin = 1;
class NativePlayerPreview {
public:
    enum class Status {
        Waiting,
        Unsupported,
        Ready,
        NoRoot,
        Submitted,
        PanelConfirmed,
        Hidden,
        Fault,
        Stopped
    };
    struct RequestFallback {
        NativePreviewRequest (*get)(void*) = nullptr;
        void* context = nullptr;
    };
#if defined(MENU_STUDIO_HUD_TEST_STUB)
public:
#else
private:
#endif
    inline static NativePlayerPreview* instance_ = nullptr;
    std::atomic<Status> state_{Status::Waiting};
    std::atomic<bool> ready_{false}, closing_{false}, ack_{false};
    std::mutex mutex_;
    NativePreviewRequest wanted_{}, warmPreferred_ = PreviewServiceRequest(), confirmed_{};
    ULONGLONG submitted_ = 0, confirmedAt_ = 0;
    bool haveSubmission_ = false;
    void (*itemScriptProbe_)(bool) = nullptr;
    RequestFallback fallback_{};
    DWORD fallbackThread_ = 0;
    PreviewBridgeBindings bindings_{};
#ifndef MENU_STUDIO_HUD_TEST_STUB
    PreviewOffscreenCapture capture_;
    PanoramaPreviewIcons icons_;
    InventoryArtNative artwork_;
    InventoryRarityBridge rarity_;
    ULONGLONG nextIcons_ = 0;
    std::uintptr_t iconRoot_ = 0;
    bool iconHost_ = false;
    unsigned iconAttempts_ = 0;
    PreviewCharmLive charmLive_;
    PreviewIdleSeedLock idle_;
    PreviewIdleSelectorLock selector_;
#endif
    std::string detail_;
    std::uint64_t token_ = 0;
    HMODULE seenClient_ = nullptr, seenPanorama_ = nullptr;
    bool attempted_ = false;
    std::atomic<bool> dispatched_{false};
    PreviewRootProbe rootProbe_;
    std::atomic<unsigned> rootRevision_{0};
    std::uintptr_t observedRoot_ = 0;
    std::atomic<std::uintptr_t> hudCandidate_{0}, menuCandidate_{0};
    std::atomic<ULONGLONG> paintAge_{0};
    std::atomic<unsigned> rootSource_{0};
    DWORD uiThread_ = 0;
    ULONGLONG nextScript_ = 0;

#ifndef MENU_STUDIO_HUD_TEST_STUB
    std::uintptr_t charmSetter_ = 0, charmLookup_ = 0;
    std::atomic<std::uintptr_t> charmPositionProbe_{0};

    using CharmPanelSample = charm::PanelDiagnostic;
    CharmPanelSample ownCharmSample_{}, officialCharmSample_{};
    premier_diag::Sample premierSample_{};
    bool premierPrepareOK_ = false;
    premier_color::Bindings premierColor_{};
    std::uintptr_t premierModuleBase_ = 0, premierModuleEnd_ = 0;

    std::uintptr_t premierAppliedClient_ = 0;
    std::int32_t premierAppliedHandle_ = -1;
    std::uint64_t premierAppliedGeneration_ = 0;
    std::atomic<unsigned> premierColorStatus_{0}, premierColorCalls_{0};

    using PremierQueueProbe = premier_queue_diag::Sample;
    PremierQueueProbe premierQueueInitial_{}, premierQueueLatest_{};
    std::uint64_t premierQueueGeneration_ = 0;
    premier_scene_diag::Sample premierSceneLatest_{};
    PremierSceneTrace premierTrace_;
    static std::uintptr_t PremierProbeEntity(std::uintptr_t fn, std::uintptr_t client) {
        MENU_PREVIEW_TRY {
            return reinterpret_cast<std::uintptr_t(__fastcall*)(void*)>(fn)(
                reinterpret_cast<void*>(client + 0x8f8));
        }
        MENU_PREVIEW_EXCEPT {
            return 0;
        }
    }
    PremierQueueProbe SamplePremierQueue(std::uintptr_t client) {
        if (!premierColor_.entity)
            return {};
        auto ent = PremierProbeEntity(premierColor_.entity, client);
        std::uintptr_t vt = 0;
        if (!ent || !Read(ent, vt) || vt < premierModuleBase_ || vt >= premierModuleEnd_)
            return {};
        std::array<std::uint32_t, 6> names{};
        if (!Bytes(premierColor_.names, names.data(), sizeof names))
            return {};
        return premier_queue_diag::Read(
            ent, names, [](std::uintptr_t a, void* out, std::size_t n) { return Bytes(a, out, n); });
    }

    static bool ApplyPremierVectors(const premier_color::Bindings& b, std::uintptr_t client,
                                    std::uintptr_t moduleBase, std::uintptr_t moduleEnd,
                                    const std::array<std::uint32_t, 6>& names,
                                    const std::array<float, 24>& vectors, std::uint32_t handle,
                                    PremierSceneTrace* trace) {

        MENU_PREVIEW_TRY {
            using GetEntity = std::uintptr_t(__fastcall*)(void*);
            using GetAttrs = std::uintptr_t(__fastcall*)(void*);
            using SetVector = void(__fastcall*)(void*, std::uint32_t, const float*);
            auto ent = reinterpret_cast<GetEntity>(b.entity)(reinterpret_cast<void*>(client + 0x8f8));
            if (!ent)
                return false;
            std::uintptr_t vt = 0;
            if (!Read(ent, vt) || vt < moduleBase || vt >= moduleEnd)
                return false;
            auto attrs = reinterpret_cast<GetAttrs>(b.attributes)(reinterpret_cast<void*>(ent));
            if (!attrs)
                return false;
            auto set = reinterpret_cast<SetVector>(b.setVector);
            if (trace)
                trace->Arm(attrs, handle);
            for (std::size_t i = 0; i < names.size(); ++i)
                set(reinterpret_cast<void*>(attrs), names[i], vectors.data() + i * 4);
            return true;
        }
        MENU_PREVIEW_EXCEPT {
            return false;
        }
    }
    void ReapplyPremierColor(std::uintptr_t client, const NativePreviewRequest& request,
                             const premier_diag::Sample& sample) {
        if (!premierColor_.entity || !premier_color::Valid(request.premier[1], request.premier[3])) {
            premierColorStatus_ = 1;
            return;
        }
        if (!sample.itemRead || !sample.itemModelText || !sample.itemIdMatch || sample.itemPending ||
            !sample.lookupPresent || sample.itemHandle == -1 || sample.itemHandle == -2 ||
            !capture_.LastSelectedPaint()) {
            premierColorStatus_ = 2;
            return;
        }
        if (premierAppliedClient_ == client && premierAppliedHandle_ == sample.itemHandle &&
            premierAppliedGeneration_ == itemPanelGeneration_)
            return;
        std::array<std::uint32_t, 6> names{};
        std::array<float, 32> palette{};
        if (!Bytes(premierColor_.names, names.data(), sizeof names) ||
            !Bytes(premierColor_.palette, palette.data(), sizeof palette)) {
            premierColorStatus_ = 3;
            return;
        }
        for (std::size_t i = 0; i < names.size(); ++i) {
            if (!names[i]) {
                premierColorStatus_ = 3;
                return;
            }
            for (std::size_t j = 0; j < i; ++j)
                if (names[i] == names[j]) {
                    premierColorStatus_ = 3;
                    return;
                }
        }

        premierAppliedClient_ = client;
        premierAppliedHandle_ = sample.itemHandle;
        premierAppliedGeneration_ = itemPanelGeneration_;
        const auto vectors = premier_color::BuildVectors(palette, request.premier[1], request.premier[3]);
        if (ApplyPremierVectors(premierColor_, client, premierModuleBase_, premierModuleEnd_, names, vectors,
                                std::uint32_t(sample.itemHandle), &premierTrace_)) {
            premierColorCalls_.fetch_add(1, std::memory_order_relaxed);
            premierColorStatus_ = 4;
        } else
            premierColorStatus_ = 5;
    }

    ULONGLONG nextOfficialSample_ = 0, nextOwnSample_ = 0;
    CharmPanelSample SampleCharmPanel(std::uintptr_t client, ULONGLONG now) {
        return charm::ReadPanelDiagnostic(
            client, now, [](std::uintptr_t a, void* p, std::size_t n) { return Bytes(a, p, n); });
    }
    void SampleOfficialCharmPanel(std::uintptr_t root, ULONGLONG now) {
        if (now < nextOfficialSample_ || !charmPositionProbe_.load(std::memory_order_acquire) ||
            !bindings_.itemVtable)
            return;
        nextOfficialSample_ = now + 100;
        std::uintptr_t panel = 0, client = 0, vt = 0;
        if (!Find(bindings_.findChild, root, "ItemPreviewPanel", panel) || !panel || !Read(panel, vt) ||
            vt != bindings_.panelVtable || !Read(panel + bindings_.clientOffset, client) ||
            !Read(client, vt) || vt != bindings_.itemVtable)
            client = 0;
        const auto sample = SampleCharmPanel(client, now);
        std::lock_guard<std::mutex> l(mutex_);
        officialCharmSample_ = sample;
    }
    static std::uintptr_t PremierLookup(std::uintptr_t fn, std::uint64_t id) {
        if (!fn)
            return 0;
        MENU_PREVIEW_TRY {
            return reinterpret_cast<std::uintptr_t(__fastcall*)(std::uint64_t)>(fn)(id);
        }
        MENU_PREVIEW_EXCEPT {
            return 0;
        }
    }

    static bool PremierPrepare(std::uintptr_t lookup, std::uintptr_t setter, const NativePreviewRequest& r) {
        if (!lookup || !setter || !PreviewHasPremier(r))
            return false;
        for (int value : r.premier)
            if (value < -1 || value > 65535)
                return false;
        MENU_PREVIEW_TRY {
            auto view = reinterpret_cast<void*(__fastcall*)(std::uint64_t)>(lookup)(PreviewFauxCharmId(r));
            if (!view)
                return false;
            auto set = reinterpret_cast<void(__fastcall*)(void*, const char*, float)>(setter);
            static const char* names[] = {"premier season", "premier season clrs", "premier season clrs max",
                                          "premier season bars", "premier season bars max"};
            for (std::size_t i = 0; i < r.premier.size(); ++i)
                if (r.premier[i] >= 0)
                    set(view, names[i], local_decorations::Bits(std::uint32_t(r.premier[i])));
            return true;
        }
        MENU_PREVIEW_EXCEPT {
            return false;
        }
    }
    static bool CharmPrepare(std::uintptr_t lookup, std::uintptr_t setter, const NativePreviewRequest& r) {
        if (!lookup || !setter || !charm::Valid(r.charm) || !local_decorations::Valid(r.decorations))
            return false;

        MENU_PREVIEW_TRY {
            auto view = reinterpret_cast<void*(__fastcall*)(std::uint64_t)>(lookup)(PreviewFauxCharmId(r));
            if (!view)
                return false;
            auto set = reinterpret_cast<void(__fastcall*)(void*, const char*, float)>(setter);
            char name[64]{};
            for (int i = 0; i < 5; ++i) {
                auto st = PreviewBaseSticker(r, i);

                std::snprintf(name, sizeof name, "sticker slot %d id", i);
                set(view, name, local_decorations::Bits(std::uint32_t(st.id)));
                if (!st.id)
                    continue;
                std::snprintf(name, sizeof name, "sticker slot %d schema", i);
                set(view, name, local_decorations::Bits(0));
                std::snprintf(name, sizeof name, "sticker slot %d wear", i);
                set(view, name, 0.f);
                std::snprintf(name, sizeof name, "sticker slot %d scale", i);
                set(view, name, 1.f);
                std::snprintf(name, sizeof name, "sticker slot %d rotation", i);
                set(view, name, st.rotation);
                std::snprintf(name, sizeof name, "sticker slot %d offset x", i);
                set(view, name, st.x);
                std::snprintf(name, sizeof name, "sticker slot %d offset y", i);
                set(view, name, st.y);
            }
            std::array<charm::Attribute, 5> attrs{};
            if (!charm::Encode(r.charm, attrs))
                return false;
            for (const auto& a : attrs)
                set(view, a.name, a.value);
            return true;
        }
        MENU_PREVIEW_EXCEPT {
            return false;
        }
    }
#endif
    std::uint64_t itemPanelGeneration_ = 0;
    NativePreviewRequest lastSent_{};
    std::uintptr_t lastRoot_ = 0, activeClient_ = 0;
    bool haveLastSent_ = false, poolNeedsRepair_ = false;
    static bool Bytes(std::uintptr_t a, void* out, std::size_t n) {
        SIZE_T k = 0;
        return a && ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(a), out, n, &k) &&
               k == n;
    }
    template <class T> static bool Read(std::uintptr_t a, T& out) {
        return Bytes(a, &out, sizeof(out));
    }
    static bool Run(std::uintptr_t fn, std::uintptr_t engine, std::uintptr_t panel, const char* code) {
#if defined(MENU_STUDIO_PREVIEW_TEST_CALLS)
        return PreviewTestScript(fn, engine, panel, code);
#else

        MENU_PREVIEW_TRY {
            reinterpret_cast<void(__fastcall*)(void*, void*, const char*, const char*, std::uint64_t)>(fn)(
                reinterpret_cast<void*>(engine), reinterpret_cast<void*>(panel), code,
                "file://{resources}/layout/avatar.xml", NativePreviewScriptOrigin);
            return true;
        }
        MENU_PREVIEW_EXCEPT {
            return false;
        }
#endif
    }
    static bool Visible(std::uintptr_t fn, std::uintptr_t panel, bool& visible) {
#if defined(MENU_STUDIO_PREVIEW_TEST_CALLS)
        return PreviewTestVisible(fn, panel, visible);
#else
        MENU_PREVIEW_TRY {
            visible = reinterpret_cast<bool(__fastcall*)(void*)>(fn)(reinterpret_cast<void*>(panel));
            return true;
        }
        MENU_PREVIEW_EXCEPT {
            visible = false;
            return false;
        }
#endif
    }
    static bool Find(std::uintptr_t fn, std::uintptr_t parent, const char* id, std::uintptr_t& panel) {
#if defined(MENU_STUDIO_PREVIEW_TEST_CALLS)
        return PreviewTestFind(fn, parent, id, panel);
#else
        MENU_PREVIEW_TRY {
            panel = reinterpret_cast<std::uintptr_t(__fastcall*)(void*, const char*)>(fn)(
                reinterpret_cast<void*>(parent), id);
            return true;
        }
        MENU_PREVIEW_EXCEPT {
            return false;
        }
#endif
    }
    void Invalidate() {
        activeClient_ = 0;
#ifndef MENU_STUDIO_HUD_TEST_STUB
        premierTrace_.Clear();
        charmLive_.Select(0, {});
        idle_.Select(0);
        selector_.Select(0);
        capture_.Select(0);
#endif
        std::lock_guard<std::mutex> l(mutex_);
        confirmedAt_ = 0;
#ifndef MENU_STUDIO_HUD_TEST_STUB
        ownCharmSample_ = {};
#endif
    }

    void Fault() {
        Invalidate();
        state_ = Status::Fault;
        ready_ = false;
    }
    void Tick(void* object, const HudResolvedBindings& hud) {
        if (!ready_.load(std::memory_order_acquire)) {
            if (closing_ && !dispatched_)
                ack_ = true;
            return;
        }
        const auto thread = GetCurrentThreadId();
        if (!uiThread_)
            uiThread_ = thread;
        if (uiThread_ != thread) {
            Fault();
            return;
        }
        auto engine = reinterpret_cast<std::uintptr_t>(object);
        std::uintptr_t vt = 0;
        if (!Read(engine, vt) || vt != bindings_.engineVtable) {
            Fault();
            return;
        }
        NativePreviewRequest request;
        ULONGLONG submitted = 0;
        bool haveSubmission = false;
        bool stickerLiveRequested = false;
        {
            std::lock_guard<std::mutex> l(mutex_);
            request = PreviewServiceRequest(warmPreferred_);
            submitted = submitted_;
            haveSubmission = haveSubmission_;
            stickerLiveRequested = wanted_.enabled && wanted_.stickerLiveSlot >= 0;
        }
        auto now = GetTickCount64();
        const bool serviceOn = !closing_ && haveSubmission && now >= submitted && now - submitted <= 500 &&
                               PreviewItemValid(request) && (!PreviewIsItem(request) || bindings_.itemVtable);
        if (!serviceOn)
            request.enabled = false;
#ifndef MENU_STUDIO_HUD_TEST_STUB

#endif
        std::uintptr_t root = 0;

        auto panelRoot = [&](std::uintptr_t global, std::uintptr_t expected, bool& hint) {
            hint = true;
            std::uintptr_t client = 0, panel = 0, v = 0;
            if (!Read(global, client) || !client || (expected && (!Read(client, v) || v != expected)) ||
                !Read(client + bindings_.hudRootOffset, panel) || !Read(panel, v) ||
                v != bindings_.panelVtable)
                return std::uintptr_t(0);
            std::array<std::uintptr_t, 64> seen{};
            unsigned used = 0;
            while (panel && used < seen.size()) {
                for (unsigned i = 0; i < used; ++i)
                    if (seen[i] == panel)
                        return std::uintptr_t(0);
                seen[used++] = panel;
                bool visible = false;
                if (!Visible(bindings_.isVisible, panel, visible) || !visible)
                    hint = false;
                std::uintptr_t parent = 0;
                if (!Read(panel + bindings_.parentOffset, parent))
                    return std::uintptr_t(0);
                if (!parent)
                    return panel;
                if (!Read(parent, v) || v != bindings_.panelVtable)
                    return std::uintptr_t(0);
                panel = parent;
            }
            return std::uintptr_t(0);
        };
        bool hudHint = false, menuHint = false;
        auto hudRoot = panelRoot(hud.hudGlobal, 0, hudHint);
        auto menuRoot = panelRoot(bindings_.mainMenuGlobal, bindings_.mainMenuVtable, menuHint);
        hudCandidate_ = hudRoot;
        menuCandidate_ = menuRoot;
        ULONGLONG paint = 0;
#if defined(MENU_STUDIO_PREVIEW_TEST_CALLS)
        paint = PreviewTestPaint();
#elif !defined(MENU_STUDIO_HUD_TEST_STUB)
        paint = capture_.LastSelectedPaint();
#endif
        paintAge_ = paint && now >= paint ? now - paint : ~ULONGLONG(0);
        root = rootProbe_.Pick(hudRoot, menuRoot, hudHint, menuHint, serviceOn, now, paint);
        rootSource_ = root ? (root == hudRoot ? 1 : 2) : 0;
        if (root != observedRoot_) {
            observedRoot_ = root;
            rootRevision_.fetch_add(1, std::memory_order_release);
        }
        if (!root) {
#ifndef MENU_STUDIO_HUD_TEST_STUB
            artwork_.LostRoot();
            rarity_.LostRoot(now);
#endif
            Invalidate();
            state_ = Status::NoRoot;
            haveLastSent_ = false;

            if (closing_)
                ack_ = true;
            return;
        }
#ifndef MENU_STUDIO_HUD_TEST_STUB
        SampleOfficialCharmPanel(root, now);

        if (!artwork_.Tick(
                root, token_, closing_,
                [&](const std::string& code) { return Run(bindings_.runScript, engine, root, code.c_str()); },
                [&](std::uintptr_t parent, const char* id, std::uintptr_t& out) {
                    return Find(bindings_.findChild, parent, id, out);
                },
                [](std::uintptr_t a, auto& value) { return Read(a, value); })) {
            Fault();
            return;
        }
        if (!rarity_.Tick(
                root, token_, now, closing_, bindings_.panelVtable,
                [&](const std::string& code) { return Run(bindings_.runScript, engine, root, code.c_str()); },
                [&](std::uintptr_t parent, const char* id, std::uintptr_t& out) {
                    return Find(bindings_.findChild, parent, id, out);
                },
                [](std::uintptr_t a, auto& value) { return Read(a, value); })) {
            Fault();
            return;
        }

        if (icons_.Ready() && (root != iconRoot_ || now >= nextIcons_ || closing_)) {
            if (root != iconRoot_) {
                iconRoot_ = root;
                iconAttempts_ = 0;
                iconHost_ = false;
            }
            std::vector<std::string> missing;
            for (std::size_t i = 0; i < LiveEquipmentIconCount; ++i)
                if (!GamePreviewIcons().Has(unsigned(i)))
                    missing.emplace_back(LiveEquipmentIconNames[i]);
            bool remove = closing_ || missing.empty() || iconAttempts_ >= 60;
            if (!remove || iconHost_) {
                auto script = BuildEquipmentIconScript(token_, missing, remove);
                if (!Run(bindings_.runScript, engine, root, script.c_str())) {
                    Fault();
                    return;
                }
                iconHost_ = !remove;
                if (!remove)
                    ++iconAttempts_;
            }
            nextIcons_ = now + 500;
        }
#endif

        const bool rootChanged = haveLastSent_ && root != lastRoot_;
        const bool sceneChanged = haveLastSent_ && !PreviewSameScene(request, lastSent_);
        if (rootChanged && (lastRoot_ == hudRoot || lastRoot_ == menuRoot)) {

            auto park = BuildNativePreviewPoolStateScript(token_, -1, NativePreviewPoolAction::Park);
            if (!Run(bindings_.runScript, engine, lastRoot_, park.c_str())) {
                Fault();
                return;
            }
        }
        if (!serviceOn) {
            const bool remove = closing_.load(std::memory_order_acquire);
            if (dispatched_ && (!haveLastSent_ || rootChanged || lastSent_.enabled || remove)) {
                auto code = BuildNativePreviewPoolStateScript(
                    token_, -1, remove ? NativePreviewPoolAction::Remove : NativePreviewPoolAction::Park);
                if (!Run(bindings_.runScript, engine, root, code.c_str())) {
                    Fault();
                    return;
                }
                nextScript_ = now + 250;
            }
            Invalidate();
            request.enabled = false;
            lastSent_ = request;
            lastRoot_ = root;
            haveLastSent_ = true;
            state_ = Status::Hidden;
            if (remove) {
                bool any = false;
                for (int i = 0; i < NativePreviewPoolSize; ++i) {
                    std::uintptr_t host = 0;
                    auto id = PreviewRequestHostId(token_, PreviewPoolRequest({}, i));
                    if (!Find(bindings_.findChild, root, id.c_str(), host)) {
                        Fault();
                        return;
                    }
                    any |= host != 0;
                }
                if (!any) {
                    dispatched_ = false;
                    ack_ = true;
                    state_ = Status::Stopped;
                }
            }
            return;
        }
        const bool changed = !haveLastSent_ || rootChanged || sceneChanged || !lastSent_.enabled;

        if (changed && haveLastSent_ && !rootChanged && lastSent_.enabled) {
            auto park = BuildNativePreviewPoolStateScript(token_, -1, NativePreviewPoolAction::Park);
            if (!Run(bindings_.runScript, engine, root, park.c_str())) {
                Fault();
                return;
            }
        }
#ifndef MENU_STUDIO_HUD_TEST_STUB
        if (changed && haveLastSent_ && PreviewIsItem(lastSent_) && PreviewHasDecorations(lastSent_)) {
            auto clean = lastSent_;
            clean.charm = {};
            clean.decorations = {};
            clean.stickerLiveSlot = -1;
            if (!CharmPrepare(charmLookup_, charmSetter_, clean)) {
                Invalidate();
                state_ = Status::Unsupported;
                return;
            }
        }

        if (changed && PreviewHasPremier(request)) {
            auto prewarm = BuildPremierWarmupScript(request);
            if (!Run(bindings_.runScript, engine, root, prewarm.c_str())) {
                Fault();
                return;
            }
            const bool prepared = PremierPrepare(charmLookup_, charmSetter_, request);
            {
                std::lock_guard<std::mutex> l(mutex_);
                premierPrepareOK_ = prepared;
            }
        }
        if (changed && PreviewIsItem(request) && PreviewHasDecorations(request) &&
            !CharmPrepare(charmLookup_, charmSetter_, request)) {
            Invalidate();
            state_ = Status::Unsupported;
            return;
        }
#endif
        if (changed) {
            Invalidate();
            if (PreviewIsItem(request)) {
                ++itemPanelGeneration_;
                if (!itemPanelGeneration_)
                    ++itemPanelGeneration_;
            }
        }
        const bool poseChanged = PreviewIsItem(request) && haveLastSent_ &&
                                 (request.yaw != lastSent_.yaw || request.pitch != lastSent_.pitch);
        const bool scriptDue = changed || now >= nextScript_;
        if (scriptDue) {
            const bool reconcile =
                !dispatched_ || !haveLastSent_ || rootChanged || !lastSent_.enabled || poolNeedsRepair_;
            auto code = reconcile ? BuildNativePreviewPoolScript(request, token_, bindings_.itemVtable != 0,
                                                                 itemPanelGeneration_)
                                  : BuildNativePreviewPoolStateScript(token_, PreviewPoolSlot(request),
                                                                      NativePreviewPoolAction::Renew);
            if (!Run(bindings_.runScript, engine, root, code.c_str())) {
                Fault();
                return;
            }
            dispatched_ = true;
            poolNeedsRepair_ = false;
            nextScript_ = now + 250;
        }
        if (PreviewIsItem(request) && (scriptDue || poseChanged)) {
            auto code = BuildNativeItemStateScript(request, token_, itemPanelGeneration_);
            if (itemScriptProbe_)
                itemScriptProbe_(true);
            const bool ok = Run(bindings_.runScript, engine, root, code.c_str());
            if (itemScriptProbe_)
                itemScriptProbe_(false);
            if (!ok) {
                Fault();
                return;
            }
        }
        lastSent_ = request;
        lastRoot_ = root;
        haveLastSent_ = true;
        std::uintptr_t host = 0, panel = 0, client = 0;
        auto id = PreviewRequestHostId(token_, request);
        if (!Find(bindings_.findChild, root, id.c_str(), host)) {
            Fault();
            return;
        }

        if (!host || !Read(host, vt) || vt != bindings_.panelVtable) {
            poolNeedsRepair_ = true;
            Invalidate();
            state_ = Status::Submitted;
            return;
        }
        const auto panelId =
            PreviewIsItem(request) ? PreviewItemPanelId(itemPanelGeneration_) : std::string("nlpreview");
        if (!Find(bindings_.findChild, host, panelId.c_str(), panel)) {
            Fault();
            return;
        }
        if (!panel || !Read(panel, vt) || vt != bindings_.panelVtable ||
            !Read(panel + bindings_.clientOffset, client) || !Read(client, vt) ||
            vt != (PreviewIsItem(request) ? bindings_.itemVtable : bindings_.playerVtable)) {
            Invalidate();
            state_ = Status::Submitted;
            return;
        }
#ifndef MENU_STUDIO_HUD_TEST_STUB
        if (request.scene == NativePreviewScene::Players) {
            idle_.Select(client);
            selector_.Select(client, request.terrorist);
            if (request.terrorist && (scriptDue || activeClient_ != client))
                selector_.PrimeCtPose();
        } else {
            idle_.Select(0);
            selector_.Select(0);
        }
        capture_.Select(client, PreviewServiceWidth(request), PreviewServiceHeight(request));
        if (!capture_.Started()) {
            Fault();
            return;
        }
        if (activeClient_ != client) {
            std::string activate = "(function(){var h=$.GetContextPanel().FindChildTraverse('" + id +
                                   "');if(h&&h.IsValid())h.visible=true;})();";
            if (!Run(bindings_.runScript, engine, root, activate.c_str())) {
                Fault();
                return;
            }
        }
#endif
        activeClient_ = client;
#ifndef MENU_STUDIO_HUD_TEST_STUB
        if (PreviewHasPremier(request) && now >= nextOwnSample_) {
            const auto faux = PremierLookup(charmLookup_, PreviewFauxCharmId(request));
            auto sample =
                premier_diag::Read(client, faux, PreviewFauxCharmId(request), request.itemDefinition, now,
                                   [](std::uintptr_t a, void* p, std::size_t n) { return Bytes(a, p, n); });
            ReapplyPremierColor(client, request, sample);
            if (sample.itemRead && sample.itemIdMatch && sample.itemModelText && !sample.itemPending &&
                sample.lookupPresent && sample.itemHandle != -1 && sample.itemHandle != -2 &&
                premierColorStatus_.load() == 4)
                PremierDrawTrace::Instance().RefreshFix(std::uint32_t(sample.itemHandle));
            PremierQueueProbe queue{};
            if (sample.itemRead && sample.itemIdMatch && sample.itemModelText && !sample.itemPending)
                queue = SamplePremierQueue(client);
            premier_scene_diag::Sample scene{};
            if (sample.itemRead && sample.itemIdMatch && sample.itemModelText && !sample.itemPending &&
                premierColor_.entity) {
                auto ent = PremierProbeEntity(premierColor_.entity, client);
                std::uintptr_t v = 0;
                std::array<std::uint32_t, 6> names{};
                if (ent && Read(ent, v) && v >= premierModuleBase_ && v < premierModuleEnd_ &&
                    Bytes(premierColor_.names, names.data(), sizeof names))
                    scene = premier_scene_diag::Read(
                        ent, std::uint32_t(sample.itemHandle), names, request.premier[1], request.premier[3],
                        [](std::uintptr_t a, void* p, std::size_t n) { return Bytes(a, p, n); });
            }
            std::lock_guard<std::mutex> l(mutex_);
            premierSample_ = sample;
            premierQueueLatest_ = queue;
            premierSceneLatest_ = scene;
            if (queue.read && premierColorStatus_.load() == 4 &&
                premierQueueGeneration_ != itemPanelGeneration_) {
                premierQueueInitial_ = queue;
                premierQueueGeneration_ = itemPanelGeneration_;
            }
        }
#endif
#ifndef MENU_STUDIO_HUD_TEST_STUB
        if (stickerLiveRequested && request.stickerLiveSlot >= 0 && request.stickerLiveSlot < 5)
            charmLive_.SelectSticker(client, request.stickerLiveSlot,
                                     request.decorations.stickers[std::size_t(request.stickerLiveSlot)],
                                     request.stickerDragging);
        else
            charmLive_.Select(request.charmLive && request.charmPlacementProbe ? client : 0, request.charm);
        if (now >= nextOwnSample_) {
            nextOwnSample_ = now + 100;
            auto sample = PreviewIsItem(request) ? SampleCharmPanel(client, now) : CharmPanelSample{};
            std::lock_guard<std::mutex> l(mutex_);
            ownCharmSample_ = sample;
        }
#endif
        {
            std::lock_guard<std::mutex> l(mutex_);
            confirmed_ = request;
            confirmedAt_ = now;
        }
        state_ = Status::PanelConfirmed;
    }

public:
    static void Frame(void* engine, const HudResolvedBindings& hud) noexcept {
        auto self = instance_;
        if (!self)
            return;
        try {
            self->Tick(engine, hud);
        } catch (...) {
            self->Fault();
        }
    }
    void SetItemScriptProbe(void (*probe)(bool)) {
        itemScriptProbe_ = probe;
    }
    void Attach(WatermarkNativeHud& hud) {
        instance_ = this;
        token_ = GetTickCount64();
        if (!token_)
            token_ = 1;
        hud.SetFrameObserver(Frame);
    }

    RequestFallback SetRequestFallback(RequestFallback next) {
        std::lock_guard<std::mutex> l(mutex_);
        auto previous = fallback_;
        fallback_ = next;
        fallbackThread_ = next.get ? GetCurrentThreadId() : 0;
        return previous;
    }
    void Submit(NativePreviewRequest r) {
        if (!r.enabled) {

            std::lock_guard<std::mutex> l(mutex_);
            if (!closing_ && fallback_.get && fallbackThread_ == GetCurrentThreadId())
                r = fallback_.get(fallback_.context);
        }
        if (!PreviewRequestValid(r))
            r.enabled = false;
        const auto now = GetTickCount64();
        NativePreviewRequest service;
        {
            std::lock_guard<std::mutex> l(mutex_);
            wanted_ = r;
            if (r.enabled)
                warmPreferred_ = r;
            service = closing_ ? NativePreviewRequest{} : PreviewServiceRequest(warmPreferred_);
            submitted_ = now;
            haveSubmission_ = true;
            if (closing_)
                confirmedAt_ = 0;
        }
#ifndef MENU_STUDIO_HUD_TEST_STUB
#endif
    }
    bool StickerLiveReady() const {
#ifndef MENU_STUDIO_HUD_TEST_STUB
        return charmLive_.StickerReady();
#else
        return false;
#endif
    }
    bool CharmLiveReady() const {
#ifndef MENU_STUDIO_HUD_TEST_STUB
        return charmLive_.Ready();
#else
        return false;
#endif
    }
    bool Confirmed(const NativePreviewRequest& request) {
        std::lock_guard<std::mutex> l(mutex_);
        auto now = GetTickCount64();
        return PreviewSameScene(request, confirmed_) && PreviewRequestValid(request) && ready_ && !closing_ &&
               confirmedAt_ && now >= confirmedAt_ && now - confirmedAt_ <= 300;
    }
#ifndef MENU_STUDIO_HUD_TEST_STUB

    void EnableOfficialPaintProbe(bool enabled) {
        capture_.EnableCharmProbe(enabled);
    }
    bool HasOfficialCharmSample() {
        if (capture_.CharmPaintSample().found)
            return true;
        std::lock_guard<std::mutex> l(mutex_);
        const auto now = GetTickCount64();
        return officialCharmSample_.found && officialCharmSample_.read && officialCharmSample_.at &&
               now >= officialCharmSample_.at && now - officialCharmSample_.at <= 500;
    }
    std::string CharmPanelDiagnostic() {
        CharmPanelSample own, official;
        {
            std::lock_guard<std::mutex> l(mutex_);
            own = ownCharmSample_;
            official = officialCharmSample_;
        }
        const auto now = GetTickCount64();
        std::ostringstream o;
        auto append = [&](const char* label, const CharmPanelSample& p) {
            o << label << "={found:" << p.found << ",read:" << p.read
              << ",age_ms:" << (p.at && now >= p.at ? now - p.at : 0) << ",b810:" << unsigned(p.b810)
              << ",b811:" << unsigned(p.b811) << ",b812:" << unsigned(p.b812) << ",b830:" << unsigned(p.b830)
              << ",b831:" << unsigned(p.b831) << ",b844:" << unsigned(p.b844) << "}";
        };
        append("own", own);
        o << " ";
        append("official_tree", official);
        o << " ";
        append("official_paint", capture_.CharmPaintSample());
        o << " typedPaints=" << capture_.CharmTypedPaints() << " modePaints=" << capture_.CharmModePaints();
        return o.str();
    }
    std::string PremierPanelDiagnostic() {
        premier_diag::Sample p;
        PremierQueueProbe first, last;
        premier_scene_diag::Sample scene;
        bool prepared = false;
        {
            std::lock_guard<std::mutex> l(mutex_);
            p = premierSample_;
            prepared = premierPrepareOK_;
            first = premierQueueInitial_;
            last = premierQueueLatest_;
            scene = premierSceneLatest_;
        }
        const auto now = GetTickCount64();
        std::ostringstream o;
        o << "Premier scene diag v1: def=" << p.definition
          << " age_ms=" << (p.at && now >= p.at ? now - p.at : 0) << " found=" << p.found
          << " read=" << p.read << " prepare_call_ok=" << prepared << " handle=" << p.handle
          << " model_text=" << p.modelText << " view_present=" << p.viewPresent
          << " faux_present=" << p.lookupPresent << " same_view=" << p.sameView << " pending=" << p.flag
          << " item_read=" << p.itemRead << " item_handle=" << p.itemHandle
          << " item_model_text=" << p.itemModelText << " item_id=" << p.itemId
          << " item_id_match=" << p.itemIdMatch << " item_pending=" << p.itemPending
          << " premier_color_v1_status=" << premierColorStatus_.load()
          << " color_apply_calls=" << premierColorCalls_.load() << " queue_first=" << first.entity << ","
          << first.store << "," << first.read << "," << first.count << "," << first.dirty << "," << first.mask
          << " queue_last=" << last.entity << "," << last.store << "," << last.read << "," << last.count
          << "," << last.dirty << "," << last.mask << " scene_v3=" << scene.stage << "," << scene.namesMask
          << "," << scene.foundMask << "," << scene.color << "," << scene.bars
          << " scene_list_v4=" << scene.renderCount << "," << scene.candidates << "," << scene.recordMode
          << " scene_flags_v5=" << scene.directFlags << "," << scene.listFlags;
        const auto trace = premierTrace_.Get();
        o << " scene_trace_v6=" << trace.enabled << "," << trace.current << "," << trace.matched << ","
          << trace.snapshot.stage << "," << trace.snapshot.mask << " trace_pending=" << trace.bestPending
          << " trace_switches=" << trace.switches << " trace_scene=0x" << std::hex << trace.snapshot.scene
          << " trace_map=0x" << trace.snapshot.map << " trace_last_scene=0x" << trace.last.scene << std::dec
          << " trace_last=" << trace.last.stage << "," << trace.last.mask;
        for (unsigned i = 0; i < 6; ++i)
            if (trace.last.mask & (1u << i))
                o << " trace_last_attr" << (i + 1) << "=" << trace.last.values[i][0] << ","
                  << trace.last.values[i][1] << "," << trace.last.values[i][2] << ","
                  << trace.last.values[i][3];
        const auto draw = PremierDrawTrace::Instance().Get();
        o << " draw_trace_v7=" << draw.calls << "," << draw.scanned << "," << draw.matched << ","
          << draw.truncated << "," << draw.readFail << "," << draw.materials << "," << draw.snapshot.stage
          << "," << draw.snapshot.mask << " draw_flags=0x" << std::hex << draw.flags << " draw_extra=0x"
          << draw.extra << std::dec;
        for (unsigned path = 0; path < 4; ++path) {
            const auto z = PremierDrawTrace::Instance().GetPath(path);
            o << " path" << path << "=" << z.calls << "," << z.scanned << "," << z.matched << ","
              << z.ownerCandidate << "," << z.truncated << "," << z.failed << "," << z.snapshot.stage << ","
              << z.snapshot.mask << ",0x" << std::hex << z.scene << ",0x" << z.descriptorVt << ",0x"
              << z.sceneVt << ",0x" << z.material << std::dec;
            for (unsigned i = 0; i < 6; ++i)
                if (z.snapshot.mask & (1u << i))
                    o << " path" << path << "_attr" << i + 1 << "=" << z.snapshot.values[i][0] << ","
                      << z.snapshot.values[i][1] << "," << z.snapshot.values[i][2] << ","
                      << z.snapshot.values[i][3];
        }
        o << " premier_rebind_v12_resets=" << PremierDrawTrace::Instance().FixResets();
        const auto materialReport = PremierDrawTrace::Instance().GetGenericMaterials();
        o << " premier_group_v11=" << materialReport.groupSamples << "," << materialReport.targetFirst << ","
          << materialReport.otherFirst << "," << materialReport.failures;
        for (unsigned i = 0; i < materialReport.count; ++i) {
            const auto& m = materialReport.materials[i];
            o << " premier_material_v11=" << m.hits << ",0x" << std::hex << m.material << std::dec << ","
              << (m.name[0] ? m.name.data() : "<unreadable>");
        }
        for (unsigned i = 0; i < 6; ++i)
            if (draw.snapshot.mask & (1u << i))
                o << " draw_attr" << (i + 1) << "=" << draw.snapshot.values[i][0] << ","
                  << draw.snapshot.values[i][1] << "," << draw.snapshot.values[i][2] << ","
                  << draw.snapshot.values[i][3];
        for (unsigned i = 0; i < 6; ++i)
            if (trace.snapshot.mask & (1u << i))
                o << " trace_attr" << (i + 1) << "=" << trace.snapshot.values[i][0] << ","
                  << trace.snapshot.values[i][1] << "," << trace.snapshot.values[i][2] << ","
                  << trace.snapshot.values[i][3];
        for (unsigned i = 0; i < 6; ++i)
            if (scene.foundMask & (1u << i))
                o << " attr" << (i + 1) << "=" << scene.values[i][0] << "," << scene.values[i][1] << ","
                  << scene.values[i][2] << "," << scene.values[i][3];
        return o.str();
    }

    bool HasOfficialStickerSample() const {
        return capture_.StickerPaintSample().found;
    }
    std::string StickerPanelDiagnostic() const {
        const auto p = capture_.StickerPaintSample();
        const auto now = GetTickCount64();
        std::ostringstream o;
        o.imbue(std::locale::classic());
        o.precision(9);
        o << "found=" << p.found << " read=" << p.read << " age_ms=" << (p.at && now >= p.at ? now - p.at : 0)
          << " flags=" << unsigned(p.b810) << "," << unsigned(p.b811) << "," << unsigned(p.b812) << ","
          << unsigned(p.b830) << "," << unsigned(p.b831) << "," << unsigned(p.b844) << " f81c=" << p.f81c
          << " f820=" << p.f820 << " f824=" << p.f824 << " f828=" << p.f828 << " f838=" << p.f838
          << " modePaints=" << capture_.StickerModePaints();
        return o.str();
    }

    std::string CharmPositionDiagnostic() const {
        auto p = charmPositionProbe_.load(std::memory_order_acquire);
        float xyz[3]{};
        if (!p)
            return "Charm probe: pattern unavailable";
        if (!Bytes(p, xyz, sizeof(xyz)))
            return "Charm probe: read failed";
        if (!std::isfinite(xyz[0]) || !std::isfinite(xyz[1]) || !std::isfinite(xyz[2]))
            return "Charm probe: non-finite values";
        std::ostringstream o;
        o.imbue(std::locale::classic());
        o.precision(9);
        o << "Charm probe XYZ: " << xyz[0] << ", " << xyz[1] << ", " << xyz[2];
        return o.str();
    }
#endif
    Status State() const {
        return state_.load();
    }
    unsigned RootRevision() const {
        return rootRevision_.load(std::memory_order_acquire);
    }
    std::string Diagnostic() const {
        static const char* names[] = {
            "waiting for modules",
            "unresolved bridge",
            "bridge ready",
            "waiting for a live Panorama window root (HUD or main menu)",
            "script submitted; native player panel NOT confirmed (see game console)",
            "native CUI_Player3dPanel confirmed; model assets/rendering still require in-game verification",
            "hidden",
            "native call fault; unload deferred",
            "stopped"};
        return std::string("Native preview: ") + names[unsigned(State())] + "; root-source=" +
               (rootSource_.load() == 1   ? "HUD/window"
                : rootSource_.load() == 2 ? "menu/window"
                                          : "none") +
               "; warm-pool=4; lease-heartbeat-ms=250; native-ready-poll=every-ui-frame; "
               "root-policy=paint-probe-v2; transition-probe-ms=450; cold-probe-ms=1800; hud-candidate=" +
               std::to_string(hudCandidate_.load()) +
               "; menu-candidate=" + std::to_string(menuCandidate_.load()) + "; paint-age-ms=" +
               (paintAge_.load() == ~ULONGLONG(0) ? std::string("none") : std::to_string(paintAge_.load())) +
               "; " + detail_
#ifndef MENU_STUDIO_HUD_TEST_STUB
               + "; " + GameInventoryRarity().Stats()
#endif
            ;
    }
    void TryStart() {
#ifndef MENU_STUDIO_HUD_TEST_STUB
        PumpInventoryAssets();
#endif
        if (ready_ || closing_ || State() == Status::Fault)
            return;
        auto c = GetModuleHandleW(L"client.dll"), p = GetModuleHandleW(L"panorama.dll");
        if (!c || !p)
            return;
#ifndef MENU_STUDIO_HUD_TEST_STUB
        auto render = GetModuleHandleW(L"rendersystemdx11.dll");
        auto animation = GetModuleHandleW(L"animationsystem.dll");
        if (!render)
            return;
#endif
        if (attempted_ && seenClient_ == c && seenPanorama_ == p)
            return;
        attempted_ = true;
        seenClient_ = c;
        seenPanorama_ = p;
        WatermarkKdModule cm, pm;
        auto read = [](std::uintptr_t a, auto& x) { return Read(a, x); };
        state_ = Status::Unsupported;
        if (!WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(c), cm) ||
            !WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(p), pm)) {
            detail_ = "invalid loaded PE";
            return;
        }
        HudScanImage ci, pi;
        auto bytes = [](std::uintptr_t a, void* out, std::size_t n) { return Bytes(a, out, n); };
        if (!ci.Load(cm, bytes) || !pi.Load(pm, bytes)) {
            detail_ = "snapshot failed";
            return;
        }
        if (!ResolvePreviewBridge(ci, pi, bindings_, detail_))
            return;
#ifndef MENU_STUDIO_HUD_TEST_STUB
        {
            std::uintptr_t pos = 0;
            std::string diag;
            charm::ResolvePreviewPosition(ci, pos, diag);
            charmPositionProbe_.store(pos, std::memory_order_release);
            detail_ += "; charm-position-probe=" + diag;
        }
#endif
#ifndef MENU_STUDIO_HUD_TEST_STUB
        {
            std::string cd;
            auto lookups = ci.Find(charm::FauxLookup, true, 2);
            if (lookups.size() == 1 && charm::ResolveViewSetter(ci, charmSetter_, cd))
                charmLookup_ = lookups[0];
            else {
                charmSetter_ = 0;
                cd = "lookup or setter pattern missing/ambiguous";
            }
            detail_ += "; charm=" + cd;
        }
        {
            premierColor_ = {};
            premierModuleBase_ = cm.base;
            premierModuleEnd_ = cm.base + cm.size;
            if (premierModuleEnd_ < premierModuleBase_ || !premier_color::Resolve(ci, premierColor_)) {
                premierColor_ = {};
                detail_ += "; Premier color v1 disabled: native ABI fingerprint mismatch";
            } else
                detail_ += "; Premier color v1 ABI fingerprint matched; visual result not validated";
        }
#endif
#ifndef MENU_STUDIO_HUD_TEST_STUB
        WatermarkKdModule rm;
        HudScanImage ri;
        if (!render || !WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(render), rm) ||
            !ri.Load(rm, bytes)) {
            detail_ += "; offscreen renderer missing";
            return;
        }
        std::string offscreen;
        if (!capture_.Start(ci, pi, ri, offscreen)) {
            detail_ += "; " + offscreen;
            return;
        }
        detail_ += "; " + offscreen;
        if (premierColor_.entity) {
            std::string trace;
            premierTrace_.Start(ci, trace);
            detail_ += "; " + trace;
        }
        if (bindings_.itemVtable && !capture_.SupportsPanel(ci, bindings_.itemVtable))
            bindings_.itemVtable = 0;
        capture_.ConfigureCharmProbe(bindings_.itemVtable);
        {
            std::string live;
            charmLive_.Start(ci, bindings_.itemVtable, live);
            detail_ += "; " + live;
        }
        detail_ += bindings_.itemVtable ? "; item RTTI shares captured Paint (live output unverified)"
                                        : "; item preview disabled: no supported typed item Paint";
        icons_.Start(pi);
        detail_ += "; " + icons_.Diagnostic();
        artwork_.Start(ci, pi, ri, bindings_, c);
        detail_ += "; " + artwork_.Diagnostic();

        WatermarkKdModule am;
        HudScanImage ai;
        std::string idleDiagnostic;
        if (WatermarkKdLoadModule(read, reinterpret_cast<std::uintptr_t>(animation), am) &&
            ai.Load(am, bytes)) {
            idle_.Start(ci, ai, bindings_.playerVtable, idleDiagnostic);
            std::string selectorDiagnostic;
            selector_.Start(ci, ai, bindings_.playerVtable, selectorDiagnostic);
            idleDiagnostic += "; " + selectorDiagnostic;
        } else
            idleDiagnostic = "idle disabled: animation module snapshot failed";
        detail_ += "; " + idleDiagnostic;
#endif
        state_ = Status::Ready;
        ready_.store(true, std::memory_order_release);
    }
#ifndef MENU_STUDIO_HUD_TEST_STUB
    bool StartupArtworkReady() const {
        return ready_.load(std::memory_order_acquire) && artwork_.Ready();
    }
    bool StartupRootReady() const {
        return rootSource_.load(std::memory_order_acquire) != 0;
    }
    void PumpInventoryAssets() {
        if (!closing_)
            artwork_.PumpMetadata();
    }
    void ResetArtwork(AmbienceImageReadback& readback) {
        artwork_.ResetReadback(readback);
    }
    bool ArtworkNeedsPump(ID3D11Device* device, const AmbienceImageReadback& readback) const {
        return artwork_.NeedsPump(device, readback);
    }
    void PumpArtwork(ID3D11Device* device, ID3D11DeviceContext* context, AmbienceImageReadback& readback) {
        artwork_.Pump(device, context, readback);
    }
    std::string CaptureDiagnostic() const {
        return charmLive_.Diagnostic() + "; " + artwork_.Diagnostic() + "; " + capture_.Diagnostic() + "; " +
               idle_.Diagnostic() + "; " + selector_.Diagnostic() + "; " + icons_.Diagnostic() + "; " +
               GameInventoryRarity().Stats();
    }
    template <class Draw> bool WithFrame(Draw&& draw) {
        return capture_.WithFrame(std::forward<Draw>(draw));
    }
#endif
    bool Stop(DWORD timeout = 2000) {
        closing_ = true;
        Submit({});
#ifndef MENU_STUDIO_HUD_TEST_STUB
        charmLive_.Select(0, {});
        idle_.Select(0);
        selector_.Select(0);
        capture_.Select(0);
#endif
        if (!ready_ && !dispatched_) {
#ifndef MENU_STUDIO_HUD_TEST_STUB
            artwork_.Stop();
            const bool traceStopped = premierTrace_.Stop();
            const bool charmStopped = charmLive_.Stop();
            const bool iconsStopped = icons_.Stop();
            const bool selectorStopped = selector_.Stop();
            const bool idleStopped = idle_.Stop();
            const bool captureStopped = capture_.Stop();
            return traceStopped && charmStopped && iconsStopped && selectorStopped && idleStopped &&
                   captureStopped && State() != Status::Fault;
#else
            return State() != Status::Fault;
#endif
        }
        auto end = GetTickCount64() + timeout;
        while (!ack_ && GetTickCount64() < end)
            Sleep(10);
        if (!ack_ || State() == Status::Fault)
            return false;
#ifndef MENU_STUDIO_HUD_TEST_STUB
        artwork_.Stop();
        const bool traceStopped = premierTrace_.Stop();
        const bool charmStopped = charmLive_.Stop();
        const bool iconsStopped = icons_.Stop();
        const bool selectorStopped = selector_.Stop();
        const bool idleStopped = idle_.Stop();
        const bool captureStopped = capture_.Stop();
        return traceStopped && charmStopped && iconsStopped && selectorStopped && idleStopped &&
               captureStopped;
#else
        return true;
#endif
    }
};
}
#undef MENU_PREVIEW_TRY
#undef MENU_PREVIEW_EXCEPT
