#pragma once

#include <d3d11.h>
#include <wrl/client.h>
#include <MinHook.h>
#include <atomic>
#include <mutex>
#include "preview_offscreen_bindings.h"
#include "preview_offscreen_contract.h"
#include "preview_retired_panels.h"
#include "inventory_charm_panel_diagnostic.h"
namespace menu {
class PreviewOffscreenCapture {
    using Paint = void(__fastcall*)(void*, void*, void*, void*, float, float, float, float, void*);
    template <class T> using ComPtr = Microsoft::WRL::ComPtr<T>;
    inline static std::atomic<PreviewOffscreenCapture*> instance_{nullptr};
    enum class Stage { Waiting, Context, Attribute, Factory, View, Submitted, Fault, Stopped };
    std::atomic<Stage> stage_{Stage::Waiting};
    Paint original_ = nullptr;
    void* hook_ = nullptr;
    PreviewOffscreenBindings b_{};
    std::atomic<std::uintptr_t> selected_{0};
    PreviewRetiredPanels retired_;
    std::atomic<std::uint32_t> selectedExtent_{350u | (600u << 16)};

    std::atomic<std::uint64_t> selectionEpoch_{1}, paintEpoch_{0};
    std::atomic<ULONGLONG> paintAt_{0};
    std::atomic<unsigned> active_{0};
    std::atomic<bool> stop_{false}, fault_{false};

    std::atomic<std::uintptr_t> charmProbeVtable_{0};
    std::atomic<bool> charmProbeEnabled_{false};
    std::atomic<std::uint64_t> charmProbePacked_{0}, charmProbeAt_{0};
    std::atomic<unsigned> charmProbeTyped_{0}, charmProbeMode_{0};
    mutable std::mutex stickerProbeMutex_;
    charm::PanelDiagnostic stickerSample_{};
    std::atomic<unsigned> stickerProbeMode_{0};
    void ObserveCharmPanel(void* p, ULONGLONG now) {
        if (!charmProbeEnabled_.load(std::memory_order_relaxed))
            return;
        const auto table = charmProbeVtable_.load(std::memory_order_acquire);
        std::uintptr_t vt = 0;
        if (!table || !Read(reinterpret_cast<std::uintptr_t>(p), vt) || vt != table)
            return;
        charmProbeTyped_.fetch_add(1, std::memory_order_relaxed);
        const auto sample = charm::ReadPanelDiagnostic(
            reinterpret_cast<std::uintptr_t>(p), now,
            [](std::uintptr_t a, void* dst, std::size_t n) { return Read(a, dst, n); });

        if (sample.read && sample.b810 == 1 && sample.b811 == 0) {
            stickerProbeMode_.fetch_add(1, std::memory_order_relaxed);
            std::unique_lock<std::mutex> g(stickerProbeMutex_, std::try_to_lock);
            if (g)
                stickerSample_ = sample;
        }
        if (!sample.read || sample.b811 != 1)
            return;
        charmProbeMode_.fetch_add(1, std::memory_order_relaxed);
        const auto bits = std::uint64_t(sample.b810) | (std::uint64_t(sample.b811) << 8) |
                          (std::uint64_t(sample.b812) << 16) | (std::uint64_t(sample.b830) << 24) |
                          (std::uint64_t(sample.b831) << 32) | (std::uint64_t(sample.b844) << 40);
        charmProbePacked_.store(bits, std::memory_order_relaxed);
        charmProbeAt_.store(now, std::memory_order_release);
    }
    std::mutex mutex_;
    bool created_ = false, enabled_ = false;
    std::uintptr_t handle_ = 0, manager_ = 0;
    ComPtr<ID3D11ShaderResourceView> srv_;
    UINT textureW_ = 0, textureH_ = 0, allocatedW_ = 0, allocatedH_ = 0, publishedW_ = 0, publishedH_ = 0;
    ULONGLONG stamp_ = 0;
    std::uintptr_t publishedPanel_ = 0;
    std::uint64_t publishedEpoch_ = 0;
    static bool Read(std::uint64_t a, void* out, std::size_t n) {
        SIZE_T k = 0;
        return a && ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(a), out, n, &k) &&
               k == n;
    }
    template <class T> static bool Read(std::uintptr_t a, T& x) {
        return Read(a, &x, sizeof x);
    }
    static bool Write(std::uint64_t a, const void* in, std::size_t n) {
        __try {
            if (!a)
                return false;
            std::memcpy(reinterpret_cast<void*>(a), in, n);
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }
    static bool CreateNative(std::uintptr_t fn, std::uintptr_t device, std::uintptr_t& handle,
                             const void* desc) {
        __try {
            using Fn = std::uintptr_t*(__fastcall*)(void*, std::uintptr_t*, const char*, bool, const void*,
                                                    const void*, const void*, int, bool);
            auto out = reinterpret_cast<Fn>(fn)(reinterpret_cast<void*>(device), &handle,
                                                "MenuStudio.ModelPreview.Offscreen", true, desc, nullptr,
                                                nullptr, 0, false);
            return out == &handle && handle != 0;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }
    static bool ReleaseNative(std::uintptr_t handle, std::uintptr_t manager) {
        __try {
            auto count = reinterpret_cast<volatile LONG*>(handle + 0x20);
            if (*count <= 0)
                return false;
            if (InterlockedDecrement(count) == 0) {
                auto vt = *reinterpret_cast<std::uintptr_t*>(manager);
                using Fn = void(__fastcall*)(void*, void*);
                reinterpret_cast<Fn>(*reinterpret_cast<std::uintptr_t*>(vt + 0x10))(
                    reinterpret_cast<void*>(manager), reinterpret_cast<void*>(handle));
            }
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }
    static bool CallRedirected(Paint next, void* panel, void* iface, void* context, void* args, float a,
                               float b, float c, float d, void* extra, std::uintptr_t entry,
                               std::uintptr_t replacement, bool& restored) {
        std::uintptr_t saved = 0;
        restored = false;
        if (!Read(entry, saved) || !saved || !Write(entry, &replacement, 8))
            return false;

        __try {
            __try {
                next(panel, iface, context, args, a, b, c, d, extra);
            } __finally {
                restored = Write(entry, &saved, 8);
            }
            return restored;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }
    static bool RetainView(std::uintptr_t view, ID3D11ShaderResourceView** out) {
        __try {
            return SUCCEEDED(reinterpret_cast<IUnknown*>(view)->QueryInterface(
                       __uuidof(ID3D11ShaderResourceView), reinterpret_cast<void**>(out))) &&
                   *out;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }
    static bool RetainBaseView(std::uintptr_t view, ID3D11View** out) {
        __try {
            return SUCCEEDED(reinterpret_cast<IUnknown*>(view)->QueryInterface(
                       __uuidof(ID3D11View), reinterpret_cast<void**>(out))) &&
                   *out;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }
    bool SourceDimensions(std::uintptr_t entry, unsigned requiredW, unsigned requiredH, unsigned& w,
                          unsigned& h) {
        std::uintptr_t saved = 0, object = 0, vt = 0, view = 0;
        if (!Read(entry, saved) || !Read(saved, object) || !Read(object, vt) ||
            vt != b_.native.textureVtable || !Read(object + 0x10, view) || !view)
            return false;
        ComPtr<ID3D11View> held;
        if (!RetainBaseView(view, held.GetAddressOf()))
            return false;
        ComPtr<ID3D11Resource> resource;
        held->GetResource(&resource);
        ComPtr<ID3D11Texture2D> texture;
        if (!resource || FAILED(resource.As(&texture)))
            return false;
        D3D11_TEXTURE2D_DESC td{};
        texture->GetDesc(&td);
        if (td.ArraySize != 1 || td.SampleDesc.Count != 1 || td.Width < requiredW || td.Height < requiredH)
            return false;

        return preview_research::BackingDimension(td.Width, 4096, w) &&
               preview_research::BackingDimension(td.Height, 4096, h);
    }
    bool EnsureTarget(unsigned w, unsigned h) {
        if (handle_ && w == allocatedW_ && h == allocatedH_)
            return true;
        std::uintptr_t device = 0, vt = 0, create = 0, currentManager = 0;
        if (!Read(b_.deviceGlobal, device) || !Read(device, vt) || vt != b_.native.deviceVtable ||
            !Read(vt + b_.native.createTextureSlot, create) || create != b_.native.createTexture ||
            !Read(b_.managerGlobal, currentManager) || !currentManager)
            return false;
        if (handle_) {
            if (currentManager != manager_) {
                fault_ = true;
                return false;
            }
            stamp_ = 0;
            srv_.Reset();
            if (!ReleaseNative(handle_, manager_)) {
                fault_ = true;
                return false;
            }
            handle_ = 0;
        }
        manager_ = currentManager;
        auto desc = preview_research::ArchivedDescriptor(static_cast<std::uint16_t>(w),
                                                         static_cast<std::uint16_t>(h));
        const bool ok = CreateNative(create, device, handle_, desc.data());
        if (!ok) {
            if (handle_)
                fault_ = true;
            return false;
        }
        allocatedW_ = w;
        allocatedH_ = h;
        return true;
    }
    bool RetainTargetView(unsigned requiredW, unsigned requiredH) {
        if (srv_)
            return textureW_ >= requiredW && textureH_ >= requiredH;
        std::uintptr_t object = 0, vt = 0, view = 0;
        if (!Read(handle_, object) || !Read(object, vt) || vt != b_.native.textureVtable ||
            !Read(object + 0x10, view) || !view)
            return false;
        ComPtr<ID3D11ShaderResourceView> held;
        if (!RetainView(view, held.GetAddressOf()))
            return false;
        D3D11_SHADER_RESOURCE_VIEW_DESC sv{};
        held->GetDesc(&sv);
        if (sv.ViewDimension != D3D11_SRV_DIMENSION_TEXTURE2D || sv.Texture2D.MostDetailedMip != 0)
            return false;
        ComPtr<ID3D11Resource> res;
        held->GetResource(&res);
        ComPtr<ID3D11Texture2D> tex;
        if (!res || FAILED(res.As(&tex)))
            return false;
        D3D11_TEXTURE2D_DESC td{};
        tex->GetDesc(&td);
        if (td.Width < requiredW || td.Height < requiredH || td.ArraySize != 1 || td.SampleDesc.Count != 1)
            return false;
        textureW_ = td.Width;
        textureH_ = td.Height;
        srv_ = std::move(held);
        return true;
    }
    void Capture(void* panel, void* iface, void* context, void* args, float a, float b, float c, float d,
                 void* extra, std::uint64_t epoch, unsigned requiredW, unsigned requiredH) {

        std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
        if (!lock || stop_ || fault_ || selectionEpoch_.load(std::memory_order_acquire) != epoch ||
            selected_.load(std::memory_order_acquire) != reinterpret_cast<std::uintptr_t>(panel))
            return;
        std::uintptr_t ctx = 0, vt = 0;
        if (!Read(reinterpret_cast<std::uintptr_t>(context), ctx) || !Read(ctx, vt) ||
            std::find(b_.contextTables.begin(), b_.contextTables.end(), vt) == b_.contextTables.end()) {
            stage_ = Stage::Context;
            return;
        }
        auto reader = [](std::uint64_t at, void* p, std::size_t n) { return Read(at, p, n); };
        const auto entry =
            preview_research::FindResourceEntry(reader, ctx + 0x190, preview_research::ColorTargetId);
        if (!entry) {
            stage_ = Stage::Attribute;
            return;
        }
        unsigned backingW = 0, backingH = 0;
        if (!SourceDimensions(entry, requiredW, requiredH, backingW, backingH)) {
            stage_ = Stage::View;
            return;
        }
        if (!EnsureTarget(backingW, backingH)) {
            stage_ = fault_ ? Stage::Fault : Stage::Factory;
            return;
        }
        bool restored = false;
        if (!CallRedirected(original_, panel, iface, context, args, a, b, c, d, extra, entry, handle_,
                            restored)) {

            fault_ = true;
            stage_ = Stage::Fault;
            stamp_ = 0;
            return;
        }
        if (selectionEpoch_.load(std::memory_order_acquire) != epoch) {
            stamp_ = 0;
            return;
        }
        if (RetainTargetView(requiredW, requiredH)) {
            publishedW_ = requiredW;
            publishedH_ = requiredH;
            publishedEpoch_ = epoch;
            publishedPanel_ = reinterpret_cast<std::uintptr_t>(panel);
            stamp_ = GetTickCount64();
            stage_ = Stage::Submitted;
        } else
            stage_ = Stage::View;
    }
    static void __fastcall Detour(void* panel, void* iface, void* ctx, void* args, float a, float b, float c,
                                  float d, void* extra) {
        auto self = instance_.load(std::memory_order_acquire);
        if (!self)
            return;
        ++self->active_;
        const auto epoch = self->selectionEpoch_.load(std::memory_order_acquire);
        const auto selected = self->selected_.load(std::memory_order_acquire);
        const auto extent = self->selectedExtent_.load(std::memory_order_acquire);
        if (reinterpret_cast<std::uintptr_t>(panel) != selected || !selected) {
            self->ObserveCharmPanel(panel, GetTickCount64());

            if (!self->retired_.Contains(reinterpret_cast<std::uintptr_t>(panel), GetTickCount64()))
                self->original_(panel, iface, ctx, args, a, b, c, d, extra);
        } else if (!self->stop_)
            try {
                self->paintAt_.store(GetTickCount64(), std::memory_order_relaxed);
                self->paintEpoch_.store(epoch, std::memory_order_release);
                self->Capture(panel, iface, ctx, args, a, b, c, d, extra, epoch, extent & 0xffffu,
                              extent >> 16);
            } catch (...) {
                self->fault_ = true;
                self->stage_ = Stage::Fault;
            }

        --self->active_;
    }

public:
    void ConfigureCharmProbe(std::uintptr_t itemVtable) {
        charmProbeVtable_.store(itemVtable, std::memory_order_release);
    }
    void EnableCharmProbe(bool enabled) {
        charmProbeEnabled_.store(enabled, std::memory_order_release);
    }
    charm::PanelDiagnostic CharmPaintSample() const {
        charm::PanelDiagnostic out{};
        const auto at = charmProbeAt_.load(std::memory_order_acquire);
        const auto now = GetTickCount64();
        if (!at || now < at || now - at > 500)
            return out;
        const auto bits = charmProbePacked_.load(std::memory_order_relaxed);
        out.found = true;
        out.read = true;
        out.at = at;
        out.b810 = static_cast<unsigned char>(bits);
        out.b811 = static_cast<unsigned char>(bits >> 8);
        out.b812 = static_cast<unsigned char>(bits >> 16);
        out.b830 = static_cast<unsigned char>(bits >> 24);
        out.b831 = static_cast<unsigned char>(bits >> 32);
        out.b844 = static_cast<unsigned char>(bits >> 40);
        return out;
    }
    unsigned CharmTypedPaints() const {
        return charmProbeTyped_.load(std::memory_order_relaxed);
    }
    unsigned CharmModePaints() const {
        return charmProbeMode_.load(std::memory_order_relaxed);
    }
    charm::PanelDiagnostic StickerPaintSample() const {
        std::lock_guard<std::mutex> g(stickerProbeMutex_);
        auto s = stickerSample_;
        const auto now = GetTickCount64();
        if (!s.at || now < s.at || now - s.at > 500)
            return {};
        return s;
    }
    unsigned StickerModePaints() const {
        return stickerProbeMode_.load(std::memory_order_relaxed);
    }
    bool Start(const HudScanImage& c, const HudScanImage& p, const HudScanImage& r, std::string& diagnostic) {
        if (created_)
            return enabled_;
        if (!ResolvePreviewOffscreen(c, p, r, b_, diagnostic))
            return false;
        hook_ = reinterpret_cast<void*>(b_.native.paint);
        instance_ = this;
        auto status =
            MH_CreateHook(hook_, reinterpret_cast<void*>(Detour), reinterpret_cast<void**>(&original_));
        if (status != MH_OK) {
            diagnostic += "; capture hook creation failed";
            return false;
        }
        created_ = true;
        status = MH_EnableHook(hook_);
        if (status != MH_OK) {
            if (MH_RemoveHook(hook_) == MH_OK) {
                created_ = false;
                instance_ = nullptr;
            }
            diagnostic += "; capture hook enabling failed";
            return false;
        }
        enabled_ = true;
        return true;
    }
    bool SupportsPanel(const HudScanImage& client, std::uintptr_t table) const {
        std::uintptr_t paint = 0;
        return table && client.Read(table + b_.native.paintSlot, paint) && paint == b_.native.paint;
    }
    void Select(std::uintptr_t panel, unsigned width = 350, unsigned height = 600) {
        if (!width || !height || width > 4096 || height > 4096) {
            panel = 0;
            width = 350;
            height = 600;
        }
        const auto extent = std::uint32_t(width | (height << 16));
        if (selected_.load(std::memory_order_acquire) == panel &&
            selectedExtent_.load(std::memory_order_acquire) == extent)
            return;
        const auto old = selected_.load(std::memory_order_acquire);
        if (old && old != panel)
            retired_.Retire(old, GetTickCount64());
        selected_.store(0, std::memory_order_release);
        selectionEpoch_.fetch_add(1, std::memory_order_acq_rel);
        selectedExtent_.store(extent, std::memory_order_release);
        selected_.store(panel, std::memory_order_release);
    }
    ULONGLONG LastSelectedPaint() const {
        auto epoch = selectionEpoch_.load(std::memory_order_acquire);
        if (!selected_.load(std::memory_order_acquire) ||
            paintEpoch_.load(std::memory_order_acquire) != epoch)
            return 0;
        auto at = paintAt_.load(std::memory_order_relaxed);
        return selectionEpoch_.load(std::memory_order_acquire) == epoch ? at : 0;
    }
    bool Started() const {
        return enabled_ && !stop_ && !fault_;
    }
    bool Faulted() const {
        return fault_;
    }
    std::string Diagnostic() const {
        static const char* text[] = {"waiting for this preview panel Paint",
                                     "unsupported render context",
                                     "color resource attribute not found",
                                     "engine target allocation unavailable",
                                     "waiting for target SRV",
                                     "Paint submitted to own target; GPU output/alpha not runtime-validated",
                                     "native capture fault; unload blocked",
                                     "stopped"};
        return std::string("Offscreen preview: ") + text[unsigned(stage_.load())];
    }

    template <class Draw> bool WithFrame(Draw&& draw) {
        std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
        if (!lock)
            return false;
        auto now = GetTickCount64();
        if (!Started() || !srv_ || !stamp_ || now < stamp_ || now - stamp_ > 500 || !selected_ ||
            publishedPanel_ != selected_.load(std::memory_order_acquire) ||
            publishedEpoch_ != selectionEpoch_.load(std::memory_order_acquire))
            return false;
        return draw(srv_.Get(), std::array<float, 4>{0, 0, float(publishedW_) / textureW_,
                                                     float(publishedH_) / textureH_});
    }
    bool Stop() {
        stop_ = true;
        if (fault_)
            return false;
        if (enabled_) {
            auto s = MH_DisableHook(hook_);
            if (s != MH_OK && s != MH_ERROR_DISABLED)
                return false;
            enabled_ = false;
        }
        auto end = GetTickCount64() + 2000;
        while (active_ && GetTickCount64() < end)
            Sleep(1);
        if (active_)
            return false;
        Sleep(100);
        if (active_)
            return false;
        std::lock_guard<std::mutex> lock(mutex_);
        stamp_ = 0;
        srv_.Reset();
        if (handle_) {
            std::uintptr_t manager = 0;
            if (!Read(b_.managerGlobal, manager) || manager != manager_ || !ReleaseNative(handle_, manager_))
                return false;
            handle_ = 0;
        }
        if (created_) {
            if (MH_RemoveHook(hook_) != MH_OK)
                return false;
            created_ = false;
        }
        instance_ = nullptr;
        stage_ = Stage::Stopped;
        return true;
    }
};
}
