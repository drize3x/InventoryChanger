#pragma once
#include "watermark_hud_patterns.h"
namespace menu {
namespace preview_icon_patterns {

inline constexpr char SetSvg[] = "40 55 53 56 57 41 56 41 57 48 8D AC 24 08 FF FF FF 48 81 EC F8 01 00 00 48 "
                                 "8B DA 4D 8B F0 48 8B 51 40 48 8B F1 48 85 DB 0F 84 ? ? ? ? 48 85 D2";
inline constexpr char Rasterize[] =
    "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 48 89 7C 24 20 41 54 41 56 41 57 48 83 EC 40 4C 8B B4 24 "
    "88 00 00 00 49 8B F9 0F 29 74 24 30 49 8B F0 F3 0F 10 B4 24 80 00 00 00 48 8B EA 4C 8B E1";
inline constexpr char RasterCall[] =
    "F3 41 0F 10 46 18 49 8D 46 1C 48 8B 4B 10 4C 8D 8D 38 01 00 00 48 89 44 24 28 4C 8D 85 30 01 00 00 48 "
    "8D 55 90 F3 0F 11 44 24 20 E8 ? ? ? ? 44 0F B6 F8";
inline constexpr char ImplCall[] =
    "4C 89 20 48 8B C8 45 33 E4 4C 89 60 10 4C 89 60 18 44 89 60 08 4C 89 60 20 4C 89 60 28 E8 ? ? ? ?";
inline constexpr char Buffer[] =
    "F7 45 04 FF FF FF 7F 75 04 33 C9 EB 04 48 8B 4D 08 4C 63 C3 33 D2 E8 ? ? ? ?";
inline constexpr char SourceName[] =
    "48 8B 46 40 4C 8D 35 ? ? ? ? 89 7D 10 48 89 7D 18 C7 45 14 C8 00 00 C0 48 89 BD E0 00 00 00 48 89 BD E8 "
    "00 00 00 48 85 C0 74 ? 48 8B 40 08 48 85 C0 74 ? 48 8B 00";
}
struct PreviewIconBindings {
    std::uintptr_t setSvg = 0, rasterize = 0;
};
inline bool ResolvePreviewIconBindings(const HudScanImage& pano, PreviewIconBindings& out,
                                       std::string& diagnostic) {
    out = {};
    PreviewIconBindings b;
    std::ostringstream log;
    auto unique = [&](const char* name, const char* pat, std::uintptr_t& fn) {
        auto hits = pano.Find(pat, true, 2);
        log << name << "=" << hits.size() << "; ";
        if (hits.size() != 1)
            return false;
        fn = hits[0];
        return true;
    };
    std::uintptr_t call = 0, buffer = 0, name = 0, implCall = 0;
    if (!unique("SetSvg", preview_icon_patterns::SetSvg, b.setSvg) ||
        !unique("Rasterize", preview_icon_patterns::Rasterize, b.rasterize) ||
        !unique("RasterCall", preview_icon_patterns::RasterCall, call) ||
        !unique("ImplCall", preview_icon_patterns::ImplCall, implCall) ||
        !unique("Buffer", preview_icon_patterns::Buffer, buffer) ||
        !unique("SourceName", preview_icon_patterns::SourceName, name)) {
        diagnostic = log.str() + "icons disabled: unsupported/ambiguous signature";
        return false;
    }

    auto impl = pano.Rip(implCall + HudPattern(preview_icon_patterns::ImplCall).size() - 5, 1, 5);
    auto displacement = HudPattern(preview_icon_patterns::RasterCall).size() - 9;
    if (call < b.setSvg || call - b.setSvg > 0x1000 || pano.Rip(call + displacement, 1, 5) != b.rasterize ||
        name < b.setSvg || name - b.setSvg > 0x1000 || implCall < b.rasterize ||
        implCall - b.rasterize > 0x300 || !impl || !pano.Contains(impl, 1, 0x20000000) || buffer < impl ||
        buffer - impl > 0x1000) {
        diagnostic = log.str() + "icons disabled: call/ABI relationship mismatch";
        return false;
    }
    out = b;
    diagnostic = log.str() + "Panorama SVG capture resolved (live output not verified)";
    return true;
}
}
