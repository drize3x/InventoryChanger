#pragma once

#include <array>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <unordered_set>
namespace preview_research {
constexpr std::uint32_t ColorTargetId = 0x6feb9f15;
using Descriptor = std::array<std::uint8_t, 0x78>;
template <class T> void Put(Descriptor& d, std::size_t off, T x) {
    std::memcpy(d.data() + off, &x, sizeof x);
}
inline Descriptor ArchivedDescriptor(std::uint16_t w, std::uint16_t h) {
    Descriptor d{};
    Put(d, 0, w);
    Put(d, 2, h);
    Put(d, 4, std::uint32_t{0x10001});
    Put(d, 0x10, std::uint32_t{9});
    Put(d, 0x3c, 1.f);
    Put(d, 0x40, 1.f);
    Put(d, 0x44, 1.f);
    Put(d, 0x50, std::uint32_t{4});
    return d;
}

inline bool BackingDimension(unsigned n, unsigned cap, unsigned& out) {
    if (!n || n > 0x7fff - 31)
        return false;
    out = (n + 31) & ~31u;
    if (out < 32)
        out = 32;
    return out <= cap;
}
struct Geometry {
    int width, height;
    float halfWidth, halfHeight;
};
inline Geometry OriginalGeometry(float bboxWidth) {
    if (!std::isfinite(bboxWidth) || bboxWidth <= 0 || bboxWidth > 1000000.f)
        return {};
    const float x = bboxWidth * 1.4f;
    const int w = static_cast<int>(x);
    const int h = static_cast<int>((600.f / 350.f) * x);
    return {w, h, w * .5f, static_cast<float>(static_cast<int>(h * .5f))};
}

template <class Read>
std::uint64_t FindResourceEntry(Read read, std::uint64_t table, std::uint32_t id, unsigned maxNodes = 64) {
    std::unordered_set<std::uint64_t> seen;
    unsigned used = 0;
    auto node = [&](std::uint64_t p) -> bool { return p && used++ < maxNodes && seen.insert(p).second; };
    while (table) {
        if (!node(table))
            return 0;
        std::array<std::uint32_t, 8> ids{};
        if (!read(table, ids.data(), sizeof ids))
            return 0;
        for (unsigned i = 0; i < 8; ++i)
            if (ids[i] == id)
                return table + 0x20 + 16 * i;
        std::uint64_t overflow = 0;
        if (!read(table + 0xa8, &overflow, 8))
            return 0;
        while (overflow) {
            if (!node(overflow) || !read(overflow + 0x10, ids.data(), sizeof ids))
                return 0;
            for (unsigned i = 0; i < 8; ++i)
                if (ids[i] == id)
                    return overflow + 0x30 + 16 * i;
            if (!read(overflow, &overflow, 8))
                return 0;
        }
        if (!read(table + 0xa0, &table, 8))
            return 0;
    }
    return 0;
}

template <class Read, class Write> class TargetScope {
    Read read_;
    Write write_;
    std::uint64_t at_ = 0, old_ = 0;
    bool active_ = false;

public:
    TargetScope(Read r, Write w) : read_(r), write_(w) {}
    TargetScope(const TargetScope&) = delete;
    TargetScope& operator=(const TargetScope&) = delete;
    bool Install(std::uint64_t at, std::uint64_t replacement) {
        if (active_ || !at || !replacement || !read_(at, &old_, 8) || !old_)
            return false;
        at_ = at;
        active_ = write_(at_, &replacement, 8);
        return active_;
    }
    bool Restore() {
        if (!active_)
            return true;
        if (!write_(at_, &old_, 8))
            return false;
        active_ = false;
        return true;
    }
    ~TargetScope() {
        Restore();
    }
};
}
