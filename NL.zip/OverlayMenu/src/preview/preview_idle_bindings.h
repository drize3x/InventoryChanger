#pragma once
#include "watermark_hud_patterns.h"
#include "preview_idle_owner.h"
namespace menu {
namespace preview_idle_patterns {
inline constexpr char Reset[] =
    "40 53 48 83 EC 20 48 8B D9 48 8B 89 E0 00 00 00 48 85 C9 74 ? 48 0F BF 83 E8 00 00 00 66 85 C0";
inline constexpr char Refresh[] =
    "48 83 EC 28 48 8B 05 ? ? ? ? 4C 8B C9 48 8B 49 08 F3 0F 10 40 30 B8 D3 4D 62 10";
inline constexpr char FloatSetter[] =
    "F3 41 0F 10 08 4C 8B C9 F3 0F 10 05 ? ? ? ? 0F 2F C1 73 ? 0F 2F 0D ? ? ? ? 73 ? 0F 2E C9";
inline constexpr char SeedBinding[] =
    "48 8D 0D ? ? ? ? 48 8D 05 ? ? ? ? 89 73 68 48 89 03 FF 15 ? ? ? ? 48 89 83 C0 00 00 00";
inline constexpr char ResetCall[] =
    "48 8B 8B B8 37 00 00 E8 ? ? ? ? 48 8B CB E8 ? ? ? ? 48 8B C8 48 8B 10 FF 92 D0 00 00 00 3C 02";
inline constexpr char PanelRecord[] =
    "48 63 86 EC 08 00 00 48 8D 3D ? ? ? ? 48 8D 0C 80 48 8B 86 F8 08 00 00 48 C1 E1 05 44 88 64 01 61 48 63 "
    "86 EC 08 00 00 48 8D 0C 80 48 8B 86 F8 08 00 00 48 C1 E1 05 8B 14 01 83 FA FF 0F 84 ? ? ? ? 4C 8B 0D ? "
    "? ? ? 4D 85 C9";
inline constexpr char RecordCount[] = "48 63 DA 4C 8B D1 3B 99 F0 08 00 00";
inline constexpr char ResetSeed[] = "48 8B 8B C8 00 00 00 F3 0F 58 C8 F3 0F 11 4C 24 30 48 85 C9 74 ? 0F B7 "
                                    "93 D0 00 00 00 66 85 D2 78 ? 4C 8D 44 24 30 E8 ? ? ? ?";
inline constexpr char RefreshSeed[] = "49 8B 89 C8 00 00 00 F3 0F 58 C8 F3 0F 11 4C 24 30 48 85 C9 74 ? 41 "
                                      "0F B7 91 D0 00 00 00 66 85 D2 78 ? 4C 8D 44 24 30 E8 ? ? ? ?";
}
struct PreviewIdleBindings {
    PreviewIdleOwnerTypes types;
    std::uintptr_t reset = 0, refresh = 0, setFloat = 0;
};

inline bool ResolvePreviewModelOwnerTypes(const HudScanImage& c, std::uintptr_t playerVtable,
                                          PreviewIdleOwnerTypes& result, std::string& diagnostic) {
    result = {};
    PreviewIdleOwnerTypes t;
    std::ostringstream log;
    auto fail = [&](const char* why) {
        diagnostic = log.str() + "preview model owner unavailable: " + why;
        return false;
    };
    auto panel = c.Vtables(".?AVCUI_Player3dPanel@@"), entity = c.Vtables(".?AVC_CSGO_PreviewPlayer@@");
    if (!playerVtable || panel.size() != 1 || panel[0] != playerVtable || entity.size() != 1)
        return fail("typed panel/entity");
    auto record = c.Find(preview_idle_patterns::PanelRecord, true, 2),
         count = c.Find(preview_idle_patterns::RecordCount, true, 2);
    log << "panel-record=" << record.size() << "; record-count=" << count.size() << "; ";
    if (record.size() != 1 || count.size() != 1)
        return fail("panel record layout");
    t.panelVtable = playerVtable;
    t.entityVtable = entity[0];
    t.entitySystemGlobal = c.Rip(record[0] + 0x44);
    if (!c.Contains(t.entitySystemGlobal, 8, 0x80000000, 0x20000000))
        return fail("entity-system global");
    result = t;
    diagnostic = log.str() + "client-only preview model owner ABI verified";
    return true;
}
inline bool ResolvePreviewIdleBindings(const HudScanImage& c, const HudScanImage& a,
                                       std::uintptr_t playerVtable, PreviewIdleBindings& result,
                                       std::string& diagnostic) {
    result = {};
    PreviewIdleBindings b;
    b.types.panelVtable = playerVtable;
    std::ostringstream log;
    auto fail = [&](const char* why) {
        diagnostic = log.str() + " idle disabled: " + why;
        return false;
    };
    auto table = [&](const HudScanImage& im, const char* name, std::uintptr_t& v) {
        auto hits = im.Vtables(name);
        if (hits.size() != 1)
            return false;
        v = hits[0];
        return true;
    };
    auto unique = [&](const char* name, const char* pattern, std::uintptr_t& v) {
        auto hits = c.Find(pattern, true, 2);
        log << name << "=" << hits.size() << "; ";
        if (hits.size() != 1)
            return false;
        v = hits[0];
        return true;
    };
    if (!playerVtable || !table(c, ".?AVC_CSGO_PreviewPlayer@@", b.types.entityVtable) ||
        !table(c, ".?AVCCS2UIPawnGraphController@@", b.types.controllerVtable) ||
        !table(a, ".?AVCNmControlParameterFloatNode@@", b.types.floatVtable))
        return fail("typed classes");
    std::uintptr_t actualPanel = 0;
    if (!table(c, ".?AVCUI_Player3dPanel@@", actualPanel) || actualPanel != playerVtable)
        return fail("panel type");
    if (!unique("reset", preview_idle_patterns::Reset, b.reset) ||
        !unique("refresh", preview_idle_patterns::Refresh, b.refresh) ||
        !unique("float-setter", preview_idle_patterns::FloatSetter, b.setFloat))
        return fail("code signatures");
    if (c.VirtualMatches(b.types.controllerVtable, b.refresh) != 1)
        return fail("typed seed-refresh method");
    std::uintptr_t call = 0, record = 0, count = 0, tail = 0;
    auto bindings = c.Find(preview_idle_patterns::SeedBinding, true, 16);
    unsigned seedMatches = 0;
    for (auto hit : bindings)
        if (c.Text(c.Rip(hit), "animation_seed") && c.Rip(hit + 7) == b.types.controllerVtable) {
            ++seedMatches;
        }
    log << "typed seed-binding=" << seedMatches << "; ";
    if (bindings.size() >= 16 || seedMatches != 1)
        return fail("animation_seed binding");
    if (!unique("reset-call", preview_idle_patterns::ResetCall, call) || c.Rip(call + 7, 1, 5) != b.reset)
        return fail("preview controller/reset edge");
    if (!unique("panel-record", preview_idle_patterns::PanelRecord, record) ||
        !unique("record-count", preview_idle_patterns::RecordCount, count))
        return fail("panel record layout");
    b.types.entitySystemGlobal = c.Rip(record + 0x44);
    if (!c.Contains(b.types.entitySystemGlobal, 8, 0x80000000, 0x20000000))
        return fail("entity-system global");
    if (!unique("reset-seed", preview_idle_patterns::ResetSeed, tail) || tail < b.reset ||
        tail - b.reset > 0x400 || c.Rip(tail + 39, 1, 5) != b.setFloat)
        return fail("reset seed setter edge");
    if (!unique("refresh-seed", preview_idle_patterns::RefreshSeed, tail) || tail < b.refresh ||
        tail - b.refresh > 0xc0 || c.Rip(tail + 40, 1, 5) != b.setFloat)
        return fail("refresh seed setter edge");

    std::uintptr_t getter = 0;
    if (!a.Read(b.types.floatVtable + 0x48, getter) || !a.Contains(getter, 1, 0x20000000))
        return fail("float value-node ABI");
    result = b;
    diagnostic = log.str() + "idle bindings verified as data; runtime clip NOT verified";
    return true;
}
}
