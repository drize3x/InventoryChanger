#pragma once
#include "players_preview_icons.h"
#include "players_preview_icon_patterns.h"
#ifndef MENU_STUDIO_ICON_NATIVE_TEST
#include <Windows.h>
#include <MinHook.h>
#endif
#include <atomic>
namespace menu {
class PanoramaPreviewIcons {
    using SetSvg = bool(__fastcall*)(void*, void*, void*);
    using Rasterize = bool(__fastcall*)(void*, void*, int*, int*, float, void*);
    inline static std::atomic<PanoramaPreviewIcons*> self_{nullptr};
    inline static SetSvg setPass_ = nullptr;
    inline static Rasterize rasterPass_ = nullptr;
    inline static thread_local int context_ = -1;
    void* hooks_[2]{};
    bool created_[2]{}, enabled_[2]{};
    std::atomic<bool> ready_{false}, stopping_{false};
    std::atomic<unsigned> active_{0}, captured_{0};
    std::string detail_ = "icons not initialized";
    mutable std::mutex detailMutex_;
    void AddDetail(const char* text) {
        std::lock_guard<std::mutex> l(detailMutex_);
        detail_ += text;
    }
    static bool Bytes(std::uintptr_t at, void* out, std::size_t n) {
        SIZE_T k = 0;
        return at && ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(at), out, n, &k) &&
               k == n;
    }
    template <class T> static bool Read(std::uintptr_t at, T& x) {
        return Bytes(at, &x, sizeof x);
    }
    static int Source(void* source) noexcept {
        try {

            std::uintptr_t holder = 0, path = 0;
            auto at = reinterpret_cast<std::uintptr_t>(source);
            if (!Read(at + 8, holder) || !holder || !Read(holder, path) || !path)
                return -1;
            char text[1025]{};
            for (unsigned i = 0; i < 1024; ++i) {
                if (!Read(path + i, text[i]))
                    return -1;
                if (!text[i])
                    return LiveEquipmentIconFromPath(text);
            }
            return -1;
        } catch (...) {
            return -1;
        }
    }
    void Capture(int key, void* buffer, int* width, int* height) noexcept {
        if (key < 0 || stopping_ || !ready_)
            return;
        try {
            int w = 0, h = 0, count = 0;
            std::uint32_t capacity = 0;
            std::uintptr_t data = 0, at = reinterpret_cast<std::uintptr_t>(buffer);
            if (!Read(reinterpret_cast<std::uintptr_t>(width), w) ||
                !Read(reinterpret_cast<std::uintptr_t>(height), h) || w < 1 || h < 1 || w > 512 || h > 512 ||
                !Read(at, count) || !Read(at + 4, capacity) || !Read(at + 8, data))
                return;
            const auto size = std::size_t(w) * std::size_t(h) * 4;
            if (count < 0 || std::size_t(count) < size || (capacity & 0x7fffffff) < size)
                return;
            if (GamePreviewIcons().Capture(unsigned(key), w, h,
                                           [&](void* out, std::size_t n) { return Bytes(data, out, n); }))
                ++captured_;
        } catch (...) {
        }
    }
    static bool __fastcall SetHook(void* object, void* source, void* params) {
        auto* self = self_.load(std::memory_order_acquire);
        if (!self)
            return setPass_(object, source, params);
        ++self->active_;
        const int previous = context_;
        context_ = (self->ready_ && !self->stopping_) ? Source(source) : -1;
        bool result = false;
#ifdef MENU_STUDIO_ICON_NATIVE_TEST
        try {
            result = setPass_(object, source, params);
        } catch (...) {
            context_ = previous;
            --self->active_;
            throw;
        }
        context_ = previous;
        --self->active_;
#else
        __try {
            result = setPass_(object, source, params);
        } __finally {
            context_ = previous;
            --self->active_;
        }
#endif
        return result;
    }
    static bool __fastcall RasterHook(void* svg, void* buffer, int* w, int* h, float scale, void* options) {
        auto* self = self_.load(std::memory_order_acquire);
        if (!self)
            return rasterPass_(svg, buffer, w, h, scale, options);
        ++self->active_;
        bool result = false;
#ifdef MENU_STUDIO_ICON_NATIVE_TEST
        try {
            result = rasterPass_(svg, buffer, w, h, scale, options);
            if (result)
                self->Capture(context_, buffer, w, h);
        } catch (...) {
            --self->active_;
            throw;
        }
        --self->active_;
#else
        __try {
            result = rasterPass_(svg, buffer, w, h, scale, options);
            if (result)
                self->Capture(context_, buffer, w, h);
        } __finally {
            --self->active_;
        }
#endif
        return result;
    }
    bool StartResolved(const PreviewIconBindings& b) {
        if (ready_)
            return true;
        if (created_[0] || created_[1] || self_.load())
            return false;
        stopping_ = false;
        hooks_[0] = reinterpret_cast<void*>(b.setSvg);
        hooks_[1] = reinterpret_cast<void*>(b.rasterize);
        self_ = this;
        void* detours[2] = {reinterpret_cast<void*>(SetHook), reinterpret_cast<void*>(RasterHook)};
        void* pass[2]{};
        for (unsigned i = 0; i < 2; ++i) {
            if (MH_CreateHook(hooks_[i], detours[i], &pass[i]) != MH_OK) {
                AddDetail("; create hook failed");
                Stop();
                return false;
            }
            created_[i] = true;
        }
        setPass_ = reinterpret_cast<SetSvg>(pass[0]);
        rasterPass_ = reinterpret_cast<Rasterize>(pass[1]);
        for (unsigned i = 0; i < 2; ++i) {
            if (MH_EnableHook(hooks_[i]) != MH_OK) {
                AddDetail("; enable hook failed");
                Stop();
                return false;
            }
            enabled_[i] = true;
        }
        ready_ = true;
        return true;
    }

public:
    bool Start(const HudScanImage& pano) {
        PreviewIconBindings b;
        std::string diagnostic;
        bool resolved = ResolvePreviewIconBindings(pano, b, diagnostic);
        {
            std::lock_guard<std::mutex> l(detailMutex_);
            detail_ = std::move(diagnostic);
        }
        if (!resolved)
            return false;
        return StartResolved(b);
    }
#ifdef MENU_STUDIO_ICON_NATIVE_TEST
    bool TestStart(const PreviewIconBindings& b) {
        return StartResolved(b);
    }
    static bool TestSet(void* object, void* source, void* params) {
        return SetHook(object, source, params);
    }
    static bool TestRaster(void* svg, void* buffer, int* w, int* h, float scale, void* options) {
        return RasterHook(svg, buffer, w, h, scale, options);
    }
    unsigned TestActive() const {
        return active_.load();
    }
#endif
    bool Ready() const {
        return ready_.load(std::memory_order_acquire);
    }
    std::string Diagnostic() const {
        std::lock_guard<std::mutex> l(detailMutex_);
        return detail_ + "; copied=" + std::to_string(captured_.load());
    }
    bool Stop() {
        stopping_ = true;
        ready_ = false;
        bool ok = true;
        for (unsigned i = 0; i < 2; ++i)
            if (enabled_[i]) {
                auto r = MH_DisableHook(hooks_[i]);
                if (r == MH_OK || r == MH_ERROR_DISABLED)
                    enabled_[i] = false;
                else
                    ok = false;
            }
        if (!ok)
            return false;
        auto end = GetTickCount64() + 2000;
        while (active_ && GetTickCount64() < end)
            Sleep(1);
        if (active_)
            return false;
        if (created_[0] || created_[1]) {
            Sleep(100);
            if (active_)
                return false;
        }
        for (unsigned i = 0; i < 2; ++i)
            if (created_[i]) {
                if (MH_RemoveHook(hooks_[i]) != MH_OK)
                    return false;
                created_[i] = false;
            }
        if (self_.load() == this)
            self_ = nullptr;
        return true;
    }
};
}
