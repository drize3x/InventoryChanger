#pragma once
#include "menu_core.h"
#include "equipment_icon_catalog.h"
#include <mutex>
namespace menu {

enum class PreviewIcon : unsigned { SSG08, C4, Defuser, Taser, Flash, Smoke, HE, Molotov, Incendiary, Count };
inline constexpr std::array<const char*, 9> PreviewIconNames{
    {"ssg08", "c4", "defuser", "taser", "flashbang", "smokegrenade", "hegrenade", "molotov", "incgrenade"}};
inline int LiveEquipmentIconIndex(const std::string& name) {
    for (std::size_t i = 0; i < LiveEquipmentIconCount; ++i)
        if (name == LiveEquipmentIconNames[i])
            return int(i);
    return -1;
}
inline bool LiveEquipmentIsGrenade(int i) {
    return (i >= 4 && i <= 8) || i == 45 || i == 49;
}
inline int LiveEquipmentIconFromPath(std::string path) {
    if (path.size() > 1024)
        return -1;
    for (char& c : path) {
        if (c == '\\')
            c = '/';
        else if (c >= 'A' && c <= 'Z')
            c = char(c - 'A' + 'a');
    }
    const std::string prefix = "/icons/equipment/";
    auto at = path.rfind(prefix);
    if (at == std::string::npos)
        return -1;
    auto file = path.substr(at + prefix.size());
    if (file.find('/') != std::string::npos)
        return -1;
    for (const char* ext : {".svg_c", ".vsvg_c", ".svg", ".vsvg"}) {
        std::string suffix = ext;
        if (file.size() > suffix.size() &&
            file.compare(file.size() - suffix.size(), suffix.size(), suffix) == 0)
            return LiveEquipmentIconIndex(file.substr(0, file.size() - suffix.size()));
    }
    return -1;
}
inline int PreviewIconFromPath(std::string path) {
    if (path.size() > 1024)
        return -1;
    for (char& c : path) {
        if (c == '\\')
            c = '/';
        else if (c >= 'A' && c <= 'Z')
            c = char(c - 'A' + 'a');
    }
    const std::string prefix = "/icons/equipment/";
    auto p = path.rfind(prefix);
    if (p == std::string::npos)
        return -1;
    auto name = path.substr(p + prefix.size());
    if (name.find('/') != std::string::npos)
        return -1;
    for (unsigned i = 0; i < PreviewIconNames.size(); ++i) {
        auto n = std::string(PreviewIconNames[i]);
        if (name == n + ".svg" || name == n + ".svg_c" || name == n + ".vsvg" || name == n + ".vsvg_c")
            return int(i);
    }
    return -1;
}

class PreviewIconStore {
    std::mutex mutex_;
    std::array<std::shared_ptr<const Canvas>, LiveEquipmentIconCount> images_{};

public:
    bool Has(unsigned i) {
        std::lock_guard<std::mutex> l(mutex_);
        return i < images_.size() && bool(images_[i]);
    }
    std::shared_ptr<const Canvas> Get(unsigned i) {
        std::lock_guard<std::mutex> l(mutex_);
        return i < images_.size() ? images_[i] : nullptr;
    }
    template <class Copy> bool Capture(unsigned i, int w, int h, Copy&& copy) {
        if (i >= images_.size() || w <= 0 || h <= 0 || w > 512 || h > 512 || Has(i))
            return false;
        auto image = std::make_shared<Canvas>(w, h);
        if (!copy(image->rgba.data(), image->rgba.size()))
            return false;

        for (std::size_t k = 0; k < image->rgba.size(); k += 4)
            image->rgba[k] = image->rgba[k + 1] = image->rgba[k + 2] = image->rgba[k + 3];
        std::lock_guard<std::mutex> l(mutex_);
        if (images_[i])
            return false;
        images_[i] = std::move(image);
        return true;
    }
};
inline PreviewIconStore& GamePreviewIcons() {
    static PreviewIconStore store;
    return store;
}
}
