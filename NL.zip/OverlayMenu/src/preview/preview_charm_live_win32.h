#pragma once

#include <atomic>
#include <mutex>
#include <MinHook.h>
#include <Windows.h>
#include "inventory_charm_input_pattern.h"
#include "inventory_decorations.h"
#include "inventory_sticker_native_patterns.h"
namespace menu {
class PreviewCharmLive {
    using Think = void(__fastcall*)(void*);
    inline static std::atomic<PreviewCharmLive*> instance_{nullptr};
    inline static Think pass_ = nullptr;
    void* hook_ = nullptr;
    Think original_ = nullptr;
    bool created_ = false, enabled_ = false;
    std::atomic<bool> ready_{false}, stopping_{false};
    std::atomic<unsigned> active_{0};
    std::atomic<unsigned long long> calls_{0}, writes_{0}, stickerWrites_{0}, stickerRestoreFailures_{0};
    std::mutex lock_;
    std::uintptr_t selected_ = 0, position_ = 0, vtable_ = 0, stickerSlotGlobal_ = 0,
                   stickerSurfaceGlobal_ = 0;
    int stickerSlot_ = -1;
    bool stickerDragging_ = false;
    local_decorations::Sticker sticker_{};
    ULONGLONG selectedAt_ = 0;
    float xyz_[3]{};
    struct Snapshot {
        std::uintptr_t panel = 0, position = 0, vtable = 0;
        ULONGLONG at = 0;
        float xyz[3]{};
        std::uintptr_t slotGlobal = 0;
        int slot = -1;
        bool dragging = false;
        local_decorations::Sticker sticker{};
    };
    Snapshot Get() {
        std::lock_guard<std::mutex> g(lock_);
        Snapshot s;
        s.panel = selected_;
        s.position = position_;
        s.vtable = vtable_;
        s.at = selectedAt_;
        s.slot = stickerSlot_;
        s.dragging = stickerDragging_;
        s.slotGlobal = stickerSlotGlobal_;
        s.sticker = sticker_;
        for (int i = 0; i < 3; i++)
            s.xyz[i] = xyz_[i];
        return s;
    }
    static bool Read(std::uintptr_t p, void* out, std::size_t n) {
        SIZE_T k = 0;
        return p && ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<void*>(p), out, n, &k) && k == n;
    }
    static bool Write(std::uintptr_t p, const void* in, std::size_t n) {
        SIZE_T k = 0;
        return p && WriteProcessMemory(GetCurrentProcess(), reinterpret_cast<void*>(p), in, n, &k) && k == n;
    }
    bool Apply(void* object) {
        if (stopping_ || !ready_)
            return false;
        const auto s = Get();
        const auto now = GetTickCount64();
        if (!s.panel || reinterpret_cast<std::uintptr_t>(object) != s.panel || !s.position || !s.at ||
            now < s.at || now - s.at > 350)
            return false;
        std::uintptr_t vt = 0;
        if (!Read(s.panel, &vt, sizeof(vt)) || vt != s.vtable)
            return false;
        if (s.slot >= 0 && s.slot < 5 && s.slotGlobal && s.sticker.id > 0) {
            unsigned char mode = 0;
            if (!Read(s.panel + 0x810, &mode, 1) || mode != 1)
                return false;

            int oldKit = 0;
            if (!Read(s.panel + 0x988, &oldKit, sizeof oldKit))
                return false;
            const unsigned char zero = 0, one = 1;
            const float zeroF = 0;
            if (oldKit != s.sticker.id) {
                if (!Write(s.panel + 0x988, &s.sticker.id, 4) || !Write(s.panel + 0x98c, &one, 1) ||
                    !Write(s.panel + 0x8c8, &one, 1))
                    return false;
            }

            const unsigned char drag = s.dragging ? one : zero;
            const bool ok = Write(s.panel + 0x811, &zero, 1) && Write(s.panel + 0x812, &one, 1) &&
                            Write(s.panel + 0x830, &drag, 1) && Write(s.panel + 0x831, &drag, 1) &&
                            Write(s.panel + 0x81c, &zeroF, 4) && Write(s.panel + 0x820, &zeroF, 4) &&
                            Write(s.panel + 0x824, &s.sticker.x, 4) &&
                            Write(s.panel + 0x828, &s.sticker.y, 4) &&
                            Write(s.panel + 0x838, &s.sticker.rotation, 4);
            if (ok)
                ++stickerWrites_;
            return ok;
        }

        const unsigned char zero = 0, one = 1;
        const bool ok = Write(s.panel + 0x810, &zero, 1) && Write(s.panel + 0x811, &one, 1) &&
                        Write(s.panel + 0x812, &one, 1) && Write(s.panel + 0x830, &one, 1) &&
                        Write(s.panel + 0x831, &one, 1) && Write(s.position, s.xyz, sizeof(s.xyz));
        if (ok)
            ++writes_;
        return ok;
    }
    static void __fastcall Hook(void* panel) {
        auto* self = instance_.load(std::memory_order_acquire);
        auto next = pass_;
        if (!next)
            return;
        if (!self) {
            next(panel);
            return;
        }
        ++self->active_;

        const auto snap = self->Get();
        const auto now = GetTickCount64();
        int saved = 0;
        bool slotSet = false;
        if (snap.slot >= 0 && snap.slot < 5 && snap.slotGlobal &&
            snap.panel == reinterpret_cast<std::uintptr_t>(panel) && snap.at && now >= snap.at &&
            now - snap.at <= 350) {
            std::uintptr_t vt = 0;
            unsigned char mode = 0;
            if (Read(snap.panel, &vt, sizeof vt) && vt == snap.vtable && Read(snap.panel + 0x810, &mode, 1) &&
                mode == 1 && Read(snap.slotGlobal, &saved, 4))
                slotSet = Write(snap.slotGlobal, &snap.slot, 4);
        }
#ifdef MENU_STUDIO_CHARM_LIVE_TEST
        try {
            ++self->calls_;
            self->Apply(panel);
            next(panel);
            self->Apply(panel);
        } catch (...) {
            if (slotSet)
                self->RestoreSlot(snap.slotGlobal, snap.slot, saved);
            --self->active_;
            throw;
        }
        if (slotSet)
            self->RestoreSlot(snap.slotGlobal, snap.slot, saved);
        --self->active_;
#else
        __try {
            ++self->calls_;
            self->Apply(panel);
            next(panel);
            self->Apply(panel);
        } __finally {
            if (slotSet)
                self->RestoreSlot(snap.slotGlobal, snap.slot, saved);
            --self->active_;
        }
#endif
    }
    void RestoreSlot(std::uintptr_t p, int ours, int saved) {
        int current = 0;
        if (!Read(p, &current, 4) || (current == ours && !Write(p, &saved, 4)))
            ++stickerRestoreFailures_;
    }

public:
    bool Start(const HudScanImage& image, std::uintptr_t vt, std::string& diagnostic) {
        if (ready_)
            return true;
        auto hits = image.Find("48 89 5C 24 08 57 48 83 EC 20 48 8B D9 48 8B 0D ? ? ? ? 48 8B 01 FF 90 ? ? ? "
                               "? 8B 8B ? ? ? ? 8B F8 83 F9 01",
                               true, 2);
        std::uintptr_t position = 0;
        std::string why;
        if (hits.size() != 1 || !vt || !charm::ResolvePreviewInput(image, position, why)) {
            diagnostic = "charm live disabled: think/input/panel unresolved; " + why;
            return false;
        }

        sticker_native::Resolve(image, stickerSlotGlobal_, stickerSurfaceGlobal_);
        hook_ = reinterpret_cast<void*>(hits[0]);
        position_ = position;
        vtable_ = vt;
        instance_.store(this, std::memory_order_release);
        if (MH_CreateHook(hook_, reinterpret_cast<void*>(Hook), reinterpret_cast<void**>(&original_)) !=
            MH_OK) {
            instance_ = nullptr;
            diagnostic = "charm live hook create failed";
            return false;
        }
        created_ = true;
        pass_ = original_;
        if (MH_EnableHook(hook_) != MH_OK) {
            Stop();
            diagnostic = "charm live hook enable failed";
            return false;
        }
        enabled_ = true;
        ready_ = true;
        diagnostic = "charm live input hook armed; unverified; " + why;
        return true;
    }
    bool Ready() const {
        return ready_.load(std::memory_order_acquire);
    }
    bool StickerReady() const {
        return Ready() && stickerSlotGlobal_ != 0 && stickerSurfaceGlobal_ != 0;
    }
    void Select(std::uintptr_t panel, const charm::Values& v) {
        std::lock_guard<std::mutex> g(lock_);
        selected_ = panel;
        stickerSlot_ = -1;
        selectedAt_ = panel ? GetTickCount64() : 0;
        xyz_[0] = v.x;
        xyz_[1] = v.y;
        xyz_[2] = v.z;
    }
    void SelectSticker(std::uintptr_t panel, int slot, const local_decorations::Sticker& v, bool dragging) {
        std::lock_guard<std::mutex> g(lock_);
        selected_ = panel;
        selectedAt_ = panel ? GetTickCount64() : 0;
        stickerSlot_ = slot;
        stickerDragging_ = dragging;
        sticker_ = v;
    }
    std::string Diagnostic() const {
        return std::string("charm-live: ") + (Ready() ? "armed" : "off") +
               "; thinks=" + std::to_string(calls_.load()) + "; writes=" + std::to_string(writes_.load()) +
               "; sticker-ready=" + std::to_string(StickerReady()) +
               " sticker-writes=" + std::to_string(stickerWrites_.load()) +
               " slot-restore-fail=" + std::to_string(stickerRestoreFailures_.load());
    }
    bool Stop() {
        stopping_ = true;
        ready_ = false;
        Select(0, {});
        if (enabled_) {
            auto s = MH_DisableHook(hook_);
            if (s != MH_OK && s != MH_ERROR_DISABLED)
                return false;
            enabled_ = false;
        }
        auto end = GetTickCount64() + 2000;
        while (active_ && GetTickCount64() < end)
            Sleep(1);
        if (active_)
            return false;
        if (created_) {
            Sleep(100);
            if (active_ || MH_RemoveHook(hook_) != MH_OK)
                return false;
            created_ = false;
        }
        if (instance_.load() == this)
            instance_ = nullptr;
        return true;
    }
};
}
