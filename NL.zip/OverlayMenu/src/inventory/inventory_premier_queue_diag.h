#pragma once
#include <array>
#include <cstdint>
#include <limits>
namespace menu::premier_queue_diag {
struct Sample {
    bool entity = false, store = false, read = false;
    int count = -1;
    unsigned dirty = 0, mask = 0;
};
template <class Reader>
Sample Read(std::uintptr_t entity, const std::array<std::uint32_t, 6>& names, Reader read) {
    Sample q{};
    if (!entity || entity > std::numeric_limits<std::uintptr_t>::max() - 0x5f0)
        return q;
    q.entity = true;
    std::uintptr_t store = 0, ptr = 0;
    unsigned char dirty = 0;
    if (!read(entity + 0x5e8, &store, sizeof store) || !store ||
        store > std::numeric_limits<std::uintptr_t>::max() - 0x121)
        return q;
    q.store = true;
    if (!read(store + 0x48, &q.count, sizeof q.count) || !read(store + 0x50, &ptr, sizeof ptr) ||
        !read(store + 0x120, &dirty, 1) || q.count < 0 || q.count > 256 || (!ptr && q.count) ||
        ptr > std::numeric_limits<std::uintptr_t>::max() - std::uintptr_t(q.count) * 24)
        return q;
    q.dirty = dirty;
    for (int i = 0; i < q.count; ++i) {
        std::uint32_t key = 0;
        if (!read(ptr + std::uintptr_t(i) * 24, &key, sizeof key))
            return q;
        for (unsigned j = 0; j < 6; ++j)
            if (key && key == names[j])
                q.mask |= 1u << j;
    }
    q.read = true;
    return q;
}
}
