#pragma once
#include "watermark_hud_patterns.h"
namespace menu::premier_trace {

inline constexpr char Wrapper[] = "48 89 5C 24 08 57 48 83 EC 20 48 8B F9 48 8B DA 48 8B 89 E8 05 00 00 48 "
                                  "85 C9 74 ? E8 ? ? ? ? 48 8B D3 48 8B CF";
inline constexpr char Update[] =
    "48 8B C4 41 55 41 57 48 83 EC 68 80 B9 20 01 00 00 00 4C 8B EA 4C 8B F9 0F 84 ? ? ? ? 48 89 68 10";
inline std::uintptr_t Resolve(const HudScanImage& image) {
    auto w = image.Find(Wrapper, true, 2), u = image.Find(Update, true, 2);
    if (w.size() != 1 || u.size() != 1)
        return 0;
    auto target = image.Rip(w[0] + 28, 1, 5);
    return target == u[0] && image.Contains(target, 32, 0x20000000) ? target : 0;
}
}
