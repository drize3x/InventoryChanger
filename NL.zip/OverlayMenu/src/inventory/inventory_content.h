#pragma once

#include "inventory_art_catalog.h"
#include <atomic>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <thread>
namespace menu {

struct InventoryFileSource {
    virtual ~InventoryFileSource() = default;
    virtual bool Exists(const std::string& rel) const = 0;
    virtual bool Read(const std::string& rel, std::string& out) const = 0;
    virtual bool ReadRange(const std::string& rel, std::uint64_t offset, std::uint32_t length,
                           std::string& out) const = 0;
};

struct InventoryDiskSource : InventoryFileSource {
    std::filesystem::path root;
    std::uint64_t maxBytes = 64ull * 1024 * 1024;
    explicit InventoryDiskSource(std::filesystem::path r) : root(std::move(r)) {}
    std::filesystem::path Resolve(const std::string& rel) const {
        return root / std::filesystem::path(rel);
    }
    bool Exists(const std::string& rel) const override {
        std::error_code ec;
        return std::filesystem::is_regular_file(Resolve(rel), ec);
    }
    bool Read(const std::string& rel, std::string& out) const override {
        std::error_code ec;
        auto path = Resolve(rel);
        auto size = std::filesystem::file_size(path, ec);
        if (ec || size > maxBytes)
            return false;
        std::ifstream f(path, std::ios::binary);
        if (!f)
            return false;
        out.assign((std::istreambuf_iterator<char>(f)), {});
        return bool(f) || f.eof();
    }
    bool ReadRange(const std::string& rel, std::uint64_t offset, std::uint32_t length,
                   std::string& out) const override {
        if (length > maxBytes)
            return false;
        std::ifstream f(Resolve(rel), std::ios::binary);
        if (!f)
            return false;
        f.seekg(std::streamoff(offset));
        if (!f)
            return false;
        out.resize(length);
        f.read(out.data(), length);
        return bool(f);
    }
};

inline constexpr std::array<const char*, 2> InventoryTeamLogoFiles{
    {"panorama/images/icons/ct_logo.vsvg_c", "panorama/images/icons/t_logo.vsvg_c"}};
struct InventoryAssets {
    std::array<std::string, 2> teamLogos;
};

struct InventoryContentResult {
    InventoryCatalog catalog;
    InventoryAssets assets;
    std::string diagnostic;
    bool loaded = false;
};

inline bool InventoryFetch(const InventoryFileSource& src, const VPKDirectory* vpk,
                           const std::string& vpkPrefix, const std::string& logical, std::string& out) {
    if (src.Exists(logical) && src.Read(logical, out))
        return true;
    if (!vpk)
        return false;
    const VPKEntry* e = vpk->Find(logical);
    if (!e)
        return false;
    if (e->length == 0) {
        out.assign(e->preload.begin(), e->preload.end());
        return true;
    }
    std::string body;
    if (e->archive == 0x7FFF) {
        if (!src.ReadRange(vpkPrefix + "_dir.vpk", vpk->EmbeddedBase() + e->offset, e->length, body))
            return false;
    } else {
        char name[32];
        std::snprintf(name, sizeof name, "%s_%03u.vpk", vpkPrefix.c_str(), unsigned(e->archive));
        if (!src.ReadRange(name, e->offset, e->length, body))
            return false;
    }
    out.assign(e->preload.begin(), e->preload.end());
    out += body;
    return true;
}

inline constexpr std::array<const char*, 1> InventoryLocalizationFiles{{"resource/csgo_english.txt"}};

inline InventoryContentResult LoadInventoryContent(const InventoryFileSource& src,
                                                   const std::string& language = "english") {
    InventoryContentResult result;
    std::string note;
    std::unique_ptr<VPKDirectory> vpk;
    std::string vpkPrefix = "pak01";
    std::string dir;
    if (src.Read(vpkPrefix + "_dir.vpk", dir)) {
        try {
            vpk = std::make_unique<VPKDirectory>(
                VPKParseDirectory(reinterpret_cast<const unsigned char*>(dir.data()), dir.size()));
        } catch (const std::exception& e) {
            note += std::string("VPK ignored: ") + e.what() + "; ";
        }
    }
    for (std::size_t i = 0; i < InventoryTeamLogoFiles.size(); ++i) {
        std::string raw;
        if (InventoryFetch(src, vpk.get(), vpkPrefix, InventoryTeamLogoFiles[i], raw) &&
            raw.size() <= (1u << 20))
            result.assets.teamLogos[i] = std::move(raw);
    }
    std::string itemsRaw;
    if (!InventoryFetch(src, vpk.get(), vpkPrefix, "scripts/items/items_game.txt", itemsRaw)) {
        result.diagnostic = "items_game.txt not found; using built-in model tables. " + note;
        return result;
    }
    std::string locRaw;
    LocalizationTable loc;
    std::string langFile = "resource/csgo_" + language + ".txt";
    std::string base = "resource/csgo_english.txt";
    if (InventoryFetch(src, vpk.get(), vpkPrefix, base, locRaw))
        loc = LoadLocalization(locRaw);
    if (language != "english" && InventoryFetch(src, vpk.get(), vpkPrefix, langFile, locRaw)) {
        auto over = LoadLocalization(locRaw);
        for (auto& kv : over.tokens)
            loc.tokens[kv.first] = kv.second;
    }
    try {
        auto root = KV1Parse(KVToUTF8(itemsRaw));
        InventoryMergeCatalogSections(root);
        result.catalog = BuildInventoryCatalog(root, loc);
        InventoryCollectEconImages(result.catalog, root, vpk.get(), &loc,
                                   [&](const std::string& path) { return src.Exists(path); });
        const auto stickerPaths =
            std::count_if(result.catalog.stickers.begin(), result.catalog.stickers.end(),
                          [](const auto& s) { return !s.image.empty(); });
        result.loaded = result.catalog.loaded;
        result.diagnostic = result.loaded
                                ? ("Loaded " + std::to_string(result.catalog.paints.size()) +
                                   " finishes from items_game.txt; Zeus finishes=" +
                                   std::to_string(result.catalog.PaintsFor(31).size()) +
                                   ", named agents=" + std::to_string(result.catalog.agents.size()) +
                                   ", stickers=" + std::to_string(result.catalog.stickers.size()) +
                                   ", capsule groups=" + std::to_string(result.catalog.capsules.size()) +
                                   ", sticker image paths=" + std::to_string(stickerPaths) + ". " + note)
                                : ("items_game.txt parsed but empty. " + note);
    } catch (const std::exception& e) {
        result.diagnostic =
            std::string("items_game.txt parse failed: ") + e.what() + "; using built-in tables. " + note;
    }
    return result;
}

inline std::filesystem::path InventoryGuessCsgoDir(const std::filesystem::path& clientDll) {
    std::error_code ec;
    auto p = clientDll;
    for (int i = 0; i < 6 && !p.empty(); ++i) {
        p = p.parent_path();
        auto csgo = p / "csgo";
        if (std::filesystem::is_regular_file(csgo / "pak01_dir.vpk", ec) ||
            std::filesystem::is_directory(csgo / "scripts", ec))
            return csgo;
        if (p.filename() == "csgo")
            return p;
    }
    return {};
}

class InventoryContentCache {
    mutable std::mutex mutex_;
    std::shared_ptr<const InventoryCatalog> catalog_;
    std::shared_ptr<const InventoryAssets> assets_;
    std::string diagnostic_ = "not loaded";
    std::atomic<bool> running_{false}, done_{false};
    std::thread worker_;

public:
    ~InventoryContentCache() {
        if (worker_.joinable())
            worker_.join();
    }
    bool Ready() const {
        return done_.load();
    }
    std::shared_ptr<const InventoryCatalog> Catalog() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return catalog_;
    }
    std::shared_ptr<const InventoryAssets> Assets() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return assets_;
    }
    std::string Diagnostic() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return diagnostic_;
    }
    void Publish(InventoryContentResult result) {
        auto cat = std::make_shared<InventoryCatalog>(std::move(result.catalog));
        auto assets = std::make_shared<InventoryAssets>(std::move(result.assets));
        std::lock_guard<std::mutex> lock(mutex_);
        catalog_ = cat;
        assets_ = assets;
        diagnostic_ = result.diagnostic;
        done_.store(true);
    }

    void Start(std::filesystem::path csgoDir, std::string language = "english") {
        bool expected = false;
        if (!running_.compare_exchange_strong(expected, true))
            return;
        worker_ = std::thread([this, csgoDir = std::move(csgoDir), language = std::move(language)] {
            InventoryContentResult r;
            if (csgoDir.empty() || !std::filesystem::exists(csgoDir))
                r.diagnostic = "csgo content directory not found; using built-in model tables.";
            else {
                InventoryDiskSource src(csgoDir);
                r = LoadInventoryContent(src, language);
            }
            Publish(std::move(r));
        });
    }

    void LoadNow(const InventoryFileSource& src, const std::string& language = "english") {
        Publish(LoadInventoryContent(src, language));
    }

    void Wait() {
        if (worker_.joinable())
            worker_.join();
    }
};

inline InventoryContentCache& InventorySharedContent() {
    static InventoryContentCache cache;
    return cache;
}
}
