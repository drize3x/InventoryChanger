#pragma once

#include <cstdint>
#include <string>
namespace menu::charm {
inline constexpr char ViewSetter[] =
    "40 53 48 83 EC 20 48 8B D9 48 81 C1 08 02 00 00 E8 ? ? ? ? 48 8B CB 48 83 C4 20 5B E9 ? ? ? ?";
inline constexpr char FauxLookup[] = "48 B8 FF 7F FF 7F FF 7F FF 7F 48 3B C8 75 ? 48 8B 05 ? ? ? ? C3 48 B8 "
                                     "FE 7F FF 7F FF 7F FF 7F 48 3B C8 75 ?";
inline constexpr char IdCaller[] = "66 41 0F 6E D4 48 8D 15 ? ? ? ? 48 8B CE E8 ? ? ? ?";
template <class Image>
bool ResolveViewSetter(const Image& image, std::uintptr_t& out, std::string& diagnostic) {
    out = 0;
    auto setters = image.Find(ViewSetter, true, 2);
    auto callers = image.Find(IdCaller, true, 128);
    if (setters.size() != 1 || callers.size() >= 128) {
        diagnostic = "attribute setter signature ambiguous or absent";
        return false;
    }
    unsigned n = 0;
    for (auto p : callers) {
        if (image.Text(image.Rip(p + 5), "keychain slot 0 id") && image.Rip(p + 15, 1, 5) == setters[0])
            ++n;
    }
    if (n != 1) {
        diagnostic = "keychain-id call-site cross-check failed";
        return false;
    }
    out = setters[0];
    diagnostic = "attribute setter pattern and ID call-site matched; ownership/ABI not validated";
    return true;
}
}
