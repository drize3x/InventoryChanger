#pragma once

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <map>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>
namespace menu {

struct KV1Node {
    std::string key, value;
    std::vector<KV1Node> children;
    bool block = false;
    static bool IEqual(const std::string& a, const char* b) {
        std::size_t i = 0;
        for (; i < a.size() && b[i]; ++i) {
            char x = a[i], y = b[i];
            if (x >= 'A' && x <= 'Z')
                x = char(x + 32);
            if (y >= 'A' && y <= 'Z')
                y = char(y + 32);
            if (x != y)
                return false;
        }
        return i == a.size() && b[i] == 0;
    }
    const KV1Node* Child(const char* k) const {
        for (const auto& c : children)
            if (IEqual(c.key, k))
                return &c;
        return nullptr;
    }
    const std::string* Value(const char* k) const {
        auto c = Child(k);
        return c && !c->block ? &c->value : nullptr;
    }
    std::string ValueOr(const char* k, const char* fallback = "") const {
        auto v = Value(k);
        return v ? *v : fallback;
    }
};

inline constexpr std::size_t KV1MaxBytes = 48u * 1024u * 1024u, KV1MaxDepth = 64,
                             KV1MaxNodes = 4u * 1024u * 1024u;
struct KV1Parser {
    std::string_view s;
    std::size_t pos = 0, nodes = 0;
    explicit KV1Parser(std::string_view text) : s(text) {
        if (s.size() > KV1MaxBytes)
            throw std::runtime_error("KeyValues input too large");
    }
    void Skip() {
        for (;;) {
            while (pos < s.size() && (unsigned char)s[pos] <= ' ')
                ++pos;
            if (pos + 1 < s.size() && s[pos] == '/' && s[pos + 1] == '/') {
                while (pos < s.size() && s[pos] != '\n')
                    ++pos;
                continue;
            }
            break;
        }
    }

    void SkipConditional() {
        std::size_t save = pos;
        Skip();
        if (pos < s.size() && s[pos] == '[') {
            while (pos < s.size() && s[pos] != ']' && s[pos] != '\n')
                ++pos;
            if (pos < s.size() && s[pos] == ']')
                ++pos;
        } else
            pos = save;
    }
    bool Token(std::string& out) {
        Skip();
        if (pos >= s.size())
            return false;
        char c = s[pos];
        if (c == '{' || c == '}') {
            out.assign(1, c);
            ++pos;
            return true;
        }
        if (c == '"') {
            ++pos;
            out.clear();
            while (pos < s.size() && s[pos] != '"') {
                char d = s[pos++];
                if (d == '\\' && pos < s.size()) {
                    char e = s[pos++];
                    switch (e) {
                    case 'n':
                        out += '\n';
                        break;
                    case 't':
                        out += '\t';
                        break;
                    case 'r':
                        out += '\r';
                        break;
                    case '\\':
                        out += '\\';
                        break;
                    case '"':
                        out += '"';
                        break;
                    default:
                        out += '\\';
                        out += e;
                    }
                } else
                    out += d;
                if (out.size() > 65536)
                    throw std::runtime_error("KeyValues token too long");
            }
            if (pos >= s.size())
                throw std::runtime_error("Unterminated KeyValues string");
            ++pos;
            return true;
        }
        out.clear();
        while (pos < s.size()) {
            char d = s[pos];
            if ((unsigned char)d <= ' ' || d == '{' || d == '}' || d == '"')
                break;
            if (d == '/' && pos + 1 < s.size() && s[pos + 1] == '/')
                break;
            out += d;
            ++pos;
            if (out.size() > 65536)
                throw std::runtime_error("KeyValues token too long");
        }
        return !out.empty();
    }
    void ParseBlock(KV1Node& parent, std::size_t depth) {
        if (depth > KV1MaxDepth)
            throw std::runtime_error("KeyValues nested too deep");
        std::string tok;
        while (Token(tok)) {
            if (tok == "}") {
                if (depth == 0)
                    throw std::runtime_error("Unbalanced KeyValues block");
                return;
            }
            if (tok == "{")
                throw std::runtime_error("Unexpected KeyValues block");
            if (++nodes > KV1MaxNodes)
                throw std::runtime_error("KeyValues node limit");
            KV1Node node;
            node.key = std::move(tok);
            SkipConditional();
            std::string next;
            if (!Token(next))
                throw std::runtime_error("Truncated KeyValues entry");
            if (next == "{") {
                node.block = true;
                ParseBlock(node, depth + 1);
            } else if (next == "}")
                throw std::runtime_error("KeyValues key without value");
            else {
                node.value = std::move(next);
                SkipConditional();
            }
            parent.children.push_back(std::move(node));
        }
        if (depth != 0)
            throw std::runtime_error("Unterminated KeyValues block");
    }
};
inline KV1Node KV1Parse(std::string_view text) {
    KV1Node root;
    root.block = true;
    KV1Parser p(text);
    p.ParseBlock(root, 0);
    return root;
}

inline void KVAppendUTF8(std::string& out, char32_t cp) {
    if (cp < 0x80)
        out += char(cp);
    else if (cp < 0x800) {
        out += char(0xC0 | (cp >> 6));
        out += char(0x80 | (cp & 0x3F));
    } else if (cp < 0x10000) {
        out += char(0xE0 | (cp >> 12));
        out += char(0x80 | ((cp >> 6) & 0x3F));
        out += char(0x80 | (cp & 0x3F));
    } else {
        out += char(0xF0 | (cp >> 18));
        out += char(0x80 | ((cp >> 12) & 0x3F));
        out += char(0x80 | ((cp >> 6) & 0x3F));
        out += char(0x80 | (cp & 0x3F));
    }
}

inline std::string KVToUTF8(const std::string& raw) {
    if (raw.size() >= 2 && (unsigned char)raw[0] == 0xFF && (unsigned char)raw[1] == 0xFE) {
        std::string out;
        out.reserve(raw.size());
        for (std::size_t i = 2; i + 1 < raw.size(); i += 2) {
            char32_t u = char32_t((unsigned char)raw[i] | ((unsigned char)raw[i + 1] << 8));
            if (u >= 0xD800 && u <= 0xDBFF && i + 3 < raw.size()) {
                char32_t lo = char32_t((unsigned char)raw[i + 2] | ((unsigned char)raw[i + 3] << 8));
                if (lo >= 0xDC00 && lo <= 0xDFFF) {
                    u = 0x10000 + ((u - 0xD800) << 10) + (lo - 0xDC00);
                    i += 2;
                }
            }
            KVAppendUTF8(out, u);
        }
        return out;
    }
    if (raw.size() >= 3 && (unsigned char)raw[0] == 0xEF && (unsigned char)raw[1] == 0xBB &&
        (unsigned char)raw[2] == 0xBF)
        return raw.substr(3);
    return raw;
}
inline std::string KVLower(std::string k) {
    for (auto& c : k)
        if (c >= 'A' && c <= 'Z')
            c = char(c + 32);
    return k;
}

struct LocalizationTable {
    std::map<std::string, std::string> tokens;
    const std::string* Find(const std::string& key) const {
        std::string k = key;
        if (!k.empty() && k[0] == '#')
            k = k.substr(1);
        auto it = tokens.find(KVLower(k));
        return it == tokens.end() ? nullptr : &it->second;
    }
    std::string Resolve(const std::string& tag, const std::string& fallback) const {
        auto v = Find(tag);
        return v ? *v : fallback;
    }
};
inline LocalizationTable LoadLocalization(const std::string& raw) {
    LocalizationTable table;
    auto root = KV1Parse(KVToUTF8(raw));
    const KV1Node* lang = root.Child("lang");
    if (!lang && !root.children.empty())
        lang = &root.children.front();
    const KV1Node* tokens = lang ? lang->Child("Tokens") : nullptr;
    if (!tokens)
        return table;
    for (const auto& kv : tokens->children)
        if (!kv.block)
            table.tokens.emplace(KVLower(kv.key), kv.value);
    return table;
}

struct VPKEntry {
    std::string path;
    std::uint16_t archive = 0;
    std::uint32_t offset = 0, length = 0;
    std::vector<unsigned char> preload;
};
struct VPKDirectory {
    std::uint32_t version = 0, treeSize = 0, headerSize = 0;
    std::vector<VPKEntry> entries;
    std::map<std::string, std::size_t> index;
    const VPKEntry* Find(const std::string& path) const {
        auto it = index.find(KVLower(path));
        return it == index.end() ? nullptr : &entries[it->second];
    }
    std::uint64_t EmbeddedBase() const {
        return std::uint64_t(headerSize) + treeSize;
    }
};
inline std::string VPKReadString(const unsigned char* d, std::size_t n, std::size_t& p) {
    std::string s;
    while (p < n && d[p]) {
        s += char(d[p++]);
        if (s.size() > 4096)
            throw std::runtime_error("VPK name too long");
    }
    if (p >= n)
        throw std::runtime_error("VPK string truncated");
    ++p;
    return s;
}
inline VPKDirectory VPKParseDirectory(const unsigned char* d, std::size_t n) {
    VPKDirectory dir;
    if (n < 12)
        throw std::runtime_error("VPK too small");
    std::uint32_t sig = 0, version = 0;
    std::memcpy(&sig, d, 4);
    std::memcpy(&version, d + 4, 4);
    if (sig != 0x55aa1234u)
        throw std::runtime_error("Bad VPK signature");
    std::size_t p = 0;
    if (version == 1) {
        std::memcpy(&dir.treeSize, d + 8, 4);
        p = 12;
    } else if (version == 2) {
        if (n < 28)
            throw std::runtime_error("VPK v2 header truncated");
        std::memcpy(&dir.treeSize, d + 8, 4);
        p = 28;
    } else
        throw std::runtime_error("Unsupported VPK version");
    dir.version = version;
    dir.headerSize = std::uint32_t(p);
    std::size_t treeEnd = p + dir.treeSize;
    if (treeEnd > n || treeEnd < p)
        throw std::runtime_error("VPK tree out of range");
    for (;;) {
        std::string ext = VPKReadString(d, treeEnd, p);
        if (ext.empty())
            break;
        for (;;) {
            std::string path = VPKReadString(d, treeEnd, p);
            if (path.empty())
                break;
            for (;;) {
                std::string name = VPKReadString(d, treeEnd, p);
                if (name.empty())
                    break;
                if (p + 18 > treeEnd)
                    throw std::runtime_error("VPK entry truncated");
                std::uint32_t crc = 0, offset = 0, length = 0;
                std::uint16_t preload = 0, archive = 0, terminator = 0;
                std::memcpy(&crc, d + p, 4);
                p += 4;
                std::memcpy(&preload, d + p, 2);
                p += 2;
                std::memcpy(&archive, d + p, 2);
                p += 2;
                std::memcpy(&offset, d + p, 4);
                p += 4;
                std::memcpy(&length, d + p, 4);
                p += 4;
                std::memcpy(&terminator, d + p, 2);
                p += 2;
                (void)crc;
                if (terminator != 0xFFFF)
                    throw std::runtime_error("VPK entry terminator mismatch");
                VPKEntry e;
                e.archive = archive;
                e.offset = offset;
                e.length = length;
                std::string dirPart = path == " " || path == "." ? std::string() : path + "/";
                e.path = dirPart + name + (ext == " " ? std::string() : "." + ext);
                if (preload) {
                    if (p + preload > treeEnd)
                        throw std::runtime_error("VPK preload truncated");
                    e.preload.assign(d + p, d + p + preload);
                    p += preload;
                }
                dir.index.emplace(KVLower(e.path), dir.entries.size());
                dir.entries.push_back(std::move(e));
                if (dir.entries.size() > 2000000)
                    throw std::runtime_error("VPK entry limit");
            }
        }
    }
    return dir;
}
}
