#pragma once

#include "inventory_catalog.h"
#include "inventory_local_weapons_core.h"
namespace menu {
inline bool InventorySelectedLocalAgent(const InventoryCatalog& catalog, const InventoryLoadout& team,
                                        int side, local_weapons::Spec& out) {
    if ((side != InventoryCT && side != InventoryT) || team.agent <= 0 || team.agent > 65535)
        return false;
    for (const auto& agent : catalog.agents) {
        if (agent.id != team.agent || !InventoryTeamAllows(agent.teams, side))
            continue;
        local_weapons::Spec spec;
        spec.kind = local_weapons::Kind::Agent;
        spec.definition = agent.id;
        spec.rarity = std::clamp(agent.rarity, 1, 7);
        out = spec;
        return true;
    }
    return false;
}
}
