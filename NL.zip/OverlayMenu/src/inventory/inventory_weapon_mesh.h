#pragma once

#include <cstdint>
#include <cstddef>
#include <map>
#include <set>
namespace menu::weapon_mesh {
struct Layout {
    std::uint32_t scene = 0, arms = 0, ownerHandle = 0, nodeOwner = 0, child = 0, next = 0, model = 0,
                  mask = 0;
    std::uintptr_t armsTable = 0, hudWeaponTable = 0, skeletonTable = 0, skeletonBaseTable = 0;
    bool valid = false;
};
struct Adapter {
    virtual ~Adapter() = default;
    virtual bool Read(std::uintptr_t, void*, std::size_t) = 0;
    virtual std::uintptr_t Entity(std::uint32_t) = 0;
    virtual bool SetMesh(std::uintptr_t, std::uint64_t) = 0;
    template <class T> bool Get(std::uintptr_t p, T& v) {
        return Read(p, &v, sizeof v);
    }
};
struct Saved {
    std::uintptr_t node = 0;
    std::uint64_t original = 0, last = 0;
    unsigned attempts = 0;
};
class Controller {
    struct Record {
        Saved world, hud;
    };
    std::map<std::uintptr_t, Record> records_;
    static bool ValidNode(Adapter& a, const Layout& o, std::uintptr_t node, std::uintptr_t owner) {
        std::uintptr_t vt = 0, actual = 0;
        return node && a.Get(node, vt) && (vt == o.skeletonTable || vt == o.skeletonBaseTable) &&
               a.Get(node + o.nodeOwner, actual) && actual == owner;
    }
    static std::uintptr_t World(Adapter& a, const Layout& o, std::uintptr_t e) {
        std::uintptr_t n = 0;
        return a.Get(e + o.scene, n) && ValidNode(a, o, n, e) ? n : 0;
    }
    static std::uintptr_t Hud(Adapter& a, const Layout& o, std::uintptr_t pawn, std::uintptr_t weapon) {
        std::uint32_t h = 0;
        std::uintptr_t arm = 0, vt = 0, root = 0, rootOwner = 0, node = 0;
        if (!pawn || !a.Get(pawn + o.arms, h) || !h || h == 0xffffffffu || !(arm = a.Entity(h)) ||
            !a.Get(arm, vt) || vt != o.armsTable || !a.Get(arm + o.scene, root) || !root ||
            !a.Get(root + o.nodeOwner, rootOwner) || rootOwner != arm || !a.Get(root + o.child, node))
            return 0;
        std::set<std::uintptr_t> seen;
        for (unsigned i = 0; node && i < 32 && seen.insert(node).second; ++i) {
            std::uintptr_t owner = 0, ownNode = 0;
            std::uint32_t link = 0;
            if (a.Get(node + o.nodeOwner, owner) && owner && a.Get(owner, vt) && vt == o.hudWeaponTable &&
                a.Get(owner + o.ownerHandle, link) && a.Entity(link) == weapon &&
                a.Get(owner + o.scene, ownNode) && ownNode == node && ValidNode(a, o, node, owner))
                return node;
            std::uintptr_t next = 0;
            if (!a.Get(node + o.next, next))
                break;
            node = next;
        }
        return 0;
    }

    static bool Apply(Adapter& a, const Layout& o, Saved& s, std::uintptr_t node, std::uint64_t mask) {
        if (!node) {
            s = {};
            return false;
        }
        std::uint64_t old = 0;
        if (!a.Get(node + o.model + o.mask, old))
            return false;
        if (s.node != node)
            s = {node, old, old, 0};
        if (old == mask) {
            s.last = mask;
            return false;
        }
        if (s.attempts >= 4)
            return false;
        ++s.attempts;
        if (a.SetMesh(node, mask)) {
            s.last = mask;
            return true;
        }
        return false;
    }
    static void Restore(Adapter& a, const Layout& o, Saved& s, std::uintptr_t node) {
        if (s.node && s.node == node) {
            std::uint64_t v = 0;
            if (a.Get(node + o.model + o.mask, v) && v == s.last && v != s.original)
                a.SetMesh(node, s.original);
        }
        s = {};
    }

public:
    static std::uintptr_t FindHudNode(Adapter& a, const Layout& o, std::uintptr_t pawn,
                                      std::uintptr_t weapon) {
        return o.valid ? Hud(a, o, pawn, weapon) : 0;
    }

    unsigned Tick(Adapter& a, const Layout& o, std::uintptr_t e, std::uintptr_t pawn, bool legacy) {
        if (!o.valid || !e)
            return 0;
        auto& r = records_[e];
        auto mask = std::uint64_t(legacy ? 2 : 1);
        auto world = World(a, o, e), hud = Hud(a, o, pawn, e);
        auto w = Apply(a, o, r.world, world, mask), h = Apply(a, o, r.hud, hud, mask);
        return (world ? 1u : 0u) | (hud ? 2u : 0u) | (w ? 4u : 0u) | (h ? 8u : 0u);
    }
    void Restore(Adapter& a, const Layout& o, std::uintptr_t e, std::uintptr_t pawn) {
        auto it = records_.find(e);
        if (it == records_.end())
            return;
        if (o.valid) {
            Restore(a, o, it->second.world, World(a, o, e));
            Restore(a, o, it->second.hud, Hud(a, o, pawn, e));
        }
        records_.erase(it);
    }
    void Forget(std::uintptr_t e) {
        records_.erase(e);
    }
};
}
