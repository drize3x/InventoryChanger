#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <cstring>
namespace menu::charm {
struct PanelDiagnostic {
    bool found = false, read = false;
    unsigned char b810 = 0, b811 = 0, b812 = 0, b830 = 0, b831 = 0, b844 = 0;
    float f81c = 0, f820 = 0, f824 = 0, f828 = 0, f838 = 0;
    std::uint64_t at = 0;
};
template <class Reader>
PanelDiagnostic ReadPanelDiagnostic(std::uintptr_t client, std::uint64_t now, Reader read) {
    PanelDiagnostic out{};
    if (!client || client > std::numeric_limits<std::uintptr_t>::max() - 0x845)
        return out;
    out.found = true;
    out.at = now;
    std::array<unsigned char, 0x35> b{};
    if (!read(client + 0x810, b.data(), b.size()))
        return out;
    out.read = true;
    out.b810 = b[0];
    out.b811 = b[1];
    out.b812 = b[2];
    out.b830 = b[0x20];
    out.b831 = b[0x21];
    out.b844 = b[0x34];
    std::memcpy(&out.f81c, b.data() + 0x0c, 4);
    std::memcpy(&out.f820, b.data() + 0x10, 4);
    std::memcpy(&out.f824, b.data() + 0x14, 4);
    std::memcpy(&out.f828, b.data() + 0x18, 4);
    std::memcpy(&out.f838, b.data() + 0x28, 4);
    return out;
}
}
