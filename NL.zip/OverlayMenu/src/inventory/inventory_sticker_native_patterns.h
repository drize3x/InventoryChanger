#pragma once
#include <cstdint>
namespace menu::sticker_native {

template <class Image> bool Resolve(const Image& image, std::uintptr_t& slot, std::uintptr_t& surface) {
    slot = surface = 0;
    auto use = image.Find("83 3D ? ? ? ? 00 0F 8C ? ? ? ? 8B 05 ? ? ? ? 85 C0 0F 88 ? ? ? ? B9 04 00 00 00",
                          true, 2);
    auto init = image.Find("80 B9 10 08 00 00 00 75 03 32 C0 C3 89 91 88 09 00 00 33 C0 C6 81 8C 09 00 00 01 "
                           "C6 81 C8 08 00 00 01 C7 05 ? ? ? ? FF FF FF FF C7 05 ? ? ? ? FF FF FF FF",
                           true, 2);
    if (use.size() != 1 || init.size() != 1)
        return false;
    const auto a = image.Rip(use[0], 2, 7), b = image.Rip(use[0] + 13, 2, 6);
    if (!a || !b || a == b || image.Rip(init[0] + 34, 2, 10) != a || image.Rip(init[0] + 44, 2, 10) != b ||
        !image.Contains(a, 4, 0x80000000, 0x20000000) || !image.Contains(b, 4, 0x80000000, 0x20000000))
        return false;
    surface = a;
    slot = b;
    return true;
}
}
