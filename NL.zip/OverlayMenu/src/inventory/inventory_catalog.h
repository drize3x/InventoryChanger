#pragma once

#include "inventory_schema.h"
#include "menu_core.h"
#include <functional>
#include <sstream>
#include <unordered_map>
namespace menu {

struct InventoryPaint {
    int id = 0;
    std::string key;
    std::string name;
    int collection = -1;
    int rarity = 1;
    float wearMin = 0.f, wearMax = 1.f;
    std::array<Color, 4> paintColors{};
    unsigned paintColorMask = 0;
    bool legacy = false;
    std::string description;
};
struct InventoryCollection {
    std::string key, name;
    std::string image{};
    std::vector<std::pair<int, int>> members{};
};
struct InventoryDefinition {
    int index = 0;
    std::string key, name, image, model, prefab;
};
struct InventoryStickerKit {
    int id = 0;
    std::string key, name;
    int rarity = 1, eventId = 0;
    int capsule = -1;
    std::string image{};
};
struct InventoryCapsule {
    std::string key, name;
    std::vector<int> stickers;
    bool tournament = false;
    int eventId = 0;
};
struct InventoryNamed {
    int id = 0;
    std::string key, name;
    int rarity = 1;
    unsigned teams = InventoryTeamBoth;
    std::string image{}, model{};
    std::array<int, 5> premierAttributes{{-1, -1, -1, -1, -1}};
};

struct InventoryCatalog {
    bool loaded = false;
    std::string source = "built-in model tables";
    std::vector<InventoryPaint> paints;
    std::unordered_map<int, std::size_t> paintById;
    std::vector<InventoryCollection> collections;
    std::map<int, std::vector<int>> itemPaints;
    std::vector<int> knifePaints;
    std::vector<InventoryStickerKit> stickers;
    std::unordered_map<int, std::size_t> stickerById;
    std::vector<InventoryCapsule> capsules;
    std::vector<InventoryNamed> music, agents, medals, keychains;
    std::array<Color, 8> rarityColors{};
    std::map<std::pair<int, int>, std::string> itemImages;
    std::map<int, InventoryDefinition> definitions;
    std::array<std::string, 2> defaultAgentNames{};
    std::array<std::string, 3> defaultNamedImages{};
    std::map<int, int> itemRarities;
    std::map<int, std::string> itemNames;
    std::map<int, std::string> eventNames;
    std::array<std::string, 5> wearNames{};

    InventoryCatalog() {
        for (int i = 0; i < 8; ++i)
            rarityColors[std::size_t(i)] = InventoryRarityColor(i);
    }

    const InventoryPaint* Paint(int id) const {
        auto it = paintById.find(id);
        return it == paintById.end() ? nullptr : &paints[it->second];
    }
    const InventoryStickerKit* Sticker(int id) const {
        auto it = stickerById.find(id);
        return it == stickerById.end() ? nullptr : &stickers[it->second];
    }
    Color RarityColor(int r) const {
        return rarityColors[std::size_t(std::clamp(r, 0, 7))];
    }
    std::string ItemName(int index, const char* fallback) const {
        auto it = itemNames.find(index);
        return it != itemNames.end() ? it->second : std::string(fallback);
    }

    const std::vector<int>& PaintsFor(int index) const {
        static const std::vector<int> empty;
        auto it = itemPaints.find(index);
        if (it != itemPaints.end() && !it->second.empty())
            return it->second;
        if (InventoryIsKnife(index))
            return knifePaints;
        return empty;
    }
    const std::string& CollectionName(int c) const {
        static const std::string none;
        return c >= 0 && std::size_t(c) < collections.size() ? collections[std::size_t(c)].name : none;
    }
};

namespace detail {
int InventoryRarityOrdinal(const std::string& name);

bool InventorySplitEntry(const std::string& key, std::string& paint, std::string& item);
}

Color InventoryParseHexColor(const std::string& hex);

InventoryCatalog BuildInventoryCatalog(const KV1Node& itemsGameRoot, const LocalizationTable& loc);

int InventoryFinishRarity(const InventoryCatalog& cat, int index, const InventoryPaint* p);

enum class InventorySort : int { Rarity = 0, Newest = 1, Name = 2 };
void InventorySortPaints(const InventoryCatalog& cat, std::vector<int>& ids, InventorySort sort,
                         int index = 0);
}
