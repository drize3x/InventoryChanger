#pragma once

#include "watermark_hud_patterns.h"
namespace menu::inventory_frost {
inline constexpr char PawnApply[] =
    "48 8B 9E A8 00 00 00 49 8D 8F 20 17 00 00 48 8D 95 28 01 00 00 E8 ? ? ? ? 4C 8D 44 24 20 BA AC 5B F6 C7 "
    "48 8B CB 0F 10 00 0F 29 44 24 20 E8 ? ? ? ?";
inline constexpr char WeaponApply[] =
    "48 8B 9F A8 00 00 00 49 8D 8C 24 94 19 00 00 48 8D 55 20 E8 ? ? ? ? 4C 8D 44 24 40 BA AC 5B F6 C7 48 8B "
    "CB 0F 10 00 0F 29 44 24 40 E8 ? ? ? ?";
inline constexpr char WeaponOwnerGuard[] =
    "4C 8B E1 E8 ? ? ? ? 49 8B CC E8 ? ? ? ? 48 85 C0 0F 85 ? ? ? ? 49 8B 94 24 D8 19 00 00";
inline constexpr char SceneGet[] =
    "3B 51 38 7C 03 33 C0 C3 48 8B 41 40 48 8B 0D ? ? ? ? 48 63 D2 48 8B 14 D0 E9 ? ? ? ?";
inline constexpr char WeaponSceneBranch[] =
    "49 8B 04 24 49 8B CC FF 90 10 02 00 00 83 F8 05 0F 85 ? ? ? ? 49 8D 8C 24 D8 19 00 00";

inline constexpr char PawnUpdate[] = "48 8D 8B 20 17 00 00 48 8B D3 4C 8B C0 E8 ? ? ? ? B0 01";
inline constexpr char OtherUpdate[] = "49 8B D7 49 8D 8F E4 1A 00 00 4C 8B C0 E8 ? ? ? ? 49 8B CF";
inline constexpr char InitSkyCall[] = "48 8B D5 48 8B CE E8 ? ? ? ? 84 C0 74 0D C7 47 04 00 00 80 3F";
inline constexpr char UpdateSkyCallLegacy[] = "49 8B D5 49 8B CF BE 10 00 00 00 E8 ? ? ? ? 84 C0 74 05";
inline constexpr char UpdateSkyCallCurrent[] =
    "49 8B D7 49 8B CE BE 10 00 00 00 4C 8B E7 E8 ? ? ? ? 84 C0 74 05";
struct EnvironmentBindings {
    std::uintptr_t update = 0, sky = 0;
};
inline bool ResolveEnvironment(const HudScanImage& image, EnvironmentBindings& out) {
    out = {};
    auto a = image.Find(PawnUpdate, true, 2), b = image.Find(OtherUpdate, true, 2),
         legacy = image.Find(UpdateSkyCallLegacy, true, 2), current = image.Find(UpdateSkyCallCurrent, true, 2),
         d = image.Find(InitSkyCall, true, 2);
    if (a.size() != 1 || b.size() != 1 || d.size() != 1 || legacy.size() + current.size() != 1)
        return false;
    const auto site = legacy.empty() ? current[0] : legacy[0];
    const auto callOffset = legacy.empty() ? 14 : 11;
    auto update = image.Rip(a[0] + 13, 1, 5), other = image.Rip(b[0] + 13, 1, 5),
         sky = image.Rip(site + callOffset, 1, 5);
    if (!update || update != other || !sky || image.Rip(d[0] + 6, 1, 5) != sky || site <= update ||
        site - update > 0x500 || !image.Contains(update, 16, 0x20000000) ||
        !image.Contains(sky, 16, 0x20000000))
        return false;
    const unsigned char legacyHead[] = {0x40, 0x55, 0x57, 0x41, 0x55, 0x41, 0x57};
    const unsigned char currentHead[] = {0x40, 0x55, 0x57, 0x41, 0x56, 0x41, 0x57};
    unsigned char actual[sizeof legacyHead]{};
    if (!image.Bytes(update, actual, sizeof actual) ||
        (std::memcmp(legacyHead, actual, sizeof actual) && std::memcmp(currentHead, actual, sizeof actual)))
        return false;
    out = {update, sky};
    return true;
}
struct Bindings {
    std::uintptr_t pawnSite = 0, weaponSite = 0, ownerGuard = 0, sceneGetter = 0, vectorGetter = 0,
                   vectorSetter = 0, weaponSceneBranch = 0;
};
inline bool Resolve(const HudScanImage& image, Bindings& out) {
    out = {};
    Bindings b;
    auto one = [&](const char* sig) {
        auto h = image.Find(sig, true, 2);
        return h.size() == 1 ? h[0] : std::uintptr_t(0);
    };
    b.pawnSite = one(PawnApply);
    b.weaponSite = one(WeaponApply);
    b.ownerGuard = one(WeaponOwnerGuard);
    b.sceneGetter = one(SceneGet);
    b.weaponSceneBranch = one(WeaponSceneBranch);
    if (!b.pawnSite || !b.weaponSite || !b.ownerGuard || !b.sceneGetter || !b.weaponSceneBranch)
        return false;

    b.vectorGetter = image.Rip(b.pawnSite + 21, 1, 5);
    b.vectorSetter = image.Rip(b.pawnSite + 47, 1, 5);
    if (!b.vectorGetter || !b.vectorSetter || image.Rip(b.weaponSite + 19, 1, 5) != b.vectorGetter ||
        image.Rip(b.weaponSite + 45, 1, 5) != b.vectorSetter ||
        !image.Contains(b.vectorGetter, 1, 0x20000000) || !image.Contains(b.vectorSetter, 1, 0x20000000))
        return false;

    if (b.pawnSite <= b.weaponSceneBranch || b.pawnSite - b.weaponSceneBranch > 0x1000 ||
        b.weaponSite <= b.ownerGuard || b.weaponSite - b.ownerGuard > 0x1000)
        return false;
    out = b;
    return true;
}
}
