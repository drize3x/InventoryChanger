#include "menu_core.h"

namespace menu {
const InventoryWeaponInfo* InventoryWeapon(int index) {
    for (const auto& w : InventoryWeapons)
        if (w.index == index)
            return &w;
    return nullptr;
}

const InventoryModelInfo* InventoryKnife(int index) {
    for (const auto& k : InventoryKnives)
        if (k.index == index)
            return &k;
    return nullptr;
}

const InventoryModelInfo* InventoryGlove(int index) {
    for (const auto& g : InventoryGloves)
        if (g.index == index)
            return &g;
    return nullptr;
}

bool InventoryIsKnife(int index) {
    return index == 41 || index == 42 || index == 59 || (index >= 500 && index <= 599);
}

bool InventoryIsGlove(int index) {
    return index == 4725 || (index >= 5027 && index <= 5099);
}

int InventoryDefaultKnife(int team) {
    return team == InventoryCT ? 42 : 59;
}

int InventoryDefaultGlove(int team) {
    return team == InventoryCT ? 5029 : 5028;
}

bool InventoryTeamAllows(unsigned teams, int team) {
    return (teams & (team == InventoryCT ? InventoryTeamCT : InventoryTeamT)) != 0;
}

InventoryGroup InventorySlotGroup(int slot) {
    return slot < 5 ? InventoryGroup::Pistols : slot < 10 ? InventoryGroup::MidTier : InventoryGroup::Rifles;
}

std::vector<int> InventoryWearTiers(float lo, float hi) {
    std::vector<int> out;
    if (!(lo <= hi)) {
        lo = 0;
        hi = 1;
    }
    for (int i = 0; i < 5; ++i)
        if (InventoryWearEdges[std::size_t(i) + 1] > lo && InventoryWearEdges[std::size_t(i)] < hi)
            out.push_back(i);
    if (out.empty())
        out.push_back(0);
    return out;
}

float InventoryWearFloat(int tier, int percent, float lo, float hi) {
    tier = std::clamp(tier, 0, 4);
    float a = std::max(InventoryWearEdges[std::size_t(tier)], lo),
          b = std::min(InventoryWearEdges[std::size_t(tier) + 1], hi);
    if (b < a)
        b = a;
    float t = std::clamp(percent, 0, 100) / 100.f;
    return std::clamp(a + (b - a) * t, 0.f, 1.f);
}

Color InventoryRarityColor(int r) {
    static constexpr std::array<std::uint32_t, 8> hex{
        {0xE9E9E9, 0xB0C3D9, 0x5E98D9, 0x4B69FF, 0x8847FF, 0xD32CE6, 0xEB4B4B, 0xE4AE39}};
    auto v = hex[std::size_t(std::clamp(r, 0, 7))];
    return {((v >> 16) & 255) / 255.f, ((v >> 8) & 255) / 255.f, (v & 255) / 255.f, 1};
}

bool InventorySameColor(Color a, Color b) {
    return a.r == b.r && a.g == b.g && a.b == b.b && a.a == b.a;
}

bool InventorySelectedForLocalCopy(const InventoryLoadout& loadout, int team, int index) {
    if (team != InventoryCT && team != InventoryT)
        return false;
    if (InventoryKnife(index))
        return index == (loadout.knife ? loadout.knife : InventoryDefaultKnife(team));
    if (InventoryGlove(index))
        return index == (loadout.gloves ? loadout.gloves : InventoryDefaultGlove(team));
    if (InventoryWeapon(index))
        return index == 31 ||
               std::find(loadout.slots.begin(), loadout.slots.end(), index) != loadout.slots.end();
    return false;
}

bool InventoryValidSlotWeapon(int team, int slot, int index) {
    auto w = InventoryWeapon(index);
    return slot >= 0 && slot < 15 && w && w->group == InventorySlotGroup(slot) &&
           InventoryTeamAllows(w->teams, team);
}

bool InventoryConfigurable(int index) {
    return InventoryWeapon(index) || InventoryIsKnife(index) || InventoryIsGlove(index);
}
}
