#pragma once
#include <cstdint>

namespace menu::knife_buy_hud {

class Schedule {
    bool known_ = false, open_ = false;
    std::uintptr_t pawn_ = 0;
    std::uint32_t pending_ = 0;
    std::uint64_t due_ = 0;
    unsigned remaining_ = 0;

public:
    std::uint32_t Tick(std::uint64_t now, std::uintptr_t pawn, bool valid, bool open, bool applied,
                       std::uint32_t handle) {
        if (!valid || !pawn) {
            *this = Schedule{};
            return 0;
        }
        if (!known_ || pawn_ != pawn) {
            known_ = true;
            pawn_ = pawn;
            open_ = open;
            pending_ = 0;
            remaining_ = 0;
            return 0;
        }
        if (open_ != open) {
            open_ = open;
            pending_ = (applied ? handle : 0);
            remaining_ = pending_ ? 2u : 0u;
            due_ = now + 250;
        }
        if (!applied || !handle || handle != pending_) {
            pending_ = 0;
            remaining_ = 0;
            return 0;
        }
        if (!remaining_ || now < due_)
            return 0;
        const auto result = pending_;
        if (--remaining_)
            due_ = now + 750;
        else
            pending_ = 0;
        return result;
    }
};
}
