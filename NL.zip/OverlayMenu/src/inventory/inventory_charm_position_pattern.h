#pragma once
#include <cstdint>
#include <string>

namespace menu::charm {

inline constexpr char PositionWriter[] = "0F 28 54 24 60 48 8D 4D 80 66 41 0F 3A 21 D4 30 0F 28 CA "
                                         "F3 0F 11 15 ? ? ? ? 0F 28 C2 0F C6 CA AA 0F C6 C2 55 "
                                         "4D 8B C5 49 8B D7 F3 0F 11 05 ? ? ? ? F3 0F 11 0D ? ? ? ?";
inline constexpr char PositionConsumer[] = "F3 0F 10 05 ? ? ? ? 48 8B 0D ? ? ? ? 48 81 C1 A0 00 00 00 "
                                           "81 48 10 80 00 00 00 F3 0F 11 40 3C 48 8B 44 24 40 "
                                           "F3 0F 10 0D ? ? ? ? 81 48 10 00 01 00 00 F3 0F 11 48 40 "
                                           "48 8B 44 24 40 F3 0F 10 05 ? ? ? ? 81 48 10 00 02 00 00 "
                                           "F3 0F 11 40 44";

template <class Image>
bool ResolvePreviewPosition(const Image& image, std::uintptr_t& out, std::string& diagnostic) {
    out = 0;
    auto w = image.Find(PositionWriter, true, 2);
    auto r = image.Find(PositionConsumer, true, 2);
    if (w.size() != 1 || r.size() != 1) {
        diagnostic = "position code missing or ambiguous";
        return false;
    }
    auto x = image.Rip(w[0] + 19, 4, 8), y = image.Rip(w[0] + 44, 4, 8), z = image.Rip(w[0] + 52, 4, 8);
    if (!x || y != x + 4 || z != x + 8 || !image.Contains(x, 12, 0x80000000, 0x20000000) ||
        image.Rip(r[0], 4, 8) != x || image.Rip(r[0] + 39, 4, 8) != y || image.Rip(r[0] + 64, 4, 8) != z) {
        diagnostic = "position targets inconsistent or not writable";
        return false;
    }
    out = x;
    diagnostic = "position code and consumer cross-checked";
    return true;
}
}
