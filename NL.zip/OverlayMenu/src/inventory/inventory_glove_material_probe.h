#pragma once

#include <cstdint>
#include <cstddef>
#include <limits>
#include <initializer_list>
namespace menu::glove_material_probe {
inline constexpr char Pattern[] =
    "E8 ? ? ? ? 4C 63 F0 49 C1 E6 04 4C 03 B7 ? ? ? ? 48 85 FF 74 32 48 8B 47 10 48 85 C0 74 29";
struct Result {
    int state = 0;
    unsigned count = 0, magic16 = 0, magic20 = 0;
};
template <class Reader> Result Inspect(Reader&& read, std::uintptr_t object, std::uint32_t offset) {
    Result r{};
    if (!object || offset < 0x40 || offset > 0x2000 || (offset & 7) ||
        object > std::numeric_limits<std::uintptr_t>::max() - offset - 16) {
        r.state = -1;
        return r;
    }
    std::uintptr_t data = 0;
    std::uint32_t count = 0;
    if (!read(object + offset, &data, sizeof data) || !read(object + offset + 8, &count, sizeof count)) {
        r.state = -2;
        return r;
    }
    r.count = count;
    if (!count) {
        r.state = 1;
        return r;
    }
    if (count > 64 || data < 0x10000 || data > std::numeric_limits<std::uintptr_t>::max() - 64 * 20 - 8) {
        r.state = -3;
        return r;
    }
    for (unsigned stride : {16u, 20u}) {
        unsigned matches = 0;
        bool ok = true;
        for (unsigned i = 0; i < count; ++i) {
            std::uint32_t id = 0;
            if (!read(data + std::uintptr_t(i) * stride + 4, &id, sizeof id)) {
                ok = false;
                break;
            }
            if (id == 0xf143b82au)
                ++matches;
        }
        if (!ok) {
            r.state = -4;
            return r;
        }
        if (stride == 16)
            r.magic16 = matches;
        else
            r.magic20 = matches;
    }
    r.state = 2;
    return r;
}
}
