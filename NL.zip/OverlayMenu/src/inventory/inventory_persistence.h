#pragma once

std::string InventoryNumber(float n);
void InventoryValidate(float n, float lo, float hi, bool integral);

void InventoryCaptureItem(const InventoryItem& it, const std::string& base,
                          std::map<std::string, std::string>& out);

void InventoryCapture(const InventoryValues& v, std::map<std::string, std::string>& out);

void InventoryRead(InventoryValues& out, const std::map<std::string, std::string>& values);
