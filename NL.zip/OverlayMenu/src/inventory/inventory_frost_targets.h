#pragma once

#include "inventory_weapon_mesh.h"
#include <algorithm>
#include <limits>
#include <vector>
namespace menu::inventory_frost {
struct SceneLayout {
    weapon_mesh::Layout mesh{};
    std::uint32_t render = 0, sceneCount = 0x38, sceneArray = 0x40, entryObject = 0x20,
                  objectAttributes = 0xa8, objectOwner = 0xc0;
    std::uintptr_t sceneObjectTable = 0;
    bool valid = false;
};
struct TargetSet {
    std::vector<std::uintptr_t> attributes;
    bool worldFound = false, hudFound = false;
    int stage = 0, detail = 0;
};
inline bool AddOffset(std::uintptr_t p, std::uintptr_t off, std::uintptr_t& out) {
    if (!p || p > std::numeric_limits<std::uintptr_t>::max() - off)
        return false;
    out = p + off;
    return true;
}

inline bool CollectEntity(weapon_mesh::Adapter& a, const SceneLayout& l, std::uintptr_t entity,
                          std::uint32_t handle, std::vector<std::uintptr_t>& out, int* detail = nullptr) {
    auto fail = [&](int d) {
        if (detail)
            *detail = d;
        return false;
    };
    if (detail)
        *detail = 0;
    std::uintptr_t at = 0, component = 0, array = 0;
    std::int32_t n = 0;
    if (!AddOffset(entity, l.render, at) || !a.Get(at, component) || !component)
        return fail(1);
    if (!AddOffset(component, l.sceneCount, at) || !a.Get(at, n) || n < 0 || n > 64)
        return fail(2);
    if (!AddOffset(component, l.sceneArray, at) || !a.Get(at, array) || (n && !array))
        return fail(3);
    std::vector<std::uintptr_t> found;
    for (int i = 0; i < n; ++i) {
        std::uintptr_t entry = 0, obj = 0, vt = 0, attr = 0;
        std::uint32_t owner = 0;

        if (!AddOffset(array, std::uintptr_t(i) * sizeof(std::uintptr_t), at) || !a.Get(at, entry))
            return fail(41);
        if (!entry)
            continue;
        if (!AddOffset(entry, l.entryObject, at) || !a.Get(at, obj))
            return fail(42);
        if (!obj)
            continue;
        if (!a.Get(obj, vt) || vt != l.sceneObjectTable)
            return fail(5);
        if (!AddOffset(obj, l.objectOwner, at) || !a.Get(at, owner) || owner != handle)
            return fail(6);
        if (!AddOffset(obj, l.objectAttributes, at) || !a.Get(at, attr))
            return fail(7);
        if (attr && std::find(found.begin(), found.end(), attr) == found.end())
            found.push_back(attr);
    }
    out = std::move(found);
    return true;
}

inline TargetSet Select(weapon_mesh::Adapter& a, const SceneLayout& l, std::uint32_t pawnHandle,
                        std::uint32_t weaponHandle) {
    TargetSet result;
    const auto& m = l.mesh;
    result.stage = 1;
    if (!l.valid || !m.valid || !l.sceneObjectTable || l.render != 0x338 || !m.ownerHandle || !m.scene ||
        !m.arms || !m.nodeOwner || !m.child || !m.next || !pawnHandle || !weaponHandle ||
        pawnHandle >= 0xfffffffeu || weaponHandle >= 0xfffffffeu)
        return result;
    auto pawn = a.Entity(pawnHandle), weapon = a.Entity(weaponHandle);
    std::uint32_t owner = 0;
    std::uintptr_t at = 0;
    result.stage = 2;
    if (!pawn || !weapon || !AddOffset(weapon, m.ownerHandle, at) || !a.Get(at, owner) ||
        a.Entity(owner) != pawn)
        return result;
    std::vector<std::uintptr_t> pawnAttrs, world;

    result.stage = 3;
    if (!CollectEntity(a, l, pawn, pawnHandle, pawnAttrs, &result.detail))
        return result;
    result.stage = 4;
    if (!CollectEntity(a, l, weapon, weaponHandle, world, &result.detail))
        return result;
    result.stage = 5;
    for (auto p : world)
        if (std::find(pawnAttrs.begin(), pawnAttrs.end(), p) != pawnAttrs.end())
            return result;
    result.attributes = world;
    result.worldFound = !world.empty();
    std::uint32_t armsHandle = 0;
    std::uintptr_t arms = 0, vt = 0, root = 0, rootOwner = 0, node = 0;
    result.stage = 6;
    if (!AddOffset(pawn, m.arms, at) || !a.Get(at, armsHandle) || !armsHandle || armsHandle >= 0xfffffffeu ||
        !(arms = a.Entity(armsHandle)) || !a.Get(arms, vt) || vt != m.armsTable ||
        !AddOffset(arms, m.scene, at) || !a.Get(at, root) || !root || !AddOffset(root, m.nodeOwner, at) ||
        !a.Get(at, rootOwner) || rootOwner != arms || !AddOffset(root, m.child, at) || !a.Get(at, node)) {
        result.attributes.clear();
        result.worldFound = false;
        return result;
    }

    std::vector<std::uintptr_t> armsAttrs;
    result.stage = 7;
    if (!CollectEntity(a, l, arms, armsHandle, armsAttrs, &result.detail)) {
        result.attributes.clear();
        result.worldFound = false;
        return result;
    }
    result.stage = 8;
    for (auto p : world)
        if (std::find(armsAttrs.begin(), armsAttrs.end(), p) != armsAttrs.end()) {
            result.attributes.clear();
            result.worldFound = false;
            return result;
        }
    result.stage = 9;
    std::vector<std::uintptr_t> seen;
    for (unsigned i = 0; node && i < 32; ++i) {
        if (std::find(seen.begin(), seen.end(), node) != seen.end())
            break;
        seen.push_back(node);
        std::uintptr_t ent = 0, ownNode = 0, next = 0;
        std::uint32_t link = 0;
        if (AddOffset(node, m.nodeOwner, at) && a.Get(at, ent) && ent && a.Get(ent, vt) &&
            vt == m.hudWeaponTable && AddOffset(ent, m.ownerHandle, at) && a.Get(at, link) &&
            a.Entity(link) == weapon && AddOffset(ent, m.scene, at) && a.Get(at, ownNode) &&
            ownNode == node) {

            std::uintptr_t identity = 0;
            std::uint32_t raw = 0, flags = 0;
            if (AddOffset(ent, 0x10, at) && a.Get(at, identity) && identity &&
                AddOffset(identity, 0x10, at) && a.Get(at, raw) && raw != 0xffffffffu &&
                AddOffset(identity, 0x30, at) && a.Get(at, flags)) {
                const auto h = (((raw >> 15) - (flags & 1u)) << 15) | (raw & 0x7fffu);
                if (a.Entity(h) == ent) {
                    std::vector<std::uintptr_t> hud;
                    if (CollectEntity(a, l, ent, h, hud, &result.detail)) {
                        bool safe = true;
                        for (auto p : hud)
                            if (std::find(pawnAttrs.begin(), pawnAttrs.end(), p) != pawnAttrs.end() ||
                                std::find(armsAttrs.begin(), armsAttrs.end(), p) != armsAttrs.end())
                                safe = false;
                        if (safe) {
                            for (auto p : hud)
                                if (std::find(result.attributes.begin(), result.attributes.end(), p) ==
                                    result.attributes.end())
                                    result.attributes.push_back(p);
                            result.hudFound = !hud.empty();
                        }
                    }
                }
            }
            break;
        }
        if (!AddOffset(node, m.next, at) || !a.Get(at, next))
            break;
        node = next;
    }
    return result;
}
}
