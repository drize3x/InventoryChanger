#pragma once
#include <algorithm>
#include <string>
namespace menu {

inline bool InventoryEconPath(const std::string& s) {
    if (s.size() < 6 || s.size() > 240 || s.compare(0, 5, "econ/") != 0)
        return false;
    std::size_t segment = 0;
    for (std::size_t i = 0; i <= s.size(); ++i) {
        if (i == s.size() || s[i] == '/') {
            const auto n = i - segment;
            if (!n || (n == 1 && s[segment] == '.') || (n == 2 && s[segment] == '.' && s[segment + 1] == '.'))
                return false;
            segment = i + 1;
        } else {
            const unsigned char c = s[i];
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' ||
                  c == '-' || c == '.'))
                return false;
        }
    }
    return true;
}
inline std::string InventoryCanonicalEconPath(std::string s) {
    if (s.compare(0, 16, "panorama/images/") == 0)
        s.erase(0, 16);

    const std::string vectorSuffix = ".vsvg_c";
    if (s.size() > vectorSuffix.size() &&
        s.compare(s.size() - vectorSuffix.size(), vectorSuffix.size(), vectorSuffix) == 0)
        s.replace(s.size() - vectorSuffix.size(), vectorSuffix.size(), ".svg");
    for (const char* suffix : {"_png.vtex_c", ".vtex_c", ".png"}) {
        const std::string tail = suffix;
        if (s.size() > tail.size() && s.compare(s.size() - tail.size(), tail.size(), tail) == 0) {
            s.resize(s.size() - tail.size());
            break;
        }
    }
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return c >= 'A' && c <= 'Z' ? char(c + 32) : char(c); });
    return InventoryEconPath(s) ? s : std::string{};
}
}
