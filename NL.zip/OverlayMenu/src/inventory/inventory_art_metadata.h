#pragma once
#include "inventory_content.h"
#include "ambience_vtex_metadata.h"
#include <deque>
#include <set>
namespace menu {

class InventoryArtMetadata {
    struct Entry {
        AmbienceCodecInfo info{AmbienceTextureCodec::Pending, {}};
        std::uint64_t stamp = 0;
    };
    mutable std::mutex mutex_;
    std::map<std::string, Entry> entries_;
    std::deque<std::string> pending_;
    std::uint64_t clock_ = 0;
    std::unique_ptr<InventoryDiskSource> disk_;
    std::unique_ptr<VPKDirectory> vpk_;
    AmbienceDecompress decompress_;
    bool mounted_ = false;
    std::set<std::string> duplicates_;
    AmbienceCodecInfo Lookup(const std::string& path) {
        if (!disk_)
            return {AmbienceTextureCodec::Unknown, "game content directory unavailable"};
        if (!mounted_) {
            mounted_ = true;
            std::string tree;
            if (disk_->Read("pak01_dir.vpk", tree))
                try {
                    vpk_ = std::make_unique<VPKDirectory>(
                        VPKParseDirectory(reinterpret_cast<const unsigned char*>(tree.data()), tree.size()));
                    std::set<std::string> seen;
                    for (const auto& e : vpk_->entries) {
                        auto key = KVLower(e.path);
                        if (key.compare(0, 21, "panorama/images/econ/") == 0 && !seen.insert(key).second)
                            duplicates_.insert(std::move(key));
                    }
                } catch (const std::exception&) {
                }
        }
        std::string raw;

        if (path.size() >= 4 && path.compare(path.size() - 4, 4, ".svg") == 0) {
            const auto logical = "panorama/images/" + path.substr(0, path.size() - 4) + ".vsvg_c";
            if (!disk_->Exists(logical) && duplicates_.count(KVLower(logical)))
                return {AmbienceTextureCodec::Unknown, "duplicate VPK econ SVG entry"};
            if (InventoryFetch(*disk_, vpk_.get(), "pak01", logical, raw) && !raw.empty() &&
                raw.size() <= 16u * 1024 * 1024)
                return {AmbienceTextureCodec::RGB, "compiled SVG; native Panorama rasterization"};
            return {AmbienceTextureCodec::Unknown, "exact local econ SVG not found"};
        }
        for (const char* suffix : {"_png.vtex_c", ".vtex_c"}) {
            const auto logical = "panorama/images/" + path + suffix;
            if (!disk_->Exists(logical) && duplicates_.count(KVLower(logical)))
                return {AmbienceTextureCodec::Unknown, "duplicate VPK econ texture entry"};
            if (InventoryFetch(*disk_, vpk_.get(), "pak01", logical, raw)) {
                if (raw.size() > 16u * 1024 * 1024)
                    return {AmbienceTextureCodec::Unknown, "econ texture exceeds read limit"};
                return ReadAmbienceVtexCodec(
                    [&](std::uint64_t at, void* out, std::size_t n) {
                        if (at > raw.size() || n > raw.size() - at)
                            return false;
                        std::memcpy(out, raw.data() + at, n);
                        return true;
                    },
                    raw.size(), decompress_);
            }
        }
        const auto png = "panorama/images/" + path + ".png";
        if (!disk_->Exists(png) && duplicates_.count(KVLower(png)))
            return {AmbienceTextureCodec::Unknown, "duplicate VPK econ PNG entry"};
        if (InventoryFetch(*disk_, vpk_.get(), "pak01", png, raw) && raw.size() >= 8 &&
            std::memcmp(raw.data(), "\x89PNG\r\n\x1a\n", 8) == 0)
            return {AmbienceTextureCodec::RGB, "loose PNG; native Panorama decode"};
        return {AmbienceTextureCodec::Unknown, "exact local econ texture not found"};
    }

public:
    void Configure(std::filesystem::path root, AmbienceDecompress decompress = {}) {
        disk_ = root.empty() ? nullptr : std::make_unique<InventoryDiskSource>(std::move(root));
        vpk_.reset();
        duplicates_.clear();
        mounted_ = false;
        decompress_ = std::move(decompress);
        std::lock_guard<std::mutex> lock(mutex_);
        entries_.clear();
        pending_.clear();
    }
    AmbienceCodecInfo Query(const std::string& path) {
        if (!InventoryEconPath(path))
            return {AmbienceTextureCodec::Unknown, "invalid econ path"};
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(path);
        if (it == entries_.end()) {
            if (entries_.size() >= 256) {
                auto oldest = entries_.end();
                for (auto i = entries_.begin(); i != entries_.end(); ++i)
                    if (i->second.info.codec != AmbienceTextureCodec::Pending &&
                        (oldest == entries_.end() || i->second.stamp < oldest->second.stamp))
                        oldest = i;
                if (oldest == entries_.end())
                    return {AmbienceTextureCodec::Pending, "metadata queue full"};
                entries_.erase(oldest);
            }
            it = entries_.emplace(path, Entry{}).first;
            pending_.push_back(path);
        }
        it->second.stamp = ++clock_;
        return it->second.info;
    }
    void Pump(unsigned budget = 2) {
        for (unsigned i = 0; i < std::min(64u, budget); ++i) {
            std::string path;
            {
                std::lock_guard<std::mutex> lock(mutex_);
                if (pending_.empty())
                    return;
                path = std::move(pending_.front());
                pending_.pop_front();
            }
            AmbienceCodecInfo info;
            try {
                info = Lookup(path);
            } catch (const std::exception&) {
                info = {AmbienceTextureCodec::Unknown, "econ metadata lookup failed"};
            }
            std::lock_guard<std::mutex> lock(mutex_);
            auto it = entries_.find(path);
            if (it != entries_.end())
                it->second.info = std::move(info);
        }
    }
    void Stop() {
        Configure({});
    }
};
}
