#pragma once

#include <cstdint>
#include <limits>
namespace menu::premier_diag {
struct Sample {
    bool found = false, read = false, modelText = false, viewPresent = false, lookupPresent = false,
         sameView = false;
    bool itemRead = false, itemModelText = false, itemIdMatch = false;
    std::int32_t handle = -1, itemHandle = -1;
    unsigned flag = 0, itemPending = 0;
    int definition = 0;
    std::uint64_t at = 0, itemId = 0;
};
template <class Reader>
Sample Read(std::uintptr_t panel, std::uintptr_t faux, std::uint64_t expectedId, int definition,
            std::uint64_t now, Reader read) {
    Sample s{};
    s.definition = definition;
    s.at = now;
    if (!panel || panel > std::numeric_limits<std::uintptr_t>::max() - 0x98d)
        return s;
    s.found = true;
    std::uintptr_t model = 0, view = 0;
    unsigned char flag = 0;
    if (read(panel + 0x538, &s.handle, sizeof s.handle) && read(panel + 0x540, &model, sizeof model) &&
        read(panel + 0x550, &view, sizeof view) && read(panel + 0x558, &flag, 1)) {
        s.read = true;
        s.flag = flag;
        s.viewPresent = view != 0;
        s.lookupPresent = faux != 0;
        s.sameView = view && faux && view == faux;
        char first = 0;
        s.modelText = model && read(model, &first, 1) && first != 0;
    }
    std::uintptr_t itemModel = 0;
    unsigned char pending = 0;
    if (read(panel + 0x8f8, &s.itemHandle, sizeof s.itemHandle) &&
        read(panel + 0x958, &itemModel, sizeof itemModel) &&
        read(panel + 0x978, &s.itemId, sizeof s.itemId) && read(panel + 0x98c, &pending, 1)) {
        s.itemRead = true;
        s.itemIdMatch = s.itemId == expectedId;
        s.itemPending = pending;
        char first = 0;
        s.itemModelText = itemModel && read(itemModel, &first, 1) && first != 0;
    }
    return s;
}
}
