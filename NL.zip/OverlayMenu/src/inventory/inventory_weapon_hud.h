#pragma once
#include <cstdint>
#include <map>
namespace menu::weapon_hud {

class Queue {
    struct Entry {
        std::uintptr_t entity;
        std::uint64_t due, expires;
        unsigned attempts;
        bool cleared;
    };
    std::map<std::uint32_t, Entry> pending_;

public:
    void Push(std::uint32_t h, std::uintptr_t e, std::uint64_t now) {
        if (!h || !e)
            return;
        if (pending_.size() >= 64 && !pending_.count(h))
            return;
        pending_[h] = {e, now, now + 4000, 0, false};
    }
    std::size_t Size() const {
        return pending_.size();
    }

    template <class Guard, class Clear, class Refresh>
    void Pump(std::uint64_t now, Guard guard, Clear clear, Refresh refresh) {
        unsigned processed = 0;
        for (auto it = pending_.begin(); it != pending_.end() && processed < 4;) {
            auto& x = it->second;
            if (now >= x.expires) {
                it = pending_.erase(it);
                continue;
            }
            if (now < x.due) {
                ++it;
                continue;
            }
            ++processed;
            int g = guard(it->first, x.entity);
            if (g == 0) {
                it = pending_.erase(it);
                continue;
            }
            if (g < 0) {
                x.due = now + 250;
                ++it;
                continue;
            }
            if (!x.cleared) {
                if (!clear(it->first, x.entity)) {
                    if (++x.attempts >= 4) {
                        it = pending_.erase(it);
                        continue;
                    }
                    x.due = now + 500;
                    ++it;
                    continue;
                }
                x.cleared = true;
                x.attempts = 0;
            }
            if (refresh(it->first)) {
                it = pending_.erase(it);
                continue;
            }
            if (++x.attempts >= 4) {
                it = pending_.erase(it);
                continue;
            }
            x.due = now + 500;
            ++it;
        }
    }
};
}
