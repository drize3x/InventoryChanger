#pragma once
#include "inventory_glove_inmatch.h"
#include "inventory_catalog.h"
namespace menu::glove_inmatch {
inline Plan MakePlan(const InventoryCatalog& catalog, const InventoryValues& cfg) {
    Plan plan;
    for (int side = 0; side < 2; ++side) {
        const auto& team = cfg.teams[std::size_t(side)];
        auto& out = plan.side[std::size_t(side)];
        if (!team.gloves || !InventoryGlove(team.gloves) || team.gloves == InventoryDefaultGlove(side))
            continue;
        out.def = team.gloves;
        if (const auto* item = team.Find(out.def))
            if (item->paintKit > 0) {
                const auto* paint = catalog.Paint(item->paintKit);
                if (!paint) {
                    out.def = 0;
                    continue;
                }
                out.finish = InventoryTargetFor(*item, out.def, 0);
                out.finish.wear =
                    InventoryWearFloat(item->wearTier, item->wearValue, paint->wearMin, paint->wearMax);
                out.palette = inventory_color::FromItem(*item);
                out.hasFinish = true;
            }
    }
    return plan;
}
}
