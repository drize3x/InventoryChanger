#pragma once

#include "inventory_local_charm_core.h"
#include "inventory_glove_identity_pin.h"
#include "inventory_decorations.h"
#include <cstdint>
#include <vector>
#include <algorithm>
#include <chrono>
namespace menu::local_weapons {
enum class Kind { Painted, Music, Medal, Agent };
struct Spec {
    int definition = 0, paint = 0, seed = 0, rarity = 1, statTrak = -1;
    float wear = 0;
    local_decorations::Values decorations{};
    Kind kind = Kind::Painted;
    bool operator==(const Spec& o) const {
        return kind == o.kind && definition == o.definition && paint == o.paint && seed == o.seed &&
               rarity == o.rarity && statTrak == o.statTrak && wear == o.wear && decorations == o.decorations;
    }
};
struct Adapter : local_charm::Adapter {
    virtual std::uintptr_t CreateWeapon(std::uint64_t, std::uint32_t, std::uint32_t, const Spec&) = 0;
};
class Controller {
    struct Entry {
        Spec spec;
        std::uintptr_t object, inventory, cache;
        local_charm::Owner owner;
        std::uint64_t id;
    };
    std::vector<Entry> entries_;
    bool uncertain_ = false;
    unsigned failureStage_ = 0;

    std::uint32_t issued_ = 0;
    std::uint32_t idSeed_ =
        std::uint32_t((std::uint64_t(std::chrono::steady_clock::now().time_since_epoch().count()) ^
                       (std::uint64_t(reinterpret_cast<std::uintptr_t>(this)) >> 4)) &
                      0xfffffU);

    void MarkFailure(unsigned stage) {
        if (!failureStage_)
            failureStage_ = stage;
        uncertain_ = true;
    }
    static bool SameOwner(const local_charm::Owner& a, const local_charm::Owner& b) {
        return a.id == b.id && a.type == b.type;
    }
    local_charm::Result Erase(Adapter& a, std::size_t n) {
        auto e = entries_[n];
        if (glove_inmatch::uncertainIdentity.load() || glove_inmatch::pinnedItem.load() == e.id)
            return local_charm::Result::Unavailable;
        local_charm::Snapshot s;
        if (!a.Capture(s))
            return local_charm::Result::Unavailable;
        if (e.inventory != s.inventory || e.cache != s.cache || !SameOwner(e.owner, s.owner)) {
            MarkFailure(1);
            return local_charm::Result::Conflict;
        }
        if (std::find(s.objects.begin(), s.objects.end(), e.object) == s.objects.end()) {
            entries_.erase(entries_.begin() + n);
            return local_charm::Result::Removed;
        }
        local_charm::Item i;
        if (!a.ItemInfo(e.object, i) || i.id != e.id) {
            MarkFailure(2);
            return local_charm::Result::Conflict;
        }
        if (!a.Notify(e.inventory, e.owner, e.object, false)) {
            MarkFailure(3);
            return local_charm::Result::Fault;
        }
        bool removed = false;
        if (!a.Remove(e.cache, e.object, removed)) {
            MarkFailure(4);
            return local_charm::Result::Fault;
        }
        if (!removed) {
            MarkFailure(5);
            return local_charm::Result::Fault;
        }
        if (!a.Destroy(e.object)) {
            MarkFailure(6);
            return local_charm::Result::Fault;
        }
        entries_.erase(entries_.begin() + n);
        return local_charm::Result::Removed;
    }
    local_charm::Result Insert(Adapter& a, const Spec& spec) {
        local_charm::Snapshot s;
        if (!a.Capture(s) || !s.inventory || !s.cache || !s.owner.id || !s.owner.type)
            return local_charm::Result::Unavailable;
        std::vector<std::uint64_t> ids;
        std::uint32_t pos = 0;
        ids.reserve(s.objects.size());
        for (auto p : s.objects) {
            local_charm::Item i;
            if (!p || !a.ItemInfo(p, i))
                return local_charm::Result::Unavailable;
            ids.push_back(i.id);
            if (i.position < 0x40000000u)
                pos = std::max(pos, i.position);
        }
        if (pos >= 0x3fffffffu)
            return local_charm::Result::Unavailable;
        const std::uint64_t base = 0x0d00000000000000ULL | (std::uint64_t(std::uint32_t(s.owner.id)) << 20);
        std::uint64_t id = 0;
        while (issued_ < 0x100000U) {
            const std::uint32_t suffix = (idSeed_ + issued_++) & 0xfffffU;
            if (!suffix)
                continue;
            const auto candidate = base | suffix;
            if (std::find(ids.begin(), ids.end(), candidate) == ids.end()) {
                id = candidate;
                break;
            }
        }
        if (!id)
            return local_charm::Result::Unavailable;
        auto p = a.CreateWeapon(id, pos + 1, std::uint32_t(s.owner.id), spec);
        if (!p)
            return local_charm::Result::Unavailable;
        bool added = false;
        if (!a.Add(s.cache, p, added)) {
            entries_.push_back({spec, p, s.inventory, s.cache, s.owner, id});
            MarkFailure(7);
            return local_charm::Result::Fault;
        }
        if (!added) {
            if (!a.Destroy(p))
                MarkFailure(8);
            return uncertain_ ? local_charm::Result::Fault : local_charm::Result::Unavailable;
        }
        entries_.push_back({spec, p, s.inventory, s.cache, s.owner, id});
        if (!a.Notify(s.inventory, s.owner, p, true)) {
            MarkFailure(9);
            return local_charm::Result::Fault;
        }
        return local_charm::Result::Added;
    }

public:
    bool Find(const Spec& spec, std::uintptr_t& object, std::uintptr_t& inventory, std::uintptr_t& cache,
              local_charm::Owner& owner, std::uint64_t& id) const {
        for (const auto& e : entries_)
            if (e.spec == spec) {
                object = e.object;
                inventory = e.inventory;
                cache = e.cache;
                owner = e.owner;
                id = e.id;
                return true;
            }
        return false;
    }
    unsigned FailureStage() const {
        return failureStage_;
    }
    bool Uncertain() const {
        return uncertain_;
    }
    bool Empty() const {
        return entries_.empty();
    }
    std::size_t Size() const {
        return entries_.size();
    }
    local_charm::Result Step(Adapter& a, const std::vector<Spec>& wanted) {
        if (uncertain_)
            return local_charm::Result::Fault;

        if (!entries_.empty()) {
            local_charm::Snapshot s;
            if (!a.Capture(s))
                return local_charm::Result::Unavailable;
            for (std::size_t i = 0; i < entries_.size(); ++i) {
                const auto& e = entries_[i];
                if (e.inventory != s.inventory || e.cache != s.cache || !SameOwner(e.owner, s.owner))
                    return local_charm::Result::Conflict;
                if (std::find(s.objects.begin(), s.objects.end(), e.object) == s.objects.end()) {
                    entries_.erase(entries_.begin() + i);
                    return local_charm::Result::Removed;
                }
                local_charm::Item item;
                if (!a.ItemInfo(e.object, item) || item.id != e.id) {
                    MarkFailure(10);
                    return local_charm::Result::Conflict;
                }
            }
        }
        for (std::size_t i = 0; i < entries_.size(); ++i)
            if (std::find(wanted.begin(), wanted.end(), entries_[i].spec) == wanted.end())
                return Erase(a, i);
        for (const auto& spec : wanted) {
            bool exists = false;
            for (const auto& e : entries_)
                if (e.spec == spec) {
                    exists = true;
                    break;
                }
            if (!exists)
                return Insert(a, spec);
        }
        return local_charm::Result::Idle;
    }
};
}
