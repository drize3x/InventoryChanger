#pragma once

#include "watermark_hud_patterns.h"
namespace menu::glove_builder {
inline std::uintptr_t Resolve(const HudScanImage& image) {
    auto fn = image.Find(
        "40 55 41 56 41 57 48 8D AC 24 00 FD FF FF 48 81 EC 00 04 00 00 4C 8B B1 B0 00 00 00 4C 8B F9", true,
        2);
    auto site =
        image.Find("48 8D 8B F8 15 00 00 E8 ? ? ? ? 48 8B CB E8 ? ? ? ? 48 8B B3 88 15 00 00", true, 2);
    if (fn.size() != 1 || site.size() != 1 || image.Rip(site[0] + 7, 1, 5) != fn[0] ||
        !image.Contains(fn[0], 1, 0x20000000))
        return 0;
    unsigned char reapply[7]{}, view[7]{};
    if (!image.Bytes(fn[0] + 0xe7, reapply, 7) || std::memcmp(reapply, "\x41\x38\x9e\x9d\x17\x00\x00", 7) ||
        !image.Bytes(fn[0] + 0x1ba, view, 7) || std::memcmp(view, "\x49\x8d\xbe\xa0\x17\x00\x00", 7))
        return 0;
    return fn[0];
}

inline std::uintptr_t ResolveHideDefault(const HudScanImage& image) {
    const auto builder = Resolve(image);
    if (!builder)
        return 0;
    auto fn = image.Find("48 85 C9 0F 84 ? ? ? ? 48 89 5C 24 08 48 89 7C 24 10 55 48 8B EC 48 83 EC 30 0F B6 "
                         "DA 48 8B F9 8B 15 ? ? ? ? E8 ? ? ? ? 83 F8 FF",
                         true, 2);
    auto call = image.Find("84 C0 74 0A 33 D2 49 8B CE E8 ? ? ? ? 49 8B CE E8 ? ? ? ?", true, 2);
    if (fn.size() != 1 || call.size() != 1 || call[0] < builder || call[0] - builder > 0xd30 ||
        image.Rip(call[0] + 9, 1, 5) != fn[0] || !image.Contains(fn[0], 1, 0x20000000))
        return 0;
    return fn[0];
}

inline std::uintptr_t ResolveDefaultPredicate(const HudScanImage& image) {
    const auto builder = Resolve(image);
    if (!builder)
        return 0;
    auto site = image.Find("49 8B CE E8 ? ? ? ? 84 C0 74 1E 41 38 9E 9D 17 00 00", true, 2);
    auto fn = image.Find(
        "40 53 48 83 EC 40 48 8B D9 48 85 C9 0F 84 ? ? ? ? 8B 15 ? ? ? ? E8 ? ? ? ? 83 F8 FF", true, 2);
    if (site.size() != 1 || fn.size() != 1 || site[0] < builder || site[0] - builder > 0xd30 ||
        image.Rip(site[0] + 3, 1, 5) != fn[0] || !image.Contains(fn[0], 1, 0x20000000))
        return 0;
    return fn[0];
}

inline std::uintptr_t ResolveModelGetterForPreserve(const HudScanImage& image) {
    const auto builder = Resolve(image);
    if (!builder)
        return 0;
    auto del = image.Find("49 8B CE E8 ? ? ? ? 84 C0 74 1E 41 38 9E 9D 17 00 00 75 15 49 8B CF E8 ? ? ? ? 48 "
                          "8B C8 E8 ? ? ? ? E9 ? ? ? ?",
                          true, 2);
    auto getter = image.Find("40 53 48 83 EC 20 48 8B 41 10 48 8B DA 4C 8B 00 4D 85 C0", true, 2);
    if (del.size() != 1 || getter.size() != 1 || del[0] != builder + 0xdb ||
        !image.Contains(getter[0], 1, 0x20000000))
        return 0;
    unsigned char a = 0, b = 0;
    if (!image.Bytes(builder + 0x32, &a, 1) || a != 0xe8 || !image.Bytes(builder + 0xc2, &b, 1) || b != 0xe8)
        return 0;
    if (image.Rip(builder + 0x32, 1, 5) != getter[0] || image.Rip(builder + 0xc2, 1, 5) != getter[0])
        return 0;

    unsigned char compare[17]{};
    static const unsigned char expected[] = {0x48, 0x8b, 0x08, 0x49, 0x39, 0x8f, 0xa8, 0,   0,
                                             0,    0x74, 0x08, 0x41, 0xc6, 0x86, 0x9d, 0x17};
    if (!image.Bytes(builder + 0xc7, compare, sizeof compare) ||
        std::memcmp(compare, expected, sizeof compare))
        return 0;
    return getter[0];
}
inline bool PreserveDeleteBranch(bool enabled, bool live, bool defaultState, bool reapply, bool hasModel,
                                 bool sameModel) {
    return enabled && live && defaultState && !reapply && hasModel && sameModel;
}

inline bool IsLocal(std::uintptr_t component, std::uintptr_t local, std::uintptr_t owner) {
    return local && local <= UINTPTR_MAX - 0x15f8 && component == local + 0x15f8 && owner == local;
}
}
