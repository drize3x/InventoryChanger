#pragma once

#include "inventory_local_weapons_core.h"
#include <array>
namespace menu::knife_autoequip {
struct Desired {
    bool active = false;
    local_weapons::Spec spec{};
};
struct Slot {
    std::uint64_t id = 0;
    std::uint16_t def = 0;
};
struct Adapter {
    virtual ~Adapter() = default;
    virtual bool Capture(local_charm::Snapshot&) = 0;
    virtual bool ItemInfo(std::uintptr_t, local_charm::Item&) = 0;
    virtual bool ReadSlot(std::uintptr_t, int, Slot&) = 0;
    virtual bool WriteSlot(std::uintptr_t, int, const Slot&) = 0;
};
class Controller {
    struct Held {
        bool active = false;
        std::uintptr_t inv = 0, cache = 0, object = 0;
        local_charm::Owner owner{};
        std::uint64_t id = 0;
        int def = 0;
        Slot original{};
        local_weapons::Spec spec{};
    };
    std::array<Held, 2> held_{};
    std::array<std::uint64_t, 2> skipped_{};
    unsigned stage_ = 0;
    bool uncertain_ = false;
    static bool SameOwner(const local_charm::Owner& a, const local_charm::Owner& b) {
        return a.id == b.id && a.type == b.type;
    }
    static int Team(int side) {
        return side == 0 ? 3 : 2;
    }
    bool Restore(Adapter& a, int side, const local_charm::Snapshot& s) {
        auto& h = held_[side];
        if (!h.active)
            return true;
        if (s.inventory != h.inv || s.cache != h.cache || !SameOwner(s.owner, h.owner)) {
            stage_ = 1;
            return false;
        }
        Slot cur;
        if (!a.ReadSlot(h.inv, Team(side), cur)) {
            stage_ = 2;
            return false;
        }
        if (cur.id != h.id) {
            skipped_[side] = h.id;
            h = {};
            return true;
        }
        if (cur.def != h.def) {
            stage_ = 3;
            return false;
        }
        if (!a.WriteSlot(h.inv, Team(side), h.original)) {
            stage_ = 4;
            uncertain_ = true;
            return false;
        }
        Slot check;
        if (!a.ReadSlot(h.inv, Team(side), check) || check.id != h.original.id ||
            check.def != h.original.def) {
            stage_ = 5;
            uncertain_ = true;
            return false;
        }
        h = {};
        return true;
    }

public:
    unsigned Stage() const {
        return stage_;
    }
    unsigned Count() const {
        return unsigned(held_[0].active) + unsigned(held_[1].active);
    }

    bool Before(Adapter& a, const std::array<Desired, 2>& desired) {
        if (uncertain_)
            return false;
        if (!Count()) {
            stage_ = 0;
            return true;
        }
        local_charm::Snapshot s;
        if (!a.Capture(s)) {
            stage_ = 6;
            return false;
        }
        for (int i = 0; i < 2; ++i) {
            auto& h = held_[i];
            if (!h.active)
                continue;
            bool valid = std::find(s.objects.begin(), s.objects.end(), h.object) != s.objects.end();
            if (!desired[i].active || !(desired[i].spec == h.spec) || !valid) {
                if (!Restore(a, i, s))
                    return false;
            } else {
                Slot cur;
                if (s.inventory != h.inv || s.cache != h.cache || !SameOwner(s.owner, h.owner) ||
                    !a.ReadSlot(h.inv, Team(i), cur)) {
                    stage_ = 7;
                    return false;
                }
                if (cur.id != h.id) {
                    skipped_[i] = h.id;
                    h = {};
                } else if (cur.def != h.def) {
                    stage_ = 8;
                    return false;
                }
            }
        }
        stage_ = 0;
        return true;
    }
    void After(Adapter& a, const local_weapons::Controller& items, const std::array<Desired, 2>& desired) {
        for (int i = 0; i < 2; ++i) {
            if (!desired[i].active) {
                skipped_[i] = 0;
                continue;
            }
            if (held_[i].active)
                continue;
            Held h;
            h.spec = desired[i].spec;
            h.def = h.spec.definition;
            if (!items.Find(h.spec, h.object, h.inv, h.cache, h.owner, h.id) || h.id == skipped_[i])
                continue;
            local_charm::Snapshot s;
            local_charm::Item item;
            if (!a.Capture(s) || s.inventory != h.inv || s.cache != h.cache || !SameOwner(s.owner, h.owner) ||
                std::find(s.objects.begin(), s.objects.end(), h.object) == s.objects.end() ||
                !a.ItemInfo(h.object, item) || item.id != h.id) {
                stage_ = 9;
                continue;
            }
            if (!a.ReadSlot(h.inv, Team(i), h.original) || h.original.id == h.id) {
                stage_ = 10;
                continue;
            }
            h.active = true;
            held_[i] = h;
            if (!a.WriteSlot(h.inv, Team(i), Slot{h.id, std::uint16_t(h.def)})) {
                stage_ = 11;
                uncertain_ = true;
                return;
            }
            Slot check;
            if (!a.ReadSlot(h.inv, Team(i), check) || check.id != h.id || check.def != h.def) {
                stage_ = 12;
                uncertain_ = true;
                return;
            }
            stage_ = 0;
        }
    }
};
}
