#pragma once

enum class InventoryGroup : int {
    Pistols = 0,
    MidTier,
    Rifles,
    Knives,
    Gloves,
    Other,
    Agents,
    Medals,
    Music
};
enum InventoryTeamIndex : int { InventoryCT = 0, InventoryT = 1 };
inline constexpr unsigned InventoryTeamCT = 1, InventoryTeamT = 2, InventoryTeamBoth = 3;
struct InventoryWeaponInfo {
    int index;
    const char* id;
    const char* name;
    InventoryGroup group;
    unsigned teams;
    bool scoped;
};

inline constexpr std::array<InventoryWeaponInfo, 35> InventoryWeapons{{
    {32, "weapon_hkp2000", "P2000", InventoryGroup::Pistols, InventoryTeamCT, false},
    {61, "weapon_usp_silencer", "USP-S", InventoryGroup::Pistols, InventoryTeamCT, false},
    {4, "weapon_glock", "Glock-18", InventoryGroup::Pistols, InventoryTeamT, false},
    {36, "weapon_p250", "P250", InventoryGroup::Pistols, InventoryTeamBoth, false},
    {63, "weapon_cz75a", "CZ75-Auto", InventoryGroup::Pistols, InventoryTeamBoth, false},
    {3, "weapon_fiveseven", "Five-SeveN", InventoryGroup::Pistols, InventoryTeamCT, false},
    {30, "weapon_tec9", "Tec-9", InventoryGroup::Pistols, InventoryTeamT, false},
    {2, "weapon_elite", "Dual Berettas", InventoryGroup::Pistols, InventoryTeamBoth, false},
    {1, "weapon_deagle", "Desert Eagle", InventoryGroup::Pistols, InventoryTeamBoth, false},
    {64, "weapon_revolver", "R8 Revolver", InventoryGroup::Pistols, InventoryTeamBoth, false},
    {13, "weapon_galilar", "Galil AR", InventoryGroup::Rifles, InventoryTeamT, false},
    {10, "weapon_famas", "FAMAS", InventoryGroup::Rifles, InventoryTeamCT, false},
    {7, "weapon_ak47", "AK-47", InventoryGroup::Rifles, InventoryTeamT, false},
    {16, "weapon_m4a1", "M4A4", InventoryGroup::Rifles, InventoryTeamCT, false},
    {60, "weapon_m4a1_silencer", "M4A1-S", InventoryGroup::Rifles, InventoryTeamCT, false},
    {39, "weapon_sg556", "SG 553", InventoryGroup::Rifles, InventoryTeamT, true},
    {8, "weapon_aug", "AUG", InventoryGroup::Rifles, InventoryTeamCT, true},
    {40, "weapon_ssg08", "SSG 08", InventoryGroup::Rifles, InventoryTeamBoth, true},
    {9, "weapon_awp", "AWP", InventoryGroup::Rifles, InventoryTeamBoth, true},
    {11, "weapon_g3sg1", "G3SG1", InventoryGroup::Rifles, InventoryTeamT, true},
    {38, "weapon_scar20", "SCAR-20", InventoryGroup::Rifles, InventoryTeamCT, true},
    {33, "weapon_mp7", "MP7", InventoryGroup::MidTier, InventoryTeamBoth, false},
    {34, "weapon_mp9", "MP9", InventoryGroup::MidTier, InventoryTeamCT, false},
    {17, "weapon_mac10", "MAC-10", InventoryGroup::MidTier, InventoryTeamT, false},
    {24, "weapon_ump45", "UMP-45", InventoryGroup::MidTier, InventoryTeamBoth, false},
    {23, "weapon_mp5sd", "MP5-SD", InventoryGroup::MidTier, InventoryTeamBoth, false},
    {19, "weapon_p90", "P90", InventoryGroup::MidTier, InventoryTeamBoth, false},
    {26, "weapon_bizon", "PP-Bizon", InventoryGroup::MidTier, InventoryTeamBoth, false},
    {35, "weapon_nova", "Nova", InventoryGroup::MidTier, InventoryTeamBoth, false},
    {25, "weapon_xm1014", "XM1014", InventoryGroup::MidTier, InventoryTeamBoth, false},
    {27, "weapon_mag7", "MAG-7", InventoryGroup::MidTier, InventoryTeamCT, false},
    {29, "weapon_sawedoff", "Sawed-Off", InventoryGroup::MidTier, InventoryTeamT, false},
    {14, "weapon_m249", "M249", InventoryGroup::MidTier, InventoryTeamBoth, false},
    {28, "weapon_negev", "Negev", InventoryGroup::MidTier, InventoryTeamBoth, false},
    {31, "weapon_taser", "Zeus x27", InventoryGroup::Other, InventoryTeamBoth, false},
}};

struct InventoryModelInfo {
    int index;
    const char* id;
    const char* name;
    unsigned teams;
};
inline constexpr std::array<InventoryModelInfo, 22> InventoryKnives{{
    {42, "weapon_knife", "Knife", InventoryTeamCT},
    {59, "weapon_knife_t", "Knife", InventoryTeamT},
    {500, "weapon_bayonet", "Bayonet", InventoryTeamBoth},
    {503, "weapon_knife_css", "Classic Knife", InventoryTeamBoth},
    {505, "weapon_knife_flip", "Flip Knife", InventoryTeamBoth},
    {506, "weapon_knife_gut", "Gut Knife", InventoryTeamBoth},
    {507, "weapon_knife_karambit", "Karambit", InventoryTeamBoth},
    {508, "weapon_knife_m9_bayonet", "M9 Bayonet", InventoryTeamBoth},
    {509, "weapon_knife_tactical", "Huntsman Knife", InventoryTeamBoth},
    {512, "weapon_knife_falchion", "Falchion Knife", InventoryTeamBoth},
    {514, "weapon_knife_survival_bowie", "Bowie Knife", InventoryTeamBoth},
    {515, "weapon_knife_butterfly", "Butterfly Knife", InventoryTeamBoth},
    {516, "weapon_knife_push", "Shadow Daggers", InventoryTeamBoth},
    {517, "weapon_knife_cord", "Paracord Knife", InventoryTeamBoth},
    {518, "weapon_knife_canis", "Survival Knife", InventoryTeamBoth},
    {519, "weapon_knife_ursus", "Ursus Knife", InventoryTeamBoth},
    {520, "weapon_knife_gypsy_jackknife", "Navaja Knife", InventoryTeamBoth},
    {521, "weapon_knife_outdoor", "Nomad Knife", InventoryTeamBoth},
    {522, "weapon_knife_stiletto", "Stiletto Knife", InventoryTeamBoth},
    {523, "weapon_knife_widowmaker", "Talon Knife", InventoryTeamBoth},
    {525, "weapon_knife_skeleton", "Skeleton Knife", InventoryTeamBoth},
    {526, "weapon_knife_kukri", "Kukri Knife", InventoryTeamBoth},
}};
inline constexpr std::array<InventoryModelInfo, 10> InventoryGloves{{
    {5029, "ct_gloves", "Default CT Gloves", InventoryTeamCT},
    {5028, "t_gloves", "Default T Gloves", InventoryTeamT},
    {4725, "studded_brokenfang_gloves", "Broken Fang Gloves", InventoryTeamBoth},
    {5027, "studded_bloodhound_gloves", "Bloodhound Gloves", InventoryTeamBoth},
    {5030, "sporty_gloves", "Sport Gloves", InventoryTeamBoth},
    {5031, "slick_gloves", "Driver Gloves", InventoryTeamBoth},
    {5032, "leather_handwraps", "Hand Wraps", InventoryTeamBoth},
    {5033, "motorcycle_gloves", "Moto Gloves", InventoryTeamBoth},
    {5034, "specialist_gloves", "Specialist Gloves", InventoryTeamBoth},
    {5035, "studded_hydra_gloves", "Hydra Gloves", InventoryTeamBoth},
}};
const InventoryWeaponInfo* InventoryWeapon(int index);
const InventoryModelInfo* InventoryKnife(int index);
const InventoryModelInfo* InventoryGlove(int index);
bool InventoryIsKnife(int index);
bool InventoryIsGlove(int index);
int InventoryDefaultKnife(int team);
int InventoryDefaultGlove(int team);
bool InventoryTeamAllows(unsigned teams, int team);

inline constexpr std::array<std::array<int, 15>, 2> InventoryDefaultSlots{{
    {{61, 2, 36, 3, 1, 35, 25, 34, 23, 19, 10, 16, 40, 8, 9}},
    {{4, 2, 36, 30, 1, 35, 25, 23, 19, 17, 13, 7, 40, 39, 9}},
}};
InventoryGroup InventorySlotGroup(int slot);

inline constexpr std::array<float, 6> InventoryWearEdges{{0.f, .07f, .15f, .38f, .45f, 1.f}};
inline constexpr std::array<const char*, 5> InventoryWearKeys{
    {"SFUI_InvTooltip_Wear_Amount_0", "SFUI_InvTooltip_Wear_Amount_1", "SFUI_InvTooltip_Wear_Amount_2",
     "SFUI_InvTooltip_Wear_Amount_3", "SFUI_InvTooltip_Wear_Amount_4"}};
inline constexpr std::array<const char*, 5> InventoryWearNames{
    {"Factory New", "Minimal Wear", "Field-Tested", "Well-Worn", "Battle-Scarred"}};

std::vector<int> InventoryWearTiers(float lo, float hi);
float InventoryWearFloat(int tier, int percent, float lo = 0, float hi = 1);

inline constexpr std::array<const char*, 8> InventoryRarityIds{
    {"default", "common", "uncommon", "rare", "mythical", "legendary", "ancient", "immortal"}};
Color InventoryRarityColor(int r);
struct InventorySticker {
    int id = 0;
    float x = 0, y = 0, rotation = 0;
    bool operator==(const InventorySticker& o) const {
        return id == o.id && x == o.x && y == o.y && rotation == o.rotation;
    }
};
struct InventoryCharm {
    int id = 0, pattern = 0;
    float x = 0, y = 0, z = 0;
    bool operator==(const InventoryCharm& o) const {
        return id == o.id && pattern == o.pattern && x == o.x && y == o.y && z == o.z;
    }
};
bool InventorySameColor(Color a, Color b);

struct InventoryItem {
    int index = 0;
    int paintKit = 0;
    int seed = 0;
    int wearTier = 0;
    int wearValue = 0;
    int statTrak = 0;
    int statTrakValue = 0;
    std::string name;
    Color colors{1, 1, 1, 1};
    std::array<Color, 4> paintColors{};
    unsigned paintColorMask = 0;
    std::array<int, 3> animations{{0, 0, 0}};
    bool chams = false;
    std::array<Color, 4> chamsColors{{{1, 1, 1, 1}, {1, 1, 1, 1}, {1, 1, 1, 1}, {1, 1, 1, 1}}};
    bool colorizeStatTrak = false;
    Color statTrakColor{1, 1, 1, 1};
    bool glow = false;
    Color glowColor{1, 1, 1, 1};
    bool clothPhysics = false, removeSleeves = false, bothTeams = false, frost = false;
    std::array<InventorySticker, 5> stickers{};
    InventoryCharm charm{};
    bool Default() const {
        InventoryItem d;
        d.index = index;
        return *this == d;
    }
    bool operator==(const InventoryItem& o) const {
        if (index != o.index || paintKit != o.paintKit || seed != o.seed || wearTier != o.wearTier ||
            wearValue != o.wearValue || statTrak != o.statTrak || statTrakValue != o.statTrakValue ||
            name != o.name || !InventorySameColor(colors, o.colors) || animations != o.animations)
            return false;
        if (paintColorMask != o.paintColorMask)
            return false;
        for (std::size_t i = 0; i < 4; ++i)
            if ((paintColorMask & (1u << i)) && !InventorySameColor(paintColors[i], o.paintColors[i]))
                return false;
        if (chams != o.chams || colorizeStatTrak != o.colorizeStatTrak || glow != o.glow ||
            !InventorySameColor(statTrakColor, o.statTrakColor) ||
            !InventorySameColor(glowColor, o.glowColor))
            return false;
        for (std::size_t i = 0; i < 4; ++i)
            if (!InventorySameColor(chamsColors[i], o.chamsColors[i]))
                return false;
        return clothPhysics == o.clothPhysics && removeSleeves == o.removeSleeves &&
               bothTeams == o.bothTeams && frost == o.frost && stickers == o.stickers && charm == o.charm;
    }
};
struct InventoryLoadout {
    std::array<int, 15> slots{};
    int knife = 0, gloves = 0, agent = 0, medal = 0, music = 0;
    std::vector<InventoryItem> items;
    const InventoryItem* Find(int index) const {
        for (const auto& i : items)
            if (i.index == index)
                return &i;
        return nullptr;
    }
    InventoryItem& Edit(int index) {
        for (auto& i : items)
            if (i.index == index)
                return i;
        InventoryItem n;
        n.index = index;
        items.push_back(n);
        return items.back();
    }
    void Prune() {
        items.erase(
            std::remove_if(items.begin(), items.end(), [](const InventoryItem& i) { return i.Default(); }),
            items.end());
    }
};
struct InventoryValues {
    std::array<InventoryLoadout, 2> teams;
    InventoryValues() {
        for (int t = 0; t < 2; ++t)
            teams[std::size_t(t)].slots = InventoryDefaultSlots[std::size_t(t)];
    }
    int Knife(int team) const {
        int k = teams[std::size_t(team)].knife;
        return k ? k : InventoryDefaultKnife(team);
    }
    int Gloves(int team) const {
        int g = teams[std::size_t(team)].gloves;
        return g ? g : InventoryDefaultGlove(team);
    }
};

bool InventorySelectedForLocalCopy(const InventoryLoadout& loadout, int team, int index);

inline constexpr std::size_t InventoryMaxName = 20, InventoryMaxItems = 96;
bool InventoryValidSlotWeapon(int team, int slot, int index);
bool InventoryConfigurable(int index);
