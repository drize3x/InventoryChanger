#pragma once

#include "watermark_hud_patterns.h"
#include <array>
#include <cmath>
namespace menu::premier_color {
struct Bindings {
    std::uintptr_t entity = 0, attributes = 0, setVector = 0, names = 0, palette = 0;
};
inline constexpr char Site[] =
    "49 8B CE E8 ? ? ? ? 48 8B C8 E8 ? ? ? ? 4C 8B E0 48 85 C0 0F 84 ? ? ? ? 8B DE 48 8D 3D ? ? ? ? 4C 8D 2D "
    "? ? ? ? 66 0F 1F 44 00 00 3B 5C 24 40 73 ? 44 8B 85 E0 00 00 00 49 C1 E0 04 4D 03 C5 EB ? 4D 8B C5 8B "
    "17 49 8B CC E8 ? ? ? ? FF C3 48 83 C7 04 83 FB 05 72 ?";
inline bool Resolve(const HudScanImage& image, Bindings& out) {
    out = {};
    auto hits = image.Find(Site, true, 2);
    if (hits.size() != 1)
        return false;
    auto a = hits[0];
    Bindings b;
    b.entity = image.Rip(a + 3, 1, 5);
    b.attributes = image.Rip(a + 11, 1, 5);
    b.names = image.Rip(a + 30);
    b.palette = image.Rip(a + 37);
    b.setVector = image.Rip(a + 80, 1, 5);
    const unsigned char ent[] = {0x8b, 0x11, 0x45, 0x33, 0xd2, 0x83, 0xfa, 0xff};
    const unsigned char attr[] = {0x40, 0x57, 0x48, 0x83, 0xec, 0x20, 0x48,
                                  0x83, 0xb9, 0xe8, 0x05, 0x00, 0x00, 0x00};
    const unsigned char set[] = {0x48, 0x89, 0x5c, 0x24, 0x18, 0x48, 0x89, 0x7c, 0x24, 0x20,
                                 0x41, 0x56, 0x48, 0x83, 0xec, 0x40, 0x41, 0x0f, 0x10, 0x00};
    auto same = [&](std::uintptr_t p, const unsigned char* expect, std::size_t n) {
        unsigned char buf[32]{};
        return image.Contains(p, n, 0x20000000) && n <= sizeof buf && image.Bytes(p, buf, n) &&
               std::memcmp(buf, expect, n) == 0;
    };
    if (!same(b.entity, ent, sizeof ent) || !same(b.attributes, attr, sizeof attr) ||
        !same(b.setVector, set, sizeof set) || !image.Contains(b.names, 24, 0x80000000, 0x20000000) ||
        !image.Contains(b.palette, 128, 0x40000000, 0x20000000))
        return false;
    std::array<float, 32> palette{};
    if (!image.Bytes(b.palette, palette.data(), sizeof palette))
        return false;
    for (float x : palette)
        if (!std::isfinite(x) || x < 0 || x > 1.001f)
            return false;
    if (std::abs(palette[5 * 4] - 0.94117647f) > 0.001f ||
        std::abs(palette[7 * 4 + 1] - 0.84313725f) > 0.001f)
        return false;
    out = b;
    return true;
}
inline bool Valid(int color, int bars) {
    return color >= 0 && color <= 7 && bars >= 0 && bars <= 5;
}
inline std::array<float, 24> BuildVectors(const std::array<float, 32>& palette, int color, int bars) {
    std::array<float, 24> out{};
    if (!Valid(color, bars))
        return out;
    for (int i = 0; i < bars; ++i)
        for (int k = 0; k < 4; ++k)
            out[std::size_t(i) * 4 + k] = palette[std::size_t(color) * 4 + k];
    out[20] = color == 7 ? 1.f : 0.f;
    return out;
}
}
