#pragma once

#include <Windows.h>
#include <MinHook.h>
#include <atomic>
#include <mutex>
#include "inventory_premier_trace_patterns.h"
#include "inventory_premier_scene_capture.h"
#include "inventory_premier_draw_trace_win32.h"
namespace menu {
class PremierSceneTrace {
    using Update = void(__fastcall*)(void*, void*);
    inline static std::atomic<PremierSceneTrace*> instance_{nullptr};
    inline static std::atomic<Update> pass_{nullptr};
    void* hook_ = nullptr;
    Update original_ = nullptr;
    bool created_ = false;
    std::atomic<bool> enabled_{false};
    std::atomic<bool> stopping_{false};
    std::atomic<unsigned> active_{0}, matched_{0};
    std::atomic<std::uintptr_t> target_{0};
    std::atomic<ULONGLONG> until_{0};
    std::atomic<std::uint64_t> epoch_{0};
    mutable std::mutex mutex_;
    premier_scene_capture::Snapshot latest_{}, best_{};
    std::uint64_t latestEpoch_ = 0;
    int bestPending_ = -1;
    unsigned switches_ = 0;
    static bool Read(std::uintptr_t p, void* out, std::size_t n) {
        SIZE_T k = 0;
        return p && ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(p), out, n, &k) &&
               k == n;
    }
    void Observe(void* store, void* scene, std::uint64_t e, int pending) noexcept {
        try {
            const auto now = GetTickCount64();
            if (stopping_ ||
                target_.load(std::memory_order_acquire) != reinterpret_cast<std::uintptr_t>(store) ||
                epoch_.load(std::memory_order_acquire) != e || now > until_.load(std::memory_order_acquire))
                return;
            auto s =
                premier_scene_capture::Read(reinterpret_cast<std::uintptr_t>(scene),
                                            [](auto a, void* p, std::size_t n) { return Read(a, p, n); });
            std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
            if (!lock)
                return;
            if (epoch_.load(std::memory_order_acquire) != e ||
                target_.load(std::memory_order_acquire) != reinterpret_cast<std::uintptr_t>(store))
                return;
            if (latest_.scene && s.scene && latest_.scene != s.scene)
                ++switches_;
            if (s.stage == 4)
                PremierDrawTrace::Instance().Publish(s.scene);
            latest_ = s;
            if (pending > bestPending_) {
                best_ = s;
                bestPending_ = pending;
            }
            latestEpoch_ = e;
            matched_.fetch_add(1, std::memory_order_relaxed);
        } catch (...) {
        }
    }
    static void __fastcall Hook(void* store, void* scene) {
        auto next = pass_.load(std::memory_order_acquire);
        if (!next)
            return;
        auto self = instance_.load(std::memory_order_acquire);
        if (!self) {
            next(store, scene);
            return;
        }
        ++self->active_;
        const auto e = self->epoch_.load(std::memory_order_acquire);
        const auto selected = self->target_.load(std::memory_order_acquire);
        const bool watch = selected && !self->stopping_.load(std::memory_order_acquire) &&
                           selected == reinterpret_cast<std::uintptr_t>(store) &&
                           GetTickCount64() <= self->until_.load(std::memory_order_acquire);
        if (watch && scene)
            PremierDrawTrace::Instance().Publish(reinterpret_cast<std::uintptr_t>(scene));
        int pending = -1;
        if (watch && selected <= std::numeric_limits<std::uintptr_t>::max() - 0x48) {
            int n = -1;
            if (Read(selected + 0x48, &n, sizeof n) && n >= 0 && n <= 256)
                pending = n;
        }
#ifdef MENU_STUDIO_PREMIER_TRACE_TEST
        try {
            next(store, scene);
            if (watch)
                self->Observe(store, scene, e, pending);
        } catch (...) {
            --self->active_;
            throw;
        }
        --self->active_;
#else
        __try {
            next(store, scene);
            if (watch)
                self->Observe(store, scene, e, pending);
        } __finally {
            --self->active_;
        }
#endif
    }

public:
    bool Start(const HudScanImage& image, std::string& result) {
        if (enabled_)
            return true;
        auto addr = premier_trace::Resolve(image);
        if (!addr) {
            result = "Premier scene trace disabled: signature mismatch";
            return false;
        }
        hook_ = reinterpret_cast<void*>(addr);
        instance_.store(this, std::memory_order_release);
        if (MH_CreateHook(hook_, reinterpret_cast<void*>(Hook), reinterpret_cast<void**>(&original_)) !=
            MH_OK) {
            instance_ = nullptr;
            result = "Premier scene trace hook create failed";
            return false;
        }
        created_ = true;
        pass_.store(original_, std::memory_order_release);
        if (MH_EnableHook(hook_) != MH_OK) {
            Stop();
            result = "Premier scene trace hook enable failed";
            return false;
        }
        enabled_ = true;
        result = "Premier scene trace armed: passthrough/read-only, unverified";
        return true;
    }
    void Arm(std::uintptr_t store, std::uint32_t handle = 0xffffffffu) noexcept {
        PremierDrawTrace::Instance().Arm(handle);
        target_.store(0, std::memory_order_release);
        const auto e = epoch_.fetch_add(1, std::memory_order_acq_rel) + 1;
        try {
            std::unique_lock<std::mutex> lock(mutex_, std::try_to_lock);
            if (!lock)
                return;
            latest_ = {};
            best_ = {};
            bestPending_ = -1;
            switches_ = 0;
            latestEpoch_ = e;
            matched_.store(0, std::memory_order_relaxed);
            until_.store(GetTickCount64() + 2500, std::memory_order_release);
            if (enabled_ && !stopping_ && store)
                target_.store(store, std::memory_order_release);
        } catch (...) {
        }
    }
    void Clear() {
        PremierDrawTrace::Instance().Clear();
        target_.store(0, std::memory_order_release);
        epoch_.fetch_add(1, std::memory_order_acq_rel);
    }
    struct Sample {
        bool enabled = false, current = false;
        unsigned matched = 0, switches = 0;
        int bestPending = -1;
        premier_scene_capture::Snapshot snapshot{}, last{};
    };
    Sample Get() const {
        Sample out;
        out.enabled = enabled_;
        out.matched = matched_.load(std::memory_order_relaxed);
        std::lock_guard<std::mutex> lock(mutex_);
        out.current = latestEpoch_ == epoch_.load(std::memory_order_acquire);
        if (out.current) {
            out.snapshot = best_;
            out.last = latest_;
            out.bestPending = bestPending_;
            out.switches = switches_;
        }
        return out;
    }
    bool Stop() {
        stopping_ = true;
        Clear();
        if (enabled_) {
            auto s = MH_DisableHook(hook_);
            if (s != MH_OK && s != MH_ERROR_DISABLED)
                return false;
            enabled_ = false;
        }
        const auto end = GetTickCount64() + 2000;
        while (active_ && GetTickCount64() < end)
            Sleep(1);
        if (active_)
            return false;
        if (created_) {
            Sleep(100);
            if (active_ || MH_RemoveHook(hook_) != MH_OK)
                return false;
            created_ = false;
        }
        if (instance_.load() == this)
            instance_ = nullptr;
        pass_.store(nullptr, std::memory_order_release);
        return true;
    }
};
}
