#pragma once
#include "watermark_hud_patterns.h"
namespace menu {

inline constexpr char LiveESPViewPattern[] = "48 63 C1 48 8D 0D ? ? ? ? 48 C1 E0 06 48 03 C1 C3";
struct LiveESPAddresses {
    std::uintptr_t entities = 0, local = 0, matrix = 0;
};
inline bool LiveESPResolve(const HudScanImage& image, LiveESPAddresses& result, std::string& diagnostic) {
    result = {};
    LiveESPAddresses a;
    auto view = image.Find(LiveESPViewPattern, true, 2);
    std::vector<std::uintptr_t> entities, locals;
    for (const auto& part : image.parts) {
        if (!(part.flags & 0x20000000))
            continue;
        for (auto i : WatermarkKdMatches(part.bytes.data(), part.bytes.size(), WatermarkKdEntityPattern))
            entities.push_back(part.start + i);
        for (auto i : WatermarkKdMatches(part.bytes.data(), part.bytes.size(), WatermarkKdLocalPattern))
            locals.push_back(part.start + i);
    }
    diagnostic = "view=" + std::to_string(view.size()) + ", entities=" + std::to_string(entities.size()) +
                 ", local=" + std::to_string(locals.size());
    if (view.size() != 1 || entities.size() != 1) {
        diagnostic += "; unsupported/ambiguous signatures";
        return false;
    }

    unsigned char body[128]{};
    if (!image.Bytes(entities[0], body, sizeof(body))) {
        diagnostic += "; entity instruction range unreadable";
        return false;
    }
    static constexpr std::array<int, 12> pages{
        {0x48, 0xC1, 0xE8, 0x09, 0x48, 0x8B, 0x54, 0xC1, 0x10, 0x48, 0x85, 0xD2}};
    static constexpr std::array<int, 4> stride{{0x48, 0x6B, 0xC0, 0x70}};
    if (WatermarkKdMatches(body, sizeof(body), pages).empty() ||
        WatermarkKdMatches(body, sizeof(body), stride).empty()) {
        diagnostic += "; unsupported entity layout";
        return false;
    }
    a.entities = image.Rip(entities[0]);
    a.matrix = image.Rip(view[0] + 3);
    if (locals.size() == 1)
        a.local = image.Rip(locals[0]);
    if (!image.Contains(a.entities, 8, 0x80000000, 0x20000000) ||
        !image.Contains(a.matrix, 64, 0x80000000, 0x20000000) ||
        (a.local && !image.Contains(a.local, 8, 0x80000000, 0x20000000))) {
        diagnostic += "; invalid data target";
        return false;
    }
    result = a;
    diagnostic += "; patterns resolved, runtime projection not certified";
    return true;
}
}
