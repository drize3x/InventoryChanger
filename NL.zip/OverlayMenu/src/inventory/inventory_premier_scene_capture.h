#pragma once

#include <array>
#include <cstdint>
#include <limits>
#include "inventory_premier_scene_diag.h"
namespace menu::premier_scene_capture {
struct Snapshot {
    unsigned stage = 0, mask = 0;
    std::uintptr_t scene = 0, map = 0;
    std::array<std::array<float, 4>, 6> values{};
};
template <class Reader> Snapshot Read(std::uintptr_t scene, Reader read) {
    Snapshot s{};
    s.scene = scene;
    auto add = [](std::uintptr_t a, std::uintptr_t b) {
        return a && a <= std::numeric_limits<std::uintptr_t>::max() - b ? a + b : std::uintptr_t(0);
    };
    auto r = [&](std::uintptr_t a, auto& v) { return a && read(a, &v, sizeof v); };
    if (!scene)
        return s;
    s.stage = 1;
    if (!r(add(scene, 0xa8), s.map))
        return s;
    s.stage = 2;
    if (!s.map)
        return s;
    s.stage = 3;
    auto slots = [&](std::uintptr_t base, unsigned count, std::uintptr_t keys, std::uintptr_t vals) {
        for (unsigned i = 0; i < count; ++i) {
            std::uint32_t k = 0;
            if (!r(add(base, keys + i * 4), k))
                return false;
            for (unsigned j = 0; j < 6; ++j)
                if (k && k == premier_scene_diag::ShaderNames[j]) {
                    if (!r(add(base, vals + i * 16), s.values[j]))
                        return false;
                    s.mask |= 1u << j;
                }
        }
        return true;
    };
    if (!slots(s.map, 8, 0, 0x20))
        return s;
    std::uintptr_t chain = 0;
    if (!r(add(s.map, 0xa8), chain))
        return s;
    for (unsigned i = 0; chain && i < 64; ++i) {
        if (!slots(chain, 4, 0x10, 0x20))
            return s;
        std::uintptr_t next = 0;
        if (!r(chain, next) || next == chain)
            return s;
        chain = next;
    }
    if (chain)
        return s;
    s.stage = 4;
    return s;
}
}
