#pragma once

#include "inventory_local_weapons_core.h"
#include <algorithm>
#include <cstdint>
#include <vector>
#include <unordered_map>
namespace menu::local_autoequip {
enum class Category { Weapon, Gloves, Agent, Music, Medal };
struct Desired {
    int team = 0;
    Category category = Category::Weapon;
    local_weapons::Spec spec{};
    int slotHint = -1;
};
struct Slot {
    std::uint64_t id = 0;
    std::uint16_t def = 0;
};
struct Adapter {
    virtual ~Adapter() = default;
    virtual bool Capture(local_charm::Snapshot&) = 0;
    virtual bool ItemInfo(std::uintptr_t, local_charm::Item&) = 0;
    virtual bool ItemDefinition(std::uintptr_t, std::uint16_t&) = 0;
    virtual bool ReadEquipSlot(std::uintptr_t, int, int, Slot&) = 0;

    virtual bool ResolvedDefinition(std::uintptr_t, int, int, std::uint16_t&) {
        return false;
    }
    virtual bool NativeLoadoutAvailable() const {
        return false;
    }
    virtual bool ResolvedIdentity(std::uintptr_t, int, int, std::uint16_t&, std::uint64_t&) {
        return false;
    }
    virtual bool WriteEquipSlot(std::uintptr_t, int, int, const Slot&) = 0;
};
class Controller {
    struct Held {
        Desired desired{};
        int slot = 0;
        std::uintptr_t inv = 0, cache = 0, object = 0;
        local_charm::Owner owner{};
        std::uint64_t id = 0;
        Slot original{};
    };
    struct Rejected {
        Desired desired;
        std::uint64_t id;
    };
    std::vector<Held> held_;
    std::vector<Rejected> rejected_;
    std::vector<std::uint64_t> skipped_;
    unsigned stage_ = 0, unmatched_ = 0;
    bool uncertain_ = false;
    static bool SameOwner(const local_charm::Owner& a, const local_charm::Owner& b) {
        return a.id == b.id && a.type == b.type;
    }
    static bool Same(const Desired& a, const Desired& b) {
        return a.team == b.team && a.category == b.category && a.spec == b.spec && a.slotHint == b.slotHint;
    }
    static bool Valid(const Desired& d) {
        if (d.category == Category::Music)
            return d.team == 0 && d.spec.kind == local_weapons::Kind::Music && d.spec.definition == 1314;
        if (d.category == Category::Medal)
            return d.team == 0 && d.spec.kind == local_weapons::Kind::Medal;
        if (d.team != 2 && d.team != 3)
            return false;
        if (d.category == Category::Agent)
            return d.spec.kind == local_weapons::Kind::Agent;
        if (d.category == Category::Gloves)
            return d.spec.kind == local_weapons::Kind::Painted && d.spec.definition > 0 &&
                   d.spec.definition <= 65535;
        return d.category == Category::Weapon && d.spec.kind == local_weapons::Kind::Painted &&
               d.spec.definition > 0 && d.spec.definition <= 65535;
    }
    bool InUse(Adapter& a, std::uintptr_t inv, std::uint64_t id, bool& used) {
        used = false;
        for (int team = 0; team <= 3; ++team)
            for (int slot = 0; slot < 58; ++slot) {
                Slot s;
                if (!a.ReadEquipSlot(inv, team, slot, s))
                    return false;
                if (s.id == id) {
                    used = true;
                    return true;
                }
            }
        return true;
    }

    using Definitions = std::unordered_map<std::uint64_t, std::uint16_t>;
    static bool Definition(const Definitions& defs, const Slot& slot, std::uint16_t& def) {
        if (!slot.id) {
            def = slot.def;
            return true;
        }
        if (slot.id >= 0xf000000000000000ULL) {
            def = std::uint16_t(slot.id);
            return def != 0;
        }
        const auto it = defs.find(slot.id);
        if (it == defs.end())
            return false;
        def = it->second;
        return true;
    }
    int Resolve(Adapter& a, const local_charm::Snapshot& s, const Definitions& defs, const Desired& d) {
        if (d.category == Category::Gloves)
            return 41;
        if (d.category == Category::Agent)
            return 38;
        if (d.category == Category::Music || d.category == Category::Medal) {
            const int slot = d.category == Category::Music ? 54 : 55;
            Slot old;
            std::uint16_t def = 0;

            return a.ReadEquipSlot(s.inventory, d.team, slot, old) && Definition(defs, old, def) &&
                           def == d.spec.definition
                       ? slot
                       : -1;
        }

        if (d.category == Category::Weapon && a.NativeLoadoutAvailable() &&
            ((d.slotHint >= 2 && d.slotHint <= 6) || (d.slotHint >= 8 && d.slotHint <= 12) ||
             (d.slotHint >= 14 && d.slotHint <= 18)))
            return d.slotHint;
        int found = -1;
        for (int slot = 2; slot <= 37; ++slot) {
            if (slot >= 26 && slot <= 31)
                continue;
            Slot old;
            std::uint16_t def = 0;
            if (!a.ReadEquipSlot(s.inventory, d.team, slot, old))
                return -1;

            if (!a.ResolvedDefinition(s.inventory, d.team, slot, def) && !Definition(defs, old, def))
                continue;
            if (def == d.spec.definition) {
                if (found != -1)
                    return -1;
                found = slot;
            }
        }
        return found;
    }

public:
    unsigned Stage() const {
        return stage_;
    }
    unsigned Count() const {
        return unsigned(held_.size());
    }
    unsigned Unmatched() const {
        return unmatched_;
    }

    int GloveSlotCheck(Adapter& a, int team) const {
        auto it = std::find_if(held_.begin(), held_.end(), [&](const Held& h) {
            return h.desired.team == team && h.desired.category == Category::Gloves;
        });
        if (it == held_.end())
            return -1;
        Slot slot;
        if (!a.ReadEquipSlot(it->inv, team, it->slot, slot))
            return 1;
        if (slot.id != it->id || slot.def != it->desired.spec.definition)
            return 2;
        if (!a.NativeLoadoutAvailable())
            return 0;
        std::uint16_t def = 0;
        std::uint64_t id = 0;
        if (!a.ResolvedIdentity(it->inv, team, it->slot, def, id))
            return 3;
        return def == it->desired.spec.definition && id == it->id ? 5 : 4;
    }

    bool GloveIdentity(Adapter& a, int team, int definition, int paint, int seed, float wear,
                       std::uint64_t& id, std::uint32_t& account) const {
        id = 0;
        account = 0;
        auto it = std::find_if(held_.begin(), held_.end(), [&](const Held& h) {
            return h.desired.team == team && h.desired.category == Category::Gloves;
        });
        if (it == held_.end() || GloveSlotCheck(a, team) != 5)
            return false;
        const auto& s = it->desired.spec;
        if (s.definition != definition || s.paint != paint ||
            (paint > 0 && (s.seed != seed || s.wear != wear)))
            return false;
        id = it->id;
        account = std::uint32_t(it->owner.id);
        return id != 0 && account != 0;
    }
    bool Before(Adapter& a, const std::vector<Desired>& desired) {
        if (uncertain_)
            return false;
        if (held_.empty()) {
            stage_ = 0;
            return true;
        }
        local_charm::Snapshot s;
        if (!a.Capture(s)) {
            stage_ = 1;
            return false;
        }
        std::vector<std::size_t> release;
        for (std::size_t i = 0; i < held_.size(); ++i) {
            auto& h = held_[i];
            if (s.inventory != h.inv || s.cache != h.cache || !SameOwner(s.owner, h.owner)) {
                stage_ = 2;
                return false;
            }
            Slot current;
            if (!a.ReadEquipSlot(h.inv, h.desired.team, h.slot, current)) {
                stage_ = 3;
                return false;
            }
            bool wanted = std::find_if(desired.begin(), desired.end(),
                                       [&](const Desired& d) { return Same(d, h.desired); }) != desired.end();
            bool exists = std::find(s.objects.begin(), s.objects.end(), h.object) != s.objects.end();
            if (wanted && exists && current.id == h.id) {
                if (current.def != h.desired.spec.definition) {
                    stage_ = 4;
                    return false;
                }
                continue;
            }
            if (current.id == h.id) {
                if (current.def != h.desired.spec.definition) {
                    stage_ = 5;
                    return false;
                }
                if (!a.WriteEquipSlot(h.inv, h.desired.team, h.slot, h.original)) {
                    stage_ = 6;
                    uncertain_ = true;
                    return false;
                }
                Slot check;
                if (!a.ReadEquipSlot(h.inv, h.desired.team, h.slot, check) || check.id != h.original.id ||
                    check.def != h.original.def) {
                    stage_ = 7;
                    uncertain_ = true;
                    return false;
                }
            } else if (std::find(skipped_.begin(), skipped_.end(), h.id) == skipped_.end())
                skipped_.push_back(h.id);
            release.push_back(i);
        }

        for (auto i : release) {
            const auto& h = held_[i];
            const bool specWanted = std::find_if(desired.begin(), desired.end(), [&](const Desired& d) {
                                        return d.spec == h.desired.spec;
                                    }) != desired.end();
            if (!specWanted) {
                bool referenced = false;
                if (!InUse(a, h.inv, h.id, referenced)) {
                    stage_ = 8;
                    return false;
                }
                if (referenced) {
                    stage_ = 9;
                    return false;
                }
            }
        }
        for (auto it = release.rbegin(); it != release.rend(); ++it)
            held_.erase(held_.begin() + *it);
        stage_ = 0;
        return true;
    }
    void After(Adapter& a, const local_weapons::Controller& items, const std::vector<Desired>& desired) {
        unmatched_ = 0;
        rejected_.erase(std::remove_if(rejected_.begin(), rejected_.end(),
                                       [&](const Rejected& r) {
                                           return std::none_of(
                                               desired.begin(), desired.end(),
                                               [&](const Desired& d) { return Same(r.desired, d); });
                                       }),
                        rejected_.end());
        if (uncertain_ || desired.empty())
            return;
        if (std::all_of(desired.begin(), desired.end(), [&](const Desired& d) {
                return std::find_if(held_.begin(), held_.end(),
                                    [&](const Held& h) { return Same(h.desired, d); }) != held_.end();
            }))
            return;
        local_charm::Snapshot s;
        if (!a.Capture(s)) {
            stage_ = 10;
            return;
        }
        Definitions defs;
        defs.reserve(s.objects.size());
        for (auto p : s.objects) {
            local_charm::Item item;
            std::uint16_t def = 0;
            if (!a.ItemInfo(p, item) || !a.ItemDefinition(p, def)) {
                stage_ = 14;
                return;
            }
            defs[item.id] = def;
        }
        for (const auto& d : desired) {
            if (!Valid(d))
                continue;
            if (std::find_if(held_.begin(), held_.end(), [&](const Held& h) { return Same(h.desired, d); }) !=
                held_.end())
                continue;
            Held h;
            h.desired = d;
            if (!items.Find(d.spec, h.object, h.inv, h.cache, h.owner, h.id) || !h.id ||
                std::find(skipped_.begin(), skipped_.end(), h.id) != skipped_.end())
                continue;
            if (std::find_if(rejected_.begin(), rejected_.end(), [&](const Rejected& r) {
                    return r.id == h.id && Same(r.desired, d);
                }) != rejected_.end()) {
                ++unmatched_;
                continue;
            }
            local_charm::Item item;
            if (s.inventory != h.inv || s.cache != h.cache || !SameOwner(s.owner, h.owner) ||
                std::find(s.objects.begin(), s.objects.end(), h.object) == s.objects.end() ||
                !a.ItemInfo(h.object, item) || item.id != h.id) {
                stage_ = 11;
                continue;
            }
            h.slot = Resolve(a, s, defs, d);
            if (h.slot < 0) {
                ++unmatched_;
                continue;
            }
            if (std::find_if(held_.begin(), held_.end(), [&](const Held& x) {
                    return x.desired.team == d.team && x.slot == h.slot;
                }) != held_.end()) {
                ++unmatched_;
                continue;
            }
            if (!a.ReadEquipSlot(h.inv, d.team, h.slot, h.original) || h.original.id == h.id) {
                ++unmatched_;
                continue;
            }
            held_.push_back(h);
            if (!a.WriteEquipSlot(h.inv, d.team, h.slot, Slot{h.id, std::uint16_t(d.spec.definition)})) {
                stage_ = 12;
                uncertain_ = true;
                return;
            }
            Slot check;
            if (!a.ReadEquipSlot(h.inv, d.team, h.slot, check) || check.id != h.id ||
                check.def != d.spec.definition) {
                stage_ = 13;
                uncertain_ = true;
                return;
            }
            if (d.category == Category::Weapon && d.slotHint == h.slot && a.NativeLoadoutAvailable()) {
                std::uint16_t liveDef = 0;
                std::uint64_t liveId = 0;
                if (!a.ResolvedIdentity(h.inv, d.team, h.slot, liveDef, liveId) ||
                    liveDef != d.spec.definition || liveId != h.id) {

                    if (!a.WriteEquipSlot(h.inv, d.team, h.slot, h.original)) {
                        stage_ = 15;
                        uncertain_ = true;
                        return;
                    }
                    Slot restored;
                    if (!a.ReadEquipSlot(h.inv, d.team, h.slot, restored) || restored.id != h.original.id ||
                        restored.def != h.original.def) {
                        stage_ = 16;
                        uncertain_ = true;
                        return;
                    }
                    held_.pop_back();
                    rejected_.push_back({d, h.id});
                    ++unmatched_;
                    stage_ = 17;
                    continue;
                }
            }
            stage_ = 0;
        }
    }
};
}
