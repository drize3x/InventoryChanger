#include "presets_local.h"

namespace menu {
std::string InventoryNumber(float n) {
    char b[32];
    std::snprintf(b, sizeof b, "%.9g", double(n));
    return b;
}

void InventoryValidate(float n, float lo, float hi, bool integral) {
    if (!std::isfinite(n) || n < lo || n > hi || (integral && n != std::floor(n)))
        throw std::runtime_error("Invalid Inventory value");
}

void InventoryCaptureItem(const InventoryItem& it, const std::string& base,
                          std::map<std::string, std::string>& out) {
    InventoryItem d;
    d.index = it.index;
    if (it == d)
        return;
    auto num = [&](const char* k, float n, float lo, float hi, bool integral) {
        InventoryValidate(n, lo, hi, integral);
        out[base + k] = InventoryNumber(n);
    };
    auto col = [&](const std::string& k, Color c) {
        for (float n : {c.r, c.g, c.b, c.a})
            InventoryValidate(n, 0, 1, false);
        int j = 0;
        for (float n : {c.r, c.g, c.b, c.a})
            out[base + k + "." + std::to_string(j++)] = InventoryNumber(n);
    };
    if (it.paintKit != d.paintKit)
        num("paint", float(it.paintKit), 0, 2000000, true);
    if (it.seed != d.seed)
        num("seed", float(it.seed), 0, 1000, true);
    if (it.wearTier != d.wearTier)
        num("weartier", float(it.wearTier), 0, 4, true);
    if (it.wearValue != d.wearValue)
        num("wearvalue", float(it.wearValue), 0, 100, true);
    if (it.statTrak != d.statTrak)
        num("stattrak", float(it.statTrak), 0, 2, true);
    if (it.statTrakValue != d.statTrakValue) {
        if (it.statTrakValue < 0)
            throw std::runtime_error("Invalid Inventory value");
        out[base + "stattrakvalue"] = std::to_string(it.statTrakValue);
    }
    if (!it.name.empty()) {
        if (DecodeUTF8(it.name).size() > InventoryMaxName)
            throw std::runtime_error("Inventory name too long");
        out[base + "name"] = it.name;
    }
    if (!InventorySameColor(it.colors, d.colors))
        col("colors", it.colors);
    if (it.paintColorMask & ~15u)
        throw std::runtime_error("Invalid Inventory color mask");
    for (int c = 0; c < 4; ++c)
        if (it.paintColorMask & (1u << c))
            col("paintcolor" + std::to_string(c), it.paintColors[std::size_t(c)]);
    for (int a = 0; a < 3; ++a)
        if (it.animations[std::size_t(a)])
            num(("anim" + std::to_string(a)).c_str(), float(it.animations[std::size_t(a)]), 0, 64, true);
    if (it.chams)
        out[base + "chams"] = "1";
    for (int c = 0; c < 4; ++c)
        if (!InventorySameColor(it.chamsColors[std::size_t(c)], d.chamsColors[std::size_t(c)]))
            col("chamscolor" + std::to_string(c), it.chamsColors[std::size_t(c)]);
    if (it.colorizeStatTrak)
        out[base + "colorizestattrak"] = "1";
    if (!InventorySameColor(it.statTrakColor, d.statTrakColor))
        col("stattrakcolor", it.statTrakColor);
    if (it.glow)
        out[base + "glow"] = "1";
    if (!InventorySameColor(it.glowColor, d.glowColor))
        col("glowcolor", it.glowColor);
    if (it.clothPhysics)
        out[base + "clothphysics"] = "1";
    if (it.removeSleeves)
        out[base + "removesleeves"] = "1";
    if (it.bothTeams)
        out[base + "bothteams"] = "1";
    if (it.frost)
        out[base + "frost"] = "1";
    for (int si = 0; si < 5; ++si) {
        const auto& s = it.stickers[std::size_t(si)];
        if (s.id == 0 && s.x == 0 && s.y == 0 && s.rotation == 0)
            continue;
        auto k = "sticker" + std::to_string(si) + ".";
        num((k + "id").c_str(), float(s.id), 0, 2000000, true);
        if (s.x)
            num((k + "x").c_str(), s.x, -10, 10, false);
        if (s.y)
            num((k + "y").c_str(), s.y, -10, 10, false);
        if (s.rotation)
            num((k + "rot").c_str(), s.rotation, -360, 360, false);
    }
    if (it.charm.id || it.charm.pattern || it.charm.x || it.charm.y || it.charm.z) {
        num("charm.id", float(it.charm.id), 0, 2000000, true);
        if (it.charm.pattern)
            num("charm.pattern", float(it.charm.pattern), 0, 100000, true);
        if (it.charm.x)
            num("charm.x", it.charm.x, -25, 25, false);
        if (it.charm.y)
            num("charm.y", it.charm.y, -10, 10, false);
        if (it.charm.z)
            num("charm.z", it.charm.z, -25, 25, false);
    }
}

void InventoryCapture(const InventoryValues& v, std::map<std::string, std::string>& out) {
    const std::string root = "inventory.";
    out[root + "version"] = "1";
    InventoryValues defaults;
    for (int t = 0; t < 2; ++t) {
        const auto& team = v.teams[std::size_t(t)];
        const std::string tb = root + (t == 0 ? "ct." : "t.");
        for (int s = 0; s < 15; ++s)
            if (team.slots[std::size_t(s)] != defaults.teams[std::size_t(t)].slots[std::size_t(s)]) {
                InventoryValidate(float(team.slots[std::size_t(s)]), 0, 100000, true);
                out[tb + "slot." + std::to_string(s)] = std::to_string(team.slots[std::size_t(s)]);
            }
        auto model = [&](const char* k, int value) {
            if (value) {
                InventoryValidate(float(value), 0, 100000, true);
                out[tb + k] = std::to_string(value);
            }
        };
        model("knife", team.knife);
        model("gloves", team.gloves);
        model("agent", team.agent);
        model("medal", team.medal);
        model("music", team.music);
        if (team.items.size() > InventoryMaxItems)
            throw std::runtime_error("Too many Inventory items");
        for (const auto& it : team.items) {
            if (it.Default())
                continue;
            if (!InventoryConfigurable(it.index))
                throw std::runtime_error("Unknown Inventory item");
            InventoryCaptureItem(it, tb + "item." + std::to_string(it.index) + ".", out);
        }
    }
}

void InventoryRead(InventoryValues& out, const std::map<std::string, std::string>& values) {
    InventoryValues next;
    const std::string root = "inventory.";
    auto begin = values.lower_bound(root);
    if (begin == values.end() || begin->first.rfind(root, 0) != 0) {
        out = next;
        return;
    }
    std::set<std::string> used;
    auto version = values.find(root + "version");
    if (version == values.end() || version->second != "1")
        throw std::runtime_error("Unsupported Inventory preset version");
    used.insert(version->first);
    auto readNum = [&](const std::string& key, float lo, float hi, bool integral, float fallback) -> float {
        auto it = values.find(key);
        if (it == values.end())
            return fallback;
        used.insert(key);
        const auto& s = it->second;
        if (s.empty() || s.size() > 32)
            throw std::runtime_error("Invalid Inventory number");
        std::size_t n = 0;
        float v = std::stof(s, &n);
        if (n != s.size())
            throw std::runtime_error("Invalid Inventory number");
        InventoryValidate(v, lo, hi, integral);
        return v;
    };
    auto readInt = [&](const std::string& key, long long lo, long long hi, int fallback) -> int {
        auto it = values.find(key);
        if (it == values.end())
            return fallback;
        used.insert(key);
        const auto& t = it->second;
        if (t.empty() || t.size() > 11 ||
            !std::all_of(t.begin(), t.end(), [](unsigned char c) { return c >= '0' && c <= '9'; }) ||
            (t.size() > 1 && t[0] == '0'))
            throw std::runtime_error("Invalid Inventory integer");
        long long n = std::stoll(t);
        if (n < lo || n > hi)
            throw std::runtime_error("Invalid Inventory integer");
        return int(n);
    };
    auto readColor = [&](const std::string& key, Color fallback) -> Color {
        int present = 0;
        float ch[4] = {fallback.r, fallback.g, fallback.b, fallback.a};
        for (int j = 0; j < 4; ++j) {
            auto k = key + "." + std::to_string(j);
            if (values.count(k))
                ++present;
            ch[j] = readNum(k, 0, 1, false, ch[j]);
        }
        if (present != 0 && present != 4)
            throw std::runtime_error("Incomplete Inventory color");
        return {ch[0], ch[1], ch[2], ch[3]};
    };
    for (int t = 0; t < 2; ++t) {
        auto& team = next.teams[std::size_t(t)];
        const std::string tb = root + (t == 0 ? "ct." : "t.");
        for (int s = 0; s < 15; ++s)
            team.slots[std::size_t(s)] = int(readNum(tb + "slot." + std::to_string(s), 0, 100000, true,
                                                     float(team.slots[std::size_t(s)])));
        team.knife = int(readNum(tb + "knife", 0, 100000, true, 0));
        team.gloves = int(readNum(tb + "gloves", 0, 100000, true, 0));
        team.agent = int(readNum(tb + "agent", 0, 100000, true, 0));
        team.medal = int(readNum(tb + "medal", 0, 100000, true, 0));
        team.music = int(readNum(tb + "music", 0, 100000, true, 0));

        std::set<int> indices;
        const std::string itemPrefix = tb + "item.";
        for (auto it = values.lower_bound(itemPrefix);
             it != values.end() && it->first.rfind(itemPrefix, 0) == 0; ++it) {
            auto rest = it->first.substr(itemPrefix.size());
            auto dot = rest.find('.');
            if (dot == std::string::npos)
                throw std::runtime_error("Malformed Inventory item key");
            int idx = std::atoi(rest.substr(0, dot).c_str());
            if (std::to_string(idx) != rest.substr(0, dot))
                throw std::runtime_error("Malformed Inventory item index");
            indices.insert(idx);
        }
        if (indices.size() > InventoryMaxItems)
            throw std::runtime_error("Too many Inventory items");
        for (int idx : indices) {
            if (!InventoryConfigurable(idx))
                throw std::runtime_error("Unknown Inventory item");
            const std::string b = itemPrefix + std::to_string(idx) + ".";
            InventoryItem it;
            it.index = idx;
            it.paintKit = int(readNum(b + "paint", 0, 2000000, true, 0));
            it.seed = int(readNum(b + "seed", 0, 1000, true, 0));
            it.wearTier = int(readNum(b + "weartier", 0, 4, true, 0));
            it.wearValue = int(readNum(b + "wearvalue", 0, 100, true, 0));
            it.statTrak = int(readNum(b + "stattrak", 0, 2, true, 0));
            it.statTrakValue = readInt(b + "stattrakvalue", 0, 2147483647LL, 0);
            auto nameIt = values.find(b + "name");
            if (nameIt != values.end()) {
                used.insert(nameIt->first);
                if (DecodeUTF8(nameIt->second).size() > InventoryMaxName)
                    throw std::runtime_error("Inventory name too long");
                it.name = nameIt->second;
            }
            it.colors = readColor(b + "colors", it.colors);
            for (int c = 0; c < 4; ++c) {
                const auto k = b + "paintcolor" + std::to_string(c);
                bool present = values.count(k + ".0") || values.count(k + ".1") || values.count(k + ".2") ||
                               values.count(k + ".3");
                it.paintColors[std::size_t(c)] = readColor(k, it.paintColors[std::size_t(c)]);
                if (present)
                    it.paintColorMask |= 1u << c;
            }
            for (int a = 0; a < 3; ++a)
                it.animations[std::size_t(a)] = int(readNum(b + "anim" + std::to_string(a), 0, 64, true, 0));
            it.chams = readNum(b + "chams", 0, 1, true, 0) != 0;
            for (int c = 0; c < 4; ++c)
                it.chamsColors[std::size_t(c)] =
                    readColor(b + "chamscolor" + std::to_string(c), it.chamsColors[std::size_t(c)]);
            it.colorizeStatTrak = readNum(b + "colorizestattrak", 0, 1, true, 0) != 0;
            it.statTrakColor = readColor(b + "stattrakcolor", it.statTrakColor);
            it.glow = readNum(b + "glow", 0, 1, true, 0) != 0;
            it.glowColor = readColor(b + "glowcolor", it.glowColor);
            it.clothPhysics = readNum(b + "clothphysics", 0, 1, true, 0) != 0;
            it.removeSleeves = readNum(b + "removesleeves", 0, 1, true, 0) != 0;
            it.bothTeams = readNum(b + "bothteams", 0, 1, true, 0) != 0;
            it.frost = readNum(b + "frost", 0, 1, true, 0) != 0;
            for (int si = 0; si < 5; ++si) {
                auto& s = it.stickers[std::size_t(si)];
                const std::string k = b + "sticker" + std::to_string(si) + ".";
                s.id = int(readNum(k + "id", 0, 2000000, true, 0));
                s.x = readNum(k + "x", -10, 10, false, 0);
                s.y = readNum(k + "y", -10, 10, false, 0);
                s.rotation = readNum(k + "rot", -360, 360, false, 0);
            }
            it.charm.id = int(readNum(b + "charm.id", 0, 2000000, true, 0));
            it.charm.pattern = int(readNum(b + "charm.pattern", 0, 100000, true, 0));
            it.charm.x = readNum(b + "charm.x", -25, 25, false, 0);
            it.charm.y = readNum(b + "charm.y", -10, 10, false, 0);
            it.charm.z = readNum(b + "charm.z", -25, 25, false, 0);
            if (!it.Default())
                team.items.push_back(it);
        }
    }
    for (auto it = begin; it != values.end() && it->first.rfind(root, 0) == 0; ++it)
        if (!used.count(it->first))
            throw std::runtime_error("Unknown Inventory preset field");
    out = next;
}
}
