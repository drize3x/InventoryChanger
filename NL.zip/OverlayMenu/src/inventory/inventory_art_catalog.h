#pragma once
#include "inventory_catalog.h"
#include "inventory_econ_path.h"
#include <set>
#include <sstream>
namespace menu {
inline void InventoryCollectEconImages(InventoryCatalog& cat, const KV1Node& root,
                                       const VPKDirectory* vpk = nullptr,
                                       const LocalizationTable* loc = nullptr,
                                       const std::function<bool(const std::string&)>& looseExists = {}) {
    const auto* ig = root.Child("items_game");
    if (!ig)
        ig = &root;
    std::map<std::string, int> aliases;
    for (const auto& x : InventoryWeapons)
        aliases[KVLower(x.id)] = x.index;
    for (const auto& x : InventoryKnives)
        aliases[KVLower(x.id)] = x.index;
    for (const auto& x : InventoryGloves)
        aliases[KVLower(x.id)] = x.index;
    auto image = [&](const KV1Node& n) {
        return InventoryCanonicalEconPath(InventorySchemaText(*ig, n, "image_inventory"));
    };
    auto model = [&](const KV1Node& n) {
        auto p = InventorySchemaText(*ig, n, "model_player");
        return p.empty() ? InventorySchemaText(*ig, n, "model_world") : p;
    };
    if (const auto* items = ig->Child("items"))
        for (const auto& item : items->children) {
            int id = 0;
            if (!InventorySchemaIndex(item.key, id))
                continue;
            InventoryDefinition d;
            d.index = id;
            d.key = item.ValueOr("name");
            if (d.key.empty())
                continue;
            auto tag = InventorySchemaText(*ig, item, "item_name");
            d.name = loc ? loc->Resolve(tag, d.key) : tag.empty() ? d.key : tag;
            d.prefab = item.ValueOr("prefab");
            d.image = image(item);
            d.model = model(item);
            aliases[KVLower(d.key)] = id;
            if (!d.image.empty()) {
                cat.itemImages[{id, 0}] = d.image;
                aliases[d.image.substr(d.image.find_last_of('/') + 1)] = id;
            }
            for (auto* list : {&cat.agents, &cat.medals})
                for (auto& n : *list)
                    if (n.id == id) {
                        n.image = d.image;
                        n.model = d.model;
                        if (list == &cat.medals && n.key.rfind("premier season coin", 0) == 0) {
                            static const char* names[] = {"premier season", "premier season clrs",
                                                          "premier season clrs max", "premier season bars",
                                                          "premier season bars max"};
                            n.premierAttributes = {{-1, -1, -1, -1, -1}};
                            if (const auto* a = item.Child("attributes"))
                                for (std::size_t k = 0; k < 5; ++k)
                                    if (const auto* value = a->Value(names[k])) {
                                        int parsed = 0;
                                        bool valid = !value->empty();
                                        for (char c : *value) {
                                            if (c < '0' || c > '9' || parsed > 6553 ||
                                                (parsed == 6553 && c > '5')) {
                                                valid = false;
                                                break;
                                            }
                                            parsed = parsed * 10 + (c - '0');
                                        }
                                        if (valid)
                                            n.premierAttributes[k] = parsed;
                                    }
                        }
                    }
            if (d.key == "customplayer_ctm_sas") {
                cat.defaultNamedImages[0] = d.image;
                if (!tag.empty())
                    cat.defaultAgentNames[0] = d.name;
            }
            if (d.key == "customplayer_tm_phoenix") {
                cat.defaultNamedImages[1] = d.image;
                if (!tag.empty())
                    cat.defaultAgentNames[1] = d.name;
            }
            cat.definitions[id] = std::move(d);
        }

    if (const auto* stickers = ig->Child("sticker_kits"))
        for (const auto& n : stickers->children) {
            int id = 0;
            if (!InventorySchemaIndex(n.key, id))
                continue;
            auto it = cat.stickerById.find(id);
            if (it == cat.stickerById.end())
                continue;
            auto path = image(n);

            if (path.empty()) {
                auto material = InventorySchemaText(*ig, n, "sticker_material");
                if (!material.empty())
                    path = InventoryCanonicalEconPath("econ/stickers/" + material);
            }
            cat.stickers[it->second].image = std::move(path);
        }
    if (const auto* charms = ig->Child("keychain_definitions")) {

        std::map<std::string, const KV1Node*> byName;
        for (const auto& n : charms->children) {
            auto name = n.ValueOr("name");
            if (!name.empty())
                byName[KVLower(name)] = &n;
        }
        for (const auto& n : charms->children) {
            int id = 0;
            if (!InventorySchemaIndex(n.key, id))
                continue;
            auto path = image(n);
            const KV1Node* cur = &n;
            std::set<const KV1Node*> seen;
            for (unsigned depth = 0; path.empty() && cur && depth < 16 && seen.insert(cur).second; ++depth) {
                auto base = KVLower(cur->ValueOr("base"));
                auto it = byName.find(base);
                if (base.empty() || it == byName.end())
                    break;
                cur = it->second;
                path = image(*cur);
            }
            for (auto& k : cat.keychains)
                if (k.id == id) {
                    k.image = path;
                    break;
                }
        }
    }
    if (const auto* music = ig->Child("music_definitions"))
        for (const auto& m : music->children) {
            const int id = std::atoi(m.key.c_str());
            for (auto& n : cat.music)
                if (n.id == id) {
                    n.image = image(m);
                    if (n.key == "valve_cs2_01" ||
                        (n.key == "valve_csgo_01" && cat.defaultNamedImages[2].empty()))
                        cat.defaultNamedImages[2] = n.image;
                }
        }
    if (const auto* sets = ig->Child("item_sets"))
        for (const auto& set : sets->children)
            for (auto& col : cat.collections)
                if (col.key == set.key) {
                    col.image = InventoryCanonicalEconPath(
                        set.ValueOr("set_image", set.ValueOr("image_inventory").c_str()));

                    if (col.image.empty()) {
                        auto candidate = InventoryCanonicalEconPath("econ/set_icons/" + set.key);
                        if (!candidate.empty())
                            for (const char* ext : {"_png.vtex_c", ".vtex_c", ".png"}) {
                                auto file = "panorama/images/" + candidate + ext;
                                if ((vpk && vpk->Find(file)) || (looseExists && looseExists(file))) {
                                    col.image = candidate;
                                    break;
                                }
                            }
                    }

                    if (col.image.empty()) {
                        auto candidate = InventoryCanonicalEconPath("econ/set_icons/" + set.key);
                        auto file = "panorama/images/" + candidate + ".vsvg_c";
                        if (!candidate.empty() &&
                            ((vpk && vpk->Find(file)) || (looseExists && looseExists(file))))
                            col.image = candidate + ".svg";
                    }
                    if (const auto* items = set.Child("items"))
                        for (const auto& e : items->children) {
                            std::string paint, item;
                            if (!detail::InventorySplitEntry(e.key, paint, item))
                                continue;
                            auto a = aliases.find(KVLower(item));
                            if (a == aliases.end())
                                continue;
                            for (const auto& p : cat.paints)
                                if (KV1Node::IEqual(p.key, paint.c_str())) {
                                    col.members.push_back({a->second, p.id});
                                    break;
                                }
                        }
                    std::sort(col.members.begin(), col.members.end());
                    col.members.erase(std::unique(col.members.begin(), col.members.end()), col.members.end());
                }
    std::map<std::pair<int, int>, int> rank;
    std::unordered_map<std::string, int> paints;
    for (const auto& p : cat.paints)
        paints[KVLower(p.key)] = p.id;
    auto finish = [&](const std::string& value) {
        auto path = InventoryCanonicalEconPath(value);
        if (path.empty() || path.compare(0, 23, "econ/default_generated/") != 0)
            return;
        std::string stem = path.substr(path.find_last_of('/') + 1);
        int quality = 0;
        for (const auto& suffix :
             std::vector<std::pair<std::string, int>>{{"_light_large", 3}, {"_light", 2}})
            if (stem.size() > suffix.first.size() &&
                stem.compare(stem.size() - suffix.first.size(), suffix.first.size(), suffix.first) == 0) {
                stem.resize(stem.size() - suffix.first.size());
                quality = suffix.second;
                break;
            }
        if (!quality)
            return;
        std::size_t longest = 0;
        int index = 0, paint = 0;
        for (const auto& a : aliases)
            if (a.first.size() > longest && stem.size() > a.first.size() + 1 &&
                stem.compare(0, a.first.size(), a.first) == 0 && stem[a.first.size()] == '_') {
                auto it = paints.find(stem.substr(a.first.size() + 1));
                if (it != paints.end()) {
                    longest = a.first.size();
                    index = a.second;
                    paint = it->second;
                }
            }
        if (!index || !paint)
            return;
        const auto k = std::make_pair(index, paint);
        if (quality > rank[k]) {
            rank[k] = quality;
            cat.itemImages[k] = std::move(path);
        }
    };
    if (const auto* alt = ig->Child("alternate_icons2")) {
        std::function<void(const KV1Node&, int)> scan = [&](const KV1Node& n, int depth) {
            if (depth > 8)
                return;
            for (const auto& x : n.children) {
                if (KV1Node::IEqual(x.key, "icon_path"))
                    finish(x.value);
                else if (!x.children.empty())
                    scan(x, depth + 1);
            }
        };
        scan(*alt, 0);
    }
    if (vpk)
        for (const auto& e : vpk->entries)
            finish(e.path);

    for (const auto& e : cat.itemImages)
        if (e.first.second) {
            auto& v = cat.itemPaints[e.first.first];
            if (std::find(v.begin(), v.end(), e.first.second) == v.end())
                v.push_back(e.first.second);
        }
}
}
