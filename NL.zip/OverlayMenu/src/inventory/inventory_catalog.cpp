#include "inventory_catalog.h"

namespace menu {
void InventoryMergeCatalogSections(KV1Node& root) {
    KV1Node* ig = &root;
    for (auto& node : root.children)
        if (KV1Node::IEqual(node.key, "items_game")) {
            ig = &node;
            break;
        }
    std::map<std::string, std::size_t> first;
    std::vector<KV1Node> result;
    result.reserve(ig->children.size());
    for (auto& node : ig->children) {
        auto key = KVLower(node.key);
        bool merge = false;
        for (const char* k : {"prefabs", "items", "paint_kits", "paint_kits_rarity", "item_sets",
                              "client_loot_lists", "revolving_loot_lists", "sticker_kits",
                              "music_definitions", "keychain_definitions", "alternate_icons2"})
            if (key == k) {
                merge = true;
                break;
            }
        if (!merge || !node.block) {
            result.push_back(std::move(node));
            continue;
        }
        auto i = first.find(key);
        if (i == first.end()) {
            first.emplace(key, result.size());
            result.push_back(std::move(node));
        } else {
            auto& dest = result[i->second].children;
            dest.reserve(dest.size() + node.children.size());
            for (auto& child : node.children)
                dest.push_back(std::move(child));
        }
    }
    ig->children = std::move(result);
}

const KV1Node* InventorySchemaField(const KV1Node& ig, const KV1Node& node, const char* field) {
    const auto* prefabs = ig.Child("prefabs");
    std::set<std::string> visiting;
    unsigned budget = 128;
    std::function<const KV1Node*(const KV1Node&, int)> get = [&](const KV1Node& n,
                                                                 int depth) -> const KV1Node* {
        if (depth > 16 || !budget)
            return nullptr;
        --budget;
        if (const auto* p = n.Child(field))
            return p;
        std::vector<std::string> parents;
        std::istringstream in(n.ValueOr("prefab"));
        std::string key;
        while (in >> key) {
            if (parents.size() == 16)
                return nullptr;
            parents.push_back(KVLower(key));
        }
        for (auto i = parents.rbegin(); i != parents.rend(); ++i) {
            if (!prefabs || !visiting.insert(*i).second)
                continue;
            const KV1Node* value = nullptr;
            if (const auto* p = prefabs->Child(i->c_str()))
                value = get(*p, depth + 1);
            visiting.erase(*i);
            if (value)
                return value;
        }
        return nullptr;
    };
    return get(node, 0);
}

std::string InventorySchemaText(const KV1Node& ig, const KV1Node& node, const char* field) {
    const auto* p = InventorySchemaField(ig, node, field);
    return p ? p->value : std::string{};
}

bool InventorySchemaPrefab(const KV1Node& ig, const KV1Node& node, const char* type) {
    const auto* prefabs = ig.Child("prefabs");
    std::set<std::string> visiting;
    unsigned budget = 128;
    std::function<bool(const KV1Node&, int)> has = [&](const KV1Node& n, int depth) {
        if (depth > 16 || !budget)
            return false;
        --budget;
        std::istringstream in(n.ValueOr("prefab"));
        std::string key;
        unsigned count = 0;
        while (in >> key) {
            if (++count > 16)
                return false;
            key = KVLower(key);
            if (key.find(type) != std::string::npos)
                return true;
            if (prefabs && visiting.insert(key).second) {
                const auto* p = prefabs->Child(key.c_str());
                const bool found = p && has(*p, depth + 1);
                visiting.erase(key);
                if (found)
                    return true;
            }
        }
        return false;
    };
    return has(node, 0);
}

bool InventorySchemaIndex(const std::string& s, int& value) {
    if (s.empty() || s.size() > 9)
        return false;
    unsigned n = 0;
    for (unsigned char c : s) {
        if (c < '0' || c > '9')
            return false;
        n = n * 10 + c - '0';
        if (n > 100000000)
            return false;
    }
    value = int(n);
    return n > 0;
}

namespace detail {
int InventoryRarityOrdinal(const std::string& name) {
    for (int i = 0; i < 8; ++i)
        if (KV1Node::IEqual(name, InventoryRarityIds[std::size_t(i)]))
            return i;

    if (!name.empty() &&
        std::all_of(name.begin(), name.end(), [](unsigned char c) { return c >= '0' && c <= '9'; })) {
        int v = std::atoi(name.c_str());
        return std::clamp(v, 0, 7);
    }
    return 1;
}

bool InventorySplitEntry(const std::string& key, std::string& paint, std::string& item) {
    if (key.size() < 3 || key[0] != '[')
        return false;
    auto close = key.find(']');
    if (close == std::string::npos)
        return false;
    paint = key.substr(1, close - 1);
    item = key.substr(close + 1);
    return !paint.empty() && !item.empty();
}
}

Color InventoryParseHexColor(const std::string& hex) {

    if (!hex.empty() && hex[0] == '#' && hex.size() >= 7) {
        auto v = std::strtoul(hex.c_str() + 1, nullptr, 16);
        return {((v >> 16) & 255) / 255.f, ((v >> 8) & 255) / 255.f, (v & 255) / 255.f, 1};
    }
    float c[4] = {1, 1, 1, 1};
    int n = 0;
    std::size_t p = 0;
    while (n < 4 && p < hex.size()) {
        while (p < hex.size() && (hex[p] == ' ' || hex[p] == ','))
            ++p;
        if (p >= hex.size())
            break;
        c[n++] = std::strtof(hex.c_str() + p, nullptr) / 255.f;
        while (p < hex.size() && hex[p] != ' ' && hex[p] != ',')
            ++p;
    }
    return {std::clamp(c[0], 0.f, 1.f), std::clamp(c[1], 0.f, 1.f), std::clamp(c[2], 0.f, 1.f),
            n >= 4 ? std::clamp(c[3], 0.f, 1.f) : 1.f};
}

InventoryCatalog BuildInventoryCatalog(const KV1Node& itemsGameRoot, const LocalizationTable& loc) {
    InventoryCatalog cat;
    const KV1Node* ig = itemsGameRoot.Child("items_game");
    if (!ig)
        ig = &itemsGameRoot;

    std::unordered_map<std::string, int> itemIndex;
    for (const auto& w : InventoryWeapons)
        itemIndex[w.id] = w.index;
    for (const auto& k : InventoryKnives)
        itemIndex[k.id] = k.index;
    for (const auto& g : InventoryGloves)
        itemIndex[g.id] = g.index;

    std::map<std::string, Color> colorByName;
    if (auto colors = ig->Child("colors"))
        for (const auto& c : colors->children) {
            auto hex = c.Value("hex_color");
            auto col = c.Value("color_name");
            (void)col;
            if (hex)
                colorByName[KVLower(c.key)] = InventoryParseHexColor(*hex);
        }
    if (auto rar = ig->Child("rarities"))
        for (const auto& r : rar->children) {

            int ord = -1;
            for (int i = 0; i < 8; ++i)
                if (KV1Node::IEqual(r.key, InventoryRarityIds[std::size_t(i)])) {
                    ord = i;
                    break;
                }
            if (ord < 0)
                continue;
            if (auto cn = r.Value("color")) {
                auto it = colorByName.find(KVLower(*cn));
                if (it != colorByName.end())
                    cat.rarityColors[std::size_t(ord)] = it->second;
            }
        }

    std::unordered_map<std::string, std::size_t> paintByKey;
    if (auto pk = ig->Child("paint_kits"))
        for (const auto& p : pk->children) {
            if (p.key == "0")
                continue;
            InventoryPaint paint;
            paint.id = std::atoi(p.key.c_str());
            paint.key = p.ValueOr("name");
            if (paint.key.empty())
                continue;
            std::string tag = p.ValueOr("description_tag");
            paint.name = tag.empty() ? paint.key : loc.Resolve(tag, paint.key);
            if (auto v = p.Value("wear_remap_min"))
                paint.wearMin = std::strtof(v->c_str(), nullptr);
            if (auto v = p.Value("wear_remap_max"))
                paint.wearMax = std::strtof(v->c_str(), nullptr);

            for (int i = 0; i < 4; ++i)
                if (auto text = p.Value(("color" + std::to_string(i)).c_str())) {
                    unsigned r = 0, g = 0, b = 0;
                    char extra = 0;
                    std::istringstream input(*text);
                    if ((input >> r >> g >> b) && !(input >> extra) && r <= 255 && g <= 255 && b <= 255) {
                        paint.paintColors[std::size_t(i)] = {r / 255.f, g / 255.f, b / 255.f, 1.f};
                        paint.paintColorMask |= 1u << i;
                    }
                }
            paint.legacy = p.ValueOr("use_legacy_model") == "1";
            {
                std::string desc = p.ValueOr("description_string");
                if (!desc.empty()) {
                    auto d = loc.Find(desc);
                    if (d)
                        paint.description = *d;
                }
            }
            cat.paintById[paint.id] = cat.paints.size();
            paintByKey[KVLower(paint.key)] = cat.paints.size();
            cat.paints.push_back(std::move(paint));
        }
    if (auto pr = ig->Child("paint_kits_rarity"))
        for (const auto& e : pr->children) {
            auto it = paintByKey.find(KVLower(e.key));
            if (it != paintByKey.end())
                cat.paints[it->second].rarity = detail::InventoryRarityOrdinal(e.value);
        }

    auto applyEntry = [&](const std::string& key, int collection) {
        std::string paintKey, itemKey;
        if (!detail::InventorySplitEntry(key, paintKey, itemKey))
            return;
        auto pit = paintByKey.find(KVLower(paintKey));
        if (pit == paintByKey.end())
            return;
        int paintId = cat.paints[pit->second].id;
        if (collection >= 0 && cat.paints[pit->second].collection < 0)
            cat.paints[pit->second].collection = collection;
        auto iit = itemIndex.find(KVLower(itemKey));
        if (iit == itemIndex.end())
            return;
        int idx = iit->second;
        if (InventoryIsKnife(idx)) {
            if (std::find(cat.knifePaints.begin(), cat.knifePaints.end(), paintId) == cat.knifePaints.end())
                cat.knifePaints.push_back(paintId);
        } else {
            auto& v = cat.itemPaints[idx];
            if (std::find(v.begin(), v.end(), paintId) == v.end())
                v.push_back(paintId);
        }
    };
    if (auto sets = ig->Child("item_sets"))
        for (const auto& set : sets->children) {
            InventoryCollection col;
            col.key = set.key;
            col.name = loc.Resolve(set.ValueOr("name"), set.key);
            int ci = int(cat.collections.size());
            cat.collections.push_back(col);
            if (auto items = set.Child("items"))
                for (const auto& e : items->children)
                    applyEntry(e.key, ci);
        }

    if (auto lists = ig->Child("client_loot_lists"))
        for (const auto& list : lists->children)
            for (const auto& e : list.children)
                applyEntry(e.key, -1);

    std::unordered_map<std::string, std::size_t> stickerByKey;
    if (auto sk = ig->Child("sticker_kits"))
        for (const auto& s : sk->children) {
            if (s.key == "0")
                continue;
            InventoryStickerKit kit;
            kit.id = std::atoi(s.key.c_str());
            kit.key = s.ValueOr("name");
            if (kit.key.empty())
                continue;
            kit.name = loc.Resolve(s.ValueOr("item_name"), kit.key);
            kit.rarity = detail::InventoryRarityOrdinal(s.ValueOr("item_rarity", "rare"));
            kit.eventId = std::atoi(s.ValueOr("tournament_event_id", "0").c_str());
            cat.stickerById[kit.id] = cat.stickers.size();
            stickerByKey[KVLower(kit.key)] = cat.stickers.size();
            cat.stickers.push_back(std::move(kit));
        }

    if (auto lists = ig->Child("client_loot_lists")) {
        std::unordered_map<std::string, const KV1Node*> byName;
        for (const auto& l : lists->children)
            byName[KVLower(l.key)] = &l;
        std::function<void(const KV1Node*, std::vector<int>&, int)> collect =
            [&](const KV1Node* list, std::vector<int>& out, int depth) {
                if (!list || depth > 8)
                    return;
                for (const auto& e : list->children) {
                    std::string paintKey, itemKey;
                    if (detail::InventorySplitEntry(e.key, paintKey, itemKey)) {
                        if (KV1Node::IEqual(itemKey, "sticker")) {
                            auto it = stickerByKey.find(KVLower(paintKey));
                            if (it != stickerByKey.end())
                                out.push_back(int(it->second));
                        }
                    } else {
                        auto sub = byName.find(KVLower(e.key));
                        if (sub != byName.end())
                            collect(sub->second, out, depth + 1);
                    }
                }
            };
        std::unordered_map<std::string, std::string> seriesLists;
        if (auto series = ig->Child("revolving_loot_lists"))
            for (const auto& e : series->children)
                if (!e.block && !e.value.empty())
                    seriesLists[e.key] = e.value;
        if (auto items = ig->Child("items"))
            for (const auto& it : items->children) {
                std::string lootName = InventorySchemaText(*ig, it, "loot_list_name");
                std::string nameTag = InventorySchemaText(*ig, it, "item_name");

                if (lootName.empty())
                    if (auto attrs = InventorySchemaField(*ig, it, "attributes"))
                        if (auto series = attrs->Child("set supply crate series")) {
                            auto key = series->block ? series->ValueOr("value") : series->value;
                            auto found = seriesLists.find(key);
                            if (found != seriesLists.end())
                                lootName = found->second;
                        }
                if (lootName.empty() || nameTag.empty())
                    continue;
                auto l = byName.find(KVLower(lootName));
                if (l == byName.end())
                    continue;
                std::vector<int> found;
                collect(l->second, found, 0);
                if (found.empty())
                    continue;
                std::sort(found.begin(), found.end());
                found.erase(std::unique(found.begin(), found.end()), found.end());
                InventoryCapsule cap;
                cap.key = it.ValueOr("name");
                cap.name = loc.Resolve(nameTag, cap.key);
                for (int si : found) {
                    const int ev = cat.stickers[std::size_t(si)].eventId;
                    cap.tournament = cap.tournament || ev != 0;
                    if (ev && !cap.eventId)
                        cap.eventId = ev;
                    if (cat.stickers[std::size_t(si)].capsule < 0)
                        cat.stickers[std::size_t(si)].capsule = int(cat.capsules.size());
                    cap.stickers.push_back(si);
                }
                if (cap.eventId && !cat.eventNames.count(cap.eventId)) {
                    const auto id = std::to_string(cap.eventId);
                    cat.eventNames[cap.eventId] =
                        loc.Resolve("CSGO_Tournament_Event_NameShort_" + id,
                                    loc.Resolve("CSGO_Tournament_Event_Name_" + id, "Tournament " + id));
                }
                cat.capsules.push_back(std::move(cap));
            }
    }

    if (auto md = ig->Child("music_definitions"))
        for (const auto& m : md->children) {
            InventoryNamed n;
            n.id = std::atoi(m.key.c_str());
            n.key = m.ValueOr("name");
            n.name = loc.Resolve(m.ValueOr("loc_name"), n.key);
            n.model = m.ValueOr("pedestal_display_model");
            if (!n.key.empty())
                cat.music.push_back(std::move(n));
        }
    if (auto kd = ig->Child("keychain_definitions"))
        for (const auto& k : kd->children) {
            InventoryNamed n;
            n.id = std::atoi(k.key.c_str());
            n.key = k.ValueOr("name");
            n.name = loc.Resolve(k.ValueOr("loc_name", k.ValueOr("item_name").c_str()), n.key);
            if (auto r = k.Value("item_rarity"))
                n.rarity = detail::InventoryRarityOrdinal(*r);
            if (!n.key.empty())
                cat.keychains.push_back(std::move(n));
        }
    if (auto items = ig->Child("items"))
        for (const auto& it : items->children) {
            std::string nameTag = InventorySchemaText(*ig, it, "item_name");
            int id = 0;
            if (!InventorySchemaIndex(it.key, id))
                continue;
            {
                auto rarity = InventorySchemaText(*ig, it, "item_rarity");
                if (!rarity.empty())
                    cat.itemRarities[id] = detail::InventoryRarityOrdinal(rarity);
            }
            if (nameTag.empty())
                continue;
            if (InventorySchemaPrefab(*ig, it, "customplayer")) {

                if (KV1Node::IEqual(nameTag, "#CSGO_CustomPlayer_t_map_based") ||
                    KV1Node::IEqual(nameTag, "#CSGO_CustomPlayer_ct_map_based"))
                    continue;
                InventoryNamed n;
                n.id = id;
                n.key = it.ValueOr("name");
                n.name = loc.Resolve(nameTag, n.key);
                {
                    auto r = InventorySchemaText(*ig, it, "item_rarity");
                    if (!r.empty())
                        n.rarity = detail::InventoryRarityOrdinal(r);
                }

                if (auto u = InventorySchemaField(*ig, it, "used_by_classes")) {
                    unsigned t = 0;
                    if (u->Child("counter-terrorists"))
                        t |= InventoryTeamCT;
                    if (u->Child("terrorists"))
                        t |= InventoryTeamT;
                    if (t)
                        n.teams = t;
                }
                cat.agents.push_back(std::move(n));
            } else if (InventorySchemaPrefab(*ig, it, "collectible") ||
                       InventorySchemaPrefab(*ig, it, "service_medal")) {
                InventoryNamed n;
                n.id = id;
                n.key = it.ValueOr("name");
                n.name = loc.Resolve(nameTag, n.key);
                {
                    auto r = InventorySchemaText(*ig, it, "item_rarity");
                    if (!r.empty())
                        n.rarity = detail::InventoryRarityOrdinal(r);
                }
                cat.medals.push_back(std::move(n));
            }

            auto iit = itemIndex.find(KVLower(it.ValueOr("name")));
            if (iit != itemIndex.end())
                cat.itemNames[iit->second] = loc.Resolve(nameTag, it.ValueOr("name"));
        }

    for (int i = 0; i < 5; ++i)
        cat.wearNames[std::size_t(i)] =
            loc.Resolve(InventoryWearKeys[std::size_t(i)], InventoryWearNames[std::size_t(i)]);

    cat.loaded = !cat.paints.empty();
    if (cat.loaded)
        cat.source = "items_game.txt";
    return cat;
}

int InventoryFinishRarity(const InventoryCatalog& cat, int index, const InventoryPaint* p) {
    if (!p)
        return 0;
    if (InventoryIsKnife(index) || InventoryIsGlove(index))
        return 6;
    auto it = cat.itemRarities.find(index);
    const int base = it == cat.itemRarities.end() ? 1 : it->second;
    return std::clamp(base + p->rarity - 1, 0, p->rarity == 7 ? 7 : 6);
}

void InventorySortPaints(const InventoryCatalog& cat, std::vector<int>& ids, InventorySort sort, int index) {
    std::stable_sort(ids.begin(), ids.end(), [&](int a, int b) {
        const auto* pa = cat.Paint(a);
        const auto* pb = cat.Paint(b);
        if (!pa || !pb)
            return pa > pb;
        if (sort == InventorySort::Rarity) {
            const int ra = index ? InventoryFinishRarity(cat, index, pa) : pa->rarity,
                      rb = index ? InventoryFinishRarity(cat, index, pb) : pb->rarity;
            if (ra != rb)
                return ra > rb;
            return pa->name < pb->name;
        }
        if (sort == InventorySort::Newest) {
            if (pa->id != pb->id)
                return pa->id > pb->id;
            return pa->name < pb->name;
        }
        return pa->name < pb->name;
    });
}
}
