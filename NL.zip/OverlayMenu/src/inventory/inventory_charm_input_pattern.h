#pragma once
#include <cstdint>
#include <string>
namespace menu::charm {

inline constexpr char InputReader[] = "F3 0F 10 35 ? ? ? ? 0F 29 BC 24 ? ? ? ? F3 0F 10 3D ? ? ? ? "
                                      "44 0F 29 84 24 ? ? ? ? F3 44 0F 10 05 ? ? ? ? 44 0F 29 A4 24";
inline constexpr char InputWriter[] = "F2 0F 11 05 ? ? ? ? F3 0F 10 05 ? ? ? ? FF C8 0F C6 CE AA 0F 2F C1 "
                                      "89 05 ? ? ? ? 66 0F 73 DF 0C 66 0F 7E 3D ? ? ? ?";
template <class Image> bool ResolvePreviewInput(const Image& image, std::uintptr_t& out, std::string& why) {
    out = 0;
    auto r = image.Find(InputReader, true, 2), w = image.Find(InputWriter, true, 2);
    if (r.size() != 1 || w.size() != 1) {
        why = "input code missing or ambiguous";
        return false;
    }
    auto x = image.Rip(r[0], 4, 8), z = image.Rip(r[0] + 16, 4, 8), y = image.Rip(r[0] + 33, 5, 9);
    if (!x || y != x + 4 || z != x + 8 || !image.Contains(x, 12, 0x80000000, 0x20000000) ||
        image.Rip(w[0], 4, 8) != x || image.Rip(w[0] + 36, 4, 8) != z) {
        why = "input read/write targets inconsistent";
        return false;
    }
    out = x;
    why = "input reader and writer cross-checked";
    return true;
}
}
