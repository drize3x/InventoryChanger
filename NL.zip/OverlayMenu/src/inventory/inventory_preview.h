#pragma once

#include "group_row_geometry.h"
#include "players_native_preview_script.h"
#include <atomic>
namespace menu {

inline std::atomic<int>& InventoryMusicReady() {
    static std::atomic<int> id{0};
    return id;
}
inline bool InventoryPreviewBoxValid(Box b) {
    return std::isfinite(b.x) && std::isfinite(b.y) && std::isfinite(b.w) && std::isfinite(b.h) && b.w > 0 &&
           b.h > 0 && std::isfinite(b.x + b.w) && std::isfinite(b.y + b.h);
}
inline bool InventoryPreviewScaleValid(float s) {
    return std::isfinite(s) && s > 0;
}

inline Box InventoryPreviewPane(Box available, float scale) {
    if (!InventoryPreviewBoxValid(available) || !InventoryPreviewScaleValid(scale))
        return {};
    Box out{available.x, available.y, 200.f * scale, available.h - 130.f * scale};
    return InventoryPreviewBoxValid(out) ? out : Box{};
}

inline Box InventoryPreviewSurface(Box pane, float scale) {
    if (!InventoryPreviewBoxValid(pane) || !InventoryPreviewScaleValid(scale))
        return {};
    const float w = pane.h * (350.f / 600.f), halfH = pane.h * .5f;
    Box out{pane.x + pane.w * .5f - 20.f * scale - w * .5f, pane.y + halfH + 5.f * scale - std::trunc(halfH),
            w, 2.f * std::trunc(halfH)};
    return InventoryPreviewBoxValid(out) ? out : Box{};
}
inline NativePreviewRequest InventoryPreviewRequest(bool shown, int team, Box pane, Box clip, int width,
                                                    int height, float scale = 1.f) {
    NativePreviewRequest r;
    if (!shown || (team != 0 && team != 1) || width <= 0 || height <= 0 || !InventoryPreviewBoxValid(pane) ||
        !InventoryPreviewBoxValid(clip))
        return r;
    auto b = InventoryPreviewSurface(pane, scale);
    if (!InventoryPreviewBoxValid(b))
        return r;
    const float x = std::max({0.f, b.x, pane.x, clip.x}), y = std::max({0.f, b.y, pane.y, clip.y});
    const float right = std::min({float(width), b.x + b.w, pane.x + pane.w, clip.x + clip.w}),
                bottom = std::min({float(height), b.y + b.h, pane.y + pane.h, clip.y + clip.h});
    r.enabled = true;
    r.terrorist = team == 1;
    r.scene = NativePreviewScene::InventoryLoadout;
    r.x = x;
    r.y = y;
    r.w = std::max(0.f, right - x);
    r.h = std::max(0.f, bottom - y);
    r.screenW = width;
    r.screenH = height;

    if (!PreviewRequestValid(r))
        r.enabled = false;
    return r;
}

inline unsigned InventoryItemExtent(float v) {
    if (!std::isfinite(v) || v <= 0 || v > 4096)
        return 0;
    unsigned n = unsigned(v);
    return std::min(4096u, std::max(32u, (n + 31u) & ~31u));
}

inline Box InventoryBigPreviewWindow(Box viewport) {
    if (!InventoryPreviewBoxValid(viewport))
        return {};
    auto dimension = [](float n) {
        return std::min(n, float(InventoryItemExtent(std::min(4096.f, std::max(1.f, n - 100.f)))));
    };
    const float w = dimension(viewport.w), h = dimension(viewport.h);
    if (w <= 0 || h <= 0)
        return {};
    return {viewport.x + std::trunc((viewport.w - w) * .5f), viewport.y + std::trunc((viewport.h - h) * .5f),
            w, h};
}
inline Box InventoryItemSurface(Box area, float scale = 1.f, bool big = false) {
    if (!InventoryPreviewBoxValid(area) || !InventoryPreviewScaleValid(scale))
        return {};
    const float childH = big ? area.h : 235.f * scale;
    unsigned w = InventoryItemExtent(area.w),
             h = InventoryItemExtent(big ? std::min(4096.f, childH + 130.f * scale) : childH + 130.f * scale);
    if (!w || !h)
        return {};
    return {area.x + area.w * .5f - w * .5f, area.y + childH * .5f - 15.f * scale - h * .5f, float(w),
            float(h)};
}

inline Box InventoryItemDisplaySurface(Box area, float scale, bool music, bool big = false) {
    auto b = InventoryItemSurface(area, scale, big);
    if (!InventoryPreviewBoxValid(b) || !music)
        return b;
    constexpr float musicSize = .48f;
    const float w = b.w * musicSize, h = b.h * musicSize;
    return {b.x + (b.w - w) * .5f, b.y + (b.h - h) * .5f, w, h};
}

inline Box InventoryBigItemDisplaySurface(Box area, Box ordinary, float scale, bool music) {
    auto source = InventoryItemSurface(ordinary, scale, false);
    if (!InventoryPreviewBoxValid(area) || !InventoryPreviewBoxValid(source))
        return {};
    const float factor = std::min(area.w / source.w, area.h / source.h) * (music ? .48f : 1.f);
    const float w = source.w * factor, h = source.h * factor;
    return {area.x + (area.w - w) * .5f, area.y + (area.h - h) * .5f, w, h};
}
inline Box InventoryGlockSurface(Box area) {
    return InventoryItemSurface(area, 1.f);
}
inline NativePreviewRequest InventoryItemRequest(bool shown, Box area, Box clip, int width, int height,
                                                 int definition, int paint, float yaw, float pitch,
                                                 float scale = 1.f, bool music = false, int activeIndex = 0,
                                                 bool big = false) {
    NativePreviewRequest r;
    if (!shown || !InventoryPreviewBoxValid(area) || !InventoryPreviewBoxValid(clip) || width <= 0 ||
        height <= 0)
        return r;
    auto b = InventoryItemSurface(area, scale, big);
    if (!InventoryPreviewBoxValid(b))
        return r;
    const float x = std::max({0.f, b.x, clip.x}), y = std::max({0.f, b.y, clip.y});
    const float right = std::min({float(width), b.x + b.w, clip.x + clip.w}),
                bottom = std::min({float(height), b.y + b.h, clip.y + clip.h});
    r.enabled = true;
    r.scene = NativePreviewScene::InventoryGlock;
    r.itemDefinition = definition;
    r.paintKit = paint;
    r.itemMusic = music;
    r.itemActiveIndex = music ? 4 : activeIndex;
    r.yaw = yaw;
    r.pitch = pitch;
    r.itemWidth = unsigned(b.w);
    r.itemHeight = unsigned(b.h);
    r.x = x;
    r.y = y;
    r.w = std::max(0.f, right - x);
    r.h = std::max(0.f, bottom - y);
    r.screenW = width;
    r.screenH = height;
    if (!PreviewRequestValid(r))
        r.enabled = false;
    return r;
}

inline NativePreviewRequest InventoryBigQualityRequest(NativePreviewRequest r, Box big, Box ordinary,
                                                       float scale) {
    if (!PreviewRequestValid(r) || !PreviewIsItem(r))
        return {};
    const auto dest = InventoryBigItemDisplaySurface(big, ordinary, scale, false);
    const auto w = InventoryItemExtent(std::min(4096.f, dest.w)),
               h = InventoryItemExtent(std::min(4096.f, dest.h));
    if (!w || !h)
        return {};
    r.itemWidth = std::max(r.itemWidth, w);
    r.itemHeight = std::max(r.itemHeight, h);
    return PreviewRequestValid(r) ? r : NativePreviewRequest{};
}
inline NativePreviewRequest InventoryGlockRequest(bool shown, Box area, Box clip, int width, int height,
                                                  int paint, float yaw, float pitch, float scale = 1.f) {
    return InventoryItemRequest(shown, area, clip, width, height, 4, paint, yaw, pitch, scale);
}
}
