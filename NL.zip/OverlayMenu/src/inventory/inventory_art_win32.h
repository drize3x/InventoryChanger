#pragma once
#include "ambience_image_source.h"
#include "ambience_image_readback_win32.h"
#include "inventory_art_script.h"
#include "inventory_art_metadata.h"
#include "inventory_art_prefetch.h"
#include <deque>
#include <atomic>
#if defined(MENU_STUDIO_INVENTORY_ART_TEST)
#define MENU_ECON_TRY try
#define MENU_ECON_EXCEPT catch (...)
#elif defined(_MSC_VER)
#define MENU_ECON_TRY __try
#define MENU_ECON_EXCEPT __except (EXCEPTION_EXECUTE_HANDLER)
#else
#error Inventory econ readback requires MSVC SEH or explicit synthetic tests.
#endif
namespace menu {

class InventoryArtNative {
#if defined(MENU_STUDIO_INVENTORY_ART_TEST)
    friend struct InventoryArtNativeTest;
#endif
    struct Queued {
        AmbienceImageJob job;
        Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> view;
        AmbienceTextureCodec codec = AmbienceTextureCodec::Unknown;
    };
    AmbienceNativeBindings bindings_{};
    InventoryArtMetadata metadata_;
    std::atomic<bool> ready_{false};
    bool host_ = false;
    std::uintptr_t root_ = 0, device_ = 0;
    std::uint64_t nextScript_ = 0;
    std::string scriptKey_;
    std::uint64_t nextWarm_ = 0;
    std::array<AmbienceImageReadback, 7> extraReadbacks_{};
    mutable std::mutex mutex_;
    std::deque<Queued> queue_;
    std::string diagnostic_ = "not configured";
    static bool Decompress(unsigned method, const unsigned char* input, std::size_t bytes,
                           unsigned char* output, std::size_t expected) {
        MENU_ECON_TRY {
            auto tier = GetModuleHandleW(L"tier0.dll");
            if (!tier || bytes > 64 * 1024 * 1024 || expected > 64 * 1024 * 1024)
                return false;
            if (method == 1) {
                auto fn = GetProcAddress(tier, "V_LZ4_decompress_safe");
                return fn && reinterpret_cast<int (*)(const char*, char*, int, int)>(fn)(
                                 reinterpret_cast<const char*>(input), reinterpret_cast<char*>(output),
                                 int(bytes), int(expected)) == int(expected);
            }
            if (method == 2) {
                auto fn = GetProcAddress(tier, "V_ZSTD_decompress");
                return fn && reinterpret_cast<std::size_t (*)(void*, std::size_t, const void*, std::size_t)>(
                                 fn)(output, expected, input, bytes) == expected;
            }
            return false;
        }
        MENU_ECON_EXCEPT {
            return false;
        }
    }
    static bool Retain(std::uintptr_t address, ID3D11ShaderResourceView*& out) {
        out = nullptr;
        MENU_ECON_TRY {
            return address &&
                   SUCCEEDED(reinterpret_cast<IUnknown*>(address)->QueryInterface(
                       __uuidof(ID3D11ShaderResourceView), reinterpret_cast<void**>(&out))) &&
                   out;
        }
        MENU_ECON_EXCEPT {
            return false;
        }
    }
    void ClearQueue() {
        std::lock_guard<std::mutex> lock(mutex_);
        queue_.clear();
    }

public:
    bool Ready() const {
        return ready_.load(std::memory_order_acquire);
    }
    bool Start(const HudScanImage& c, const HudScanImage& p, const HudScanImage& r,
               const PreviewBridgeBindings& bridge, HMODULE client) {
        bindings_.bridge = bridge;
        ready_ = ResolvePanoramaImageNative(c, p, r, bindings_, diagnostic_);
        if (!ready_)
            return false;
        std::array<wchar_t, 32768> path{};
        auto n = GetModuleFileNameW(client, path.data(), DWORD(path.size()));
        metadata_.Configure(n && n < path.size() ? InventoryGuessCsgoDir(std::filesystem::path(path.data()))
                                                 : std::filesystem::path{},
                            Decompress);
        return true;
    }
    void PumpMetadata() {
        if (!ready_)
            return;
        const auto now = InventoryArtworkClock();
        if (now >= nextWarm_) {
            if (auto cat = InventorySharedContent().Catalog())
                InventoryPrefetchBase(*cat, now);
            nextWarm_ = now + 500;
        }
        for (const auto& j : GameInventoryArtwork().Plan(now))
            metadata_.Query(j.name);
        metadata_.Pump(16);
    }
    void LostRoot() {
        if (!root_)
            return;
        root_ = 0;
        host_ = false;
        nextScript_ = 0;
        scriptKey_.clear();
        ClearQueue();
        GameInventoryArtwork().InvalidatePending();
    }
    template <class Run, class Find, class Read>
    bool Tick(std::uintptr_t root, std::uint64_t owner, bool remove, Run&& run, Find&& find, Read&& read) {
        if (!ready_)
            return true;
        if (root != root_) {
            LostRoot();
            root_ = root;
        }
        if (!root)
            return true;
        const auto now = InventoryArtworkClock();
        auto& cache = GameInventoryArtwork();
        auto jobs = remove ? std::vector<AmbienceImageJob>{} : cache.Plan(now);
        std::string key;
        for (const auto& j : jobs)
            key += j.name + ":" + std::to_string(j.ticket) + ";";
        if ((host_ || !jobs.empty()) && (remove || key != scriptKey_ || now >= nextScript_)) {
            if (!run(BuildInventoryArtScript(owner, jobs, remove || jobs.empty())))
                return false;
            host_ = !remove && !jobs.empty();
            nextScript_ = now + 250;
            scriptKey_ = std::move(key);
        }
        if (remove) {
            LostRoot();
            return true;
        }
        if (jobs.empty())
            return true;
        std::uintptr_t host = 0;
        if (!find(root, InventoryArtHost(owner).c_str(), host) || !host)
            return true;
        std::uintptr_t vt = 0;
        if (!read(host, vt) || vt != bindings_.bridge.panelVtable)
            return true;
        for (const auto& job : jobs) {
            auto codec = metadata_.Query(job.name);
            if (codec.codec == AmbienceTextureCodec::Pending)
                continue;
            if (codec.codec != AmbienceTextureCodec::RGB && codec.codec != AmbienceTextureCodec::YCoCg) {
                cache.Reject(job, now);
                continue;
            }
            std::uintptr_t panel = 0;
            if (!find(host, InventoryArtChild(job).c_str(), panel))
                continue;
            AmbienceSourceSnapshot source;
            if (!ReadAmbienceImageSource(bindings_, panel, read, source))
                continue;
            ID3D11ShaderResourceView* raw = nullptr;
            if (!Retain(source.srv, raw))
                continue;
            Queued q;
            q.job = job;
            q.view.Attach(raw);
            q.codec = codec.codec;
            if (!cache.Claim(job))
                continue;
            std::lock_guard<std::mutex> lock(mutex_);
            queue_.push_back(std::move(q));
        }
        return true;
    }

    void ResetReadback(AmbienceImageReadback& readback) {
        readback.Reset();
        for (auto& r : extraReadbacks_)
            r.Reset();
        ClearQueue();
        GameInventoryArtwork().InvalidatePending();
    }
    bool NeedsPump(ID3D11Device* device, const AmbienceImageReadback& readback) const {
        if (device_ != reinterpret_cast<std::uintptr_t>(device) || readback.Pending())
            return true;
        for (const auto& r : extraReadbacks_)
            if (r.Pending())
                return true;
        std::lock_guard<std::mutex> lock(mutex_);
        return !queue_.empty();
    }

    void Pump(ID3D11Device* device, ID3D11DeviceContext* context, AmbienceImageReadback& readback) {
        const auto now = InventoryArtworkClock();
        auto& cache = GameInventoryArtwork();
        if (device_ != reinterpret_cast<std::uintptr_t>(device)) {
            device_ = reinterpret_cast<std::uintptr_t>(device);
            ResetReadback(readback);
        }
        auto lane = [&](AmbienceImageReadback& r) {
            if (r.Pending() && !cache.Live(r.Job()))
                r.Reset();
            AmbienceImageReadback::Completion done;
            if (r.Poll(context, now, done)) {
                auto image =
                    done.image ? InventoryArtworkRGBA(done.image->width, done.image->height, done.image->rgba)
                               : nullptr;
                if (!image || !cache.Publish(done.job, std::move(image)))
                    cache.Reject(done.job, now);
            }
            if (r.Pending())
                return;

            for (unsigned i = 0; i < 64; ++i) {
                Queued q;
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    if (queue_.empty())
                        return;
                    q = std::move(queue_.front());
                    queue_.pop_front();
                }
                if (!cache.Live(q.job))
                    continue;
                if (!r.Begin(device, context, q.view.Get(), q.job, now, q.codec, 1024, 1024))
                    cache.Reject(q.job, now);
                return;
            }
        };
        lane(readback);
        for (auto& r : extraReadbacks_)
            lane(r);
    }

    std::string Diagnostic() const {
        return "Econ artwork: " + diagnostic_ + "; " + GameInventoryArtwork().Stats();
    }
    void Stop() {
        ready_ = false;
        LostRoot();
        ClearQueue();
        metadata_.Stop();
    }
};
}
#undef MENU_ECON_TRY
#undef MENU_ECON_EXCEPT
