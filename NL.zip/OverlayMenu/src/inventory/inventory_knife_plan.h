#pragma once
#include "inventory_catalog.h"
#include "inventory_knife_experiment.h"
namespace menu::knife_experiment {
inline Plan MakePlan(const InventoryCatalog& catalog, const InventoryValues& cfg) {
    Plan plan;
    for (const auto& model : InventoryKnives) {
        auto it = catalog.definitions.find(model.index);
        if (it != catalog.definitions.end() && ModelPath(it->second.model))
            plan.models[model.index] = it->second.model;
    }
    for (int side = 0; side < 2; ++side) {
        const auto& team = cfg.teams[std::size_t(side)];
        auto& out = plan.side[std::size_t(side)];
        const int def = team.knife;
        if (!def || !InventoryKnife(def))
            continue;
        auto it = plan.models.find(def);
        if (it == plan.models.end())
            continue;
        out.def = def;
        out.path = it->second;
        if (const auto* item = team.Find(def)) {
            if (item->paintKit > 0)
                if (const auto* paint = catalog.Paint(item->paintKit)) {
                    out.finish = InventoryTargetFor(*item, def, 0);
                    out.finish.wear =
                        InventoryWearFloat(item->wearTier, item->wearValue, paint->wearMin, paint->wearMax);
                    out.palette = inventory_color::FromItem(*item);
                    out.hasFinish = true;
                }
        }
    }
    return plan;
}
}
