#pragma once
#include "inventory_background.h"
#include "renderer_dx11.h"
namespace menu {

struct InventoryBackgroundGPU {
    void Draw(wm::RendererDX11& renderer, ID3D11RenderTargetView* target, int, int, Box b, float radius,
              float mix, float alpha) {
        if (b.w <= 0 || b.h <= 0 || alpha <= 0)
            return;
        const auto c = InventoryBackground(mix, alpha);
        renderer.ClearClip();
        renderer.DrawOriginalHorizontalGradient(target, b.x, b.y, b.w, b.h,
                                                {c.left.r, c.left.g, c.left.b, c.left.a},
                                                {c.right.r, c.right.g, c.right.b, c.right.a}, radius);
    }
};
}
