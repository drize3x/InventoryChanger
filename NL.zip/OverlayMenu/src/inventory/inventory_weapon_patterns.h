#pragma once
#include "watermark_hud_patterns.h"
#include <map>
namespace menu::weapon_inmatch {
struct Tables {
    std::uintptr_t main = 0, attributes = 0;
};

inline bool MatchingGunPair(const std::map<int, Tables>& tables, int def, std::uintptr_t main,
                            std::uintptr_t attributes) {
    if (!tables.count(def) || !main || !attributes)
        return false;
    for (const auto& [id, t] : tables)
        if (t.main == main && t.attributes == attributes)
            return true;
    return false;
}
inline std::map<int, Tables> ResolveTables(const HudScanImage& image) {
    static const std::pair<int, const char*> names[] = {{1, ".?AVC_DEagle@@"},
                                                        {2, ".?AVC_WeaponElite@@"},
                                                        {3, ".?AVC_WeaponFiveSeven@@"},
                                                        {4, ".?AVC_WeaponGlock@@"},
                                                        {7, ".?AVC_AK47@@"},
                                                        {8, ".?AVC_WeaponAug@@"},
                                                        {9, ".?AVC_WeaponAWP@@"},
                                                        {10, ".?AVC_WeaponFamas@@"},
                                                        {11, ".?AVC_WeaponG3SG1@@"},
                                                        {13, ".?AVC_WeaponGalilAR@@"},
                                                        {14, ".?AVC_WeaponM249@@"},
                                                        {16, ".?AVC_WeaponM4A1@@"},
                                                        {17, ".?AVC_WeaponMAC10@@"},
                                                        {19, ".?AVC_WeaponP90@@"},
                                                        {23, ".?AVC_WeaponMP5SD@@"},
                                                        {24, ".?AVC_WeaponUMP45@@"},
                                                        {25, ".?AVC_WeaponXM1014@@"},
                                                        {26, ".?AVC_WeaponBizon@@"},
                                                        {27, ".?AVC_WeaponMag7@@"},
                                                        {28, ".?AVC_WeaponNegev@@"},
                                                        {29, ".?AVC_WeaponSawedoff@@"},
                                                        {30, ".?AVC_WeaponTec9@@"},
                                                        {31, ".?AVC_WeaponTaser@@"},
                                                        {32, ".?AVC_WeaponHKP2000@@"},
                                                        {33, ".?AVC_WeaponMP7@@"},
                                                        {34, ".?AVC_WeaponMP9@@"},
                                                        {35, ".?AVC_WeaponNOVA@@"},
                                                        {36, ".?AVC_WeaponP250@@"},
                                                        {38, ".?AVC_WeaponSCAR20@@"},
                                                        {39, ".?AVC_WeaponSG556@@"},
                                                        {40, ".?AVC_WeaponSSG08@@"},
                                                        {60, ".?AVC_WeaponM4A1Silencer@@"},
                                                        {61, ".?AVC_WeaponUSPSilencer@@"},
                                                        {63, ".?AVC_WeaponCZ75a@@"},
                                                        {64, ".?AVC_WeaponRevolver@@"}};

    std::map<std::string, int> byName;
    for (auto x : names)
        byName[x.second] = x.first;
    std::map<std::uint32_t, int> descriptors;
    std::map<int, int> nameCount;
    for (const auto& part : image.parts) {
        if (part.flags & 0x20000000)
            continue;
        for (std::size_t i = 16; i + 7 < part.bytes.size(); ++i) {
            const auto* p = part.bytes.data() + i;
            if (std::memcmp(p, ".?AVC_", 6))
                continue;
            auto end = std::find(p, part.bytes.data() + part.bytes.size(), 0);
            if (end == part.bytes.data() + part.bytes.size() || end - p > 100)
                continue;
            auto it = byName.find(std::string(reinterpret_cast<const char*>(p), end - p));
            if (it == byName.end())
                continue;
            auto addr = part.start + i - 16;
            if (addr < image.module.base || addr - image.module.base > 0xffffffffu)
                continue;
            descriptors[std::uint32_t(addr - image.module.base)] = it->second;
            ++nameCount[it->second];
        }
    }
    std::map<std::uintptr_t, std::pair<int, int>> cols;
    for (const auto& p : image.parts) {
        if (p.flags & (0x20000000 | 0x80000000))
            continue;
        for (std::size_t i = 0; i + 24 <= p.bytes.size(); i += 4) {
            std::uint32_t v[6]{};
            std::memcpy(v, p.bytes.data() + i, sizeof v);
            if (v[0] != 1 || (v[1] != 0 && v[1] != 0x1268) || v[2] != 0)
                continue;
            auto d = descriptors.find(v[3]);
            auto col = p.start + i;
            if (d == descriptors.end() || nameCount[d->second] != 1 ||
                std::uint64_t(v[5]) != col - image.module.base ||
                !image.Contains(image.module.base + v[4], 16, 0, 0x20000000))
                continue;
            cols[col] = {d->second, v[1] ? 1 : 0};
        }
    }
    std::map<int, std::array<std::vector<std::uintptr_t>, 2>> found;
    for (const auto& p : image.parts) {
        if (p.flags & (0x20000000 | 0x80000000))
            continue;
        for (std::size_t i = 0; i + 16 <= p.bytes.size(); i += 8) {
            std::uintptr_t x = 0, first = 0;
            std::memcpy(&x, p.bytes.data() + i, 8);
            auto c = cols.find(x);
            if (c == cols.end())
                continue;
            std::memcpy(&first, p.bytes.data() + i + 8, 8);
            if (image.Contains(first, 1, 0x20000000))
                found[c->second.first][c->second.second].push_back(p.start + i + 8);
        }
    }
    std::map<int, Tables> out;
    const unsigned char expected[] = {0x48, 0x8d, 0x41, 0x28, 0xc3};
    for (auto& [def, ts] : found) {
        auto& v = ts[0];
        auto& a = ts[1];
        std::sort(v.begin(), v.end());
        v.erase(std::unique(v.begin(), v.end()), v.end());
        std::sort(a.begin(), a.end());
        a.erase(std::unique(a.begin(), a.end()), a.end());
        std::uintptr_t fn = 0;
        unsigned char bytes[5]{};
        if (v.size() == 1 && a.size() == 1 && image.Read(a[0] + 24, fn) &&
            image.Contains(fn, 5, 0x20000000) && image.Bytes(fn, bytes, 5) &&
            !std::memcmp(bytes, expected, 5))
            out[def] = {v[0], a[0]};
    }
    return out;
}
inline std::uintptr_t ResolveMeshSetter(const HudScanImage& image) {
    auto f = image.Find("48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 48 8D 99 40 01 00 00 48 8B 71 30 48 8B "
                        "FA 48 39 93 08 02 00 00 74 ?",
                        true, 2);
    return f.size() == 1 ? f[0] : 0;
}

}

namespace menu::weapon_inmatch {

inline std::uintptr_t ResolveCharmUpdater(const HudScanImage& image) {
    auto fn = image.Find("44 88 44 24 18 48 89 54 24 10 48 89 4C 24 08 55 53 56 57 41 54 41 55 41 56 41 57 "
                         "48 8D AC 24 58 FE FF FF",
                         true, 2);
    auto call = image.Find("45 33 C0 48 8B CB 48 8D 50 50 E8 ? ? ? ? 48 8B 53 10 8B 42 30", true, 2);
    if (fn.size() != 1 || call.size() != 1 || image.Rip(call[0] + 10, 1, 5) != fn[0])
        return 0;

    auto guard =
        image.Find("40 38 BB 62 1B 00 00 75 ? 48 8B CB E8 ? ? ? ? 84 C0 75 ? 48 8D BB 68 12 00 00", true, 2);
    if (guard.size() != 1 || guard[0] >= call[0] || call[0] - guard[0] > 0x100)
        return 0;
    return fn[0];
}
}
