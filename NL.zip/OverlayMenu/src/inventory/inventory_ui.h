#pragma once

#include "group_row_geometry.h"
#include "players_remaining_preview.h"
#include "hud_color_picker.h"
#include "world_tooltip.h"
#include "presets_edit.h"
#include "inventory_content.h"
#include "inventory_live_rarity.h"
#include "inventory_medal_icon.h"
#include "inventory_team_icons.h"
#include "inventory_preview.h"
#include "inventory_art_prefetch.h"
#include <random>
namespace menu {
struct InventoryUI {
    enum Action : int {
        Surface = 0,
        Panel,
        Team,
        Card,
        CloseButton,
        Paint,
        WeaponDrop,
        WeaponOption,
        SortDrop,
        SortOption,
        SearchBox,
        ModelChip,
        ModelOption,
        ToolOptions,
        ToolCamera,
        ToolBig,
        ToolBoth,
        OptRow,
        OptSlider,
        OptValue,
        OptName,
        OptOption,
        ContextItem,
        GridThumb,
        MoveMode,
        Slot,
        StickerFilter,
        CharmRandom,
        PageScroll,
        CapsuleDrop,
        CapsuleOption,
        ModelDrag,
        BigClose,
        BigBackdrop
    };
    enum Kind : int { KindWeapon = 0, KindKnife, KindGloves, KindTaser, KindAgent, KindMedal, KindMusic };
    enum CardId : int { CardAgent = 15, CardMedal, CardMusic, CardKnife, CardGloves, CardTaser, CardCount };
    enum Opt : int {
        OptNameRow = 0,
        OptSeed,
        OptColors,
        OptWear,
        OptWearValue,
        OptStatTrak,
        OptStatTrakValue,
        OptAnimations,
        OptInspect,
        OptDeploy,
        OptIdle,
        OptChams,
        OptChamsModel,
        OptChamsModelOverlay,
        OptChamsArms,
        OptChamsArmsOverlay,
        OptColorizeStatTrak,
        OptGlow,
        OptCloth,
        OptSleeves,
        OptFrost,
        OptCount
    };
    enum OptType : int {
        TypeText = 0,
        TypeSlider,
        TypeColor,
        TypeChoice,
        TypeNumber,
        TypeHeading,
        TypeToggle,
        TypeToggleColor
    };
    struct OptSpec {
        const char* key;
        OptType type;
        bool child;
    };

    static constexpr std::array<OptSpec, OptCount> OptSpecs{{
        {"inventory_skinoptions_name", TypeText, false},
        {"inventory_skinoptions_seed", TypeSlider, false},
        {"inventory_skinoptions_colors", TypeColor, false},
        {"inventory_skinoptions_wear", TypeChoice, false},
        {"inventory_skinoptions_wear_value", TypeSlider, false},
        {"inventory_skinoptions_stattrak", TypeChoice, false},
        {"inventory_skinoptions_stattrak_value", TypeSlider, false},
        {"inventory_skinoptions_animations", TypeHeading, false},
        {"inventory_skinoptions_inspect_animation", TypeChoice, true},
        {"inventory_skinoptions_deploy_animation", TypeChoice, true},
        {"inventory_skinoptions_idle_animation", TypeChoice, true},
        {"inventory_skinoptions_chams", TypeHeading, false},
        {"visuals_localplayer_model", TypeColor, true},
        {"visuals_chams_overlay", TypeColor, true},
        {"visuals_localplayer_model_arms", TypeColor, true},
        {"visuals_chams_overlay", TypeColor, true},
        {"visuals_localplayer_weapon_settings_colorizestattrak", TypeToggleColor, true},
        {"visuals_localplayer_model_player_glow", TypeToggleColor, true},
        {"inventory_skinoptions_cloth_physics", TypeToggle, false},
        {"inventory_skinoptions_remove_sleeves", TypeToggle, false},
        {"inventory_skinoptions_frost", TypeToggle, false},
    }};
    struct Hit {
        Box box{};
        Action action = Surface;
        int field = -1, option = -1;
        std::int64_t Key() const {
            return (std::int64_t(action) << 40) | (std::int64_t(field + 2) << 24) | std::int64_t(option + 2);
        }
    };
    struct Entry {
        int id = 0, rarity = 0, weapon = 0, section = 0;
        std::u32string name, group, description;
        bool header = false;
    };
    struct GridRow {
        bool header = false;
        std::size_t first = 0, count = 0;
        float y = 0, h = 0;
    };
    struct IconImage {
        std::shared_ptr<const Canvas> source, image;
        std::uint64_t stamp = 0;
    };
    struct Clip {
        bool has = false;
        Kind kind = KindWeapon;
        InventoryItem item;
        int named = 0;
    };
    struct SlotClip {
        bool has = false, charm = false;
        InventorySticker sticker;
        InventoryCharm keychain;
    };
    struct WindowTransition {
        PresetMotion motion;
        std::vector<PresetLayer> cached;
    };

    InventoryCharm nativeItemCharm{}, charmDragPreview{}, charmDragOriginal{};
    bool charmDrag = false;
    std::array<InventorySticker, 5> nativeItemStickers{};
    InventorySticker stickerDragOriginal{}, stickerDragPreview{};
    bool stickerDrag = false, nativeStickerDragging = false;
    int stickerMoveSlot = -1, stickerDragSlot = -1, stickerDragTeam = -1, stickerDragEditor = -1,
        stickerDragWeapon = 0, stickerDragPaint = 0;
    int charmDragTeam = -1, charmDragEditor = -1, charmDragWeapon = 0, charmDragPaint = 0;
    bool nativeItemPreview = false, nativeItemMusic = false, modelDrag = false;
    int nativeItemDefinition = 4, nativeItemPaint = 0, nativeItemTeam = -1, nativeItemActiveIndex = 0;
    std::array<int, 5> nativeItemPremier{{-1, -1, -1, -1, -1}};
    float modelYaw = 0, modelPitch = 0, modelLastX = 0, modelLastY = 0;
    PresetsUI paint;
    LanguageCatalog* languages = nullptr;
    HudColorPicker picker;
    const InventoryCatalog* catalogOverride = nullptr;
    std::shared_ptr<const InventoryCatalog> catalogHold;
    const InventoryCatalog* cat = nullptr;
    std::vector<Hit> hits;
    std::array<Color, 46> palette{};
    Box drawClip{};
    bool visible = false, blocked = false, searchFocus = false, bigPreview = false, cameraZoom = false,
         optionsOpen = false, hideTournament = false, nameEditing = false, valueEditing = false,
         selectAll = false, thumbDrag = false, contextOpen = false;
    int paintColorChannel = -1;
    int capsule = -1, team = InventoryCT, editor = -1, shownEditor = -1, drop = -1, choice = -1, color = -1,
        drag = -1, sort = 0, moveMode = 1, stickerSlot = -1, contextCard = -1, contextSlot = -1;
    std::int64_t held = -1, hover = -1;
    float scale = 1, F = 13, mouseX = -1, mouseY = -1, hoverTime = 0, thumbGrab = 0;
    float gridScroll = 0, gridTarget = 0, gridMax = 0, optionsScroll = 0, optionsMax = 0, dropScroll = 0,
          dropMax = 0, pageScroll = 0, pageMax = 0;
    Box viewport{}, pageBody{}, overlay{}, bigBox{}, gridBox{}, gridTrack{}, gridThumb{}, optionsBox{},
        optionsBody{}, dropBox{}, dropAnchor{}, optionsAnchor{}, contextBox{}, searchBox{}, nameBox{},
        valueBox{}, chipBox{}, previewBox{}, itemSourceBox{}, itemPreviewClip{}, loadoutPreviewBox{};
    std::array<Box, OptCount> optRows{}, optSliders{}, optControls{};
    std::array<Box, CardCount> cardBoxes{};
    std::array<Box, 6> slotBoxes{};
    std::u32string search, nameText;
    PresetEditor searchEdit, nameEdit;
    std::string numeric;
    char16_t highSurrogate = 0;
    std::map<std::int64_t, PresetMotion> hoverMotion;
    PresetMotion editorMotion, tooltipMotion;
    PresetLayer lastTooltip{};
    bool tooltipStored = false;
    std::map<int, WindowTransition> transitions;
    std::set<int> drawnWindows;
    std::vector<Entry> entries;
    std::vector<GridRow> gridRows;
    std::string entriesKey;
    float gridContent = 0;
    std::map<std::uint64_t, IconImage> iconCache;
    std::map<std::string, IconImage> artworkCache, moveTintCache;
    std::map<std::array<std::uint32_t, 9>, IconImage> rarityCache;
    Clip clip;
    SlotClip slotClip;
    unsigned randomState = 0x9E3779B9u;

    std::array<PresetMotion, 2> teamExpand, teamHover, moveExpand, moveHover;
    PresetMotion teamBackground;
    float teamRowWidth = -1;
    std::uint64_t nextArtWarm = 0;
    const InventoryAssets* assetsOverride = nullptr;
    std::shared_ptr<const InventoryAssets> assetsHold;
    const InventoryAssets* assets = nullptr;
    std::array<std::shared_ptr<const Canvas>, 2> teamSource;
    std::map<std::uint64_t, IconImage> teamIcons;

    std::u32string Label(const std::string& k) const {
        if (k.empty())
            return {};
        if (languages)
            return languages->Label(k);
        auto it = DefaultLanguageStrings().find(k);
        return DecodeUTF8(it == DefaultLanguageStrings().end() ? k : it->second);
    }
    static std::u32string Upper(std::u32string v) {
        for (auto& c : v)
            if (c >= 'a' && c <= 'z')
                c -= 32;
        return v;
    }
    static std::u32string Lower(std::u32string v) {
        for (auto& c : v)
            if (c >= 'A' && c <= 'Z')
                c += 32;
        return v;
    }
    static bool Contains(const std::u32string& hay, const std::u32string& needle) {
        return needle.empty() || Lower(hay).find(Lower(needle)) != std::u32string::npos;
    }

    static std::u32string Plain(const std::string& s) {
        std::u32string out;
        bool tag = false;
        for (char32_t c : DecodeUTF8(s)) {
            if (c == '<') {
                tag = true;
                continue;
            }
            if (tag) {
                if (c == '>')
                    tag = false;
                continue;
            }
            out.push_back(c);
        }
        auto replace = [&](const std::u32string& a, const std::u32string& b) {
            std::size_t p = 0;
            while ((p = out.find(a, p)) != std::u32string::npos) {
                out.replace(p, a.size(), b);
                p += b.size();
            }
        };
        replace(U"&quot;", U"\"");
        replace(U"&amp;", U"&");
        replace(U"\\n", U"\n");
        return out;
    }
    const InventoryCatalog& Cat() const {
        static const InventoryCatalog empty;
        return cat ? *cat : empty;
    }
    void RefreshCatalog() {
        if (catalogOverride) {
            if (cat != catalogOverride)
                entriesKey.clear();
            cat = catalogOverride;
            return;
        }
        auto c = InventorySharedContent().Catalog();
        if (c != catalogHold) {
            catalogHold = c;
            entriesKey.clear();
        }
        cat = catalogHold.get();
    }
    void RefreshAssets() {
        const InventoryAssets* next = assetsOverride;
        if (!next) {
            auto a = InventorySharedContent().Assets();
            if (a != assetsHold)
                assetsHold = a;
            next = assetsHold.get();
        }
        if (next != assets) {
            assets = next;
            teamSource.fill(nullptr);
            teamIcons.clear();
        }
    }
    std::u32string ItemName(int index) const {
        const auto& c = Cat();
        if (auto w = InventoryWeapon(index))
            return DecodeUTF8(c.ItemName(index, w->name));
        if (auto k = InventoryKnife(index))
            return DecodeUTF8(c.ItemName(index, k->name));
        if (auto g = InventoryGlove(index))
            return DecodeUTF8(c.ItemName(index, g->name));
        return DecodeUTF8(c.ItemName(index, ("#" + std::to_string(index)).c_str()));
    }
    std::u32string WearName(int tier) const {
        tier = std::clamp(tier, 0, 4);
        const auto& n = Cat().wearNames[std::size_t(tier)];
        return DecodeUTF8(n.empty() ? InventoryWearNames[std::size_t(tier)] : n);
    }

    static Kind CardKind(int c) {
        return c < 15            ? KindWeapon
               : c == CardKnife  ? KindKnife
               : c == CardGloves ? KindGloves
               : c == CardTaser  ? KindTaser
               : c == CardAgent  ? KindAgent
               : c == CardMedal  ? KindMedal
                                 : KindMusic;
    }
    static bool PaintKind(Kind k) {
        return k == KindWeapon || k == KindKnife || k == KindGloves || k == KindTaser;
    }
    const InventoryLoadout& Loadout(const Settings& cfg) const {
        return cfg.inventory.teams[std::size_t(team)];
    }
    InventoryLoadout& Loadout(Settings& cfg) const {
        return cfg.inventory.teams[std::size_t(team)];
    }
    int CardIndex(const Settings& cfg, int c) const {
        if (c >= 0 && c < 15)
            return Loadout(cfg).slots[std::size_t(c)];
        if (c == CardKnife)
            return cfg.inventory.Knife(team);
        if (c == CardGloves)
            return cfg.inventory.Gloves(team);
        if (c == CardTaser)
            return 31;
        return 0;
    }
    static int NamedValue(const InventoryLoadout& l, Kind k) {
        return k == KindAgent ? l.agent : k == KindMedal ? l.medal : l.music;
    }
    static int& NamedRef(InventoryLoadout& l, Kind k) {
        return k == KindAgent ? l.agent : k == KindMedal ? l.medal : l.music;
    }
    const std::vector<InventoryNamed>& NamedList(Kind k) const {
        const auto& c = Cat();
        return k == KindAgent ? c.agents : k == KindMedal ? c.medals : c.music;
    }
    const InventoryNamed* FindNamed(Kind k, int id) const {
        for (const auto& n : NamedList(k))
            if (n.id == id)
                return &n;
        return nullptr;
    }
    int PreviewMusicId(int selected) const {
        if (selected > 0 && selected <= 65535)
            return selected;
        for (const auto& n : Cat().music)
            if (n.key == "valve_cs2_01" && n.id > 0 && n.id <= 65535)
                return n.id;
        return 0;
    }
    int DisplayRarity(int index, const InventoryPaint* p) const {
        if (p && !catalogOverride) {
            const int live = GameInventoryRarity().Query({index, p->id});
            if (live >= 1)
                return live;
        }
        return InventoryFinishRarity(Cat(), index, p);
    }
    struct CardInfo {
        int index = 0;
        Kind kind = KindWeapon;
        std::u32string weapon, skin;
        int rarity = 0;
        bool configured = false;
        const InventoryPaint* paint = nullptr;
    };
    CardInfo Info(const Settings& cfg, int c) const {
        CardInfo i;
        i.kind = CardKind(c);
        i.index = CardIndex(cfg, c);
        if (PaintKind(i.kind)) {
            i.weapon = ItemName(i.index);
            if (auto it = Loadout(cfg).Find(i.index)) {
                i.configured = !it->Default();
                if (it->paintKit > 0) {
                    i.paint = Cat().Paint(it->paintKit);
                    i.skin =
                        i.paint ? DecodeUTF8(i.paint->name) : DecodeUTF8("#" + std::to_string(it->paintKit));
                    i.rarity = i.paint ? DisplayRarity(i.index, i.paint) : 1;
                }
            }
            if (i.kind == KindKnife && Loadout(cfg).knife)
                i.configured = true;
            if (i.kind == KindGloves && Loadout(cfg).gloves)
                i.configured = true;
            return i;
        }
        int v = NamedValue(Loadout(cfg), i.kind);
        i.index = v;
        i.configured = v != 0;
        if (v) {
            auto n = FindNamed(i.kind, v);
            i.skin = n ? DecodeUTF8(n->name) : DecodeUTF8("#" + std::to_string(v));
            i.rarity = n ? std::clamp(n->rarity, 0, 7) : 1;
        }
        return i;
    }
    std::u32string Title(const CardInfo& i) const {
        if (i.kind == KindAgent && i.index == 0)
            return DefaultAgentName();
        if (!PaintKind(i.kind))
            return i.skin.empty() ? Label("inventory_skinoptions_animation_default") : i.skin;
        if (i.skin.empty())
            return i.weapon;
        return i.weapon + U" | " + i.skin;
    }
    static int EquipmentIcon(int index) {
        const char* raw = nullptr;
        if (auto k = InventoryKnife(index))
            raw = k->id;
        else if (auto w = InventoryWeapon(index))
            raw = w->id;
        if (raw) {
            std::string id = raw;
            if (id.rfind("weapon_", 0) == 0)
                id.erase(0, 7);
            return LiveEquipmentIconIndex(id);
        }
        return -1;
    }

    std::u32string DefaultAgentName() const {
        const auto& n = Cat().defaultAgentNames[team == InventoryT ? 1 : 0];
        return n.empty() ? U"Agent" : DecodeUTF8(n);
    }
    static char32_t PlaceholderGlyph(Kind k) {
        switch (k) {
        case KindAgent:
            return 0xf007;
        case KindMusic:
            return 0xf001;
        case KindGloves:
            return 0xf7b5;
        default:
            return 0;
        }
    }
    Kind EditorKind() const {
        return CardKind(std::max(0, shownEditor));
    }
    bool Scoped(int index) const {
        auto w = InventoryWeapon(index);
        return w && w->scoped;
    }
    bool StickerCapable(const Settings& cfg) const {
        return shownEditor >= 0 && shownEditor < 15 &&
               InventoryWeapon(CardIndex(cfg, shownEditor)) != nullptr;
    }

    int Layer(Box b, bool pop = false, float radius = 0) {
        paint.layers.push_back({b, radius, pop, {}});
        paint.layers.back().pixelAligned = true;
        return int(paint.layers.size()) - 1;
    }
    PresetDraw& Push(int z, PresetDraw d) {
        d.clipped = true;
        d.clip = paint.layers[std::size_t(z)].box;
        if (drawClip.w > 0)
            d.clip = PresetIntersect(d.clip, drawClip);
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        return paint.layers[std::size_t(z)].draw.back();
    }
    void Rect(int z, Box b, Color c, float radius = 0, float stroke = 0, unsigned corners = 15) {
        if (b.w <= 0 || b.h <= 0 || c.a <= 0)
            return;
        PresetDraw d{b, c, radius, stroke, corners, {}, false};
        Push(z, std::move(d));
    }
    void Text(int z, Box b, const std::u32string& v, Color c, int font = 0, float px = 13,
              bool standalone = false) {
        if (v.empty() || b.w <= 0 || b.h <= 0 || c.a <= 0)
            return;
        PresetDraw d{b, c, 0, 0, 15, v, font == 3 && !standalone};
        d.font = font;
        d.textSize = px;
        Push(z, std::move(d));
    }
    void AddHit(int z, Box b, Action a, int f = -1, int opt = -1) {
        if (blocked)
            return;
        b = PresetIntersect(b, paint.layers[std::size_t(z)].box);
        if (drawClip.w > 0)
            b = PresetIntersect(b, drawClip);
        if (b.w > 0 && b.h > 0)
            hits.push_back({b, a, f, opt});
    }
    int SurfaceLayer(Box b, float radius = 15) {
        int z = Layer(b, true, radius * scale);
        Rect(z, b, palette[8], radius * scale);
        Rect(z, b, palette[11], radius * scale, scale);
        return z;
    }
    float Hover(Action a, int f = -1, int opt = -1) const {
        auto it = hoverMotion.find(Hit{{}, a, f, opt}.Key());
        return it == hoverMotion.end() ? 0.f : it->second.value;
    }
    static Color Alpha(Color c, float a) {
        c.a *= a;
        return c;
    }
    float TextW(Fonts& f, const std::u32string& t, int font = 0, float px = 13) const {
        return f.NativeTextSize(font, px * scale, t).w;
    }
    std::u32string Fit(Fonts& f, const std::u32string& text, float width, int font = 0, float px = 13) const {
        if (width <= 0)
            return {};
        auto out = text;
        if (f.NativeTextSize(font, px * scale, out).w <= width)
            return out;
        while (!out.empty() && f.NativeTextSize(font, px * scale, out + U"…").w > width)
            out.pop_back();
        return out.empty() ? U"" : out + U"…";
    }
    void Swatch(int z, Box b, Color c, float alpha) {
        Box rb{std::floor(b.x) - 1, std::floor(b.y) - 1, std::ceil(b.x + b.w) - std::floor(b.x) + 2,
               std::ceil(b.y + b.h) - std::floor(b.y) + 2};
        auto image = std::make_shared<Canvas>(int(rb.w), int(rb.h));
        DrawPickerPreview(*image, {b.x - rb.x, b.y - rb.y, b.w, b.h}, scale, F + 14 * scale, c, c, false,
                          false);
        PresetDraw d{rb, {1, 1, 1, alpha}, 0, 0, 15, {}, false};
        d.raster = image;
        d.rasterStamp = PickerPreviewStamp(c, c, false, false);
        Push(z, std::move(d));
    }

    std::shared_ptr<const Canvas> IconSource(int icon) {
        if (icon < 0)
            return {};
        auto source = GamePreviewIcons().Get(unsigned(icon));
        return source ? source
                      : (icon == LiveEquipmentIconIndex("flair0") ? InventoryDefaultMedalIcon() : nullptr);
    }
    const IconImage* Icon(int icon, float height, Color c) {
        if (icon < 0 || !(height > 0))
            return nullptr;
        auto source = IconSource(icon);
        if (!source || source->width <= 0 || source->height <= 0)
            return nullptr;
        const int h = std::clamp(int(std::round(height)), 1, 256),
                  w = std::clamp(int(std::round(float(source->width) * float(h) / float(source->height))), 1,
                                 1024);
        auto q = [](float v) { return std::uint64_t(std::clamp(int(v * 255.f + .5f), 0, 255)); };
        const std::uint64_t key = (std::uint64_t(icon) << 56) | (std::uint64_t(h) << 40) | (q(c.r) << 24) |
                                  (q(c.g) << 16) | (q(c.b) << 8) | q(c.a);
        auto found = iconCache.find(key);
        if (found != iconCache.end() && found->second.source == source)
            return &found->second;
        if (iconCache.size() > 384)
            iconCache.clear();
        auto image = std::make_shared<Canvas>(w, h);
        auto alpha = [&](int x, int y) {
            x = std::clamp(x, 0, source->width - 1);
            y = std::clamp(y, 0, source->height - 1);
            return source->rgba[4 * (std::size_t(y) * std::size_t(source->width) + std::size_t(x)) + 3] /
                   255.f;
        };
        const float rx = float(source->width) / float(w), ry = float(source->height) / float(h);
        const int taps = std::clamp(int(std::ceil(std::max(rx, ry))), 1, 4);
        for (int y = 0; y < h; ++y)
            for (int x = 0; x < w; ++x) {
                float cover = 0;
                for (int ty = 0; ty < taps; ++ty)
                    for (int tx = 0; tx < taps; ++tx) {
                        float sx = (float(x) + (float(tx) + .5f) / float(taps)) * rx - .5f,
                              sy = (float(y) + (float(ty) + .5f) / float(taps)) * ry - .5f;
                        int ix = int(std::floor(sx)), iy = int(std::floor(sy));
                        float fx = sx - float(ix), fy = sy - float(iy);
                        float top = alpha(ix, iy) * (1 - fx) + alpha(ix + 1, iy) * fx,
                              bottom = alpha(ix, iy + 1) * (1 - fx) + alpha(ix + 1, iy + 1) * fx;
                        cover += top * (1 - fy) + bottom * fy;
                    }
                image->Blend(x, y, c, cover / float(taps * taps));
            }
        std::uint64_t hash = 14695981039346656037ull;
        for (auto b : image->rgba) {
            hash ^= b;
            hash *= 1099511628211ull;
        }
        auto& e = iconCache[key];
        e.source = source;
        e.image = image;
        e.stamp = (hash ^ (key * 0x9E3779B97F4A7C15ull)) | 1ull;
        return &e;
    }

    const IconImage* TeamIcon(int t, int size) {
        if (t < 0 || t > 1 || size <= 0 || size > 512)
            return nullptr;
        auto& source = teamSource[std::size_t(t)];
        if (!source)
            source = InventoryTeamLogo(t, assets ? assets->teamLogos[std::size_t(t)] : std::string());
        if (!source)
            return nullptr;
        const std::uint64_t key = (std::uint64_t(t) << 32) | std::uint64_t(size);
        auto found = teamIcons.find(key);
        if (found != teamIcons.end() && found->second.source == source)
            return &found->second;
        if (teamIcons.size() > 32)
            teamIcons.clear();
        auto image = InventoryResampleLogo(*source, size);
        if (!image)
            return nullptr;
        std::uint64_t hash = 14695981039346656037ull;
        for (auto b : image->rgba) {
            hash ^= b;
            hash *= 1099511628211ull;
        }
        auto& e = teamIcons[key];
        e.source = source;
        e.image = image;
        e.stamp = (hash ^ (key * 0x9E3779B97F4A7C15ull)) | 1ull;
        return &e;
    }
    void Image(int z, float x, float y, const IconImage* im, float alpha = 1) {
        if (!im)
            return;
        PresetDraw d{{std::round(x), std::round(y), float(im->image->width), float(im->image->height)},
                     {1, 1, 1, alpha},
                     0,
                     0,
                     15,
                     {},
                     false};
        d.raster = im->image;
        d.rasterStamp = im->stamp;
        Push(z, std::move(d));
    }

    void EditorRarityLine(int z, Box b, Color color) {
        if (b.w <= 0 || b.h <= 0 || color.a <= 0)
            return;
        Rect(z, b, color);
        paint.layers[std::size_t(z)].draw.back().pixelLine = true;
    }

    void RarityStrip(int z, Box card, Color color) {
        const auto b = InventoryRarityStrip(card, scale);
        if (b.w <= 0 || b.h <= 0)
            return;
        const float x = std::floor(b.x), y = std::floor(b.y), radius = std::min(5 * scale, b.h * .5f);
        const std::array<float, 9> values{
            {b.x - x, b.y - y, b.w, b.h, radius, color.r, color.g, color.b, color.a}};
        std::array<std::uint32_t, 9> key{};
        std::memcpy(key.data(), values.data(), sizeof key);
        auto found = rarityCache.find(key);
        if (found == rarityCache.end()) {
            if (rarityCache.size() >= 128)
                rarityCache.clear();
            auto canvas = std::make_shared<Canvas>(std::max(1, int(std::ceil(b.x + b.w) - x)),
                                                   std::max(1, int(std::ceil(b.y + b.h) - y)));
            canvas->RoundRect({b.x - x, b.y - y, b.w, b.h}, radius, color, {0, 0, 0, 0}, 0, 0, 12);
            std::uint64_t hash = 14695981039346656037ull;
            for (auto q : canvas->rgba) {
                hash ^= q;
                hash *= 1099511628211ull;
            }
            IconImage entry;
            entry.image = canvas;
            entry.stamp = hash | 1ull;
            found = rarityCache.emplace(key, std::move(entry)).first;
        }
        Image(z, x, y, &found->second);
    }
    bool ArtworkDraw(Box b, const std::string& path, PresetDraw& out, float fill = .8f, float alpha = 1) {
        if (path.empty() || b.w <= 2 || b.h <= 2)
            return false;
        auto result = GameInventoryArtwork().Query(path, InventoryArtworkClock());
        auto source = result.image;
        if (!source)
            return false;
        const auto box = InventoryArtworkBox(b, source->width, source->height, fill);
        const int w = std::max(1, int(std::round(box.w))), h = std::max(1, int(std::round(box.h)));
        const auto key = path + ":" + std::to_string(w) + "x" + std::to_string(h);
        auto found = artworkCache.find(key);
        if (found == artworkCache.end() || found->second.source != source) {
            if (artworkCache.size() >= 192)
                artworkCache.clear();
            IconImage entry;
            entry.source = source;
            entry.image = InventoryResizeArtwork(*source, w, h);
            if (entry.image) {
                std::uint64_t hash = 14695981039346656037ull;
                for (auto q : entry.image->rgba) {
                    hash ^= q;
                    hash *= 1099511628211ull;
                }
                entry.stamp = (hash ^ result.revision) | 1ull;
                found = artworkCache.insert_or_assign(key, std::move(entry)).first;
            }
        }
        if (found == artworkCache.end() || !found->second.image)
            return false;
        const auto& im = found->second;
        out = {};
        out.box = {std::round(box.x), std::round(box.y), float(im.image->width), float(im.image->height)};
        out.color = {1, 1, 1, alpha};
        out.raster = im.image;
        out.rasterStamp = im.stamp;
        return true;
    }
    bool ArtworkPath(int z, Box b, const std::string& path, float fill = .8f, float alpha = 1) {
        PresetDraw d;
        if (!ArtworkDraw(b, path, d, fill, alpha))
            return false;
        Push(z, std::move(d));
        return true;
    }

    bool MovingIcon(int z, Box b, const std::string& path, float active) {
        PresetDraw d;
        if (!ArtworkDraw(b, path, d, .88f))
            return false;
        const int level = std::clamp(int(std::round(active * 8.f)), 0, 8);
        if (level < 8) {
            const auto key = std::to_string(d.rasterStamp) + ":" + std::to_string(level);
            auto found = moveTintCache.find(key);
            if (found == moveTintCache.end() || found->second.source != d.raster) {
                if (moveTintCache.size() >= 64)
                    moveTintCache.clear();
                auto image = std::make_shared<Canvas>(*d.raster);
                for (std::size_t i = 0; i + 3 < image->rgba.size(); i += 4) {
                    const auto gray = unsigned(
                        (54u * image->rgba[i] + 183u * image->rgba[i + 1] + 19u * image->rgba[i + 2] + 128u) /
                        256u);
                    for (int c = 0; c < 3; ++c)
                        image->rgba[i + c] =
                            static_cast<unsigned char>((unsigned(image->rgba[i + c]) * unsigned(level) +
                                                        gray * unsigned(8 - level) + 4u) /
                                                       8u);
                }
                std::uint64_t hash = 14695981039346656037ull;
                for (auto q : image->rgba) {
                    hash ^= q;
                    hash *= 1099511628211ull;
                }
                IconImage entry;
                entry.source = d.raster;
                entry.image = image;
                entry.stamp = hash | 1ull;
                found = moveTintCache.insert_or_assign(key, std::move(entry)).first;
            }
            d.raster = found->second.image;
            d.rasterStamp = found->second.stamp;
        }
        Push(z, std::move(d));
        return true;
    }
    void Artwork(Fonts& fonts, int z, Box b, Kind kind, int index, Color ink, float fill = .62f,
                 float alpha = 1, int paintKit = 0) {
        if (b.w <= 2 || b.h <= 2)
            return;
        if (PaintKind(kind)) {
            const auto path = InventoryItemArtworkPath(Cat(), index, paintKit);
            if (ArtworkPath(z, b, path, fill, alpha))
                return;

            auto name = Fit(fonts, ItemName(index), b.w - 8 * scale, 1);
            const float w = TextW(fonts, name, 1);
            Text(z, {b.x + (b.w - w) * .5f, b.y + (b.h - F) * .5f, w + 1, F}, name, Alpha(palette[2], alpha),
                 1);
            return;
        }
        const auto named = kind == KindAgent   ? InventoryNamedArt::Agent
                           : kind == KindMedal ? InventoryNamedArt::Medal
                                               : InventoryNamedArt::Music;
        if (ArtworkPath(z, b, InventoryNamedImage(Cat(), named, index, team), .8f, alpha))
            return;
        if (kind == KindMedal) {
            const float size = std::min(b.h * fill, b.w * .7f);
            if (auto im = FitIcon(LiveEquipmentIconIndex("flair0"), size, size, Alpha(ink, alpha)))
                Image(z, b.x + (b.w - float(im->image->width)) * .5f,
                      b.y + (b.h - float(im->image->height)) * .5f, im);
            return;
        }
        char32_t glyph = PlaceholderGlyph(kind);
        if (glyph) {
            float px = std::max(8.f, std::min(b.h * fill, b.w * .7f) / scale);
            std::u32string g(1, glyph);
            float lh = fonts.PixelHeight(0, px * scale), gw = TextW(fonts, g, 3, px);
            Text(z, {b.x + (b.w - gw) * .5f, b.y + (b.h - lh) * .5f, gw + 2, lh}, g, Alpha(ink, alpha), 3,
                 px);
        }
    }
    float searchTextX = 0, nameTextX = 0, gridPitch = 0;
    Box contextPoint{}, weaponBox{}, sortBox{}, capsuleBox{};

    std::string EntriesKey(const Settings& cfg) const {
        std::string k = std::to_string(shownEditor) + "/" + std::to_string(team) + "/" +
                        std::to_string(shownEditor >= 0 ? CardIndex(cfg, shownEditor) : 0) + "/" +
                        std::to_string(sort) + "/" + std::to_string(stickerSlot) + "/" +
                        (hideTournament ? "1" : "0") + "/" + std::to_string(capsule) + "/" +
                        std::to_string(reinterpret_cast<std::uintptr_t>(cat)) + "/" + EncodeUTF8(search) +
                        "/" + std::to_string(catalogOverride ? 0 : GameInventoryRarity().Revision());
        return k;
    }
    Entry PaintEntry(int id, int current, int weapon, int section) const {
        const auto& c = Cat();
        const auto* p = c.Paint(id);
        Entry e;
        e.id = id;
        e.section = section;
        e.weapon = weapon;
        if (p) {
            e.name = DecodeUTF8(p->name);
            e.rarity = DisplayRarity(current, p);
            if (auto col = InventoryCollectionFor(c, weapon, id))
                e.group = DecodeUTF8(col->name);
            e.description = Plain(p->description);
        } else
            e.name = DecodeUTF8("#" + std::to_string(id));
        return e;
    }
    void BuildEntries(const Settings& cfg) {
        auto key = EntriesKey(cfg);
        if (key == entriesKey)
            return;
        entriesKey = key;
        entries.clear();
        if (shownEditor < 0)
            return;
        const auto& c = Cat();
        const Kind kind = EditorKind();
        const int index = CardIndex(cfg, shownEditor);
        if (stickerSlot >= 0 && StickerCapable(cfg)) {
            if (stickerSlot < 5) {

                const int selected = CurrentCapsule();
                std::vector<std::size_t> own, other;
                for (std::size_t i = 0; i < c.stickers.size(); ++i) {
                    const auto& st = c.stickers[i];
                    if (hideTournament && st.eventId)
                        continue;
                    if (!Contains(DecodeUTF8(st.name), search))
                        continue;
                    bool mine =
                        selected < 0 || std::find(c.capsules[std::size_t(selected)].stickers.begin(),
                                                  c.capsules[std::size_t(selected)].stickers.end(),
                                                  int(i)) != c.capsules[std::size_t(selected)].stickers.end();
                    (mine ? own : other).push_back(i);
                }
                auto order = [&](std::vector<std::size_t>& v) {
                    std::stable_sort(v.begin(), v.end(), [&](std::size_t a, std::size_t b) {
                        const auto& x = c.stickers[a];
                        const auto& y = c.stickers[b];
                        if (sort == 0 && x.rarity != y.rarity)
                            return x.rarity > y.rarity;
                        if (sort == 1 && x.id != y.id)
                            return x.id > y.id;
                        return x.name < y.name;
                    });
                };
                auto emit = [&](const std::vector<std::size_t>& v, int section) {
                    for (auto i : v) {
                        const auto& st = c.stickers[i];
                        Entry e;
                        e.id = st.id;
                        e.section = section;
                        e.name = DecodeUTF8(st.name);
                        e.rarity = std::clamp(st.rarity, 0, 7);
                        const int group = section == 0 && selected >= 0 ? selected : st.capsule;
                        if (group >= 0 && std::size_t(group) < c.capsules.size())
                            e.group = DecodeUTF8(c.capsules[std::size_t(group)].name);
                        entries.push_back(std::move(e));
                    }
                };
                order(own);
                emit(own, 0);
                if (!search.empty() && selected >= 0 && !other.empty()) {
                    Entry h;
                    h.header = true;
                    h.name = Label("inventory_stickers_fromothercapsules");
                    entries.push_back(h);
                    order(other);
                    emit(other, 1);
                }
            } else {
                std::vector<const InventoryNamed*> list;
                for (const auto& k : c.keychains)
                    if (Contains(DecodeUTF8(k.name), search))
                        list.push_back(&k);
                std::stable_sort(list.begin(), list.end(),
                                 [&](const InventoryNamed* a, const InventoryNamed* b) {
                                     if (sort == 0 && a->rarity != b->rarity)
                                         return a->rarity > b->rarity;
                                     if (sort == 1 && a->id != b->id)
                                         return a->id > b->id;
                                     return a->name < b->name;
                                 });
                for (auto k : list) {
                    Entry e;
                    e.id = k->id;
                    e.name = DecodeUTF8(k->name);
                    e.rarity = std::clamp(k->rarity, 0, 7);
                    entries.push_back(std::move(e));
                }
            }
            return;
        }
        if (PaintKind(kind)) {

            Entry none;
            none.id = 0;
            none.name = Label("inventory_defaultskin");
            none.weapon = index;
            entries.push_back(none);
            std::vector<int> own = c.PaintsFor(index);
            auto orderPaints = [&](std::vector<int>& ids) {
                std::map<int, int> grades;
                for (int id : ids)
                    grades[id] = DisplayRarity(index, c.Paint(id));
                std::stable_sort(ids.begin(), ids.end(), [&](int a, int b) {
                    const auto* pa = c.Paint(a);
                    const auto* pb = c.Paint(b);
                    if (!pa || !pb)
                        return pa > pb;
                    if (sort == 0 && grades[a] != grades[b])
                        return grades[a] > grades[b];
                    if (sort == 1 && a != b)
                        return a > b;
                    return pa->name < pb->name;
                });
            };
            orderPaints(own);
            for (int id : own) {
                auto e = PaintEntry(id, index, index, 0);
                if (Contains(e.name, search))
                    entries.push_back(std::move(e));
            }
            if (!search.empty()) {

                std::set<int> seen(own.begin(), own.end());
                seen.insert(0);
                std::map<int, int> from;
                std::vector<int> ids;
                const bool gloves = kind == KindGloves;
                auto consider = [&](int source, const std::vector<int>& list) {
                    for (int id : list) {
                        if (seen.count(id))
                            continue;
                        const auto* p = c.Paint(id);
                        if (!p || !Contains(DecodeUTF8(p->name), search))
                            continue;
                        seen.insert(id);
                        from[id] = source;
                        ids.push_back(id);
                    }
                };
                for (const auto& kv : c.itemPaints) {
                    if (kv.first == index || InventoryIsGlove(kv.first) != gloves)
                        continue;
                    consider(kv.first, kv.second);
                }
                if (!gloves && !InventoryIsKnife(index))
                    consider(-1, c.knifePaints);
                if (!ids.empty()) {
                    Entry h;
                    h.header = true;
                    h.name = Label("inventory_fromotherweapons");
                    entries.push_back(h);
                    orderPaints(ids);
                    for (int id : ids)
                        entries.push_back(PaintEntry(id, index, from[id], 1));
                }
            }
            return;
        }
        Entry def;
        def.id = 0;
        def.name = kind == KindAgent ? DefaultAgentName() : Label("inventory_skinoptions_animation_default");
        entries.push_back(def);
        std::vector<const InventoryNamed*> list;
        for (const auto& n : NamedList(kind)) {
            if (kind == KindAgent && !InventoryTeamAllows(n.teams, team))
                continue;
            if (!Contains(DecodeUTF8(n.name), search))
                continue;
            list.push_back(&n);
        }
        std::stable_sort(list.begin(), list.end(), [&](const InventoryNamed* a, const InventoryNamed* b) {
            if (sort == 0 && a->rarity != b->rarity)
                return a->rarity > b->rarity;
            if (sort == 1 && a->id != b->id)
                return a->id > b->id;
            return a->name < b->name;
        });
        for (auto n : list) {
            Entry e;
            e.id = n->id;
            e.name = DecodeUTF8(n->name);
            e.rarity = std::clamp(n->rarity, 0, 7);
            entries.push_back(std::move(e));
        }
    }
    void LayoutGrid(float width, int columns = 5) {
        columns = std::clamp(columns, 1, 5);
        gridRows.clear();
        const float gap = 10 * scale, cw = std::max(1.f, (width - (columns - 1) * gap) / float(columns)),
                    imgH = std::trunc(cw * .72f), headerH = F + 16 * scale;
        gridPitch = imgH + 3 * scale + F + 16 * scale;
        float y = 0;
        std::size_t i = 0;
        while (i < entries.size()) {
            if (entries[i].header) {
                gridRows.push_back({true, i, 1, y, headerH});
                y += headerH;
                ++i;
                continue;
            }
            GridRow r;
            r.first = i;
            r.y = y;
            r.h = gridPitch;
            while (i < entries.size() && !entries[i].header && r.count < std::size_t(columns)) {
                ++r.count;
                ++i;
            }
            gridRows.push_back(r);
            y += gridPitch;
        }
        gridContent = y;
    }

    struct CapsuleGroup {
        std::u32string label;
        std::vector<int> capsules;
    };
    std::vector<CapsuleGroup> CapsuleGroups() const {
        std::vector<CapsuleGroup> out;
        const auto& c = Cat();
        CapsuleGroup plain{Label("inventory_stickers_nontournament"), {}};
        std::map<int, std::vector<int>> events;
        for (std::size_t i = 0; i < c.capsules.size(); ++i) {
            const auto& cap = c.capsules[i];
            if (!cap.tournament)
                plain.capsules.push_back(int(i));
            else if (!hideTournament)
                events[cap.eventId].push_back(int(i));
        }
        if (!plain.capsules.empty())
            out.push_back(std::move(plain));
        for (auto& kv : events) {
            auto it = c.eventNames.find(kv.first);
            out.push_back({DecodeUTF8(it != c.eventNames.end() ? it->second : "#" + std::to_string(kv.first)),
                           std::move(kv.second)});
        }
        return out;
    }
    int CurrentCapsule() const {
        const auto groups = CapsuleGroups();
        for (const auto& g : groups)
            for (int i : g.capsules)
                if (i == capsule)
                    return i;
        return groups.empty() ? -1 : groups.front().capsules.front();
    }
    const Entry* FindEntry(int section, int id) const {
        for (const auto& e : entries)
            if (!e.header && e.section == section && e.id == id)
                return &e;
        return nullptr;
    }

    InventoryCharm CharmForPreview(const InventoryItem& item) const {
        if (modelDrag && charmDrag && visible && !blocked && nativeItemPreview && !PopupOpen() &&
            moveMode == 0 && team == charmDragTeam && shownEditor == charmDragEditor &&
            editor == shownEditor && shownEditor >= 0 && team >= 0 && team <= 1 &&
            EditorKind() == KindWeapon && item.index == charmDragWeapon && item.paintKit == charmDragPaint &&
            item.charm == charmDragOriginal)
            return charmDragPreview;
        return item.charm;
    }
    InventoryItem CurrentItem(const Settings& cfg) const {
        int idx = shownEditor >= 0 ? CardIndex(cfg, shownEditor) : 0;
        auto it = Loadout(cfg).Find(idx);
        InventoryItem out = it ? *it : InventoryItem{};
        out.index = idx;
        return out;
    }
    bool CharmDragCurrent(const Settings& cfg) const {
        if (!modelDrag || !charmDrag || !visible || blocked || !nativeItemPreview || PopupOpen() ||
            moveMode != 0 || team != charmDragTeam || shownEditor != charmDragEditor ||
            editor != shownEditor || shownEditor < 0 || team < 0 || team > 1 || EditorKind() != KindWeapon)
            return false;
        const auto it = CurrentItem(cfg);
        return it.index == charmDragWeapon && it.paintKit == charmDragPaint && it.charm == charmDragOriginal;
    }
    bool StickerDragCurrent(const Settings& cfg) const {
        if (!modelDrag || !stickerDrag || !visible || blocked || !nativeItemPreview || PopupOpen() ||
            moveMode != 1 || team != stickerDragTeam || shownEditor != stickerDragEditor ||
            editor != shownEditor || shownEditor < 0 || team < 0 || team > 1 || EditorKind() != KindWeapon ||
            stickerDragSlot < 0 || stickerDragSlot >= 5)
            return false;
        const auto it = CurrentItem(cfg);
        return it.index == stickerDragWeapon && it.paintKit == stickerDragPaint &&
               it.stickers[std::size_t(stickerDragSlot)] == stickerDragOriginal;
    }
    template <class Fn> void EditItem(Settings& cfg, Fn&& fn) {
        if (shownEditor < 0 || !PaintKind(EditorKind()))
            return;
        int idx = CardIndex(cfg, shownEditor);
        auto& l = Loadout(cfg);
        fn(l.Edit(idx));
        l.Prune();
    }
    int SelectedId(const Settings& cfg) const {
        if (shownEditor < 0)
            return -1;
        Kind k = EditorKind();
        if (stickerSlot >= 0 && StickerCapable(cfg)) {
            auto it = CurrentItem(cfg);
            return stickerSlot < 5 ? it.stickers[std::size_t(stickerSlot)].id : it.charm.id;
        }
        if (PaintKind(k))
            return CurrentItem(cfg).paintKit;
        return NamedValue(Loadout(cfg), k);
    }
    void SelectEntry(Settings& cfg, int id) {
        if (shownEditor < 0)
            return;
        Kind kind = EditorKind();
        if (stickerSlot >= 0 && StickerCapable(cfg)) {
            EditItem(cfg, [&](InventoryItem& it) {
                if (stickerSlot < 5)
                    it.stickers[std::size_t(stickerSlot)].id = id;
                else
                    it.charm.id = id;
            });
            return;
        }
        if (PaintKind(kind)) {
            EditItem(cfg, [&](InventoryItem& it) {
                if (it.paintKit != id) {
                    it.paintColorMask = 0;
                    it.paintColors = {};
                }
                it.paintKit = id;
                if (id > 0)
                    if (auto p = Cat().Paint(id)) {
                        auto tiers = InventoryWearTiers(p->wearMin, p->wearMax);
                        if (std::find(tiers.begin(), tiers.end(), it.wearTier) == tiers.end())
                            it.wearTier = tiers.front();
                    }
            });
            if (id == 0) {
                optionsOpen = false;
                choice = color = -1;
                nameEditing = valueEditing = false;
            }
            return;
        }
        NamedRef(Loadout(cfg), kind) = id;
    }
    std::vector<int> WeaponChoices(const Settings&) const {
        std::vector<int> out;
        if (shownEditor < 0)
            return out;
        Kind k = EditorKind();
        if (k == KindWeapon) {
            auto g = InventorySlotGroup(shownEditor);
            for (const auto& w : InventoryWeapons)
                if (w.group == g && InventoryTeamAllows(w.teams, team))
                    out.push_back(w.index);
        } else if (k == KindKnife) {
            for (const auto& m : InventoryKnives)
                if (InventoryTeamAllows(m.teams, team))
                    out.push_back(m.index);
        } else if (k == KindGloves) {
            for (const auto& m : InventoryGloves)
                if (InventoryTeamAllows(m.teams, team))
                    out.push_back(m.index);
        }
        return out;
    }
    void ChooseWeapon(Settings& cfg, int index) {
        if (shownEditor < 0)
            return;
        auto& l = Loadout(cfg);
        Kind k = EditorKind();
        if (k == KindWeapon) {
            int slot = shownEditor;
            if (!InventoryValidSlotWeapon(team, slot, index))
                return;
            int old = l.slots[std::size_t(slot)];

            for (int s = 0; s < 15; ++s)
                if (s != slot && l.slots[std::size_t(s)] == index) {
                    l.slots[std::size_t(s)] = old;
                    break;
                }
            l.slots[std::size_t(slot)] = index;
        } else if (k == KindKnife) {
            if (!InventoryIsKnife(index))
                return;
            l.knife = index == InventoryDefaultKnife(team) ? 0 : index;
        } else if (k == KindGloves) {
            if (!InventoryIsGlove(index))
                return;
            l.gloves = index == InventoryDefaultGlove(team) ? 0 : index;
        }
        stickerSlot = -1;
        optionsOpen = false;
        choice = color = -1;
        gridScroll = gridTarget = 0;
        entriesKey.clear();
    }

    bool CanPaste(const Settings& cfg, int card) const {
        if (!clip.has || card < 0 || CardKind(card) != clip.kind)
            return false;
        if (clip.kind == KindAgent && clip.named) {
            auto n = FindNamed(KindAgent, clip.named);
            return !n || InventoryTeamAllows(n->teams, team);
        }
        (void)cfg;
        return true;
    }
    void Copy(const Settings& cfg, int card) {
        Kind k = CardKind(card);
        clip = Clip{};
        clip.has = true;
        clip.kind = k;
        if (PaintKind(k)) {
            int idx = CardIndex(cfg, card);
            auto it = Loadout(cfg).Find(idx);
            clip.item = it ? *it : InventoryItem{};
            clip.item.index = idx;
        } else
            clip.named = NamedValue(Loadout(cfg), k);
    }
    void Paste(Settings& cfg, int card) {
        if (!CanPaste(cfg, card))
            return;
        auto& l = Loadout(cfg);
        Kind k = CardKind(card);
        if (PaintKind(k)) {
            int target = CardIndex(cfg, card);
            if (k == KindKnife) {
                int model = clip.item.index;
                if (model == 42 || model == 59)
                    model = InventoryDefaultKnife(team);
                l.knife = model == InventoryDefaultKnife(team) ? 0 : model;
                target = model;
            }
            if (k == KindGloves) {
                int model = clip.item.index;
                if (model == 5028 || model == 5029)
                    model = InventoryDefaultGlove(team);
                l.gloves = model == InventoryDefaultGlove(team) ? 0 : model;
                target = model;
            }
            auto item = clip.item;
            item.index = target;
            l.Edit(target) = item;
            l.Prune();
        } else
            NamedRef(l, k) = clip.named;
        entriesKey.clear();
    }
    void Delete(Settings& cfg, int card) {
        auto& l = Loadout(cfg);
        Kind k = CardKind(card);
        if (PaintKind(k)) {
            int idx = CardIndex(cfg, card);
            l.items.erase(std::remove_if(l.items.begin(), l.items.end(),
                                         [&](const InventoryItem& i) { return i.index == idx; }),
                          l.items.end());
            if (k == KindKnife)
                l.knife = 0;
            if (k == KindGloves)
                l.gloves = 0;
        } else
            NamedRef(l, k) = 0;
        entriesKey.clear();
    }

    void SlotAction(Settings& cfg, int slot, int code) {
        bool charm = slot == 5;
        if (code == 0) {
            auto it = CurrentItem(cfg);
            slotClip = SlotClip{};
            slotClip.has = true;
            slotClip.charm = charm;
            if (charm)
                slotClip.keychain = it.charm;
            else
                slotClip.sticker = it.stickers[std::size_t(slot)];
            return;
        }
        EditItem(cfg, [&](InventoryItem& it) {
            if (code == 1 && slotClip.has && slotClip.charm == charm) {
                if (charm)
                    it.charm = slotClip.keychain;
                else
                    it.stickers[std::size_t(slot)] = slotClip.sticker;
            } else if (code == 2) {
                if (charm) {
                    it.charm.x = it.charm.y = it.charm.z = 0;
                } else {
                    it.stickers[std::size_t(slot)].x = it.stickers[std::size_t(slot)].y = 0;
                }
            } else if (code == 3 && !charm)
                it.stickers[std::size_t(slot)].rotation = 0;
            else if (code == 4) {
                if (charm)
                    it.charm = InventoryCharm{};
                else
                    it.stickers[std::size_t(slot)] = InventorySticker{};
            }
        });
    }

    bool OptVisible(int o, const InventoryItem& it, Kind k) const {
        const bool gloves = k == KindGloves;
        switch (o) {
        case OptFrost:
        case OptNameRow:
        case OptStatTrak:
        case OptAnimations:
        case OptInspect:
        case OptDeploy:
        case OptIdle:
        case OptColorizeStatTrak:
            return !gloves;
        case OptStatTrakValue:
            return !gloves && it.statTrak != 0;
        case OptCloth:
        case OptSleeves:
            return gloves;
        default:
            return true;
        }
    }
    static bool OptEnabled(int, const InventoryItem&) {
        return true;
    }
    static bool ToggleValue(int o, const InventoryItem& it) {
        switch (o) {
        case OptChams:
            return it.chams;
        case OptColorizeStatTrak:
            return it.colorizeStatTrak;
        case OptGlow:
            return it.glow;
        case OptCloth:
            return it.clothPhysics;
        case OptSleeves:
            return it.removeSleeves;
        case OptFrost:
            return it.frost;
        default:
            return false;
        }
    }
    static Color* ColorRef(InventoryItem& it, int o) {
        switch (o) {
        case OptColors:
            return &it.colors;
        case OptChamsModel:
        case OptChamsModelOverlay:
        case OptChamsArms:
        case OptChamsArmsOverlay:
            return &it.chamsColors[std::size_t(o - OptChamsModel)];
        case OptColorizeStatTrak:
            return &it.statTrakColor;
        case OptGlow:
            return &it.glowColor;
        default:
            return nullptr;
        }
    }
    static Color ColorValue(InventoryItem it, int o) {
        auto p = ColorRef(it, o);
        return p ? *p : Color{1, 1, 1, 1};
    }
    std::vector<std::pair<int, std::u32string>> ChoiceOptions(int o, const InventoryItem& it) const {
        std::vector<std::pair<int, std::u32string>> out;
        if (o == OptWear) {
            const auto* p = Cat().Paint(it.paintKit);
            for (int t : p ? InventoryWearTiers(p->wearMin, p->wearMax) : InventoryWearTiers(0, 1))
                out.push_back({t, WearName(t)});
        } else if (o == OptStatTrak)
            out = {{0, Label("inventory_skinoptions_stattrak_none")},
                   {1, Label("inventory_skinoptions_stattrak_static")},
                   {2, Label("inventory_skinoptions_stattrak_increment")}};
        else
            out = {{0, Label("inventory_skinoptions_animation_default")}};
        return out;
    }
    static int ChoiceValue(int o, const InventoryItem& it) {
        return o == OptWear       ? it.wearTier
               : o == OptStatTrak ? it.statTrak
               : o == OptInspect  ? it.animations[0]
               : o == OptDeploy   ? it.animations[1]
                                  : it.animations[2];
    }
    std::u32string ChoiceSummary(int o, const InventoryItem& it) const {
        int v = ChoiceValue(o, it);
        for (const auto& p : ChoiceOptions(o, it))
            if (p.first == v)
                return p.second;
        return o == OptWear ? WearName(v) : Label("inventory_skinoptions_animation_default");
    }
    void SetChoice(Settings& cfg, int o, int v) {
        EditItem(cfg, [&](InventoryItem& it) {
            if (o == OptWear)
                it.wearTier = std::clamp(v, 0, 4);
            else if (o == OptStatTrak)
                it.statTrak = std::clamp(v, 0, 2);
            else if (o >= OptInspect && o <= OptIdle)
                it.animations[std::size_t(o - OptInspect)] = std::max(0, v);
        });
    }
    static float SliderFraction(int o, const InventoryItem& it) {
        if (o == OptSeed)
            return float(it.seed) / 1000.f;
        if (o == OptWearValue)
            return float(it.wearValue) / 100.f;
        if (o == OptStatTrakValue)
            return float(double(it.statTrakValue) / 2147483647.0);
        return 0.f;
    }
    static std::u32string SliderText(int o, const InventoryItem& it) {
        return DecodeUTF8(o == OptSeed        ? std::to_string(it.seed)
                          : o == OptWearValue ? std::to_string(it.wearValue) + "%"
                                              : std::to_string(it.statTrakValue));
    }
    void SetSlider(Settings& cfg, int o, float t) {
        if (!std::isfinite(t))
            return;
        t = std::clamp(t, 0.f, 1.f);
        EditItem(cfg, [&](InventoryItem& it) {
            if (o == OptSeed)
                it.seed = int(std::lround(t * 1000.f));
            else if (o == OptWearValue)
                it.wearValue = int(std::lround(t * 100.f));
            else if (o == OptStatTrakValue)
                it.statTrakValue = int(std::llround(double(t) * 2147483647.0));
        });
    }

    float ActualWear(const InventoryItem& it) const {
        const auto* p = Cat().Paint(it.paintKit);
        return p ? InventoryWearFloat(it.wearTier, it.wearValue, p->wearMin, p->wearMax)
                 : InventoryWearFloat(it.wearTier, it.wearValue);
    }
    void SetWearAt(Settings& cfg, float value) {
        if (!std::isfinite(value))
            return;
        EditItem(cfg, [&](InventoryItem& it) {
            const auto* p = Cat().Paint(it.paintKit);
            float lo = p ? p->wearMin : 0.f, hi = p ? p->wearMax : 1.f;
            if (!std::isfinite(lo) || !std::isfinite(hi) || lo < 0.f || hi > 1.f || lo > hi) {
                lo = 0.f;
                hi = 1.f;
            }
            value = std::clamp(value, lo, hi);
            int tier = 4;
            for (int i = 0; i < 5; ++i)
                if (value + 1e-6f < InventoryWearEdges[std::size_t(i) + 1] || i == 4) {
                    tier = i;
                    break;
                }

            if (hi > lo) {
                const auto tiers = InventoryWearTiers(lo, hi);
                if (std::find(tiers.begin(), tiers.end(), tier) == tiers.end())
                    tier = tiers.back();
            }
            const float a = std::max(lo, InventoryWearEdges[std::size_t(tier)]),
                        b = std::min(hi, InventoryWearEdges[std::size_t(tier) + 1]);
            it.wearTier = tier;
            it.wearValue = b > a ? std::clamp(int(std::lround((value - a) * 100.f / (b - a))), 0, 100) : 0;
        });
    }
    void Toggle(Settings& cfg, int o) {
        EditItem(cfg, [&](InventoryItem& it) {
            switch (o) {
            case OptChams:
                it.chams = !it.chams;
                break;
            case OptColorizeStatTrak:
                it.colorizeStatTrak = !it.colorizeStatTrak;
                break;
            case OptGlow:
                it.glow = !it.glow;
                break;
            case OptCloth:
                it.clothPhysics = !it.clothPhysics;
                break;
            case OptSleeves:
                it.removeSleeves = !it.removeSleeves;
                break;
            case OptFrost:
                it.frost = !it.frost;
                break;
            default:
                break;
            }
        });
    }
    Color PaintColorValue(const InventoryItem& it, int channel) const {
        const unsigned bit = 1u << channel;
        if (it.paintColorMask & bit)
            return it.paintColors[std::size_t(channel)];
        if (auto p = Cat().Paint(it.paintKit))
            if (p->paintColorMask & bit)
                return p->paintColors[std::size_t(channel)];
        return it.colors;
    }
    Settings PickerSettings(const Settings& cfg) const {
        Settings c = cfg;
        if (color >= 0) {
            auto it = CurrentItem(cfg);
            c.worldHud.colors[4] = color == OptColors && paintColorChannel >= 0
                                       ? PaintColorValue(it, paintColorChannel)
                                       : ColorValue(it, color);
        }
        return c;
    }
    void SyncPicker(Settings& cfg, const Settings& c) {
        if (color < 0)
            return;
        Color v = c.worldHud.colors[4];
        int o = color;
        EditItem(cfg, [&](InventoryItem& it) {
            if (o == OptColors && paintColorChannel >= 0) {
                if (!InventorySameColor(PaintColorValue(it, paintColorChannel), v)) {
                    it.paintColors[std::size_t(paintColorChannel)] = v;
                    it.paintColorMask |= 1u << paintColorChannel;
                }
            } else if (auto p = ColorRef(it, o))
                *p = v;
        });
    }
    void OpenColor(int o, int channel = -1) {
        choice = -1;
        nameEditing = valueEditing = false;
        color = o;
        paintColorChannel = o == OptColors && channel >= 0 && channel < 4 ? channel : -1;
        picker.Reset(4, false, false);
        picker.languages = languages;
    }
    void BeginName(const Settings& cfg, bool select = true) {
        nameText = DecodeUTF8(CurrentItem(cfg).name);
        if (nameText.size() > InventoryMaxName)
            nameText.resize(InventoryMaxName);
        nameEdit.Reset(nameText, select);
        nameEditing = true;
        highSurrogate = 0;
        valueEditing = false;
    }
    void CommitName(Settings& cfg) {
        if (!nameEditing)
            return;
        nameEditing = false;
        if (nameText.size() > InventoryMaxName)
            nameText.resize(InventoryMaxName);
        auto v = EncodeUTF8(nameText);
        EditItem(cfg, [&](InventoryItem& it) { it.name = v; });
    }
    void BeginValue(const Settings& cfg) {
        numeric = std::to_string(CurrentItem(cfg).statTrakValue);
        valueEditing = true;
        selectAll = true;
        nameEditing = false;
    }
    void CommitValue(Settings& cfg) {
        if (!valueEditing)
            return;
        valueEditing = false;
        long long v = 0;
        if (!numeric.empty() && numeric.size() <= 12)
            v = std::stoll(numeric);
        v = std::clamp<long long>(v, 0, 2147483647LL);
        EditItem(cfg, [&](InventoryItem& it) { it.statTrakValue = int(v); });
        numeric.clear();
    }
    void CommitEdits(Settings& cfg) {
        CommitName(cfg);
        CommitValue(cfg);
    }

    bool PopupOpen() const {
        return drop >= 0 || optionsOpen || choice >= 0 || color >= 0 || contextOpen;
    }
    bool Active() const {
        return visible && (editor >= 0 || PopupOpen());
    }
    bool Capturing() const {
        return held >= 0 || drag >= 0 || thumbDrag || modelDrag || picker.held >= 0;
    }
    bool Editing() const {
        return visible && !blocked && (searchFocus || nameEditing || valueEditing || color >= 0);
    }
    void CancelInput() {
        held = -1;
        drag = -1;
        thumbDrag = modelDrag = charmDrag = stickerDrag = false;
        picker.held = -1;
    }
    void ClosePopups() {
        drop = -1;
        optionsOpen = false;
        choice = color = -1;
        contextOpen = false;
        contextCard = contextSlot = -1;
        nameEditing = valueEditing = false;
        numeric.clear();
        CancelInput();
    }
    void CloseEditor() {
        ClosePopups();
        bigPreview = false;
        nativeItemPreview = false;
        editor = shownEditor = -1;
        searchFocus = false;
        stickerSlot = -1;
        entriesKey.clear();
    }
    void OpenEditor(int card) {
        if (card < 0 || card >= CardCount)
            return;
        stickerMoveSlot = -1;
        ClosePopups();
        bigPreview = false;
        nativeItemPreview = false;
        nativeItemTeam = -1;
        modelYaw = modelPitch = 0;
        editor = shownEditor = card;
        search.clear();
        searchEdit.Reset(search);
        searchFocus = false;
        stickerSlot = -1;
        gridScroll = gridTarget = 0;
        entriesKey.clear();
    }
    void Hide() {
        CloseEditor();
        visible = false;
        loadoutPreviewBox = {};
        hits.clear();
        paint.layers.clear();
        transitions.clear();
        hover = -1;
        hoverTime = 0;
        tooltipStored = false;
        tooltipMotion.Snap(0);
    }
    int HitAt(float x, float y) const {
        if (!visible || blocked)
            return -1;
        for (int i = int(hits.size()) - 1; i >= 0; --i)
            if (hits[std::size_t(i)].box.Contains(x, y))
                return i;
        return -1;
    }
    bool TransitionActive(int key) const {
        switch (key) {
        case 1:
            return drop == 0;
        case 2:
            return drop == 1;
        case 3:
            return drop == 2;
        case 4:
            return optionsOpen;
        case 7:
            return contextOpen;
        case 8:
            return drop == 3;
        case 10:
            return editor >= 0;
        default:
            break;
        }
        if (key >= 500 && key < 600)
            return choice == key - 500;
        if (key >= 600 && key < 700)
            return color == key - 600;
        return false;
    }
    void BeginWindow(int key) {
        drawnWindows.insert(key);
        auto& w = transitions[key];
        if (!w.motion.initialized)
            w.motion.Snap(0);
    }
    void FadeLayers(std::size_t begin, float alpha) {
        for (std::size_t j = begin; j < paint.layers.size(); ++j) {
            auto& l = paint.layers[j];
            l.opacity *= alpha;
            for (auto& d : l.draw) {
                d.color.a *= alpha;
                d.shadowColor.a *= alpha;
                d.backdropOpacity *= alpha;
            }
        }
    }
    void RememberWindow(int key, std::size_t begin) {
        auto& w = transitions[key];
        w.cached.assign(paint.layers.begin() + std::ptrdiff_t(begin), paint.layers.end());
        FadeLayers(begin, w.motion.value);
    }

    void DrawItemCardFrame(int z, Box b, float hover) {
        const float radius = 9 * scale;
        const auto fill = Mix(Alpha(palette[12], .5f), Alpha(palette[13], .5f), std::clamp(hover, 0.f, 1.f));
        Rect(z, b, fill, radius, 0, 3);
        Rect(z, b, palette[11], radius, scale, 3);
    }

    static const char* SortKey(int i) {
        static constexpr std::array<const char*, 3> k{
            {"inventory_skins_sort_rarity", "inventory_skins_sort_newest", "inventory_skins_sort_name"}};
        return k[std::size_t(std::clamp(i, 0, 2))];
    }
    void DrawLoadoutCard(Fonts& fonts, const Settings& cfg, int z, Box b, int card, float fill) {
        cardBoxes[std::size_t(card)] = b;
        const auto info = Info(cfg, card);
        const float hv = Hover(Card, -1, card);
        DrawItemCardFrame(z, b, hv);
        RarityStrip(z, b, RarityColor(info.rarity));
        const Color ink =
            info.rarity > 0 ? Mix(palette[2], RarityColor(info.rarity), .45f) : Alpha(palette[2], .85f);
        Artwork(fonts, z, b, info.kind, info.index, Alpha(ink, .85f + .15f * hv),
                PaintKind(info.kind) ? .8f : fill, 1, info.paint ? info.paint->id : 0);
        AddHit(z, b, Card, -1, card);
    }
    Color RarityColor(int r) const {
        return Cat().RarityColor(r);
    }

    void DrawTeamSwitch(Fonts& fonts, int z, float areaX, float areaW, float top) {
        const float s = scale, padX = 6 * s, padY = 3 * s, gap = 10 * s, h = F + 2 * padY;
        static const std::array<const char*, 2> keys{{"tab_inventory_loadout_ct", "tab_inventory_loadout_t"}};
        static const std::array<Color, 2> ink{{{.59f, .79f, .98f, 1.f}, {.92f, .75f, .34f, 1.f}}};
        struct Toggle {
            std::u32string label;
            float rawW = 0, textW = 0, expand = 0, hover = 0, w = 0;
        };
        std::array<Toggle, 2> tg;
        float total = 0;
        for (int t = 0; t < 2; ++t) {
            auto& g = tg[std::size_t(t)];
            const bool selected = team == t;
            const auto& e = teamExpand[std::size_t(t)];
            const auto& hv = teamHover[std::size_t(t)];
            g.label = Label(keys[std::size_t(t)]);
            if (!g.label.empty()) {
                g.rawW = TextW(fonts, g.label, 1);
                g.textW = std::trunc(g.rawW + .95f);
            }
            g.expand = g.label.empty() ? 0.f : e.initialized ? e.value : selected ? 1.f : 0.f;
            g.hover = hv.initialized ? hv.value : selected ? .5f : 0.f;
            const float collapsed = F + 2 * padX, expanded = collapsed + 6 * s + g.textW;
            g.w = collapsed + g.expand * (expanded - collapsed);
            total += g.w + gap;
        }
        float x = areaX + std::trunc((areaW - (teamRowWidth >= 0 ? teamRowWidth : total)) * .5f);
        for (int t = 0; t < 2; ++t) {
            const auto& g = tg[std::size_t(t)];
            const Box b{x, top, g.w, h};
            Rect(z, b, Alpha(palette[33], .4f * g.hover), 7.8f * s);
            if (auto im = TeamIcon(t, int(std::round(F))))
                Image(z, b.x + padX, b.y + (h - F) * .5f, im);
            if (g.expand > .001f && !g.label.empty()) {
                const float tx = b.x + padX + F + 6 * s, ty = b.y + (h - F) * .5f;
                auto& draws = paint.layers[std::size_t(z)].draw;
                const auto before = draws.size();
                Text(z, {tx, ty, g.rawW + 1, F}, g.label, Alpha(ink[std::size_t(t)], g.expand), 1);
                if (draws.size() > before)
                    draws.back().clip =
                        PresetIntersect(draws.back().clip, Box{tx, b.y, std::max(0.f, b.x + b.w - tx), b.h});
            }
            AddHit(z, b, Team, -1, t);
            x += g.w + gap;
        }
        teamRowWidth = total;
    }
    void MeasureLoadout(Fonts& fonts, const Settings& cfg, const Layout& layout, Box line, int height) {
        const float s = scale, top = line.y + line.h + 15 * s;
        pageBody = {
            layout.content.x + 15 * s, top, std::max(0.f, layout.content.w - 30 * s),
            std::max(0.f,
                     std::min(float(height) - 6 * s, layout.content.y + layout.content.h - 15 * s) - top)};
        const float gap = 24 * s, leftW = std::trunc(std::max(0.f, pageBody.w - gap) * .34f),
                    rightX = pageBody.x + leftW + gap,
                    rightW = std::max(0.f, pageBody.x + pageBody.w - rightX);
        const float headH = F + 14 * s, colGap = 12 * s, rowGap = 12 * s,
                    colW = std::max(0.f, std::trunc((rightW - 2 * colGap) / 3.f));
        const float cardH = std::max(44 * s, std::trunc((pageBody.h - headH - 8 * s - 4 * rowGap) / 5.f)),
                    contentH = headH + 8 * s + 5 * cardH + 4 * rowGap;
        pageMax = std::max(0.f, contentH - pageBody.h);
        pageScroll = std::clamp(pageScroll, 0.f, pageMax);
        const int previewZ = Layer(pageBody), z = Layer(pageBody);
        drawClip = pageBody;
        const float y0 = pageBody.y - pageScroll, cy = y0 + headH + 8 * s;

        static constexpr std::array<const char*, 3> heads{
            {"inventory_loadout_pistols", "inventory_loadout_midtier", "inventory_loadout_rifles"}};
        for (int c = 0; c < 3; ++c) {
            const float x = rightX + float(c) * (colW + colGap);
            auto t = Label(heads[std::size_t(c)]);
            const float w = TextW(fonts, t, 1);
            Text(z, {x + std::trunc((colW - w) * .5f), y0 + (headH - F) * .5f, w + 1, F}, t, palette[2], 1);
            for (int r = 0; r < 5; ++r)
                DrawLoadoutCard(fonts, cfg, z, {x, cy + float(r) * (cardH + rowGap), colW, cardH}, c * 5 + r,
                                .46f);
        }

        DrawTeamSwitch(fonts, z, pageBody.x, leftW, y0 + (headH - F) * .5f);

        const float sg = 10 * s, sw = std::trunc(std::max(0.f, leftW - 2 * sg) / 3.f),
                    sh = std::min(std::trunc(sw * .88f), cardH), bottom = cy + 5 * cardH + 4 * rowGap,
                    row2 = bottom - sh, row1 = row2 - sg - sh;
        static constexpr std::array<int, 6> smallCards{
            {CardAgent, CardMedal, CardMusic, CardKnife, CardGloves, CardTaser}};
        for (int i = 0; i < 6; ++i)
            DrawLoadoutCard(fonts, cfg, z,
                            {pageBody.x + float(i % 3) * (sw + sg), i < 3 ? row1 : row2, sw, sh},
                            smallCards[std::size_t(i)], .5f);

        loadoutPreviewBox = previewBox = InventoryPreviewPane({pageBody.x, y0, pageBody.w, pageBody.h}, s);
        if (loadoutPreviewBox.h > 24 * s) {
            auto b = InventoryPreviewSurface(loadoutPreviewBox, s);
            PresetDraw d{};
            d.box = b;
            d.color = {1, 1, 1, 1};
            d.nativePreviewTeam = team;
            d.clipped = true;
            d.clip = PresetIntersect(PresetIntersect(loadoutPreviewBox, pageBody), viewport);
            paint.layers[std::size_t(previewZ)].draw.push_back(std::move(d));
        }
        drawClip = {};
        if (pageMax > 0) {
            const Box track{pageBody.x + pageBody.w - 3 * s, pageBody.y, 3 * s, pageBody.h};
            const float th = std::max(10 * s, pageBody.h * pageBody.h / (pageBody.h + pageMax));
            Rect(z, {track.x, track.y + (track.h - th) * pageScroll / pageMax, track.w, th}, palette[18],
                 2 * s);
        }
    }

    void Tool(Fonts& fonts, int z, float& x, float y, float size, Action a, char32_t glyph, Color onInk,
              bool on, Box* out = nullptr) {
        const Box b{x, y, size, size};
        const float hv = Hover(a);
        Rect(z, b, Alpha(palette[33], .4f * hv), 6 * scale);
        const std::u32string g(1, glyph);
        const float gw = TextW(fonts, g, 3);
        Text(z, {b.x + (size - gw) * .5f, b.y + (size - F) * .5f, gw + 1, F}, g,
             on ? onInk : Mix(palette[14], palette[2], hv), 3);
        AddHit(z, b, a);
        x += size + 4 * scale;
        if (out)
            *out = b;
    }

    struct FilterBoxes {
        Box weapon{}, sort{}, search{};
    };
    static FilterBoxes Filters(float x, float y, float width, float s, float font, bool weapon, bool sort) {
        width = std::max(0.f, width);
        const int n = int(weapon) + int(sort);
        const float gap = n ? std::min(8 * s, width / float(n)) : 0.f;
        const float desired = (weapon ? 125 * s : 0) + (sort ? 90 * s : 0);
        const float budget = std::max(0.f, width - gap * n),
                    factor = desired > 0 ? std::min(1.f, budget / desired) : 0.f;
        const float h = font + (weapon ? 7.2f : sort ? 9.f : 14.f) * s;
        FilterBoxes result;
        float pos = x;
        if (weapon) {
            const float w = 125 * s * factor;
            result.weapon = {pos, y, w, h};
            pos += w + gap;
        }
        if (sort) {
            const float w = 90 * s * factor;
            result.sort = {pos, y, w, h};
            pos += w + gap;
        }
        result.search = {pos, y, std::max(0.f, x + width - pos), h};
        return result;
    }
    void Dropdown(Fonts& fonts, int z, Box b, Action a, const std::u32string& value, bool open) {
        const float s = scale, hv = std::max(Hover(a), open ? 1.f : 0.f);
        Rect(z, b, Mix(palette[12], palette[13], hv), 6 * s);
        Rect(z, b, palette[11], 6 * s, s);
        const std::u32string arrow = U"\uf107";
        const float aw = TextW(fonts, arrow, 3), ax = b.x + b.w - 10 * s - aw, tx = b.x + 10 * s,
                    tw = std::max(0.f, ax - tx - 6 * s);
        Text(z, {tx, b.y + (b.h - F) * .5f, tw, F}, Fit(fonts, value, tw), Mix(palette[14], palette[0], hv));
        Text(z, {ax, b.y + (b.h - F) * .5f, aw + 1, F}, arrow, Mix(palette[14], palette[2], hv), 3);
        AddHit(z, b, a);
        (a == WeaponDrop ? weaponBox : a == CapsuleDrop ? capsuleBox : sortBox) = b;
    }
    void SearchField(Fonts& fonts, int z, Box b) {
        const float s = scale;
        searchBox = b;
        const float hv = Hover(SearchBox);
        Rect(z, b, Mix(palette[12], palette[13], searchFocus ? 0.f : .5f * hv), 6 * s);
        Rect(z, b, searchFocus ? Alpha(palette[30], .55f) : palette[11], 6 * s, s);
        const std::u32string glass = U"\uf002";
        const float gw = TextW(fonts, glass, 3);
        Text(z, {b.x + 10 * s, b.y + (b.h - F) * .5f, gw + 1, F}, glass, palette[14], 3);
        const float tx = b.x + 10 * s + gw + 8 * s, tw = std::max(0.f, b.x + b.w - 10 * s - tx),
                    ty = b.y + (b.h - F) * .5f;
        searchTextX = tx;
        if (search.empty() && !searchFocus)
            Text(z, {tx, ty, tw, F}, Label("menu_search"), Alpha(palette[14], .8f));
        else {
            searchEdit.Measure(fonts, 13 * s, search, tw, true, 0);
            const Box saved = drawClip, area{tx, b.y, tw, b.h};
            drawClip = saved.w > 0 ? PresetIntersect(saved, area) : area;
            if (searchFocus && searchEdit.Selected()) {
                const float a0 = searchEdit.advance[searchEdit.Begin()],
                            a1 = searchEdit.advance[searchEdit.End()];
                Rect(z, {tx + a0 - searchEdit.scroll, b.y + 4 * s, a1 - a0, b.h - 8 * s},
                     Alpha(palette[30], .35f));
            }
            Text(z, {tx - searchEdit.scroll, ty, TextW(fonts, search) + searchEdit.scroll + 2, F}, search,
                 palette[0]);
            if (searchFocus) {
                const float caret =
                    searchEdit.advance.empty()
                        ? 0.f
                        : searchEdit.advance[std::min(searchEdit.cursor, searchEdit.advance.size() - 1)];
                Rect(z, {tx + caret - searchEdit.scroll, b.y + 5 * s, s, b.h - 10 * s}, palette[2]);
            }
            drawClip = saved;
        }
        AddHit(z, b, SearchBox);
    }
    std::string SlotArtwork(int slot, int id) const {
        if (id <= 0)
            return {};
        if (slot == 5) {
            for (const auto& k : Cat().keychains)
                if (k.id == id)
                    return k.image;
            return {};
        }
        if (auto p = Cat().Sticker(id))
            return p->image;
        return {};
    }
    void DrawSlot(Fonts& fonts, int z, Box b, int slot, const InventoryItem& it) {
        slotBoxes[std::size_t(slot)] = b;
        (void)fonts;
        const bool charm = slot == 5, on = stickerSlot == slot;
        const int id = charm ? it.charm.id : it.stickers[std::size_t(slot)].id;
        const float hv = Hover(Slot, -1, slot);
        if (on || hv > 0)
            Rect(z, b, Alpha(palette[33], on ? .18f : .12f * hv), 5 * scale);
        const std::string path =
            id ? SlotArtwork(slot, id)
               : (charm ? "econ/tools/keychain_remove_tool" : "econ/tournaments/teams/nosticker");
        if (!ArtworkPath(z, b, path, .96f) && id) {
            int r = 1;
            if (charm) {
                for (const auto& k : Cat().keychains)
                    if (k.id == id) {
                        r = k.rarity;
                        break;
                    }
            } else if (auto st = Cat().Sticker(id))
                r = st->rarity;
            const float in = 6 * scale;
            Rect(z, {b.x + in, b.y + in, b.w - 2 * in, b.h - 2 * in}, Alpha(RarityColor(r), .85f),
                 (b.w - 2 * in) * .5f);
        }
        AddHit(z, b, Slot, -1, slot);
    }
    void DrawGridCard(Fonts& fonts, int z, Box b, const Entry& e, bool selected, Kind kind, int index,
                      bool sticker) {
        const float s = scale, hv = Hover(Paint, e.section, e.id);
        DrawItemCardFrame(z, b, hv);
        const Color rc = RarityColor(e.rarity);
        RarityStrip(z, b, rc);
        if (sticker && !ArtworkPath(z, b, SlotArtwork(stickerSlot, e.id), .8f)) {
            const float r = std::min(b.w, b.h) * .26f;
            const Box d{b.x + b.w * .5f - r, b.y + b.h * .5f - r, 2 * r, 2 * r};
            Rect(z, d, Alpha(rc, .5f + .25f * hv), r);
            Rect(z, d, Alpha(palette[2], .35f), r, s);
        } else if (!sticker)
            Artwork(fonts, z, b, kind,
                    PaintKind(kind) ? (e.section == 1 && e.weapon > 0 ? e.weapon : index) : e.id,
                    Alpha(palette[2], .85f + .15f * hv), PaintKind(kind) ? .8f : .5f, 1, e.id);
        Text(z, {b.x, b.y + b.h + 9 * s, b.w, F}, Fit(fonts, e.name, b.w, 1), palette[0], 1);
        if (selected) {
            const float r = 6 * s, cx = b.x + b.w - 12 * s, cy = b.y + 12 * s, r2 = 2.5f * s;
            Rect(z, {cx - r, cy - r, 2 * r, 2 * r}, palette[31], r, 1.5f * s);
            Rect(z, {cx - r2, cy - r2, 2 * r2, 2 * r2}, palette[31], r2);
        }
        AddHit(z, {b.x, b.y, b.w, std::max(gridPitch, b.h + 3 * s + F + 12 * s)}, Paint, e.section, e.id);
    }
    void MeasureMovingControls(Fonts& fonts, const Settings& cfg, int z, const InventoryItem& item,
                               Box anchor) {
        const float s = scale;
        if (StickerCapable(cfg) && anchor.h > 80 * s) {
            const float d = 30 * s, g = 8 * s, rowW = 6 * d + 5 * g, sx = anchor.x + anchor.w - rowW - 14 * s,
                        sy = anchor.y + anchor.h - d - 8 * s;
            Rect(z, {sx - 5 * s, sy - 3 * s, rowW + 10 * s, d + 6 * s}, Alpha(palette[12], .9f), 8 * s);
            for (int i = 0; i < 6; ++i)
                DrawSlot(fonts, z, {sx + float(i) * (d + g), sy, d, d}, i == 0 ? 5 : i - 1, item);
            const std::array<std::u32string, 2> labels{
                {Label("inventory_move_toggler_charm"), Label("inventory_move_toggler_stickers")}};
            const float e = F + 10 * s;
            float widths[2]{};
            for (int m = 0; m < 2; ++m)
                widths[m] = e + (6 * s + TextW(fonts, labels[std::size_t(m)], 1) + 12 * s) *
                                    moveExpand[std::size_t(m)].value;
            float px = anchor.x + anchor.w - 14 * s - (widths[0] + 6 * s + widths[1]);
            const float py = sy - 8 * s - e;
            for (int m = 0; m < 2; ++m) {
                const bool on = moveMode == m;
                const Box b{px, py, widths[m], e};
                const auto& motion = moveHover[std::size_t(m)];
                const float hv = motion.initialized ? motion.value : (on ? .5f : 0.f);
                Rect(z, b, Alpha(palette[33], .4f * hv), 7.8f * s);
                MovingIcon(z, {b.x, b.y, e, e},
                           m == 0 ? "econ/tools/keychain_remove_tool" : "econ/tournaments/teams/nosticker",
                           moveExpand[std::size_t(m)].initialized ? moveExpand[std::size_t(m)].value
                                                                  : (on ? 1.f : 0.f));
                if (moveExpand[std::size_t(m)].value > .01f) {
                    const Box saved = drawClip;
                    drawClip = PresetIntersect(b, {b.x + e, b.y, std::max(0.f, b.w - e), b.h});
                    if (drawClip.w > 0)
                        Text(z,
                             {b.x + e + 2 * s, b.y + (e - F) * .5f,
                              TextW(fonts, labels[std::size_t(m)], 1) + 1, F},
                             labels[std::size_t(m)], Alpha(palette[31], moveExpand[std::size_t(m)].value), 1);
                    drawClip = saved;
                }
                AddHit(z, b, MoveMode, -1, m);
                px += b.w + 6 * s;
            }
            const auto caption = Upper(Label("inventory_move_toggler"));
            const float hf = fonts.PixelHeight(0, 10 * s), cw = TextW(fonts, caption, 0, 10);
            Text(z, {anchor.x + anchor.w - 14 * s - cw, py - 5 * s - hf, cw + 1, hf}, caption, palette[3], 0,
                 10);
        }
    }
    void MeasureEditor(Fonts& fonts, const Settings& cfg, const Layout& layout) {
        const float s = scale;
        const auto begin = paint.layers.size();
        BeginWindow(10);
        overlay = layout.content;

        const int z = Layer(overlay, true, 12 * s);
        paint.layers[std::size_t(z)].shadow = false;
        paint.layers[std::size_t(z)].clipToPage = false;
        Rect(z, overlay, Alpha(palette[8], .78f), 12 * s);
        AddHit(z, overlay, Panel);
        const Kind kind = EditorKind();
        const int index = CardIndex(cfg, shownEditor);
        const auto info = Info(cfg, shownEditor);
        const auto item = CurrentItem(cfg);
        const bool sticker = stickerSlot >= 0 && StickerCapable(cfg);

        const float tpx = 18, th = fonts.PixelHeight(2, tpx * s), ty = overlay.y + 14 * s;
        const InventoryCollection* collection =
            PaintKind(kind) && info.paint ? InventoryCollectionFor(Cat(), info.index, info.paint->id)
                                          : nullptr;
        const bool hasCollection = collection && !collection->name.empty();
        const float iconSize = hasCollection ? 38 * s : 0, gap = hasCollection ? 8 * s : 0;
        const float maxText = std::max(1.f, overlay.w - 140 * s - iconSize - gap);
        auto title = Fit(fonts, Title(info), maxText, 2, tpx);
        const float tw = TextW(fonts, title, 2, tpx);
        auto collectionName =
            hasCollection ? Fit(fonts, DecodeUTF8(collection->name), maxText, 0) : std::u32string{};
        const float cw = hasCollection ? TextW(fonts, collectionName, 0) : 0,
                    subH = hasCollection ? fonts.PixelHeight(0, 13 * s) : 0;
        const float textH = th + (hasCollection ? 3 * s + subH : 0), blockH = std::max(textH, iconSize),
                    groupW = iconSize + gap + std::max(tw, cw);
        const float gx = overlay.x + std::trunc((overlay.w - groupW) * .5f), textX = gx + iconSize + gap,
                    textY = ty + (blockH - textH) * .5f;
        if (hasCollection)
            ArtworkPath(z, {gx, ty + (blockH - iconSize) * .5f, iconSize, iconSize}, collection->image, 1.f);
        Text(z, {textX, textY, tw + 1, th}, title, palette[2], 2, tpx);
        if (hasCollection)
            Text(z, {textX, textY + th + 3 * s, cw + 1, subH}, collectionName, palette[0], 0);

        const float uw = std::min(300 * s, overlay.w), uy = ty + blockH + 10 * s;
        EditorRarityLine(z, {overlay.x + std::trunc((overlay.w - uw) * .5f), uy, uw, 5 * s},
                         RarityColor(info.rarity));
        {
            const Box close{overlay.x + overlay.w - 40 * s, ty + (th - 26 * s) * .5f, 26 * s, 26 * s};
            const float hv = Hover(CloseButton);
            Rect(z, close, Alpha(palette[33], .4f * hv), 6 * s);
            const std::u32string x = U"\uf00d";
            const float xw = TextW(fonts, x, 3, 15), xh = fonts.PixelHeight(0, 15 * s);
            Text(z, {close.x + (close.w - xw) * .5f, close.y + (close.h - xh) * .5f, xw + 1, xh}, x,
                 Mix(palette[14], palette[2], hv), 3, 15);
            AddHit(z, close, CloseButton);
        }
        const float tbH = F + 14 * s, lowerTop = std::trunc(overlay.y + overlay.h * .53f),
                    tbY = (lowerTop - 10 * s) - tbH;
        previewBox = {overlay.x + 15 * s, uy + 14 * s, std::max(0.f, overlay.w - 30 * s),
                      std::max(0.f, tbY - 8 * s - (uy + 14 * s))};
        itemSourceBox = previewBox;
        itemPreviewClip =
            PresetIntersect(overlay, {previewBox.x, previewBox.y, previewBox.w,
                                      std::max(0.f, std::min(235 * s, lowerTop - previewBox.y))});
        const int musicId = kind == KindMusic ? PreviewMusicId(info.index) : 0;
        nativeItemMusic = kind == KindMusic && musicId > 0;
        const auto* selectedMedal = kind == KindMedal ? FindNamed(kind, info.index) : nullptr;
        nativeItemPremier =
            selectedMedal ? selectedMedal->premierAttributes : std::array<int, 5>{{-1, -1, -1, -1, -1}};
        nativeItemPreview = (PaintKind(kind) && index > 0 && index <= 65535) ||
                            (kind == KindMedal && info.index > 0 && info.index <= 65535) || nativeItemMusic;
        if (nativeItemPreview) {
            const int previewDefinition = nativeItemMusic ? 1314 : PaintKind(kind) ? index : info.index;
            const int previewPaint = nativeItemMusic ? musicId : PaintKind(kind) ? item.paintKit : 0;
            if (nativeItemDefinition != previewDefinition || nativeItemPaint != previewPaint ||
                nativeItemTeam != team) {
                if (modelDrag)
                    CancelInput();
                modelYaw = modelPitch = 0;
            }
            if ((PopupOpen() || blocked) && modelDrag)
                CancelInput();
            nativeItemDefinition = previewDefinition;
            nativeItemPaint = previewPaint;
            nativeItemTeam = team;
            nativeItemCharm = (kind == KindWeapon ? CharmForPreview(item) : InventoryCharm{});
            nativeItemStickers = (kind == KindWeapon ? item.stickers : std::array<InventorySticker, 5>{});
            nativeStickerDragging = kind == KindWeapon && StickerDragCurrent(cfg);
            if (nativeStickerDragging)
                nativeItemStickers[std::size_t(stickerDragSlot)] = stickerDragPreview;
            nativeItemActiveIndex = kind == KindKnife    ? 8
                                    : kind == KindGloves ? 7
                                    : kind == KindMedal  ? 3
                                    : nativeItemMusic    ? 4
                                                         : 0;

            if (!bigPreview && nativeItemMusic &&
                InventoryMusicReady().load(std::memory_order_acquire) != musicId) {
                const Box saved = drawClip;
                drawClip = previewBox;
                Artwork(fonts, z, previewBox, kind, info.index, palette[2], .8f, 1, 0);
                drawClip = saved;
            }
            if (!bigPreview) {
                PresetDraw d{};
                d.box = InventoryItemDisplaySurface(previewBox, s, nativeItemMusic);
                d.color = {1, 1, 1, 1};
                d.nativePreviewTeam = 2;
                const Box saved = drawClip;
                drawClip = itemPreviewClip;
                Push(z, std::move(d));
                drawClip = saved;

                if (!PopupOpen() && !blocked)
                    AddHit(z, itemPreviewClip, ModelDrag);
            }
        } else {
            if (modelDrag)
                CancelInput();
            const float zoom = cameraZoom && Scoped(index) ? 1.45f : 1.f;
            const Color ink = info.rarity > 0 ? Mix(palette[2], RarityColor(info.rarity), .5f) : palette[2];
            if (!bigPreview) {
                const Box saved = drawClip;
                drawClip = previewBox;
                Artwork(fonts, z, previewBox, kind, PaintKind(kind) ? index : info.index, ink,
                        std::min(.95f, .8f * zoom), 1, item.paintKit);
                drawClip = saved;
            }
        }

        if (!bigPreview) {
            Box controls = previewBox;

            controls.h = std::max(0.f, tbY + tbH * .5f + 15 * s + 8 * s - controls.y);
            MeasureMovingControls(fonts, cfg, z, item, controls);
        }

        {
            float bx = overlay.x + 15 * s;
            Box optionsButton{};
            if (PaintKind(kind) && !sticker) {
                if (item.paintKit > 0)
                    Tool(fonts, z, bx, tbY, tbH, ToolOptions, 0xf3f0, palette[2], optionsOpen,
                         &optionsButton);
                if (Scoped(index))
                    Tool(fonts, z, bx, tbY, tbH, ToolCamera, cameraZoom ? 0xf010 : 0xf00e, palette[2], false);
            }
            Tool(fonts, z, bx, tbY, tbH, ToolBig, 0xf320, palette[2], bigPreview);
            if (PaintKind(kind))
                Tool(fonts, z, bx, tbY, tbH, ToolBoth, 0xf560, palette[31], item.bothTeams);
            if (kind == KindKnife || kind == KindGloves) {
                const auto name = ItemName(index);
                const float nw = TextW(fonts, name);
                const int icon = EquipmentIcon(index);
                const IconImage* im = icon >= 0 ? Icon(icon, 12 * s, palette[14]) : nullptr;
                const std::u32string glove(1, PlaceholderGlyph(KindGloves));
                const float iw = im                   ? float(im->image->width)
                                 : kind == KindGloves ? TextW(fonts, glove, 3)
                                                      : 0.f;
                chipBox = {bx + 4 * s, tbY, 10 * s + iw + (iw > 0 ? 8 * s : 0.f) + nw + 12 * s, tbH};
                const float hv = std::max(Hover(ModelChip), drop == 2 ? 1.f : 0.f);
                Rect(z, chipBox, Alpha(palette[33], .4f * hv), 6 * s);
                if (im)
                    Image(z, chipBox.x + 10 * s, chipBox.y + (tbH - float(im->image->height)) * .5f, im);
                else if (iw > 0)
                    Text(z, {chipBox.x + 10 * s, chipBox.y + (tbH - F) * .5f, iw + 1, F}, glove, palette[14],
                         3);
                Text(z,
                     {chipBox.x + 10 * s + iw + (iw > 0 ? 8 * s : 0.f), chipBox.y + (tbH - F) * .5f, nw + 1,
                      F},
                     name, Mix(palette[14], palette[2], hv));
                AddHit(z, chipBox, ModelChip);
            }
            if (optionsButton.w > 0)
                optionsAnchor = optionsButton;
        }

        const bool pickerOpen = sticker;
        const int savedSlot = stickerSlot;
        const bool savedBlocked = blocked, savedSearchFocus = searchFocus;
        const auto savedSearch = search;
        const float savedGridScroll = gridScroll, savedGridTarget = gridTarget;
        if (pickerOpen) {
            stickerSlot = -1;
            blocked = true;
            searchFocus = false;
            search.clear();
            gridScroll = gridTarget = 0;
            entriesKey.clear();
        }
        Rect(z, {overlay.x, lowerTop, overlay.w, overlay.y + overlay.h - lowerTop}, Alpha(palette[8], .94f),
             12 * s, 0, 12);
        const float fy = lowerTop + 12 * s, fx = overlay.x + 15 * s, fw = std::max(0.f, overlay.w - 30 * s);
        const bool hasWeapon = kind == KindWeapon || kind == KindKnife, hasSort = PaintKind(kind);
        const auto filters = Filters(fx, fy, fw, s, F, hasWeapon, hasSort);
        const float fh = filters.search.h;
        if (hasWeapon)
            Dropdown(fonts, z, filters.weapon, WeaponDrop, ItemName(index), drop == 0);
        if (hasSort)
            Dropdown(fonts, z, filters.sort, SortDrop, Label(SortKey(sort)), drop == 1);
        SearchField(fonts, z, filters.search);
        gridBox = {fx, fy + fh + 10 * s, std::max(0.f, fw - 10 * s),
                   std::max(0.f, overlay.y + overlay.h - 12 * s - (fy + fh + 10 * s))};
        BuildEntries(cfg);
        LayoutGrid(gridBox.w);
        gridMax = std::max(0.f, gridContent - gridBox.h);
        gridTarget = std::clamp(gridTarget, 0.f, gridMax);
        gridScroll = std::clamp(gridScroll, 0.f, gridMax);
        if (!sticker || pickerOpen) {
            const auto now = InventoryArtworkClock();
            unsigned demanded = 0;
            for (const auto& row : gridRows) {
                if (row.header || row.y + row.h < gridScroll - gridPitch ||
                    row.y > gridScroll + gridBox.h + gridPitch)
                    continue;
                for (std::size_t j = 0; j < row.count && demanded < 60; ++j, ++demanded) {
                    const auto& e = entries[row.first + j];
                    const int src = e.section == 1
                                        ? (e.weapon > 0 ? e.weapon : InventoryDefaultKnife(InventoryCT))
                                        : index;
                    if (PaintKind(kind)) {
                        InventoryDemandItem(Cat(), src, e.id, now);
                        if (auto col = InventoryCollectionFor(Cat(), src, e.id))
                            InventoryDemandImage(col->image, now);
                    } else
                        InventoryDemandImage(InventoryNamedImage(Cat(),
                                                                 kind == KindAgent ? InventoryNamedArt::Agent
                                                                 : kind == KindMedal
                                                                     ? InventoryNamedArt::Medal
                                                                     : InventoryNamedArt::Music,
                                                                 e.id, team),
                                             now);
                }
            }
        }
        {
            const float gap = 10 * s, cw = std::max(1.f, (gridBox.w - 4 * gap) / 5.f),
                        imgH = std::trunc(cw * .72f);
            const int selected = SelectedId(cfg);
            const Box saved = drawClip;
            drawClip = gridBox;
            for (const auto& r : gridRows) {
                const float ry = std::round(gridBox.y + r.y - gridScroll);
                if (ry + r.h < gridBox.y || ry > gridBox.y + gridBox.h)
                    continue;
                if (r.header) {
                    Text(z, {gridBox.x, ry + (r.h - F) * .5f, gridBox.w, F}, entries[r.first].name,
                         palette[2], 1);
                    continue;
                }
                for (std::size_t j = 0; j < r.count; ++j) {
                    const auto& e = entries[r.first + j];
                    DrawGridCard(fonts, z,
                                 {std::round(gridBox.x + float(j) * (cw + gap)), ry, std::floor(cw), imgH}, e,
                                 e.id == selected, kind,
                                 e.section == 1 && (!sticker || pickerOpen)
                                     ? (e.weapon > 0 ? e.weapon : InventoryDefaultKnife(InventoryCT))
                                     : index,
                                 sticker && !pickerOpen);
                }
            }
            drawClip = saved;
        }
        if (!catalogOverride && !Cat().loaded && !sticker) {
            auto& content = InventorySharedContent();
            const auto note = DecodeUTF8(content.Ready() ? content.Diagnostic()
                                                         : std::string("Loading the game item schema..."));
            const float nw = std::min(TextW(fonts, note), gridBox.w);
            Text(z, {gridBox.x + (gridBox.w - nw) * .5f, gridBox.y + gridBox.h - F - 4 * s, nw + 1, F},
                 Fit(fonts, note, gridBox.w), Alpha(palette[14], .8f));
        }
        if (gridMax > 0) {
            gridTrack = {gridBox.x + gridBox.w + 4 * s, gridBox.y, 4 * s, gridBox.h};
            const float th = std::max(20 * s, gridBox.h * gridBox.h / (gridBox.h + gridMax));
            gridThumb = {gridTrack.x, gridTrack.y + (gridTrack.h - th) * gridScroll / gridMax, gridTrack.w,
                         th};
            Rect(z, gridThumb, Mix(palette[18], palette[2], thumbDrag ? .3f : 0.f), 2 * s);
            AddHit(z, {gridThumb.x - 3 * s, gridThumb.y, gridThumb.w + 6 * s, gridThumb.h}, GridThumb);
        } else
            gridTrack = gridThumb = {};
        if (pickerOpen) {
            stickerSlot = savedSlot;
            blocked = savedBlocked;
            searchFocus = savedSearchFocus;
            search = savedSearch;
            gridScroll = savedGridScroll;
            gridTarget = savedGridTarget;
            entriesKey.clear();
        }
        RememberWindow(10, begin);
    }

    bool tipLive = false;
    unsigned NextRandom() {
        randomState ^= randomState << 13;
        randomState ^= randomState >> 17;
        randomState ^= randomState << 5;
        return randomState;
    }
    const IconImage* FitIcon(int icon, float maxW, float maxH, Color c) {
        if (icon < 0)
            return nullptr;
        auto src = IconSource(icon);
        if (!src || src->width <= 0 || src->height <= 0)
            return nullptr;
        return Icon(icon, std::min(maxH, maxW * float(src->height) / float(src->width)), c);
    }

    Box Place(Box anchor, float w, float h, int width, int height, bool preferAbove) const {
        const float s = scale, below = std::max(0.f, float(height) - 6 * s - (anchor.y + anchor.h + 6 * s)),
                    above = std::max(0.f, anchor.y - 12 * s);
        const bool up = preferAbove ? (h <= above || above >= below) : (h > below && above > below);
        const float fit = std::max(std::min(h, up ? above : below), std::min(h, 60 * s));
        return PresetPopupFit({anchor.x, up ? anchor.y - 6 * s - fit : anchor.y + anchor.h + 6 * s, w, fit},
                              width, height);
    }
    void ScrollThumb(int z, Box b, float scroll, float max) {
        if (max <= 0)
            return;
        const float s = scale, track = b.h - 14 * s, th = std::max(10 * s, track * track / (track + max));
        Rect(z, {b.x + b.w - 5 * s, b.y + 7 * s + (track - th) * scroll / max, 3 * s, th}, palette[18],
             2 * s);
    }

    void MeasureItemList(Fonts& fonts, const Settings& cfg, int width, int height, bool model) {
        const float s = scale, R = F + 14 * s, slot = 42 * s;
        const int key = model ? 3 : 1;
        const auto begin = paint.layers.size();
        BeginWindow(key);
        const Kind kind = EditorKind();
        const auto choices = WeaponChoices(cfg);
        const int current = CardIndex(cfg, shownEditor);
        const Action a = model ? ModelOption : WeaponOption;
        const std::u32string heading =
            model ? Label(kind == KindGloves ? "group_inventory_gloves" : "group_inventory_knives")
                  : std::u32string{};
        const float headH = heading.empty() ? 0.f : F + 12 * s;
        const Box anchor = model ? chipBox : weaponBox;
        float w = std::max(anchor.w, 180 * s);
        for (int idx : choices)
            w = std::max(w, TextW(fonts, ItemName(idx)) + slot + 28 * s);
        if (!heading.empty())
            w = std::max(w, TextW(fonts, heading, 1) + 28 * s);
        const float full = headH + float(choices.size()) * R + 14 * s;
        const Box b = Place(anchor, std::min(w, float(width) - 12 * s),
                            std::min(full, headH + 10 * R + 14 * s), width, height, false);
        dropBox = b;
        dropMax = std::max(0.f, full - b.h);
        dropScroll = std::clamp(dropScroll, 0.f, dropMax);
        if (!blocked)
            hits.push_back({viewport, Surface});
        const int z = SurfaceLayer(b);
        AddHit(z, b, Panel);
        const Box saved = drawClip;
        drawClip = {b.x, b.y + 4 * s, b.w, std::max(0.f, b.h - 8 * s)};
        float y = b.y + 7 * s - dropScroll;
        if (!heading.empty()) {
            Text(z, {b.x + 14 * s, y + (headH - F) * .5f, b.w - 28 * s, F}, heading, palette[2], 1);
            y += headH;
        }
        for (int idx : choices) {
            const Box row{b.x + 7 * s, y, b.w - 14 * s, R};
            y += R;
            if (row.y + row.h < b.y || row.y > b.y + b.h)
                continue;
            const bool on = idx == current;
            Rect(z, row, Alpha(palette[33], .4f * Hover(a, -1, idx)), 9 * s);
            const Color ink = on ? palette[2] : palette[14];
            if (auto im = FitIcon(EquipmentIcon(idx), slot - 8 * s, 12 * s, ink))
                Image(z, row.x + 7 * s + (slot - float(im->image->width)) * .5f,
                      row.y + (R - float(im->image->height)) * .5f, im);
            else if (InventoryIsGlove(idx)) {
                const Box art{row.x + 7 * s, row.y + (R - 24 * s) * .5f, slot - 8 * s, 24 * s};
                if (!ArtworkPath(z, art, InventoryItemArtworkPath(Cat(), idx, 0), .9f)) {
                    const std::u32string g(1, PlaceholderGlyph(KindGloves));
                    const float gw = TextW(fonts, g, 3);
                    Text(z, {row.x + 7 * s + (slot - gw) * .5f, row.y + (R - F) * .5f, gw + 1, F}, g, ink, 3);
                }
            }
            Text(z, {row.x + 7 * s + slot, row.y + (R - F) * .5f, std::max(0.f, row.w - 14 * s - slot), F},
                 ItemName(idx), ink);
            AddHit(z, row, a, -1, idx);
        }
        drawClip = saved;
        ScrollThumb(z, b, dropScroll, dropMax);
        RememberWindow(key, begin);
    }

    void MeasureSortList(Fonts& fonts, int width, int height) {
        const float s = scale, R = F + 14 * s;
        const auto begin = paint.layers.size();
        BeginWindow(2);
        const float marker = TextW(fonts, U"\uf00c", 3) + 12 * s;
        float w = std::max(sortBox.w, 120 * s);
        for (int i = 0; i < 3; ++i)
            w = std::max(w, TextW(fonts, Label(SortKey(i))) + 38 * s + marker);
        const Box b =
            Place(sortBox, std::min(w, float(width) - 12 * s), 3 * R + 14 * s, width, height, false);
        dropBox = b;
        if (!blocked)
            hits.push_back({viewport, Surface});
        const int z = SurfaceLayer(b);
        AddHit(z, b, Panel);
        for (int i = 0; i < 3; ++i) {
            const Box row{b.x + 7 * s, b.y + 7 * s + float(i) * R, b.w - 14 * s, R};
            const bool on = sort == i;
            Rect(z, row, Alpha(palette[33], .4f * Hover(SortOption, -1, i)), 15 * s / 1.6f);
            if (on)
                Text(z, {row.x + 12 * s, row.y + (R - F) * .5f, marker, F}, U"\uf00c", palette[0], 3);
            Text(z, {row.x + 12 * s + marker, row.y + (R - F) * .5f, row.w - 24 * s - marker, F},
                 Label(SortKey(i)), on ? palette[2] : palette[14]);
            AddHit(z, row, SortOption, -1, i);
        }
        RememberWindow(2, begin);
    }

    void MeasureCapsuleList(Fonts& fonts, int width, int height) {
        const float s = scale, R = F + 14 * s, headH = F + 12 * s;
        const auto begin = paint.layers.size();
        BeginWindow(8);
        const auto groups = CapsuleGroups();
        const int current = CurrentCapsule();
        const auto& c = Cat();
        const float marker = TextW(fonts, U"\uf00c", 3) + 12 * s;
        float w = std::max(capsuleBox.w, 180 * s), full = 14 * s;
        for (const auto& g : groups) {
            w = std::max(w, TextW(fonts, g.label, 1) + 28 * s);
            full += headH;
            for (int i : g.capsules) {
                w = std::max(w, TextW(fonts, DecodeUTF8(c.capsules[std::size_t(i)].name)) + 38 * s + marker);
                full += R;
            }
        }
        const Box b = Place(capsuleBox, std::min(w, float(width) - 12 * s), std::min(full, 10 * R + 14 * s),
                            width, height, false);
        dropBox = b;
        dropMax = std::max(0.f, full - b.h);
        dropScroll = std::clamp(dropScroll, 0.f, dropMax);
        if (!blocked)
            hits.push_back({viewport, Surface});
        const int z = SurfaceLayer(b);
        AddHit(z, b, Panel);
        const Box saved = drawClip;
        drawClip = {b.x, b.y + 4 * s, b.w, std::max(0.f, b.h - 8 * s)};
        float y = b.y + 7 * s - dropScroll;
        for (const auto& g : groups) {
            Text(z, {b.x + 14 * s, y + (headH - F) * .5f, b.w - 28 * s, F}, g.label, palette[3], 1);
            y += headH;
            for (int i : g.capsules) {
                const Box row{b.x + 7 * s, y, b.w - 14 * s, R};
                y += R;
                if (row.y + row.h < b.y || row.y > b.y + b.h)
                    continue;
                const bool on = i == current;
                Rect(z, row, Alpha(palette[33], .4f * Hover(CapsuleOption, -1, i)), 15 * s / 1.6f);
                if (on)
                    Text(z, {row.x + 12 * s, row.y + (R - F) * .5f, marker, F}, U"\uf00c", palette[0], 3);
                Text(z, {row.x + 12 * s + marker, row.y + (R - F) * .5f, row.w - 24 * s - marker, F},
                     Fit(fonts, DecodeUTF8(c.capsules[std::size_t(i)].name), row.w - 24 * s - marker),
                     on ? palette[2] : palette[14]);
                AddHit(z, row, CapsuleOption, -1, i);
            }
        }
        drawClip = saved;
        ScrollThumb(z, b, dropScroll, dropMax);
        RememberWindow(8, begin);
    }

    void OptionRow(Fonts& fonts, int z, int o, Box row, const InventoryItem& it) {
        const float s = scale;
        const auto& spec = OptSpecs[std::size_t(o)];
        const bool enabled = OptEnabled(o, it);
        const float a = enabled ? 1.f : .5f, ty = row.y + (row.h - F) * .5f, right = row.x + row.w - 12 * s,
                    left = row.x + 12 * s + (spec.child ? 12 * s : 0.f);
        optRows[std::size_t(o)] = row;
        if (spec.type == TypeHeading) {
            Text(z, {row.x + 12 * s, ty, row.w - 24 * s, F}, Label(spec.key), palette[2], 1);
            return;
        }
        const float hv = enabled ? Hover(OptRow, o) : 0.f;
        Rect(z, row, Alpha(palette[33], .4f * hv), 15 * s / 1.6f);
        if (enabled)
            AddHit(z, row, OptRow, o);
        float labelRight = right;
        auto swatch = [&](float x) {
            const Box sw{x - 16 * s, row.y + (row.h - 16 * s) * .5f, 16 * s, 16 * s};
            Swatch(z, sw, ColorValue(it, o), a);
            optControls[std::size_t(o)] = sw;
            if (enabled)
                AddHit(z, sw, OptValue, o);
            labelRight = sw.x - 8 * s;
        };
        auto toggle = [&](bool on) {
            const float h = F + 2 * s, center = row.y + row.h * .5f, t = on ? 1.f : 0.f;
            const Box c{right - 32 * s, center - h * .5f, 32 * s, h};
            Rect(z, c, Alpha(palette[22], a), h * .5f);
            Rect(z, c, Alpha(palette[23], a * t), h * .5f);
            const float r = h * .5f - 2 * s, cx = c.x + h * .5f + (c.w - h) * t;
            Rect(z, {cx - r, center - r, 2 * r, 2 * r}, Alpha(Mix(palette[20], palette[21], t), a), r);
            labelRight = c.x - 8 * s;
            return c;
        };
        switch (spec.type) {
        case TypeText: {
            const float fw = std::trunc(row.w / 2.5f), fh = F + 8 * s;
            const Box f{right - fw, row.y + (row.h - fh) * .5f, fw, fh};
            nameBox = f;
            optControls[std::size_t(o)] = f;
            labelRight = f.x - 8 * s;
            Rect(z, f, Mix(palette[12], palette[13], nameEditing ? 0.f : .5f * Hover(OptName, o)), 6 * s);
            Rect(z, f, nameEditing ? Alpha(palette[30], .55f) : palette[11], 6 * s, s);
            const float tx = f.x + 8 * s, tw = std::max(0.f, f.w - 16 * s);
            nameTextX = tx;
            if (nameEditing) {
                nameEdit.Measure(fonts, 13 * s, nameText, tw, true, 0);
                const Box saved = drawClip, area{tx, f.y, tw, f.h};
                drawClip = saved.w > 0 ? PresetIntersect(saved, area) : area;
                if (drawClip.w > 0 && drawClip.h > 0) {
                    if (nameEdit.Selected()) {
                        const float a0 = nameEdit.advance[nameEdit.Begin()],
                                    a1 = nameEdit.advance[nameEdit.End()];
                        Rect(z, {tx + a0 - nameEdit.scroll, f.y + 4 * s, a1 - a0, f.h - 8 * s},
                             Alpha(palette[30], .35f));
                    }
                    Text(z, {tx - nameEdit.scroll, ty, TextW(fonts, nameText) + nameEdit.scroll + 2, F},
                         nameText, palette[0]);
                    const float caret =
                        nameEdit.advance.empty()
                            ? 0.f
                            : nameEdit.advance[std::min(nameEdit.cursor, nameEdit.advance.size() - 1)];
                    Rect(z, {tx + caret - nameEdit.scroll, f.y + 5 * s, s, f.h - 10 * s}, palette[2]);
                }
                drawClip = saved;
            } else
                Text(z, {tx, ty, tw, F}, Fit(fonts, DecodeUTF8(it.name), tw), palette[0]);
            if (enabled)
                AddHit(z, f, OptName, o);
            break;
        }
        case TypeSlider: {
            const float w = std::trunc(row.w / 2.6f);
            const Box ctl{right - w, row.y + (row.h - 6 * s) * .5f, w, 6 * s};
            optSliders[std::size_t(o)] = ctl;
            const float v = std::clamp(SliderFraction(o, it), 0.f, 1.f);
            Rect(z, ctl, Alpha(palette[24], a), 3 * s);
            {
                const Box saved = drawClip, fill{ctl.x, ctl.y, ctl.w * v, ctl.h};
                const Box clip = saved.w > 0 ? PresetIntersect(saved, fill) : fill;
                if (v > 0 && clip.w > 0 && clip.h > 0) {
                    drawClip = clip;
                    Rect(z, ctl, Alpha(palette[25], a), 3 * s);
                }
                drawClip = saved;
            }

            const auto t = o == OptStatTrakValue && valueEditing ? DecodeUTF8(numeric) : SliderText(o, it);
            const float tw = TextW(fonts, t), textw = std::max(tw, 8 * s);
            const Box value{ctl.x - 8 * s - textw, row.y, textw, row.h};
            if (o == OptStatTrakValue && valueEditing && selectAll && !numeric.empty())
                Rect(z, {value.x, row.y + 4 * s, value.w, row.h - 8 * s}, Alpha(palette[30], .35f));
            Text(z, {value.x, ty, textw + 1, F}, t, Alpha(palette[14], a));
            labelRight = value.x - 8 * s;
            if (enabled) {
                AddHit(z, {ctl.x - 4 * s, row.y, ctl.w + 8 * s, row.h}, OptSlider, o);
                if (o == OptStatTrakValue) {
                    valueBox = value;
                    optControls[std::size_t(o)] = value;
                    AddHit(z, value, OptValue, o);
                }
            }
            break;
        }
        case TypeColor:
            if (o == OptColors) {
                {
                    float x = right;
                    for (int i = 3; i >= 0; --i) {
                        const Box sw{x - 16 * s, row.y + (row.h - 16 * s) * .5f, 16 * s, 16 * s};
                        Swatch(z, sw, PaintColorValue(it, i), a);
                        if (enabled)
                            AddHit(z, sw, OptValue, o, i);
                        if (paintColorChannel == i || optControls[std::size_t(o)].w <= 0)
                            optControls[std::size_t(o)] = sw;
                        x -= 22 * s;
                    }
                    labelRight = x + 6 * s - 8 * s;
                }
            } else
                swatch(right);
            break;
        case TypeChoice: {
            const std::u32string chev = U"\uf105";
            const float aw = TextW(fonts, chev, 3);
            Text(z, {right - aw, ty, aw + 1, F}, chev, Alpha(Mix(palette[14], palette[2], hv), a), 3);
            const auto v = Fit(fonts, ChoiceSummary(o, it), row.w * .45f);
            const float vw = TextW(fonts, v);
            Text(z, {right - aw - 8 * s - vw, ty, vw + 1, F}, v, Alpha(palette[14], a));
            optControls[std::size_t(o)] = {right - aw - 8 * s - vw, row.y, vw + aw + 8 * s, row.h};
            labelRight = right - aw - 16 * s - vw;
            break;
        }
        case TypeNumber: {
            const auto value = DecodeUTF8(valueEditing ? numeric : std::to_string(it.statTrakValue));
            const float tw = TextW(fonts, value), nw = std::min(std::max(60 * s, tw + 16 * s), row.w * .42f),
                        nh = F + 6 * s;
            const Box nb{right - nw, row.y + (row.h - nh) * .5f, nw, nh};
            valueBox = nb;
            optControls[std::size_t(o)] = nb;
            labelRight = nb.x - 8 * s;
            Rect(z, nb, Mix(palette[12], palette[13], valueEditing ? 0.f : Hover(OptValue, o)), 6 * s);
            Rect(z, nb, valueEditing ? Alpha(palette[30], .55f) : palette[11], 6 * s, s);
            const float shown = std::min(tw, std::max(0.f, nb.w - 16 * s));
            if (valueEditing && selectAll && !numeric.empty())
                Rect(z, {nb.x + 8 * s, nb.y + 3 * s, shown, nb.h - 6 * s}, Alpha(palette[30], .35f));
            Text(z, {nb.x + 8 * s, ty, std::max(0.f, nb.w - 16 * s), F}, value, palette[14]);
            if (valueEditing)
                Rect(z, {nb.x + 8 * s + shown + s, nb.y + 4 * s, s, nb.h - 8 * s}, palette[2]);
            if (enabled)
                AddHit(z, nb, OptValue, o);
            break;
        }
        case TypeToggle:
            toggle(ToggleValue(o, it));
            break;
        case TypeToggleColor: {
            const Box c = toggle(ToggleValue(o, it));
            swatch(c.x - 10 * s);
            break;
        }
        default:
            break;
        }
        const float lw = std::max(0.f, labelRight - left);
        Text(z, {left, ty, lw, F}, Fit(fonts, Label(spec.key), lw),
             Alpha(Mix(palette[spec.child ? 14 : 0], palette[2], hv), a));
    }

    void WearRow(Fonts& fonts, int z, Box row, const InventoryItem& it) {
        const float s = scale, R = F + 14 * s;
        OptionRow(fonts, z, OptWear, {row.x, row.y, row.w, R}, it);
        const Box bar{row.x + 12 * s, row.y + R + 7 * s, std::max(0.f, row.w - 24 * s), 6 * s};
        optSliders[std::size_t(OptWearValue)] = bar;
        const float hv = Hover(OptSlider, OptWearValue);
        const Color colors[5] = {{44 / 255.f, 94 / 255.f, 101 / 255.f, 1},
                                 {148 / 255.f, 172 / 255.f, 67 / 255.f, 1},
                                 {249 / 255.f, 223 / 255.f, 67 / 255.f, 1},
                                 {254 / 255.f, 143 / 255.f, 67 / 255.f, 1},
                                 {240 / 255.f, 86 / 255.f, 64 / 255.f, 1}};
        const Box saved = drawClip;
        for (int i = 0; i < 5; ++i) {
            const float x0 = InventoryWearEdges[std::size_t(i)], x1 = InventoryWearEdges[std::size_t(i) + 1];
            const Box band{bar.x + bar.w * x0, bar.y, bar.w * (x1 - x0), bar.h};
            drawClip = saved.w > 0 ? PresetIntersect(saved, band) : band;
            if (drawClip.w > 0 && drawClip.h > 0)
                Rect(z, bar, Mix(colors[i], palette[2], .07f * hv), 3 * s);
        }
        drawClip = saved;
        const float x = bar.x + bar.w * std::clamp(ActualWear(it), 0.f, 1.f);
        const Color marker = Mix(palette[14], palette[2], hv);

        for (int i = 0; i < 4; ++i) {
            const float w = float(7 - i * 2) * s;
            Rect(z, {x - w * .5f, bar.y - (10 - i) * s, w, s}, marker);
        }
        if (OptEnabled(OptWearValue, it))
            AddHit(z, {bar.x - 3 * s, bar.y - 5 * s, bar.w + 6 * s, bar.h + 10 * s}, OptSlider, OptWearValue);
    }

    void MeasureOptions(Fonts& fonts, const Settings& cfg, int width, int height) {
        const float s = scale, R = F + 14 * s;
        const auto begin = paint.layers.size();
        BeginWindow(4);
        const auto it = CurrentItem(cfg);
        const Kind kind = EditorKind();
        std::vector<int> rows;
        for (int o = 0; o < OptCount; ++o)
            if (o != OptWearValue && OptVisible(o, it, kind))
                rows.push_back(o);
        const float titleH = F + 18 * s, content = float(rows.size()) * R + 14 * s + 22 * s,
                    full = titleH + content + 7 * s;
        const Box b =
            Place(optionsAnchor, std::min(300 * s, float(width) - 12 * s), full, width, height, true);
        optionsBox = b;
        if (!blocked)
            hits.push_back({viewport, Surface});
        const int z = SurfaceLayer(b);
        AddHit(z, b, Panel);
        const float tf = fonts.PixelHeight(2, 14 * s);
        Text(z, {b.x + 14 * s, b.y + (titleH - tf) * .5f + 2 * s, b.w - 28 * s, tf},
             Label("inventory_skinoptions"), palette[2], 2, 14);
        optionsBody = {b.x + 7 * s, b.y + titleH, b.w - 14 * s, std::max(0.f, b.h - titleH - 7 * s)};
        optionsMax = std::max(0.f, content - optionsBody.h);
        optionsScroll = std::clamp(optionsScroll, 0.f, optionsMax);
        Rect(z, optionsBody, palette[40], 12 * s);
        Rect(z, optionsBody, palette[11], 12 * s, s);
        const Box saved = drawClip;
        drawClip = optionsBody;
        float y = optionsBody.y + 7 * s - optionsScroll;
        for (int o : rows) {
            const float rh = R + (o == OptWear ? 22 * s : 0.f);
            const Box row{optionsBody.x + 7 * s, y, optionsBody.w - 14 * s, rh};
            y += rh;
            if (row.y + row.h < optionsBody.y || row.y > optionsBody.y + optionsBody.h)
                continue;
            if (o == OptWear)
                WearRow(fonts, z, row, it);
            else
                OptionRow(fonts, z, o, row, it);
        }
        drawClip = saved;
        ScrollThumb(z, optionsBody, optionsScroll, optionsMax);
        RememberWindow(4, begin);
    }

    void MeasureChoice(Fonts& fonts, const Settings& cfg, int width, int height) {
        const float s = scale, R = F + 14 * s;
        const int o = choice;
        const Box row = optRows[std::size_t(o)];
        if (row.w <= 0 || row.h <= 0) {
            choice = -1;
            return;
        }
        const auto begin = paint.layers.size();
        BeginWindow(500 + o);
        const auto it = CurrentItem(cfg);
        const auto opts = ChoiceOptions(o, it);
        const int value = ChoiceValue(o, it);
        const float marker = TextW(fonts, U"\uf00c", 3) + 12 * s;
        float w = 140 * s;
        for (const auto& p : opts)
            w = std::max(w, TextW(fonts, p.second) + 38 * s + marker);
        w = std::min(w, float(width) - 12 * s);
        const float h = std::min(float(opts.size()) * R + 14 * s, float(height) - 12 * s);
        Box want{optionsBox.x + optionsBox.w + 7 * s, row.y + row.h * .5f - h * .25f, w, h};
        if (want.x + w > float(width) - 6 * s)
            want.x = optionsBox.x - w - 7 * s;
        const Box b = PresetPopupFit(want, width, height);
        if (!blocked)
            hits.push_back({viewport, Surface});
        const int z = SurfaceLayer(b);
        AddHit(z, b, Panel);
        for (std::size_t j = 0; j < opts.size(); ++j) {
            const Box r{b.x + 7 * s, b.y + 7 * s + float(j) * R, b.w - 14 * s, R};
            const bool on = opts[j].first == value;
            Rect(z, r, Alpha(palette[33], .4f * Hover(OptOption, o, opts[j].first)), 15 * s / 1.6f);
            if (on)
                Text(z, {r.x + 12 * s, r.y + (R - F) * .5f, marker, F}, U"\uf00c", palette[0], 3);
            Text(z, {r.x + 12 * s + marker, r.y + (R - F) * .5f, r.w - 24 * s - marker, F}, opts[j].second,
                 on ? palette[2] : palette[14]);
            AddHit(z, r, OptOption, o, opts[j].first);
        }
        RememberWindow(500 + o, begin);
    }

    void MeasureColor(Fonts& fonts, const Settings& cfg, int width, int height) {
        const float s = scale;
        const int o = color;
        Box anchor = optControls[std::size_t(o)];
        if (anchor.w <= 0)
            anchor = optRows[std::size_t(o)];
        if (anchor.w <= 0) {
            color = -1;
            return;
        }
        const auto begin = paint.layers.size();
        BeginWindow(600 + o);
        if (!blocked)
            hits.push_back({viewport, Surface});
        auto c = PickerSettings(cfg);
        picker.languages = languages;
        picker.SetMetrics(fonts, s);
        const float pw = 265 * s;
        Box b = PresetPopupFit({optionsBox.x + optionsBox.w + 7 * s, anchor.y, pw, picker.Height(s)}, width,
                               height);
        if (b.x < optionsBox.x + optionsBox.w && optionsBox.x - pw - 7 * s >= 0)
            b.x = optionsBox.x - pw - 7 * s;
        const int z = SurfaceLayer(b);
        picker.Draw(paint, z, fonts, c, b);
        picker.DrawMenus(paint, fonts, c, width, height);
        RememberWindow(600 + o, begin);
    }

    struct ContextRow {
        int code;
        char32_t glyph;
        std::u32string label;
        bool enabled;
    };
    std::vector<ContextRow> ContextRows(const Settings& cfg) const {
        std::vector<ContextRow> r;
        if (contextCard >= 0) {
            r.push_back({0, 0xf0c5, Label("menu_buttons_copy"), true});
            r.push_back({1, 0xf0ea, Label("menu_buttons_paste"), CanPaste(cfg, contextCard)});
            r.push_back({4, 0xf2ed, Label("menu_buttons_delete"), true});
        } else if (contextSlot >= 0) {
            const bool charm = contextSlot == 5;
            r.push_back({0, 0xf0c5, Label("menu_buttons_copy"), true});
            r.push_back({1, 0xf0ea, Label("menu_buttons_paste"), slotClip.has && slotClip.charm == charm});
            r.push_back({2, 0xf601, Label("inventory_stickeroptions_resetposition"), true});
            if (!charm)
                r.push_back({3, 0xe630, Label("inventory_stickeroptions_resetrotation"), true});
            r.push_back({4, 0xf2ed, Label("menu_buttons_delete"), true});
        }
        return r;
    }
    void MeasureContext(Fonts& fonts, const Settings& cfg, int width, int height) {
        const float s = scale, R = F + 14 * s;
        const auto rows = ContextRows(cfg);
        if (rows.empty()) {
            contextOpen = false;
            return;
        }
        const auto begin = paint.layers.size();
        BeginWindow(7);
        float icon = 0;
        for (const auto& r : rows)
            icon = std::max(icon, TextW(fonts, std::u32string(1, r.glyph), 3));

        float w = 120 * s;
        for (const auto& r : rows)
            w = std::max(w, TextW(fonts, r.label) + icon + 54 * s);
        const Box b = PresetPopupFit({contextPoint.x, contextPoint.y, std::min(w, float(width) - 12 * s),
                                      float(rows.size()) * R + 14 * s},
                                     width, height);
        contextBox = b;
        if (!blocked)
            hits.push_back({viewport, Surface});
        const int z = SurfaceLayer(b);
        AddHit(z, b, Panel);
        for (std::size_t j = 0; j < rows.size(); ++j) {
            const auto& r = rows[j];
            const Box row{b.x + 7 * s, b.y + 7 * s + float(j) * R, b.w - 14 * s, R};
            const float a = r.enabled ? 1.f : .45f, hv = r.enabled ? Hover(ContextItem, -1, r.code) : 0.f;
            Rect(z, row, Alpha(palette[33], .4f * hv), 15 * s / 1.6f);
            const Color ink = Alpha(Mix(palette[14], palette[2], hv), a);
            Text(z, {row.x + 10 * s, row.y + (R - F) * .5f, icon + 1, F}, std::u32string(1, r.glyph), ink, 3);
            Text(z, {row.x + 20 * s + icon, row.y + (R - F) * .5f, std::max(0.f, row.w - 20 * s - icon), F},
                 r.label, ink);
            if (r.enabled)
                AddHit(z, row, ContextItem, -1, r.code);
        }
        RememberWindow(7, begin);
    }

    void MeasureBigPreview(Fonts& fonts, const Settings& cfg) {
        const float s = scale;
        bigBox = InventoryBigPreviewWindow(viewport);
        if (!InventoryPreviewBoxValid(bigBox))
            return;
        const int shade = Layer(viewport, false);
        paint.layers[std::size_t(shade)].shadow = false;
        paint.layers[std::size_t(shade)].clipToPage = false;
        Rect(shade, viewport, {0, 0, 0, .5f});
        AddHit(shade, viewport, BigBackdrop);
        const int z = Layer(bigBox, true, 12 * s);
        paint.layers[std::size_t(z)].clipToPage = false;
        Rect(z, bigBox, Alpha(palette[8], .95f), 12 * s);
        AddHit(z, bigBox, Panel);
        previewBox = bigBox;
        itemPreviewClip = PresetIntersect(bigBox, viewport);
        const Kind kind = EditorKind();
        const auto info = Info(cfg, shownEditor);
        const auto item = CurrentItem(cfg);
        if (nativeItemPreview) {
            if (nativeItemMusic &&
                InventoryMusicReady().load(std::memory_order_acquire) != PreviewMusicId(info.index)) {
                const Box saved = drawClip;
                drawClip = itemPreviewClip;
                Artwork(fonts, z, previewBox, kind, info.index, palette[2], .48f, 1, 0);
                drawClip = saved;
            }
            PresetDraw d{};
            d.box = InventoryBigItemDisplaySurface(previewBox, itemSourceBox, s, nativeItemMusic);
            d.color = {1, 1, 1, 1};
            d.nativePreviewTeam = 2;
            const Box saved = drawClip;
            drawClip = itemPreviewClip;
            Push(z, std::move(d));
            drawClip = saved;
            if (!blocked)
                AddHit(z, itemPreviewClip, ModelDrag);
        } else {
            const Box saved = drawClip;
            drawClip = itemPreviewClip;
            Artwork(fonts, z, previewBox, kind, PaintKind(kind) ? CardIndex(cfg, shownEditor) : info.index,
                    palette[2], .8f, 1, item.paintKit);
            drawClip = saved;
        }

        const int header = Layer(bigBox);
        paint.layers[std::size_t(header)].clipToPage = false;
        const InventoryCollection* collection =
            PaintKind(kind) && info.paint ? InventoryCollectionFor(Cat(), info.index, info.paint->id)
                                          : nullptr;
        const bool hasCollection = collection && !collection->name.empty();
        const float ih = hasCollection ? 75 * s : 0, iw = hasCollection ? ih * (128.f / 99.f) : 0,
                    gap = hasCollection ? 10 * s : 0;
        const float available = std::max(1.f, bigBox.w - 100 * s - iw - gap);
        auto rawTitle = Title(info);
        float titlePx = TextW(fonts, rawTitle, 2, 30) > 500 * s ? 15.f : 30.f;
        auto title = Fit(fonts, rawTitle, available, 2, titlePx);
        auto subtitle =
            hasCollection ? Fit(fonts, DecodeUTF8(collection->name), available, 0, 26) : std::u32string{};
        const float tw = TextW(fonts, title, 2, titlePx), cw = TextW(fonts, subtitle, 0, 26);
        const float th = fonts.PixelHeight(2, titlePx * s),
                    sh = hasCollection ? fonts.PixelHeight(0, 26 * s) : 0;
        const float textH = th + (hasCollection ? sh : 0), blockH = std::max(ih, textH);
        const float gx = bigBox.x + std::trunc((bigBox.w - (iw + gap + std::max(tw, cw))) * .5f),
                    ty = bigBox.y + 20 * s, tx = gx + iw + gap, textY = ty + (blockH - textH) * .5f;
        if (hasCollection)
            ArtworkPath(header, {gx, ty + (blockH - ih) * .5f, iw, ih}, collection->image, 1.f);
        Text(header, {tx, textY, tw + 1, th}, title, palette[2], 2, titlePx);
        if (hasCollection)
            Text(header, {tx, textY + th, cw + 1, sh}, subtitle, palette[0], 0, 26);
        const float lineWidth = std::min(550 * s, bigBox.w);
        Rect(header, {bigBox.x + (bigBox.w - lineWidth) * .5f, ty + blockH + 10 * s, lineWidth, 5 * s},
             RarityColor(info.rarity));
        const Box close{bigBox.x + bigBox.w - 40 * s, bigBox.y + 14 * s, 26 * s, 26 * s};
        const float hv = Hover(BigClose);

        {
            float x = bigBox.x + 15 * s;
            const float h = F + 14 * s, y = bigBox.y + bigBox.h - h - 15 * s;
            Box opts{};
            if (PaintKind(kind) && stickerSlot < 0) {
                if (item.paintKit > 0)
                    Tool(fonts, header, x, y, h, ToolOptions, 0xf3f0, palette[2], optionsOpen, &opts);
                if (Scoped(CardIndex(cfg, shownEditor)))
                    Tool(fonts, header, x, y, h, ToolCamera, cameraZoom ? 0xf010 : 0xf00e, palette[2], false);
            }
            if (PaintKind(kind))
                Tool(fonts, header, x, y, h, ToolBoth, 0xf560, palette[31], item.bothTeams);
            if (opts.w > 0)
                optionsAnchor = opts;
        }
        MeasureMovingControls(fonts, cfg, header, item, previewBox);
        Rect(header, close, Alpha(palette[33], .4f * hv), 6 * s);
        const std::u32string x = U"\uf00d";
        const float xw = TextW(fonts, x, 3, 15), xh = fonts.PixelHeight(0, 15 * s);
        Text(header, {close.x + (close.w - xw) * .5f, close.y + (close.h - xh) * .5f, xw + 1, xh}, x,
             Mix(palette[14], palette[2], hv), 3, 15);
        AddHit(header, close, BigClose);
    }

    void MeasureBigPicker(Fonts& fonts, const Settings& cfg, int width, int height) {
        const float s = scale;
        const float w = 460 * s, h = std::min(370 * s, std::max(80 * s, float(height) - 12 * s));
        const Box anchor = slotBoxes[std::size_t(std::clamp(stickerSlot, 0, 5))];
        const float below = anchor.y + anchor.h + 4 * s;
        const float popupY = below + h <= float(height) ? below : std::max(0.f, anchor.y - h - 4 * s);
        const Box b = PresetPopupFit({anchor.x, popupY, w, h}, width, height);
        const int z = SurfaceLayer(b);
        AddHit(z, b, Panel);
        const float fy = b.y + 12 * s, fh = F + 7.2f * s, fx = b.x + 15 * s, fw = std::max(0.f, b.w - 30 * s);
        float x = fx;
        const int cap = stickerSlot < 5 ? CurrentCapsule() : -1;
        const float bw = fh;
        if (cap >= 0) {
            const float cw = std::min(150 * s, std::max(0.f, fw - bw - 60 * s));
            Dropdown(fonts, z, {x, fy, cw, fh}, CapsuleDrop,
                     DecodeUTF8(Cat().capsules[std::size_t(cap)].name), drop == 3);
            x += cw + 8 * s;
        }
        SearchField(fonts, z, {x, fy, std::max(0.f, fx + fw - bw - 8 * s - x), fh});
        const Box btn{fx + fw - bw, fy, bw, fh};
        const Action action = stickerSlot < 5 ? StickerFilter : CharmRandom;
        const bool on = stickerSlot < 5 && hideTournament;
        const float hv = Hover(action);
        const std::u32string glyph(1, stickerSlot < 5 ? char32_t(0xf0b0) : char32_t(0xf77e));
        const float gw = TextW(fonts, glyph, 3);
        Rect(z, btn, Mix(palette[12], palette[13], hv), 6 * s);
        Rect(z, btn, on ? Alpha(palette[30], .7f) : palette[11], 6 * s, s);
        Text(z, {btn.x + (bw - gw) * .5f, btn.y + (fh - F) * .5f, gw + 1, F}, glyph,
             on ? palette[30] : Mix(palette[14], palette[2], hv), 3);
        AddHit(z, btn, action);
        gridBox = {fx, fy + fh + 10 * s, std::max(0.f, fw - 10 * s),
                   std::max(0.f, b.y + b.h - 12 * s - (fy + fh + 10 * s))};
        BuildEntries(cfg);
        LayoutGrid(gridBox.w, 4);
        gridMax = std::max(0.f, gridContent - gridBox.h);
        gridTarget = std::clamp(gridTarget, 0.f, gridMax);
        gridScroll = std::clamp(gridScroll, 0.f, gridMax);
        const float gap = 10 * s, cw = std::max(1.f, (gridBox.w - 3 * gap) / 4.f),
                    imgH = std::trunc(cw * .72f);
        const int selected = SelectedId(cfg);
        const Box saved = drawClip;
        drawClip = gridBox;
        for (const auto& r : gridRows) {
            const float ry = std::round(gridBox.y + r.y - gridScroll);
            if (ry + r.h < gridBox.y || ry > gridBox.y + gridBox.h)
                continue;
            if (r.header) {
                Text(z, {gridBox.x, ry + (r.h - F) * .5f, gridBox.w, F}, entries[r.first].name, palette[2],
                     1);
                continue;
            }
            for (std::size_t j = 0; j < r.count; ++j) {
                const auto& e = entries[r.first + j];
                DrawGridCard(fonts, z,
                             {std::round(gridBox.x + float(j) * (cw + gap)), ry, std::floor(cw), imgH}, e,
                             e.id == selected, EditorKind(), CardIndex(cfg, shownEditor), true);
            }
        }
        drawClip = saved;
        if (gridMax > 0) {
            gridTrack = {gridBox.x + gridBox.w + 4 * s, gridBox.y, 4 * s, gridBox.h};
            const float th = std::max(20 * s, gridBox.h * gridBox.h / (gridBox.h + gridMax));
            gridThumb = {gridTrack.x, gridTrack.y + (gridTrack.h - th) * gridScroll / gridMax, gridTrack.w,
                         th};
            Rect(z, gridThumb, Mix(palette[18], palette[2], thumbDrag ? .3f : 0.f), 2 * s);
            AddHit(z, {gridThumb.x - 3 * s, gridThumb.y, gridThumb.w + 6 * s, gridThumb.h}, GridThumb);
        } else
            gridTrack = gridThumb = {};
    }

    std::u32string SlotName(const Settings& cfg, int slot) const {
        const auto it = CurrentItem(cfg);
        if (slot == 5) {
            if (it.charm.id) {
                for (const auto& k : Cat().keychains)
                    if (k.id == it.charm.id)
                        return DecodeUTF8(k.name);
                return DecodeUTF8("#" + std::to_string(it.charm.id));
            }
            return Label("inventory_move_toggler_charm");
        }
        const int id = it.stickers[std::size_t(std::clamp(slot, 0, 4))].id;
        if (id) {
            if (auto st = Cat().Sticker(id))
                return DecodeUTF8(st->name);
            return DecodeUTF8("#" + std::to_string(id));
        }
        return Label("inventory_stickeroptions_slot") + U" " + DecodeUTF8(std::to_string(slot + 1));
    }

    void MeasureTooltip(Fonts& fonts, const Settings& cfg, int width, int height) {
        tipLive = false;
        const int h = HitAt(mouseX, mouseY);
        const bool calm = !blocked && !Capturing() && choice < 0 && color < 0 && !contextOpen && drop < 0 &&
                          !nameEditing && !valueEditing;
        if (h >= 0 && hoverTime >= .3f && calm) {
            const auto& hit = hits[std::size_t(h)];
            std::u32string title, body;
            bool tinted = false;
            Color tint{};
            const InventoryCollection* tooltipCollection = nullptr;
            std::string tooltipStickerImage;
            switch (hit.action) {
            case Paint: {
                const Entry* e = FindEntry(hit.field, hit.option);
                if (!e || e->id <= 0)
                    break;
                title = e->name;
                tinted = e->rarity > 0;
                tint = RarityColor(e->rarity);
                body = e->group;
                if (stickerSlot >= 0)
                    tooltipStickerImage = SlotArtwork(stickerSlot, e->id);
                if (stickerSlot < 0 && PaintKind(EditorKind()) && !e->group.empty())
                    tooltipCollection = InventoryCollectionFor(Cat(), e->weapon, e->id);
                if (stickerSlot < 0 && PaintKind(EditorKind()) && (e->group.empty() || e->section == 1)) {
                    auto line = Label("inventory_skin_weapon") + U": " +
                                (e->weapon < 0 ? Label("group_inventory_knives") : ItemName(e->weapon));
                    body = body.empty() ? line : body + U"\n" + line;
                }
                if (!e->description.empty())
                    body += (body.empty() ? U"" : U"\n\n") + e->description;
                break;
            }
            case Card:
                if (editor < 0)
                    title = Title(Info(cfg, hit.option));
                break;
            case ToolOptions:
                title = Label("inventory_skinoptions");
                break;
            case ToolCamera:
                title = Label("inventory_togglecameraangles");
                break;
            case ToolBig:
                title = Label("inventory_togglebigpreview");
                break;
            case ToolBoth:
                title = Label("inventory_applytobothteams");
                break;
            case StickerFilter:
                title = Label("inventory_stickers_hidetournamentstickers");
                break;
            case CharmRandom:
                title = Label("inventory_keychains_randomizetemplate");
                break;
            case Slot:
                title = SlotName(cfg, hit.option);
                if (hit.option >= 0 && hit.option < 6) {
                    const auto item = CurrentItem(cfg);
                    const int id =
                        hit.option == 5 ? item.charm.id : item.stickers[std::size_t(hit.option)].id;
                    tooltipStickerImage = SlotArtwork(hit.option, id);
                }
                break;
            default:
                break;
            }
            if (!title.empty()) {
                PresetDraw stickerIcon;
                const bool hasStickerIcon =
                    !tooltipStickerImage.empty() &&
                    ArtworkDraw({0, 0, 32 * scale, 32 * scale}, tooltipStickerImage, stickerIcon, 1.f);
                if (hasStickerIcon) {
                    lastTooltip = WorldCollectionTooltip(
                        fonts, cfg, hit.box, title,
                        body.empty() ? Label((hit.action == Slot ? hit.option : stickerSlot) == 5
                                                 ? "inventory_move_toggler_charm"
                                                 : "inventory_move_toggler_stickers")
                                     : body,
                        U"", width, height, std::move(stickerIcon));
                } else if (body.empty())
                    lastTooltip = WorldNameTooltip(fonts, cfg, hit.box, title, width, height);
                else {
                    PresetDraw icon;
                    const bool hasIcon =
                        tooltipCollection &&
                        ArtworkDraw({0, 0, 32 * scale, 32 * scale}, tooltipCollection->image, icon, 1.f);
                    if (hasIcon) {
                        auto rest = body.substr(DecodeUTF8(tooltipCollection->name).size());
                        while (!rest.empty() && rest.front() == U'\n')
                            rest.erase(rest.begin());
                        lastTooltip = WorldCollectionTooltip(fonts, cfg, hit.box, title,
                                                             DecodeUTF8(tooltipCollection->name), rest, width,
                                                             height, std::move(icon));
                    } else
                        lastTooltip =
                            WorldDescriptionTooltip(fonts, cfg, hit.box, title, body, width, height);
                    if (tinted && lastTooltip.draw.size() > 2)
                        lastTooltip.draw[2].color = tint;
                }
                if (tinted && lastTooltip.draw.size() > 2)
                    lastTooltip.draw[2].color = tint;
                tooltipStored = true;
                tipLive = true;
            }
        }
        if (tooltipStored && !blocked && hoverTime >= .3f)
            AppendWorldTooltip(paint, lastTooltip, tooltipMotion.value);
    }

    void Measure(Fonts& fonts, const Settings& cfg, const Layout& layout, Box line, int width, int height,
                 bool shown, bool modalBlocked) {
        if (!shown) {
            Hide();
            return;
        }
        visible = true;
        blocked = modalBlocked;
        scale = cfg.scale;
        F = fonts.PixelHeight(0, 13 * scale);
        viewport = {0, 0, float(width), float(height)};
        palette = CurrentPalette(cfg);
        paint.layers.clear();
        drawnWindows.clear();
        hits.clear();
        drawClip = {};
        cardBoxes.fill({});
        slotBoxes.fill({});
        optRows.fill({});
        optSliders.fill({});
        optControls.fill({});
        bigBox = gridBox = gridTrack = gridThumb = searchBox = nameBox = valueBox = chipBox = weaponBox =
            sortBox = capsuleBox = optionsAnchor = optionsBox = dropBox = contextBox = {};
        if (blocked) {
            ClosePopups();
            searchFocus = false;
            hover = -1;
            hoverTime = 0;
            tooltipStored = false;
        }
        RefreshCatalog();
        RefreshAssets();
        shownEditor = editor;
        nativeItemPreview = false;
        const auto artNow = InventoryArtworkClock();
        if (artNow >= nextArtWarm) {
            InventoryPrefetchLoadout(Cat(), cfg, artNow);
            nextArtWarm = artNow + 300;
        }
        if (stickerSlot >= 0 && !StickerCapable(cfg))
            stickerSlot = -1;
        const auto item = CurrentItem(cfg);
        const Kind kind = EditorKind();
        if (shownEditor < 0) {
            if (contextSlot >= 0) {
                contextOpen = false;
                contextSlot = -1;
            }
            drop = -1;
            optionsOpen = false;
            choice = color = -1;
            nameEditing = valueEditing = searchFocus = false;
        }
        if (optionsOpen && (!PaintKind(kind) || item.paintKit <= 0 || stickerSlot >= 0))
            optionsOpen = false;
        if (!optionsOpen) {
            choice = color = -1;
            nameEditing = valueEditing = false;
        }
        if (choice >= 0 && (!OptVisible(choice, item, kind) || !OptEnabled(choice, item)))
            choice = -1;
        if (color >= 0 && (!OptVisible(color, item, kind) || !OptEnabled(color, item))) {
            color = -1;
            picker.held = -1;
        }
        if (valueEditing && !OptVisible(OptStatTrakValue, item, kind)) {
            valueEditing = false;
            numeric.clear();
        }
        if ((drop == 0 || drop == 1) && (bigPreview || stickerSlot >= 0))
            drop = -1;
        if (drop == 0 && kind != KindWeapon && kind != KindKnife)
            drop = -1;
        if (drop == 1 && !PaintKind(kind))
            drop = -1;
        if (drop == 2 && kind != KindKnife && kind != KindGloves)
            drop = -1;
        if (drop == 3 &&
            (stickerSlot < 0 || stickerSlot >= 5 || !StickerCapable(cfg) || Cat().capsules.empty()))
            drop = -1;
        if (contextCard >= 0 && shownEditor >= 0) {
            contextOpen = false;
            contextCard = -1;
        }
        MeasureLoadout(fonts, cfg, layout, line, height);
        if (shownEditor >= 0) {
            MeasureEditor(fonts, cfg, layout);
            if (!bigPreview && stickerSlot >= 0 && StickerCapable(cfg))
                MeasureBigPicker(fonts, cfg, width, height);
            if (drop == 0)
                MeasureItemList(fonts, cfg, width, height, false);
            else if (drop == 1)
                MeasureSortList(fonts, width, height);
            else if (drop == 2)
                MeasureItemList(fonts, cfg, width, height, true);
            else if (drop == 3 && !bigPreview)
                MeasureCapsuleList(fonts, width, height);
            if (optionsOpen && !bigPreview && optionsAnchor.w <= 0) {
                optionsOpen = false;
                choice = color = -1;
                nameEditing = valueEditing = false;
            }
            if (optionsOpen && !bigPreview) {
                MeasureOptions(fonts, cfg, width, height);
                if (choice >= 0)
                    MeasureChoice(fonts, cfg, width, height);
                if (color >= 0)
                    MeasureColor(fonts, cfg, width, height);
            }
        }
        if (contextOpen && !bigPreview)
            MeasureContext(fonts, cfg, width, height);
        if (bigPreview && shownEditor >= 0) {
            MeasureBigPreview(fonts, cfg);
            if (stickerSlot >= 0 && StickerCapable(cfg))
                MeasureBigPicker(fonts, cfg, width, height);
            if (optionsOpen && optionsAnchor.w > 0) {
                MeasureOptions(fonts, cfg, width, height);
                if (choice >= 0)
                    MeasureChoice(fonts, cfg, width, height);
                if (color >= 0)
                    MeasureColor(fonts, cfg, width, height);
            }
            if (drop == 3)
                MeasureCapsuleList(fonts, width, height);
            if (contextOpen)
                MeasureContext(fonts, cfg, width, height);
        }
        if (modelDrag && (!nativeItemPreview || PopupOpen()))
            CancelInput();

        if (!blocked)
            for (auto& entry : transitions)
                if (!drawnWindows.count(entry.first) && entry.second.motion.value > .001f) {
                    const auto b = paint.layers.size();
                    paint.layers.insert(paint.layers.end(), entry.second.cached.begin(),
                                        entry.second.cached.end());
                    FadeLayers(b, entry.second.motion.value);
                }
        MeasureTooltip(fonts, cfg, width, height);
    }

    void ActivateRow(Settings& cfg, int o) {
        if (o < 0 || o >= OptCount)
            return;
        const auto it = CurrentItem(cfg);
        if (!OptEnabled(o, it))
            return;
        switch (OptSpecs[std::size_t(o)].type) {
        case TypeText:
            if (!nameEditing)
                BeginName(cfg);
            break;
        case TypeColor:
            if (o == OptColors)
                OpenColor(o, 0);
            else
                OpenColor(o);
            break;
        case TypeChoice:
            color = -1;
            choice = choice == o ? -1 : o;
            break;
        case TypeNumber:
            if (!valueEditing)
                BeginValue(cfg);
            break;
        case TypeToggle:
        case TypeToggleColor:
            Toggle(cfg, o);
            break;
        default:
            break;
        }
    }
    void Activate(const Hit& h, Settings& cfg) {
        switch (h.action) {
        case Surface:
            if (contextOpen) {
                contextOpen = false;
                contextCard = contextSlot = -1;
            } else if (choice >= 0)
                choice = -1;
            else if (drop >= 0)
                drop = -1;
            else if (optionsOpen) {
                optionsOpen = false;
                nameEditing = valueEditing = false;
            }
            break;
        case Team:
            if (h.option != team) {
                modelDrag = false;
                stickerMoveSlot = -1;
                team = std::clamp(h.option, 0, 1);
                entriesKey.clear();
            }
            break;
        case Card:
            OpenEditor(h.option);
            break;
        case CloseButton:
            CloseEditor();
            break;
        case Paint:
            SelectEntry(cfg, h.option);
            break;
        case WeaponDrop:
            drop = drop == 0 ? -1 : 0;
            dropScroll = 0;
            break;
        case SortDrop:
            drop = drop == 1 ? -1 : 1;
            break;
        case CapsuleDrop:
            drop = drop == 3 ? -1 : 3;
            dropScroll = 0;
            break;
        case CapsuleOption:
            capsule = h.option;
            drop = -1;
            gridScroll = gridTarget = 0;
            entriesKey.clear();
            break;
        case ModelChip:
            drop = drop == 2 ? -1 : 2;
            dropScroll = 0;
            break;
        case WeaponOption:
        case ModelOption:
            ChooseWeapon(cfg, h.option);
            drop = -1;
            break;
        case SortOption:
            sort = std::clamp(h.option, 0, 2);
            drop = -1;
            entriesKey.clear();
            break;
        case ToolOptions:
            optionsOpen = !optionsOpen;
            choice = color = -1;
            nameEditing = valueEditing = false;
            optionsScroll = 0;
            drop = -1;
            break;
        case ToolCamera:
            cameraZoom = !cameraZoom;
            break;
        case ToolBig:
            ClosePopups();
            bigPreview = true;
            searchFocus = false;
            hoverTime = 0;
            tooltipStored = false;
            break;
        case BigClose:
        case BigBackdrop:
            bigPreview = false;
            ClosePopups();
            CancelInput();
            break;
        case ToolBoth:
            EditItem(cfg, [](InventoryItem& it) { it.bothTeams = !it.bothTeams; });
            break;
        case OptRow:
            ActivateRow(cfg, h.field);
            break;
        case OptValue:
            if (h.field == OptStatTrakValue) {
                if (!valueEditing)
                    BeginValue(cfg);
            } else
                OpenColor(h.field, h.option);
            break;
        case OptOption:
            SetChoice(cfg, h.field, h.option);
            choice = -1;
            break;
        case ContextItem: {
            const int code = h.option;
            if (contextCard >= 0) {
                if (code == 0)
                    Copy(cfg, contextCard);
                else if (code == 1)
                    Paste(cfg, contextCard);
                else if (code == 4)
                    Delete(cfg, contextCard);
            } else if (contextSlot >= 0)
                SlotAction(cfg, contextSlot, code);
            contextOpen = false;
            contextCard = contextSlot = -1;
            break;
        }
        case MoveMode:
            moveMode = std::clamp(h.option, 0, 1);
            break;
        case Slot:
            if (h.option >= 0 && h.option < 5)
                stickerMoveSlot = h.option;
            stickerSlot = stickerSlot == h.option ? -1 : h.option;
            search.clear();
            searchEdit.Reset(search);
            searchFocus = false;
            gridScroll = gridTarget = 0;
            entriesKey.clear();
            optionsOpen = false;
            choice = color = -1;
            drop = -1;
            break;
        case StickerFilter:
            hideTournament = !hideTournament;
            entriesKey.clear();
            break;

        case CharmRandom:
            EditItem(cfg, [&](InventoryItem& it) {
                if (it.charm.id)
                    it.charm.pattern = int(NextRandom() % 100001u);
            });
            break;
        default:
            break;
        }
    }
    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl = false) {
        (void)ctrl;
        if (!visible || blocked)
            return false;
        mouseX = x;
        mouseY = y;
        if (color >= 0) {
            auto c = PickerSettings(cfg);
            const bool used = picker.Click(x, y, down, c);
            SyncPicker(cfg, c);
            if (!used && down) {
                color = -1;
                CancelInput();
            }
            return true;
        }
        const int n = HitAt(x, y);
        if (down) {
            if (n < 0) {
                CommitEdits(cfg);
                searchFocus = false;
                return false;
            }
            const auto h = hits[std::size_t(n)];
            if (nameEditing && h.action != OptName)
                CommitName(cfg);
            if (valueEditing && !(h.action == OptValue && h.field == OptStatTrakValue))
                CommitValue(cfg);
            if (searchFocus && h.action != SearchBox)
                searchFocus = false;
            held = h.Key();
            if (h.action == SearchBox) {
                searchFocus = true;
                searchEdit.Sync(search);
                searchEdit.Mouse(x - searchTextX, false);
                return true;
            }
            if (h.action == OptName) {
                if (!nameEditing)
                    BeginName(cfg, false);
                nameEdit.Mouse(x - nameTextX, false);
                return true;
            }
            if (h.action == OptSlider) {
                if (OptEnabled(h.field, CurrentItem(cfg))) {
                    drag = h.field;
                    Move(x, y, cfg);
                }
                return true;
            }
            if (h.action == ModelDrag) {
                if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(scale) || scale <= 0) {
                    CancelInput();
                    return true;
                }
                modelDrag = true;
                modelLastX = x;
                modelLastY = y;
                charmDrag = stickerDrag = false;
                if (moveMode == 0 && nativeItemPreview && shownEditor >= 0 && editor == shownEditor &&
                    team >= 0 && team <= 1 && EditorKind() == KindWeapon) {
                    const auto it = CurrentItem(cfg);
                    if (it.charm.id > 0 && std::isfinite(it.charm.x) && std::isfinite(it.charm.y) &&
                        std::isfinite(it.charm.z)) {
                        charmDrag = true;
                        charmDragOriginal = charmDragPreview = it.charm;
                        charmDragTeam = team;
                        charmDragEditor = shownEditor;
                        charmDragWeapon = it.index;
                        charmDragPaint = it.paintKit;
                    }
                }
                if (moveMode == 1 && nativeItemPreview && shownEditor >= 0 && editor == shownEditor &&
                    team >= 0 && team <= 1 && EditorKind() == KindWeapon && stickerMoveSlot >= 0 &&
                    stickerMoveSlot < 5) {
                    const auto it = CurrentItem(cfg);
                    const auto st = it.stickers[std::size_t(stickerMoveSlot)];
                    if (st.id > 0 && std::isfinite(st.x) && std::isfinite(st.y) &&
                        std::isfinite(st.rotation)) {
                        stickerDrag = true;
                        stickerDragOriginal = stickerDragPreview = st;
                        stickerDragSlot = stickerMoveSlot;
                        stickerDragTeam = team;
                        stickerDragEditor = shownEditor;
                        stickerDragWeapon = it.index;
                        stickerDragPaint = it.paintKit;
                    }
                }
                return true;
            }
            if (h.action == GridThumb) {
                thumbDrag = true;
                thumbGrab = y - gridThumb.y;
                return true;
            }
            return true;
        }
        const bool used = held >= 0 || drag >= 0 || thumbDrag || modelDrag;
        if (charmDrag) {
            if (std::isfinite(x) && std::isfinite(y) && CharmDragCurrent(cfg)) {
                Move(x, y, cfg);
                if (CharmDragCurrent(cfg) && !(charmDragPreview == charmDragOriginal)) {
                    const auto pending = charmDragPreview;
                    EditItem(cfg, [&](InventoryItem& it) {
                        it.charm.x = pending.x;
                        it.charm.z = pending.z;
                    });
                }
            }
        } else if (stickerDrag) {
            if (std::isfinite(x) && std::isfinite(y) && StickerDragCurrent(cfg)) {
                Move(x, y, cfg);
                if (StickerDragCurrent(cfg) && !(stickerDragPreview == stickerDragOriginal)) {
                    const auto pending = stickerDragPreview;
                    const int slot = stickerDragSlot;
                    EditItem(cfg, [&](InventoryItem& it) { it.stickers[std::size_t(slot)] = pending; });
                }
            }
        } else if (n >= 0 && held == hits[std::size_t(n)].Key() && drag < 0 && !thumbDrag && !modelDrag)
            Activate(hits[std::size_t(n)], cfg);
        CancelInput();
        return used;
    }
    void Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        if (!visible || blocked)
            return;
        if (modelDrag) {
            if (!nativeItemPreview || PopupOpen() || !std::isfinite(x) || !std::isfinite(y) ||
                !std::isfinite(scale) || !(scale > 0)) {
                CancelInput();
                return;
            }
            const float dx = x - modelLastX, dy = y - modelLastY;
            if (std::abs(dx) > 10000 || std::abs(dy) > 10000) {
                CancelInput();
                return;
            }

            if (charmDrag) {
                if (!CharmDragCurrent(cfg)) {
                    CancelInput();
                    return;
                }

                const auto surface =
                    bigPreview
                        ? InventoryBigItemDisplaySurface(previewBox, itemSourceBox, scale, nativeItemMusic)
                        : InventoryItemDisplaySurface(previewBox, scale, nativeItemMusic);
                if (!InventoryPreviewBoxValid(surface)) {
                    CancelInput();
                    return;
                }
                charmDragPreview.x = std::clamp(charmDragPreview.x - 20.f * dx / surface.w, -25.f, 25.f);
                charmDragPreview.z = std::clamp(charmDragPreview.z - 20.f * dy / surface.h, -25.f, 25.f);
            } else if (stickerDrag) {
                if (!StickerDragCurrent(cfg)) {
                    CancelInput();
                    return;
                }
                const auto surface =
                    bigPreview
                        ? InventoryBigItemDisplaySurface(previewBox, itemSourceBox, scale, nativeItemMusic)
                        : InventoryItemDisplaySurface(previewBox, scale, nativeItemMusic);
                if (!InventoryPreviewBoxValid(surface)) {
                    CancelInput();
                    return;
                }

                stickerDragPreview.x = std::clamp(stickerDragPreview.x + dx / surface.w, -10.f, 10.f);
                stickerDragPreview.y = std::clamp(stickerDragPreview.y + dy / surface.h, -10.f, 10.f);
            } else if (EditorKind() == KindGloves) {
            } else if (EditorKind() == KindMedal || EditorKind() == KindMusic) {
                modelYaw = std::clamp(modelYaw + dx * .65f / scale, -25.f, 25.f);
                modelPitch = std::clamp(modelPitch - dy * .65f / scale, -20.f, 20.f);
            } else {
                modelYaw = std::remainder(modelYaw + dx * .65f / scale, 360.f);
                modelPitch = std::clamp(modelPitch - dy * .65f / scale, -85.f, 85.f);
            }
            modelLastX = x;
            modelLastY = y;
        }
        if (drag >= 0) {
            if (!optionsOpen || !OptEnabled(drag, CurrentItem(cfg))) {
                CancelInput();
                return;
            }
            const Box b = optSliders[std::size_t(drag)];
            if (b.w > 0) {
                const float v = (x - b.x) / std::max(1.f, b.w);
                if (drag == OptWearValue)
                    SetWearAt(cfg, v);
                else
                    SetSlider(cfg, drag, v);
            }
        }
        if (thumbDrag && gridMax > 0) {
            const float track = gridTrack.h - gridThumb.h;
            if (track > 0)
                gridScroll = gridTarget =
                    std::clamp((y - thumbGrab - gridTrack.y) / track * gridMax, 0.f, gridMax);
        }
        if (color >= 0) {
            auto c = PickerSettings(cfg);
            if (picker.Move(x, y, c))
                SyncPicker(cfg, c);
        }
        if (held >= 0 && nameEditing && (held >> 40) == OptName)
            nameEdit.Mouse(x - nameTextX, true);
        if (held >= 0 && searchFocus && (held >> 40) == SearchBox)
            searchEdit.Mouse(x - searchTextX, true);
    }
    bool Context(float x, float y, Settings& cfg) {
        if (!visible || blocked)
            return false;
        mouseX = x;
        mouseY = y;
        CommitEdits(cfg);
        if (contextOpen) {
            contextOpen = false;
            contextCard = contextSlot = -1;
            return true;
        }
        const int n = HitAt(x, y);
        if (n < 0)
            return Active();
        const auto h = hits[std::size_t(n)];
        if (h.action == Card && editor < 0) {
            ClosePopups();
            contextOpen = true;
            contextCard = h.option;
            contextSlot = -1;
            contextPoint = {x, y, 0, 0};
            return true;
        }
        if (h.action == Slot && editor >= 0) {
            drop = -1;
            optionsOpen = false;
            choice = color = -1;
            contextOpen = true;
            contextSlot = h.option;
            contextCard = -1;
            contextPoint = {x, y, 0, 0};
            return true;
        }
        return true;
    }
    bool Key(int key, Settings& cfg, bool shift = false, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        if (modelDrag && key == 27) {
            CancelInput();
            return true;
        }
        if (color >= 0) {
            auto c = PickerSettings(cfg);
            if (picker.Key(key, c, ctrl))
                SyncPicker(cfg, c);
            else if (key == 27) {
                color = -1;
                CancelInput();
            }
            return true;
        }
        if (nameEditing) {
            if (key == 27)
                nameEditing = false;
            else if (key == 13)
                CommitName(cfg);
            else if (key == 8 || key == 46)
                nameEdit.Delete(nameText, key == 8, ctrl);
            else if (ctrl && key == 'A')
                nameEdit.All(nameText);
            else if (ctrl && (key == 'Z' || key == 'Y'))
                nameEdit.History(nameText, key == 'Y');
            else if (key == 37 || key == 39)
                nameEdit.Move(nameText, key == 37 ? -1 : 1, shift, ctrl);
            else if (key == 36 || key == 35)
                nameEdit.Home(nameText, key == 35, shift);
            return true;
        }
        if (valueEditing) {
            if (key == 27) {
                valueEditing = false;
                numeric.clear();
            } else if (key == 13)
                CommitValue(cfg);
            else if (ctrl && key == 'A')
                selectAll = true;
            else if (key == 8 || key == 46) {
                if (selectAll)
                    numeric.clear();
                else if (!numeric.empty())
                    numeric.pop_back();
                selectAll = false;
            }
            return true;
        }
        if (searchFocus) {
            if (key == 27 || key == 13)
                searchFocus = false;
            else if (key == 8 || key == 46) {
                if (searchEdit.Delete(search, key == 8, ctrl))
                    gridScroll = gridTarget = 0;
            } else if (ctrl && key == 'A')
                searchEdit.All(search);
            else if (ctrl && (key == 'Z' || key == 'Y')) {
                if (searchEdit.History(search, key == 'Y'))
                    gridScroll = gridTarget = 0;
            } else if (key == 37 || key == 39)
                searchEdit.Move(search, key == 37 ? -1 : 1, shift, ctrl);
            else if (key == 36 || key == 35)
                searchEdit.Home(search, key == 35, shift);
            return true;
        }
        if ((key == 219 || key == 221) && moveMode == 1 && shownEditor >= 0 && EditorKind() == KindWeapon &&
            !PopupOpen() && stickerMoveSlot >= 0 && stickerMoveSlot < 5) {
            const int slot = stickerMoveSlot;
            EditItem(cfg, [&](InventoryItem& it) {
                auto& st = it.stickers[std::size_t(slot)];
                if (st.id)
                    st.rotation = std::clamp(st.rotation + (key == 219 ? -5.f : 5.f), -360.f, 360.f);
            });
            return true;
        }
        if (key == 27 && bigPreview) {
            if (contextOpen) {
                contextOpen = false;
                contextCard = contextSlot = -1;
            } else if (choice >= 0)
                choice = -1;
            else if (drop >= 0)
                drop = -1;
            else if (optionsOpen)
                optionsOpen = false;
            else if (stickerSlot >= 0) {
                stickerSlot = -1;
                search.clear();
                searchEdit.Reset(search);
                entriesKey.clear();
            } else
                bigPreview = false;
            CancelInput();
            return true;
        }
        if (key == 27) {
            if (contextOpen) {
                contextOpen = false;
                contextCard = contextSlot = -1;
                return true;
            }
            if (choice >= 0) {
                choice = -1;
                return true;
            }
            if (drop >= 0) {
                drop = -1;
                return true;
            }
            if (optionsOpen) {
                optionsOpen = false;
                return true;
            }
            if (stickerSlot >= 0) {
                stickerSlot = -1;
                search.clear();
                searchEdit.Reset(search);
                entriesKey.clear();
                return true;
            }
            if (editor >= 0) {
                CloseEditor();
                return true;
            }
            return false;
        }
        return Active();
    }
    bool Character(char16_t c) {
        if (!visible || blocked)
            return false;
        if (color >= 0)
            return picker.Character(c);
        auto decode = [&](char32_t& cp) {
            if (c >= 0xd800 && c <= 0xdbff) {
                highSurrogate = c;
                return false;
            }
            cp = c;
            if (c >= 0xdc00 && c <= 0xdfff) {
                if (!highSurrogate)
                    return false;
                cp = 0x10000 + ((char32_t(highSurrogate) - 0xd800) << 10) + (char32_t(c) - 0xdc00);
            }
            highSurrogate = 0;
            return true;
        };
        if (nameEditing) {
            char32_t cp = 0;
            if (!decode(cp))
                return true;
            nameEdit.Sync(nameText);
            if (nameText.size() - (nameEdit.End() - nameEdit.Begin()) >= InventoryMaxName)
                return true;
            nameEdit.Insert(nameText, std::u32string(1, cp), InventoryMaxName * 4 + 1);
            return true;
        }
        if (valueEditing) {
            if (c >= '0' && c <= '9') {
                if (selectAll) {
                    numeric.clear();
                    selectAll = false;
                }
                if (numeric.size() < 10)
                    numeric += char(c);
            }
            return true;
        }
        if (searchFocus) {
            char32_t cp = 0;
            if (!decode(cp))
                return true;
            if (searchEdit.Insert(search, std::u32string(1, cp), 128))
                gridScroll = gridTarget = 0;
            return true;
        }
        return false;
    }
    bool Wheel(float delta, Settings&) {
        if (!visible || blocked)
            return false;
        const float s = scale;
        if (bigPreview) {
            if (contextOpen || choice >= 0 || color >= 0)
                return true;
            if (optionsOpen) {
                if (optionsBox.Contains(mouseX, mouseY))
                    optionsScroll = std::clamp(optionsScroll - delta * 30 * s, 0.f, optionsMax);
                return true;
            }
            if (drop == 3) {
                dropScroll = std::clamp(dropScroll - delta * 30 * s, 0.f, dropMax);
                return true;
            }
            if (stickerSlot >= 0 && gridBox.Contains(mouseX, mouseY) && gridMax > 0)
                gridTarget = std::clamp(gridTarget - delta * std::max(30 * s, gridPitch * .5f), 0.f, gridMax);
            return true;
        }
        if (color >= 0 || choice >= 0 || contextOpen || drop == 1)
            return true;
        if (drop == 0 || drop == 2 || drop == 3) {
            dropScroll = std::clamp(dropScroll - delta * 30 * s, 0.f, dropMax);
            return true;
        }
        if (optionsOpen) {
            if (optionsBox.Contains(mouseX, mouseY))
                optionsScroll = std::clamp(optionsScroll - delta * 30 * s, 0.f, optionsMax);
            return true;
        }
        if (editor >= 0) {
            if (gridMax > 0)
                gridTarget = std::clamp(gridTarget - delta * std::max(30 * s, gridPitch * .5f), 0.f, gridMax);
            return true;
        }
        if (pageMax > 0 && pageBody.Contains(mouseX, mouseY)) {
            pageScroll = std::clamp(pageScroll - delta * 30 * s, 0.f, pageMax);
            return true;
        }
        return false;
    }
    float BackgroundMix() const {
        return teamBackground.initialized ? teamBackground.value : (team == InventoryT ? 1.f : 0.f);
    }
    void Tick(float dt, const Settings&) {
        dt = std::max(0.f, dt);
        if (!visible)
            return;
        teamBackground.Tick(team == InventoryT ? 1.f : 0.f, dt);
        const int h = HitAt(mouseX, mouseY);
        const std::int64_t key = h < 0 ? -1 : hits[std::size_t(h)].Key();
        if (key != hover) {
            hover = key;
            hoverTime = 0;
        } else
            hoverTime += dt;
        if (hoverMotion.size() > 1024) {
            std::map<std::int64_t, PresetMotion> keep;
            for (const auto& t : hits) {
                auto it = hoverMotion.find(t.Key());
                if (it != hoverMotion.end())
                    keep.insert(*it);
            }
            hoverMotion.swap(keep);
        }
        for (const auto& t : hits)
            hoverMotion.try_emplace(t.Key());
        for (auto& kv : hoverMotion) {
            const auto action = Action(kv.first >> 40);
            const float over = (action == Card || action == Paint) ? .8f : .5f;
            kv.second.Tick(blocked ? 0.f : kv.first == held ? 1.f : kv.first == key ? over : 0.f, dt);
        }

        for (int t = 0; t < 2; ++t) {
            const std::int64_t k = Hit{{}, Team, -1, t}.Key();
            const bool selected = team == t;
            teamHover[std::size_t(t)].Tick(blocked     ? (selected ? .5f : 0.f)
                                           : k == held ? 1.f
                                           : k == key  ? .75f
                                           : selected  ? .5f
                                                       : 0.f,
                                           dt);
            teamExpand[std::size_t(t)].Tick(selected ? 1.f : 0.f, dt);
        }
        for (int m = 0; m < 2; ++m) {
            const auto k = Hit{{}, MoveMode, -1, m}.Key();
            moveExpand[std::size_t(m)].Tick(moveMode == m ? 1.f : 0.f, dt);
            const bool selected = moveMode == m;
            moveHover[std::size_t(m)].Tick(blocked     ? (selected ? .5f : 0.f)
                                           : k == held ? 1.f
                                           : k == key  ? .75f
                                           : selected  ? .5f
                                                       : 0.f,
                                           dt);
        }
        tooltipMotion.Tick(tipLive && !blocked && hoverTime >= .3f ? 1.f : 0.f, dt);
        if (color >= 0)
            picker.Tick(dt, !blocked);
        for (auto& w : transitions)
            w.second.motion.Tick(!blocked && TransitionActive(w.first) ? 1.f : 0.f, dt);

        if (std::abs(gridTarget - gridScroll) < .5f)
            gridScroll = gridTarget;
        else
            gridScroll += (gridTarget - gridScroll) * std::min(1.f, dt * 14.f);
    }
};
}
