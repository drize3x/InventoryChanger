#pragma once

#include "menu_core.h"
#include "inventory_apply.h"
#include "inventory_charm_attributes.h"
#include "inventory_decorations.h"
#include <array>
namespace menu::knife_skin {
struct Attr {
    unsigned char pad[0x30]{};
    std::uint16_t id = 0, pad2 = 0;
    float value = 0, initial = 0;
    std::int32_t refund = 0;
    bool bonus = false;
    unsigned char tail[7]{};
};
static_assert(sizeof(Attr) == 0x48, "CEconItemAttribute ABI");
struct Vector {
    std::uint64_t count = 0;
    std::uintptr_t data = 0;
};
struct Adapter {
    virtual ~Adapter() = default;
    virtual bool Read(std::uintptr_t, void*, std::size_t) = 0;
    virtual bool Write(std::uintptr_t, const void*, std::size_t) = 0;
    template <class T> bool Get(std::uintptr_t p, T& v) {
        return Read(p, &v, sizeof v);
    }
    virtual std::uintptr_t Allocate(std::size_t) = 0;
    virtual bool Release(std::uintptr_t) = 0;
    virtual bool Ready(std::uintptr_t, std::uintptr_t) = 0;
    virtual bool Refresh(std::uintptr_t, std::uintptr_t) = 0;
};
class Controller {
    std::uintptr_t entity_ = 0, vector_ = 0, allocation_ = 0;
    std::array<Attr, 43> expected_{};
    std::size_t count_ = 0;
    bool refreshed_ = false, uncertain_ = false;

public:
    int Apply(Adapter& a, std::uintptr_t entity, std::uintptr_t view, std::uint32_t listOffset,
              std::uint32_t attrOffset, const InventoryWeaponTarget& t,
              const charm::Values* decoration = nullptr,
              const local_decorations::Values* stickers = nullptr) {
        if (uncertain_)
            return 4;
        if (entity_ == entity && allocation_) {
            Vector cur{};
            std::array<Attr, 43> data{};
            if (view + listOffset + attrOffset != vector_ || !a.Get(vector_, cur) || cur.count != count_ ||
                cur.data != allocation_ || !a.Read(allocation_, data.data(), count_ * sizeof(Attr)) ||
                std::memcmp(data.data(), expected_.data(), count_ * sizeof(Attr)) != 0) {
                uncertain_ = true;
                return 4;
            }
            if (refreshed_)
                return 0;
            if (a.Ready(entity, view) && a.Refresh(entity, view)) {
                refreshed_ = true;
                return 0;
            }
            return 3;
        }
        if (entity_ || !entity || !view || !listOffset || !attrOffset || t.paintKit <= 0 || t.seed < 0 ||
            !std::isfinite(t.wear) || t.wear < 0 || t.wear > 1 || !a.Ready(entity, view))
            return 1;
        const auto vec = view + listOffset + attrOffset;
        Vector old;
        if (!a.Get(vec, old))
            return 1;
        if (old.count || old.data)
            return 2;
        if (decoration && (!charm::Valid(*decoration) || decoration->id <= 0))
            return 1;
        if (stickers && (!local_decorations::Valid(*stickers) || stickers->charm.id))
            return 1;
        std::array<Attr, 43> attrs{};
        attrs[0].id = 6;
        attrs[0].value = attrs[0].initial = float(t.paintKit);
        attrs[1].id = 7;
        attrs[1].value = attrs[1].initial = float(t.seed);
        attrs[2].id = 8;
        attrs[2].value = attrs[2].initial = t.wear;
        std::size_t count = 3;
        if (decoration) {
            const std::uint16_t ids[] = {299, 306, 300, 301, 302};
            const float vals[] = {charm::IntBits(std::uint32_t(decoration->id)),
                                  charm::IntBits(std::uint32_t(decoration->seed)), decoration->x,
                                  decoration->y, decoration->z};
            for (int i = 0; i < 5; ++i) {
                attrs[count].id = ids[i];
                attrs[count].value = attrs[count].initial = vals[i];
                ++count;
            }
        }
        if (stickers) {

            local_decorations::ForEachAttribute(
                *stickers,
                [&](int id, int value) {
                    attrs[count].id = std::uint16_t(id);
                    attrs[count].value = attrs[count].initial = local_decorations::Bits(std::uint32_t(value));
                    ++count;
                },
                [&](int id, float value) {
                    attrs[count].id = std::uint16_t(id);
                    attrs[count].value = attrs[count].initial = value;
                    ++count;
                });
        }
        auto mem = a.Allocate(count * sizeof(Attr));
        if (!mem)
            return 1;
        if (!a.Write(mem, attrs.data(), count * sizeof(Attr))) {
            a.Release(mem);
            return 1;
        }
        Vector again;
        if (!a.Get(vec, again) || again.count || again.data) {
            a.Release(mem);
            return 2;
        }
        Vector nv{count, mem};
        const bool wrote = a.Write(vec, &nv, sizeof nv);
        Vector check{};
        const bool read = a.Get(vec, check);
        if (!read || check.count != nv.count || check.data != nv.data) {
            if (read && !check.count && !check.data) {
                a.Release(mem);
                return 1;
            }
            uncertain_ = true;
            return 4;
        }
        entity_ = entity;
        vector_ = vec;
        allocation_ = mem;
        expected_ = attrs;
        count_ = count;
        if (!wrote)
            return 3;
        if (!a.Refresh(entity, view))
            return 3;
        refreshed_ = true;
        return 0;
    }

    // Rebuild only the material; retain our verified attribute allocation and model.
    bool RefreshOwned(Adapter& a, std::uintptr_t entity, std::uintptr_t view) {
        if (uncertain_ || !entity_ || entity_ != entity || !vector_ || !allocation_)
            return false;
        Vector cur{};
        std::array<Attr, 43> data{};
        if (!a.Get(vector_, cur) || cur.count != count_ || cur.data != allocation_ ||
            !a.Read(allocation_, data.data(), count_ * sizeof(Attr)) ||
            std::memcmp(data.data(), expected_.data(), count_ * sizeof(Attr)) != 0) {
            uncertain_ = true;
            return false;
        }
        if (!a.Ready(entity, view))
            return false;
        return a.Refresh(entity, view);
    }

    bool Restore(Adapter& a, std::uintptr_t entity, std::uintptr_t view) {
        if (uncertain_)
            return false;
        if (!entity_)
            return true;
        if (entity != entity_)
            return false;
        Vector cur{};
        std::array<Attr, 43> data{};
        if (!a.Get(vector_, cur) || cur.count != count_ || cur.data != allocation_ ||
            !a.Read(allocation_, data.data(), count_ * sizeof(Attr)) ||
            std::memcmp(data.data(), expected_.data(), count_ * sizeof(Attr)) != 0)
            return false;
        Vector empty{};
        if (!a.Write(vector_, &empty, sizeof empty))
            return false;
        Vector check{};
        if (!a.Get(vector_, check) || check.count || check.data) {
            uncertain_ = true;
            return false;
        }
        const auto ptr = allocation_;
        entity_ = vector_ = allocation_ = 0;
        count_ = 0;
        refreshed_ = false;
        return a.Release(ptr);
    }

    void Forget() {
        entity_ = vector_ = allocation_ = 0;
        count_ = 0;
        refreshed_ = false;
        uncertain_ = false;
    }
};
}
