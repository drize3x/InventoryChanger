#pragma once

#include "menu_core.h"
#include <cmath>
namespace menu {
struct InventoryBackgroundColors {
    Color left, right;
};
inline InventoryBackgroundColors InventoryBackground(float teamMix, float pageAlpha) {
    const float t = std::clamp(teamMix, 0.f, 1.f), a = std::clamp(pageAlpha, 0.f, 1.f);

    Color c{Canvas::Byte(.2099999934f + .4700000286f * t) / 255.f,
            Canvas::Byte(.5099999905f + .0699999928f * t) / 255.f,
            Canvas::Byte(.8000000119f - .5800000429f * t) / 255.f, 1};
    Color d = c;
    c.a = std::floor(255.f * .05f * a * a) / 255.f;
    d.a = std::floor(255.f * .15f * a * a) / 255.f;
    return {c, d};
}
inline void PaintInventoryBackground(Canvas& out, Box box, float radius, InventoryBackgroundColors colors) {
    if (box.w <= 0 || box.h <= 0)
        return;
    const float r = std::clamp(radius, 0.f, std::min(box.w, box.h) * .5f);
    const int x0 = std::max(0, int(std::floor(box.x))), y0 = std::max(0, int(std::floor(box.y)));
    const int x1 = std::min(out.width, int(std::ceil(box.x + box.w))),
              y1 = std::min(out.height, int(std::ceil(box.y + box.h)));
    const float corner = r / .4f;
    for (int y = y0; y < y1; ++y) {
        const bool middleY = y + .5f >= box.y + corner + .5f && y + .5f <= box.y + box.h - corner - .5f;
        for (int x = x0; x < x1; ++x) {
            Color c = Mix(colors.left, colors.right, std::clamp((x + .5f - box.x) / box.w, 0.f, 1.f));
            const bool middleX = x + .5f >= box.x + corner + .5f && x + .5f <= box.x + box.w - corner - .5f;
            const bool innerX = x + .5f >= box.x + .5f && x + .5f <= box.x + box.w - .5f;
            const bool innerY = y + .5f >= box.y + .5f && y + .5f <= box.y + box.h - .5f;
            float coverage = ((middleX && innerY) || (middleY && innerX))
                                 ? 1.f
                                 : std::clamp(.5f - BoxDistance(box, r, x + .5f, y + .5f, 1), 0.f, 1.f);
            if (coverage > 0)
                out.Blend(x, y, c, coverage);
        }
    }
}
}
