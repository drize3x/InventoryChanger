#pragma once

#include <windows.h>
#include <array>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <limits>
#include "inventory_premier_scene_capture.h"
namespace menu {
class PremierDrawTrace {
public:
    struct MaterialSample {
        std::uintptr_t material = 0;
        unsigned long long hits = 0;
        std::array<char, 192> name{};
    };

private:
    std::atomic<std::uintptr_t> scene_{0};
    std::atomic<std::uint32_t> owner_{0xffffffffu};
    std::atomic<ULONGLONG> until_{0}, fixUntil_{0};
    std::atomic<unsigned long long> generation_{0}, calls_{0}, scanned_{0}, matched_{0}, truncated_{0},
        readFail_{0};
    struct PathCounters {
        std::atomic<unsigned long long> calls{0}, scanned{0}, matched{0}, ownerCandidate{0}, truncated{0},
            failed{0};
        std::atomic<std::uintptr_t> descriptorVt{0}, sceneVt{0}, scene{0}, material{0};
    };
    std::array<PathCounters, 4> paths_{};
    mutable std::mutex mu_;
    premier_scene_capture::Snapshot snap_{};
    std::array<premier_scene_capture::Snapshot, 4> pathSnap_{};
    std::atomic<unsigned long long> fixResets_{0};
    std::atomic<unsigned> groupSamples_{0}, groupTargetFirst_{0}, groupOtherFirst_{0}, groupFailures_{0};
    std::array<MaterialSample, 24> genericMaterials_{};
    unsigned genericMaterialCount_ = 0;
    std::uintptr_t extra_ = 0;
    std::uint16_t flags_ = 0;
    std::array<std::uintptr_t, 16> materials_{};
    unsigned materialCount_ = 0;
    static bool Read(std::uintptr_t p, void* out, std::size_t n) {
        SIZE_T k = 0;
        return p && ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<LPCVOID>(p), out, n, &k) &&
               k == n;
    }

    static void ReadName(std::uintptr_t material, std::array<char, 192>& out) {
        std::uintptr_t name = 0;
        if (!material || material > UINTPTR_MAX - 16 || !Read(material + 16, &name, sizeof name) || !name)
            return;
        for (std::size_t i = 0; i + 1 < out.size(); ++i) {
            char c = 0;
            if (name > UINTPTR_MAX - i || !Read(name + i, &c, 1))
                return;
            if (!c)
                return;
            out[i] = (c >= 33 && c <= 126 && c != '|') ? c : '_';
        }
    }
    void NoteGroup(std::uintptr_t base, int index, const unsigned char* primitive, std::uintptr_t target) {

        if (groupSamples_.load(std::memory_order_relaxed) >= 256)
            return;
        groupSamples_.fetch_add(1, std::memory_order_relaxed);
        auto key = [&](const unsigned char* p, std::uint32_t& mesh, std::uintptr_t& material) {
            std::uintptr_t ptr = 0;
            std::memcpy(&ptr, p + 8, 8);
            std::memcpy(&material, p + 0x20, 8);
            return ptr && ptr <= UINTPTR_MAX - 0x64 && Read(ptr + 0x64, &mesh, 4);
        };
        std::uint32_t mk = 0;
        std::uintptr_t mat = 0, first = target;
        if (!key(primitive, mk, mat)) {
            ++groupFailures_;
            return;
        }
        std::array<unsigned char, 0x70> p{};
        for (int at = index - 1; at >= 0; --at) {
            auto off = std::uintptr_t(at) * 0x70;
            if (base > UINTPTR_MAX - off || !Read(base + off, p.data(), p.size())) {
                ++groupFailures_;
                return;
            }
            std::uint32_t prevKey = 0;
            std::uintptr_t prevMat = 0;
            if (!key(p.data(), prevKey, prevMat)) {
                ++groupFailures_;
                return;
            }
            if (prevKey != mk || prevMat != mat)
                break;
            std::memcpy(&first, p.data() + 0x18, 8);
        }
        if (first == target)
            ++groupTargetFirst_;
        else
            ++groupOtherFirst_;
    }
    void NoteGenericMaterial(std::uintptr_t p) {
        if (!p)
            return;
        for (unsigned i = 0; i < genericMaterialCount_; ++i)
            if (genericMaterials_[i].material == p) {
                ++genericMaterials_[i].hits;
                return;
            }
        if (genericMaterialCount_ == genericMaterials_.size())
            return;
        auto& m = genericMaterials_[genericMaterialCount_++];
        m.material = p;
        m.hits = 1;
        ReadName(p, m.name);
    }

public:
    static PremierDrawTrace& Instance() {
        static PremierDrawTrace t;
        return t;
    }
    void Clear() {
        fixUntil_.store(0, std::memory_order_release);
        scene_.store(0, std::memory_order_release);
        owner_.store(0xffffffffu, std::memory_order_release);
        generation_.fetch_add(1, std::memory_order_acq_rel);
    }
    void Arm(std::uint32_t owner = 0xffffffffu) {
        Clear();
        std::lock_guard<std::mutex> l(mu_);
        snap_ = {};
        pathSnap_ = {};
        genericMaterials_ = {};
        genericMaterialCount_ = 0;
        groupSamples_ = 0;
        groupTargetFirst_ = 0;
        groupOtherFirst_ = 0;
        groupFailures_ = 0;
        fixResets_ = 0;
        extra_ = 0;
        flags_ = 0;
        materials_ = {};
        materialCount_ = 0;
        calls_ = 0;
        scanned_ = 0;
        matched_ = 0;
        truncated_ = 0;
        readFail_ = 0;
        for (auto& p : paths_) {
            p.calls = 0;
            p.scanned = 0;
            p.matched = 0;
            p.ownerCandidate = 0;
            p.truncated = 0;
            p.failed = 0;
            p.descriptorVt = 0;
            p.sceneVt = 0;
            p.scene = 0;
            p.material = 0;
        }
        until_ = GetTickCount64() + 2500;
        owner_.store(owner, std::memory_order_release);
    }
    void Publish(std::uintptr_t scene) {
        if (scene && GetTickCount64() <= until_.load(std::memory_order_acquire))
            scene_.store(scene, std::memory_order_release);
    }
    void NoteFixReset() {
        fixResets_.fetch_add(1, std::memory_order_relaxed);
    }
    unsigned long long FixResets() const {
        return fixResets_.load(std::memory_order_relaxed);
    }
    void RefreshFix(std::uint32_t handle) {
        if (handle != 0xffffffffu && owner_.load(std::memory_order_acquire) == handle &&
            scene_.load(std::memory_order_acquire))
            fixUntil_.store(GetTickCount64() + 300, std::memory_order_release);
    }
    bool FixTarget(std::uintptr_t& scene, std::uint32_t& owner) const {
        const auto until = fixUntil_.load(std::memory_order_acquire);
        if (!until || GetTickCount64() > until)
            return false;
        scene = scene_.load(std::memory_order_acquire);
        owner = owner_.load(std::memory_order_acquire);
        return scene && owner != 0xffffffffu;
    }
    void Observe(const void* data, int count, unsigned path = 0, void* descriptor = nullptr) noexcept {
        try {
            const auto target = scene_.load(std::memory_order_acquire);
            const auto owner = owner_.load(std::memory_order_acquire);
            const auto gen = generation_.load(std::memory_order_acquire);
            if (path >= paths_.size() || (!target && owner == 0xffffffffu) ||
                GetTickCount64() > until_.load(std::memory_order_acquire) || !data || count <= 0)
                return;
            auto& pc = paths_[path];
            if (pc.calls.fetch_add(1, std::memory_order_relaxed) >= 100000)
                return;
            if (path == 0)
                ++calls_;
            if (count > 512) {
                ++pc.truncated;
                if (path == 0)
                    ++truncated_;
                count = 512;
            }
            std::array<unsigned char, 0x70 * 32> buffer{};
            auto base = reinterpret_cast<std::uintptr_t>(data);
            for (int i = 0; i < count; i += 32) {
                int n = (count - i < 32) ? count - i : 32;
                auto offset = std::uintptr_t(i) * 0x70;
                if (base > std::numeric_limits<std::uintptr_t>::max() - offset ||
                    !Read(base + offset, buffer.data(), std::size_t(n) * 0x70)) {
                    ++pc.failed;
                    if (path == 0)
                        ++readFail_;
                    return;
                }
                pc.scanned.fetch_add(n, std::memory_order_relaxed);
                if (path == 0)
                    scanned_.fetch_add(n, std::memory_order_relaxed);
                for (int j = 0; j < n; ++j) {
                    const auto* p = buffer.data() + j * 0x70;
                    std::uintptr_t object = 0;
                    std::memcpy(&object, p + 0x18, sizeof object);
                    const bool exact = target && object == target;
                    std::uint32_t h = 0xffffffffu;
                    const bool ownerMatch = !exact && owner != 0xffffffffu && object &&
                                            object <= std::numeric_limits<std::uintptr_t>::max() - 0xc0 &&
                                            Read(object + 0xc0, &h, sizeof h) && h == owner;
                    if (!exact && !ownerMatch)
                        continue;
                    if (generation_.load(std::memory_order_acquire) != gen)
                        return;
                    if (exact) {
                        ++pc.matched;
                        if (path == 0)
                            ++matched_;
                    } else
                        ++pc.ownerCandidate;
                    std::uintptr_t dvt = 0, svt = 0, pmat = 0;
                    Read(reinterpret_cast<std::uintptr_t>(descriptor), &dvt, sizeof dvt);
                    Read(object, &svt, sizeof svt);
                    std::memcpy(&pmat, p + 0x20, sizeof pmat);
                    pc.descriptorVt = dvt;
                    pc.sceneVt = svt;
                    pc.scene = object;
                    pc.material = pmat;
                    std::unique_lock<std::mutex> lock(mu_, std::try_to_lock);
                    if (!lock || generation_.load(std::memory_order_acquire) != gen)
                        continue;
                    if (path == 3 && exact) {
                        NoteGenericMaterial(pmat);
                        NoteGroup(base, i + j, p, target);
                    }
                    auto snapshot = premier_scene_capture::Read(
                        object, [](auto a, void* b, std::size_t s) { return Read(a, b, s); });
                    pathSnap_[path] = snapshot;
                    if (path != 0 || !exact)
                        continue;
                    std::memcpy(&extra_, p + 0x30, sizeof extra_);
                    std::memcpy(&flags_, p + 0x62, sizeof flags_);
                    bool seen = false;
                    for (unsigned k = 0; k < materialCount_; ++k)
                        if (materials_[k] == pmat)
                            seen = true;
                    if (!seen && materialCount_ < materials_.size())
                        materials_[materialCount_++] = pmat;
                    snap_ = snapshot;
                }
            }
        } catch (...) {
        }
    }
    struct PathSample {
        unsigned long long calls = 0, scanned = 0, matched = 0, ownerCandidate = 0, truncated = 0, failed = 0;
        std::uintptr_t descriptorVt = 0, sceneVt = 0, scene = 0, material = 0;
        premier_scene_capture::Snapshot snapshot{};
    };
    PathSample GetPath(unsigned i) const {
        PathSample s;
        if (i >= paths_.size())
            return s;
        const auto& p = paths_[i];
        s.calls = p.calls;
        s.scanned = p.scanned;
        s.matched = p.matched;
        s.ownerCandidate = p.ownerCandidate;
        s.truncated = p.truncated;
        s.failed = p.failed;
        s.descriptorVt = p.descriptorVt;
        s.sceneVt = p.sceneVt;
        s.scene = p.scene;
        s.material = p.material;
        std::lock_guard<std::mutex> lock(mu_);
        s.snapshot = pathSnap_[i];
        return s;
    }
    struct MaterialReport {
        std::array<MaterialSample, 24> materials{};
        unsigned count = 0, groupSamples = 0, targetFirst = 0, otherFirst = 0, failures = 0;
    };
    MaterialReport GetGenericMaterials() const {
        std::lock_guard<std::mutex> lock(mu_);
        MaterialReport r;
        r.materials = genericMaterials_;
        r.count = genericMaterialCount_;
        r.groupSamples = groupSamples_;
        r.targetFirst = groupTargetFirst_;
        r.otherFirst = groupOtherFirst_;
        r.failures = groupFailures_;
        return r;
    }
    struct Sample {
        unsigned long long calls = 0, scanned = 0, matched = 0, truncated = 0, readFail = 0;
        unsigned materials = 0;
        std::uintptr_t extra = 0;
        std::uint16_t flags = 0;
        premier_scene_capture::Snapshot snapshot{};
    };
    Sample Get() const {
        Sample o;
        o.calls = calls_;
        o.scanned = scanned_;
        o.matched = matched_;
        o.truncated = truncated_;
        o.readFail = readFail_;
        std::lock_guard<std::mutex> l(mu_);
        o.materials = materialCount_;
        o.extra = extra_;
        o.flags = flags_;
        o.snapshot = snap_;
        return o;
    }
};
}
