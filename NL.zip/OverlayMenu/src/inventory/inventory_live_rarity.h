#pragma once

#include <algorithm>
#include <cstdint>
#include <map>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>
namespace menu {
struct InventoryRarityKey {
    int definition = 0, paint = 0;
    bool operator<(const InventoryRarityKey& b) const {
        return definition != b.definition ? definition < b.definition : paint < b.paint;
    }
};
inline bool InventoryRarityKeyValid(InventoryRarityKey k) {
    return k.definition > 0 && k.definition < 65535 && k.paint > 0 && k.paint <= 65535;
}
class InventoryLiveRarityCache {
    struct Entry {
        int value = -1;
        std::uint64_t next = 0;
        bool inFlight = false;
    };
    mutable std::mutex mutex_;
    std::map<InventoryRarityKey, Entry> entries_;
    std::uint64_t revision_ = 0;

public:
    int Query(InventoryRarityKey k) {
        if (!InventoryRarityKeyValid(k))
            return -1;
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(k);
        if (it == entries_.end()) {
            if (entries_.size() >= 8192)
                return -1;
            it = entries_.emplace(k, Entry{}).first;
        }
        return it->second.value;
    }
    std::string Stats() const {
        std::lock_guard<std::mutex> lock(mutex_);
        unsigned ready = 0, pending = 0, retry = 0;
        for (const auto& e : entries_) {
            if (e.second.value >= 1)
                ++ready;
            else if (e.second.next)
                ++retry;
            else
                ++pending;
        }
        return "CS2 rarity: ready=" + std::to_string(ready) + " pending=" + std::to_string(pending) +
               " retry=" + std::to_string(retry);
    }
    std::uint64_t Revision() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return revision_;
    }
    std::vector<InventoryRarityKey> Plan(std::uint64_t now) {
        std::vector<InventoryRarityKey> out;
        std::lock_guard<std::mutex> lock(mutex_);
        for (auto& e : entries_)
            if (e.second.value < 0 && !e.second.inFlight && now >= e.second.next) {
                e.second.inFlight = true;
                out.push_back(e.first);
                if (out.size() == 16)
                    break;
            }
        return out;
    }
    void Complete(InventoryRarityKey k, int rarity, std::uint64_t now) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = entries_.find(k);
        if (it == entries_.end() || !it->second.inFlight)
            return;
        auto& e = it->second;
        e.inFlight = false;
        if (rarity >= 1 && rarity <= 7) {
            e.value = rarity;
            ++revision_;
        } else
            e.next = now + 5000;
    }
    void Cancel(const std::vector<InventoryRarityKey>& batch, std::uint64_t now) {
        for (auto k : batch)
            Complete(k, -1, now);
    }
};
inline InventoryLiveRarityCache& GameInventoryRarity() {
    static InventoryLiveRarityCache cache;
    return cache;
}
inline std::string InventoryRarityHost(std::uint64_t owner, std::uint64_t serial) {
    return "MenuStudioRarity_" + std::to_string(owner) + "_" + std::to_string(serial);
}
inline std::string InventoryRarityMarker(std::size_t index, int rarity) {
    return "rarity_" + std::to_string(index) + "_" +
           (rarity < 0 ? std::string("error") : std::to_string(rarity));
}
inline std::string BuildInventoryRarityScript(const std::string& host,
                                              const std::vector<InventoryRarityKey>& batch) {
    std::ostringstream s;
    s << "(function(){var h=null;try{var root=$.GetContextPanel();h=$.CreatePanel('Panel',root,'" << host
      << "');h.visible=false;h.hittest=false;h.hittestchildren=false;$.Schedule(3,function(){if(h&&h.IsValid("
         "))h.DeleteAsync(0);});var api=typeof InventoryAPI==='undefined'?null:InventoryAPI;";
    s << R"JS((function(){var jobs=[)JS";
    bool comma = false;
    for (auto k : batch) {
        if (!InventoryRarityKeyValid(k))
            continue;
        if (comma)
            s << ",";
        comma = true;
        s << "[" << k.definition << "," << k.paint << "]";
    }
    s << R"JS(];function rarity(d,p){if(!api||typeof api.GetFauxItemIDFromDefAndPaintIndex!=='function'||typeof api.GetItemRarity!=='function'||typeof api.GetItemDefinitionIndex!=='function')return -1;
 var id=api.GetFauxItemIDFromDefAndPaintIndex(d,p);if(typeof id!=='string'||!(/^[0-9]{1,20}$/).test(id)||id==='0'||api.GetItemDefinitionIndex(id)!==d)return -1;
 var r=api.GetItemRarity(id);return typeof r==='number'&&isFinite(r)&&Math.floor(r)===r&&r>=1&&r<=7?r:-1;}
 var ok=false;try{ok=rarity(4,38)===4&&rarity(40,624)===6;}catch(e){}
 jobs.forEach(function(j,i){var r=-1;try{if(ok)r=rarity(j[0],j[1]);}catch(e){}$.CreatePanel('Panel',h,'rarity_'+i+'_'+(r<0?'error':r));});})();
 }catch(e){}})();)JS";
    return s.str();
}
inline std::string BuildInventoryRarityRemove(const std::string& host) {
    return "(function(){var h=$.GetContextPanel().FindChildTraverse('" + host +
           "');if(h&&h.IsValid())h.DeleteAsync(0);})();";
}

class InventoryRarityBridge {
    std::uintptr_t root_ = 0;
    std::string host_;
    std::vector<InventoryRarityKey> batch_;
    std::uint64_t serial_ = 0, started_ = 0, next_ = 0;

public:
    void LostRoot(std::uint64_t now) {
        GameInventoryRarity().Cancel(batch_, now);
        batch_.clear();
        root_ = 0;
        host_.clear();
        started_ = 0;
    }
    template <class Run, class Find, class Read>
    bool Tick(std::uintptr_t root, std::uint64_t owner, std::uint64_t now, bool closing,
              std::uintptr_t panelVtable, Run&& run, Find&& find, Read&& read) {
        if (root != root_)
            LostRoot(now);
        root_ = root;
        if (!root)
            return true;
        if (closing) {
            if (!host_.empty() && !run(BuildInventoryRarityRemove(host_)))
                return false;
            LostRoot(now);
            return true;
        }
        if (!batch_.empty()) {
            std::uintptr_t h = 0, vt = 0;
            if (!find(root, host_.c_str(), h))
                return false;
            bool done = false;
            if (h && read(h, vt) && vt == panelVtable) {
                std::vector<int> values(batch_.size(), -2);
                done = true;
                for (std::size_t i = 0; i < batch_.size(); ++i) {
                    for (int r = -1; r <= 7; ++r) {
                        if (r == 0)
                            continue;
                        std::uintptr_t marker = 0;
                        auto id = InventoryRarityMarker(i, r);
                        if (!find(h, id.c_str(), marker))
                            return false;
                        if (marker) {
                            values[i] = r;
                            break;
                        }
                    }
                    if (values[i] == -2)
                        done = false;
                }
                if (done)
                    for (std::size_t i = 0; i < batch_.size(); ++i)
                        GameInventoryRarity().Complete(batch_[i], values[i], now);
            }
            if (done || (now >= started_ && now - started_ >= 2000)) {
                if (!done)
                    GameInventoryRarity().Cancel(batch_, now);
                if (!run(BuildInventoryRarityRemove(host_)))
                    return false;
                batch_.clear();
                host_.clear();
                next_ = now + 250;
            }
        }
        if (batch_.empty() && now >= next_) {
            batch_ = GameInventoryRarity().Plan(now);
            if (!batch_.empty()) {
                host_ = InventoryRarityHost(owner, ++serial_);
                started_ = now;
                if (!run(BuildInventoryRarityScript(host_, batch_))) {
                    GameInventoryRarity().Cancel(batch_, now);
                    batch_.clear();
                    host_.clear();
                    return false;
                }
            }
        }
        return true;
    }
};
}
