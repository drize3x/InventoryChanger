#pragma once
#include "inventory_art_catalog.h"
#include "inventory_artwork.h"
namespace menu {
enum class InventoryNamedArt { Agent, Medal, Music };
std::string InventoryNamedImage(const InventoryCatalog& cat, InventoryNamedArt kind, int id, int team);

const InventoryCollection* InventoryCollectionFor(const InventoryCatalog& cat, int index, int paint);

std::string InventoryItemArtworkPath(const InventoryCatalog& cat, int index, int paint);
void InventoryDemandImage(const std::string& path, std::uint64_t now);
void InventoryDemandItem(const InventoryCatalog& cat, int index, int paint, std::uint64_t now);

std::vector<std::string> InventoryStartupImagePaths(const InventoryCatalog& cat, const Settings& cfg);
struct InventoryStartupImagesStatus {
    std::size_t ready = 0, total = 0;
    std::string missing;
};
InventoryStartupImagesStatus InventoryCheckStartupImages(const std::vector<std::string>& paths,
                                                         std::uint64_t now);

void InventoryPrefetchBase(const InventoryCatalog& cat, std::uint64_t now);
void InventoryPrefetchLoadout(const InventoryCatalog& cat, const Settings& cfg, std::uint64_t now);
}
