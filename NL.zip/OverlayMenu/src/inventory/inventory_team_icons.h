#pragma once

#include "menu_core.h"
#include "svg_raster.h"
#include <memory>
#include <string>
namespace menu {

inline constexpr int InventoryTeamLogoHeight = 20;

inline const std::string& InventoryFallbackTeamSvg(int team) {
    static const std::string ct =
        "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\">"
        "<circle cx=\"50\" cy=\"50\" r=\"47\" fill=\"#0d1015\"/>"
        "<circle cx=\"50\" cy=\"50\" r=\"42\" fill=\"none\" stroke=\"#8b99aa\" stroke-width=\"4.5\"/>"
        "<polyline points=\"27,29 38,71 50,45 62,71 73,29\" fill=\"none\" stroke=\"#b6cade\" "
        "stroke-width=\"8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/>"
        "</svg>";
    static const std::string t = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\">"
                                 "<circle cx=\"50\" cy=\"50\" r=\"47\" fill=\"#c4ae7a\"/>"
                                 "<polygon points=\"50.0,22.5 52.9,31.0 61.9,31.1 54.8,36.5 57.3,45.1 "
                                 "50.0,40.0 42.7,45.1 45.2,36.5 38.1,31.1 47.1,31.0\" fill=\"#4a3a1c\"/>"
                                 "<g stroke=\"#4a3a1c\" stroke-width=\"5.5\" stroke-linecap=\"round\" "
                                 "fill=\"none\"><path d=\"M27 54 L70 84\"/><path d=\"M73 54 L30 84\"/></g>"
                                 "</svg>";
    return team == 0 ? ct : t;
}

inline std::shared_ptr<Canvas> InventoryCanvasFromBitmap(const svg::Bitmap& bm) {
    if (bm.width <= 0 || bm.height <= 0 ||
        bm.rgba.size() != std::size_t(bm.width) * std::size_t(bm.height) * 4)
        return nullptr;
    auto canvas = std::make_shared<Canvas>(bm.width, bm.height);
    canvas->rgba = bm.rgba;
    return canvas;
}

inline std::shared_ptr<const Canvas> InventoryTeamLogo(int team, const std::string& resource,
                                                       bool* fromGame = nullptr) {
    if (fromGame)
        *fromGame = false;
    svg::Bitmap bm;
    const std::string payload = svg::ExtractPayload(resource);
    if (!payload.empty() && svg::Render(payload, 0, InventoryTeamLogoHeight, bm) && !svg::IsBlank(bm)) {
        if (fromGame)
            *fromGame = true;
        return InventoryCanvasFromBitmap(bm);
    }
    if (!svg::Render(InventoryFallbackTeamSvg(team), 0, InventoryTeamLogoHeight, bm))
        return nullptr;
    return InventoryCanvasFromBitmap(bm);
}

inline std::shared_ptr<Canvas> InventoryResampleLogo(const Canvas& src, int size) {
    if (size <= 0 || src.width <= 0 || src.height <= 0)
        return nullptr;
    auto out = std::make_shared<Canvas>(size, size);
    auto texel = [&](int x, int y, int c) {
        x = std::clamp(x, 0, src.width - 1);
        y = std::clamp(y, 0, src.height - 1);
        return float(
            src.rgba[4 * (std::size_t(y) * std::size_t(src.width) + std::size_t(x)) + std::size_t(c)]);
    };
    for (int y = 0; y < size; ++y) {
        const float v = (float(y) + .5f) / float(size) * float(src.height) - .5f;
        const int y0 = int(std::floor(v));
        const float fy = v - float(y0);
        for (int x = 0; x < size; ++x) {
            const float u = (float(x) + .5f) / float(size) * float(src.width) - .5f;
            const int x0 = int(std::floor(u));
            const float fx = u - float(x0);
            for (int c = 0; c < 4; ++c) {
                const float top = texel(x0, y0, c) * (1 - fx) + texel(x0 + 1, y0, c) * fx,
                            bottom = texel(x0, y0 + 1, c) * (1 - fx) + texel(x0 + 1, y0 + 1, c) * fx;
                out->rgba[4 * (std::size_t(y) * std::size_t(size) + std::size_t(x)) + std::size_t(c)] =
                    Canvas::Byte((top * (1 - fy) + bottom * fy) / 255.f);
            }
        }
    }
    return out;
}

}
