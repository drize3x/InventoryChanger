#pragma once
#include "inventory_econ_path.h"
#include "ambience_image_cache.h"
#include "menu_core.h"
#include <chrono>
namespace menu {
using InventoryArtworkCache = AmbienceImageCache<const Canvas, InventoryEconPath, 256, 64>;
inline InventoryArtworkCache& GameInventoryArtwork() {
    static InventoryArtworkCache cache;
    return cache;
}
inline std::uint64_t InventoryArtworkClock() {
    return std::uint64_t(std::chrono::duration_cast<std::chrono::milliseconds>(
                             std::chrono::steady_clock::now().time_since_epoch())
                             .count());
}

inline Box InventoryRarityStrip(Box b, float scale) {
    const float h = std::min(b.h, 3.f * scale);
    return {b.x, b.y + b.h - h, b.w, h};
}

inline Box InventoryArtworkBox(Box b, int width, int height, float factor = .8f) {
    if (width <= 0 || height <= 0 || b.w <= 0 || b.h <= 0)
        return {};
    const float h = std::min(float(height), factor * std::min(b.w, b.h)),
                w = h * float(width) / float(height);
    return {std::trunc(b.x + (b.w - w) * .5f), std::trunc(b.y + (b.h - h) * .5f), w, h};
}
inline std::shared_ptr<const Canvas> InventoryArtworkRGBA(int w, int h,
                                                          const std::vector<unsigned char>& rgba) {
    if (w < 1 || h < 1 || w > 1024 || h > 1024 || rgba.size() != std::size_t(w) * std::size_t(h) * 4)
        return {};
    auto image = std::make_shared<Canvas>(w, h);
    for (std::size_t i = 0; i < rgba.size(); i += 4) {
        const unsigned a = rgba[i + 3];
        for (int c = 0; c < 3; ++c)
            image->rgba[i + c] = static_cast<unsigned char>((unsigned(rgba[i + c]) * a + 127) / 255);
        image->rgba[i + 3] = static_cast<unsigned char>(a);
    }
    return image;
}

inline std::shared_ptr<const Canvas> InventoryResizeArtwork(const Canvas& src, int w, int h) {
    if (w < 1 || h < 1 || w > 2048 || h > 2048 || src.width < 1 || src.height < 1)
        return {};
    auto dst = std::make_shared<Canvas>(w, h);
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < w; ++x) {
            const float sx = (float(x) + .5f) * float(src.width) / float(w) - .5f,
                        sy = (float(y) + .5f) * float(src.height) / float(h) - .5f;
            const int ix = int(std::floor(sx)), iy = int(std::floor(sy));
            const float fx = sx - float(ix), fy = sy - float(iy);
            auto sample = [&](int dx, int dy, int c) {
                return float(src.rgba[4 * (std::size_t(std::clamp(iy + dy, 0, src.height - 1)) * src.width +
                                           std::size_t(std::clamp(ix + dx, 0, src.width - 1))) +
                                      c]);
            };
            for (int c = 0; c < 4; ++c) {
                const float a = sample(0, 0, c) * (1 - fx) + sample(1, 0, c) * fx,
                            b = sample(0, 1, c) * (1 - fx) + sample(1, 1, c) * fx;
                dst->rgba[4 * (std::size_t(y) * w + x) + c] =
                    static_cast<unsigned char>(std::clamp(a * (1 - fy) + b * fy + .5f, 0.f, 255.f));
            }
        }
    return dst;
}
}
