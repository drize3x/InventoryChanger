#pragma once
#include "watermark_hud_patterns.h"
namespace menu::knife_skin {
struct Bindings {
    std::uintptr_t knifeTable = 0, hasAttributesTable = 0, releaseMaterials = 0, hasPaint = 0,
                   refreshMaterials = 0;
};
inline bool Resolve(const HudScanImage& image, Bindings& out) {
    out = {};
    auto table = image.Vtables(".?AVC_Knife@@");
    auto attributesTable = image.Vtables(".?AVC_Knife@@", 0x1268);
    auto a =
        image.Find("48 8D 8F 68 12 00 00 48 8B 01 FF 50 18 48 8D 8F 10 06 00 00 B2 01 48 8B D8 E8 ? ? ? ? 48 "
                   "8D 4B 50 E8 ? ? ? ? 44 0F B6 C8 48 89 74 24 20 45 33 C0 48 8D 53 50 48 8B CF E8 ? ? ? ?",
                   true, 2);
    if (table.size() != 1 || attributesTable.size() != 1 || a.size() != 1)
        return false;
    Bindings b;
    b.knifeTable = table[0];
    b.hasAttributesTable = attributesTable[0];
    std::uintptr_t getter = 0;
    unsigned char getterBytes[5]{};
    const unsigned char expectedGetter[] = {0x48, 0x8d, 0x41, 0x28, 0xc3};
    if (!image.Read(b.hasAttributesTable + 24, getter) || !image.Contains(getter, 5, 0x20000000) ||
        !image.Bytes(getter, getterBytes, 5) || std::memcmp(getterBytes, expectedGetter, 5))
        return false;
    b.releaseMaterials = image.Rip(a[0] + 25, 1, 5);
    b.hasPaint = image.Rip(a[0] + 34, 1, 5);
    b.refreshMaterials = image.Rip(a[0] + 58, 1, 5);
    const unsigned char release[] = {0x48, 0x89, 0x5c, 0x24, 0x10, 0x48, 0x89, 0x6c, 0x24, 0x18};
    const unsigned char paint[] = {0x40, 0x53, 0x48, 0x83, 0xec, 0x20, 0x48, 0x8b, 0xd9, 0x48, 0x85, 0xc9};
    const unsigned char refresh[] = {0x48, 0x85, 0xc9, 0x0f, 0x84};
    unsigned char buf[12]{};
    if (!image.Contains(b.releaseMaterials, 10, 0x20000000) || !image.Contains(b.hasPaint, 12, 0x20000000) ||
        !image.Contains(b.refreshMaterials, 5, 0x20000000) || !image.Bytes(b.releaseMaterials, buf, 10) ||
        std::memcmp(buf, release, 10) || !image.Bytes(b.hasPaint, buf, 12) || std::memcmp(buf, paint, 12) ||
        !image.Bytes(b.refreshMaterials, buf, 5) || std::memcmp(buf, refresh, 5))
        return false;
    out = b;
    return true;
}
}
