#pragma once
#include <atomic>
#include <cstdint>
namespace menu::glove_inmatch {

inline std::atomic<std::uint64_t> pinnedItem{0};
inline std::atomic<bool> uncertainIdentity{false};
}
