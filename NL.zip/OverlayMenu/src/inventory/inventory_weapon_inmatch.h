#pragma once

#include "inventory_knife_skin.h"
#include "inventory_catalog.h"
#include "inventory_color_composite.h"
#include <map>
namespace menu::weapon_inmatch {
struct Choice {
    InventoryWeaponTarget finish;
    bool legacy = false;
    InventoryCharm charm{};
    local_decorations::Values stickers{};
    inventory_color::Palette palette{};
};
struct Plan {
    std::array<std::map<int, Choice>, 2> side;
};
inline Plan MakePlan(const InventoryCatalog& cat, const InventoryValues& cfg) {
    Plan p;
    for (int side = 0; side < 2; ++side)
        for (const auto& w : InventoryWeapons) {
            if (!InventorySelectedForLocalCopy(cfg.teams[side], side, w.index))
                continue;
            auto item = cfg.teams[side].Find(w.index);
            if (!item || item->paintKit <= 0) {
                auto other = cfg.teams[1 - side].Find(w.index);
                item = other && other->bothTeams ? other : nullptr;
            }
            if (!item || item->paintKit <= 0)
                continue;
            const auto* paint = cat.Paint(item->paintKit);
            if (!paint)
                continue;
            auto target = InventoryTargetFor(*item, w.index, 0);
            target.wear = InventoryWearFloat(item->wearTier, item->wearValue, paint->wearMin, paint->wearMax);
            charm::Values cv{item->charm.id, item->charm.pattern, item->charm.x, item->charm.y,
                             item->charm.z};
            const bool known = cv.id > 0 && charm::Valid(cv) &&
                               std::any_of(cat.keychains.begin(), cat.keychains.end(),
                                           [&](const auto& k) { return k.id == cv.id; });
            local_decorations::Values stickers{};
            for (std::size_t i = 0; i < stickers.stickers.size(); ++i) {
                const auto& st = item->stickers[i];
                stickers.stickers[i] = {st.id, st.x, st.y, st.rotation};
            }
            if (!local_decorations::Valid(stickers))
                stickers = {};
            p.side[side][w.index] = {target, paint->legacy, known ? item->charm : InventoryCharm{}, stickers,
                                     inventory_color::FromItem(*item)};
        }
    return p;
}
struct Adapter : InventoryMemory, knife_skin::Adapter {
    virtual bool Read(std::uintptr_t, void*, std::size_t) override = 0;
    virtual bool Write(std::uintptr_t, const void*, std::size_t) override = 0;
    virtual bool GunReady(std::uintptr_t, std::uintptr_t, int) = 0;
    virtual void SetPaintPalette(const inventory_color::Palette&, int, int) {}
    virtual bool EntityMatches(std::uint32_t, std::uintptr_t) {
        return true;
    }
    virtual bool IsDropped(std::uint32_t, std::uintptr_t) {
        return false;
    }
    virtual unsigned SetWeaponMesh(std::uintptr_t, std::uintptr_t, bool) {
        return 0;
    }
    virtual void RestoreWeaponMesh(std::uintptr_t, std::uintptr_t) {}
    virtual void ForgetWeaponMesh(std::uintptr_t) {}
    virtual bool UpdateWeaponCharm(std::uintptr_t, std::uintptr_t) {
        return false;
    }
    virtual void WeaponHudChanged(std::uint32_t, std::uintptr_t, std::uintptr_t) {}
};
struct Stats {
    const char* stage = "idle";
    unsigned applied = 0, failed = 0, restored = 0;
    int team = -1, def = 0, paint = 0, skin = -1, legacy = -1, attrCount = -1, charm = 0, charmState = 0,
        stickerState = 0;
    const char* skip = "none";
};
class Controller {
    struct Owned {
        std::uintptr_t entity = 0;
        int def = 0;
        InventoryWeaponSnapshot original{};
        InventoryWeaponTarget target{};
        InventoryCharm charm{};
        local_decorations::Values stickers{};
        inventory_color::Palette palette{};
        bool legacy = false, skinReady = false, meshRefreshPending = false, externalAttrs = false,
             hudNotified = false, charmAttempted = false;
        int charmState = 0;
        std::uint64_t retryAt = 0;
        knife_skin::Controller skin;
    };
    std::map<std::uint32_t, Owned> owned_;
    template <class T> static bool Get(Adapter& a, std::uintptr_t p, T& x) {
        return a.InventoryMemory::Get(p, x);
    }
    template <class T> static bool Set(Adapter& a, std::uintptr_t p, const T& x) {
        T v{};
        return Get(a, p, v) && (std::memcmp(&v, &x, sizeof x) == 0 || a.Write(p, &x, sizeof x));
    }
    static bool Same(const InventoryWeaponTarget& a, const InventoryWeaponTarget& b) {
        return a.paintKit == b.paintKit && a.seed == b.seed && a.wear == b.wear && a.statTrak == b.statTrak &&
               a.quality == b.quality;
    }
    static bool Snapshot(Adapter& a, const InventoryOffsets& o, std::uintptr_t e,
                         InventoryWeaponSnapshot& s) {
        auto v = e + o.attributeManager + o.item;
        return Get(a, e + o.fallbackPaintKit, s.paintKit) &&
               (!o.fallbackSeed || Get(a, e + o.fallbackSeed, s.seed)) &&
               (!o.fallbackWear || Get(a, e + o.fallbackWear, s.wear)) &&
               (!o.fallbackStatTrak || Get(a, e + o.fallbackStatTrak, s.statTrak)) &&
               (!o.itemIdHigh || Get(a, v + o.itemIdHigh, s.itemIdHigh)) &&
               (!o.entityQuality || Get(a, v + o.entityQuality, s.quality));
    }
    static bool Fields(Adapter& a, const InventoryOffsets& o, std::uintptr_t e,
                       const InventoryWeaponSnapshot& s) {
        auto v = e + o.attributeManager + o.item;
        return Set(a, e + o.fallbackPaintKit, s.paintKit) &&
               (!o.fallbackSeed || Set(a, e + o.fallbackSeed, s.seed)) &&
               (!o.fallbackWear || Set(a, e + o.fallbackWear, s.wear)) &&
               (!o.fallbackStatTrak || Set(a, e + o.fallbackStatTrak, s.statTrak)) &&
               (!o.itemIdHigh || Set(a, v + o.itemIdHigh, s.itemIdHigh)) &&
               (!o.entityQuality || Set(a, v + o.entityQuality, s.quality));
    }
    static InventoryWeaponSnapshot Desired(const Owned& x) {
        auto s = x.original;
        s.paintKit = x.target.paintKit;
        s.seed = x.target.seed;
        s.wear = x.target.wear;
        s.statTrak = x.target.statTrak;
        s.itemIdHigh = 0xffffffffu;
        s.quality = x.target.quality;
        return s;
    }
    template <class T>
    static bool RestoreIfOurs(Adapter& a, std::uintptr_t p, const T& applied, const T& original) {
        T current{};
        if (!Get(a, p, current))
            return false;
        if (std::memcmp(&current, &applied, sizeof current) != 0)
            return true;
        return Set(a, p, original);
    }
    static bool RestoreFields(Adapter& a, const InventoryOffsets& o, const Owned& x) {
        auto v = x.entity + o.attributeManager + o.item;
        auto d = Desired(x);
        auto& z = x.original;
        return RestoreIfOurs(a, x.entity + o.fallbackPaintKit, d.paintKit, z.paintKit) &&
               (!o.fallbackSeed || RestoreIfOurs(a, x.entity + o.fallbackSeed, d.seed, z.seed)) &&
               (!o.fallbackWear || RestoreIfOurs(a, x.entity + o.fallbackWear, d.wear, z.wear)) &&
               (!o.fallbackStatTrak ||
                RestoreIfOurs(a, x.entity + o.fallbackStatTrak, d.statTrak, z.statTrak)) &&
               (!o.itemIdHigh || RestoreIfOurs(a, v + o.itemIdHigh, d.itemIdHigh, z.itemIdHigh)) &&
               (!o.entityQuality || RestoreIfOurs(a, v + o.entityQuality, d.quality, z.quality));
    }

    static bool MatchesExisting(Adapter& a, std::uintptr_t at, const InventoryWeaponTarget& t) {
        knife_skin::Vector vec{};
        if (!Get(a, at, vec) || !vec.data || vec.count == 0 || vec.count > 64)
            return false;
        bool found[3] = {false, false, false};
        for (std::uint64_t i = 0; i < vec.count; ++i) {
            knife_skin::Attr v{};
            if (!Get(a, vec.data + i * sizeof(v), v))
                return false;
            int j = v.id == 6 ? 0 : v.id == 7 ? 1 : v.id == 8 ? 2 : -1;
            if (j < 0)
                continue;
            if (found[j] || !std::isfinite(v.value))
                return false;
            found[j] = true;
            const float want = j == 0 ? float(t.paintKit) : j == 1 ? float(t.seed) : t.wear;
            if (std::fabs(v.value - want) > 0.000001f)
                return false;
        }
        return found[0] && found[1] && found[2];
    }
    static bool MatchesCharm(Adapter& a, std::uintptr_t at, const InventoryCharm& c) {
        knife_skin::Vector vec{};
        if (!Get(a, at, vec) || !vec.data || !vec.count || vec.count > 64)
            return false;
        bool found[5] = {};
        const int ids[] = {299, 306, 300, 301, 302};
        const float wanted[] = {charm::IntBits(std::uint32_t(c.id)), charm::IntBits(std::uint32_t(c.pattern)),
                                c.x, c.y, c.z};
        for (std::uint64_t i = 0; i < vec.count; ++i) {
            knife_skin::Attr v{};
            if (!Get(a, vec.data + i * sizeof(v), v))
                return false;
            for (int j = 0; j < 5; ++j)
                if (v.id == ids[j]) {
                    if (found[j] || std::memcmp(&v.value, &wanted[j], 4))
                        return false;
                    found[j] = true;
                }
        }
        for (int j = 0; j < 5; ++j)
            if (!found[j] && (j == 0 || wanted[j] != 0.f))
                return false;
        return true;
    }
    static bool Restore(Adapter& a, const InventoryOffsets& o, Owned& x, std::uintptr_t pawn = 0,
                        bool local = false) {
        auto v = x.entity + o.attributeManager + o.item;
        std::uint16_t def = 0;
        if (!Get(a, v + o.itemDefinition, def) || def != x.def || !a.GunReady(x.entity, v, x.def))
            return false;
        a.RestoreWeaponMesh(x.entity, pawn);
        a.SetPaintPalette({}, 0, 0);
        if (!x.skin.Restore(a, x.entity, v))
            return false;
        if (!RestoreFields(a, o, x))
            return false;
        if (local && x.charmAttempted)
            a.UpdateWeaponCharm(x.entity, v);
        return a.Refresh(x.entity, v);
    }

public:
    bool Holding() const {
        return !owned_.empty();
    }
    Stats Tick(Adapter& a, const InventoryOffsets& o, std::uint32_t list, std::uint32_t attr,
               std::uintptr_t controller, const Plan& plan, bool enabled, std::uint64_t now = 0) {
        Stats s;
        std::uint32_t ph = 0;
        std::uintptr_t pawn = 0, svc = 0, arr = 0;
        std::uint8_t team = 0;
        int count = 0;
        if (!o.Required() || !list || !attr || !controller || !Get(a, controller + o.pawnHandle, ph) || !ph ||
            ph == 0xffffffffu || !(pawn = a.Entity(ph)) || !Get(a, pawn + o.team, team) ||
            !Get(a, pawn + o.weaponServices, svc) || !svc || !Get(a, svc + o.myWeapons, count) || count < 0 ||
            count > 64 || !Get(a, svc + o.myWeapons + 8, arr) || (count && !arr)) {

            for (auto it = owned_.begin(); it != owned_.end();) {
                auto live = a.Entity(it->first);
                if (!live || live != it->second.entity || !a.EntityMatches(it->first, live)) {
                    a.ForgetWeaponMesh(it->second.entity);
                    it->second.skin.Forget();
                    it = owned_.erase(it);
                } else if (!enabled && Restore(a, o, it->second)) {
                    ++s.restored;
                    it = owned_.erase(it);
                } else {
                    ++it;
                }
            }
            s.stage = "weapon graph unavailable";
            return s;
        }
        s.team = team == 3 ? 0 : team == 2 ? 1 : -1;
        if (s.team < 0)
            enabled = false;
        std::map<std::uint32_t, std::uintptr_t> current;
        for (int i = 0; i < count; ++i) {
            std::uint32_t h = 0;
            if (!Get(a, arr + i * 4, h)) {
                s.stage = "weapon list unreadable";
                return s;
            }
            if (h && h != 0xffffffffu) {
                auto e = a.Entity(h);
                if (e)
                    current[h] = e;
            }
        }
        for (auto it = owned_.begin(); it != owned_.end();) {
            auto& x = it->second;
            auto live = a.Entity(it->first);
            auto cur = current.find(it->first);
            auto target = s.team >= 0 ? plan.side[s.team].find(x.def) : plan.side[0].end();
            bool wanted = enabled && s.team >= 0 && cur != current.end() && cur->second == x.entity &&
                          target != plan.side[s.team].end() && Same(x.target, target->second.finish) &&
                          x.legacy == target->second.legacy && x.charm == target->second.charm &&
                          x.stickers == target->second.stickers && x.palette == target->second.palette;
            if (!live || live != x.entity || !a.EntityMatches(it->first, live)) {
                a.ForgetWeaponMesh(x.entity);
                x.skin.Forget();
                it = owned_.erase(it);
                continue;
            }

            if (enabled && cur == current.end() && a.IsDropped(it->first, x.entity)) {
                ++it;
                continue;
            }
            if (!wanted) {
                if (!Restore(a, o, x, pawn, cur != current.end() && cur->second == x.entity)) {
                    s.stage = "restore blocked";
                    ++s.failed;
                    ++it;
                    continue;
                }
                if (cur != current.end() && cur->second == x.entity)
                    a.WeaponHudChanged(it->first, x.entity, x.entity + o.attributeManager + o.item);
                ++s.restored;
                it = owned_.erase(it);
                continue;
            }
            ++it;
        }
        if (!enabled)
            return s;
        for (const auto& [h, e] : current) {
            std::uint16_t def = 0;
            auto view = e + o.attributeManager + o.item;
            if (!Get(a, view + o.itemDefinition, def) || !InventoryWeapon(def))
                continue;
            auto t = plan.side[s.team].find(def);
            if (t == plan.side[s.team].end())
                continue;
            s.def = def;
            s.paint = t->second.finish.paintKit;
            s.legacy = t->second.legacy ? 1 : 0;
            s.charm = t->second.charm.id;
            auto it = owned_.find(h);
            if (it == owned_.end()) {
                knife_skin::Vector existing{};
                if (!a.GunReady(e, view, def)) {
                    s.skip = "guard";
                    ++s.failed;
                    continue;
                }
                if (!Get(a, view + list + attr, existing)) {
                    s.skip = "attributes-unreadable";
                    ++s.failed;
                    continue;
                }
                s.attrCount = existing.count <= 0x7fffffff ? int(existing.count) : -2;
                bool external = existing.count || existing.data;
                if (external && !MatchesExisting(a, view + list + attr, t->second.finish)) {
                    s.skip = "attributes-existing-differ";
                    ++s.failed;
                    continue;
                }
                Owned x;
                x.entity = e;
                x.def = def;
                x.target = t->second.finish;
                x.legacy = t->second.legacy;
                x.charm = t->second.charm;
                x.stickers = t->second.stickers;
                x.palette = t->second.palette;
                x.externalAttrs = external;
                if (!Snapshot(a, o, e, x.original)) {
                    s.skip = "snapshot";
                    ++s.failed;
                    continue;
                }
                it = owned_.emplace(h, std::move(x)).first;
            }
            auto& x = it->second;
            if (x.entity != e || x.def != def ||
                (!Same(x.target, t->second.finish) || x.legacy != t->second.legacy))
                continue;
            if (!Fields(a, o, e, Desired(x))) {
                s.skip = "field-write";
                ++s.failed;
                continue;
            }
            if (now && x.retryAt && now < x.retryAt) {
                s.skip = "retry-wait";
                ++s.failed;
                continue;
            }

            const unsigned mesh = a.SetWeaponMesh(e, pawn, x.legacy);
            if (mesh & 12u)
                x.meshRefreshPending = true;
            a.SetPaintPalette(x.palette, x.def, x.target.paintKit);
            const bool wasReady = x.skinReady;
            if (x.externalAttrs) {
                if (!MatchesExisting(a, view + list + attr, x.target)) {
                    s.skip = "attributes-changed";
                    s.skin = 4;
                } else
                    s.skin = (!x.skinReady && (!a.Ready(e, view) || !a.Refresh(e, view))) ? 3 : 0;
            } else {
                charm::Values cv{x.charm.id, x.charm.pattern, x.charm.x, x.charm.y, x.charm.z};
                s.skin = x.skin.Apply(a, e, view, list, attr, x.target, x.charm.id ? &cv : nullptr,
                                      local_decorations::Any(x.stickers) ? &x.stickers : nullptr);
            }
            if (s.skin == 0) {
                s.stickerState = local_decorations::Any(x.stickers) ? (x.externalAttrs ? 2 : 1) : 0;
                x.skinReady = true;
                if (!wasReady)
                    x.meshRefreshPending = false;
                if (x.meshRefreshPending) {
                    if (!a.Ready(e, view) || !a.Refresh(e, view)) {
                        s.skin = 3;
                        s.skip = "mesh-refresh";
                        ++s.failed;
                        x.retryAt = now ? now + 1000 : 0;
                        continue;
                    }
                    x.meshRefreshPending = false;
                }
                if (x.charm.id && !x.charmAttempted) {
                    if (x.externalAttrs && !MatchesCharm(a, view + list + attr, x.charm))
                        x.charmState = 3;
                    else {
                        x.charmAttempted = true;
                        x.charmState = a.UpdateWeaponCharm(e, view) ? 1 : 2;
                    }
                }
                s.charmState = x.charmState;
                if (!x.hudNotified) {
                    a.WeaponHudChanged(h, e, view);
                    x.hudNotified = true;
                }
                x.retryAt = 0;
                ++s.applied;
            } else {
                if (!std::strcmp(s.skip, "none"))
                    s.skip = "skin-apply";
                x.retryAt = now ? now + 1000 : 0;
                ++s.failed;
            }
        }
        s.stage = s.applied ? "applied" : s.failed ? "skipped" : "no selected weapon";
        return s;
    }
};
}
