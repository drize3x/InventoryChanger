#include "inventory_art_prefetch.h"

namespace menu {
std::string InventoryNamedImage(const InventoryCatalog& cat, InventoryNamedArt kind, int id, int team) {
    const auto& list = kind == InventoryNamedArt::Agent   ? cat.agents
                       : kind == InventoryNamedArt::Medal ? cat.medals
                                                          : cat.music;
    if (id) {
        for (const auto& n : list)
            if (n.id == id)
                return n.image;
        return {};
    }
    if (kind == InventoryNamedArt::Agent)
        return cat.defaultNamedImages[team == InventoryT ? 1 : 0];
    if (kind == InventoryNamedArt::Music)
        return cat.defaultNamedImages[2];
    return {};
}

const InventoryCollection* InventoryCollectionFor(const InventoryCatalog& cat, int index, int paint) {
    const InventoryCollection* found = nullptr;
    for (const auto& c : cat.collections)
        if (std::find(c.members.begin(), c.members.end(), std::pair<int, int>{index, paint}) !=
            c.members.end()) {
            if (found)
                return nullptr;
            found = &c;
        }
    return found;
}

std::string InventoryItemArtworkPath(const InventoryCatalog& cat, int index, int paint) {
    auto it = cat.itemImages.find({index, paint});
    return it != cat.itemImages.end() ? it->second : std::string{};
}

void InventoryDemandImage(const std::string& path, std::uint64_t now) {
    if (!path.empty())
        GameInventoryArtwork().Query(path, now);
}

void InventoryDemandItem(const InventoryCatalog& cat, int index, int paint, std::uint64_t now) {
    InventoryDemandImage(InventoryItemArtworkPath(cat, index, paint), now);
}

std::vector<std::string> InventoryStartupImagePaths(const InventoryCatalog& cat, const Settings& cfg) {
    std::vector<std::string> paths;
    auto add = [&](const std::string& path) {
        if (!path.empty() && std::find(paths.begin(), paths.end(), path) == paths.end())
            paths.push_back(path);
    };
    auto item = [&](int index, int paint) {
        auto i = cat.itemImages.find({index, paint});
        if (i != cat.itemImages.end())
            add(i->second);
    };
    for (const auto& w : InventoryWeapons)
        item(w.index, 0);
    for (const auto& path : cat.defaultNamedImages)
        add(path);
    for (int team = 0; team < 2; ++team) {
        const auto& l = cfg.inventory.teams[std::size_t(team)];
        auto equipped = [&](int index) {
            auto* p = l.Find(index);
            item(index, p ? p->paintKit : 0);
        };
        for (int index : l.slots)
            equipped(index);
        equipped(cfg.inventory.Knife(team));
        equipped(cfg.inventory.Gloves(team));
        equipped(31);
        add(InventoryNamedImage(cat, InventoryNamedArt::Agent, l.agent, team));
        add(InventoryNamedImage(cat, InventoryNamedArt::Medal, l.medal, team));
        add(InventoryNamedImage(cat, InventoryNamedArt::Music, l.music, team));
    }
    return paths;
}

InventoryStartupImagesStatus InventoryCheckStartupImages(const std::vector<std::string>& paths,
                                                         std::uint64_t now) {
    InventoryStartupImagesStatus s;
    s.total = paths.size();
    for (const auto& path : paths) {
        auto result = GameInventoryArtwork().Query(path, now);
        if (result.state == AmbienceImageState::Ready && result.image)
            ++s.ready;
        else if (result.state == AmbienceImageState::Missing && s.missing.empty())
            s.missing = path;
    }
    return s;
}

void InventoryPrefetchBase(const InventoryCatalog& cat, std::uint64_t now) {
    for (const auto& w : InventoryWeapons)
        InventoryDemandItem(cat, w.index, 0, now);
    for (const auto& p : cat.defaultNamedImages)
        InventoryDemandImage(p, now);
}

void InventoryPrefetchLoadout(const InventoryCatalog& cat, const Settings& cfg, std::uint64_t now) {
    for (int team = 0; team < 2; ++team) {
        const auto& l = cfg.inventory.teams[std::size_t(team)];
        auto item = [&](int index) {
            auto* p = l.Find(index);
            InventoryDemandItem(cat, index, p ? p->paintKit : 0, now);
        };
        for (int index : l.slots)
            item(index);
        item(cfg.inventory.Knife(team));
        item(cfg.inventory.Gloves(team));
        item(31);
        InventoryDemandImage(InventoryNamedImage(cat, InventoryNamedArt::Agent, l.agent, team), now);
        InventoryDemandImage(InventoryNamedImage(cat, InventoryNamedArt::Medal, l.medal, team), now);
        InventoryDemandImage(InventoryNamedImage(cat, InventoryNamedArt::Music, l.music, team), now);
    }
}
}
