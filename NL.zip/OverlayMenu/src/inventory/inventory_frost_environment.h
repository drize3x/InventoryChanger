#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
namespace menu::inventory_frost {
struct Environment {
    bool initialized = false;
    float level = 0, last[3]{};
    std::uint64_t at = 0;
    bool Step(bool sky, const float* p, std::uint64_t now) {
        if (!p || !now || !std::isfinite(p[0]) || !std::isfinite(p[1]) || !std::isfinite(p[2]))
            return false;
        if (!initialized || now < at || now - at > 2000) {
            initialized = true;
            level = sky ? 1.f : 0.f;
            for (int i = 0; i < 3; ++i)
                last[i] = p[i];
            at = now;
            return true;
        }
        float dx = p[0] - last[0], dy = p[1] - last[1], dz = p[2] - last[2];
        float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
        if (!std::isfinite(dist) || dist > 1024.f) {
            initialized = false;
            return Step(sky, p, now);
        }
        // Fade under cover even if the player stops moving.
        const float target = sky ? 1.f : 0.f;
        const float dt = std::min(0.25f, float(now - at) / 1000.f);
        if (level < target)
            level = std::min(target, level + dt / 10.f);
        else
            level = std::max(target, level - dt / 10.f);
        for (int i = 0; i < 3; ++i) {
            last[i] = p[i];
        }
        at = now;
        return true;
    }
};
// Never force frost from a missing, stale, or invalid environment sample.
inline float FreshLevel(float level, std::uint64_t sampled, std::uint64_t now) {
    constexpr std::uint64_t MaxSampleAgeMs = 1000;
    return sampled && now >= sampled && now - sampled <= MaxSampleAgeMs && std::isfinite(level) &&
                   level >= 0.f && level <= 1.f
               ? level
               : 0.f;
}
}
