#pragma once

#include "inventory_knife_skin.h"
#include "inventory_glove_identity.h"
#include "inventory_color_composite.h"
#include <array>
namespace menu::glove_inmatch {
struct Choice {
    int def = 0;
    bool hasFinish = false;
    InventoryWeaponTarget finish{};
    inventory_color::Palette palette{};
};
struct Plan {
    std::array<Choice, 2> side{};
};
struct Offsets {
    std::uint32_t view = 0, reapply = 0, definition = 0, quality = 0, initialized = 0, list = 0,
                  attributes = 0, identity = 0, restoreMaterial = 0, disallowSOC = 0;
};

struct Diagnostics {
    unsigned starts = 0, restores = 0, pawnChanges = 0, teamChanges = 0, choiceChanges = 0, disabled = 0,
             identityChanges = 0, defResets = 0, qualityResets = 0, initResets = 0;
};
struct Adapter : knife_skin::Adapter {

    virtual bool PrepareAppearance(std::uintptr_t, std::uintptr_t) {
        return true;
    }
    virtual bool EquippedIdentity(int, const Choice&, Identity&) {
        return false;
    }

    virtual bool EquippedFlags(int, const Choice&, Identity, std::uint8_t&, std::uint8_t&) {
        return false;
    }

    virtual bool InvalidateDescription(std::uintptr_t, std::uintptr_t) {
        return false;
    }
};

class FlagOverride {
    std::uintptr_t at_ = 0;
    std::uint8_t original_ = 0, written_ = 0;
    bool held_ = false;

public:
    bool Held() const {
        return held_;
    }
    void Forget() {
        held_ = false;
        at_ = 0;
    }
    template <class A> bool Apply(A& a, std::uintptr_t at, std::uint8_t desired, bool& changed) {
        changed = false;
        if (!at || desired > 1 || (held_ && at_ != at))
            return false;
        std::uint8_t cur = 0;
        if (!a.Get(at, cur) || cur > 1 || (held_ && cur != written_))
            return false;
        if (!held_) {
            at_ = at;
            original_ = cur;
            written_ = cur;
            held_ = true;
        }
        if (cur == desired)
            return true;

        written_ = desired;
        const bool ok = a.Write(at, &desired, 1);
        std::uint8_t check = 0;
        if (!a.Get(at, check))
            return false;
        if (check == cur) {
            written_ = cur;
            return false;
        }
        if (check != desired)
            return false;
        changed = true;
        return ok;
    }
    template <class A> bool Restore(A& a) {
        if (!held_)
            return true;
        std::uint8_t cur = 0;
        if (!a.Get(at_, cur))
            return false;
        if (cur == written_ && cur != original_) {
            if (!a.Write(at_, &original_, 1))
                return false;
            std::uint8_t check = 0;
            if (!a.Get(at_, check) || check != original_)
                return false;
        }
        Forget();
        return true;
    }
};
class Controller {
    struct Snapshot {
        std::uint16_t def = 0;
        std::int32_t quality = 0;
        std::uint8_t initialized = 0;
    };
    std::uint32_t handle_ = 0;
    std::uintptr_t pawn_ = 0;
    Choice choice_{};
    Snapshot original_{};
    bool holding_ = false, pendingRefresh_ = false;
    unsigned appearanceFrames_ = 0, armsChanges_ = 0;
    std::uint32_t armsHandle_ = 0;
    std::uintptr_t armsNode_ = 0;
    int appearanceStatus_ = -1, lastTeam_ = -1;
    bool syncIdentity_ = false, descriptionPending_ = false, renderGated_ = false;
    std::uint64_t lastRender_ = 0;
    int descriptionStatus_ = -1;
    Diagnostics diag_{};
    IdentityOverride identity_;
    FlagOverride materialFlag_, socFlag_;
    int flagStatus_ = -1, flagMaterial_ = -1, flagSOC_ = -1;
    std::uint64_t nextFlagTry_ = 0;
    knife_skin::Controller attributes_;
    const char* stage_ = "idle";
    static bool Same(const Choice& a, const Choice& b) {
        return a.def == b.def && a.hasFinish == b.hasFinish &&
               (!a.hasFinish || (a.finish.paintKit == b.finish.paintKit && a.finish.seed == b.finish.seed &&
                                 a.finish.wear == b.finish.wear));
    }
    template <class T> static bool Set(Adapter& a, std::uintptr_t p, const T& v) {
        T old{};
        return a.Get(p, old) && (std::memcmp(&old, &v, sizeof v) == 0 || a.Write(p, &v, sizeof v));
    }
    bool Restore(Adapter& a, const Offsets& o) {
        if (!holding_)
            return true;
        const auto v = pawn_ + o.view;
        if (choice_.hasFinish && !attributes_.Restore(a, pawn_, v)) {
            stage_ = "attribute restore blocked";
            return false;
        }
        if (!materialFlag_.Restore(a) || !socFlag_.Restore(a)) {
            stage_ = "flag restore blocked";
            return false;
        }
        flagStatus_ = -1;
        flagMaterial_ = flagSOC_ = -1;
        nextFlagTry_ = 0;
        const bool hadIdentity = identity_.Held();
        if (!identity_.Restore(a)) {
            stage_ = "identity restore blocked";
            return false;
        }
        std::uint16_t def = 0;
        std::int32_t quality = 0;
        std::uint8_t init = 0;
        if (!a.Get(v + o.definition, def) || !a.Get(v + o.quality, quality) ||
            !a.Get(v + o.initialized, init)) {
            stage_ = "restore read failed";
            return false;
        }

        if (def == choice_.def) {
            if (!Set(a, v + o.definition, original_.def) || !Set(a, v + o.quality, original_.quality) ||
                !Set(a, v + o.initialized, original_.initialized)) {
                stage_ = "restore write failed";
                return false;
            }
            if (hadIdentity)
                descriptionStatus_ = a.InvalidateDescription(pawn_, v) ? 1 : 0;
            if (!a.Refresh(pawn_, v)) {
                stage_ = "restore refresh failed";
                return false;
            }
        }
        ++diag_.restores;
        holding_ = false;
        pendingRefresh_ = false;
        descriptionPending_ = false;
        appearanceFrames_ = 0;
        appearanceStatus_ = -1;
        armsHandle_ = 0;
        armsNode_ = 0;
        handle_ = 0;
        pawn_ = 0;
        choice_ = {};
        stage_ = "restored";
        return true;
    }

public:
    const char* Stage() const {
        return stage_;
    }
    bool Holding() const {
        return holding_;
    }
    const Choice& AppliedChoice() const {
        return choice_;
    }
    unsigned ArmsChanges() const {
        return armsChanges_;
    }
    bool IdentityHeld() const {
        return identity_.Held();
    }
    int DescriptionStatus() const {
        return descriptionStatus_;
    }
    int FlagStatus() const {
        return flagStatus_;
    }
    int FlagMaterial() const {
        return flagMaterial_;
    }
    int FlagSOC() const {
        return flagSOC_;
    }
    unsigned PendingAppearanceFrames() const {
        return appearanceFrames_;
    }
    bool RenderGated() const {
        return renderGated_;
    }
    const Diagnostics& Diag() const {
        return diag_;
    }

    void RequestStageRefresh() {
        if (holding_) {
            appearanceFrames_ = 4;
            renderGated_ = false;
        }
    }
    void Tick(Adapter& a, const Offsets& o, std::uint32_t handle, std::uintptr_t pawn, int team,
              const Plan& plan, bool enabled, std::uint64_t nowMs = 0, std::uint32_t armsHandle = 0,
              std::uintptr_t armsNode = 0, std::uint64_t renderFrame = 0) {
        (void)nowMs;
        if (holding_ && (handle != handle_ || pawn != pawn_)) {
            ++diag_.pawnChanges;
            attributes_.Forget();
            identity_.Forget();
            materialFlag_.Forget();
            socFlag_.Forget();
            flagStatus_ = -1;
            flagMaterial_ = flagSOC_ = -1;
            nextFlagTry_ = 0;
            holding_ = false;
            pendingRefresh_ = false;
            descriptionPending_ = false;
            appearanceFrames_ = 0;
            appearanceStatus_ = -1;
            armsHandle_ = 0;
            armsNode_ = 0;
            handle_ = 0;
            pawn_ = 0;
            choice_ = {};
            stage_ = "pawn changed";
        }
        if (!handle || handle == 0xffffffffu || !pawn) {
            stage_ = "no pawn";
            return;
        }
        if (!o.view || !o.reapply || !o.definition || !o.quality || !o.initialized || !o.list ||
            !o.attributes) {
            stage_ = "schema unavailable";
            return;
        }
        const Choice desired = enabled && (team == 0 || team == 1) ? plan.side[std::size_t(team)] : Choice{};
        const bool teamChanged = lastTeam_ >= 0 && team >= 0 && team != lastTeam_;
        if (holding_ && (!desired.def || teamChanged || !Same(desired, choice_))) {
            if (teamChanged)
                ++diag_.teamChanges;
            else if (!desired.def)
                ++diag_.disabled;
            else
                ++diag_.choiceChanges;
            if (!Restore(a, o))
                return;
        }
        if (!desired.def) {
            stage_ = "disabled";
            return;
        }
        if (!InventoryGlove(desired.def) || desired.def == InventoryDefaultGlove(team) ||
            desired.finish.paintKit < 0) {
            stage_ = "invalid choice";
            return;
        }
        if (teamChanged) {
            syncIdentity_ = true;
            descriptionPending_ = true;
            renderGated_ = renderFrame != 0;
            lastRender_ = renderFrame;
        }
        lastTeam_ = team;

        if (armsHandle && armsNode) {
            if (holding_ && (armsHandle_ != armsHandle || armsNode_ != armsNode)) {
                appearanceFrames_ = 4;
                ++armsChanges_;
            }
            armsHandle_ = armsHandle;
            armsNode_ = armsNode;
        }
        const auto v = pawn + o.view;
        if (!holding_) {
            knife_skin::Vector vec{};
            if (!a.Ready(pawn, v) || !a.Get(v + o.list + o.attributes, vec)) {
                stage_ = "not ready";
                return;
            }
            if (vec.count || vec.data) {
                stage_ = "original attributes not empty";
                return;
            }
            Snapshot orig{};
            if (!a.Get(v + o.definition, orig.def) || !a.Get(v + o.quality, orig.quality) ||
                !a.Get(v + o.initialized, orig.initialized)) {
                stage_ = "snapshot failed";
                return;
            }
            ++diag_.starts;
            holding_ = true;
            handle_ = handle;
            pawn_ = pawn;
            choice_ = desired;
            original_ = orig;
            appearanceFrames_ = 4;
            appearanceStatus_ = -1;
        }

        // Color changes do not alter the item identity or attributes. Reapply only
        // the material, without restoring or recreating the gloves.
        if (holding_ && desired.hasFinish && choice_.palette != desired.palette) {
            choice_.palette = desired.palette;
            pendingRefresh_ = true;
        }

        if (syncIdentity_ && o.identity) {
            Identity wanted{};
            if (a.EquippedIdentity(team, desired, wanted)) {
                bool changed = false;
                if (!identity_.Apply(a, v + o.identity, wanted, changed) && identity_.Uncertain()) {
                    stage_ = "identity sync uncertain";
                    return;
                }
                if (changed) {
                    ++diag_.identityChanges;
                    appearanceFrames_ = 4;
                    pendingRefresh_ = true;
                    descriptionPending_ = true;
                }

                std::uint64_t liveId = 0;
                std::uint32_t hi = 0, lo = 0, account = 0;
                if (o.restoreMaterial && o.disallowSOC &&
                    (!nextFlagTry_ || !nowMs || nowMs >= nextFlagTry_) &&
                    (!materialFlag_.Held() || !socFlag_.Held()) && identity_.Held() &&
                    a.Get(v + o.identity, liveId) && a.Get(v + o.identity + 8, hi) &&
                    a.Get(v + o.identity + 12, lo) && a.Get(v + o.identity + 16, account) &&
                    liveId == wanted.id && hi == std::uint32_t(wanted.id >> 32) &&
                    lo == std::uint32_t(wanted.id) && account == wanted.account) {
                    std::uint8_t material = 0, soc = 0;
                    nextFlagTry_ = nowMs ? nowMs + 250 : 0;
                    if (a.EquippedFlags(team, desired, wanted, material, soc)) {
                        flagMaterial_ = material;
                        flagSOC_ = soc;
                        bool m = false, d = false;
                        if (!materialFlag_.Apply(a, v + o.restoreMaterial, material, m) ||
                            !socFlag_.Apply(a, v + o.disallowSOC, soc, d)) {
                            flagStatus_ = 0;
                            stage_ = "flag sync blocked";
                            return;
                        }
                        flagStatus_ = 1;
                        if (m || d) {
                            appearanceFrames_ = 4;
                            pendingRefresh_ = true;
                            descriptionPending_ = true;
                        }
                    } else
                        flagStatus_ = 2;
                }
            } else if (identity_.Held()) {

                if (!materialFlag_.Restore(a) || !socFlag_.Restore(a)) {
                    stage_ = "flag restore blocked";
                    return;
                }
                flagStatus_ = -1;
                flagMaterial_ = flagSOC_ = -1;
                nextFlagTry_ = 0;
                if (!identity_.Restore(a)) {
                    stage_ = "identity restore blocked";
                    return;
                }
                pendingRefresh_ = true;
            }
        }
        const std::uint16_t def = std::uint16_t(desired.def);
        const std::int32_t quality = InventoryQualityUnusual;
        const std::uint8_t init = 1;
        std::uint16_t oldDef = 0;
        std::int32_t oldQuality = 0;
        std::uint8_t oldInit = 0;
        if (!a.Get(v + o.definition, oldDef) || !a.Get(v + o.quality, oldQuality) ||
            !a.Get(v + o.initialized, oldInit)) {
            stage_ = "field read failed";
            return;
        }
        const bool changed = oldDef != def || oldQuality != quality || oldInit != init;
        if (changed) {
            if (oldDef != def)
                ++diag_.defResets;
            if (oldQuality != quality)
                ++diag_.qualityResets;
            if (oldInit != init)
                ++diag_.initResets;
            pendingRefresh_ = true;
        }
        if (!Set(a, v + o.definition, def) || !Set(a, v + o.quality, quality) ||
            !Set(a, v + o.initialized, init)) {
            stage_ = "field write failed";
            return;
        }
        if (desired.hasFinish) {
            const int result = attributes_.Apply(a, pawn, v, o.list, o.attributes, desired.finish);
            if (result != 0) {
                stage_ = result == 2   ? "attributes occupied"
                         : result == 3 ? "refresh pending"
                         : result == 4 ? "attribute ownership uncertain"
                                       : "paint unavailable";
                return;
            }
        }

        if (descriptionPending_) {
            descriptionStatus_ = a.InvalidateDescription(pawn, v) ? 1 : 0;
            descriptionPending_ = false;
            pendingRefresh_ = true;
        }

        if (appearanceFrames_ && (!renderGated_ || renderFrame != lastRender_)) {
            lastRender_ = renderFrame;
            appearanceStatus_ = a.PrepareAppearance(pawn, v) ? 1 : 0;
            --appearanceFrames_;
            pendingRefresh_ = true;
        }
        if (pendingRefresh_) {
            if (!a.Refresh(pawn, v)) {
                stage_ = "refresh failed";
                return;
            }
            pendingRefresh_ = false;
        }
        stage_ = appearanceStatus_ == 0 ? "bodygroup unavailable" : "applied";
    }
};
}
