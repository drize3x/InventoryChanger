#pragma once
#include "inventory_kv.h"
#include <functional>
#include <set>
#include <sstream>
namespace menu {

void InventoryMergeCatalogSections(KV1Node& root);

const KV1Node* InventorySchemaField(const KV1Node& ig, const KV1Node& node, const char* field);
std::string InventorySchemaText(const KV1Node& ig, const KV1Node& node, const char* field);
bool InventorySchemaPrefab(const KV1Node& ig, const KV1Node& node, const char* type);
bool InventorySchemaIndex(const std::string& s, int& value);
}
