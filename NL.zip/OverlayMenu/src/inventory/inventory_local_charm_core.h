#pragma once

#include <cstdint>
#include <vector>
#include <algorithm>
namespace menu::local_charm {
struct Owner {
    std::uint64_t id = 0;
    std::uint32_t type = 0, pad = 0;
};
struct Snapshot {
    std::uintptr_t inventory = 0, cache = 0;
    Owner owner{};
    std::vector<std::uintptr_t> objects;
};
struct Item {
    std::uint64_t id = 0;
    std::uint32_t position = 0;
};
struct Adapter {
    virtual ~Adapter() = default;
    virtual bool Capture(Snapshot&) = 0;
    virtual bool ItemInfo(std::uintptr_t, Item&) = 0;
    virtual std::uintptr_t Create(std::uint64_t, std::uint32_t, std::uint32_t, int, int) = 0;
    virtual std::uintptr_t CreateSticker(std::uint64_t, std::uint32_t, std::uint32_t, int) {
        return 0;
    }
    virtual bool Add(std::uintptr_t, std::uintptr_t, bool&) = 0;
    virtual bool Notify(std::uintptr_t, const Owner&, std::uintptr_t, bool) = 0;
    virtual bool Remove(std::uintptr_t, std::uintptr_t, bool&) = 0;
    virtual bool Destroy(std::uintptr_t) = 0;
};
enum class Result { Idle, Added, Removed, Unavailable, Conflict, Fault };
class Controller {
    std::uintptr_t object_ = 0, inventory_ = 0, cache_ = 0;
    Owner owner_{};
    std::uint64_t id_ = 0;
    bool uncertain_ = false;
    static bool sameOwner(const Owner& a, const Owner& b) {
        return a.id == b.id && a.type == b.type;
    }
    void Forget() {
        object_ = inventory_ = cache_ = 0;
        owner_ = {};
        id_ = 0;
    }

public:
    bool Holding() const {
        return object_ != 0;
    }
    bool Uncertain() const {
        return uncertain_;
    }
    Result InsertImpl(Adapter& a, int value, int seed, bool sticker) {
        if (Holding() || uncertain_)
            return Result::Conflict;
        Snapshot s;
        if (!a.Capture(s) || !s.inventory || !s.cache || !s.owner.id || !s.owner.type)
            return Result::Unavailable;
        std::vector<std::uint64_t> ids;
        ids.reserve(s.objects.size());
        std::uint32_t pos = 0;
        for (auto p : s.objects) {
            Item i;
            if (!p || !a.ItemInfo(p, i))
                return Result::Unavailable;
            ids.push_back(i.id);
            if (i.position < 0x40000000u)
                pos = std::max(pos, i.position);
        }

        if (pos >= 0x3fffffff)
            return Result::Unavailable;
        std::uint64_t id = (sticker ? 0x0c00000000000000ULL : 0x0e00000000000000ULL) |
                           (std::uint64_t(std::uint32_t(s.owner.id)) << 20) | 1ULL;
        for (unsigned n = 0; n < 1024 && std::find(ids.begin(), ids.end(), id) != ids.end(); ++n)
            ++id;
        if (std::find(ids.begin(), ids.end(), id) != ids.end())
            return Result::Unavailable;
        auto p = sticker ? a.CreateSticker(id, pos + 1, std::uint32_t(s.owner.id), value)
                         : a.Create(id, pos + 1, std::uint32_t(s.owner.id), value, seed);
        if (!p)
            return Result::Unavailable;
        bool added = false;
        if (!a.Add(s.cache, p, added)) {
            uncertain_ = true;
            object_ = p;
            inventory_ = s.inventory;
            cache_ = s.cache;
            owner_ = s.owner;
            id_ = id;
            return Result::Fault;
        }
        if (!added) {
            if (!a.Destroy(p))
                uncertain_ = true;
            return uncertain_ ? Result::Fault : Result::Unavailable;
        }
        object_ = p;
        inventory_ = s.inventory;
        cache_ = s.cache;
        owner_ = s.owner;
        id_ = id;
        if (!a.Notify(inventory_, owner_, object_, true)) {
            uncertain_ = true;
            return Result::Fault;
        }
        return Result::Added;
    }
    Result Insert(Adapter& a, int charmId = 1, int seed = 1) {
        return InsertImpl(a, charmId, seed, false);
    }
    Result InsertSticker(Adapter& a, int kit = 1) {
        return InsertImpl(a, kit, 0, true);
    }
    Result Erase(Adapter& a) {
        if (uncertain_)
            return Result::Fault;
        if (!object_)
            return Result::Idle;
        Snapshot s;
        if (!a.Capture(s))
            return Result::Unavailable;
        if (s.inventory != inventory_ || s.cache != cache_ || !sameOwner(s.owner, owner_)) {

            uncertain_ = true;
            return Result::Conflict;
        }
        if (std::find(s.objects.begin(), s.objects.end(), object_) == s.objects.end()) {

            Forget();
            return Result::Removed;
        }
        Item i;
        if (!a.ItemInfo(object_, i) || i.id != id_) {
            uncertain_ = true;
            return Result::Conflict;
        }
        if (!a.Notify(inventory_, owner_, object_, false)) {
            uncertain_ = true;
            return Result::Fault;
        }
        bool removed = false;
        if (!a.Remove(cache_, object_, removed) || !removed) {
            uncertain_ = true;
            return Result::Fault;
        }
        if (!a.Destroy(object_)) {
            uncertain_ = true;
            return Result::Fault;
        }
        Forget();
        return Result::Removed;
    }
};
}
