#pragma once

#include "watermark_hud_patterns.h"
namespace menu::glove_inmatch {
inline std::uintptr_t ResolveBodyGroup(const HudScanImage& image) {
    auto sites = image.Find("E8 ? ? ? ? EB 0C 48 8B CF", true, 2);
    auto funcs =
        image.Find("48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 41 8B F8 48 8B F2 48 8B D9 E8 ? ? ? ? 48 85 "
                   "C0 74 ? 48 8B D6 48 8B C8 E8 ? ? ? ? 85 C0 78 ? 44 8B C7 8B D0 48 8B CB E8 ? ? ? ?",
                   true, 2);
    if (sites.size() != 1 || funcs.size() != 1 || image.Rip(sites[0], 1, 5) != funcs[0] ||
        !image.Contains(funcs[0], 1, 0x20000000))
        return 0;
    return funcs[0];
}
}
