#pragma once

#include <cstdint>
#include <string>
namespace menu::local_inventory_probe {
inline constexpr char ItemCacheCaller[] = "49 8B 4E 68 BA 01 00 00 00 C7 45 1F FF FF FF FF 44 89 7D 23 "
                                          "C7 45 27 FF FF FF FF E8 ? ? ? ? 48 8B F8 48 85 C0";
inline constexpr char LocalInventoryCaller[] = "66 41 C7 46 64 01 01 E8 ? ? ? ? 48 8B C8 48 8B 10 "
                                               "FF 92 40 02 00 00 49 3B C6";
inline constexpr char ItemFactory[] = "48 83 EC 28 B9 48 00 00 00 E8 ? ? ? ? 48 85 C0 74 ? "
                                      "48 8D 0D ? ? ? ? C7 40 32 00 00 FF 00";
inline constexpr char DynamicSetterThunk[] =
    "E9 ? ? ? ? CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC 49 8B C0 48 8B CA 48 8B D0";
inline constexpr char SchemaAttributeCaller[] =
    "E8 ? ? ? ? 48 85 C0 74 ? E8 ? ? ? ? 0F B7 14 3B 48 8B C8 E8 ? ? ? ? 0F B6 48";
inline constexpr char SchemaLookupBody[] =
    "85 D2 78 ? 3B 91 50 01 00 00 7D ? 48 8B 81 58 01 00 00 48 63 D2 48 8B 04 D0 C3";
inline constexpr char SchemaGetterCaller[] =
    "E8 ? ? ? ? 0F B7 0B 3B 88 50 01 00 00 7D ? 48 8B 80 58 01 00 00 48 8B 0C C8";
struct Bindings {
    std::uintptr_t findItemCache = 0, managerGetter = 0, itemFactory = 0, schemaGetter = 0,
                   attributeLookup = 0, dynamicSetter = 0;
};
template <class Image> bool Resolve(const Image& image, Bindings& out, std::string& reason) {
    out = {};
    auto c = image.Find(ItemCacheCaller, true, 2);
    auto m = image.Find(LocalInventoryCaller, true, 2);
    auto f = image.Find(ItemFactory, true, 2);
    if (c.size() != 1 || m.size() != 1 || f.size() != 1) {
        reason = "required signature missing or ambiguous";
        return false;
    }
    const auto cache = image.Rip(c[0] + 27, 1, 5), manager = image.Rip(m[0] + 7, 1, 5);
    if (!image.Contains(cache, 1, 0x20000000, 0) || !image.Contains(manager, 8, 0x20000000, 0) ||
        !image.Contains(f[0], 1, 0x20000000, 0)) {
        reason = "target outside executable section";
        return false;
    }
    unsigned char get[8]{};
    if (!image.Bytes(manager, get, sizeof(get)) || get[0] != 0x48 || get[1] != 0x8d || get[2] != 0x05 ||
        get[7] != 0xc3) {
        reason = "manager getter form does not match";
        return false;
    }
    auto global = image.Rip(manager, 3, 7);
    if (!image.Contains(global, 8, 0x80000000, 0x20000000)) {
        reason = "manager global is not writable data";
        return false;
    }
    auto th = image.Find(DynamicSetterThunk, true, 2), ac = image.Find(SchemaAttributeCaller, true, 2);
    auto body = image.Find(SchemaLookupBody, true, 2), gc = image.Find(SchemaGetterCaller, true, 16);
    if (th.size() != 1 || ac.size() != 1 || body.size() != 1 || gc.size() < 2 || gc.size() >= 16) {
        reason = "schema or setter signature missing/ambiguous";
        return false;
    }
    const auto setter = image.Rip(th[0], 1, 5), lookup = image.Rip(ac[0], 1, 5),
               getter = image.Rip(gc[0], 1, 5);
    if (lookup != body[0] || !image.Contains(setter, 1, 0x20000000, 0) ||
        !image.Contains(getter, 1, 0x20000000, 0)) {
        reason = "schema/setter target cross-check failed";
        return false;
    }
    for (auto call : gc)
        if (image.Rip(call, 1, 5) != getter) {
            reason = "schema getter callers disagree";
            return false;
        }
    out = {cache, manager, f[0], getter, lookup, setter};
    reason = "static caller/factory cross-checks passed; runtime not verified";
    return true;
}
}
