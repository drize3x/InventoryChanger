#pragma once

#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
namespace menu::charm {
struct Values {
    int id = 0, seed = 0;
    float x = 0, y = 0, z = 0;
};
struct Attribute {
    const char* name;
    float value;
};
inline float IntBits(std::uint32_t value) {
    float out;
    static_assert(sizeof(out) == sizeof(value));
    std::memcpy(&out, &value, sizeof(out));
    return out;
}
inline bool Valid(const Values& v) {
    return v.id >= 0 && v.id <= 2000000 && v.seed >= 0 && v.seed <= 100000 && std::isfinite(v.x) &&
           std::isfinite(v.y) && std::isfinite(v.z) && std::abs(v.x) <= 25 && std::abs(v.y) <= 10 &&
           std::abs(v.z) <= 25;
}
inline bool Encode(const Values& v, std::array<Attribute, 5>& out) {
    if (!Valid(v))
        return false;
    out = {{{"keychain slot 0 id", IntBits(static_cast<std::uint32_t>(v.id))},
            {"keychain slot 0 seed", IntBits(static_cast<std::uint32_t>(v.seed))},
            {"keychain slot 0 offset x", v.x},
            {"keychain slot 0 offset y", v.y},
            {"keychain slot 0 offset z", v.z}}};
    return true;
}
}
