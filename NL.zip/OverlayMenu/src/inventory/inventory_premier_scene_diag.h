#pragma once

#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
namespace menu::premier_scene_diag {
struct Sample {
    unsigned stage = 0, namesMask = 0, foundMask = 0, recordMode = 0, candidates = 0, directFlags = 0,
             listFlags = 0;
    int color = -1, bars = -1, renderCount = -1;
    std::array<std::array<float, 4>, 6> values{};
};
inline constexpr std::array<std::uint32_t, 6> ShaderNames{
    {0x6bae020fu, 0x5ddc820du, 0x3097b936u, 0xf4a1f1ccu, 0xd3c57830u, 0x8ac5d5e3u}};
template <class Reader>
Sample Read(std::uintptr_t entity, std::uint32_t handle, const std::array<std::uint32_t, 6>& names, int color,
            int bars, Reader read) {
    Sample s{};
    s.color = color;
    s.bars = bars;
    for (unsigned i = 0; i < 6; ++i)
        if (names[i] == ShaderNames[i])
            s.namesMask |= 1u << i;
    auto r = [&](std::uintptr_t a, auto& x) {
        return a && a <= std::numeric_limits<std::uintptr_t>::max() - sizeof(x) && read(a, &x, sizeof(x));
    };
    auto add = [](std::uintptr_t a, std::uintptr_t b) {
        return a && a <= std::numeric_limits<std::uintptr_t>::max() - b ? a + b : std::uintptr_t(0);
    };
    if (!entity)
        return s;
    s.stage = 1;
    std::uintptr_t node = 0, owner = 0, scene = 0, map = 0;
    if (!r(add(entity, 0x330), node) || !node)
        return s;
    s.stage = 2;
    if (!r(add(node, 0x30), owner) || owner != entity)
        return s;
    s.stage = 3;

    auto check = [&](std::uintptr_t candidate, unsigned& flags) {
        flags = 0;
        std::uintptr_t cn = 0, co = 0, obj = 0, nodeOwner = 0;
        std::uint32_t ch = 0;
        if (!candidate)
            return false;
        flags |= 1;
        if (!r(candidate, cn) || !cn)
            return false;
        flags |= 2;
        if (cn == node)
            flags |= 4;
        if (r(add(candidate, 0x28), co) && co == entity)
            flags |= 8;
        if (r(add(cn, 0x30), nodeOwner) && nodeOwner == entity)
            flags |= 16;
        if (!r(add(candidate, 0x20), obj) || !obj)
            return false;
        flags |= 32;
        if (r(add(obj, 0xc0), ch) && ch == handle)
            flags |= 64;
        if ((flags & (8 | 16)) != (8 | 16))
            return false;
        ++s.candidates;
        if (!(flags & 64))
            return false;
        scene = obj;
        return true;
    };
    std::uintptr_t direct = 0;
    if (r(add(node, 0x218), direct) && check(direct, s.directFlags)) {
        s.recordMode = 1;
    } else {
        s.stage = 10;
        std::uintptr_t component = 0, list = 0;
        if (!r(add(entity, 0x338), component) || !component)
            return s;
        s.stage = 11;
        if (!r(add(component, 0x38), s.renderCount) || s.renderCount < 1 || s.renderCount > 128)
            return s;
        s.stage = 12;
        if (!r(add(component, 0x40), list) || !list)
            return s;
        s.stage = 13;
        for (int i = 0; i < s.renderCount; ++i) {
            std::uintptr_t candidate = 0;
            if (!r(add(list, std::uintptr_t(i) * sizeof(candidate)), candidate)) {
                s.stage = 14;
                return s;
            }
            unsigned flags = 0;
            if (check(candidate, flags)) {
                s.listFlags |= flags;
                s.recordMode = 2;
                break;
            }
            s.listFlags |= flags;
        }
        if (!scene)
            return s;
    }
    s.stage = 7;
    if (!r(add(scene, 0xa8), map) || !map)
        return s;
    s.stage = 8;
    auto slots = [&](std::uintptr_t base, unsigned count, std::uintptr_t keys, std::uintptr_t values) {
        for (unsigned i = 0; i < count; ++i) {
            std::uint32_t k = 0;
            if (!r(add(base, keys + i * 4), k))
                return false;
            for (unsigned j = 0; j < 6; ++j)
                if (k && k == ShaderNames[j]) {
                    std::array<float, 4> v{};
                    if (!r(add(base, values + i * 16), v))
                        return false;
                    s.values[j] = v;
                    s.foundMask |= 1u << j;
                }
        }
        return true;
    };
    if (!slots(map, 8, 0, 0x20))
        return s;
    std::uintptr_t chain = 0;
    if (!r(add(map, 0xa8), chain))
        return s;
    for (unsigned i = 0; chain && i < 64; ++i) {
        if (!slots(chain, 4, 0x10, 0x20))
            return s;
        std::uintptr_t next = 0;
        if (!r(chain, next) || next == chain)
            return s;
        chain = next;
    }
    if (chain)
        return s;
    s.stage = 9;
    return s;
}
}
