#pragma once

#include "menu_core.h"
#include "inventory_apply.h"
#include "inventory_color_composite.h"
#include <array>
#include <map>
namespace menu::knife_experiment {
inline std::uint32_t HashString(const std::string& s) {
    std::uint32_t h = 0x31415926u ^ std::uint32_t(s.size()), k = 0;
    constexpr std::uint32_t m = 0x5bd1e995u;
    std::size_t i = 0;
    while (i + 4 <= s.size()) {
        std::memcpy(&k, s.data() + i, 4);
        k *= m;
        k ^= k >> 24;
        k *= m;
        h *= m;
        h ^= k;
        i += 4;
    }
    switch (s.size() - i) {
    case 3:
        h ^= std::uint32_t((unsigned char)s[i + 2]) << 16;
        [[fallthrough]];
    case 2:
        h ^= std::uint32_t((unsigned char)s[i + 1]) << 8;
        [[fallthrough]];
    case 1:
        h ^= (unsigned char)s[i];
        h *= m;
    }
    h ^= h >> 13;
    h *= m;
    h ^= h >> 15;
    return h;
}
inline std::uint32_t Hash(int id) {
    return HashString(std::to_string(id));
}
inline bool KnownKnifeToken(int def, std::uint32_t token) {
    const auto* model = InventoryKnife(def);
    return model && (token == Hash(def) || token == HashString("weapon_knife") ||
                     token == HashString("weapon_knife_t") || token == HashString(model->id));
}
inline bool ModelPath(const std::string& s) {
    if (s.size() < 21 || s.size() > 240 || s.compare(0, 15, "weapons/models/") != 0 ||
        s.substr(s.size() - 5) != ".vmdl" || s.find("..") != std::string::npos)
        return false;
    for (unsigned char c : s)
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '/' ||
              c == '_' || c == '-' || c == '.'))
            return false;
    return true;
}
struct Choice {
    int def = 0;
    std::string path;
    InventoryWeaponTarget finish;
    inventory_color::Palette palette{};
    bool hasFinish = false;
};
struct Plan {
    std::array<Choice, 2> side;
    std::map<int, std::string> models;
};
struct Adapter : InventoryMemory {
    virtual bool Rebuild(std::uintptr_t, const std::string&) = 0;
    virtual bool Subclass(std::uintptr_t) = 0;
    virtual void SetPaintPalette(const inventory_color::Palette&, int, int) {}
    virtual bool RefreshPaintPalette(std::uintptr_t, std::uintptr_t) { return false; }
    virtual int Skin(std::uintptr_t, std::uintptr_t, const InventoryWeaponTarget&) {
        return 1;
    }
    virtual bool RestoreSkin(std::uintptr_t, std::uintptr_t) {
        return true;
    }
    virtual void ForgetSkin() {}
    virtual void RefreshRestored(std::uintptr_t, std::uintptr_t) {}
};
struct Stats {
    const char* stage = "idle";
    int team = -1, from = 0, to = 0, paint = 0;
    std::uint32_t handle = 0;
    unsigned changes = 0, failures = 0, models = 0;
    int skin = 1;
    std::uint32_t token = 0, expected = 0;
};
class Controller {
    struct Owned {
        std::uint32_t handle = 0;
        std::uintptr_t entity = 0, pawn = 0;
        std::uint16_t def = 0, appliedDef = 0;
        std::uint32_t subclass = 0;
        std::string path, appliedPath;
        InventoryWeaponSnapshot fields;
        InventoryWeaponTarget appliedFinish;
        inventory_color::Palette appliedPalette{};
        bool appliedHasFinish = false;
    };
    Owned own_{};
    bool fault_ = false;
    std::uint64_t paletteRetryAt_ = 0;
    template <class T> static bool Set(Adapter& m, std::uintptr_t p, const T& v) {
        T x{};
        return m.Get(p, x) && (std::memcmp(&x, &v, sizeof v) == 0 || m.Write(p, &v, sizeof v));
    }
    static bool ReadFields(Adapter& m, const InventoryOffsets& o, std::uintptr_t e,
                           InventoryWeaponSnapshot& s) {
        auto v = e + o.attributeManager + o.item;
        return m.Get(e + o.fallbackPaintKit, s.paintKit) &&
               (!o.fallbackSeed || m.Get(e + o.fallbackSeed, s.seed)) &&
               (!o.fallbackWear || m.Get(e + o.fallbackWear, s.wear)) &&
               (!o.fallbackStatTrak || m.Get(e + o.fallbackStatTrak, s.statTrak)) &&
               (!o.itemIdHigh || m.Get(v + o.itemIdHigh, s.itemIdHigh)) &&
               (!o.entityQuality || m.Get(v + o.entityQuality, s.quality));
    }
    static bool WriteFields(Adapter& m, const InventoryOffsets& o, std::uintptr_t e,
                            const InventoryWeaponSnapshot& s) {
        auto v = e + o.attributeManager + o.item;
        return Set(m, e + o.fallbackPaintKit, s.paintKit) &&
               (!o.fallbackSeed || Set(m, e + o.fallbackSeed, s.seed)) &&
               (!o.fallbackWear || Set(m, e + o.fallbackWear, s.wear)) &&
               (!o.fallbackStatTrak || Set(m, e + o.fallbackStatTrak, s.statTrak)) &&
               (!o.itemIdHigh || Set(m, v + o.itemIdHigh, s.itemIdHigh)) &&
               (!o.entityQuality || Set(m, v + o.entityQuality, s.quality));
    }
    bool Restore(Adapter& m, const InventoryOffsets& o, std::uint32_t subclassOffset, Stats& s) {
        if (!own_.entity)
            return true;
        std::uint16_t current = 0;
        auto view = own_.entity + o.attributeManager + o.item;
        if (!m.Get(view + o.itemDefinition, current) || current != own_.appliedDef) {
            s.stage = "restore identity changed";
            own_ = {};
            return false;
        }
        if (!m.RestoreSkin(own_.entity, view)) {
            s.stage = "skin restore failed";
            fault_ = true;
            ++s.failures;
            return false;
        }
        bool ok = Set(m, view + o.itemDefinition, own_.def) &&
                  Set(m, own_.entity + subclassOffset, own_.subclass) &&
                  WriteFields(m, o, own_.entity, own_.fields);
        if (ok) {
            ok = m.Subclass(own_.entity) && m.Rebuild(own_.entity, own_.path);
            if (ok)
                m.RefreshRestored(own_.entity, view);
        }
        own_ = {};
        paletteRetryAt_ = 0;
        if (!ok) {
            fault_ = true;
            ++s.failures;
            s.stage = "restore failed";
        }
        return ok;
    }

public:
    Stats Tick(Adapter& m, const InventoryOffsets& o, std::uint32_t subclassOffset, std::uintptr_t controller,
               const Plan& plan, bool enabled, std::uint64_t nowMs = 0) {
        Stats s;
        s.models = unsigned(plan.models.size());
        if (fault_) {
            s.stage = "fault latched";
            return s;
        }
        if (!o.Required() || !subclassOffset || !controller) {
            s.stage = "schema/controller unavailable";
            return s;
        }
        std::uint32_t ph = 0;
        if (!m.Get(controller + o.pawnHandle, ph) || !ph || ph == 0xffffffffu) {
            m.ForgetSkin();
            own_ = {};
            s.stage = "no pawn";
            return s;
        }
        auto pawn = m.Entity(ph);
        if (!pawn) {
            m.ForgetSkin();
            own_ = {};
            s.stage = "stale pawn";
            return s;
        }
        std::uint8_t team = 0;
        std::uintptr_t svc = 0, arr = 0;
        std::int32_t count = 0;
        if (!m.Get(pawn + o.team, team) || !m.Get(pawn + o.weaponServices, svc) || !svc ||
            !m.Get(svc + o.myWeapons, count) || count < 0 || count > 64 ||
            !m.Get(svc + o.myWeapons + 8, arr) || (count && !arr)) {
            s.stage = "weapon list unavailable";
            return s;
        }
        s.team = team == 3 ? InventoryCT : team == 2 ? InventoryT : -1;
        if (s.team < 0) {
            s.stage = "no team";
            return s;
        }
        std::uint32_t handle = 0;
        std::uintptr_t ent = 0;
        std::uint16_t def = 0;
        for (int i = 0; i < count; ++i) {
            std::uint32_t h = 0;
            std::uint16_t d = 0;
            if (!m.Get(arr + 4 * i, h) || !h || h == 0xffffffffu)
                continue;
            auto e = m.Entity(h);
            if (!e || !m.Get(e + o.attributeManager + o.item + o.itemDefinition, d))
                continue;
            if (InventoryKnife(int(d))) {
                handle = h;
                ent = e;
                def = d;
                break;
            }
        }
        if (own_.entity && (pawn != own_.pawn || handle != own_.handle || ent != own_.entity)) {
            m.ForgetSkin();
            own_ = {};
        }
        if (!ent) {
            s.stage = "no knife";
            return s;
        }

        if (own_.entity && def != own_.appliedDef) {
            m.ForgetSkin();
            own_ = {};
        }
        const auto& choice = plan.side[std::size_t(s.team)];
        s.from = def;
        s.to = choice.def;
        s.handle = handle;
        s.paint = choice.hasFinish ? choice.finish.paintKit : 0;
        if (!enabled || !choice.def) {
            if (own_.entity)
                Restore(m, o, subclassOffset, s);
            else
                s.stage = "disabled";
            return s;
        }
        if (!InventoryKnife(choice.def) || !ModelPath(choice.path)) {
            s.stage = "target model unavailable";
            return s;
        }
        const auto sameFinish = [&]() {
            const auto& a = own_.appliedFinish;
            const auto& b = choice.finish;
            return own_.appliedHasFinish == choice.hasFinish &&
                   (!choice.hasFinish || (a.paintKit == b.paintKit && a.seed == b.seed && a.wear == b.wear &&
                                          a.statTrak == b.statTrak && a.quality == b.quality));
        };
        if (own_.entity &&
            (own_.appliedDef != choice.def || own_.appliedPath != choice.path || !sameFinish())) {
            if (!Restore(m, o, subclassOffset, s))
                return s;
            if (!m.Get(ent + o.attributeManager + o.item + o.itemDefinition, def)) {
                s.stage = "restore read failed";
                return s;
            }
        }
        if (own_.entity) {
            if (choice.hasFinish) {
                const auto view = ent + o.attributeManager + o.item;
                m.SetPaintPalette(own_.appliedPalette, choice.def, choice.finish.paintKit);
                s.skin = m.Skin(ent, view, choice.finish);
                if (s.skin == 0 && own_.appliedPalette != choice.palette &&
                    (!nowMs || !paletteRetryAt_ || nowMs >= paletteRetryAt_)) {
                    m.SetPaintPalette(choice.palette, choice.def, choice.finish.paintKit);
                    if (m.RefreshPaintPalette(ent, view)) {
                        own_.appliedPalette = choice.palette;
                        paletteRetryAt_ = 0;
                    } else {
                        m.SetPaintPalette(own_.appliedPalette, choice.def, choice.finish.paintKit);
                        paletteRetryAt_ = nowMs ? nowMs + 1000 : 0;
                        s.skin = 3;
                    }
                }
            }
            s.stage = "applied";
            s.from = own_.def;
            s.token = own_.subclass;
            s.expected = Hash(own_.def);
            return s;
        }
        auto it = plan.models.find(def);
        if (it == plan.models.end() || !ModelPath(it->second)) {
            s.stage = "original model unavailable";
            return s;
        }
        std::uint32_t token = 0;
        s.expected = Hash(def);
        if (!m.Get(ent + subclassOffset, token)) {
            s.stage = "subclass unreadable";
            return s;
        }
        s.token = token;
        if (!KnownKnifeToken(def, token)) {
            s.stage = "subclass mismatch";
            return s;
        }
        Owned candidate;
        candidate.handle = handle;
        candidate.entity = ent;
        candidate.pawn = pawn;
        candidate.def = def;
        candidate.appliedDef = std::uint16_t(choice.def);
        candidate.subclass = token;
        candidate.path = it->second;
        candidate.appliedPath = choice.path;
        candidate.appliedFinish = choice.finish;
        candidate.appliedPalette = choice.palette;
        candidate.appliedHasFinish = choice.hasFinish;
        if (!ReadFields(m, o, ent, candidate.fields)) {
            s.stage = "snapshot unavailable";
            return s;
        }
        own_ = candidate;
        paletteRetryAt_ = 0;
        InventoryWeaponSnapshot desired = candidate.fields;
        desired.paintKit = 0;
        desired.seed = 0;
        desired.wear = 0.f;
        desired.statTrak = -1;
        desired.itemIdHigh = 0xffffffffu;
        desired.quality = InventoryQualityUnusual;
        if (choice.hasFinish) {
            desired.paintKit = choice.finish.paintKit;
            desired.seed = choice.finish.seed;
            desired.wear = choice.finish.wear;
            desired.statTrak = choice.finish.statTrak;
            desired.itemIdHigh = 0xffffffffu;
            desired.quality = choice.finish.quality;
        }
        const auto view = ent + o.attributeManager + o.item;
        const auto hash = Hash(choice.def);
        bool ok = Set(m, view + o.itemDefinition, std::uint16_t(choice.def)) &&
                  Set(m, ent + subclassOffset, hash) && WriteFields(m, o, ent, desired);
        if (ok)
            ok = m.Subclass(ent) && m.Rebuild(ent, choice.path);
        if (!ok) {
            ++s.failures;
            s.stage = "apply failed";
            Restore(m, o, subclassOffset, s);
            fault_ = true;
            return s;
        }
        if (choice.hasFinish) {
            m.SetPaintPalette(choice.palette, choice.def, choice.finish.paintKit);
            s.skin = m.Skin(ent, view, choice.finish);
        }
        s.stage = "applied";
        s.changes = 1;
        return s;
    }
};
}
