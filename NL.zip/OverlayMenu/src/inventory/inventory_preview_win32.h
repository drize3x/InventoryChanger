#pragma once
#include "inventory_ui.h"
#ifndef MENU_STUDIO_INVENTORY_PREVIEW_TEST
#include "players_native_preview_win32.h"
#include "preview_image_cache_win32.h"
#include "presets_gpu.h"
#endif
#include <limits>
namespace menu {

class InventoryPreviewFrame;
class InventoryPreviewRuntime {
    friend class InventoryPreviewFrame;
    PreviewImageCache image_;
    PreviewImageCache playerImage_;
    NativePreviewRequest playerScene_{};
    unsigned playerRoot_ = 0;
    bool havePlayerScene_ = false;
    NativePreviewRequest scene_{};
    bool haveScene_ = false;

    NativePreviewRequest liveCharm_{};
    unsigned liveRoot_ = 0;
    std::uint64_t liveSince_ = 0;
    bool liveActive_ = false, liveFrameReady_ = false;
    NativePreviewRequest SelectLiveCharm(NativePreviewRequest next, bool dragging, unsigned root,
                                         std::uint64_t now) {
        if (!dragging || !PreviewIsItem(next) || next.charm.id <= 0 || !PreviewRequestValid(next)) {
            liveActive_ = false;
            return next;
        }
        auto comparable = next;
        comparable.charm = liveCharm_.charm;
        const bool identity = liveActive_ && liveRoot_ == root && next.charm.id == liveCharm_.charm.id &&
                              next.charm.seed == liveCharm_.charm.seed &&
                              PreviewSameScene(comparable, liveCharm_);
        if (!identity) {
            liveCharm_ = next;
            liveRoot_ = root;
            liveSince_ = now;
            liveActive_ = true;
            liveFrameReady_ = false;
        } else if (!PreviewCharmSame(next.charm, liveCharm_.charm) && now >= liveSince_ &&
                   ((liveFrameReady_ && now - liveSince_ >= 125) || now - liveSince_ >= 750)) {
            liveCharm_ = next;
            liveSince_ = now;
            liveFrameReady_ = false;
        }
        next.charm = liveCharm_.charm;
        return next;
    }

    NativePreviewRequest liveSticker_{};
    unsigned liveStickerRoot_ = 0;
    std::uint64_t liveStickerSince_ = 0;
    int liveStickerSlot_ = -1;
    bool liveStickerActive_ = false, liveStickerFrameReady_ = false;
    static bool StickerMoveOnly(const NativePreviewRequest& a, const NativePreviewRequest& b) {
        if (!PreviewIsItem(a) || !PreviewIsItem(b))
            return false;
        bool moved = false;
        for (std::size_t i = 0; i < a.decorations.stickers.size(); ++i) {
            const auto& x = a.decorations.stickers[i];
            const auto& y = b.decorations.stickers[i];
            if (x.id != y.id)
                return false;
            if (!(x == y))
                moved = true;
        }
        auto test = a;
        test.decorations.stickers = b.decorations.stickers;
        return moved && PreviewSameScene(test, b);
    }
    static bool StickerStageMatch(NativePreviewRequest a, const NativePreviewRequest& b) {

        a.itemWidth = b.itemWidth;
        a.itemHeight = b.itemHeight;
        return PreviewSameScene(a, b);
    }
    NativePreviewRequest SelectLiveSticker(NativePreviewRequest next, bool dragging, int slot, unsigned root,
                                           std::uint64_t now) {
        if (!dragging || slot < 0 || slot >= 5 || !PreviewIsItem(next) || !PreviewRequestValid(next) ||
            next.decorations.stickers[std::size_t(slot)].id <= 0) {
            liveStickerActive_ = false;
            return next;
        }
        auto comparable = next;
        comparable.decorations.stickers[std::size_t(slot)] =
            liveSticker_.decorations.stickers[std::size_t(slot)];
        const bool same = liveStickerActive_ && liveStickerRoot_ == root && liveStickerSlot_ == slot &&
                          next.decorations.stickers[std::size_t(slot)].id ==
                              liveSticker_.decorations.stickers[std::size_t(slot)].id &&
                          StickerStageMatch(comparable, liveSticker_);
        if (!same) {
            liveSticker_ = next;
            liveStickerRoot_ = root;
            liveStickerSlot_ = slot;
            liveStickerSince_ = now;
            liveStickerActive_ = true;
            liveStickerFrameReady_ = false;
        } else if (!(next.decorations.stickers[std::size_t(slot)] ==
                     liveSticker_.decorations.stickers[std::size_t(slot)]) &&
                   now >= liveStickerSince_ &&
                   ((liveStickerFrameReady_ && now - liveStickerSince_ >= 125) ||
                    now - liveStickerSince_ >= 750)) {
            liveSticker_ = next;
            liveStickerSince_ = now;
            liveStickerFrameReady_ = false;
        }
        next.decorations.stickers[std::size_t(slot)] = liveSticker_.decorations.stickers[std::size_t(slot)];
        return next;
    }
    unsigned rootRevision_ = 0;
    std::uint64_t charmRetainUntil_ = 0;
    NativePreviewRequest quality_{};
    unsigned qualityRoot_ = 0;
    std::uint64_t qualityStarted_ = 0;
    bool qualityActive_ = false, qualityReady_ = false, qualityFailed_ = false;
    ID3D11DeviceContext* context_ = nullptr;
    void Bind(ID3D11DeviceContext* context) {
        if (context_ != context) {
            Reset();
            context_ = context;
        }
    }
    void Select(const NativePreviewRequest& r, unsigned rootRevision, bool keepResize = false) {
        if (!haveScene_ || !PreviewSameScene(r, scene_) || rootRevision_ != rootRevision) {
            const bool sameBase = haveScene_ && rootRevision_ == rootRevision && PreviewIsItem(r) &&
                                  PreviewIsItem(scene_) && r.itemDefinition == scene_.itemDefinition &&
                                  r.paintKit == scene_.paintKit && r.itemMusic == scene_.itemMusic &&
                                  r.itemActiveIndex == scene_.itemActiveIndex;
            const bool sameCharmMove = sameBase && r.charm.id > 0 && r.charm.id == scene_.charm.id &&
                                       !PreviewCharmSame(r.charm, scene_.charm);
            const bool sameStickerMove = sameBase && StickerMoveOnly(r, scene_);
            auto modeNormalized = r;
            modeNormalized.stickerLiveSlot = scene_.stickerLiveSlot;
            modeNormalized.decorations.stickers = scene_.decorations.stickers;
            bool sameStickerIds = true;
            for (std::size_t i = 0; i < r.decorations.stickers.size(); ++i)
                if (r.decorations.stickers[i].id != scene_.decorations.stickers[i].id)
                    sameStickerIds = false;
            const bool sameStickerTransition = sameBase && sameStickerIds &&
                                               r.stickerLiveSlot != scene_.stickerLiveSlot &&
                                               PreviewSameScene(modeNormalized, scene_);
            const bool sameResize = sameBase && keepResize && PreviewCharmSame(r.charm, scene_.charm);
            if (sameCharmMove || sameStickerMove || sameStickerTransition) {
                const auto now = GetTickCount64();
                charmRetainUntil_ = now + 3000;
            } else if (PreviewIsItem(r) && !sameResize) {
                charmRetainUntil_ = 0;
                InventoryMusicReady().store(0, std::memory_order_release);
                image_.Reset();
            }
            scene_ = r;
            rootRevision_ = rootRevision;
            haveScene_ = true;
        }
        if (!PreviewIsItem(r) &&
            (!havePlayerScene_ || !PreviewSameScene(r, playerScene_) || playerRoot_ != rootRevision)) {
            playerImage_.Reset();
            playerScene_ = r;
            playerRoot_ = rootRevision;
            havePlayerScene_ = true;
        }
    }
    NativePreviewRequest ChooseQuality(NativePreviewRequest normalRequest, NativePreviewRequest high,
                                       unsigned root, std::uint64_t now) {
        if (!PreviewRequestValid(high)) {
            qualityActive_ = false;
            return normalRequest;
        }
        if (!qualityActive_ || qualityRoot_ != root || !PreviewSameScene(quality_, high)) {
            quality_ = high;
            qualityRoot_ = root;
            qualityStarted_ = now;
            qualityActive_ = true;
            qualityReady_ = false;
            qualityFailed_ = false;
        }
        if (!qualityReady_ && now >= qualityStarted_ && now - qualityStarted_ >= 2500)
            qualityFailed_ = true;
        return qualityFailed_ ? normalRequest : high;
    }

public:
    void Reset() {
        InventoryMusicReady().store(0, std::memory_order_release);
        image_.Reset();
        playerImage_.Reset();
        playerScene_ = {};
        playerRoot_ = 0;
        havePlayerScene_ = false;
        haveScene_ = false;
        scene_ = {};
        rootRevision_ = 0;
        charmRetainUntil_ = 0;
        context_ = nullptr;
        qualityActive_ = qualityReady_ = qualityFailed_ = false;
        liveActive_ = liveFrameReady_ = false;
        liveStickerActive_ = liveStickerFrameReady_ = false;
        liveStickerSlot_ = -1;
    }
};

class InventoryPreviewFrame {
    InventoryPreviewRuntime& runtime_;
    NativePlayerPreview& native_;
    const InventoryUI& ui_;
    ID3D11DeviceContext* context_ = nullptr;
    bool allowed_ = false, used_ = false, drawn_ = false;
    NativePreviewRequest request_{};
    NativePlayerPreview::RequestFallback previousFallback_{};
    PresetNativePreviewSink sink_{};
    PresetNativePreviewSink* previousSink_ = nullptr;
    NativePreviewRequest Request() {
        const auto viewport = ui_.viewport;
        if (!allowed_ || !context_ || !InventoryPreviewBoxValid(viewport) ||
            double(viewport.w) > std::numeric_limits<int>::max() ||
            double(viewport.h) > std::numeric_limits<int>::max())
            return {};
        request_ = ui_.nativeItemPreview
                       ? InventoryItemRequest(
                             ui_.visible, ui_.bigPreview ? ui_.itemSourceBox : ui_.previewBox,
                             ui_.bigPreview ? viewport : ui_.itemPreviewClip, int(viewport.w),
                             int(viewport.h), ui_.nativeItemDefinition, ui_.nativeItemPaint, ui_.modelYaw,
                             ui_.modelPitch, ui_.scale, ui_.nativeItemMusic, ui_.nativeItemActiveIndex, false)
                       : InventoryPreviewRequest(ui_.visible, ui_.team, ui_.loadoutPreviewBox, ui_.pageBody,
                                                 int(viewport.w), int(viewport.h), ui_.scale);
        if (ui_.nativeItemPreview) {
            request_.premier = ui_.nativeItemPremier;
            for (std::size_t i = 0; i < request_.decorations.stickers.size(); ++i) {
                const auto& st = ui_.nativeItemStickers[i];
                request_.decorations.stickers[i] = {st.id, st.x, st.y, st.rotation};
            }
            const auto& c = ui_.nativeItemCharm;
            request_.charm = {c.id, c.pattern, c.x, c.y, c.z};
            request_.charmPlacementProbe = (ui_.moveMode == 0 && c.id > 0);

            const int slot = ui_.nativeStickerDragging ? ui_.stickerDragSlot : ui_.stickerMoveSlot;
            if (ui_.moveMode == 1 && slot >= 0 && slot < 5 &&
                request_.decorations.stickers[std::size_t(slot)].id > 0 && native_.StickerLiveReady()) {
                request_.stickerLiveSlot = slot;
                request_.stickerDragging = ui_.nativeStickerDragging;
            }
        }
        request_.charmLive = request_.charmPlacementProbe && native_.CharmLiveReady();
        if (!request_.charmLive)
            request_ = runtime_.SelectLiveCharm(request_, ui_.nativeItemPreview && ui_.charmDrag,
                                                native_.RootRevision(), GetTickCount64());
        request_ = runtime_.SelectLiveSticker(
            request_, ui_.nativeItemPreview && ui_.nativeStickerDragging && request_.stickerLiveSlot < 0,
            ui_.stickerDragSlot, native_.RootRevision(), GetTickCount64());

        if (ui_.nativeItemPreview && ui_.bigPreview && PreviewRequestValid(request_)) {
            auto high = InventoryBigQualityRequest(request_, ui_.previewBox, ui_.itemSourceBox, ui_.scale);
            request_ = runtime_.ChooseQuality(request_, high, native_.RootRevision(), GetTickCount64());
        } else
            runtime_.qualityActive_ = false;
        used_ = PreviewRequestValid(request_);
        if (used_)
            runtime_.Select(request_, native_.RootRevision(), ui_.nativeItemPreview && ui_.bigPreview);
        else
            runtime_.Reset();
        return request_;
    }
    static NativePreviewRequest Fallback(void* p) {
        return static_cast<InventoryPreviewFrame*>(p)->Request();
    }
    static void Surface(void* p, wm::RendererDX11& renderer, ID3D11RenderTargetView* target, int width,
                        int height, const PresetDraw& d, Box clip) {
        static_cast<InventoryPreviewFrame*>(p)->Draw(renderer, target, width, height, d, clip);
    }
    void Draw(wm::RendererDX11& renderer, ID3D11RenderTargetView* target, int width, int height,
              const PresetDraw& d, Box clip) {
        if (!used_ || !allowed_ || !PreviewRequestValid(request_) || width != request_.screenW ||
            height != request_.screenH || !InventoryPreviewBoxValid(d.box) ||
            !InventoryPreviewBoxValid(clip) || !std::isfinite(d.color.a) || d.color.a <= 0)
            return;
        const bool isPlayerSurface = d.nativePreviewTeam == 0 || d.nativePreviewTeam == 1;
        const bool frozenPlayer = PreviewIsItem(request_) && isPlayerSurface;

        if (frozenPlayer) {
            if (!runtime_.havePlayerScene_ || runtime_.playerRoot_ != native_.RootRevision() ||
                int(runtime_.playerScene_.terrorist) != d.nativePreviewTeam ||
                ui_.team != d.nativePreviewTeam)
                return;
        } else if (d.nativePreviewTeam != PreviewSurfaceTag(request_))
            return;
        if (!frozenPlayer) {
            drawn_ = true;

            runtime_.Select(request_, native_.RootRevision(), ui_.nativeItemPreview && ui_.bigPreview);
        }
        const auto now = GetTickCount64();
        auto& image = frozenPlayer || !PreviewIsItem(request_) ? runtime_.playerImage_ : runtime_.image_;
        if (!frozenPlayer && native_.Confirmed(request_)) {
            const bool copied =
                native_.WithFrame([&](ID3D11ShaderResourceView* source, const std::array<float, 4>& uv) {
                    return image.Copy(context_, source, uv, now);
                });
            if (copied) {
                runtime_.charmRetainUntil_ = 0;
                if (runtime_.liveActive_ && runtime_.liveRoot_ == native_.RootRevision() &&
                    PreviewSameScene(request_, runtime_.liveCharm_))
                    runtime_.liveFrameReady_ = true;
                if (runtime_.liveStickerActive_ && runtime_.liveStickerRoot_ == native_.RootRevision() &&
                    InventoryPreviewRuntime::StickerStageMatch(request_, runtime_.liveSticker_))
                    runtime_.liveStickerFrameReady_ = true;
            }
            if (copied && runtime_.qualityActive_ && !runtime_.qualityFailed_ &&
                runtime_.qualityRoot_ == native_.RootRevision() &&
                PreviewSameScene(request_, runtime_.quality_))
                runtime_.qualityReady_ = true;
        }
        const bool waiting = runtime_.qualityActive_ && !runtime_.qualityReady_ && !runtime_.qualityFailed_;
        const bool retainingCharm = runtime_.charmRetainUntil_ && now <= runtime_.charmRetainUntil_;
        auto* source = image.View(now, frozenPlayer ? std::numeric_limits<std::uint64_t>::max()
                                                    : (retainingCharm ? 3000
                                                       : waiting      ? 2500
                                                                      : 500));
        if (!frozenPlayer && request_.itemMusic)
            InventoryMusicReady().store(0, std::memory_order_release);
        if (source) {
            clip = PresetPixelClip(
                PresetIntersect(PresetIntersect(clip, d.box), {0, 0, float(width), float(height)}));
            if (clip.w <= 0 || clip.h <= 0)
                return;
            renderer.SetClip(clip.x, clip.y, clip.w, clip.h);
            const bool rendered = renderer.DrawExternalTexture(
                target, source, width, height, d.box.x, d.box.y, d.box.w, d.box.h, image.UV(),
                wm::TextureAlpha::Straight, std::min(1.f, d.color.a));
            renderer.ClearClip();
            if (frozenPlayer && rendered)
                drawn_ = true;
            if (!frozenPlayer && request_.itemMusic && rendered)
                InventoryMusicReady().store(request_.paintKit, std::memory_order_release);
        }
    }

public:
    InventoryPreviewFrame(InventoryPreviewRuntime& runtime, NativePlayerPreview& native,
                          const InventoryUI& ui, ID3D11DeviceContext* context, bool allowed)
        : runtime_(runtime), native_(native), ui_(ui), context_(context), allowed_(allowed) {
        runtime_.Bind(context_);
        previousFallback_ = native_.SetRequestFallback({Fallback, this});
        sink_ = {Surface, this};
        previousSink_ = PresetNativePreviewSink::current;
        PresetNativePreviewSink::current = &sink_;
    }
    InventoryPreviewFrame(const InventoryPreviewFrame&) = delete;
    InventoryPreviewFrame& operator=(const InventoryPreviewFrame&) = delete;
    ~InventoryPreviewFrame() {
        PresetNativePreviewSink::current = previousSink_;
        native_.SetRequestFallback(previousFallback_);
        if (!used_ || !drawn_)
            runtime_.Reset();
    }
};
}
