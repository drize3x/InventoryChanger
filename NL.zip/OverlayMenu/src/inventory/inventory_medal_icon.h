#pragma once

#include "inventory_team_icons.h"
namespace menu {
inline std::shared_ptr<const Canvas> InventoryDefaultMedalIcon() {
    static const std::shared_ptr<const Canvas> icon = []() -> std::shared_ptr<const Canvas> {
        static const std::string source =
            R"MENUSTUDIO_SVG(<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M23.2877 26.652C22.8494 26.5643 22.4986 26.8273 22.3233 27.178L21.0082 31.9999L17.3261 25.5999C20.2192 25.3369 22.8493 24.1972 24.9536 22.4436L28.1098 27.9668L23.2877 26.652Z" fill="white"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M11.1013 32L9.78624 27.1781C9.69853 26.8274 9.26019 26.5644 8.90957 26.6521L4.08771 27.9672L7.24397 22.444C9.34803 24.1974 11.9784 25.337 14.7837 25.6002L11.1013 32Z" fill="white"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M4 12.0987C4 5.43573 9.43573 0 16.0987 0C22.7616 0 28.1973 5.43573 28.1973 12.0987C28.1973 18.7616 22.7616 24.1973 16.0987 24.1973C9.43573 24.1973 4 18.7616 4 12.0987ZM17.6768 10.5205H21.5344C21.8851 10.5205 22.0605 10.9589 21.7974 11.1343L18.5537 13.4138L19.7811 17.1836C19.9564 17.5343 19.5181 17.7974 19.255 17.5343L16.0988 15.2549L12.9425 17.5343C12.6795 17.7974 12.2411 17.5343 12.3287 17.1836L13.5561 13.4138L10.3998 11.1343C10.1368 10.959 10.3121 10.5205 10.6629 10.5205H14.5205L15.7479 6.75067C15.8356 6.39995 16.3616 6.39995 16.4492 6.75067L17.6766 10.5205H17.6768Z" fill="white"/>
</svg>
)MENUSTUDIO_SVG";
        svg::Bitmap bitmap;
        if (!svg::Render(source, 32, 32, bitmap) || svg::IsBlank(bitmap))
            return {};
        return InventoryCanvasFromBitmap(bitmap);
    }();
    return icon;
}
}
