#pragma once

#include "inventory_glove_identity_pin.h"
#include <array>
#include <cstdint>
#include <cstring>
namespace menu::glove_inmatch {
struct Identity {
    std::uint64_t id = 0;
    std::uint32_t account = 0;
};
class IdentityOverride {
    using Bytes = std::array<unsigned char, 20>;
    std::uintptr_t address_ = 0;
    Bytes original_{}, written_{};
    bool held_ = false, uncertain_ = false;
    static Bytes Pack(Identity x) {
        Bytes b{};
        auto high = std::uint32_t(x.id >> 32), low = std::uint32_t(x.id);
        std::memcpy(b.data(), &x.id, 8);
        std::memcpy(b.data() + 8, &high, 4);
        std::memcpy(b.data() + 12, &low, 4);
        std::memcpy(b.data() + 16, &x.account, 4);
        return b;
    }

public:
    bool Held() const {
        return held_;
    }
    bool Uncertain() const {
        return uncertain_;
    }
    void Forget() {
        address_ = 0;
        held_ = false;
        uncertain_ = false;
        pinnedItem.store(0);
        uncertainIdentity.store(false);
        original_ = {};
        written_ = {};
    }
    template <class A> bool Apply(A& a, std::uintptr_t address, Identity x, bool& changed) {
        changed = false;
        if (uncertain_ || !address || !x.id || !x.account || (held_ && address != address_))
            return false;
        Bytes cur{};
        if (!a.Read(address, cur.data(), cur.size()))
            return false;
        if (held_ && cur != written_)
            return false;
        const auto next = Pack(x);
        if (!held_) {
            address_ = address;
            original_ = cur;
            written_ = cur;
            held_ = true;
        }
        if (cur == next) {
            pinnedItem.store(x.id);
            return true;
        }

        const bool ok = a.Write(address, next.data(), next.size());
        Bytes check{};
        if (!a.Read(address, check.data(), check.size())) {
            uncertain_ = true;
            uncertainIdentity.store(true);
            return false;
        }
        if (check == next) {
            written_ = next;
            pinnedItem.store(x.id);
            changed = cur != next;
            return ok;
        }
        if (check != cur) {
            uncertain_ = true;
            uncertainIdentity.store(true);
        }
        return false;
    }
    template <class A> bool Restore(A& a) {
        if (uncertain_)
            return false;
        if (!held_)
            return true;
        Bytes cur{};
        if (!a.Read(address_, cur.data(), cur.size()))
            return false;
        if (cur == written_ && cur != original_) {
            if (!a.Write(address_, original_.data(), original_.size()))
                return false;
            Bytes check{};
            if (!a.Read(address_, check.data(), check.size()) || check != original_)
                return false;
        }
        Forget();
        return true;
    }
};
}
