#pragma once
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
namespace menu::local_decorations {
struct Sticker {
    int id = 0;
    float x = 0, y = 0, rotation = 0;
    bool operator==(const Sticker& o) const {
        return id == o.id && x == o.x && y == o.y && rotation == o.rotation;
    }
};
struct Charm {
    int id = 0, seed = 0;
    float x = 0, y = 0, z = 0;
    bool operator==(const Charm& o) const {
        return id == o.id && seed == o.seed && x == o.x && y == o.y && z == o.z;
    }
};
struct Values {
    std::array<Sticker, 5> stickers{};
    Charm charm{};
    bool operator==(const Values& o) const {
        return stickers == o.stickers && charm == o.charm;
    }
};
inline bool Valid(const Values& v) {
    if (v.charm.id < 0 || v.charm.id > 2000000 || v.charm.seed < 0 || v.charm.seed > 100000 ||
        !std::isfinite(v.charm.x) || !std::isfinite(v.charm.y) || !std::isfinite(v.charm.z) ||
        std::abs(v.charm.x) > 25 || std::abs(v.charm.y) > 10 || std::abs(v.charm.z) > 25)
        return false;
    for (const auto& s : v.stickers)
        if (s.id < 0 || s.id > 2000000 || !std::isfinite(s.x) || !std::isfinite(s.y) ||
            !std::isfinite(s.rotation) || std::abs(s.x) > 10 || std::abs(s.y) > 10 ||
            std::abs(s.rotation) > 360)
            return false;
    return true;
}
inline bool Any(const Values& v) {
    if (v.charm.id > 0)
        return true;
    for (const auto& s : v.stickers)
        if (s.id > 0)
            return true;
    return false;
}
template <class Integer, class Real>
inline void ForEachAttribute(const Values& v, Integer integer, Real real) {
    for (int i = 0; i < 5; ++i) {
        const auto& st = v.stickers[std::size_t(i)];
        if (!st.id)
            continue;
        integer(113 + 4 * i, st.id);
        integer(290 + i, 0);
        real(114 + 4 * i, 0.f);
        real(115 + 4 * i, 1.f);
        real(116 + 4 * i, st.rotation);
        real(278 + 2 * i, st.x);
        real(279 + 2 * i, st.y);
    }
    const auto& c = v.charm;
    if (c.id) {
        integer(299, c.id);
        integer(306, c.seed);
        real(300, c.x);
        real(301, c.y);
        real(302, c.z);
    }
}
inline float Bits(std::uint32_t n) {
    float f;
    std::memcpy(&f, &n, 4);
    return f;
}
}
