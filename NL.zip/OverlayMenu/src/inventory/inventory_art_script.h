#pragma once
#include "inventory_artwork.h"
#include <sstream>
namespace menu {
inline std::string InventoryArtHost(std::uint64_t owner) {
    return "MenuStudioEcon_" + std::to_string(owner);
}
inline std::string InventoryArtChild(const AmbienceImageJob& job) {
    return "ms_econ_" + std::to_string(job.ticket);
}
inline std::string BuildInventoryArtScript(std::uint64_t owner, const std::vector<AmbienceImageJob>& jobs,
                                           bool remove = false) {
    std::ostringstream s;
    s << "(function(){try{var root=$.GetContextPanel(),id='" << InventoryArtHost(owner) << "',owner='"
      << owner
      << "',h=root.FindChildTraverse(id);if(h&&h.GetAttributeString('ms_econ_owner','')!==owner)return;";
    if (remove)
        s << "if(h&&h.IsValid())h.DeleteAsync(0);";
    else {
        s << R"JS(if(!h){h=$.CreatePanel('Panel',root,id);h.SetAttributeString('ms_econ_owner',owner);h.SetAttributeString('ms_econ_lease',String(Date.now()));h.hittest=false;h.hittestchildren=false;
 h.style.ignoreParentFlow='true';h.style.width='512px';h.style.height='384px';h.style.opacity='0';
 (function lease(){if(!h||!h.IsValid())return;if(Date.now()-Number(h.GetAttributeString('ms_econ_lease','0'))>2000){h.DeleteAsync(0);return;}$.Schedule(.25,lease);})();}
 h.SetAttributeString('ms_econ_lease',String(Date.now()));var wanted=[)JS";
        bool comma = false;
        for (const auto& job : jobs)
            if (InventoryEconPath(job.name) && job.ticket) {
                if (comma)
                    s << ",";
                comma = true;
                s << "{id:'" << InventoryArtChild(job) << "',src:'file://{images}/" << job.name
                  << (job.name.size() >= 4 && job.name.compare(job.name.size() - 4, 4, ".svg") == 0 ? ""
                                                                                                    : ".png")
                  << "'}";
            }
        s << R"JS(];var keep={};wanted.forEach(function(j){keep[j.id]=true;var p=h.FindChildTraverse(j.id);if(!p){p=$.CreatePanel('Image',h,j.id);p.hittest=false;p.hittestchildren=false;p.style.ignoreParentFlow='true';p.style.width='512px';p.style.height='384px';p.SetImage(j.src);}});
 h.Children().forEach(function(p){if(!keep[p.id])p.DeleteAsync(0);});)JS";
    }
    s << "}catch(e){}})();";
    return s.str();
}
}
