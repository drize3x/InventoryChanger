#pragma once

#include "watermark_hud_patterns.h"
#include "menu_core.h"
#include <cmath>
#include <cstddef>
#include <cstdint>
namespace menu::inventory_color {
struct Palette {
    std::uint32_t rgba[4]{};
    unsigned mask = 0;
    bool operator==(const Palette& o) const {
        if (mask != o.mask)
            return false;
        for (int i = 0; i < 4; ++i)
            if ((mask & (1u << i)) && rgba[i] != o.rgba[i])
                return false;
        return true;
    }
    bool operator!=(const Palette& o) const {
        return !(*this == o);
    }
};
inline Palette FromItem(const InventoryItem& item) {
    Palette p;
    p.mask = item.paintColorMask & 15u;
    for (int i = 0; i < 4; ++i)
        if (p.mask & (1u << i)) {
            auto c = item.paintColors[i];
            if (!std::isfinite(c.r) || !std::isfinite(c.g) || !std::isfinite(c.b) || !std::isfinite(c.a)) {
                p.mask &= ~(1u << i);
                continue;
            }
            auto b = [](float x) { return std::uint32_t(std::lround(std::clamp(x, 0.f, 1.f) * 255.f)); };
            p.rgba[i] = b(c.r) | (b(c.g) << 8) | (b(c.b) << 16) | (b(c.a) << 24);
        }
    return p;
}

// Verify that the local glove builder appends a wear variable through the same ABI.
inline bool GloveUsesAppend(const HudScanImage& image, std::uintptr_t builder, std::uintptr_t append) {
    auto name = image.Find("48 8D 15 ? ? ? ? 0F 11 45 7C 48 8D 4D 20 40 88 75 40", true, 2);
    auto call = image.Find("C7 45 60 05 00 00 00 48 8D 55 20 F3 0F 11 75 7C 48 8D 4C 24 40 F3 0F 11 B5 "
                           "88 00 00 00 F3 0F 11 B5 94 00 00 00 F3 0F 11 B5 A0 00 00 00 E8 ? ? ? ?", true, 2);
    return builder && append && name.size() == 1 && call.size() == 1 && name[0] >= builder &&
           name[0] - builder < 0xd30 && call[0] > name[0] && call[0] - builder < 0xd30 &&
           image.Text(image.Rip(name[0]), "g_flWearAmount") && image.Rip(call[0] + 45, 1, 5) == append;
}

struct LooseVariable {
    char* name = nullptr;
    unsigned char pad[0x38]{};
    std::int32_t type = 0;
    unsigned char pad2[0x48]{};
    std::uint32_t color = 0;
    unsigned char tail[0x288 - 0x90]{};
};
static_assert(sizeof(LooseVariable) == 0x288 && offsetof(LooseVariable, type) == 0x40 &&
                  offsetof(LooseVariable, color) == 0x8c,
              "composite ABI drift");

inline std::uintptr_t ResolveAppend(const HudScanImage& image, std::uintptr_t refresh) {
    auto hits = image.Find("48 8D 55 00 F3 0F 11 75 5C 48 8D 4D D0 F3 0F 11 75 68 F3 0F 11 75 74 F3 0F 11 B5 "
                           "80 00 00 00 C7 45 40 05 00 00 00 E8 ? ? ? ?",
                           true, 2);
    if (hits.size() != 1 || !refresh || hits[0] < refresh || hits[0] - refresh > 0x500)
        return 0;
    auto fn = image.Rip(hits[0] + 38, 1, 5);
    unsigned char prologue[25]{};
    const unsigned char expected[] = {0x48, 0x89, 0x6c, 0x24, 0x18, 0x48, 0x89, 0x7c, 0x24,
                                      0x20, 0x41, 0x56, 0x48, 0x83, 0xec, 0x20, 0x48, 0x63,
                                      0x29, 0x4c, 0x8b, 0xf2, 0x48, 0x8b, 0xf9};
    if (!image.Contains(fn, sizeof prologue, 0x20000000) || !image.Bytes(fn, prologue, sizeof prologue) ||
        std::memcmp(prologue, expected, sizeof prologue))
        return 0;
    unsigned char stride[6]{};
    const unsigned char expectStride[] = {0x41, 0xb9, 0x88, 0x02, 0x00, 0x00};
    if (!image.Bytes(fn + 0x52, stride, 6) || std::memcmp(stride, expectStride, 6))
        return 0;
    auto wear = image.Find("48 8D 15 ? ? ? ? 44 88 6D 20 F3 0F 7F 4D 28 48 8D 4D 00", true, 16);
    if (wear.size() >= 16)
        return 0;
    unsigned matches = 0;
    for (auto w : wear)
        if (w >= refresh && w - refresh <= 0x500 && image.Text(image.Rip(w), "g_flWearAmount"))
            ++matches;
    if (matches != 1)
        return 0;
    return fn;
}
}
