#pragma once

#include "inventory_model.h"
#include <cstdint>
#include <cstring>
#include <map>
#include <string>
#include <vector>
namespace menu {

struct InventoryOffsets {

    std::uint32_t pawnHandle = 0;
    std::uint32_t weaponServices = 0;
    std::uint32_t myWeapons = 0;
    std::uint32_t team = 0;
    std::uint32_t attributeManager = 0;
    std::uint32_t item = 0;
    std::uint32_t itemDefinition = 0;
    std::uint32_t fallbackPaintKit = 0;

    std::uint32_t steamId = 0;
    std::uint32_t itemIdHigh = 0, accountId = 0, entityQuality = 0, customName = 0;
    std::uint32_t fallbackSeed = 0, fallbackWear = 0, fallbackStatTrak = 0, originalOwnerLow = 0,
                  originalOwnerHigh = 0;
    std::uint32_t inventoryServices = 0;
    std::uint32_t musicId = 0;
    bool Required() const {
        return pawnHandle && weaponServices && myWeapons && team && attributeManager && item &&
               itemDefinition && fallbackPaintKit;
    }
};

struct InventoryMemory {
    virtual ~InventoryMemory() = default;
    virtual bool Read(std::uintptr_t at, void* out, std::size_t n) = 0;
    virtual bool Write(std::uintptr_t at, const void* in, std::size_t n) = 0;
    virtual std::uintptr_t Entity(std::uint32_t handle) = 0;
    template <class T> bool Get(std::uintptr_t at, T& v) {
        return Read(at, &v, sizeof v);
    }
};

enum InventoryQuality : std::int32_t {
    InventoryQualityNormal = 0,
    InventoryQualityUnusual = 3,
    InventoryQualityStatTrak = 9
};
inline constexpr std::size_t InventoryNameBytes = 81;
inline constexpr std::uint32_t InventoryMaxWeapons = 64;

struct InventoryWeaponSnapshot {
    std::int32_t paintKit = 0, seed = 0, statTrak = 0, quality = 0;
    float wear = 0;
    std::uint32_t itemIdHigh = 0, accountId = 0, ownerLow = 0, ownerHigh = 0;
    std::array<char, InventoryNameBytes> name{};
};
struct InventoryApplyStats {
    const char* stage = "idle";
    int team = -1;
    unsigned weapons = 0, configured = 0, applied = 0, restored = 0, writes = 0, unchanged = 0, failures = 0;
    bool music = false;
};

struct InventoryWeaponTarget {
    std::int32_t paintKit = 0, seed = 0, statTrak = -1, quality = 0;
    float wear = 0;
    std::uint32_t itemIdHigh = 0xFFFFFFFFu, accountId = 0, ownerLow = 0, ownerHigh = 0;
    std::array<char, InventoryNameBytes> name{};
    bool hasName = false;
};
inline InventoryWeaponTarget InventoryTargetFor(const InventoryItem& item, int definition,
                                                std::uint64_t steamId) {
    InventoryWeaponTarget t;
    t.paintKit = item.paintKit;
    t.seed = std::clamp(item.seed, 0, 1000);
    t.wear = InventoryWearFloat(item.wearTier, item.wearValue);

    t.statTrak = item.statTrak ? std::max(0, item.statTrakValue) : -1;
    t.quality = item.statTrak                  ? InventoryQualityStatTrak
                : InventoryIsKnife(definition) ? InventoryQualityUnusual
                                               : InventoryQualityNormal;
    t.accountId = std::uint32_t(steamId & 0xFFFFFFFFu);
    t.ownerLow = t.accountId;
    t.ownerHigh = std::uint32_t(steamId >> 32);
    if (!item.name.empty()) {
        t.hasName = true;
        std::size_t n = std::min(item.name.size(), InventoryNameBytes - 1);

        while (n > 0 && n < item.name.size() && (static_cast<unsigned char>(item.name[n]) & 0xC0) == 0x80)
            --n;
        std::memcpy(t.name.data(), item.name.data(), n);
        t.name[n] = 0;
    }
    return t;
}

inline const InventoryItem* InventoryResolveItem(const InventoryValues& cfg, int team, int definition) {
    if (team < 0 || team > 1)
        return nullptr;

    if (InventoryIsKnife(definition)) {
        if (cfg.Knife(team) != definition)
            return nullptr;
    } else if (!InventoryWeapon(definition))
        return nullptr;
    const InventoryItem* own = cfg.teams[std::size_t(team)].Find(definition);
    if (own && own->paintKit > 0)
        return own;
    const InventoryItem* other = cfg.teams[std::size_t(1 - team)].Find(definition);
    if (other && other->bothTeams && other->paintKit > 0)
        return other;
    return nullptr;
}

class InventoryApplier {
    struct Owned {
        std::uintptr_t entity = 0;
        InventoryWeaponSnapshot snapshot;
        bool nameTouched = false;
    };
    std::map<std::uint32_t, Owned> owned_;
    bool musicOwned_ = false;
    std::uintptr_t musicAt_ = 0;
    std::uint16_t musicOriginal_ = 0;
    template <class T> static bool Same(InventoryMemory& m, std::uintptr_t at, const T& want, bool& failed) {
        T cur{};
        if (!m.Get(at, cur)) {
            failed = true;
            return true;
        }
        return std::memcmp(&cur, &want, sizeof(T)) == 0;
    }
    template <class T>
    static void Put(InventoryMemory& m, std::uintptr_t at, const T& v, InventoryApplyStats& s) {
        bool failed = false;
        if (Same(m, at, v, failed)) {
            if (failed)
                ++s.failures;
            else
                ++s.unchanged;
            return;
        }
        if (m.Write(at, &v, sizeof v))
            ++s.writes;
        else
            ++s.failures;
    }
    static bool Snapshot(InventoryMemory& m, const InventoryOffsets& o, std::uintptr_t w,
                         InventoryWeaponSnapshot& s) {
        std::uintptr_t view = w + o.attributeManager + o.item;
        bool ok = m.Get(w + o.fallbackPaintKit, s.paintKit);
        if (o.fallbackSeed)
            ok = ok && m.Get(w + o.fallbackSeed, s.seed);
        if (o.fallbackWear)
            ok = ok && m.Get(w + o.fallbackWear, s.wear);
        if (o.fallbackStatTrak)
            ok = ok && m.Get(w + o.fallbackStatTrak, s.statTrak);
        if (o.originalOwnerLow)
            ok = ok && m.Get(w + o.originalOwnerLow, s.ownerLow);
        if (o.originalOwnerHigh)
            ok = ok && m.Get(w + o.originalOwnerHigh, s.ownerHigh);
        if (o.entityQuality)
            ok = ok && m.Get(view + o.entityQuality, s.quality);
        if (o.itemIdHigh)
            ok = ok && m.Get(view + o.itemIdHigh, s.itemIdHigh);
        if (o.accountId)
            ok = ok && m.Get(view + o.accountId, s.accountId);
        if (o.customName)
            ok = ok && m.Read(view + o.customName, s.name.data(), s.name.size());
        return ok;
    }
    static void ApplyTarget(InventoryMemory& m, const InventoryOffsets& o, std::uintptr_t w,
                            const InventoryWeaponTarget& t, bool& nameTouched, InventoryApplyStats& s) {
        std::uintptr_t view = w + o.attributeManager + o.item;
        if (o.itemIdHigh)
            Put(m, view + o.itemIdHigh, t.itemIdHigh, s);
        if (o.accountId)
            Put(m, view + o.accountId, t.accountId, s);
        if (o.entityQuality)
            Put(m, view + o.entityQuality, t.quality, s);
        Put(m, w + o.fallbackPaintKit, t.paintKit, s);
        if (o.fallbackSeed)
            Put(m, w + o.fallbackSeed, t.seed, s);
        if (o.fallbackWear)
            Put(m, w + o.fallbackWear, t.wear, s);
        if (o.fallbackStatTrak)
            Put(m, w + o.fallbackStatTrak, t.statTrak, s);
        if (o.originalOwnerLow)
            Put(m, w + o.originalOwnerLow, t.ownerLow, s);
        if (o.originalOwnerHigh)
            Put(m, w + o.originalOwnerHigh, t.ownerHigh, s);
        if (o.customName && t.hasName) {
            Put(m, view + o.customName, t.name, s);
            nameTouched = true;
        }
    }
    static void Restore(InventoryMemory& m, const InventoryOffsets& o, std::uintptr_t w, const Owned& own,
                        InventoryApplyStats& s) {
        const auto& p = own.snapshot;
        std::uintptr_t view = w + o.attributeManager + o.item;
        if (o.itemIdHigh)
            Put(m, view + o.itemIdHigh, p.itemIdHigh, s);
        if (o.accountId)
            Put(m, view + o.accountId, p.accountId, s);
        if (o.entityQuality)
            Put(m, view + o.entityQuality, p.quality, s);
        Put(m, w + o.fallbackPaintKit, p.paintKit, s);
        if (o.fallbackSeed)
            Put(m, w + o.fallbackSeed, p.seed, s);
        if (o.fallbackWear)
            Put(m, w + o.fallbackWear, p.wear, s);
        if (o.fallbackStatTrak)
            Put(m, w + o.fallbackStatTrak, p.statTrak, s);
        if (o.originalOwnerLow)
            Put(m, w + o.originalOwnerLow, p.ownerLow, s);
        if (o.originalOwnerHigh)
            Put(m, w + o.originalOwnerHigh, p.ownerHigh, s);
        if (o.customName && own.nameTouched)
            Put(m, view + o.customName, p.name, s);
        ++s.restored;
    }

    struct LocalWeapons {
        std::uintptr_t pawn = 0;
        int team = -1;
        std::vector<std::pair<std::uint32_t, std::uintptr_t>> weapons;
    };
    static bool Walk(InventoryMemory& m, const InventoryOffsets& o, std::uintptr_t controller,
                     LocalWeapons& out, InventoryApplyStats& s) {
        std::uint32_t pawnHandle = 0;
        if (!controller || !m.Get(controller + o.pawnHandle, pawnHandle) || pawnHandle == 0 ||
            pawnHandle == 0xFFFFFFFFu) {
            s.stage = "no local pawn";
            return false;
        }
        out.pawn = m.Entity(pawnHandle);
        if (!out.pawn) {
            s.stage = "local pawn handle stale";
            return false;
        }
        std::uint8_t team = 0;
        if (!m.Get(out.pawn + o.team, team)) {
            s.stage = "team unreadable";
            return false;
        }
        out.team = team == 3 ? InventoryCT : team == 2 ? InventoryT : -1;
        s.team = out.team;
        if (out.team < 0) {
            s.stage = "not on a team";
            return false;
        }
        std::uintptr_t services = 0;
        if (!m.Get(out.pawn + o.weaponServices, services) || !services) {
            s.stage = "no weapon services";
            return false;
        }
        std::int32_t count = 0;
        std::uintptr_t data = 0;
        if (!m.Get(services + o.myWeapons, count) || !m.Get(services + o.myWeapons + 8, data) || count < 0 ||
            std::uint32_t(count) > InventoryMaxWeapons || (count && !data)) {
            s.stage = "weapon list unreadable";
            return false;
        }
        for (std::int32_t i = 0; i < count; ++i) {
            std::uint32_t h = 0;
            if (!m.Get(data + std::uintptr_t(i) * 4, h) || h == 0 || h == 0xFFFFFFFFu)
                continue;
            auto e = m.Entity(h);
            if (e)
                out.weapons.push_back({h, e});
        }
        s.weapons = unsigned(out.weapons.size());
        return true;
    }

public:
    const std::map<std::uint32_t, Owned>& Owned_() const {
        return owned_;
    }
    bool Holding() const {
        return !owned_.empty() || musicOwned_;
    }

    InventoryApplyStats Tick(InventoryMemory& m, const InventoryOffsets& o, std::uintptr_t controller,
                             const InventoryValues& cfg, bool enabled) {
        InventoryApplyStats s;
        if (!o.Required()) {
            s.stage = "schema incomplete";
            return s;
        }
        LocalWeapons local;
        if (!Walk(m, o, controller, local, s)) {

            owned_.clear();
            if (!enabled)
                ReleaseMusic(m, s);
            return s;
        }
        std::uint64_t steam = 0;
        if (o.steamId)
            m.Get(controller + o.steamId, steam);
        std::map<std::uint32_t, Owned> next;
        for (const auto& [handle, entity] : local.weapons) {
            std::uint16_t def = 0;
            if (!m.Get(entity + o.attributeManager + o.item + o.itemDefinition, def)) {
                ++s.failures;
                continue;
            }
            const InventoryItem* item = enabled ? InventoryResolveItem(cfg, local.team, int(def)) : nullptr;
            auto known = owned_.find(handle);
            bool ours = known != owned_.end() && known->second.entity == entity;
            if (item) {
                ++s.configured;
                Owned own;
                if (ours)
                    own = known->second;
                else {
                    own.entity = entity;
                    if (!Snapshot(m, o, entity, own.snapshot)) {
                        ++s.failures;
                        continue;
                    }
                }
                ApplyTarget(m, o, entity, InventoryTargetFor(*item, int(def), steam), own.nameTouched, s);
                ++s.applied;
                next[handle] = own;
            } else if (ours)
                Restore(m, o, entity, known->second, s);
        }
        owned_.swap(next);

        int music = enabled ? cfg.teams[std::size_t(local.team)].music : 0;
        if (music > 0 && o.inventoryServices && o.musicId) {
            std::uintptr_t services = 0;
            if (m.Get(controller + o.inventoryServices, services) && services) {
                std::uintptr_t at = services + o.musicId;
                if (!musicOwned_ || musicAt_ != at) {
                    std::uint16_t cur = 0;
                    if (m.Get(at, cur)) {
                        musicOriginal_ = cur;
                        musicAt_ = at;
                        musicOwned_ = true;
                    }
                }
                if (musicOwned_) {
                    Put(m, at, std::uint16_t(music), s);
                    s.music = true;
                }
            }
        } else
            ReleaseMusic(m, s);
        s.stage = enabled ? "applied" : "restored";
        return s;
    }
    void ReleaseMusic(InventoryMemory& m, InventoryApplyStats& s) {
        if (!musicOwned_)
            return;
        Put(m, musicAt_, musicOriginal_, s);
        musicOwned_ = false;
        musicAt_ = 0;
    }

    InventoryApplyStats RestoreAll(InventoryMemory& m, const InventoryOffsets& o, std::uintptr_t controller) {
        InventoryValues none;
        auto s = Tick(m, o, controller, none, false);
        owned_.clear();
        ReleaseMusic(m, s);
        return s;
    }
};
}
