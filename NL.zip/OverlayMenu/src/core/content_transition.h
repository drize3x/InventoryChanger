#pragma once
#include <algorithm>
#include <cmath>
namespace menu {

struct DumpContentTransition {
    struct Page {
        int main = 0, child = 0;
        bool operator==(Page b) const {
            return main == b.main && child == b.child;
        }
        bool operator!=(Page b) const {
            return !(*this == b);
        }
    };
    static constexpr float Duration = .15f, Slide = 10.f;
    Page displayed{}, requested{};
    float value = 0, renderAlpha = 0, target = 0, elapsed = 0, low = 0, high = 0;
    bool initialized = false;
    static Page Key(int main, int child) {
        return {main, main == 2 ? child : 0};
    }
    void Advance(float next, float dt) {
        if (!initialized || next != target) {
            target = next;
            elapsed = 0;
            low = std::min(value, next);
            high = std::max(value, next);
            if (!initialized) {
                initialized = true;
                value = next;
            }
            return;
        }
        if (std::abs(value - next) <= 1.1920928955078125e-7f) {
            elapsed = 0;
            value = next;
            return;
        }
        elapsed += dt;
        if (elapsed >= Duration) {
            value = next;
            elapsed = 0;
            return;
        }
        float t = std::clamp(elapsed / Duration, 0.f, 1.f), u = 1 - t, ease = 1 - u * u * u;
        value = next <= (low + high) * .5f ? high - (high - low) * ease : low + (high - low) * ease;
    }
    void Tick(int main, int child, float dt) {
        requested = Key(main, child);
        renderAlpha = value;
        dt = std::isfinite(dt) ? std::max(0.f, dt) : 0.f;
        if (displayed != requested) {
            if (value > 0)
                Advance(0, dt);
            else
                displayed = requested;
        } else
            Advance(1, dt);
    }
    bool Outgoing() const {
        return displayed != requested;
    }
    float Offset(float scale) const {
        return Slide * scale * (1 - renderAlpha);
    }
};
}
