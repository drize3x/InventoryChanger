#pragma once
#include <cstddef>

namespace dump_menu {
struct Vec2 {
    float x, y;
};
struct Rect {
    float left, top, right, bottom;
};

inline float outer_width(float scaled_context_1c10) {
    return scaled_context_1c10;
}
inline float default_outer_width(float scale) {
    return 800.f * scale;
}
inline float sidebar_width(float scale) {
    return 170.f * scale;
}
inline float row_height(float scale, float nav_object_8 = 32.f) {
    return nav_object_8 * scale;
}
inline float header_height(float scale, float scaled_context_163c) {
    return 35.f * scale + 2.f * scaled_context_163c;
}
inline float footer_height(float scale, float footer_object_2c, float scaled_context_163c) {
    return footer_object_2c * scale + 2.f * scaled_context_163c;
}
inline float measured_outer_height(const float* component_heights, std::size_t count,
                                   float scaled_context_1634, float scaled_context_1580) {
    float total = 0.f;
    for (std::size_t i = 0; i < count; ++i) {
        total += component_heights[i];
        if (i + 1 < count)
            total += scaled_context_1634;
    }
    return total + 2.f * scaled_context_1580;
}

inline Vec2 centered_top_left(Vec2 display_size, Vec2 actual_window_size) {
    return {(display_size.x - actual_window_size.x) * .5f, (display_size.y - actual_window_size.y) * .5f};
}
inline float nav_indent(float scale, float scaled_context_1638) {
    return scaled_context_1638 + 5.f * scale;
}
inline Rect nav_highlight(float cursor_x, float cursor_y, float child_pos_x, float child_width, float row_h,
                          float scale) {
    return {cursor_x - 10.f * scale, cursor_y, child_pos_x + child_width - 10.f * scale, cursor_y + row_h};
}
inline float highlight_radius_parameter(float scale) {
    return 8.f * scale;
}
inline float highlight_alpha(float palette_33_alpha, float animated_state, float global_alpha) {
    return palette_33_alpha * .4f * animated_state * global_alpha;
}

// cs2_212C3300000.bin: RVA 0x979f79, 0x97ca35 (10*s inset),
// 0x97d535 (nested frame padding), 0x7fa1cd (runtime font height).
struct SearchMetrics {
    float inset, paddingX, paddingY, inputHeight;
};
inline SearchMetrics search_metrics(float scale, float runtime_font_height,
                                    float header_frame_x, float header_frame_y) {
    const float px = 2.f * header_frame_x - scale;
    const float py = 3.f * header_frame_y - scale;
    return {10.f * scale, px, py, runtime_font_height + 2.f * py};
}
inline float search_width(float child_width, float inset) {
    return child_width - 2.f * inset;
}

inline float nav_state_target(bool selected, bool hovered, bool held) {
    if (selected || held)
        return 1.f;
    return hovered ? .5f : 0.f;
}
}
