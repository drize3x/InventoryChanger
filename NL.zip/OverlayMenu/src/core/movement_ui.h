#pragma once

#include "world_tooltip.h"
#include "group_row_geometry.h"
namespace menu {
struct MovementUI {
    PresetsUI paint;
    LanguageCatalog* languages = nullptr;
    Box card{}, row{}, airRow{}, more{}, jumpRow{}, jumpMore{}, popupBox{}, popupBody{};
    std::array<Box, 6> options{};
    std::array<Box, 4> jumpOptions{};
    std::array<Box, 4> sliderRows{}, sliders{};
    bool visible = false, blocked = false, held = false, focus = false, popup = false;
    int popupKind = 0;
    int pressed = -1, drag = -1, hoverIndex = -1, keyFocus = 0;
    float scale = 1, mouseX = -1, mouseY = -1, hoverTime = 0, scroll = 0, maxScroll = 0;
    PresetMotion hover, check, airCheck, jumpCheck, tooltip, popupMotion;
    std::array<PresetMotion, 3> rowHover{};
    std::array<PresetMotion, 4> jumpHover{}, jumpMark{};
    std::array<PresetMotion, 2> dotsHover{};
    PresetMotion jumpLabelShift;
    PresetLayer lastJumpTip{};
    bool hasJumpTip = false;
    std::array<PresetMotion, 10> itemHover{};
    std::array<PresetMotion, 6> optionAvailability{};
    std::array<PresetMotion, 4> sliderTip{};
    PresetMotion extraRows;
    PresetLayer lastPopup{};
    bool hasLastPopup = false;
    static constexpr const char* modes[6] = {"avoidcollisions",      "viewangles",     "movementkeys",
                                             "onlywhileholdingjump", "stoponshiftkey", "stoponkeyrelease"};
    static constexpr const char* jumpModes[4] = {"highjump", "rampboost", "nolandpenalty", "nofalldamage"};
    static constexpr const char* vals[4] = {"subticks", "turnspeed", "cornersdistance", "wallslide"};
    std::u32string Label(const char* key) const {
        if (languages)
            return languages->Label(key);
        const auto& m = DefaultLanguageStrings();
        auto it = m.find(key);
        return DecodeUTF8(it == m.end() ? key : it->second);
    }
    static std::string ModeKey(int i) {
        return std::string("miscellaneous_movement_airstrafe_modes_") + modes[i];
    }
    static std::string JumpKey(int i) {
        return std::string("miscellaneous_movement_jumpbug_") + jumpModes[i];
    }
    static std::string ValueKey(int i) {
        return std::string("miscellaneous_movement_airstrafe_") + vals[i];
    }
    bool Active() const {
        return visible && popup && !blocked;
    }
    bool Capturing() const {
        return held || pressed >= 0 || drag >= 0;
    }
    void CancelInput() {
        held = false;
        pressed = drag = -1;
    }
    bool Over() const {
        return visible && !blocked && !popup && row.Contains(mouseX, mouseY);
    }
    bool ModeEnabled(int i, const Settings& c) const {
        return i == 5   ? c.movementAirModes[2]
               : i == 1 ? !(c.movementAirModes[2] && c.movementAirModes[5])
                        : true;
    }
    bool ValueVisible(int i, const Settings& c) const {
        return i < 2 || c.movementAirModes[0];
    }
    int Hit(float x, float y, const Settings& c) const {
        if (!visible || blocked)
            return -1;
        if (popup) {
            if (popupBody.Contains(x, y)) {
                if (popupKind == 1) {
                    for (int i = 0; i < 4; ++i)
                        if (jumpOptions[std::size_t(i)].Contains(x, y))
                            return 50 + i;
                    return popupBox.Contains(x, y) ? 40 : 41;
                }
                for (int i = 0; i < 6; ++i)
                    if (options[std::size_t(i)].Contains(x, y))
                        return 10 + i;
                for (int i = 0; i < 4; ++i)
                    if (ValueVisible(i, c) && sliderRows[std::size_t(i)].Contains(x, y))
                        return 20 + i;
            }
            return popupBox.Contains(x, y) ? 40 : 41;
        }
        if (jumpMore.Contains(x, y))
            return 4;
        if (jumpRow.Contains(x, y))
            return 3;
        if (more.Contains(x, y))
            return 2;
        if (airRow.Contains(x, y))
            return 1;
        if (row.Contains(x, y))
            return 0;
        return -1;
    }
    void Move(float x, float y, const Settings& c) {
        if (x != mouseX || y != mouseY) {
            mouseX = x;
            mouseY = y;
            int h = Hit(x, y, c);
            if (h != hoverIndex) {
                hoverIndex = h;
                hoverTime = 0;
            }
        }
    }
    void Move(float x, float y, Settings& c) {
        Move(x, y, static_cast<const Settings&>(c));
        if (drag >= 0 && drag < 4 && sliders[std::size_t(drag)].w > 0) {
            auto b = sliders[std::size_t(drag)];
            int max = drag == 2 ? 201 : drag == 3 ? 90 : 100;
            c.movementAirValues[std::size_t(drag)] =
                int(std::lround(std::clamp((x - b.x) / std::max(1.f, b.w), 0.f, 1.f) * max));
        }
    }
    void Tick(float dt, const Settings& cfg) {
        if (!visible)
            return;
        dt = std::max(0.f, dt);
        int h = Hit(mouseX, mouseY, cfg);
        if (h != hoverIndex) {
            hoverIndex = h;
            hoverTime = 0;
        }
        hoverTime = h >= 0 ? hoverTime + dt : 0;
        hover.Tick(Over() ? .5f : 0.f, dt);
        check.Tick(cfg.movementBunnyHop ? 1.f : 0.f, dt);
        airCheck.Tick(cfg.movementAirStrafe ? 1.f : 0.f, dt);
        jumpCheck.Tick(cfg.movementJumpBug ? 1.f : 0.f, dt);
        bool anyJump = std::any_of(cfg.movementJumpBugModes.begin(), cfg.movementJumpBugModes.end(),
                                   [](bool v) { return v; });
        jumpLabelShift.Tick(anyJump ? 1.f : 0.f, dt);
        for (int i = 0; i < 2; ++i) {
            int dotHit = i ? 4 : 2;
            bool open = popup && popupKind == i;
            dotsHover[i].Tick(open ? 1.f : (!popup && h == dotHit ? (held && pressed == h ? 1.f : .5f) : 0.f),
                              dt);
        }
        for (int i = 0; i < 4; ++i) {
            jumpMark[i].Tick(cfg.movementJumpBugModes[i] ? 1.f : 0.f, dt);
            jumpHover[i].Tick(
                popup && popupKind == 1 && h == 50 + i ? (held && pressed == h ? 1.f : .5f) : 0.f, dt);
        }
        popupMotion.Tick(popup ? 1.f : 0.f, dt);
        for (int i = 0; i < 3; ++i)
            rowHover[std::size_t(i)].Tick(!popup && (i == 0   ? h == 0
                                                     : i == 1 ? (h == 1 || h == 2)
                                                              : (h == 3 || h == 4))
                                              ? .5f
                                              : 0.f,
                                          dt);
        for (int i = 0; i < 10; ++i) {
            bool enabled = i >= 6 || ModeEnabled(i, cfg);
            bool over = popup && popupKind == 0 && enabled && h == (i < 6 ? 10 + i : 20 + i - 6);
            itemHover[std::size_t(i)].Tick(over ? (held && pressed == h ? 1.f : .5f) : 0.f, dt);
        }
        for (int i = 0; i < 6; ++i) {
            optionAvailability[i].Tick(ModeEnabled(i, cfg) ? 1.f : .28f, dt);
        }
        for (int i = 0; i < 4; ++i) {
            auto b = sliders[i];
            sliderTip[i].Tick(popup && popupKind == 0 && ValueVisible(i, cfg) &&
                                      (drag == i || (b.w > 0 && b.Contains(mouseX, mouseY)))
                                  ? 1.f
                                  : 0.f,
                              dt);
        }
        extraRows.Tick(cfg.movementAirModes[0] ? 1.f : 0.f, dt);
        bool t = h == 0 || h == 1 || h == 3 || (h >= 10 && h <= 15) || (h >= 20 && h <= 23) ||
                 (h >= 50 && h <= 53);
        tooltip.Tick(t && hoverTime >= .3f && drag < 0 ? 1.f : 0.f, dt);
    }
    void SetMode(int i, Settings& c) {
        if (i < 0 || i >= 6 || !ModeEnabled(i, c))
            return;
        auto& m = c.movementAirModes;
        m[std::size_t(i)] = !m[std::size_t(i)];
        if ((i == 1 || i == 2) && !m[1] && !m[2])
            m[std::size_t(i)] = true;
    }
    bool Click(float x, float y, bool down, Settings& cfg) {
        if (!visible || blocked) {
            CancelInput();
            return false;
        }
        Move(x, y, cfg);
        int hit = Hit(x, y, cfg);
        if (down) {
            if (hit < 0)
                return false;
            pressed = hit;
            if (hit != 40 && hit != 41)
                keyFocus = hit;
            focus = true;
            held = true;
            if (hit >= 20 && hit <= 23) {
                int i = hit - 20;
                auto b = sliders[std::size_t(i)];
                Box target = PresetIntersect(
                    {b.x, sliderRows[std::size_t(i)].y, b.w, sliderRows[std::size_t(i)].h}, popupBody);
                if (target.Contains(x, y)) {
                    drag = i;
                    Move(x, y, cfg);
                }
            }
            return true;
        }
        bool used = held;
        int p = pressed;
        held = false;
        pressed = -1;
        if (drag >= 0) {
            Move(x, y, cfg);
            drag = -1;
            return true;
        }
        if (!used)
            return false;
        if (p != hit)
            return true;
        if (hit == 0)
            cfg.movementBunnyHop = !cfg.movementBunnyHop;
        else if (hit == 1)
            cfg.movementAirStrafe = !cfg.movementAirStrafe;
        else if (hit == 2 || hit == 4) {
            popup = true;
            popupKind = hit == 4 ? 1 : 0;
            scroll = 0;
            popupMotion.Snap(0);
            hasJumpTip = false;
        } else if (hit == 3)
            cfg.movementJumpBug = !cfg.movementJumpBug;
        else if (hit >= 50 && hit <= 53)
            cfg.movementJumpBugModes[std::size_t(hit - 50)] =
                !cfg.movementJumpBugModes[std::size_t(hit - 50)];
        else if (hit >= 10 && hit <= 15)
            SetMode(hit - 10, cfg);
        else if (hit == 41)
            popup = false;
        return true;
    }
    bool Key(int key, Settings& cfg) {
        if (!visible || blocked)
            return false;
        if (key == 27 && popup) {
            popup = false;
            keyFocus = popupKind == 1 ? 4 : 2;
            CancelInput();
            return true;
        }
        if (key == 9 || (popup && (key == 38 || key == 40))) {
            focus = true;
            std::vector<int> items;
            if (popup) {
                if (popupKind == 1) {
                    for (int i = 0; i < 4; ++i)
                        items.push_back(50 + i);
                } else {
                    for (int i = 0; i < 6; ++i)
                        if (ModeEnabled(i, cfg))
                            items.push_back(10 + i);
                    for (int i = 0; i < (cfg.movementAirModes[0] ? 4 : 2); ++i)
                        items.push_back(20 + i);
                }
            } else
                items = {0};
            auto it = std::find(items.begin(), items.end(), keyFocus);
            int n = it == items.end() ? 0 : int(it - items.begin()) + (key == 38 ? -1 : 1);
            n = (n + int(items.size())) % int(items.size());
            keyFocus = items[std::size_t(n)];
            return true;
        }
        if (!focus)
            return popup;
        if (popup && keyFocus >= 20 && keyFocus <= 23 && (key == 37 || key == 39)) {
            int i = keyFocus - 20;
            if (!ValueVisible(i, cfg))
                return true;
            int max = i == 2 ? 201 : i == 3 ? 90 : 100;
            cfg.movementAirValues[std::size_t(i)] =
                std::clamp(cfg.movementAirValues[std::size_t(i)] + (key == 37 ? -1 : 1), 0, max);
            return true;
        }
        if (key == 13 || key == 32) {
            if (!popup && keyFocus == 0)
                cfg.movementBunnyHop = !cfg.movementBunnyHop;
            else if (!popup && keyFocus == 1)
                cfg.movementAirStrafe = !cfg.movementAirStrafe;
            else if (!popup && (keyFocus == 2 || keyFocus == 4)) {
                popup = true;
                popupKind = keyFocus == 4 ? 1 : 0;
                scroll = 0;
                popupMotion.Snap(0);
                hasJumpTip = false;
            } else if (!popup && keyFocus == 3)
                cfg.movementJumpBug = !cfg.movementJumpBug;
            else if (popup && popupKind == 1 && keyFocus >= 50 && keyFocus <= 53)
                cfg.movementJumpBugModes[std::size_t(keyFocus - 50)] =
                    !cfg.movementJumpBugModes[std::size_t(keyFocus - 50)];
            else if (popup && keyFocus >= 10 && keyFocus <= 15)
                SetMode(keyFocus - 10, cfg);
            return true;
        }
        return popup;
    }
    bool Wheel(float steps, Settings&) {
        if (!Active())
            return false;
        scroll = std::clamp(scroll - steps * 30 * scale, 0.f, maxScroll);
        return true;
    }
    void Measure(Fonts& fonts, const Settings& cfg, const Layout& l, Box header, int width, int height,
                 bool shown, bool modal) {
        visible = shown;
        blocked = modal;
        scale = cfg.scale;
        paint.layers.clear();
        card = row = airRow = more = jumpRow = jumpMore = popupBox = popupBody = {};
        options.fill({});
        jumpOptions.fill({});
        sliderRows.fill({});
        sliders.fill({});
        if (!shown || modal) {
            CancelInput();
            popup = false;
            popupMotion.Snap(0);
            hasLastPopup = false;
            hasJumpTip = false;
            if (!shown) {
                focus = false;
                hoverTime = 0;
                return;
            }
        }
        const float s = scale, F = fonts.PixelHeight(0, 13 * s), hf = fonts.PixelHeight(0, 10 * s),
                    top = header.y + header.h + 15 * s, H = F + 6 * s, R = F + 14 * s;
        const float x = l.content.x + 15 * s, w = GroupTwoColumnWidth(l.content, s);
        card = {x, top + hf + 5 * s, w, GroupCardHeight(1, F, s)};
        row = {x + 14 * s, card.y + 7 * s, std::max(0.f, w - 28 * s), H};
        if (w <= 0 || card.y >= height)
            return;
        auto pal = CurrentPalette(cfg);
        paint.layers.push_back({{l.content.x, l.content.y, l.content.w, l.content.h}, 0, false, {}});
        auto rect = [&](int z, Box b, Color c, float r = 0, float stroke = 0, Box clip = Box{}) {
            if (b.w <= 0 || b.h <= 0 || c.a <= 0)
                return;
            PresetDraw d{b, c, r, stroke, 15, {}, false};
            d.clipped = true;
            d.clip = clip.w > 0 ? PresetIntersect(paint.layers[std::size_t(z)].box, clip)
                                : paint.layers[std::size_t(z)].box;
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto text = [&](int z, Box b, std::u32string t, Color c, float px, int font = 0, Box clip = Box{}) {
            PresetDraw d{b, c, 0, 0, 15, std::move(t), font == 3};
            d.font = font;
            d.textSize = px;
            d.clipped = true;
            d.clip = clip.w > 0 ? PresetIntersect(paint.layers[std::size_t(z)].box, clip)
                                : paint.layers[std::size_t(z)].box;
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto alpha = [](Color c, float a) {
            c.a *= a;
            return c;
        };
        auto title = Label("group_miscellaneous_movement");
        for (auto& c : title) {
            if (c >= U'a' && c <= U'z')
                c -= 32;
            else if (c >= 0x430 && c <= 0x44f)
                c -= 32;
            else if (c == 0x451)
                c = 0x401;
        }
        text(0, {x + 14 * s, top, w - 28 * s, hf}, title, pal[3], 10);
        rect(0, card, pal[40], 15 * s);
        rect(0, card, pal[11], 15 * s, s);
        for (int i = 0; i < 1; ++i) {
            Box r = i == 0 ? row : i == 1 ? airRow : jumpRow;
            float rh = rowHover[std::size_t(i)].initialized ? rowHover[std::size_t(i)].value : 0.f;
            rect(0, GroupRowHoverBounds(r, s), alpha(pal[33], .15f * rh), 15 * s);
            float v = i == 0   ? (check.initialized ? check.value : float(cfg.movementBunnyHop))
                      : i == 1 ? (airCheck.initialized ? airCheck.value : float(cfg.movementAirStrafe))
                               : (jumpCheck.initialized ? jumpCheck.value : float(cfg.movementJumpBug));
            float center = r.y + r.h * .5f, hh = F + 2 * s;
            Box ctl{r.x + r.w - 32 * s, center - hh * .5f, 32 * s, hh};
            rect(0, ctl, pal[22], hh * .5f);
            rect(0, ctl, alpha(pal[23], v), hh * .5f);
            float rad = hh * .5f - 2 * s, cx = ctl.x + hh * .5f + (ctl.w - hh) * v;
            rect(0, {cx - rad, center - rad, 2 * rad, 2 * rad}, Mix(pal[20], pal[21], v), rad);
            const char* key = i == 0   ? "miscellaneous_movement_bunnyhop"
                              : i == 1 ? "miscellaneous_movement_airstrafe"
                                       : "miscellaneous_movement_jumpbug";
            Box moreControl = i == 1 ? more : jumpMore;
            text(0, {r.x, r.y + (H - F) * .5f, std::max(0.f, (i ? moreControl.x : ctl.x) - r.x - 6 * s), F},
                 Label(key), pal[0], 13);
        }
        if (popup && popupKind == 1) {
            float titleH = F + 18 * s, total = 4 * R + 14 * s,
                  pw = std::min(284 * s, std::max(1.f, float(width) - 12 * s)),
                  ph = std::min(titleH + total + 7 * s, std::max(1.f, float(height) - 12 * s));
            popupBox = PresetPopupFit({jumpMore.x + jumpMore.w + 7 * s, jumpRow.y, pw, ph}, width, height);
            popupBody = {popupBox.x + 7 * s, popupBox.y + titleH, popupBox.w - 14 * s,
                         popupBox.h - titleH - 7 * s};
            maxScroll = std::max(0.f, total - popupBody.h);
            scroll = std::clamp(scroll, 0.f, maxScroll);
            int z = int(paint.layers.size());
            paint.layers.push_back({popupBox, 15 * s, true, {}});
            rect(z, popupBox, pal[8], 15 * s);
            rect(z, popupBox, pal[11], 15 * s, s);
            text(z, {popupBox.x + 14 * s, popupBox.y + 7 * s, popupBox.w - 28 * s, F},
                 Label("miscellaneous_movement_jumpbug"), pal[2], 13, 2);
            Box group{popupBody.x, popupBody.y - scroll, popupBody.w, total};
            rect(z, group, pal[40], 15 * s, 0, popupBody);
            rect(z, group, pal[11], 15 * s, s, popupBody);
            for (int i = 0; i < 4; ++i) {
                Box rr{group.x + 7 * s, group.y + 7 * s + i * R, group.w - 14 * s, R};
                jumpOptions[i] = PresetIntersect(rr, popupBody);
                float hv = jumpHover[i].value;
                rect(z, rr, alpha(pal[33], .4f * hv), 15 * s / 1.6f, 0, popupBody);
                float mark = jumpMark[i].initialized ? jumpMark[i].value : float(cfg.movementJumpBugModes[i]);
                if (mark > .001f)
                    text(z, {rr.x + 12 * s, rr.y + 7 * s, 14 * s, F}, U"\uf00c", alpha(pal[0], mark), 13, 3,
                         popupBody);
                auto key = JumpKey(i);
                float labelOffset = (12.f + 24.f * jumpLabelShift.value) * s;
                text(z, {rr.x + labelOffset, rr.y + 7 * s, std::max(0.f, rr.w - labelOffset - 12 * s), F},
                     Label(key.c_str()), Mix(pal[14], pal[2], hv), 13, 0, popupBody);
            }
            if (maxScroll > 0) {
                float th = std::max(10 * s, popupBody.h * popupBody.h / (popupBody.h + maxScroll));
                rect(z,
                     {popupBox.x + popupBox.w - 5 * s, popupBody.y + (popupBody.h - th) * scroll / maxScroll,
                      3 * s, th},
                     pal[18], 2 * s);
            }
            lastPopup = paint.layers[z];
            hasLastPopup = true;
            float a = popupMotion.value;
            paint.layers[z].opacity *= a;
            for (auto& d : paint.layers[z].draw) {
                d.color.a *= a;
                d.shadowColor.a *= a;
                d.backdropOpacity *= a;
            }
        } else if (popup) {
            float expansion = extraRows.initialized ? extraRows.value : float(cfg.movementAirModes[0]);
            int count = expansion > .001f || cfg.movementAirModes[0] ? 4 : 2;
            float extraHeight = 2 * R * std::clamp(expansion, 0.f, 1.f);
            float total = (6 * R + 14 * s) + 7 * s + (2 * R + extraHeight + 14 * s), titleH = F + 18 * s;
            float pw = std::min(265 * s, std::max(1.f, float(width) - 12 * s));
            float ph = std::min(titleH + total + 7 * s, std::max(1.f, float(height) - 12 * s));
            popupBox = PresetPopupFit({more.x + more.w + 7 * s, airRow.y, pw, ph}, width, height);
            popupBody = {popupBox.x + 7 * s, popupBox.y + titleH, popupBox.w - 14 * s,
                         popupBox.h - titleH - 7 * s};
            maxScroll = std::max(0.f, total - popupBody.h);
            scroll = std::clamp(scroll, 0.f, maxScroll);
            int z = int(paint.layers.size());
            paint.layers.push_back({popupBox, 15 * s, true, {}});
            rect(z, popupBox, pal[8], 15 * s);
            rect(z, popupBox, pal[11], 15 * s, s);
            text(z, {popupBox.x + 14 * s, popupBox.y + 7 * s, popupBox.w - 28 * s, F},
                 Label("miscellaneous_movement_airstrafe"), pal[2], 13, 2);
            float y = popupBody.y - scroll;
            Box group{popupBody.x, y, popupBody.w, 6 * R + 14 * s};
            rect(z, group, pal[40], 15 * s, 0, popupBody);
            rect(z, group, pal[11], 15 * s, s, popupBody);
            float cy = y + 7 * s;
            for (int i = 0; i < 6; ++i) {
                Box rr{group.x + 7 * s, cy, group.w - 14 * s, R};
                options[std::size_t(i)] = PresetIntersect(rr, popupBody);
                bool en = ModeEnabled(i, cfg);
                float a = optionAvailability[i].initialized ? optionAvailability[i].value : (en ? 1.f : .28f);
                float hv = en ? itemHover[std::size_t(i)].value : 0.f;
                rect(z, rr, alpha(pal[33], .4f * hv), 15 * s / 1.6f, 0, popupBody);
                if (cfg.movementAirModes[i])
                    text(z, {rr.x + 12 * s, rr.y + 7 * s, 14 * s, F}, U"\uf00c", alpha(pal[0], a), 13, 3,
                         popupBody);
                auto key = ModeKey(i);
                text(z, {rr.x + 36 * s, rr.y + 7 * s, rr.w - 48 * s, F}, Label(key.c_str()),
                     alpha(Mix(pal[14], pal[2], hv), a), 13, 0, popupBody);
                cy += R;
            }
            y += group.h + 7 * s;
            group = {popupBody.x, y, popupBody.w, 2 * R + extraHeight + 14 * s};
            rect(z, group, pal[40], 15 * s, 0, popupBody);
            rect(z, group, pal[11], 15 * s, s, popupBody);
            cy = y + 7 * s;
            for (int i = 0; i < count; ++i) {
                Box rr{group.x + 7 * s, cy, group.w - 14 * s, R};
                Box innerClip = PresetIntersect(popupBody, group);
                sliderRows[std::size_t(i)] = ValueVisible(i, cfg) ? PresetIntersect(rr, innerClip) : Box{};
                float trackW = std::trunc(rr.w / 2.5f);
                Box bar{rr.x + rr.w - 12 * s - trackW, rr.y + (R - 6 * s) * .5f, trackW, 6 * s};
                sliders[std::size_t(i)] = ValueVisible(i, cfg) ? PresetIntersect(bar, innerClip) : Box{};
                float hv = itemHover[std::size_t(6 + i)].value;
                rect(z, rr, alpha(pal[33], .4f * hv), 15 * s / 1.6f, 0, innerClip);
                float maximum = float(i == 2   ? 201
                                      : i == 3 ? 90
                                               : 100),
                      v = std::clamp(cfg.movementAirValues[std::size_t(i)] / maximum, 0.f, 1.f);
                rect(z, bar, pal[24], 3 * s, 0, innerClip);
                Box fill = PresetIntersect(innerClip, {bar.x, bar.y, bar.w * v, bar.h});
                if (v > 0 && fill.w > 0)
                    rect(z, bar, pal[25], 3 * s, 0, fill);
                auto key = ValueKey(i);
                text(z, {rr.x + 12 * s, rr.y + 7 * s, std::max(0.f, bar.x - rr.x - 18 * s), F},
                     Label(key.c_str()), Mix(pal[14], pal[2], hv), 13, 0, innerClip);
                cy += R;
            }
            if (maxScroll > 0) {
                float th = std::max(10 * s, popupBody.h * popupBody.h / (popupBody.h + maxScroll));
                rect(z,
                     {popupBox.x + popupBox.w - 5 * s, popupBody.y + (popupBody.h - th) * scroll / maxScroll,
                      3 * s, th},
                     pal[18], 2 * s);
            }
            lastPopup = paint.layers[std::size_t(z)];
            hasLastPopup = true;
            float a = popupMotion.value;
            paint.layers[std::size_t(z)].opacity *= a;
            for (auto& d : paint.layers[std::size_t(z)].draw) {
                d.color.a *= a;
                d.shadowColor.a *= a;
                d.backdropOpacity *= a;
            }
        } else {
            maxScroll = scroll = 0;
            if (hasLastPopup && popupMotion.value > .001f) {
                auto layer = lastPopup;
                layer.opacity *= popupMotion.value;
                for (auto& d : layer.draw) {
                    d.color.a *= popupMotion.value;
                    d.shadowColor.a *= popupMotion.value;
                    d.backdropOpacity *= popupMotion.value;
                }
                paint.layers.push_back(std::move(layer));
            }
        }
        if (popup && popupKind == 0)
            for (int i = 0; i < 4; ++i) {
                auto b = sliders[i];
                float a = sliderTip[i].value * popupMotion.value;
                if (b.w <= 0 || a <= .001f)
                    continue;
                auto value = DecodeUTF8(std::to_string(cfg.movementAirValues[i]) + (i < 2 ? "%" : ""));
                float tw = fonts.NativeTextSize(0, 13 * s, value).w,
                      maximum = float(i == 2   ? 201
                                      : i == 3 ? 90
                                               : 100),
                      t = std::clamp(cfg.movementAirValues[i] / maximum, 0.f, 1.f);
                Box tip = PresetPopupFit(
                    {b.x + b.w * t - tw * .5f - 7 * s, b.y - F - 14 * s, tw + 14 * s, F + 9 * s}, width,
                    height);
                int tz = int(paint.layers.size());
                paint.layers.push_back({tip, 8 * s, true, {}});
                paint.layers[std::size_t(tz)].opacity = a;
                rect(tz, tip, alpha(pal[8], a), 8 * s);
                rect(tz, tip, alpha(pal[11], a), 8 * s, s);
                text(tz, {tip.x + 7 * s, tip.y + 4 * s, tw, F}, value, alpha(pal[0], a), 13);
            }
        int h = Hit(mouseX, mouseY, cfg);
        bool isJump = h == 3 || (h >= 50 && h <= 53);
        if (!modal && isJump && hoverTime >= .3f && drag < 0) {
            auto key = h == 3 ? std::string("miscellaneous_movement_jumpbug") : JumpKey(h - 50);
            auto target = h == 3 ? jumpRow : jumpOptions[std::size_t(h - 50)];
            auto desc = key + "_tooltip";
            lastJumpTip = WorldDescriptionTooltip(fonts, cfg, target, Label(key.c_str()), Label(desc.c_str()),
                                                  width, height, 19.f * 13.f * s);
            hasJumpTip = true;
        }
        if (!modal && hasJumpTip && tooltip.value > .001f && drag < 0 &&
            (isJump || h == 40 || h == 41 || h < 0))
            AppendWorldTooltip(paint, lastJumpTip, tooltip.value);
        if (!modal && !isJump && hoverTime >= .3f && tooltip.value > 0 && drag < 0) {
            std::string key;
            Box target{};
            if (h == 0) {
                key = "miscellaneous_movement_bunnyhop";
                target = row;
            } else if (h == 1) {
                key = "miscellaneous_movement_airstrafe";
                target = airRow;
            } else if (h >= 10 && h <= 15) {
                key = ModeKey(h - 10);
                target = options[std::size_t(h - 10)];
            } else if (h >= 20 && h <= 23) {
                key = ValueKey(h - 20);
                target = sliderRows[std::size_t(h - 20)];
            }
            if (!key.empty()) {
                auto desc = key + "_tooltip";
                auto tip = WorldDescriptionTooltip(fonts, cfg, target, Label(key.c_str()),
                                                   Label(desc.c_str()), width, height);
                AppendWorldTooltip(paint, tip, tooltip.value);
            }
        }
    }
};
}
