#pragma once
#include "menu_core.h"
namespace menu {

struct NativeColorWidth {
    float value = 0, target = 0, from = 0, wait = 0, elapsed = 0;
    bool initialized = false;
    void Observe(float next, bool rgbaChanged) {
        if (!initialized) {
            value = target = from = next;
            initialized = true;
        }
        if (rgbaChanged)
            wait = .2f;
        if (next >= value) {
            value = target = from = next;
            elapsed = 0;
            return;
        }
        if (next != target) {
            from = value;
            target = next;
            elapsed = 0;
        }
    }
    void Tick(float dt) {
        dt = std::max(0.f, dt);
        if (wait > 0) {
            float used = std::min(wait, dt);
            wait -= used;
            dt -= used;
        }
        if (wait > 0 || dt <= 0 || value == target)
            return;
        elapsed = std::min(.2f, elapsed + dt);
        float t = elapsed / .2f;
        value = from + (target - from) * (1 - (1 - t) * (1 - t) * (1 - t));
    }
};
using HudColorWidth = NativeColorWidth;

struct PickerFormatMetrics {
    float font = 12, row = 26, width = 100, marker = 24, arrow = 8, opener = 49, component = 33;
};
inline const char32_t* PickerFormatLabel(int mode) {
    return mode == 0 ? U"RGB" : mode == 1 ? U"HSV" : U"HEX";
}
inline PickerFormatMetrics MeasurePickerFormat(Fonts& fonts, float s, int mode) {
    PickerFormatMetrics m;
    m.font = fonts.PixelHeight(1, 12 * s);
    m.row = m.font + 14 * s;
    auto width = [&](int f, float px, const std::u32string& v) {
        return std::trunc(fonts.NativeTextSize(f, px * s, v).w + .95f);
    };
    m.marker = width(3, 12, U"\uf00c") + 12 * s;
    float intrinsic = 0;
    for (int n = 0; n < 3; ++n)
        intrinsic = std::max(intrinsic, width(1, 12, PickerFormatLabel(n)) + 24 * s + m.marker);
    m.width = std::trunc(intrinsic) + 14 * s;
    m.arrow = fonts.NativeTextSize(3, 11 * s, U"\uf107").w;
    m.opener = width(1, 12, PickerFormatLabel(mode)) + width(3, 12, U"\uf107") + 15 * s;
    m.component = width(1, 12, U"255") + 12 * s;
    return m;
}
inline Box PickerCompactPopup(Box anchor, float w, float h, float s, float viewportW, float viewportH) {
    return {std::clamp(anchor.x + (anchor.w - w) * .5f, 0.f, std::max(0.f, viewportW - w - 10 * s)),
            std::clamp(anchor.y + (anchor.h - h) * .5f, 0.f, std::max(0.f, viewportH - h - 10 * s)), w, h};
}

inline void DrawPickerAlphaMarker(Canvas& canvas, float x, float y, float s) {
    DrawMenuCircleShadow(canvas, x, y, 7 * s, 2 * s, 2 * s, 10 * s, {0, 0, 0, 128.f / 255});
    canvas.RoundRect({x - 7 * s, y - 7 * s, 14 * s, 14 * s}, 7 * s, {1, 1, 1, 1});
}

inline Color PickerFieldFill(Color base, float motion) {
    base.a *= .2f + .2f * motion;
    return base;
}
inline Color PickerButtonFill(Color base, float motion) {
    base.a *= .4f * motion;
    return base;
}

inline Color PickerChecker(float x, float y, float step) {
    bool tile = (int(std::floor(x / step)) + int(std::floor(y / step))) % 2 == 0;
    return tile ? Color{224.f / 255, 224.f / 255, 224.f / 255, 1} : Color{1, 1, 1, 217.f / 255};
}
inline Color PickerOver(Color below, Color above) {
    float a = above.a + below.a * (1 - above.a);
    if (a <= 0)
        return {};
    return {(above.r * above.a + below.r * below.a * (1 - above.a)) / a,
            (above.g * above.a + below.g * below.a * (1 - above.a)) / a,
            (above.b * above.a + below.b * below.a * (1 - above.a)) / a, a};
}

inline Color PickerPacked(Color c) {
    return {Canvas::Byte(c.r) / 255.f, Canvas::Byte(c.g) / 255.f, Canvas::Byte(c.b) / 255.f,
            Canvas::Byte(c.a) / 255.f};
}
inline void DrawPickerPreview(Canvas& canvas, Box mask, float s, float frameHeight, Color first, Color last,
                              bool gradient, bool squareFrame) {
    first = PickerPacked(first);
    last = PickerPacked(last);
    float margin = (frameHeight - mask.h) * .5f;
    Box raw{squareFrame ? mask.x - (frameHeight - mask.w) * .5f : mask.x, mask.y - margin,
            squareFrame ? frameHeight : mask.w, frameHeight};
    for (int y = std::max(0, int(std::floor(mask.y)));
         y < std::min(canvas.height, int(std::ceil(mask.y + mask.h))); ++y)
        for (int x = std::max(0, int(std::floor(mask.x)));
             x < std::min(canvas.width, int(std::ceil(mask.x + mask.w))); ++x) {
            float coverage = std::clamp(.5f - BoxDistance(mask, 6 * s, x + .5f, y + .5f), 0.f, 1.f);
            if (coverage <= 0)
                continue;
            float xx = x + .5f - raw.x, yy = y + .5f - raw.y,
                  t = std::clamp(xx / std::max(1.f, raw.w), 0.f, 1.f);
            canvas.Blend(x, y,
                         PickerOver(PickerChecker(xx, yy, std::max(.01f, raw.h / 3)),
                                    gradient ? Mix(first, last, t) : first),
                         coverage);
        }
}
inline std::uint64_t PickerPreviewStamp(Color first, Color last, bool gradient, bool squareFrame) {
    auto packed = [](Color c) {
        return (std::uint64_t(Canvas::Byte(c.r)) << 24) | (std::uint64_t(Canvas::Byte(c.g)) << 16) |
               (std::uint64_t(Canvas::Byte(c.b)) << 8) | Canvas::Byte(c.a);
    };
    std::uint64_t hash = 14695981039346656037ull;
    for (auto v : {packed(first), packed(last), std::uint64_t(gradient), std::uint64_t(squareFrame)})
        for (int i = 0; i < 8; ++i) {
            hash ^= (v >> (8 * i)) & 255;
            hash *= 1099511628211ull;
        }
    return hash;
}

inline void DrawPickerSaved(Canvas& canvas, Box b, float s, Color color, Color rim) {
    for (int yy = std::max(0, int(std::floor(b.y))); yy < std::min(canvas.height, int(std::ceil(b.y + b.h)));
         ++yy)
        for (int xx = std::max(0, int(std::floor(b.x)));
             xx < std::min(canvas.width, int(std::ceil(b.x + b.w))); ++xx) {
            Box inside{b.x + s, b.y + s, b.w - 2 * s, b.h - 2 * s};
            Color col = PickerOver(rim, PickerChecker(xx + .5f - b.x, yy + .5f - b.y, b.h / 3));
            Color overlay = color;
            overlay.a *= std::clamp(.5f - BoxDistance(inside, 6 * s, xx + .5f, yy + .5f), 0.f, 1.f);
            col = PickerOver(col, overlay);
            float coverage = std::clamp(.5f - BoxDistance(b, 6 * s, xx + .5f, yy + .5f), 0.f, 1.f);
            canvas.Blend(xx, yy, col, coverage);
        }
}

}
