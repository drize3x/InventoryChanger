#pragma once
#include "menu_core.h"
namespace menu {

inline bool PresetSettingsEqual(const Settings& a, const Settings& b) {
    if (a.windowsScale != b.windowsScale || a.theme != b.theme || a.scale != b.scale ||
        a.textPx != b.textPx || a.face != b.face || a.blur != b.blur || a.sigma != b.sigma ||
        a.customAccent != b.customAccent || a.accent.r != b.accent.r || a.accent.g != b.accent.g ||
        a.accent.b != b.accent.b)
        return false;
    auto color = [](Color x, Color y) { return x.r == y.r && x.g == y.g && x.b == y.b && x.a == y.a; };
    auto colors = [&](const auto& x, const auto& y) {
        for (std::size_t n = 0; n < x.size(); ++n)
            if (!color(x[n], y[n]))
                return false;
        return true;
    };
    if (a.worldESP != b.worldESP || a.worldView.value != b.worldView.value ||
        a.worldHud.value != b.worldHud.value || a.worldHud.scopeColorMode != b.worldHud.scopeColorMode ||
        a.worldHud.penetrationColorEnabled != b.worldHud.penetrationColorEnabled ||
        !colors(a.worldHud.colors, b.worldHud.colors) || a.worldMisc.value != b.worldMisc.value ||
        a.worldAmbience != b.worldAmbience || !colors(a.worldMisc.colors, b.worldMisc.colors) ||
        a.watermarkOrder != b.watermarkOrder || a.players.value != b.players.value ||
        !colors(a.players.colors, b.players.colors) || a.players.espEnabled != b.players.espEnabled ||
        a.players.espLayout != b.players.espLayout ||
        a.players.universalScaling != b.players.universalScaling)
        return false;
    for (std::size_t t = 0; t < a.players.espSettings.size(); ++t)
        for (std::size_t n = 0; n < a.players.espSettings[t].size(); ++n) {
            const auto& x = a.players.espSettings[t][n];
            const auto& y = b.players.espSettings[t][n];
            if (x.colorMode != y.colorMode || !colors(x.colors, y.colors))
                return false;
            for (const auto& f : ESPFields(int(n)))
                if (x.value[std::size_t(f.slot)] != y.value[std::size_t(f.slot)])
                    return false;
        }
    if (a.keybinds.size() != b.keybinds.size())
        return false;
    for (std::size_t n = 0; n < a.keybinds.size(); ++n) {
        const auto& x = a.keybinds[n];
        const auto& y = b.keybinds[n];
        if (x.id != y.id || x.target != y.target || x.key != y.key || x.mode != y.mode ||
            x.shown != y.shown || x.value != y.value)
            return false;
    }
    return true;
}
struct PresetChangeTracker {
    std::shared_ptr<const Settings> previous;
    std::uint64_t revision = 0;
    bool Observe(const Settings& cfg) {
        if (previous && PresetSettingsEqual(*previous, cfg))
            return false;
        previous = std::make_shared<Settings>(cfg);
        ++revision;
        return true;
    }
    void Reset() {
        previous.reset();
        revision = 0;
    }
};
}
