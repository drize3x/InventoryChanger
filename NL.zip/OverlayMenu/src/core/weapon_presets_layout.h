#pragma once

namespace menu {
struct WeaponPresetsLayout {

    static constexpr float ItemSpacingX = 15;

    static float GlobalGap(float scale) {
        return 5 * scale;
    }
    static constexpr float Width = 230, MaxHeight = 400, ListMaxHeight = 250;
    static constexpr float WeaponPickerMinWidth = 160, WeaponPickerMaxHeight = 250;
    static constexpr float IconHeight = 12, ChipPadding = 5, RemoveSize = 25, AnimationSeconds = .2f;

    static Box FitNative(Box b, float width, float height, float safe) {
        float sx = width > 2 * safe ? safe : 0, sy = height > 2 * safe ? safe : 0;
        b.w = std::min(b.w, std::max(0.f, width - 2 * sx));
        b.h = std::min(b.h, std::max(0.f, height - 2 * sy));
        b.x = std::trunc(std::clamp(b.x, sx, std::max(sx, width - sx - b.w)));
        b.y = std::trunc(std::clamp(b.y, sy, std::max(sy, height - sy - b.h)));
        return b;
    }
    static Box ComboPopup(Box item, float w, float h, float width, float height, float safe) {
        return FitNative({item.x + (item.w - w) * .5f, item.y - item.h * .5f, w, h}, width, height, safe);
    }

    static Box PointPopup(Box point, float w, float h, float width, float height, float safe) {
        float sx = width > 2 * safe ? safe : 0, sy = height > 2 * safe ? safe : 0, x = point.x, y = point.y;
        if (w <= width - sx - x)
            return FitNative({x, y, w, h}, width, height, safe);
        if (h <= height - sy - y)
            return FitNative({x, y, w, h}, width, height, safe);
        if (h <= y - sy)
            return FitNative({x, y - h, w, h}, width, height, safe);
        if (w <= x - sx)
            return FitNative({x - w, y, w, h}, width, height, safe);
        return FitNative({x, y, w, h}, width, height, safe);
    }

    static float WheelTarget(float current, float delta, float maximum, float innerHeight, float fontHeight,
                             unsigned lines) {
        float step = innerHeight;
        if (lines <= 120)
            step = std::trunc(std::min(fontHeight * float(lines), innerHeight * .67f));
        return std::clamp(current - step * delta, 0.f, maximum);
    }

    static float ScrollFrame(float current, float target, float maximum, float dt, float speed = 1) {
        target = std::clamp(target, 0.f, maximum);
        current = std::clamp(current, 0.f, maximum);
        float diff = target - current;
        if (diff > .1f)
            current += std::max(20 * speed * std::abs(diff) * dt, .1f);
        else if (-diff > .1f)
            current -= std::max(20 * speed * std::abs(diff) * dt, .1f);
        else
            current = target;
        return std::clamp(current, 0.f, maximum);
    }
    static float HeaderWidth(float text, float arrow, float padding, float scale) {
        return std::min(150 * scale, text + arrow + 3 * padding);
    }
};
}
