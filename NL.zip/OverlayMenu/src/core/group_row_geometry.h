#pragma once
#include "menu_core.h"
namespace menu {

inline Box GroupRowHoverBounds(Box row, float s) {
    return {row.x - 13 * s, row.y - 6 * s, row.w + 26 * s, row.h + 12 * s};
}
inline unsigned GroupRowCorners(int index, int count) {
    return (index == 0 ? 3u : 0u) | (index == count - 1 ? 12u : 0u);
}
inline Box GroupRowSeparator(Box row, float s) {
    return {row.x, row.y - 8 * s, row.w, s};
}

inline bool GroupTwoColumnFits(Box content, float s) {
    return content.w >= 360 * s;
}
inline float GroupTwoColumnWidth(Box content, float s) {
    return GroupTwoColumnFits(content, s) ? std::min(300 * s, std::max(0.f, (content.w - 45 * s) * .5f))
                                          : std::max(0.f, std::min(300 * s, content.w - 30 * s));
}
inline float GroupRowPitch(float fontHeight, float s) {
    return fontHeight + 6 * s + 15 * s;
}
inline float GroupCardHeight(int rows, float fontHeight, float s) {
    return 14 * s + rows * (fontHeight + 6 * s) + std::max(0, rows - 1) * 15 * s;
}
}
