#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include <cmath>
namespace wm {

struct OriginalPrimitive {
    std::array<std::uint32_t, 96> data{};
    void I(std::size_t byteOffset, std::uint32_t v) {
        data.at(byteOffset / 4) = v;
    }
    void F(std::size_t byteOffset, float v) {
        static_assert(sizeof(v) == 4);
        std::uint32_t bits;
        std::memcpy(&bits, &v, 4);
        I(byteOffset, bits);
    }
};
inline OriginalPrimitive MakeOriginalRectPrimitive(float w, float h, const std::array<float, 4>& color,
                                                   float radius, float smoothing, float thickness,
                                                   bool sampleBackdrop) {
    OriginalPrimitive p{};
    p.I(0x00, 1);
    p.I(0x04, sampleBackdrop ? 2 : 0);
    p.I(0x08, 1);
    p.F(0x10, w);
    p.F(0x14, h);
    p.F(0x20, 1);
    p.F(0x24, 1);
    for (std::size_t corner = 0; corner < 4; ++corner) {
        for (std::size_t channel = 0; channel < 4; ++channel) {
            float c = std::floor(std::clamp(color[channel], 0.f, 1.f) * 255.f + .5f) / 255.f;
            p.F(0x50 + 16 * corner + 4 * channel, c);
        }
        p.F(0xb0 + 4 * corner, std::clamp(radius, 0.f, .5f * std::min(w, h)));
    }
    p.F(0xc0, thickness);
    p.F(0xc4, std::clamp(smoothing, 0.f, 1.f));
    return p;
}

inline OriginalPrimitive MakeOriginalArcPrimitive(float diameter, const std::array<float, 4>& color,
                                                  float thickness, float start, float end) {
    OriginalPrimitive p{};
    p.I(0x00, 2);
    p.I(0x08, 1);
    p.F(0x10, diameter);
    p.F(0x14, diameter);
    p.F(0x20, 1);
    p.F(0x24, 1);
    for (std::size_t k = 0; k < 4; ++k)
        p.F(0x90 + 4 * k, std::floor(std::clamp(color[k], 0.f, 1.f) * 255.f + .5f) / 255.f);
    p.F(0xc8, start);
    p.F(0xcc, end);
    p.F(0xd0, 0);
    p.F(0xd4, thickness);
    return p;
}

inline OriginalPrimitive MakeOriginalIndicatorLine(float w, float h, const std::array<float, 4>& color,
                                                   float radius, float shadow = 0) {
    radius = std::clamp(radius, 0.f, .5f * std::min(w, h));
    auto p = MakeOriginalRectPrimitive(w + shadow, h + shadow, {0, 0, 0, 0}, radius, 0, 0, false);
    p.I(0x00, 3);
    p.I(0xd8, 0);
    p.I(0xdc, 6);
    constexpr float stops[6] = {0, .1f, .5f, .5f, .9f, 1};
    for (int i = 0; i < 6; ++i) {
        p.F(0x160 + 4 * i, stops[i]);
        for (int ch = 0; ch < 4; ++ch) {
            float v = color[ch];
            if (ch == 3 && (i < 2 || i > 3))
                v = 0;
            p.F(0xe0 + 16 * i + 4 * ch, std::floor(std::clamp(v, 0.f, 1.f) * 255.f + .5f) / 255.f);
        }
    }
    if (shadow > 0) {
        p.I(0x0c, 1);
        for (int ch = 0; ch < 4; ++ch) {
            float v = color[ch] * (ch == 3 ? .75f : 1.f);
            p.F(0x30 + 4 * ch, std::floor(std::clamp(v, 0.f, 1.f) * 255.f + .5f) / 255.f);
        }
        p.F(0x48, shadow);
    }
    return p;
}

inline OriginalPrimitive MakeOriginalHorizontalGradient(float w, float h, const std::array<float, 4>& left,
                                                        const std::array<float, 4>& right, float radius) {
    auto p = MakeOriginalRectPrimitive(w, h, left, radius, 1, 0, false);
    for (std::size_t corner : {std::size_t(1), std::size_t(2)})
        for (std::size_t channel = 0; channel < 4; ++channel)
            p.F(0x50 + 16 * corner + 4 * channel,
                std::floor(std::clamp(right[channel], 0.f, 1.f) * 255.f + .5f) / 255.f);
    return p;
}

inline OriginalPrimitive MakeOriginalShadowPrimitive(float w, float h, const std::array<float, 4>& color,
                                                     float radius, float size, float ox = 0, float oy = 0,
                                                     float smoothing = 1) {

    radius = std::clamp(radius, 0.f, .5f * std::min(w, h));
    auto p = MakeOriginalRectPrimitive(w + size + 2 * std::abs(ox), h + size + 2 * std::abs(oy), {0, 0, 0, 0},
                                       radius, 0, 0, false);
    p.I(0x0c, 2);
    for (int k = 0; k < 4; ++k)
        p.F(0x30 + 4 * k, std::floor(std::clamp(color[k], 0.f, 1.f) * 255.f + .5f) / 255.f);
    p.F(0x40, ox);
    p.F(0x44, oy);
    p.F(0x48, size);
    p.F(0xc4, std::clamp(smoothing, 0.f, 1.f));
    return p;
}

inline OriginalPrimitive MakeOriginalInnerPrimitive(float w, float h, const std::array<float, 4>& fill,
                                                    const std::array<float, 4>& glow, float radius,
                                                    float size) {
    auto p = MakeOriginalRectPrimitive(w, h, fill, radius, 1, 0, false);
    p.I(0x0c, 3);
    for (int k = 0; k < 4; ++k)
        p.F(0x30 + 4 * k, std::floor(std::clamp(glow[k], 0.f, 1.f) * 255.f + .5f) / 255.f);
    p.F(0x48, size);
    return p;
}
static_assert(sizeof(OriginalPrimitive) == 0x180);
}
