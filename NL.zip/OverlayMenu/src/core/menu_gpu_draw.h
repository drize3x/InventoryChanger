#pragma once
#include "renderer_dx11.h"
#include "menu_core.h"
namespace menu {
inline void DrawMenuGPU(wm::RendererDX11& renderer, ID3D11RenderTargetView* target, int width, int height,
                        const Canvas& overlay, const Settings& cfg, const State& state, const Layout& layout,
                        bool upload = true, float layerX = 0, float layerY = 0) {
    const auto pal = CurrentPalette(cfg);
    const float s = cfg.scale;
    auto rectangle = [&](Box b, Color c, float radius, float thickness = 0, bool texture = false,
                         float smoothing = 0) {
        renderer.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {c.r, c.g, c.b, c.a}, radius, smoothing,
                                  thickness, texture, cfg.blur);
    };

    if (cfg.blur)
        rectangle(layout.outer, {1, 1, 1, 1}, 16 * s, 0, true, 1);
    rectangle(layout.outer, pal[6], 16 * s, 0, false, 1);

    const auto shadow = pal[38];
    renderer.DrawOriginalRect(target, layout.outer.x, layout.outer.y, layout.outer.w, layout.outer.h,
                              {0, 0, 0, 0}, 16 * s, 0, 0, false, false, 18 * s,
                              {shadow.r, shadow.g, shadow.b, shadow.a});

    Color contentFill = pal[9];
    contentFill.a *= .7f;
    rectangle(layout.content, contentFill, 16 * s, 0, false, 1);
    rectangle(layout.content, pal[11], 16 * s, 1 * s, false, 1);
    Color profileHi = pal[33];
    profileHi.a *= .4f * state.profileAnim;
    rectangle(ProfileHighlight(layout, s), profileHi, 6 * s);

    for (int i = 0; i < (layout.visualsOpen ? 7 : 5); ++i) {
        const auto& b = i < 5 ? layout.rows[i] : layout.visualRows[i - 5];
        auto h = dump_menu::nav_highlight(b.x, b.y, layout.sidebar.x, layout.sidebar.w, b.h, s);
        Color c = pal[33];
        c.a = dump_menu::highlight_alpha(c.a, state.anim[i], i >= 5 ? layout.visualsAlpha : 1.f);
        if (c.a > 0)
            rectangle({h.left, h.top, h.right - h.left, h.bottom - h.top}, c, 8 * s);
    }
    {
        const auto& b = layout.extensionsRow;
        auto h = dump_menu::nav_highlight(b.x, b.y, layout.sidebar.x, layout.sidebar.w, b.h, s);
        Color c = pal[33];
        c.a = dump_menu::highlight_alpha(c.a, state.anim[7], 1.f);
        if (c.a > 0)
            rectangle({h.left, h.top, h.right - h.left, h.bottom - h.top}, c, 8 * s);
    }
    rectangle({layout.sidebar.x + 15 * s, layout.sidebar.y + 10 * s, 35 * s, 35 * s}, pal[42], 8 * s);
    renderer.DrawLayer(target, width, height, overlay.rgba.data(), overlay.width, overlay.height, layerX,
                       layerY, float(overlay.width), 0, 0, upload);
}
}
