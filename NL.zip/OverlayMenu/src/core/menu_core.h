#pragma once

#include "menu_geometry.h"
#include "content_transition.h"
#include "gaussian_kernel.h"
#include "logo_pixels.h"
#include <ft2build.h>
#include FT_FREETYPE_H
#include FT_MODULE_H
#include FT_GLYPH_H
#include FT_STROKER_H
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <ctime>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <memory>
#include <iterator>
#include <utility>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
#include "ambience_sky_custom.h"
namespace menu {
struct Color {
    float r, g, b, a = 1;
};
#include "menu_palette.h"
struct Box {
    float x, y, w, h;
    bool Contains(float px, float py) const {
        return px >= x && py >= y && px < x + w && py < y + h;
    }
};
inline Color Mix(Color a, Color b, float t) {
    return {a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t, a.a + (b.a - a.a) * t};
}
struct Canvas {
    int width, height;
    std::vector<unsigned char> rgba;
    Canvas(int w, int h) : width(w), height(h), rgba(std::size_t(w) * h * 4) {}
    void Clear(Color c) {
        for (std::size_t i = 0; i < rgba.size(); i += 4) {
            rgba[i] = Byte(c.r * c.a);
            rgba[i + 1] = Byte(c.g * c.a);
            rgba[i + 2] = Byte(c.b * c.a);
            rgba[i + 3] = Byte(c.a);
        }
    }
    static unsigned char Byte(float v) {
        return static_cast<unsigned char>(std::clamp(v * 255.f + .5f, 0.f, 255.f));
    }
    void Blend(int x, int y, Color c, float coverage = 1) {
        if (x < 0 || y < 0 || x >= width || y >= height)
            return;
        float a = std::clamp(c.a * coverage, 0.f, 1.f);
        auto* p = rgba.data() + 4 * (std::size_t(y) * width + x);
        p[0] = Byte(c.r * a + p[0] / 255.f * (1 - a));
        p[1] = Byte(c.g * a + p[1] / 255.f * (1 - a));
        p[2] = Byte(c.b * a + p[2] / 255.f * (1 - a));
        p[3] = Byte(a + p[3] / 255.f * (1 - a));
    }
    void RoundRect(Box b, float radius, Color fill, Color stroke = {0, 0, 0, 0}, float thickness = 0,
                   float smoothing = 0, unsigned cornerMask = 15, const Box* clip = nullptr) {
        const float r = std::clamp(radius, 0.f, std::min(b.w, b.h) * .5f) /
                        std::max(1 - .6f * smoothing, .01f),
                    n = 2 + 3.6f * smoothing;
        for (int y = std::max(0, int(std::floor(b.y - 1)));
             y < std::min(height, int(std::ceil(b.y + b.h + 1))); ++y)
            for (int x = std::max(0, int(std::floor(b.x - 1)));
                 x < std::min(width, int(std::ceil(b.x + b.w + 1))); ++x) {
                if (clip && !clip->Contains(x + .5f, y + .5f))
                    continue;
                float rr = (cornerMask == 15 || (cornerMask & (1u << ((x + .5f >= b.x + b.w * .5f ? 1 : 0) +
                                                                      (y + .5f >= b.y + b.h * .5f ? 2 : 0)))))
                               ? r
                               : 0;
                float qx = std::abs(x + .5f - b.x - b.w * .5f) - b.w * .5f + rr;
                float qy = std::abs(y + .5f - b.y - b.h * .5f) - b.h * .5f + rr;
                float dx = std::max(qx, 0.f), dy = std::max(qy, 0.f);
                float d = (smoothing > 0 ? std::pow(std::pow(dx, n) + std::pow(dy, n), 1 / n)
                                         : std::hypot(dx, dy)) +
                          std::min(std::max(qx, qy), 0.f) - rr;
                float outer = std::clamp(.5f - d, 0.f, 1.f);
                Blend(x, y, fill, outer);
                if (thickness > 0)
                    Blend(x, y, stroke, outer - std::clamp(.5f - d - thickness, 0.f, 1.f));
            }
    }
};
struct Glyph {
    int w = 0, h = 0, left = 0, top = 0;
    float advance = 0;
    FT_Pos lsbDelta = 0, rsbDelta = 0;
    FT_UInt index = 0;
    std::vector<unsigned char> alpha;
};
struct ESPGlyph {
    int left = 0, top = 0;
    std::shared_ptr<const Canvas> image;
};
class Fonts {
    struct Face {
        FT_Face handle = nullptr;
        std::vector<unsigned char> bytes;
        std::unordered_map<std::uint64_t, Glyph> glyphs;
        std::unordered_map<std::uint64_t, ESPGlyph> espGlyphs;
        ~Face() {
            if (handle)
                FT_Done_Face(handle);
        }
    };
    FT_Library lib = nullptr, espLib = nullptr;
    std::array<std::unique_ptr<Face>, 10> faces;
    FT_Face Size(int id, float px) {
        FT_Face f = faces.at(id)->handle;
        if (FT_Set_Char_Size(f, 0, FT_F26Dot6(std::max(1.f, px * 64)), 72, 72))
            throw std::runtime_error("FreeType size failed");
        return f;
    }

public:
    explicit Fonts(const std::filesystem::path& directory) {
        if (FT_Init_FreeType(&lib))
            throw std::runtime_error("FreeType init failed");
        try {

            if (FT_Init_FreeType(&espLib))
                throw std::runtime_error("ESP FreeType init failed");
            FT_UInt hostVersion = 40, espVersion = 42;
            if (FT_Property_Set(lib, "truetype", "interpreter-version", &hostVersion) ||
                FT_Property_Set(espLib, "truetype", "interpreter-version", &espVersion))
                throw std::runtime_error(
                    "ESP requires bundled dump-matched FreeType v42; rebuild vendor/freetype");
            const char* names[] = {"NotoSans-Regular.ttf", "NotoSans-Medium.ttf",    "NotoSans-SemiBold.ttf",
                                   "Menu-icons.otf",       "ESP-settings-icons.otf", "Verdana.ttf",
                                   "SmallFonts.ttf",       "Stratum2Mono-Bold.otf",  "Verdana-Bold.ttf",
                                   "Calibri-Bold.ttf"};
            for (int id = 0; id < 10; ++id) {
                auto f = std::make_unique<Face>();
                auto path = directory / names[id];

                if ((id == 5 || id == 8 || id == 9) && !std::filesystem::exists(path)) {
                    std::filesystem::path windowsDir;
#ifdef _MSC_VER
                    wchar_t* raw = nullptr;
                    std::size_t length = 0;
                    const auto envError = _wdupenv_s(&raw, &length, L"WINDIR");
                    std::unique_ptr<wchar_t, decltype(&std::free)> env(raw, &std::free);
                    if (envError == 0 && env && length > 1)
                        windowsDir = env.get();
#else
                    if (const char* win = std::getenv("WINDIR"))
                        windowsDir = win;
#endif
                    if (!windowsDir.empty())
                        path = windowsDir / "Fonts" /
                               (id == 5   ? "verdana.ttf"
                                : id == 8 ? "verdanab.ttf"
                                          : "calibrib.ttf");
#ifndef _WIN32
                    else
                        path =
                            std::filesystem::path("/usr/share/fonts/msttcore") / (id == 5   ? "verdana.ttf"
                                                                                  : id == 8 ? "verdanab.ttf"
                                                                                            : "calibrib.ttf");
#else
                    else
                        path = std::filesystem::path("C:/Windows/Fonts") / (id == 5   ? "verdana.ttf"
                                                                            : id == 8 ? "verdanab.ttf"
                                                                                      : "calibrib.ttf");
#endif
                }
                if (id == 9 && !std::filesystem::exists(path))
                    path = directory / "NotoSans-SemiBold.ttf";
                std::ifstream in(path, std::ios::binary);
                if (!in)
                    throw std::runtime_error(std::string("Missing font: ") + names[id]);
                f->bytes.assign(std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>());
                if (FT_New_Memory_Face(id >= 5 && id <= 8 ? espLib : lib, f->bytes.data(),
                                       FT_Long(f->bytes.size()), 0, &f->handle)) {
                    throw std::runtime_error("Cannot decode bundled font");
                }
                FT_Select_Charmap(f->handle, FT_ENCODING_UNICODE);
                faces[id] = std::move(f);
            }
        } catch (...) {
            for (auto& f : faces)
                f.reset();
            if (espLib)
                FT_Done_FreeType(espLib);
            espLib = nullptr;
            FT_Done_FreeType(lib);
            lib = nullptr;
            throw;
        }
    }
    ~Fonts() {
        for (auto& f : faces)
            f.reset();
        if (espLib)
            FT_Done_FreeType(espLib);
        if (lib)
            FT_Done_FreeType(lib);
    }
    Fonts(const Fonts&) = delete;
    Fonts& operator=(const Fonts&) = delete;

    static unsigned ESPBuilderFlags(int id) {
        switch (id) {
        case 5:
        case 8:
            return 0x2A00;
        case 6:
            return 0x2992;
        case 7:
            return 0x2A0C;
        default:
            throw std::runtime_error("Not an ESP face");
        }
    }
    static FT_Int32 ESPLoadFlags(int id) {
        const auto user = ESPBuilderFlags(id);
        FT_Int32 flags = FT_LOAD_NO_BITMAP | (user & 1 ? FT_LOAD_NO_HINTING : 0) |
                         (user & 4 ? FT_LOAD_FORCE_AUTOHINT : FT_LOAD_NO_AUTOHINT);
        if (user & 8)
            flags |= FT_LOAD_TARGET_LIGHT;
        else if (user & 16)
            flags |= FT_LOAD_TARGET_MONO;
        if (user & 0x400)
            flags |= FT_LOAD_COLOR;
        return flags;
    }
    const Glyph& Get(int id, float px, std::uint32_t cp) {
        std::uint64_t key = (std::uint64_t(std::max(1, int(px * 64))) << 32) | cp;
        auto& cache = faces.at(id)->glyphs;
        auto found = cache.find(key);
        if (found != cache.end())
            return found->second;
        auto f = Size(id, px);
        FT_UInt index = FT_Get_Char_Index(f, cp);
        if (!index && id == 3) {
            f = Size(4, px);
            index = FT_Get_Char_Index(f, cp);
        }
        if (!index && id != 3)
            index = FT_Get_Char_Index(f, '?');
        if (!index)
            throw std::runtime_error("Missing glyph in bundled font");

        FT_Int32 flags = id >= 5 && id <= 8 ? ESPLoadFlags(id)
                                            : (FT_LOAD_NO_BITMAP | FT_LOAD_NO_AUTOHINT |
                                               (id == 3 ? FT_LOAD_TARGET_LIGHT : FT_LOAD_TARGET_NORMAL));
        if (FT_Load_Glyph(f, index, flags) ||
            FT_Render_Glyph(f->glyph, id == 6 ? FT_RENDER_MODE_MONO : FT_RENDER_MODE_NORMAL))
            throw std::runtime_error("Glyph rasterization failed");
        auto& bm = f->glyph->bitmap;
        Glyph g;
        g.w = int(bm.width);
        g.h = int(bm.rows);
        g.left = f->glyph->bitmap_left;
        g.top = f->glyph->bitmap_top;
        g.advance = f->glyph->advance.x / 64.f;
        g.index = index;
        g.lsbDelta = f->glyph->lsb_delta;
        g.rsbDelta = f->glyph->rsb_delta;
        g.alpha.resize(std::size_t(g.w) * g.h);
        for (int y = 0; y < g.h; ++y) {
            auto* row = bm.buffer + (bm.pitch >= 0 ? y : g.h - 1 - y) * std::abs(bm.pitch);
            for (int x = 0; x < g.w; ++x)
                g.alpha[std::size_t(y) * g.w + x] =
                    bm.pixel_mode == FT_PIXEL_MODE_MONO ? (((row[x / 8] >> (7 - x % 8)) & 1) * 255) : row[x];
        }
        return cache.emplace(key, std::move(g)).first->second;
    }
    float Width(int id, float px, const std::u32string& str) {
        float width = 0;
        for (auto cp : str)
            width += Get(id, px, cp).advance;
        return width;
    }

    float PixelHeight(int id, float px) {
        if (id >= 5 && id <= 8) {
            const auto& cap = GetESP(id, px, U'A');
            return float(cap.image->height - ((ESPBuilderFlags(id) & 0x200) ? 1 : 0));
        }
        const auto& m = Size(id, px)->size->metrics;
        return float((m.ascender - m.descender + 63) >> 6);
    }

    Box NativeTextSize(int id, float px, const std::u32string& str) {
        float x = 0, w = 0, h = 0, f = PixelHeight(id, px);
        for (auto cp : str) {
            if (!cp)
                break;
            if (cp == U'\r' || cp == 0xfe0f)
                continue;
            if (cp == U'\n') {
                w = std::max(w, x);
                h += f;
                x = 0;
            } else
                x += std::ceil(Get(id, px, cp).advance);
        }
        w = std::max(w, x);
        if (x > 0 || h == 0)
            h += f;
        return {0, 0, w, h};
    }

    float ESPPairAdjustment(int id, float px, FT_UInt previous, FT_Pos previousRsb, const Glyph& current) {
        if (!previous)
            return 0;
        auto face = Size(id, px);
        FT_Vector kern{};
        if (FT_HAS_KERNING(face) && FT_Get_Kerning(face, previous, current.index, FT_KERNING_UNFITTED, &kern))
            throw std::runtime_error("ESP kerning failed");
        return std::floor((kern.x + current.lsbDelta - previousRsb + 32) / 64.f);
    }
    Box ESPTextSize(int id, float px, const std::u32string& str) {
        float x = 0, w = 0, h = 0, f = PixelHeight(id, px);
        FT_UInt previous = 0;
        FT_Pos rsb = 0;
        for (auto cp : str) {
            if (!cp)
                break;
            if (cp == U'\r' || cp == 0xfe0f)
                continue;
            if (cp == U'\n') {
                w = std::max(w, x);
                h += f;
                x = 0;
                previous = 0;
                rsb = 0;
                continue;
            }
            const auto& g = Get(id, px, cp);
            x += ESPPairAdjustment(id, px, previous, rsb, g) + std::ceil(g.advance);
            previous = g.index;
            rsb = g.rsbDelta;
        }
        w = std::max(w, x);
        if (x > 0 || h == 0)
            h += f;
        return {0, 0, w, h};
    }

    void NativeText(Canvas& c, int id, float px, const std::u32string& str, float globalX, float globalY,
                    Color color, float canvasX = 0, float canvasY = 0, const Box* clip = nullptr) {
        auto face = Size(id, px);
        float asc = std::trunc(face->size->metrics.ascender / 64.f + .5f), f = PixelHeight(id, px);
        float origin = std::trunc(globalX), pen = origin, y = std::trunc(globalY);
        auto q = [](float v) { return std::trunc(std::clamp(v, 0.f, 1.f) * 255 + .5f) / 255.f; };
        color = {q(color.r), q(color.g), q(color.b), q(color.a)};
        for (auto cp : str) {
            if (!cp)
                break;
            if (cp == U'\r' || cp == 0xfe0f)
                continue;
            if (cp == U'\n') {
                pen = origin;
                y += f;
                continue;
            }
            const auto& g = Get(id, px, cp);
            int gx = int(pen + g.left - canvasX), gy = int(y + asc - g.top - canvasY);
            for (int yy = 0; yy < g.h; ++yy) {
                for (int xx = 0; xx < g.w; ++xx) {
                    if (!clip || clip->Contains(gx + xx + .5f, gy + yy + .5f))
                        c.Blend(gx + xx, gy + yy, color, g.alpha[std::size_t(yy) * g.w + xx] / 255.f);
                }
            }
            pen += std::ceil(g.advance);
        }
    }

    const ESPGlyph& GetESP(int id, float px, std::uint32_t cp) {
        const auto key = (std::uint64_t(std::max(1, int(px * 64))) << 32) | cp;
        auto& cache = faces.at(id)->espGlyphs;
        auto it = cache.find(key);
        if (it != cache.end())
            return it->second;
        const auto& g = Get(id, px, cp);
        Glyph stroke;
        bool outlined = (ESPBuilderFlags(id) & 0x100) != 0;
        if (outlined) {
            auto face = Size(id, px);
            FT_Glyph glyph = nullptr;
            FT_Stroker stroker = nullptr;
            if (FT_Load_Glyph(face, g.index, ESPLoadFlags(id)) || FT_Get_Glyph(face->glyph, &glyph))
                throw std::runtime_error("ESP outline glyph failed");
            if (FT_Stroker_New(espLib, &stroker)) {
                FT_Done_Glyph(glyph);
                throw std::runtime_error("ESP stroker failed");
            }
            FT_Stroker_Set(stroker, 64, FT_STROKER_LINECAP_ROUND, FT_STROKER_LINEJOIN_ROUND, 0);
            auto err = FT_Glyph_StrokeBorder(&glyph, stroker, 0, 1);
            FT_Stroker_Done(stroker);
            if (!err)
                err = FT_Glyph_To_Bitmap(&glyph, FT_RENDER_MODE_MONO, nullptr, 1);
            if (err) {
                FT_Done_Glyph(glyph);
                throw std::runtime_error("ESP outline raster failed");
            }
            auto bitmap = reinterpret_cast<FT_BitmapGlyph>(glyph);
            const auto& bm = bitmap->bitmap;
            stroke.w = int(bm.width);
            stroke.h = int(bm.rows);
            stroke.left = bitmap->left;
            stroke.top = bitmap->top;
            stroke.alpha.resize(std::size_t(stroke.w) * stroke.h);
            for (int y = 0; y < stroke.h; ++y) {
                auto row = bm.buffer + (bm.pitch >= 0 ? y : stroke.h - 1 - y) * std::abs(bm.pitch);
                for (int x = 0; x < stroke.w; ++x)
                    stroke.alpha[std::size_t(y) * stroke.w + x] =
                        bm.pixel_mode == FT_PIXEL_MODE_MONO ? (((row[x / 8] >> (7 - x % 8)) & 1) * 255)
                                                            : row[x];
            }
            FT_Done_Glyph(glyph);
        }
        int left = outlined ? std::min(g.left, stroke.left) : g.left,
            top = outlined ? std::max(g.top, stroke.top) : g.top;
        int right = outlined ? std::max(g.left + g.w, stroke.left + stroke.w) : g.left + g.w + 1,
            bottom = outlined ? std::max(g.h - g.top, stroke.h - stroke.top) : g.h - g.top + 1;
        auto image = std::make_shared<Canvas>(std::max(1, right - left), std::max(1, top + bottom));
        auto paint = [&](const Glyph& src, int dx, int dy, Color ink) {
            for (int y = 0; y < src.h; ++y)
                for (int x = 0; x < src.w; ++x)
                    image->Blend(src.left - left + x + dx, top - src.top + y + dy, ink,
                                 src.alpha[std::size_t(y) * src.w + x] / 255.f);
        };
        if (outlined)
            paint(stroke, 0, 0, {0, 0, 0, 175.f / 255});
        else
            paint(g, 1, 1, {0, 0, 0, 200.f / 255});
        paint(g, 0, 0, {1, 1, 1, 1});
        return cache.emplace(key, ESPGlyph{left, top, std::move(image)}).first->second;
    }
    void NativeESPText(Canvas& c, int id, float px, const std::u32string& str, float x, float y, Color ink,
                       const Box* clip = nullptr) {

        float asc = float(GetESP(id, px, U'A').top), f = PixelHeight(id, px), origin = std::trunc(x),
              pen = origin;
        y = std::trunc(y);
        FT_UInt previous = 0;
        FT_Pos rsb = 0;
        ink = {Canvas::Byte(ink.r) / 255.f, Canvas::Byte(ink.g) / 255.f, Canvas::Byte(ink.b) / 255.f,
               Canvas::Byte(ink.a) / 255.f};
        for (auto cp : str) {
            if (!cp)
                break;
            if (cp == U'\r' || cp == 0xfe0f)
                continue;
            if (cp == U'\n') {
                pen = origin;
                y += f;
                previous = 0;
                rsb = 0;
                continue;
            }
            const auto& metrics = Get(id, px, cp);
            pen += ESPPairAdjustment(id, px, previous, rsb, metrics);
            const auto& g = GetESP(id, px, cp);
            const auto& image = *g.image;
            int gx = int(pen + g.left), gy = int(y + asc - g.top);
            for (int yy = 0; yy < image.height; ++yy)
                for (int xx = 0; xx < image.width; ++xx) {
                    if (clip && !clip->Contains(gx + xx + .5f, gy + yy + .5f))
                        continue;
                    const auto* p = image.rgba.data() + 4 * (std::size_t(yy) * image.width + xx);
                    float a = p[3] / 255.f;
                    if (a > 0)
                        c.Blend(gx + xx, gy + yy,
                                {ink.r * p[0] / 255.f / a, ink.g * p[1] / 255.f / a, ink.b * p[2] / 255.f / a,
                                 ink.a * a});
                }
            pen += std::ceil(metrics.advance);
            previous = metrics.index;
            rsb = metrics.rsbDelta;
        }
    }

    void NativeMergedIcon(Canvas& c, float px, char32_t cp, float globalX, float globalY, Color color,
                          float canvasX = 0, float canvasY = 0, const Box* clip = nullptr,
                          int destinationFace = 0) {
        float dst = std::trunc(Size(destinationFace, px)->size->metrics.ascender / 64.f + .5f),
              src = std::trunc(Size(3, px)->size->metrics.ascender / 64.f + .5f);
        NativeText(c, 3, px, std::u32string(1, cp), globalX, globalY + dst - src, color, canvasX, canvasY,
                   clip);
    }
    void Text(Canvas& c, int id, float px, const std::u32string& str, Box box, Color color, bool icon = false,
              const Box* clip = nullptr) {
        auto f = Size(id, px);
        float asc = f->size->metrics.ascender / 64.f, desc = f->size->metrics.descender / 64.f;
        float baseline = box.y + (box.h - (asc - desc)) * .5f + asc, pen = box.x;
        for (auto cp : str) {
            const auto& g = Get(id, px, cp);
            int gx = int(std::round(pen)) + g.left;
            int gy = icon ? int(std::round(box.y + (box.h - g.h) * .5f)) : int(std::round(baseline)) - g.top;
            for (int yy = 0; yy < g.h; ++yy)
                for (int xx = 0; xx < g.w; ++xx) {
                    int x = gx + xx, y = gy + yy;

                    if (x + .5f >= box.x && x + .5f < box.x + box.w &&
                        (!clip || clip->Contains(x + .5f, y + .5f)))
                        c.Blend(x, y, color, g.alpha[std::size_t(yy) * g.w + xx] / 255.f);
                }
            pen += g.advance;
            if (pen > box.x + box.w)
                break;
        }
    }
};
inline std::u32string ASCII(const std::string& s) {
    return {s.begin(), s.end()};
}
struct Tab {
    const char* key;
    const char* hash;
    char32_t glyph;
    const char* previewCaption;
};
inline constexpr std::array<Tab, 5> Tabs{{{"tab_ragebot", "56B2897F", 0xf05b, "Rage"},
                                          {"tab_legitbot", "D7B3B875", 0xf8cc, "Legit"},
                                          {"tab_visuals", "9E26A902", 0xf03e, "Visuals"},
                                          {"tab_inventory", "37F828C9", 0xf5fd, "Inventory"},
                                          {"tab_miscellaneous", "7CFEA9CF", 0xf3f0, "Miscellaneous"}}};

struct ProfileImageLevel {
    int width = 0, height = 0;
    std::vector<unsigned char> rgba;
};
struct ProfileImage : ProfileImageLevel {
    std::vector<ProfileImageLevel> mips;
};
#include "profile_image_sampling.h"
inline std::u32string SubscriptionText(std::int64_t end, std::int64_t now, const std::u32string& lifetime) {
    if (!end)
        return {};
    const auto remaining = end - now;
    if (remaining >= 157680001)
        return lifetime;
    if (remaining >= 86401)
        return ASCII(std::to_string(remaining / 86400) + " days left");
    return U"1 day left";
}
#include "world_view_model.h"
#include "world_hud_model.h"
#include "world_misc_model.h"
#include "world_ambience_model.h"
#include "players_model.h"
#include "world_esp_model.h"
#include "rage_model.h"
#include "inventory_model.h"

struct MenuKeybind {
    std::string id, target;
    int key = 0, mode = 0;
    bool shown = true;
    std::array<float, 4> value{{0, 0, 0, 0}};
};
// Original frame updater: RVA 0x9ccc63..0x9ccee1. Snapshot all 46
// current colors, then interpolate to the selected palette over .2s (cubic out).
// A reversed switch snapshots the visible intermediate colors, not an endpoint.
struct ThemePaletteTransition {
    static constexpr float Duration = .2f;
    std::array<Color, 46> value{}, from{};
    int theme = -1;
    float elapsed = Duration;
    bool Tick(int next, float dt) {
        next = std::clamp(next, 0, 1);
        if (theme < 0) {
            theme = next;
            std::copy(std::begin(BasePalettes[next]), std::end(BasePalettes[next]), value.begin());
            from = value;
            return false;
        }
        if (next != theme) {
            from = value;
            theme = next;
            elapsed = 0;
            return true;
        }
        dt = std::isfinite(dt) ? std::max(0.f, dt) : 0.f;
        if (elapsed >= Duration || dt == 0)
            return false;
        elapsed = std::min(Duration, elapsed + dt);
        const float u = 1.f - elapsed / Duration, ease = 1.f - u * u * u;
        for (std::size_t i = 0; i < value.size(); ++i)
            value[i] = elapsed >= Duration ? BasePalettes[theme][i] : Mix(from[i], BasePalettes[theme][i], ease);
        return true;
    }
};

struct Settings {
    bool movementBunnyHop = false;

    bool movementJumpBug = false;
    std::array<bool, 4> movementJumpBugModes{{false, false, false, false}};

    bool devHistorySkeleton = false;

    bool hitSoundEnabled = true;
    std::array<int, 5> hitSoundForType{{0, 0, 0, 0, 0}};
    std::array<int, 5> hitSoundVolume{{100, 100, 100, 100, 100}};

    bool movementAirStrafe = false;
    std::array<bool, 6> movementAirModes{{false, true, false, false, false, false}};
    std::array<int, 4> movementAirValues{{100, 65, 50, 45}};
    std::vector<MenuKeybind> keybinds;
    RageValues rage;
    InventoryValues inventory;
    WorldESPValues worldESP;
    WorldViewValues worldView;
    WorldHudValues worldHud;
    WorldMiscValues worldMisc;
    WorldAmbienceValues worldAmbience;
    PlayersValues players;
    std::array<int, 23> watermarkOrder{
        {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22}};
    float scale = 1.f, textPx = 13.f, sigma = 5.f;
    int face = 1, theme = 0;
    ThemePaletteTransition themePalette; // presentation only; deliberately not persisted
    bool keyLabels = false, diagnostics = false, blur = true, useGpu = true, demoBackground = true;

    int espScale = 0;
    int windowsScale = 0;
    float hostDpi = 96.f;
    std::u32string userName = U"Cheusol", userDetail = U"Lifetime", lifetimeText = U"Lifetime";
    std::u32string aboutBranch = U"—";
    std::int64_t subscriptionEnd = 0;

    bool customAccent = false;
    Color accent = BasePalettes[0][31];
    std::shared_ptr<ProfileImage> avatar, backgroundImage, aboutLogo;
    std::array<std::u32string, 5> captions{};
    Settings() {
        for (std::size_t i = 0; i < Tabs.size(); ++i)
            captions[i] = ASCII(Tabs[i].previewCaption);
    }
};
inline float ScreenWindowScale(const Settings& cfg) {
    if (cfg.windowsScale > 0)
        return 1.f + .25f * float(std::clamp(cfg.windowsScale, 1, 5) - 1);
    return std::clamp(std::isfinite(cfg.hostDpi) ? cfg.hostDpi / 96.f : 1.f, .75f, 10.f);
}
inline std::array<Color, 46> CurrentPalette(const Settings& cfg) {
    std::array<Color, 46> p{};
    if (cfg.themePalette.theme >= 0)
        p = cfg.themePalette.value;
    else
        std::copy(std::begin(BasePalettes[std::clamp(cfg.theme, 0, 1)]),
                  std::end(BasePalettes[std::clamp(cfg.theme, 0, 1)]), p.begin());
    if (cfg.customAccent) {
        auto a = cfg.accent;
        a.a = 1;
        for (int i : {23, 25, 31, 39})
            p[i] = a;
    }

    p[21] = {1, 1, 1, 1};
    p[26] = {1, 1, 1, 1};
    p[27] = {.8f, .8f, .8f, 1};
    return p;
}
struct Layout {
    Box outer, sidebar, content, extensionsRow;
    bool visualsOpen = false;
    float visualsHeight = 0, visualsAlpha = 0;
    std::array<Box, 2> visualRows;
    std::array<Box, 5> rows;
    std::array<Box, 3> headings;
    float navHeight = 0, headerHeight = 0, footerHeight = 0;
};
inline Layout ComputeLayout(int width, int height, const Settings& cfg, float panX = 0, float panY = 0,
                            bool visualsOpen = false, float expansion = -1, float alpha = 1) {
    const float s = cfg.scale;
    Layout l;
    expansion = std::clamp(expansion < 0 ? (visualsOpen ? 1.f : 0.f) : expansion, 0.f, 1.f);
    l.visualsHeight = expansion;
    l.visualsOpen = expansion > 0;
    l.visualsAlpha = l.visualsOpen ? std::clamp(alpha, 0.f, 1.f) : 0;
    const float pad = 10 * s;
    l.headerHeight = dump_menu::header_height(s, pad);
    l.footerHeight = dump_menu::footer_height(s, 35, pad);

    float measured = 2 * pad + 3 * 10 * s + (6 + 2 * expansion) * (32 * s + 5 * s) + 2 * (15 * s + 5 * s);
    l.navHeight = std::max(measured, 501 * s);
    const float components[] = {l.headerHeight, l.navHeight, l.footerHeight};
    float w = dump_menu::default_outer_width(s),
          h = dump_menu::measured_outer_height(components, 3, 1 * s, 0);
    float x = std::max(24.f, (width - w) * .5f) - panX, y = std::max(64.f, (height - 48 - h) * .5f) - panY;
    l.outer = {x, y, w, h};
    l.sidebar = {x, y, 170 * s, h};
    l.content = {x + 170 * s, y, w - 170 * s, h};
    float rowY = y + l.headerHeight + 1 * s + pad;
    l.headings[0] = {x + 20 * s, rowY, 140 * s, 10 * s};
    rowY += 10 * s + 5 * s;
    for (int i = 0; i < 5; ++i) {
        if (i == 2) {
            rowY += 15 * s;
            l.headings[1] = {x + 20 * s, rowY, 140 * s, 10 * s};
            rowY += 10 * s + 5 * s;
        }
        l.rows[i] = {x + 20 * s, rowY, 140 * s, 32 * s};
        rowY += 37 * s;
        if (i == 2 && l.visualsOpen) {
            float childY = rowY;
            for (auto& child : l.visualRows) {
                child = {x + 35 * s, childY, 125 * s, 32 * s};
                childY += 37 * s;
            }
            rowY += 74 * s * expansion;
        }
    }

    rowY += 15 * s;
    l.headings[2] = {x + 20 * s, rowY, 140 * s, 10 * s};
    rowY += 15 * s;
    l.extensionsRow = {x + 20 * s, rowY, 140 * s, 32 * s};
    return l;
}

struct DumpTween {
    float value = 0, from = 0, target = 0, elapsed = .2f;
    void Tick(float next, float dt) {
        if (next != target) {
            from = value;
            target = next;
            elapsed = 0;
            return;
        }
        elapsed = std::min(.2f, elapsed + std::max(0.f, dt));
        float t = elapsed / .2f;
        value = from + (target - from) * (1 - (1 - t) * (1 - t) * (1 - t));
    }
};
struct State {
    DumpContentTransition contentTransition;
    DumpTween visualHeight, visualAlpha;
    bool profileOpen = false;
    bool profileHover = false;
    float profileAnim = 0, profileFrom = 0, profileTarget = 0, profileElapsed = 0;
    int selected = 0, selectedVisual = 0, hover = -1, held = -1;
    std::array<float, 8> from{}, anim{}, target{}, elapsed{};
    void Select(int i) {
        if (i == 7)
            return;
        if (i >= 5 && i <= 6) {
            selected = 2;
            selectedVisual = i - 5;
        } else
            selected = std::clamp(i, 0, 4);
    }
    bool IsSelected(int i) const {
        return i == 7  ? false
               : i < 5 ? (selected == i && i != 2)
                       : (selected == 2 && selectedVisual == i - 5);
    }
    void Tick(float dt) {
        contentTransition.Tick(selected, selectedVisual, dt);
        if (selected == 2) {
            visualHeight.Tick(1, dt);
            visualAlpha.Tick(visualHeight.value >= .75f ? 1.f : 0.f, dt);
        } else {
            visualAlpha.Tick(0, dt);
            visualHeight.Tick(visualAlpha.value > .3f ? 1.f : 0.f, dt);
        }
        float v = profileOpen ? 1.f : (profileHover ? .5f : 0.f);
        if (v != profileTarget) {
            profileTarget = v;
            profileFrom = profileAnim;
            profileElapsed = 0;
        }
        profileElapsed = std::min(.2f, profileElapsed + std::max(0.f, dt));
        float t = profileElapsed / .2f;
        profileAnim = profileFrom + (profileTarget - profileFrom) * (1 - (1 - t) * (1 - t) * (1 - t));
        for (int i = 0; i < 8; ++i) {
            float v = dump_menu::nav_state_target(IsSelected(i), hover == i, held == i);
            if (v != target[i]) {
                target[i] = v;
                from[i] = anim[i];
                elapsed[i] = 0;
            }
            elapsed[i] = std::min(.2f, elapsed[i] + std::max(0.f, dt));
            float t = elapsed[i] / .2f;
            anim[i] = from[i] + (target[i] - from[i]) * (1 - (1 - t) * (1 - t) * (1 - t));
        }
    }
};
inline Layout AnimatedLayout(int width, int height, const Settings& cfg, const State& state, float panX = 0,
                             float panY = 0) {
    return ComputeLayout(width, height, cfg, panX, panY, state.selected == 2, state.visualHeight.value,
                         state.visualAlpha.value);
}
inline Layout TranslateLayout(Layout l, float dx, float dy) {
    auto move = [&](Box& b) {
        b.x += dx;
        b.y += dy;
    };
    move(l.outer);
    move(l.sidebar);
    move(l.content);
    move(l.extensionsRow);
    for (auto& b : l.rows)
        move(b);
    for (auto& b : l.visualRows)
        move(b);
    for (auto& b : l.headings)
        move(b);
    return l;
}

struct MenuDrag {
    bool active = false;
    float offsetX = 0, offsetY = 0, lastX = 0, lastY = 0;
    bool Begin(const Layout& l, float x, float y, bool itemClaimed = false);
    void Stop() {
        active = false;
    }
    void Constrain(const Layout& l, int width, int height) {
        float nx = std::clamp(l.outer.x, std::min(0.f, width - l.outer.w), std::max(0.f, width - l.outer.w));
        float ny = std::clamp(l.outer.y, 0.f,
                              std::max(0.f, height - (l.outer.h <= height ? l.outer.h : l.headerHeight)));
        offsetX += nx - l.outer.x;
        offsetY += ny - l.outer.y;
    }
    bool Update(const Layout& l, float x, float y, bool down, bool focused, int width, int height) {
        if (!down || !focused) {
            Stop();
            return false;
        }
        if (!active)
            return false;
        float nx = l.outer.x + x - lastX, ny = l.outer.y + y - lastY;
        lastX = x;
        lastY = y;
        nx = std::clamp(nx, std::min(0.f, width - l.outer.w), std::max(0.f, width - l.outer.w));
        ny = std::clamp(ny, 0.f, std::max(0.f, height - (l.outer.h <= height ? l.outer.h : l.headerHeight)));
        offsetX += nx - l.outer.x;
        offsetY += ny - l.outer.y;
        return nx != l.outer.x || ny != l.outer.y;
    }
};
inline Box ProfileBox(const Layout& l, float s) {
    return {l.sidebar.x, l.outer.y + l.headerHeight + s + l.navHeight + s, l.sidebar.w, l.footerHeight};
}
inline Box ProfileHighlight(const Layout& l, float s) {
    auto b = ProfileBox(l, s);
    return {b.x + 10 * s, b.y + 5 * s, b.w - 20 * s, b.h - 10 * s};
}
inline Box ProfileAvatarBox(const Layout& l, float s) {
    auto b = ProfileBox(l, s);
    return {b.x + 15 * s, b.y + 10 * s, 35 * s, 35 * s};
}
inline void DrawImage(Canvas& c, const ProfileImage& image, Box b, bool circular = false, float opacity = 1) {
    if (image.width <= 0 || image.height <= 0 ||
        image.rgba.size() != std::size_t(image.width) * image.height * 4)
        return;
    for (int y = std::max(0, int(std::floor(b.y))); y < std::min(c.height, int(std::ceil(b.y + b.h))); ++y)
        for (int x = std::max(0, int(std::floor(b.x))); x < std::min(c.width, int(std::ceil(b.x + b.w)));
             ++x) {
            float coverage =
                circular ? std::clamp(.5f + b.h * .5f -
                                          std::hypot(x + .5f - b.x - b.w * .5f, y + .5f - b.y - b.h * .5f),
                                      0.f, 1.f)
                         : 1.f;
            float u = (x + .5f - b.x) / b.w * image.width - .5f,
                  v = (y + .5f - b.y) / b.h * image.height - .5f;
            int ix = int(std::floor(u)), iy = int(std::floor(v));
            float fx = u - ix, fy = v - iy, col[4]{};
            for (int yy = 0; yy < 2; ++yy)
                for (int xx = 0; xx < 2; ++xx) {
                    auto* pixel = image.rgba.data() +
                                  4 * (std::size_t(std::clamp(iy + yy, 0, image.height - 1)) * image.width +
                                       std::clamp(ix + xx, 0, image.width - 1));
                    float weight = (xx ? fx : 1 - fx) * (yy ? fy : 1 - fy), a = pixel[3] / 255.f;
                    for (int k = 0; k < 3; ++k)
                        col[k] += pixel[k] / 255.f * a * weight;
                    col[3] += a * weight;
                }
            if (col[3] > 0)
                c.Blend(x, y, {col[0] / col[3], col[1] / col[3], col[2] / col[3], col[3]},
                        coverage * opacity);
        }
}
inline void DrawAvatar(Canvas& c, const ProfileImage& image, Box b) {
    DrawImage(c, image, b, true);
}
inline int Hit(const Layout& l, float x, float y) {
    if (l.extensionsRow.Contains(x, y))
        return 7;
    for (int i = 0; i < 5; ++i)
        if (l.rows[i].Contains(x, y))
            return i;
    if (l.visualsOpen && l.visualsAlpha > .3f)
        for (int i = 0; i < 2; ++i)
            if (l.visualRows[i].Contains(x, y))
                return i + 5;
    return -1;
}
inline bool MenuDrag::Begin(const Layout& l, float x, float y, bool itemClaimed) {

    const Box profile{l.sidebar.x, l.outer.y + l.outer.h - l.footerHeight, l.sidebar.w, l.footerHeight};
    active = !itemClaimed && l.outer.Contains(x, y) && Hit(l, x, y) < 0 && !profile.Contains(x, y);
    lastX = x;
    lastY = y;
    return active;
}
inline void RenderBackground(Canvas& c, const Settings& cfg) {
    c.Clear(Color{.065f, .075f, .095f, 1});
    if (cfg.demoBackground && !cfg.backgroundImage) {

        for (int y = 0; y < c.height; ++y)
            for (int x = 0; x < c.width; ++x) {
                const bool cell = ((x / 44 + y / 44) & 1) != 0;
                const float u = (x + .5f) / c.width - .5f, v = (y + .5f) / c.height - .4f;
                const float glow = std::exp(-(u * u + v * v) * 10.f);
                const Color col = cell ? Color{.16f, .23f, .30f, 1} : Color{.075f, .11f, .16f, 1};
                auto* pixel = c.rgba.data() + 4 * (std::size_t(y) * c.width + x);
                pixel[0] = Canvas::Byte(col.r + glow * .05f);
                pixel[1] = Canvas::Byte(col.g + glow * .15f);
                pixel[2] = Canvas::Byte(col.b + glow * .21f);
                pixel[3] = 255;
            }
    }
    if (cfg.demoBackground && cfg.backgroundImage && cfg.backgroundImage->width > 0 &&
        cfg.backgroundImage->height > 0) {
        const auto& image = *cfg.backgroundImage;
        float zoom = std::max(float(c.width) / image.width, float(c.height) / image.height);
        float w = image.width * zoom, h = image.height * zoom;
        DrawImage(c, image, {(c.width - w) * .5f, (c.height - h) * .5f, w, h});
    }
}
inline float BoxDistance(Box b, float r, float x, float y, float smoothing = 0) {
    r /= std::max(1 - .6f * smoothing, .01f);
    float n = 2 + 3.6f * smoothing;
    float qx = std::abs(x - b.x - b.w * .5f) - b.w * .5f + r,
          qy = std::abs(y - b.y - b.h * .5f) - b.h * .5f + r;
    float dx = std::max(qx, 0.f), dy = std::max(qy, 0.f);
    return (smoothing > 0 ? std::pow(std::pow(dx, n) + std::pow(dy, n), 1 / n) : std::hypot(dx, dy)) +
           std::min(std::max(qx, qy), 0.f) - r;
}
inline float Smooth(float t) {
    t = std::clamp(t, 0.f, 1.f);
    return t * t * (3 - 2 * t);
}

inline void DrawMenuShadow(Canvas& c, Box b, float r, float size, Color color, float smoothing = 1) {
    float pad = size * .5f;
    for (int y = std::max(0, int(std::floor(b.y - pad - 1)));
         y < std::min(c.height, int(std::ceil(b.y + b.h + pad + 1))); ++y)
        for (int x = std::max(0, int(std::floor(b.x - pad - 1)));
             x < std::min(c.width, int(std::ceil(b.x + b.w + pad + 1))); ++x) {
            float d = BoxDistance(b, r, x + .5f, y + .5f, smoothing);
            float fw = std::abs(BoxDistance(b, r, x + 1.5f, y + .5f, smoothing) - d) +
                       std::abs(BoxDistance(b, r, x + .5f, y + 1.5f, smoothing) - d);
            float exterior = Smooth((d + fw) / std::max(2 * fw, .001f));
            float fade = 1 - Smooth((d + size * .5f) / size);
            c.Blend(x, y, color, exterior * fade);
        }
}

inline void DrawMenuCircleShadow(Canvas& c, float cx, float cy, float radius, float ox, float oy, float blur,
                                 Color color) {
    float pad = (2 * std::max(std::abs(ox), std::abs(oy)) + blur) * .5f;
    for (int y = std::max(0, int(std::floor(cy - radius - pad)));
         y < std::min(c.height, int(std::ceil(cy + radius + pad))); ++y)
        for (int x = std::max(0, int(std::floor(cx - radius - pad)));
             x < std::min(c.width, int(std::ceil(cx + radius + pad))); ++x) {
            float px = x + .5f - cx, py = y + .5f - cy, d = std::hypot(px, py) - radius;
            float fw =
                std::abs(std::hypot(px + 1, py) - radius - d) + std::abs(std::hypot(px, py + 1) - radius - d);
            float exterior = d > 0 ? Smooth(d / std::max(fw, .001f)) : 0;
            float shifted = std::hypot(px - ox, py - oy) - radius;
            float fade = 1 - Smooth((shifted + blur * .5f) / std::max(blur, .001f));
            c.Blend(x, y, color, exterior * fade);
        }
}
inline void BlurMenuBackdrop(Canvas& c, Box b, float radius, float sigma, float opacity = 1,
                             float skipTop = 0, float smoothing = 1) {
    auto k = wm::MakeKernel(sigma, c.width, c.height, false);
    auto original = c.rgba;
    std::vector<unsigned char> horizontal(c.rgba.size());
    int x0 = std::max(0, int(std::floor(b.x - 1))), x1 = std::min(c.width, int(std::ceil(b.x + b.w + 1)));
    int y0 = std::max(0, int(std::floor(b.y - 1))), y1 = std::min(c.height, int(std::ceil(b.y + b.h + 1)));
    for (int y = std::max(0, y0 - 8); y < std::min(c.height, y1 + 8); ++y)
        for (int x = x0; x < x1; ++x)
            for (int ch = 0; ch < 4; ++ch) {
                float v = original[4 * (std::size_t(y) * c.width + x) + ch] * k.weights[0][0];
                for (int i = 1; i <= 8; ++i)
                    v += (original[4 * (std::size_t(y) * c.width + std::clamp(x - i, 0, c.width - 1)) + ch] +
                          original[4 * (std::size_t(y) * c.width + std::clamp(x + i, 0, c.width - 1)) + ch]) *
                         k.weights[i][0];
                horizontal[4 * (std::size_t(y) * c.width + x) + ch] =
                    static_cast<unsigned char>(std::clamp(v + .5f, 0.f, 255.f));
            }
    for (int y = y0; y < y1; ++y)
        for (int x = x0; x < x1; ++x) {
            float coverage =
                y + .5f < b.y + skipTop
                    ? 0
                    : std::clamp(.5f - BoxDistance(b, radius, x + .5f, y + .5f, smoothing), 0.f, 1.f);
            for (int ch = 0; ch < 4; ++ch) {
                float v = horizontal[4 * (std::size_t(y) * c.width + x) + ch] * k.weights[0][0];
                for (int i = 1; i <= 8; ++i)
                    v += (horizontal[4 * (std::size_t(std::clamp(y - i, 0, c.height - 1)) * c.width + x) +
                                     ch] +
                          horizontal[4 * (std::size_t(std::clamp(y + i, 0, c.height - 1)) * c.width + x) +
                                     ch]) *
                         k.weights[i][0];
                auto idx = 4 * (std::size_t(y) * c.width + x) + ch;
                c.rgba[idx] = static_cast<unsigned char>(
                    std::clamp(original[idx] + coverage * opacity * (v - original[idx]) + .5f, 0.f, 255.f));
            }
        }
}

inline void DrawMenuSeparator(Canvas& c, Box b, Color color, const Box* clip = nullptr) {
    for (int y = std::max(0, int(std::floor(b.y))); y < std::min(c.height, int(std::ceil(b.y + b.h))); ++y) {
        float cy = std::max(0.f, std::min(float(y + 1), b.y + b.h) - std::max(float(y), b.y));
        for (int x = std::max(0, int(std::floor(b.x))); x < std::min(c.width, int(std::ceil(b.x + b.w)));
             ++x) {
            if (clip && !clip->Contains(x + .5f, y + .5f))
                continue;
            float cx = std::max(0.f, std::min(float(x + 1), b.x + b.w) - std::max(float(x), b.x));
            c.Blend(x, y, color, cx * cy);
        }
    }
}
inline std::array<Box, 2> MenuSidebarSeparators(const Layout& l, float s) {
    return {{{l.sidebar.x + 10 * s, l.outer.y + l.headerHeight, l.sidebar.w - 20 * s, s},
             {l.sidebar.x + 10 * s, l.outer.y + l.headerHeight + s + l.navHeight, l.sidebar.w - 20 * s, s}}};
}
inline void Render(Canvas& c, Fonts& fonts, const Settings& cfg, const State& state, const Layout& l,
                   bool uiOnly = false) {
    const float s = cfg.scale, px = cfg.textPx * s;
    if (uiOnly)
        c.Clear({0, 0, 0, 0});
    else
        RenderBackground(c, cfg);

    const auto palette = CurrentPalette(cfg);
    Color text = palette[0], selected = palette[2], muted = palette[3], contentFill = palette[9];
    contentFill.a *= .7f;
    if (!uiOnly) {
        if (cfg.blur)
            BlurMenuBackdrop(c, l.outer, 16 * s, wm::MainMenuBlurSigma(s));
        c.RoundRect(l.outer, 16 * s, palette[6], {0, 0, 0, 0}, 0, 1);
        DrawMenuShadow(c, l.outer, 16 * s, 18 * s, palette[38]);
    }
    if (!uiOnly)
        c.RoundRect(l.content, 16 * s, contentFill, palette[11], 1 * s, 1);

    for (auto line : MenuSidebarSeparators(l, s))
        DrawMenuSeparator(c, line, palette[34]);
    const char* groupLabels[] = {cfg.keyLabels ? "803C4C15" : "AIMBOT", cfg.keyLabels ? "85535F22" : "COMMON",
                                 cfg.keyLabels ? "DB164D2B" : "EXTENSIONS"};
    for (int g = 0; g < 3; ++g)
        fonts.Text(c, 0, 10 * s, ASCII(groupLabels[g]), l.headings[g], muted);
    auto drawNav = [&](const Box& b, int id, char32_t glyph, const std::u32string& caption) {
        auto h = dump_menu::nav_highlight(b.x, b.y, l.sidebar.x, l.sidebar.w, b.h, s);
        float a = state.anim[id], alpha = (id == 5 || id == 6) ? l.visualsAlpha : 1.f;
        Color hi = palette[33];
        hi.a = dump_menu::highlight_alpha(hi.a, a, alpha);
        if (!uiOnly)
            c.RoundRect({h.left, h.top, h.right - h.left, h.bottom - h.top}, 8 * s, hi);
        Color idle = text;
        idle.a *= .6f;
        auto captionColor = Mix(idle, palette[2], a), iconColor = Mix(idle, palette[31], a);
        captionColor.a *= alpha;
        iconColor.a *= alpha;

        float iconW = std::trunc(fonts.Width(3, px, std::u32string(1, glyph)) + .95f);
        float iconX = b.x + std::floor((15 * s - iconW) * .5f);
        fonts.Text(c, 3, px, std::u32string(1, glyph), {iconX, b.y, iconW, b.h}, iconColor, true);
        fonts.Text(c, cfg.face, px, caption, {b.x + 25 * s, b.y, b.w - 25 * s, b.h}, captionColor);
    };
    for (int i = 0; i < 5; ++i)
        drawNav(l.rows[i], i, Tabs[i].glyph, cfg.keyLabels ? ASCII(Tabs[i].hash) : cfg.captions[i]);
    if (l.visualsOpen) {
        drawNav(l.visualRows[0], 5, 0xf007, cfg.keyLabels ? U"D0ADA261" : U"Players");
        drawNav(l.visualRows[1], 6, 0xf7a2, cfg.keyLabels ? U"D4F82B89" : U"World");
    }
    drawNav(l.extensionsRow, 7, 0xe443, cfg.keyLabels ? U"DB164D2B" : U"Extensions");

    Box logoBox{l.sidebar.x + 15 * s, l.sidebar.y + 10 * s, 35 * s, 35 * s};
    if (!uiOnly)
        c.RoundRect(logoBox, 8 * s, palette[42]);
    const float logoH = std::trunc(35 * s * .38f), logoW = logoH * 51.f / 30.f;
    const float logoX = std::trunc(logoBox.x + (logoBox.w - logoW) * .5f),
                logoY = std::trunc(logoBox.y + (logoBox.h - logoH) * .5f);

    for (int y = int(logoY); y < int(std::ceil(logoY + logoH)); ++y)
        for (int x = int(logoX); x < int(std::ceil(logoX + logoW)); ++x) {
            float u = (x + .5f - logoX) / logoW * 51 - .5f, v = (y + .5f - logoY) / logoH * 30 - .5f;
            int ix = int(std::floor(u)), iy = int(std::floor(v));
            float fx = u - ix, fy = v - iy, rgba[4]{};
            for (int yy = 0; yy < 2; ++yy)
                for (int xx = 0; xx < 2; ++xx) {
                    int tx = std::clamp(ix + xx, 0, 50), ty = std::clamp(iy + yy, 0, 29);
                    const auto* p = wm::LogoRGBA + 4 * (ty * 51 + tx);
                    float weight = (xx ? fx : 1 - fx) * (yy ? fy : 1 - fy), a = p[3] / 255.f;
                    for (int k = 0; k < 3; ++k)
                        rgba[k] += p[k] / 255.f * a * weight;
                    rgba[3] += a * weight;
                }
            if (rgba[3] > 0)
                c.Blend(x, y, {rgba[0] / rgba[3], rgba[1] / rgba[3], rgba[2] / rgba[3], rgba[3]});
        }
    fonts.Text(c, 2, 14 * s, U"Neverlose", {l.sidebar.x + 60 * s, l.sidebar.y + 13 * s, 105 * s, 17 * s},
               palette[2]);
    fonts.Text(c, 1, 8 * s, U"Counter-Strike 2",
               {l.sidebar.x + 60 * s, l.sidebar.y + 32 * s, 105 * s, 11 * s}, palette[1]);

    const auto profile = ProfileBox(l, s);
    const float footerY = profile.y + 10 * s;
    Color profileHi = palette[33];
    profileHi.a *= .4f * state.profileAnim;
    if (!uiOnly)
        c.RoundRect(ProfileHighlight(l, s), 6 * s, profileHi);
    if (cfg.avatar)
        DrawAvatar(c, *cfg.avatar, ProfileAvatarBox(l, s));
    const float blockY = footerY + std::floor((35 * s - px - 11 * s - 1 * s) * .5f);
    const float arrowWidth = std::trunc(fonts.Width(3, px, U"\uf105") + .95f);
    const float arrowX = profile.x + profile.w - arrowWidth - 15 * s;
    const float textX = profile.x + 60 * s, textW = std::max(0.f, arrowX - textX);
    fonts.Text(c, cfg.face, px, cfg.userName, {textX, blockY, textW, px}, palette[2]);
    auto detail = cfg.subscriptionEnd ? SubscriptionText(cfg.subscriptionEnd,
                                                         std::int64_t(std::time(nullptr)), cfg.lifetimeText)
                                      : cfg.userDetail;
    fonts.Text(c, 0, 11 * s, detail, {textX, blockY + px + 1 * s, textW, 11 * s}, palette[3]);
    fonts.Text(c, 3, px, U"\uf105", {arrowX, profile.y + (profile.h - px) * .5f, arrowWidth, px}, palette[0],
               true);
    if (cfg.diagnostics) {

        float x = l.content.x + 30 * s, y = l.content.y + 28 * s, w = l.content.w - 60 * s;
        const std::array<std::u32string, 8> lines{
            {U"DIAGNOSTICS / NOT ORIGINAL UI", U"Standalone menu shell",
             U"Selected key: " + ASCII(Tabs[state.selected].key),
             U"Width 800*S  |  Sidebar 170*S  |  Row 32*S", U"Navigation minimum: 501*S",
             U"Captions: supplied file; navigation fonts: noto500/13, headings noto400/10.",
             U"Profile: external inputs. Page content is not recovered.",
             U"F1 hides this diagnostic overlay."}};
        for (std::size_t i = 0; i < lines.size(); ++i)
            fonts.Text(c, i == 1 ? 1 : 0, (i == 1 ? 20.f : 12.f) * s, lines[i],
                       {x, y + float(i) * 30 * s, w, 28 * s}, i < 2 ? selected : text);
    }
}
}
