#pragma once

#include <filesystem>
#include <fstream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

namespace menu {
struct PresetStorageChoice {
    std::filesystem::path directory, migratedFrom;
    bool fallback = false;
    std::vector<std::string> warnings;
};

inline std::string PresetStorageToken() {
    std::random_device rng;
    const char* hex = "0123456789abcdef";
    std::string token;
    for (int i = 0; i < 16; ++i) {
        unsigned byte = rng() & 255;
        token += hex[byte >> 4];
        token += hex[byte & 15];
    }
    return token;
}

inline std::string PresetPathLower(const std::filesystem::path& path) {
    auto text = path.u8string();
    for (char& c : text)
        if (c >= 'A' && c <= 'Z')
            c = char(c - 'A' + 'a');
    return text;
}

inline std::filesystem::path PresetGameRoot(const std::filesystem::path& executable) {
    auto dir = executable.parent_path();

    if (PresetPathLower(executable.filename()) == "cs2.exe" && PresetPathLower(dir.filename()) == "win64" &&
        PresetPathLower(dir.parent_path().filename()) == "bin" &&
        PresetPathLower(dir.parent_path().parent_path().filename()) == "game")
        return dir.parent_path().parent_path().parent_path();
    return dir;
}

inline bool PresetStorageWritable(const std::filesystem::path& dir, std::string& error) {
    namespace fs = std::filesystem;
    fs::path probe, renamed;
    try {
        if (dir.empty() || !dir.is_absolute())
            throw std::runtime_error("Storage directory must be absolute");
        fs::create_directories(dir);
        const auto leaf = ".menustudio-probe-" + PresetStorageToken();
        probe = dir / (leaf + ".tmp");
        renamed = dir / (leaf + ".ok");
        {
            std::ofstream out(probe, std::ios::binary | std::ios::trunc);
            if (!out)
                throw std::runtime_error("Cannot create a preset storage probe");
            out << "MenuStudio local preset storage\n";
            out.close();
            if (!out)
                throw std::runtime_error("Cannot finish a preset storage probe");
        }
        fs::rename(probe, renamed);
        if (!fs::remove(renamed))
            throw std::runtime_error("Cannot remove a preset storage probe");
        return true;
    } catch (const std::exception& e) {
        error = e.what();
        std::error_code ignored;
        if (!probe.empty())
            fs::remove(probe, ignored);
        if (!renamed.empty())
            fs::remove(renamed, ignored);
        return false;
    }
}

inline std::filesystem::path PresetCatalogPath(const std::filesystem::path& directory) {
    namespace fs = std::filesystem;
    if (directory.empty())
        return {};
    for (const auto* leaf : {"presets.json", "presets.json.bak"}) {
        auto file = directory / leaf;
        if (fs::exists(file))
            return file;
    }
    return {};
}

inline PresetStorageChoice SelectPresetStorage(const std::filesystem::path& preferred,
                                               const std::filesystem::path& alternate,
                                               const std::filesystem::path& legacy) {
    namespace fs = std::filesystem;
    PresetStorageChoice choice;
    std::string firstError, secondError;
    if (PresetStorageWritable(preferred, firstError))
        choice.directory = preferred;
    else if (preferred != alternate && PresetStorageWritable(alternate, secondError)) {
        choice.directory = alternate;
        choice.fallback = true;
        choice.warnings.push_back("Preferred preset directory unavailable: " + preferred.u8string() + "; " +
                                  firstError);
    } else
        throw std::runtime_error("No writable preset directory. " + preferred.u8string() + ": " + firstError +
                                 "; " + alternate.u8string() + ": " + secondError);

    if (!PresetCatalogPath(choice.directory).empty())
        return choice;
    const auto other = choice.fallback ? preferred : alternate;
    for (const auto& sourceDirectory : {other, legacy}) {
        if (sourceDirectory.empty() || sourceDirectory == choice.directory)
            continue;
        fs::path source;
        try {
            source = PresetCatalogPath(sourceDirectory);
        } catch (const fs::filesystem_error& e) {
            choice.warnings.push_back("Cannot inspect previous preset directory: " + std::string(e.what()));
            continue;
        }
        if (source.empty())
            continue;
        if (!fs::is_regular_file(source) || fs::file_size(source) > 4 * 1024 * 1024)
            throw std::runtime_error("Previous preset catalog is not a regular file or exceeds 4 MiB: " +
                                     source.u8string());

        const auto staging = choice.directory / (".menustudio-migrate-" + PresetStorageToken() + ".tmp");
        try {
            fs::copy_file(source, staging, fs::copy_options::none);
            fs::rename(staging, choice.directory / "presets.json");
        } catch (...) {
            std::error_code ignored;
            fs::remove(staging, ignored);
            throw;
        }
        choice.migratedFrom = source;
        break;
    }
    return choice;
}

inline std::string PresetStorageSummary(const PresetStorageChoice& choice) {
    auto text = "Local presets: " + choice.directory.u8string();
    if (choice.fallback)
        text += " (fallback)";
    if (!choice.migratedFrom.empty())
        text += "; copied from " + choice.migratedFrom.u8string();
    return text;
}
}