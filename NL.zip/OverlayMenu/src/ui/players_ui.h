#pragma once
#include "group_row_geometry.h"
#include "hud_color_picker.h"
#include "world_tooltip.h"
#include "players_esp_settings_ui.h"
#include "players_esp_preview.h"
#include "players_name_avatar.h"
#include "players_remaining_preview.h"
#include <iomanip>
#include <sstream>
namespace menu {

struct PlayersUI {
    enum { Surface, Tab, Toggle, Select, Option, Details, Slider, Swatch, Customize, Universal, ESPItem };
    struct Hit {
        Box box{};
        int kind = 0, index = -1, option = -1;
        Box control{};
        int Key() const {
            return kind * 10000 + (index + 2) * 32 + option + 1;
        }
    };
    PlayersNameAvatar nameAvatar;
    PlayersESPSettingsUI espSettings;
    PlayersMainPreview mainPreview;
    PlayersRemainingPreview remainingPreview;
    PlayersPreviewHover previewHover;
    PresetsUI paint;
    std::size_t searchLayerStart = 0;
    LanguageCatalog* languages = nullptr;
    HudColorPicker picker, parentPicker;
    bool suspendedPicker = false, releaseGuard = false;
    HudColorPicker& InlinePicker() {
        return suspendedPicker ? parentPicker : picker;
    }
    std::vector<Hit> hits;
    std::array<Box, 24> rows{}, controls{};
    std::array<Box, 4> cards{};
    std::array<Box, 2> tabs{};
    std::array<Box, 24> swatches{};
    Box toolbar{}, customize{}, universal{};
    std::array<PresetMotion, 24> checked, available, sliderTip;
    std::map<int, PresetMotion> hover;
    std::array<std::array<PresetMotion, PlayersESPItems.size()>, 2> espFill, espInk;
    struct Transition {
        PresetMotion alpha;
        std::vector<PresetLayer> cached;
    };
    std::map<int, Transition> transitions;
    std::array<PresetMotion, 2> tabExpand, tabFill;
    PresetMotion pageBlend, tooltipFade;
    int animationPage = -1, previousPage = 0;
    float hoverSeconds = 0;
    int lastHover = -1;
    PresetLayer tooltipLast{};
    bool tooltipStored = false;
    bool customizeOpen = false;
    float customizeScroll = 0, customizeMax = 0;
    Box customizeBox{}, previewBox{}, boundingBox{}, customizeTitle{}, customizeViewport{};
    float customizeParentY = 0;
    int page = 0, detail = -1, choice = -1, color = -1, editing = -1, held = -1, focus = -1, drag = -1;
    bool visible = false, blocked = false, selectAll = false;
    float scale = 1, F = 18, mouseX = -1, mouseY = -1, scroll = 0, maxScroll = 0, detailScroll = 0,
          detailMax = 0;
    Box content{}, detailBox{}, choiceAnchor{}, detailAnchor{}, colorAnchor{};
    std::string numeric;
    std::u32string Label(const std::string& key) const {
        if (languages)
            return languages->Label(key);
        auto it = DefaultLanguageStrings().find(key);
        return DecodeUTF8(it == DefaultLanguageStrings().end() ? key : it->second);
    }

    static Box PreviewBoundingBox(Box child, float s, float fontHeight) {
        float mx = 60 * s, my = std::max(mx, fontHeight + 17 * s);
        return {child.x + mx, child.y + my - 25 * s, child.w - 2 * mx, child.h - 2 * my};
    }

    struct PreviewLayout {
        Box body{}, work{}, child{};
        float columnX = 0, toolbarY = 0;
    };
    static PreviewLayout NativePreviewLayout(Box main, float headerHeight, float s, float toolbarHeight) {
        const auto roundSize = [](float v) { return std::trunc(v + std::copysign(.49999997f, v)); };

        main = {std::trunc(main.x), std::trunc(main.y), std::trunc(main.w), roundSize(main.h)};
        const float cfgY = std::trunc(main.y + s), cfgH = roundSize(headerHeight - s);

        const float bodyCursorY = cfgY + cfgH + s;
        PreviewLayout n;
        n.body = {std::trunc(main.x + s), std::trunc(bodyCursorY), std::trunc(std::max(4.f, main.w - 2 * s)),
                  roundSize(main.y + main.h - s - bodyCursorY)};

        const float p = 10 * s, spacing = 5 * s;
        n.work = {std::trunc(n.body.x + p), std::trunc(n.body.y + p), std::max(0.f, n.body.w - 2 * p),
                  std::max(0.f, n.body.h - 2 * p)};

        const float offsetMax = std::max(p + 1, n.work.x + n.work.w - n.body.x);
        n.columnX = std::trunc(n.body.x + p + (offsetMax - p) * .5f + spacing);
        n.toolbarY = n.body.y + p;
        const float childCursorY = n.toolbarY + toolbarHeight + spacing;

        n.child = {std::trunc(n.columnX), std::trunc(childCursorY),
                   std::trunc(std::max(4.f, n.body.x + offsetMax - spacing - n.columnX)),
                   std::trunc(std::max(4.f, n.body.y + n.body.h - p - childCursorY))};
        return n;
    }
    static Color PreviewPackedColor(Color c) {
        return {Canvas::Byte(c.r) / 255.f, Canvas::Byte(c.g) / 255.f, Canvas::Byte(c.b) / 255.f,
                Canvas::Byte(c.a) / 255.f};
    }

    struct NameFont {
        int face;
        float px;
    };
    static NameFont PreviewNameFont(int option, float s, bool universal) {
        static constexpr int faces[4] = {5, 6, 7, 8};
        static constexpr float sizes[4][5] = {
            {9, 11, 14, 16, 18}, {7, 9, 11, 12, 14}, {11, 14, 17, 19, 22}, {9, 11, 14, 16, 18}};
        int step = universal && s > 1 ? std::clamp(int((s - 1) * 4), 0, 4) : 0;
        option = std::clamp(option, 0, 3);
        return {option == 1 && step > 0 ? 5 : faces[option], sizes[option][step]};
    }
    static std::u32string PreviewNameCase(std::u32string label, int mode) {
        for (auto& cp : label) {
            if (cp == U'\t')
                cp = U' ';
            if (mode == 1 && cp >= U'a' && cp <= U'z')
                cp -= 32;
            else if (mode == 2 && cp >= U'A' && cp <= U'Z')
                cp += 32;
        }
        return label;
    }
    static Box PreviewNameBox(Box child, Box bbox, float w, float h, float s) {

        float cx = std::trunc(child.x + child.w * .5f),
              ay = std::trunc(std::trunc(child.y + child.h * .5f) - 25 * s);
        float mid = bbox.x + bbox.w * .5f - cx;
        float mx = std::trunc(mid + std::copysign(.49999997f, mid));

        return {std::trunc(cx + std::trunc(mx - w * .5f)), std::trunc(ay + std::trunc(bbox.y - ay - h - 3)),
                w, h};
    }
    static std::u32string Upper(std::u32string t) {
        for (auto& c : t)
            if (c >= U'a' && c <= U'z')
                c -= 32;
        return t;
    }
    bool searchChoiceAnchor = false;
    Box searchChoiceBox{};
    bool Active() const {
        return visible && (customizeOpen || detail >= 0 || choice >= 0 || color >= 0);
    }
    bool PickerActive() const {
        return detail >= 0 || color >= 0;
    }
    bool Capturing() const {
        return visible && !blocked &&
               (espSettings.Capturing() || previewHover.Capturing() || held >= 0 || drag >= 0 ||
                releaseGuard || picker.held >= 0);
    }
    bool Editing() const {
        return visible && !blocked &&
               (espSettings.Editing() || editing >= 0 || (PickerActive() && picker.Editing()));
    }
    bool Enabled(int i, const Settings& c) const {
        if (i < 0 || i >= 24)
            return false;
        int p = PlayersSpecs[std::size_t(i)].parent;
        return p < 0 || c.players.value[std::size_t(p)] != 0;
    }
    static bool HasDetails(int i) {
        return i == 1 || i == 7 || i == 10 || i == 12 || i == 15;
    }
    void CancelInput() {
        previewHover.Cancel();
        espSettings.Cancel();
        held = drag = -1;
        picker.held = -1;
    }
    void CloseColor() {
        color = -1;
        if (suspendedPicker) {
            picker = parentPicker;
            suspendedPicker = false;
        }
        picker.held = -1;
    }
    void Close(bool animate = true) {
        searchChoiceAnchor = false;
        espSettings.Close();
        if (!animate) {
            espSettings.alpha.Snap(0);
            espSettings.cached.clear();
        }
        customizeOpen = false;
        customizeScroll = 0;
        detail = choice = color = editing = focus = -1;
        suspendedPicker = false;
        numeric.clear();
        CancelInput();
        picker.Reset(4);
        if (!animate)
            transitions.clear();
    }
    void SyncPage() {
        if (animationPage < 0) {
            animationPage = previousPage = page;
            pageBlend.Snap(1);
            for (int i = 0; i < 2; ++i) {
                tabExpand[i].Snap(page == i ? 1.f : 0.f);
                tabFill[i].Snap(page == i ? .5f : 0.f);
            }
        } else if (animationPage != page) {
            previousPage = animationPage;
            animationPage = page;
            pageBlend.Snap(0);
            pageBlend.Tick(1, 0);
        }
    }
    void OpenSwatch(int i, Box b) {
        const auto& d = PlayersSpecs[std::size_t(i)];
        choice = editing = -1;
        if (detail >= 0) {
            parentPicker = picker;
            suspendedPicker = true;
            color = d.color;
            colorAnchor = b;
            picker.Reset(4);
            Start(2000 + color);
        } else if (HasDetails(i)) {
            detail = i;
            detailAnchor = {b.x + b.w + 7 * scale, b.y, 0, 0};
            detailScroll = 0;
            picker.Reset(4);
            Start(detail);
        } else {
            color = d.color;
            colorAnchor = b;
            picker.Reset(4);
            Start(2000 + color);
        }
        CancelInput();
    }
    std::string TipKey() const {
        if (Active())
            return {};
        int n = HitAt(mouseX, mouseY);
        if (n < 0)
            return {};
        const auto& h = hits[std::size_t(n)];
        if (h.kind == Universal)
            return "visuals_preview_items_universalscaling_tooltip";
        if (h.index == 1 && (h.kind == Toggle || h.kind == Swatch))
            return "visuals_enemies_options_offscreenarrow_tooltip";
        return {};
    }
    void Start(int key) {
        auto& t = transitions[key];
        if (!t.alpha.initialized)
            t.alpha.Snap(0);
        t.alpha.Tick(1, 0);
    }
    bool Showing(int key) const {
        return key == 3000   ? customizeOpen
               : key >= 2000 ? color == key - 2000
               : key >= 1000 ? choice == key - 1000
                             : detail == key;
    }
    void Tick(float dt, const Settings& cfg) {
        previewHover.Sync(cfg.players.espLayout);
        if (!visible)
            return;
        dt = std::max(0.f, dt);
        mainPreview.seconds += dt;
        espSettings.Tick(dt, cfg);
        previewHover.Tick(dt, page, visible && !blocked && !Active() && !espSettings.Active(), mouseX, mouseY,
                          cfg.players.espEnabled[std::size_t(page)]);
        SyncPage();
        pageBlend.Tick(1, dt);
        for (auto& t : transitions)
            t.second.alpha.Tick(Showing(t.first) && !blocked ? 1.f : 0.f, dt);
        for (std::size_t i = 0; i < 24; ++i) {
            checked[i].Tick(cfg.players.value[i] != 0 ? 1.f : 0.f, dt);
            available[i].Tick(Enabled(int(i), cfg) ? 1.f : .5f, dt);
            sliderTip[i].Tick(detail >= 0 && choice < 0 && color < 0 && editing < 0 && Enabled(int(i), cfg) &&
                                      (drag == int(i) || controls[i].Contains(mouseX, mouseY))
                                  ? 1.f
                                  : 0.f,
                              dt);
        }
        int n = HitAt(mouseX, mouseY), k = n >= 0 ? hits[std::size_t(n)].Key() : -1;
        if (k != lastHover) {
            lastHover = k;
            hoverSeconds = 0;
        } else
            hoverSeconds += dt;

        for (std::size_t team = 0; team < 2; ++team)
            for (std::size_t i = 0; i < PlayersESPItems.size(); ++i) {
                Hit h{{}, ESPItem, int(i)};
                bool selected = cfg.players.espEnabled[team][i],
                     hot = !blocked && !espSettings.Active() && customizeOpen && int(team) == page &&
                           k == h.Key(),
                     pressed = !blocked && !espSettings.Active() && customizeOpen && int(team) == page &&
                               held == h.Key();
                espFill[team][i].Tick(pressed ? 1.f : selected || hot ? .5f : 0.f, dt);
                espInk[team][i].Tick(selected || pressed ? 1.f : hot ? .5f : 0.f, dt);
            }
        for (const auto& h : hits) {
            hover.try_emplace(h.Key());
        }
        int rowKey = -1, openKey = -1;
        if (n >= 0) {
            const auto& hit = hits[std::size_t(n)];
            if (hit.kind == Swatch && hit.index >= 0) {
                int kind = PlayersSpecs[std::size_t(hit.index)].kind == WorldKind::Check ? Toggle : Select;
                rowKey = Hit{{}, kind, hit.index}.Key();
            }
        }
        int root = detail >= 0                                                   ? detail
                   : choice >= 0 && PlayersSpecs[std::size_t(choice)].parent < 0 ? choice
                                                                                 : -1;
        if (root >= 0)
            openKey =
                Hit{{}, PlayersSpecs[std::size_t(root)].kind == WorldKind::Check ? Toggle : Select, root}
                    .Key();
        auto swatchOpen = [&](int key) {
            for (int i = 0; i < int(PlayersSpecs.size()); ++i) {
                const auto& spec = PlayersSpecs[std::size_t(i)];
                if (spec.color >= 0 && key == Hit{{}, Swatch, i}.Key() &&
                    ((color >= 0 && color == spec.color) || detail == i))
                    return true;
            }
            return false;
        };
        for (auto& m : hover)
            m.second.Tick(!blocked && (m.first == held || m.first == openKey || swatchOpen(m.first)) ? 1.f
                          : !blocked && (m.first == k || m.first == rowKey)                          ? .5f
                                                                                                     : 0.f,
                          dt);
        for (int i = 0; i < 2; ++i) {
            Hit h{{}, Tab, i};
            tabExpand[i].Tick(page == i ? 1.f : 0.f, dt);
            tabFill[i].Tick(!blocked && held == h.Key() ? 1.f
                            : !blocked && k == h.Key()  ? .75f
                            : page == i                 ? .5f
                                                        : 0.f,
                            dt);
        }
        if (PickerActive()) {
            picker.Tick(dt, !blocked && choice < 0);
        }
        if (suspendedPicker) {
            parentPicker.Tick(dt, false);
        }
        tooltipFade.Tick(!TipKey().empty() && hoverSeconds >= .3f ? 1.f : 0.f, dt);
    }
    int HitAt(float x, float y) const {
        if (!visible || blocked)
            return -1;
        for (int n = int(hits.size()) - 1; n >= 0; --n)
            if (hits[std::size_t(n)].box.Contains(x, y))
                return n;
        return -1;
    }
    std::string Number(int i, const Settings& cfg) const {
        std::ostringstream s;
        if (PlayersSpecs[std::size_t(i)].kind == WorldKind::Decimal)
            s << std::fixed << std::setprecision(2);
        s << cfg.players.value[std::size_t(i)];
        return s.str();
    }
    Settings ColorSettings(const Settings& cfg) const {
        Settings v = cfg;
        int i = color >= 0 ? color : detail >= 0 ? PlayersSpecs[std::size_t(detail)].color : -1;
        if (i >= 0)
            v.worldHud.colors[4] = cfg.players.colors[std::size_t(i)];
        return v;
    }
    void SyncColor(Settings& cfg, const Settings& proxy) {
        int i = color >= 0 ? color : detail >= 0 ? PlayersSpecs[std::size_t(detail)].color : -1;
        if (i >= 0)
            cfg.players.colors[std::size_t(i)] = proxy.worldHud.colors[4];
    }
    void Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        if (!visible || blocked)
            return;
        if (espSettings.Active()) {
            espSettings.Move(x, y, cfg);
            return;
        }
        if (previewHover.Capturing()) {
            previewHover.Move(x, y);
            return;
        }
        if (PickerActive() && choice < 0) {
            auto p = ColorSettings(cfg);
            picker.Move(x, y, p);
            SyncColor(cfg, p);
            if (color >= 0)
                return;
        }
        if (drag >= 0) {
            auto b = controls[std::size_t(drag)];
            const auto& d = PlayersSpecs[std::size_t(drag)];
            if (Enabled(drag, cfg))
                cfg.players.Set(std::size_t(drag),
                                d.minimum + (d.maximum - d.minimum) *
                                                std::clamp((x - b.x) / std::max(1.f, b.w - 1), 0.f, 1.f));
        }
    }
    bool Commit(Settings& cfg) {
        if (editing < 0)
            return true;
        try {
            std::size_t used = 0;
            float v = std::stof(numeric, &used);
            if (used != numeric.size() || !std::isfinite(v))
                return false;
            if (Enabled(editing, cfg))
                cfg.players.Set(std::size_t(editing), v);
            editing = -1;
            numeric.clear();
            return true;
        } catch (...) {
            return false;
        }
    }
    void Activate(const Hit& h, Settings& cfg) {
        if (h.kind == Tab) {
            Close(false);
            page = h.index;
            scroll = 0;
            SyncPage();
            return;
        }
        if (h.kind == Universal) {
            cfg.players.universalScaling = !cfg.players.universalScaling;
            return;
        }
        if (h.kind == Customize) {
            bool open = !customizeOpen;
            Close();
            customizeOpen = open;
            if (open)
                Start(3000);
            return;
        }
        if (h.kind == ESPItem) {
            if (h.index >= 0 && h.index < int(PlayersESPItems.size()))
                cfg.players.espEnabled[std::size_t(page)][std::size_t(h.index)] =
                    !cfg.players.espEnabled[std::size_t(page)][std::size_t(h.index)];
            return;
        }
        if (h.kind == Surface)
            return;
        if (!Enabled(h.index, cfg))
            return;
        const auto& d = PlayersSpecs[std::size_t(h.index)];
        if (h.kind == Toggle)
            cfg.players.Set(std::size_t(h.index), cfg.players.value[std::size_t(h.index)] ? 0 : 1);
        else if (h.kind == Select) {
            searchChoiceAnchor = false;
            if (choice == h.index)
                choice = -1;
            else {
                choice = h.index;
                choiceAnchor = h.control;
                Start(1000 + choice);
            }
        } else if (h.kind == Option) {
            if (d.kind == WorldKind::Multi)
                cfg.players.Set(std::size_t(h.index),
                                float(int(cfg.players.value[std::size_t(h.index)]) ^ (1 << h.option)));
            else {
                cfg.players.Set(std::size_t(h.index), float(h.option));
                choice = -1;
            }
        } else if (h.kind == Swatch)
            OpenSwatch(h.index, h.box);
    }
    bool Context(float x, float y) {
        if (!visible || blocked)
            return false;
        if (espSettings.Active())
            return true;
        if (previewHover.Capturing())
            return true;
        int item = previewHover.At(x, y);
        if (item > 0) {
            CancelInput();
            espSettings.Open(item, page, x, y);
            return true;
        }
        int n = HitAt(x, y);
        if (n < 0 || hits[std::size_t(n)].kind != ESPItem)
            return false;
        int i = hits[std::size_t(n)].index;
        CancelInput();
        espSettings.Open(i, page, x, y);
        return true;
    }
    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        if (espSettings.Active() || espSettings.releaseGuard)
            return espSettings.Click(x, y, down, cfg);
        mouseX = x;
        mouseY = y;
        if (!down && releaseGuard) {
            releaseGuard = false;
            CancelInput();
            return true;
        }
        if (PickerActive() && choice < 0) {
            auto p = ColorSettings(cfg);
            bool used = picker.Click(x, y, down, p);
            SyncColor(cfg, p);
            if (used)
                return true;
            if (color >= 0) {
                if (down) {
                    CloseColor();
                    releaseGuard = true;
                    CancelInput();
                }
                return true;
            }
        }
        if (previewHover.Capturing()) {
            if (!down)
                return previewHover.Release(x, y, &cfg.players.espLayout);
            return true;
        }
        if (down && !Active() && !espSettings.Active() && previewHover.Press(x, y))
            return true;
        int n = HitAt(x, y);
        if (down) {
            if (n < 0)
                return false;
            const auto h = hits[std::size_t(n)];
            if (h.kind == Surface) {
                if (editing >= 0)
                    Commit(cfg);
                else if (h.index != -2) {
                    if (choice >= 0)
                        choice = -1;
                    else
                        Close();
                    releaseGuard = true;
                }
                CancelInput();
                return true;
            }
            if (editing >= 0 && !Commit(cfg)) {
                return true;
            }
            held = focus = h.Key();
            if (h.kind == Slider && Enabled(h.index, cfg)) {
                if (ctrl) {
                    editing = h.index;
                    numeric = Number(editing, cfg);
                    selectAll = true;
                } else {
                    drag = h.index;
                    Move(x, y, cfg);
                }
            }
            return true;
        }
        bool used = held >= 0 || drag >= 0;
        if (n >= 0 && held == hits[std::size_t(n)].Key() && drag < 0 && editing < 0)
            Activate(hits[std::size_t(n)], cfg);
        CancelInput();
        return used;
    }
    bool Key(int k, Settings& cfg, bool shift = false, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        if (espSettings.Active())
            return espSettings.KeyInput(k, cfg, shift, ctrl);
        if (PickerActive() && choice < 0) {
            auto p = ColorSettings(cfg);
            if (picker.Key(k, p, ctrl)) {
                SyncColor(cfg, p);
                return true;
            }
            if (color >= 0) {
                if (k == 27)
                    CloseColor();
                return true;
            }
        }
        if (editing >= 0) {
            if (k == 27)
                editing = -1;
            else if (k == 13)
                Commit(cfg);
            else if (ctrl && k == 'A')
                selectAll = true;
            else if (k == 8 || k == 46) {
                if (selectAll)
                    numeric.clear();
                else if (!numeric.empty())
                    numeric.pop_back();
                selectAll = false;
            }
            return true;
        }
        if (k == 27 && previewHover.Capturing()) {
            previewHover.Cancel();
            return true;
        }
        if (k == 27 && Active()) {
            if (choice >= 0)
                choice = -1;
            else
                Close();
            return true;
        }
        if (k == 9) {
            std::vector<int> list;
            for (const auto& h : hits)
                if (h.kind != Surface && h.kind != Tab && (!customizeOpen || h.kind == ESPItem))
                    list.push_back(h.Key());
            if (list.empty())
                return Active();
            auto it = std::find(list.begin(), list.end(), focus);
            int i = it == list.end()
                        ? 0
                        : (int(it - list.begin()) + (shift ? -1 : 1) + int(list.size())) % int(list.size());
            focus = list[std::size_t(i)];
            return true;
        }
        for (const auto& h : hits)
            if (h.Key() == focus) {
                if (h.kind == Slider && (k == 37 || k == 39) && Enabled(h.index, cfg))
                    cfg.players.Set(
                        std::size_t(h.index),
                        cfg.players.value[std::size_t(h.index)] +
                            (k == 37 ? -1 : 1) *
                                (PlayersSpecs[std::size_t(h.index)].kind == WorldKind::Decimal ? .01f : 1.f));
                else if (k == 13 || k == 32) {
                    if (h.kind == Slider) {
                        editing = h.index;
                        numeric = Number(editing, cfg);
                        selectAll = true;
                    } else
                        Activate(h, cfg);
                } else
                    return Active();
                return true;
            }
        return Active();
    }
    bool Character(char16_t c) {
        if (!visible || blocked)
            return false;
        if (espSettings.Active())
            return espSettings.Character(c);
        if (PickerActive() && choice < 0 && picker.Editing())
            return picker.Character(c);
        if (editing < 0)
            return false;
        if ((c >= '0' && c <= '9') || c == '+' || c == '-' || c == '.') {
            if (selectAll) {
                numeric.clear();
                selectAll = false;
            }
            if (numeric.size() < 24)
                numeric += char(c);
        }
        return true;
    }
    bool Wheel(float steps, Settings& cfg) {
        if (!visible || blocked)
            return false;
        if (espSettings.Active())
            return espSettings.Wheel(steps);
        if (customizeOpen) {
            customizeScroll = std::clamp(customizeScroll - steps * 30 * scale, 0.f, customizeMax);
            return true;
        }
        if (color >= 0 || choice >= 0)
            return true;
        if (previewHover.Capturing())
            return true;
        int item = previewHover.At(mouseX, mouseY);
        if (item > 0 && cfg.players.espEnabled[std::size_t(page)][std::size_t(item)]) {
            if (!std::isfinite(steps))
                return true;
            int ticks = int(std::clamp(steps, -100.f, 100.f));
            if (ticks == 0)
                return true;
            if (cfg.players.universalScaling) {
                int base = cfg.espScale;
                if (base == 0 && ticks > 0)
                    base = 1;
                cfg.espScale = std::clamp(base + ticks, 1, 5);
            } else {
                auto& v = cfg.players.espSettings[std::size_t(page)][std::size_t(item)];
                v.sizeStep = std::clamp(v.sizeStep + ticks, 0, 4);
            }
            return true;
        }
        int n = HitAt(mouseX, mouseY);
        if (n >= 0) {
            const auto& h = hits[std::size_t(n)];
            if (h.kind == Slider && Enabled(h.index, cfg)) {
                cfg.players.Set(
                    std::size_t(h.index),
                    cfg.players.value[std::size_t(h.index)] +
                        steps * (PlayersSpecs[std::size_t(h.index)].kind == WorldKind::Decimal ? .01f : 1.f));
                return true;
            }
        }
        if (detail >= 0)
            detailScroll = std::clamp(detailScroll - steps * 30 * scale, 0.f, detailMax);
        else if (content.Contains(mouseX, mouseY))
            scroll = std::clamp(scroll - steps * 30 * scale, 0.f, maxScroll);
        else
            return false;
        return true;
    }
    void Measure(Fonts& fonts, const Settings& cfg, const Layout& layout, Box header, int width, int height,
                 bool shown, bool block) {
        previewHover.Sync(cfg.players.espLayout);
        visible = shown;
        blocked = block;
        paint.layers.clear();
        hits.clear();
        rows.fill({});
        controls.fill({});
        cards.fill({});
        swatches.fill({});
        scale = cfg.scale;
        F = fonts.PixelHeight(0, 13 * scale);
        if (!visible) {
            previewHover.Reset();
            Close(false);
            animationPage = -1;
            releaseGuard = false;
            tooltipFade.Snap(0);
            tooltipStored = false;
            return;
        }
        SyncPage();
        if (blocked) {
            Close(false);
            releaseGuard = false;
        }
        if (editing >= 0 && !Enabled(editing, cfg)) {
            editing = -1;
            CancelInput();
        }
        if (choice >= 0 && !Enabled(choice, cfg))
            choice = -1;
        const float s = scale, H = F + 6 * s, R = F + 14 * s, heading = fonts.PixelHeight(0, 10 * s);
        auto pal = CurrentPalette(cfg);
        bool acceptHits = true;
        picker.languages = parentPicker.languages = languages;
        picker.SetMetrics(fonts, s);
        parentPicker.SetMetrics(fonts, s);
        auto layer = [&](Box b, bool popup = false) {
            paint.layers.push_back({b, popup ? 15 * s : 0, popup, {}});
            paint.layers.back().pixelAligned = true;
            return int(paint.layers.size()) - 1;
        };
        auto rect = [&](int z, Box b, Color c, float radius = 0, float stroke = 0) {
            PresetDraw d{b, c, radius, stroke, 15, {}, false};
            d.clipped = true;
            d.clip = paint.layers[std::size_t(z)].box;
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto text = [&](int z, Box b, const std::u32string& t, Color c, int font = 0, float px = 13) {
            if (font == 3 && !t.empty()) {
                const auto& g = fonts.Get(3, px * s, t[0]);
                b.x = std::trunc(b.x);
                b.y = std::trunc(b.y);
                b.w = std::max(b.w, float(g.left + g.w));
            }
            PresetDraw d{b, c, 0, 0, 15, t, font == 3};
            d.font = font;
            d.textSize = px;
            d.clipped = true;
            d.clip = paint.layers[std::size_t(z)].box;
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto hit = [&](int z, Box b, int kind, int i = -1, int option = -1, Box control = Box{}) {
            if (blocked || !acceptHits)
                return;
            b = PresetIntersect(b, paint.layers[std::size_t(z)].box);
            if (b.w > 0 && b.h > 0)
                hits.push_back({b, kind, i, option, control});
        };
        auto motion = [&](int kind, int i, int option = -1) {
            Hit h{{}, kind, i, option};
            auto it = hover.find(h.Key());
            return it == hover.end() ? 0.f : it->second.value;
        };
        auto surface = [&](Box b, bool popup) {
            int z = layer(b, popup);
            rect(z, b, pal[popup ? 8 : 40], 15 * s);
            rect(z, b, pal[11], 15 * s, s);
            return z;
        };
        auto dim = [](Color c, float a) {
            c.a *= a;
            return c;
        };
        auto tw = [&](const std::u32string& t, int font = 0) {
            return fonts.NativeTextSize(font, 13 * s, t).w;
        };
        auto row = [&](int z, Box b, int i, bool inner, unsigned corners = 15) {
            const auto& d = PlayersSpecs[std::size_t(i)];
            bool enabled = Enabled(i, cfg);
            float a = available[std::size_t(i)].initialized ? available[std::size_t(i)].value
                                                            : (enabled ? 1.f : .5f);
            float v = cfg.players.value[std::size_t(i)], right = b.x + b.w - (inner ? 12 * s : 0),
                  left = b.x + (inner ? 12 * s : 0), labelRight = right;
            int kind = d.kind == WorldKind::Check                                    ? Toggle
                       : (d.kind == WorldKind::Choice || d.kind == WorldKind::Multi) ? Select
                                                                                     : Slider;
            float hv = enabled ? motion(kind, i) : 0;
            if (acceptHits)
                rows[std::size_t(i)] = b;
            if (inner)
                rect(z, b, dim(pal[33], .4f * hv * a), 15 * s / 1.6f);
            else {
                Box band = GroupRowHoverBounds(b, s);
                rect(z, band, dim(pal[33], .15f * hv * a), 15 * s);
                paint.layers[std::size_t(z)].draw.back().corners = corners;
            }
            static constexpr std::array<char32_t, 24> icons{
                {0, 0,      0xf047, 0xe105, 0,      0,      0, 0, 0xe0c9, 0xe29e, 0, 0xe0c9,
                 0, 0xe0c9, 0xf007, 0,      0xe365, 0xf062, 0, 0, 0,      0,      0, 0}};
            if (inner && icons[std::size_t(i)]) {
                auto t = std::u32string(1, icons[std::size_t(i)]);
                float iw = tw(t, 3);
                text(z, {left + (20 * s - iw) * .5f, b.y + 7 * s, 20 * s, F}, t, dim(pal[14], a), 3);
                left += 32 * s;
            }
            Box c{};
            float t =
                checked[std::size_t(i)].initialized ? checked[std::size_t(i)].value : (v != 0 ? 1.f : 0.f);
            if (d.kind == WorldKind::Check) {
                float nominal = F + 2 * s, center = b.y + b.h * .5f, frac = center - std::trunc(center);
                c = {right - 32 * s, center - nominal * .5f + frac, 32 * s, nominal - 2 * frac};
                rect(z, c, dim(pal[22], a), nominal * .5f);
                rect(z, c, dim(pal[23], a * t), nominal * .5f);
                float radius = nominal * .5f - 2 * s, cx = c.x + nominal * .5f + (c.w - nominal) * t;
                rect(z, {cx - radius, center - radius, 2 * radius, 2 * radius},
                     dim(Mix(pal[20], pal[21], t), a), radius);
            } else if (d.kind == WorldKind::Choice || d.kind == WorldKind::Multi) {
                auto opts = PlayersOptions(i);
                auto value = Label(opts[std::size_t(std::clamp(int(v), 0, int(opts.size()) - 1))]);
                if (d.kind == WorldKind::Multi) {
                    value.clear();
                    for (std::size_t j = 0; j < opts.size(); ++j)
                        if (int(v) & (1 << j)) {
                            if (!value.empty())
                                value += U", ";
                            value += Label(opts[j]);
                        }
                    if (value.size() >= 15) {
                        value.clear();
                        for (std::size_t j = 0; j < opts.size(); ++j)
                            if (int(v) & (1 << j)) {
                                auto name = Label(opts[j]);
                                if (!name.empty()) {
                                    if (!value.empty())
                                        value += U", ";
                                    value += name.front();
                                }
                            }
                    }
                    if (value.empty())
                        value = Label("menu_select");
                }
                float aw = tw(inner ? U"\uf105" : U"\uf107", 3),
                      cw = inner ? std::min(b.w - 24 * s, tw(value) + aw + 3 * s)
                                 : std::min(std::trunc(b.w / 2.2f) + 12 * s, b.w * .5f);
                c = {right - cw, b.y + (b.h - H) * .5f, cw, H};
                if (!inner) {
                    rect(z, c, dim(Mix(pal[12], pal[13], hv), a), 6 * s);
                    rect(z, c, dim(pal[11], a), 6 * s, s);
                }
                text(z,
                     {c.x + (inner ? 0 : 6 * s), b.y + (b.h - F) * .5f,
                      std::max(0.f, c.w - aw - (inner ? 3 : 18) * s), F},
                     value, dim(Mix(pal[14], pal[2], hv), a));
                text(z, {right - aw - (inner ? 0 : 6 * s), b.y + (b.h - F) * .5f, aw, F},
                     inner ? U"\uf105" : U"\uf107", dim(pal[14], a), 3);
            } else {
                float sw = std::trunc(b.w / 2.5f);
                c = {right - sw, b.y + (b.h - 6 * s) * .5f, sw, 6 * s};
                rect(z, c, dim(pal[24], a), 3 * s);
                float fraction = (v - d.minimum) / (d.maximum - d.minimum);
                rect(z, {c.x, c.y, c.w * fraction, c.h}, dim(pal[25], a), 3 * s);
                if (editing == i) {
                    Box edit{c.x, b.y, c.w, b.h};
                    rect(z, edit, pal[12], 6 * s);
                    rect(z, edit, pal[11], 6 * s, s);
                    text(z, {edit.x + 6 * s, edit.y + 7 * s, edit.w - 12 * s, F}, DecodeUTF8(numeric + "|"),
                         pal[2]);
                }
            }
            if (acceptHits) {
                controls[std::size_t(i)] = c;
            }
            labelRight = c.x - 6 * s;
            if (enabled) {
                Box target = kind == Slider ? Box{c.x, b.y, c.w, b.h}
                             : inner        ? b
                                            : Box{b.x - 13 * s, b.y - 6 * s, b.w + 26 * s, b.h + 12 * s};
                hit(z, target, kind, i, -1, c);
            }

            if (d.color >= 0) {
                Box cb{c.x - 22 * s, b.y + (b.h - 16 * s) * .5f, 16 * s, 16 * s};
                Color col = cfg.players.colors[std::size_t(d.color)];
                rect(z, {cb.x - 3 * s, cb.y - 3 * s, cb.w + 6 * s, cb.h + 6 * s},
                     dim(pal[33], .4f * motion(Swatch, i) * a), 6 * s);

                Box rasterBox{std::floor(cb.x) - 1, std::floor(cb.y) - 1,
                              std::ceil(cb.x + cb.w) - std::floor(cb.x) + 2,
                              std::ceil(cb.y + cb.h) - std::floor(cb.y) + 2};
                auto image = std::make_shared<Canvas>(int(rasterBox.w), int(rasterBox.h));
                DrawPickerPreview(*image, {cb.x - rasterBox.x, cb.y - rasterBox.y, cb.w, cb.h}, s, H, col,
                                  col, false, false);
                PresetDraw sw{rasterBox, {1, 1, 1, a}, 0, 0, 15, {}, false};
                sw.raster = image;
                sw.rasterStamp = PickerPreviewStamp(col, col, false, false);
                sw.clipped = true;
                sw.clip = paint.layers[std::size_t(z)].box;
                paint.layers[std::size_t(z)].draw.push_back(std::move(sw));
                if (acceptHits)
                    swatches[std::size_t(i)] = cb;
                if (enabled)
                    hit(z, cb, Swatch, i);
                labelRight = cb.x - 6 * s;
            }
            text(z, {left, b.y + (b.h - F) * .5f, std::max(0.f, labelRight - left), F}, Label(d.key),
                 dim(Mix(pal[0], pal[2], kind == Toggle ? t : hv), a));
        };
        float top = header.y + header.h + 15 * s;
        content = {layout.content.x + 15 * s, top, std::max(0.f, layout.content.w - 30 * s),
                   std::max(0.f, layout.content.y + layout.content.h - top - 15 * s)};
        const float cw = std::max(0.f, std::min(300 * s, (content.w - 7 * s) * .5f));
        static constexpr std::array<const char*, 4> groups{
            {"group_visuals_enemies_options", "group_visuals_enemies_model", "group_visuals_teammate_options",
             "group_visuals_teammate_model"}};
        auto groupFields = [&](int group) {
            std::vector<int> fields;
            for (int i = 0; i < 24; ++i)
                if (PlayersSpecs[std::size_t(i)].group == group && PlayersSpecs[std::size_t(i)].parent < 0)
                    fields.push_back(i);
            return fields;
        };
        auto groupHeight = [&](int group) {
            auto n = groupFields(group).size();
            return heading + 5 * s + 14 * s + float(n) * H + float(n - 1) * 15 * s;
        };
        maxScroll = std::max(0.f, groupHeight(page * 2) + 15 * s + groupHeight(page * 2 + 1) - content.h);
        scroll = std::clamp(scroll, 0.f, maxScroll);
        auto drawGroups = [&](int selected, float alpha, bool interactive) {
            if (alpha <= .001f && !interactive)
                return;
            acceptHits = interactive;
            int z = layer(content);
            paint.layers[std::size_t(z)].opacity = alpha;
            float y = top - scroll;
            for (int j = 0; j < 2; ++j) {
                int group = selected * 2 + j;
                auto fields = groupFields(group);
                Box card{content.x, y + heading + 5 * s, cw,
                         14 * s + float(fields.size()) * H + float(fields.size() - 1) * 15 * s};
                if (interactive)
                    cards[std::size_t(group)] = card;
                text(z, {card.x + 14 * s, y, cw - 28 * s, heading}, Upper(Label(groups[std::size_t(group)])),
                     pal[3], 0, 10);
                rect(z, card, pal[40], 15 * s);
                rect(z, card, pal[11], 15 * s, s);
                float ry = card.y + 7 * s;
                for (int i : fields) {
                    Box b{card.x + 14 * s, ry, cw - 28 * s, H};
                    if (i != fields.front()) {
                        rect(z, {b.x, b.y - 8 * s, b.w, s}, pal[34]);
                        paint.layers[std::size_t(z)].draw.back().pixelLine = true;
                    }
                    row(z, b, i, false, i == fields.front() ? 3u : i == fields.back() ? 12u : 0u);
                    ry += H + 15 * s;
                }
                y = card.y + card.h + 15 * s;
            }

            for (auto& d : paint.layers[std::size_t(z)].draw)
                d.color.a *= alpha;
        };
        float blend = pageBlend.initialized ? pageBlend.value : 1.f;
        if (previousPage != page && blend < 1)
            drawGroups(previousPage, 1 - blend, false);
        drawGroups(page, blend, true);
        acceptHits = true;

        float tabF = fonts.PixelHeight(1, 13 * s), tabH = tabF + 6 * s;
        const auto nativePreview = NativePreviewLayout(layout.content, layout.headerHeight, s, tabH);
        const float toolbarTop = nativePreview.toolbarY;
        int base = layer(nativePreview.work);
        std::array<float, 2> widths{};
        for (int i = 0; i < 2; ++i) {
            float expansion = tabExpand[i].initialized ? tabExpand[i].value : page == i ? 1.f : 0.f;
            float iw = tw(std::u32string(1, i ? 0xf503 : 0xf007), 3);
            widths[i] =
                iw + 12 * s +
                (fonts.NativeTextSize(1, 13 * s, Label(i ? "tab_visuals_teammates" : "tab_visuals_enemies"))
                     .w +
                 6 * s) *
                    expansion;
        }
        float total = widths[0] + widths[1] + 5 * s + 2 * tabH + 16 * s,
              tx = nativePreview.columnX +
                   (nativePreview.body.x + nativePreview.body.w - nativePreview.columnX - total) * .5f;
        toolbar = {tx, toolbarTop, total, tabH};
        for (int i = 0; i < 2; ++i) {
            float expansion = tabExpand[i].initialized ? tabExpand[i].value : page == i ? 1.f : 0.f;
            Box b{tx, toolbarTop, widths[i], tabH};
            tabs[std::size_t(i)] = b;
            float fill = tabFill[i].initialized ? tabFill[i].value : page == i ? .5f : 0.f;
            rect(base, b, dim(pal[33], .4f * fill), 7.8f * s);
            Color col = pal[page == i ? 31 : 0];
            auto icon = std::u32string(1, i ? 0xf503 : 0xf007);
            float iw = tw(icon, 3);
            text(base, {b.x + 6 * s, b.y + 3 * s, iw, tabF}, icon, col, 3);
            if (expansion > 0) {
                auto start = paint.layers[std::size_t(base)].draw.size();
                text(base, {b.x + 6 * s + iw + 6 * s, b.y + 3 * s, std::max(0.f, b.w - iw - 18 * s), tabF},
                     Label(i ? "tab_visuals_teammates" : "tab_visuals_enemies"), dim(col, expansion), 1);
                for (std::size_t k = start; k < paint.layers[std::size_t(base)].draw.size(); ++k)
                    paint.layers[std::size_t(base)].draw[k].clip = PresetIntersect(nativePreview.work, b);
            }
            hit(base, b, Tab, i);
            tx += b.w + (i == 0 ? 5 * s : 0);
        }
        tx += 5 * s;
        rect(base, {tx, toolbarTop + 3 * s, s, tabH - 6 * s}, pal[34]);
        paint.layers[std::size_t(base)].draw.back().pixelLine = true;
        tx += 6 * s;
        customize = {tx, toolbarTop, tabH, tabH};
        universal = {tx + tabH + 5 * s, toolbarTop, tabH, tabH};
        for (int i = 0; i < 2; ++i) {
            Box b = i ? universal : customize;
            int kind = i ? Universal : Customize;
            float m = motion(kind, -1);
            rect(base, b, dim(pal[33], .4f * m), 6 * s);
            auto icon = std::u32string(1, i ? 0xe0a0 : 0xe489);
            float iw = tw(icon, 3);
            Color col = pal[i ? (cfg.players.universalScaling ? 31 : 30) : 0];
            if (i)
                col.a *= .7f + .3f * std::min(1.f, m * 2);
            text(base, {b.x + (b.w - iw) * .5f, b.y + 3 * s, iw, tabF}, icon, col, 3);
            hit(base, b, kind);
        }

        previewBox = nativePreview.child;
        boundingBox = PreviewBoundingBox(previewBox, s, F);
        previewHover.Begin(previewBox, page, !blocked && !Active() && !espSettings.Active(), s,
                           cfg.players.universalScaling);
        previewHover.SetAnchor(boundingBox);
        for (int i = 0; i < 29; ++i)
            previewHover.itemMargin[std::size_t(i)] =
                2 + .5f * ESPSizeStep(cfg.players.espSettings[std::size_t(page)][std::size_t(i)], s,
                                      cfg.players.universalScaling, cfg.espScale);
        auto previewStart = paint.layers.size();
        if (cfg.players.espEnabled[std::size_t(page)][0] && boundingBox.w > 2 && boundingBox.h > 2) {
            int z = layer(previewBox);

            Color ink = PreviewPackedColor(cfg.players.espSettings[std::size_t(page)][0].colors[0]);
            if (ink.a > 0)
                rect(z, boundingBox, ink, 0, 1);
            Color outline{10.f / 255, 10.f / 255, 10.f / 255, 140.f / 255};
            rect(z, {boundingBox.x - 1, boundingBox.y - 1, boundingBox.w + 2, boundingBox.h + 2}, outline, 0,
                 1);
            rect(z, {boundingBox.x + 1, boundingBox.y + 1, boundingBox.w - 2, boundingBox.h - 2}, outline, 0,
                 1);
        }
        if (cfg.players.espEnabled[std::size_t(page)][1] && boundingBox.w > 2 && boundingBox.h > 2) {
            const auto& values = cfg.players.espSettings[std::size_t(page)][1];

            auto label = PreviewNameCase(U"Neverlose", values.value[1]);
            auto nf = PreviewNameFont(
                values.value[0],
                1.f + .25f * ESPSizeStep(values, s, cfg.players.universalScaling, cfg.espScale), true);
            auto size = fonts.ESPTextSize(nf.face, nf.px, label);
            float width = std::min(std::trunc(size.w + .95f), 400 * s);
            auto image = values.value[2] ? cfg.avatar : nullptr;
            int side = previewHover.Side(1);
            auto metrics = PlayersNameAvatar::Measure(width, size.h, fonts.PixelHeight(nf.face, nf.px), side,
                                                      image.get());
            Box b = PreviewNameBox(previewBox, boundingBox, metrics.width, metrics.anchorHeight, s);
            int z = layer(previewBox);
            nameAvatar.Draw(paint.layers[std::size_t(z)], previewBox, b, label, values.colors[0],
                            {nf.face, nf.px}, s, metrics, image, side);
            previewHover.Add(1, {b.x, b.y, b.w, metrics.hitHeight});
            previewHover.advance[1] = metrics.height;
            PlayersPreviewHover::Mark(paint.layers[std::size_t(z)], 0, 1);
        }
        if (boundingBox.w > 2 && boundingBox.h > 2) {
            const auto team = std::size_t(page);
            float bottomStack = 0;
            if (cfg.players.espEnabled[team][3]) {
                int z = layer(previewBox);
                float step = mainPreview.Bar(paint.layers[std::size_t(z)], fonts, previewBox, boundingBox, s,
                                             cfg.players.universalScaling, true,
                                             cfg.players.espSettings[team][3], previewHover.Side(3),
                                             ESPSizeStep(cfg.players.espSettings[team][3], s,
                                                         cfg.players.universalScaling, cfg.espScale));
                auto body =
                    PlayersMainPreview::BarBox(previewBox, boundingBox,
                                               (2 + ESPSizeStep(cfg.players.espSettings[team][3], s,
                                                                cfg.players.universalScaling, cfg.espScale)),
                                               true, s);
                bool vertical = PlayersPreviewHover::Vertical(previewHover.Side(3));
                body.w = vertical ? float((2 + ESPSizeStep(cfg.players.espSettings[team][3], s,
                                                           cfg.players.universalScaling, cfg.espScale)))
                                  : PlayersMainPreview::Round(boundingBox.w);
                body.h = vertical ? PlayersMainPreview::Round(boundingBox.h)
                                  : float((2 + ESPSizeStep(cfg.players.espSettings[team][3], s,
                                                           cfg.players.universalScaling, cfg.espScale)));
                previewHover.Bar(3, paint.layers[std::size_t(z)], 0, body, step);
            }
            if (cfg.players.espEnabled[team][4]) {
                int z = layer(previewBox);
                float step = mainPreview.Bar(paint.layers[std::size_t(z)], fonts, previewBox, boundingBox, s,
                                             cfg.players.universalScaling, false,
                                             cfg.players.espSettings[team][4], previewHover.Side(4),
                                             ESPSizeStep(cfg.players.espSettings[team][4], s,
                                                         cfg.players.universalScaling, cfg.espScale));
                auto body =
                    PlayersMainPreview::BarBox(previewBox, boundingBox,
                                               (2 + ESPSizeStep(cfg.players.espSettings[team][4], s,
                                                                cfg.players.universalScaling, cfg.espScale)),
                                               false, s);
                bool vertical = PlayersPreviewHover::Vertical(previewHover.Side(4));
                body.w = vertical ? float((2 + ESPSizeStep(cfg.players.espSettings[team][4], s,
                                                           cfg.players.universalScaling, cfg.espScale)))
                                  : PlayersMainPreview::Round(boundingBox.w);
                body.h = vertical ? PlayersMainPreview::Round(boundingBox.h)
                                  : float((2 + ESPSizeStep(cfg.players.espSettings[team][4], s,
                                                           cfg.players.universalScaling, cfg.espScale)));
                previewHover.Bar(4, paint.layers[std::size_t(z)], 0, body, step);
                bottomStack = step;
            }
            if (cfg.players.espEnabled[team][2]) {
                const auto& v = cfg.players.espSettings[team][2];
                auto nf = PreviewNameFont(
                    v.value[0], 1.f + .25f * ESPSizeStep(v, s, cfg.players.universalScaling, cfg.espScale),
                    true);
                auto label = PreviewNameCase(U"50 m", v.value[1]);
                auto size = fonts.ESPTextSize(nf.face, nf.px, label);
                float w = std::min(std::trunc(size.w + .95f), 400 * s);
                Box b = PlayersMainPreview::DistanceBox(previewBox, boundingBox, w, size.h, bottomStack, s);
                int z = layer(previewBox);
                PlayersMainPreview::Text(paint.layers[std::size_t(z)], previewBox, b, label, v.colors[0],
                                         {nf.face, nf.px}, s);
                previewHover.Add(2, b);
                PlayersPreviewHover::Mark(paint.layers[std::size_t(z)], 0, 2);
                bottomStack += size.h + 2;
            }
            int z = layer(previewBox);
            remainingPreview.Draw(paint.layers[std::size_t(z)], fonts, previewBox, boundingBox, s,
                                  cfg.players.universalScaling, cfg.players.espEnabled[team],
                                  cfg.players.espSettings[team], bottomStack, PreviewNameFont,
                                  PreviewNameCase, &previewHover, cfg.espScale);

            if (paint.layers[std::size_t(z)].draw.empty())
                paint.layers.pop_back();
        }
        previewHover.Apply(paint, previewStart);
        auto highlight = previewHover.Highlight(cfg);
        if (!highlight.draw.empty())
            paint.layers.insert(paint.layers.begin() + std::ptrdiff_t(previewStart), std::move(highlight));
        auto remember = [&](int key, std::size_t start) {
            auto& t = transitions[key];
            if (!t.alpha.initialized)
                t.alpha.Snap(0);
            t.cached.assign(paint.layers.begin() + std::ptrdiff_t(start), paint.layers.end());
            for (std::size_t j = start; j < paint.layers.size(); ++j) {
                paint.layers[j].opacity *= t.alpha.value;
                for (auto& d : paint.layers[j].draw)
                    d.color.a *= t.alpha.value;
            }
        };
        searchLayerStart = paint.layers.size();
        if (customizeOpen) {

            const float outerBorder = 1.f;
            const float outerPad = 7 * s + outerBorder;
            const float cardX = 13 * s, cardY = 8 * s;
            const float titleF = fonts.PixelHeight(1, 14 * s), titleH = F + 12 * s;

            const float separatorH = s, bodyTop = outerPad + titleH + 7 * s + separatorH + 7 * s;
            float listW = std::max(1.f, std::trunc(previewBox.w - 5 * s + .5f));

            float pw = std::min(listW + 2 * outerPad, std::max(1.f, float(width) - 12 * s));
            listW = std::max(1.f, pw - 2 * outerPad);

            const float childEndExtra = s > 1.f ? s * .5f : 0.f;
            float gap = 5 * s, lineGap = 7 * s, bh = F + 9 * s;
            struct Pill {
                int index;
                Box box;
            };
            std::vector<Pill> pills;
            std::vector<std::pair<int, Box>> sections;
            float y = 0;
            for (int g = 0; g < 5; ++g) {
                std::vector<int> list;
                for (std::size_t i = 0; i < PlayersESPItems.size(); ++i)
                    if (PlayersESPItems[i].category == g)
                        list.push_back(int(i));
                if (list.empty())
                    continue;
                float sy = y, x = cardX;
                y += cardY + tabF + 10 * s;
                float lineY = y;
                for (int i : list) {
                    float bw =
                        std::min(std::max(1.f, listW - 2 * cardX),
                                 std::trunc(tw(Label(PlayersESPItems[std::size_t(i)].key)) + .95f) + 18 * s);
                    if (x > cardX && x + bw > listW - cardX) {
                        x = cardX;
                        lineY += bh + lineGap;
                    }
                    pills.push_back({i, {outerPad + x, lineY, bw, bh}});
                    x += bw + gap;
                }
                y = lineY + bh + cardY;
                sections.push_back({g, {outerPad, sy, listW, y - sy}});
                y += childEndExtra + 7 * s;
            }
            float bodyH = std::max(0.f, y - 7 * s), desired = bodyTop + bodyH + outerPad;
            float ph = std::min(desired, std::max(1.f, float(height) - 12 * s));
            customizeMax = std::max(0.f, desired - ph);
            customizeScroll = std::clamp(customizeScroll, 0.f, customizeMax);

            customizeParentY = nativePreview.body.y;

            customizeBox =
                PresetPopupFit({previewBox.x + 5 * s, customizeParentY + 40 * s, pw, ph}, width, height);
            if (!blocked)
                hits.push_back({{0, 0, float(width), float(height)}, Surface});
            auto start = paint.layers.size();
            int z = layer(customizeBox, true);
            rect(z, customizeBox, pal[8], 15 * s);
            rect(z, customizeBox, pal[11], 15 * s, outerBorder);
            hit(z, customizeBox, Surface, -2);

            float titleW =
                std::trunc(fonts.NativeTextSize(1, 14 * s, Label("visuals_preview_items")).w + .95f);
            customizeTitle = {customizeBox.x + outerPad + 7 * s,
                              std::trunc(customizeBox.y + outerPad + (titleH - titleF) * .5f),
                              std::min(titleW, std::max(0.f, pw - 2 * outerPad - 7 * s)), titleF};
            text(z, customizeTitle, Label("visuals_preview_items"), pal[2], 1, 14);

            rect(z,
                 {customizeBox.x + outerBorder, customizeBox.y + outerPad + titleH + 7 * s,
                  pw - 2 * outerBorder, separatorH},
                 pal[34]);
            paint.layers[std::size_t(z)].draw.back().pixelLine = true;
            customizeViewport = {customizeBox.x + outerPad, customizeBox.y + bodyTop, listW,
                                 std::max(0.f, customizeBox.h - bodyTop - outerPad)};
            Box viewport = customizeViewport;
            int iz = z;
            auto childStart = paint.layers[std::size_t(z)].draw.size();
            for (const auto& section : sections) {
                Box b = section.second;
                b.x += customizeBox.x;
                b.y += customizeViewport.y - customizeScroll;
                rect(iz, b, pal[40], std::trunc(15 * s / 1.5f));
                rect(iz, b, pal[11], std::trunc(15 * s / 1.5f), s);
                text(iz, {b.x + cardX, b.y + cardY, std::max(0.f, b.w - 2 * cardX), tabF},
                     Label(PlayersESPCategories[std::size_t(section.first)]), pal[2], 1);
            }
            for (const auto& pill : pills) {
                Box b = pill.box;
                b.x += customizeBox.x;
                b.y += customizeViewport.y - customizeScroll;
                bool selected = cfg.players.espEnabled[std::size_t(page)][std::size_t(pill.index)];
                auto& fm = espFill[std::size_t(page)][std::size_t(pill.index)];
                auto& im = espInk[std::size_t(page)][std::size_t(pill.index)];
                float fill = fm.initialized ? fm.value : (selected ? .5f : 0.f),
                      ink = im.initialized ? im.value : (selected ? 1.f : 0.f);
                rect(iz, b, pal[40], 6 * s);
                rect(iz, b, Mix(pal[11], dim(pal[31], .4f), ink), 6 * s, s);
                rect(iz, b, dim(pal[33], .2f * fill), 6 * s);
                float labelW = std::trunc(tw(Label(PlayersESPItems[std::size_t(pill.index)].key)) + .95f);
                text(iz,
                     {std::trunc(b.x + (b.w - labelW) * .5f), std::trunc(b.y + (b.h - F) * .5f), labelW, F},
                     Label(PlayersESPItems[std::size_t(pill.index)].key), Mix(pal[14], pal[2], ink));
                hit(iz, PresetIntersect(b, viewport), ESPItem, pill.index);
            }
            for (std::size_t j = childStart; j < paint.layers[std::size_t(z)].draw.size(); ++j)
                paint.layers[std::size_t(z)].draw[j].clip = viewport;
            remember(3000, start);
        }
        if (detail >= 0) {
            std::vector<int> children;
            for (int i = 0; i < 24; ++i)
                if (PlayersSpecs[std::size_t(i)].parent == detail)
                    children.push_back(i);
            float pickerH = InlinePicker().Height(s), desired = pickerH + 21 * s + float(children.size()) * R;
            detailBox = PresetPopupFit({detailAnchor.x, detailAnchor.y, 265 * s,
                                        std::min(desired, std::max(1.f, float(height) - 12 * s))},
                                       width, height);
            if (!blocked)
                hits.push_back({{0, 0, float(width), float(height)}, Surface});
            auto start = paint.layers.size();
            int z = surface(detailBox, true);
            hit(z, detailBox, Surface, -2);
            Box body{detailBox.x, detailBox.y, detailBox.w, detailBox.h - 7 * s};
            int bz = z;
            detailMax = std::max(0.f, desired - detailBox.h);
            detailScroll = std::clamp(detailScroll, 0.f, detailMax);
            float y = body.y - detailScroll;
            auto proxy = ColorSettings(cfg);
            if (suspendedPicker)
                proxy.worldHud.colors[4] =
                    cfg.players.colors[std::size_t(PlayersSpecs[std::size_t(detail)].color)];
            InlinePicker().Draw(paint, bz, fonts, proxy, {body.x, y, 265 * s, pickerH});
            y += pickerH + 14 * s;
            for (int i : children) {
                row(bz, {body.x + 14 * s, y, body.w - 28 * s, R}, i, true);
                y += R;
            }
            if (choice < 0 && color < 0 && editing < 0)
                for (int i : children) {
                    const auto& d = PlayersSpecs[std::size_t(i)];
                    float a = sliderTip[std::size_t(i)].value;
                    if ((d.kind != WorldKind::Integer && d.kind != WorldKind::Decimal) || a <= .001f ||
                        !Enabled(i, cfg))
                        continue;
                    Box bar = controls[std::size_t(i)];
                    auto label = DecodeUTF8(Number(i, cfg));
                    float tw2 = tw(label),
                          t = (cfg.players.value[std::size_t(i)] - d.minimum) / (d.maximum - d.minimum);
                    Box tip = PresetPopupFit(
                        {bar.x + bar.w * t - tw2 * .5f - 7 * s, bar.y - F - 14 * s, tw2 + 14 * s, F + 9 * s},
                        width, height);
                    int tz = layer(tip, true);
                    rect(tz, tip, dim(pal[8], a), 8 * s);
                    rect(tz, tip, dim(pal[11], a), 8 * s, s);
                    text(tz, {tip.x + 7 * s, tip.y + 4 * s, tw2, F}, label, dim(pal[0], a));
                }
            remember(detail, start);
        }
        if (choice >= 0) {
            auto opts = PlayersOptions(choice);
            bool multi = PlayersSpecs[std::size_t(choice)].kind == WorldKind::Multi;
            Box choiceSource = searchChoiceAnchor ? searchChoiceBox : choiceAnchor;
            float pw = choiceSource.w;
            for (const auto& key : opts)
                pw = std::max(pw, tw(Label(key)) + 38 * s + (multi ? tw(U"\uf00c", 3) + 12 * s : 0.f));
            float ph = std::min(300 * s, 14 * s + float(opts.size()) * R);
            Box a = rows[std::size_t(choice)];
            if (searchChoiceAnchor)
                a = choiceSource;
            Box b = PresetPopupFit(multi ? Box{a.x + a.w + 7 * s, a.y + a.h * .5f - ph * .25f, pw, ph}
                                         : Box{choiceSource.x + (choiceSource.w - pw) * .5f,
                                               choiceSource.y + (choiceSource.h - ph) * .5f, pw, ph},
                                   width, height);
            if (!blocked)
                hits.push_back({{0, 0, float(width), float(height)}, Surface});
            auto start = paint.layers.size();
            int z = surface(b, true);
            hit(z, b, Surface, -2);
            for (std::size_t j = 0; j < opts.size(); ++j) {
                Box r{b.x + 7 * s, b.y + 7 * s + float(j) * R, b.w - 14 * s, R};
                rect(z, r, dim(pal[33], .4f * motion(Option, choice, int(j))), 15 * s / 1.6f);
                bool selected = multi ? (int(cfg.players.value[std::size_t(choice)]) & (1 << j)) != 0
                                      : int(cfg.players.value[std::size_t(choice)]) == int(j);
                if (multi && selected)
                    text(z, {r.x + 12 * s, r.y + 7 * s, 16 * s, F}, U"\uf00c", pal[0], 3);
                text(z, {r.x + (multi ? 34 : 12) * s, r.y + 7 * s, r.w - (multi ? 46 : 24) * s, F},
                     Label(opts[j]), pal[selected ? 2 : 14]);
                hit(z, r, Option, choice, int(j));
            }
            remember(1000 + choice, start);
        }
        if (color >= 0) {
            if (!blocked)
                hits.push_back({{0, 0, float(width), float(height)}, Surface});
            auto start = paint.layers.size();
            picker.languages = languages;
            picker.SetMetrics(fonts, s);
            auto proxy = ColorSettings(cfg);
            Box b = PresetPopupFit(
                {colorAnchor.x + colorAnchor.w + 7 * s, colorAnchor.y, 265 * s, picker.Height(s)}, width,
                height);
            int z = surface(b, true);
            picker.Draw(paint, z, fonts, proxy, b);
            remember(2000 + color, start);
        }
        if (PickerActive() && choice < 0) {
            auto proxy = ColorSettings(cfg);
            picker.DrawMenus(paint, fonts, proxy, width, height);
        }
        if (!TipKey().empty() && hoverSeconds >= .3f) {
            bool arrow = TipKey() == "visuals_enemies_options_offscreenarrow_tooltip";
            tooltipLast = WorldDescriptionTooltip(fonts, cfg, arrow ? rows[1] : universal,
                                                  Label(arrow ? "visuals_enemies_options_offscreenarrow"
                                                              : "visuals_preview_items_universalscaling"),
                                                  Label(TipKey()), width, height);
            tooltipStored = true;
        }
        if (previewHover.allowed && previewHover.tipItem >= 0 && previewHover.hot == previewHover.tipItem &&
            previewHover.tipFade.value > 0) {
            int i = previewHover.tipItem;
            auto b = previewHover.bounds[std::size_t(i)];
            if (b.w > 0 && b.h > 0) {
                auto tip = WorldDescriptionTooltip(fonts, cfg, b, Label(PlayersESPItems[std::size_t(i)].key),
                                                   Label("visuals_preview_item_tooltip"), width, height);
                AppendWorldTooltip(paint, tip, previewHover.tipFade.value);
            }
        }
        if (tooltipStored)
            AppendWorldTooltip(paint, tooltipLast, tooltipFade.value);
        for (auto it = transitions.begin(); it != transitions.end();) {
            if (!Showing(it->first)) {
                if (it->second.alpha.value <= .001f) {
                    it = transitions.erase(it);
                    continue;
                }
                for (auto l : it->second.cached) {
                    l.opacity *= it->second.alpha.value;
                    for (auto& d : l.draw)
                        d.color.a *= it->second.alpha.value;
                    paint.layers.push_back(std::move(l));
                }
            }
            ++it;
        }
        espSettings.languages = languages;
        espSettings.Draw(paint, fonts, cfg, width, height);
    }
};
}
