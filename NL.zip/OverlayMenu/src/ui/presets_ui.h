#pragma once
#include "presets_local.h"
#include "preset_change_tracker.h"
#include "presets_motion.h"
#include "presets_edit.h"
#include "presets_widgets.h"
#include "extensions_api.h"
#include "group_row_geometry.h"
#include "color_picker_common.h"
#include <cstdlib>
namespace menu {

inline Box PresetIntersect(Box a, Box b) {
    float x = std::max(a.x, b.x), y = std::max(a.y, b.y);
    return {x, y, std::max(0.f, std::min(a.x + a.w, b.x + b.w) - x),
            std::max(0.f, std::min(a.y + a.h, b.y + b.h) - y)};
}

inline Box PresetPixelClip(Box b) {
    float x = std::ceil(b.x - .5f), y = std::ceil(b.y - .5f), r = std::ceil(b.x + std::max(0.f, b.w) - .5f),
          bottom = std::ceil(b.y + std::max(0.f, b.h) - .5f);
    return {x, y, std::max(0.f, r - x), std::max(0.f, bottom - y)};
}
inline Box PresetAAClip(Box b) {
    return {b.x - 1, b.y - 1, b.w + 2, b.h + 2};
}
struct PresetDraw {
    Box box;
    Color color;
    float radius = 0, stroke = 0;
    unsigned corners = 15;
    std::u32string text;
    bool icon = false;
    Box clip{};
    bool clipped = false;
    int font = 1;
    float textSize = 13;
    std::shared_ptr<const Canvas> raster{};
    std::uint64_t rasterStamp = 0;
    bool pixelLine = false, uniformSeparator = false;

    float backdropOpacity = 0, shadowSize = 0;
    Color shadowColor{};
    int iconDestination = 0;
    bool espText = false;

    int previewItem = -1;
    int nativePreviewTeam = -1;
    bool indicatorLine = false;
    float indicatorGlow = 0;
};
struct PresetHit {
    Box box;
    int layer = 0, action = 0, index = 0;
    std::string id, key;
};

struct PresetLayer {
    Box box;
    float radius = 0;
    bool popup = false;
    std::vector<PresetDraw> draw;
    float opacity = 1;
    float nativeHUDScale = 0;
    bool pixelAligned = false;
    bool shadow = true, clipToPage = true, searchSurface = false, searchOverlay = false;
};
inline bool PresetLayerInPass(const PresetLayer& layer, int pass) {
    const bool overlay = layer.popup || layer.searchOverlay;
    return pass == 0 || (pass == 1 ? !overlay : overlay);
}
enum class MainSearchSource { None, Rage, Players, WorldView, WorldESP, WorldHud, WorldMisc, Ambience };
struct MainSearchItem {
    std::u32string label, group;
    int target = -1;
    MainSearchSource source = MainSearchSource::None;
    int index = -1;
    bool check = false, numeric = false, enabled = true;
    float minimum = 0, maximum = 0;
    std::u32string display, description, detailGroup;
    std::vector<std::u32string> options;
    bool multi = false;
    int profile = 0, colorSlot = -1, colorCount = 0;
};
struct MainSearchGroup {
    std::u32string title;
    std::vector<std::size_t> items;
};
inline PresetLayer PresetDescriptionTooltip(Fonts& fonts, const Settings& cfg, Box item,
                                           const std::u32string& title, const std::u32string& body, int width,
                                           int height, float requestedTextWidth = 0) {
    const float s = cfg.scale, F = fonts.PixelHeight(0, 13 * s), pad = 10 * s;
    const float maxWidth =
        std::max(1.f, std::min(requestedTextWidth > 0 ? requestedTextWidth : 20 * F, float(width) - 26 * s));
    std::vector<std::u32string> lines;
    std::u32string line, word;
    auto flush = [&] {
        lines.push_back(line);
        line.clear();
    };
    auto append = [&] {
        if (!line.empty() && fonts.NativeTextSize(0, 13 * s, line + U" " + word).w > maxWidth)
            flush();
        if (!line.empty() && !word.empty())
            line += U" ";
        line += word;
        word.clear();
    };
    for (char32_t cp : body) {
        if (cp == U' ' || cp == U'\n') {
            append();
            if (cp == U'\n')
                flush();
        } else
            word += cp;
    }
    append();
    if (!line.empty() || lines.empty())
        flush();
    float widest = fonts.NativeTextSize(2, 13 * s, title).w;
    for (const auto& t : lines)
        widest = std::max(widest, fonts.NativeTextSize(0, 13 * s, t).w);
    const float w = std::min(std::trunc(widest + .95f) + 2 * pad, std::max(1.f, float(width) - 6 * s)),
                h = 3 * pad + F * (1 + float(lines.size()));
    Box b{std::trunc(std::clamp(item.x + item.w + 15 * s, 3 * s, std::max(3 * s, float(width) - w - 3 * s))),
          std::trunc(
              std::clamp(item.y + (item.h - h) * .5f, 3 * s, std::max(3 * s, float(height) - h - 3 * s))),
          w, h};
    auto pal = CurrentPalette(cfg);
    PresetLayer layer{b, 10 * s, true, {}};
    layer.draw.push_back({b, pal[8], 10 * s, 0, 15, {}, false});
    layer.draw.push_back({b, pal[11], 10 * s, s, 15, {}, false});
    auto text = [&](const std::u32string& t, float y, int font, Color col) {
        if (t.empty())
            return;
        PresetDraw d{{b.x + pad, y, b.w - 2 * pad, F}, col, 0, 0, 15, t, false};
        d.font = font;
        d.textSize = 13;
        d.clipped = true;
        d.clip = b;
        layer.draw.push_back(std::move(d));
    };
    text(title, b.y + pad, 2, pal[2]);
    float y = b.y + 2 * pad + F;
    for (const auto& t : lines) {
        text(t, y, 0, pal[14]);
        y += F;
    }
    return layer;
}

struct PresetsUI {
    bool mainSearch = false;
    int mainSearchTarget = -1;
    float mainSearchOffset = 0, mainSearchMaximum = 0, mainSearchHeightTarget = 0;
    PresetMotion mainSearchHeight, mainSearchOpacity;
    std::map<std::pair<MainSearchSource, int>, PresetMotion> mainSearchChecks;
    int mainSearchChoice = -1, mainSearchChoiceLayer = -1, mainSearchColorRequest = -1, mainSearchDetail = -1;
    int mainSearchNativeRequest = -1, mainSearchNativeAction = 0;
    Box mainSearchNativeAnchor{};
    float mainSearchDetailOffset = 0, mainSearchDetailMaximum = 0;
    Box mainSearchDetailAnchor{}, mainSearchDetailBox{};
    Box mainSearchColorAnchor{};
    Box mainSearchChoiceAnchor{};
    int mainSearchDrag = -1;
    Box mainSearchDragTrack{};
    std::u32string mainSearchText;
    std::vector<MainSearchItem> mainSearchItems;
    PresetStore store;
    bool open = false, trash = false, sorting = false, searchFocus = false;
    int page = 0;
    float scroll = 0, trashScroll = 0;
    std::string context, renaming, clipboardOut, notice;
    std::u32string search, renameText;
    char16_t highSurrogate = 0;

    struct DefaultExtension {
        std::string id;
        std::u32string name;
        bool external = false, prebuilt = true, active = false;
    };
    std::vector<DefaultExtension> defaultExtensions{{"demo-interface", U"Interface Tools", false, true, true},
                                                    {"demo-theme", U"Theme Helper", false, true, true},
                                                    {"demo-layout", U"Layout Notes", false, true, false}};
    struct DefaultRowMotion {
        PresetMotion fill, text;
    };
    std::map<std::string, DefaultRowMotion> defaultRowMotion;
    static std::u32string DefaultLabel(const std::u32string& label) {
        return label.substr(0, std::min(label.find(U"##"), label.find(U'\n')));
    }
    Box defaultAnchor{};
    bool defaultPosition = false;
    bool apiDocsRequested = false;
    bool TakeApiDocsRequest() {
        bool requested = apiDocsRequested;
        apiDocsRequested = false;
        return requested;
    }
    bool renameSelectAll = false;
    int hovered = -1, held = -1;
    float hoverSeconds = 0, noticeSeconds = 0, dirtySeconds = 0, purgeSeconds = 0, caretSeconds = 0;
    PresetChangeTracker changes;
    std::string heldKey, hoverKey, hoverRow;
    std::map<std::string, PresetMotion> tweens;
    std::map<std::string, float> saved;
    std::array<PresetMotion, 2> tabExpand, tabFill;
    PresetMotion pageBlend, searchTween;

    PresetMotion defaultButtonFill, defaultButtonInk;
    std::map<std::string, PresetMotion> rowBorder, rowFill, rowVisibility, savedFade;
    PresetMotion selectorFill, scrollFill, trashScrollFill;
    PresetEditor editor;
    std::string editorKey;
    Box editorBox{};
    PresetScrollView listScroll, trashView;
    float mouseX = -1, mouseY = -1, uiScale = 1;
    Box contextAnchor{}, sortAnchor{}, trashAnchor{};
    bool contextPosition = false, sortPosition = false, trashPosition = false;
    int extensionPanel = 0;
    PresetMotion tooltipFade;
    PresetLayer tooltipLast{};
    bool tooltipStored = false;
    int animationPage = -1, previousPage = 0;
    std::size_t bodyStart = 0;
    Box searchBox{}, renameBox{};
    void SyncMotion() {
        if (!defaultButtonFill.initialized)
            defaultButtonFill.Snap(0);
        if (!defaultButtonInk.initialized)
            defaultButtonInk.Snap(0);
        for (const auto& e : defaultExtensions) {
            auto& m = defaultRowMotion[e.id];
            if (!m.fill.initialized)
                m.fill.Snap(0);
            if (!m.text.initialized)
                m.text.Snap(e.active ? 1.f : 0.f);
        }
        if (animationPage < 0) {
            animationPage = previousPage = page;
            pageBlend.Snap(1);
            for (int i = 0; i < 2; ++i) {
                tabExpand[i].Snap(page == i ? 1.f : 0.f);
                tabFill[i].Snap(page == i ? .5f : 0.f);
            }
        } else if (animationPage != page) {
            previousPage = animationPage;
            animationPage = page;
            pageBlend.Snap(0);
            pageBlend.Tick(1, 0);
        }
        auto matches = Visible();
        for (const auto& p : store.items)
            if (!p.deleted) {
                if (!savedFade[p.id].initialized)
                    savedFade[p.id].Snap(0);
                bool shown = std::find(matches.begin(), matches.end(), p.id) != matches.end();
                auto& visibility = rowVisibility[p.id];
                if (!visibility.initialized)
                    visibility.Snap(shown ? 1.f : 0.f);
                auto& border = rowBorder[p.id];
                if (!border.initialized)
                    border.Snap(p.id == store.selected ? 1.f : 0.f);
                auto& fill = rowFill[p.id];
                if (!fill.initialized)
                    fill.Snap(p.id == store.selected ? .5f : 0.f);
            }
    }
    std::vector<std::string> AnimatedVisible() const {
        auto ids = Visible(false, false);
        ids.erase(std::remove_if(ids.begin(), ids.end(),
                                 [&](const std::string& id) {
                                     auto it = rowVisibility.find(id);
                                     return it != rowVisibility.end() && it->second.value <= 0 &&
                                            it->second.target <= 0;
                                 }),
                  ids.end());
        return ids;
    }
    Layout anchor{};
    float fontHeight = 18;
    int viewportW = 1200, viewportH = 800;
    std::vector<PresetLayer> layers;
    std::vector<PresetHit> hits;
    Box popup{}, listClip{}, headerSave{}, selector{}, headerLine{}, headerDivider{};
    const LanguageCatalog* languages = nullptr;
    std::u32string Label(const char* key) const {
        if (languages)
            return languages->Label(key);
        auto i = DefaultLanguageStrings().find(key);
        return i == DefaultLanguageStrings().end() ? ASCII(key) : DecodeUTF8(i->second);
    }

    std::u32string RelativeTime(std::int64_t stamp, std::int64_t now) const {
        std::uint32_t age = std::uint32_t(std::uint64_t(now) - std::uint64_t(stamp));
        std::int64_t signedAge = age <= 0x7fffffffU ? std::int64_t(age) : std::int64_t(age) - 0x100000000LL;
        if (signedAge <= 120)
            return Label("time_justnow");
        if (age <= 3600)
            return ASCII(std::to_string(age / 60)) + U" " + Label("time_minutesago");
        if (age <= 21600)
            return ASCII(std::to_string(age / 3600)) + U" " + Label("time_hoursago");
        return Label(age <= 86400     ? "time_today"
                     : age <= 172800  ? "time_yesterday"
                     : age <= 604800  ? "time_lastweek"
                     : age <= 2592000 ? "time_lastmonth"
                                      : "time_longtimeago");
    }

    std::u32string DetailsBody(const LocalPreset& p, std::int64_t now) const {
        return Label("menu_presets_author") + U": " + DecodeUTF8(p.author) + U"\n" +
               Label(p.deleted ? "menu_presets_deleted" : "menu_presets_modified") + U": " +
               RelativeTime(p.deleted ? p.deleted : p.modified, now);
    }
    const LocalPreset* Active() const {
        return store.Find(store.selected);
    }
    void Storage(const std::filesystem::path& root, Settings& cfg) {
        store.Load(root);
        store.Autoload(cfg);
        changes.Observe(cfg);
        dirtySeconds = 0;
    }
    void Notify(const std::string& s) {
        notice = s;
        noticeSeconds = 4;
    }
    void CancelInput() {
        held = -1;
        heldKey.clear();
        highSurrogate = 0;
        listScroll.Stop();
        trashView.Stop();
    }
    bool Editing() const {
        return searchFocus || !renaming.empty();
    }
    std::u32string& EditText() {
        return mainSearch ? mainSearchText : renaming.empty() ? search : renameText;
    }
    void PrepareEditor() {
        auto key = mainSearch ? "main-search-input" : renaming.empty() ? "search" : "rename-" + renaming;
        auto& t = EditText();
        if (editorKey != key) {
            editorKey = key;
            editor.Reset(t, !renaming.empty() && renameSelectAll);
        } else
            editor.Sync(t);
        if (renameSelectAll && !renaming.empty())
            editor.All(t);
    }
    void FocusSearch() {
        searchFocus = true;
        renaming.clear();
        renameSelectAll = false;
        PrepareEditor();
    }
    bool EditKey(int key, bool control = false, bool shift = false) {
        if (!Editing())
            return false;
        PrepareEditor();
        auto& t = EditText();
        bool handled = true;
        switch (key) {
        case 0x25:
            editor.Move(t, -1, shift, control);
            break;
        case 0x27:
            editor.Move(t, 1, shift, control);
            break;
        case 0x24:
            editor.Home(t, false, shift);
            break;
        case 0x23:
            editor.Home(t, true, shift);
            break;
        case 0x2e:
            editor.Delete(t, false, control);
            break;
        default:
            if (control && key == 'A')
                editor.All(t);
            else if (control && key == 'Z')
                editor.History(t, shift);
            else if (control && key == 'Y')
                editor.History(t, true);
            else if (control && (key == 'C' || key == 'X')) {
                clipboardOut = EncodeUTF8(editor.Selection(t));
                if (key == 'X' && editor.Selected())
                    editor.Delete(t, false);
            } else
                handled = false;
        }
        renameSelectAll =
            !renaming.empty() && editor.Begin() == 0 && editor.End() == t.size() && editor.Selected();
        if (handled) {
            caretSeconds = 0;
            if (mainSearch)
                mainSearchOffset = 0;
        }
        return handled;
    }
    void PasteText(const std::string& text) {
        if (!Editing())
            return;
        PrepareEditor();
        editor.Insert(EditText(), DecodeUTF8(text), mainSearch ? 128 : renaming.empty() ? 64 : 128);
        if (mainSearch)
            mainSearchOffset = 0;
        renameSelectAll = false;
        caretSeconds = 0;
        scroll = 0;
    }
    void Close() {
        if (mainSearch)
            mainSearchOpacity.Tick(0.f, 0.f);
        tooltipFade.Snap(0);
        tooltipStored = false;
        listScroll.Stop();
        trashView.Stop();
        extensionPanel = 0;
        mainSearchDrag = mainSearchChoice = mainSearchColorRequest = mainSearchDetail = mainSearchNativeRequest = -1;
        open = trash = sorting = searchFocus = mainSearch = false;
        context.clear();
        renaming.clear();
        heldKey.clear();
        hoverKey.clear();
        hoverRow.clear();
        held = hovered = -1;
        highSurrogate = 0;
    }
    void Escape() {
        if (mainSearch && mainSearchChoice >= 0) {
            mainSearchChoice = -1;
            return;
        }
        if (mainSearch && mainSearchDetail >= 0) {
            mainSearchDetail = -1;
            return;
        }
        if (!renaming.empty()) {
            renaming.clear();
            return;
        }
        if (!context.empty()) {
            context.clear();
            return;
        }
        if (sorting) {
            sorting = false;
            return;
        }
        if (extensionPanel) {
            extensionPanel = 0;
            return;
        }
        if (trash) {
            trash = false;
            return;
        }
        Close();
    }
    static std::u32string SearchFold(std::u32string text) {
        for (auto& c : text) {
            if (c >= U'A' && c <= U'Z')
                c += 32;
            else if (c >= U'А' && c <= U'Я')
                c += 32;
            else if (c == U'Ё')
                c = U'ё';
        }
        return text;
    }
    std::vector<std::size_t> MainSearchMatches() const {
        std::vector<std::size_t> matches;
        if (mainSearchText.empty())
            return matches;
        const auto query = SearchFold(mainSearchText);
        for (std::size_t i = 0; i < mainSearchItems.size(); ++i) {
            const auto& item = mainSearchItems[i];
            if (SearchFold(item.label).find(query) != std::u32string::npos ||
                SearchFold(item.group).find(query) != std::u32string::npos)
                matches.push_back(i);
        }
        return matches;
    }
    std::vector<MainSearchGroup> MainSearchGroups() const {
        std::vector<MainSearchGroup> groups;
        for (auto index : MainSearchMatches()) {
            const auto& title = mainSearchItems[index].group;
            auto it = std::find_if(groups.begin(), groups.end(), [&](const MainSearchGroup& group) {
                return group.title == title;
            });
            if (it == groups.end()) {
                if (groups.size() == 6)
                    continue;
                groups.push_back({title, {}});
                it = groups.end() - 1;
            }
            it->items.push_back(index);
        }
        return groups;
    }
    static float MainSearchValue(const Settings& cfg, const MainSearchItem& item) {
        const auto i = std::size_t(item.index);
        if (item.index < 0)
            return 0;
        switch (item.source) {
        case MainSearchSource::Rage:
            return cfg.rage.Get(item.index);
        case MainSearchSource::Players:
            return i < cfg.players.value.size() ? cfg.players.value[i] : 0;
        case MainSearchSource::WorldView:
            return i < cfg.worldView.value.size() ? cfg.worldView.value[i] : 0;
        case MainSearchSource::WorldESP:
            return i < cfg.worldESP.value.size() ? cfg.worldESP.value[i] : 0;
        case MainSearchSource::WorldHud:
            return i < cfg.worldHud.value.size() ? cfg.worldHud.value[i] : 0;
        case MainSearchSource::WorldMisc:
            return i < cfg.worldMisc.value.size() ? cfg.worldMisc.value[i] : 0;
        case MainSearchSource::Ambience:
            return item.profile >= 0 && std::size_t(item.profile) < cfg.worldAmbience.profiles.size() &&
                           i < cfg.worldAmbience.profiles[std::size_t(item.profile)].value.size()
                       ? cfg.worldAmbience.profiles[std::size_t(item.profile)].value[i] : 0;
        default:
            return 0;
        }
    }
    static void MainSearchSet(Settings& cfg, const MainSearchItem& item, float value) {
        if (!item.enabled || item.index < 0)
            return;
        const auto i = std::size_t(item.index);
        switch (item.source) {
        case MainSearchSource::Rage:
            cfg.rage.Set(item.index, value);
            break;
        case MainSearchSource::Players:
            cfg.players.Set(i, value);
            break;
        case MainSearchSource::WorldView:
            cfg.worldView.Set(i, value);
            break;
        case MainSearchSource::WorldESP:
            cfg.worldESP.Set(i, value);
            break;
        case MainSearchSource::WorldHud:
            cfg.worldHud.Set(i, value);
            break;
        case MainSearchSource::WorldMisc:
            cfg.worldMisc.Set(i, value);
            break;
        case MainSearchSource::Ambience:
            if (item.profile >= 0 && std::size_t(item.profile) < cfg.worldAmbience.profiles.size())
                cfg.worldAmbience.profiles[std::size_t(item.profile)].Set(i, value);
            break;
        default:
            break;
        }
    }
    static Color MainSearchColor(const Settings& cfg, const MainSearchItem& item, int offset = 0) {
        const int slot = item.colorSlot + offset;
        if (slot < 0 || offset < 0 || offset >= item.colorCount)
            return {1, 1, 1, 1};
        const auto n = std::size_t(slot);
        switch (item.source) {
        case MainSearchSource::Rage:
            return n < cfg.rage.colors.size() ? cfg.rage.colors[n] : Color{1, 1, 1, 1};
        case MainSearchSource::Players:
            return n < cfg.players.colors.size() ? cfg.players.colors[n] : Color{1, 1, 1, 1};
        case MainSearchSource::WorldESP:
            return n < cfg.worldESP.colors.size() ? cfg.worldESP.colors[n] : Color{1, 1, 1, 1};
        case MainSearchSource::WorldMisc:
            return n < cfg.worldMisc.colors.size() ? cfg.worldMisc.colors[n] : Color{1, 1, 1, 1};
        case MainSearchSource::Ambience:
            return item.profile >= 0 && std::size_t(item.profile) < cfg.worldAmbience.profiles.size() &&
                           n < cfg.worldAmbience.profiles[std::size_t(item.profile)].colors.size()
                       ? cfg.worldAmbience.profiles[std::size_t(item.profile)].colors[n] : Color{1, 1, 1, 1};
        default:
            return {1, 1, 1, 1};
        }
    }
    static void MainSearchSetColor(Settings& cfg, const MainSearchItem& item, int offset, Color value) {
        const int slot = item.colorSlot + offset;
        if (!item.enabled || slot < 0 || offset < 0 || offset >= item.colorCount)
            return;
        const auto n = std::size_t(slot);
        switch (item.source) {
        case MainSearchSource::Rage:
            if (n < cfg.rage.colors.size())
                cfg.rage.colors[n] = value;
            break;
        case MainSearchSource::Players:
            if (n < cfg.players.colors.size())
                cfg.players.colors[n] = value;
            break;
        case MainSearchSource::WorldESP:
            if (n < cfg.worldESP.colors.size())
                cfg.worldESP.SetColor(n, value);
            break;
        case MainSearchSource::WorldMisc:
            if (n < cfg.worldMisc.colors.size())
                cfg.worldMisc.colors[n] = value;
            break;
        case MainSearchSource::Ambience:
            if (item.profile >= 0 && std::size_t(item.profile) < cfg.worldAmbience.profiles.size())
                cfg.worldAmbience.profiles[std::size_t(item.profile)].SetColor(n, value);
            break;
        default:
            break;
        }
    }
    static void MainSearchToggle(Settings& cfg, const MainSearchItem& item) {
        if (!item.check || !item.enabled)
            return;
        const bool on = MainSearchValue(cfg, item) == 0;
        MainSearchSet(cfg, item, on ? 1.f : 0.f);
        if (on && item.source == MainSearchSource::Ambience && item.profile >= 0 &&
            std::size_t(item.profile) < cfg.worldAmbience.profiles.size()) {
            auto& values = cfg.worldAmbience.profiles[std::size_t(item.profile)];
            const auto counterpart = [&](const char* first, const char* second) {
                if (item.index == AmbienceIndex(first)) {
                    int other = AmbienceIndex(second);
                    if (other >= 0)
                        values.Set(std::size_t(other), 0.f);
                }
            };
            counterpart("weather_rain", "weather_snow");
            counterpart("weather_snow", "weather_rain");
            counterpart("ground_snow_pom", "ground_snow_pom_40");
            counterpart("ground_snow_pom_40", "ground_snow_pom");
        }
    }
    void MainSearchSlide(Settings& cfg, float x) {
        if (mainSearchDrag < 0 || std::size_t(mainSearchDrag) >= mainSearchItems.size())
            return;
        const auto& item = mainSearchItems[std::size_t(mainSearchDrag)];
        if (!item.numeric || mainSearchDragTrack.w <= 0)
            return;
        float fraction = std::clamp((x - mainSearchDragTrack.x) / mainSearchDragTrack.w, 0.f, 1.f);
        MainSearchSet(cfg, item, item.minimum + (item.maximum - item.minimum) * fraction);
    }
    std::vector<std::string> Visible(bool deleted = false, bool filter = true) const {
        std::vector<std::string> ids;
        auto fold = [](std::u32string s) {
            for (auto& cp : s) {
                if (cp >= U'A' && cp <= U'Z')
                    cp += 32;
                else if (cp >= U'А' && cp <= U'Я')
                    cp += 32;
                else if (cp == U'Ё')
                    cp = U'ё';
            }
            return s;
        };
        auto needle = fold(search);
        for (auto& p : store.items)
            if (bool(p.deleted) == deleted && (deleted || !filter || needle.empty() ||
                                               fold(DecodeUTF8(p.name)).find(needle) != std::u32string::npos))
                ids.push_back(p.id);
        std::stable_sort(ids.begin(), ids.end(), [&](const std::string& a, const std::string& b) {
            auto x = store.Find(a), y = store.Find(b);
            if (deleted)
                return x->deleted > y->deleted;
            if (store.sort == 2) {
                auto xx = fold(DecodeUTF8(x->name)), yy = fold(DecodeUTF8(y->name));
                return xx == yy ? a < b : xx < yy;
            }
            auto xx = store.sort == 1 ? x->modified : x->created,
                 yy = store.sort == 1 ? y->modified : y->created;
            return xx == yy ? a < b : xx > yy;
        });
        return ids;
    }

    bool TooltipAllowed() const {
        if (sorting || !context.empty() || !renaming.empty() || hovered < 0 || hovered >= int(hits.size()))
            return false;
        int a = hits[hovered].action;
        if (mainSearch) {
            int index = hits[hovered].index;
            return mainSearchDrag < 0 && (a == 34 || a == 35 || a == 36) && index >= 0 &&
                   std::size_t(index) < mainSearchItems.size() &&
                   !mainSearchItems[std::size_t(index)].description.empty();
        }
        if (a == 30)
            return !open;
        if (a == 1 || a == 2) {
            auto p = Active();
            return !open && p && !p->deleted;
        }
        if (!open)
            return false;
        if (trash && a != 18 && a != 19 && a != 24)
            return false;
        return a == 2 || a == 4 || a == 5 || a == 6 || a == 10 || a == 12 || a == 13 || a == 18 || a == 19 ||
               a == 20 || a == 21 || a == 24 || a == 25;
    }
    void Tick(float dt, const Settings& cfg) {
        dt = std::max(0.f, dt);
        hoverSeconds += dt;
        caretSeconds += dt;
        noticeSeconds = std::max(0.f, noticeSeconds - dt);
        SyncMotion();
        mainSearchOpacity.Tick(mainSearch ? 1.f : 0.f, dt);
        mainSearchHeight.Tick(mainSearch || mainSearchOpacity.value > 0.f ? mainSearchHeightTarget : 0.f, dt);
        if (mainSearch)
            for (const auto& item : mainSearchItems)
                if (item.check && item.index >= 0)
                    mainSearchChecks[{item.source, item.index}].Tick(
                        MainSearchValue(cfg, item) != 0 ? 1.f : 0.f, dt);

        for (auto& kv : savedFade) {
            auto& remaining = saved[kv.first];
            bool fullyShown = kv.second.value >= 1;
            kv.second.Tick(remaining > 0 ? 1.f : 0.f, dt);
            if (remaining > 0 && fullyShown)
                remaining = std::max(0.f, remaining - dt);
        }
        for (auto& kv : tweens)
            kv.second.Tick(kv.first == heldKey ? 1.f : kv.first == hoverKey ? .5f : 0.f, dt);

        bool defaultShown = open && page == 1, defaultHeld = defaultShown && heldKey == "extension-0",
             defaultHover = defaultShown && hoverKey == "extension-0",
             defaultPopup = defaultShown && extensionPanel == 1;
        defaultButtonFill.Tick(defaultHeld ? 1.f : (defaultHover || defaultPopup) ? .5f : 0.f, dt);
        defaultButtonInk.Tick(defaultHeld || defaultPopup ? 1.f : defaultHover ? .5f : 0.f, dt);
        for (const auto& e : defaultExtensions) {
            auto& m = defaultRowMotion[e.id];
            std::string k = "prebuilt-" + e.id;
            float hover =
                open && page == 1 && extensionPanel == 1 && hoverKey == k ? (heldKey == k ? 1.f : .5f) : 0.f;
            m.fill.Tick(hover, dt);
            m.text.Tick(e.active ? 1.f : hover, dt);
        }
        for (int i = 0; i < 2; ++i) {
            tabExpand[i].Tick(page == i ? 1.f : 0.f, dt);
            tabFill[i].Tick(heldKey == "tab" + std::to_string(i)    ? 1.f
                            : hoverKey == "tab" + std::to_string(i) ? .75f
                                                                    : (page == i ? .5f : 0.f),
                            dt);
        }
        tooltipFade.Tick(TooltipAllowed() && hoverSeconds >= .3f ? 1.f : 0.f, dt);
        scrollFill.Tick(listScroll.dragging ? 1.f : hoverKey == "list-scroll" ? .8f : 0.f, dt);
        trashScrollFill.Tick(trashView.dragging ? 1.f : hoverKey == "trash-scroll" ? .8f : 0.f, dt);
        selectorFill.Tick(open || heldKey == "selector" ? 1.f : hoverKey == "selector" ? .5f : 0.f, dt);
        pageBlend.Tick(1, dt);
        searchTween.Tick(searchFocus ? 1.f : hoverKey == "search" ? .5f : 0.f, dt);
        auto matches = Visible();
        for (const auto& p : store.items)
            if (!p.deleted) {
                bool selected = p.id == store.selected, hoveredRow = p.id == hoverRow,
                     heldRow = heldKey == "row-" + p.id || heldKey == "rename-" + p.id;
                rowBorder[p.id].Tick(selected ? 1.f : hoveredRow ? .5f : 0.f, dt);
                rowFill[p.id].Tick(heldRow ? 1.f : (selected || hoveredRow) ? .5f : 0.f, dt);
                rowVisibility[p.id].Tick(
                    std::find(matches.begin(), matches.end(), p.id) != matches.end() ? 1.f : 0.f, dt);
            }
        if (changes.Observe(cfg)) {
            dirtySeconds = .75f;
        } else if (dirtySeconds > 0) {
            dirtySeconds -= dt;
            if (dirtySeconds <= 0 && store.automatic && Active()) {
                try {
                    store.Save(store.selected, cfg);
                } catch (const std::exception& e) {
                    Notify(e.what());
                }
            }
        }
        purgeSeconds += dt;
        if (purgeSeconds >= 3600) {
            purgeSeconds = 0;
            try {
                store.Purge(PresetNow());
            } catch (const std::exception& e) {
                Notify(e.what());
            }
        }
    }
    int Hit(float x, float y) const {
        for (int i = int(hits.size()) - 1; i >= 0; --i)
            if (hits[i].box.Contains(x, y))
                return i;
        return -1;
    }
    void Move(float x, float y, Settings* cfg = nullptr) {
        if (cfg && mainSearch && mainSearchDrag >= 0 && x >= 0 && y >= 0)
            MainSearchSlide(*cfg, x);
        mouseX = x;
        mouseY = y;
        if (listScroll.dragging && y >= 0) {
            listScroll.Drag(y);
            scroll = listScroll.offset;
        }
        if (trashView.dragging && y >= 0) {
            trashView.Drag(y);
            trashScroll = trashView.offset;
        }
        if (Editing() &&
            (heldKey == "search" || heldKey == "main-search-input" || heldKey == "rename-" + renaming)) {
            PrepareEditor();
            editor.Mouse(x - editorBox.x, true);
            renameSelectAll = false;
        }
        int h = Hit(x, y);
        std::string key = h >= 0 ? hits[h].key : "";
        if (key != hoverKey) {
            hoverSeconds = 0;
        }
        hovered = h;
        hoverKey = key;
        hoverRow.clear();
        if (h >= 0) {
            tweens.try_emplace(key);
            if (key.rfind("row-", 0) == 0 || key.rfind("rename-", 0) == 0 || key.rfind("more-", 0) == 0 ||
                key.rfind("save-", 0) == 0 || key.rfind("load-", 0) == 0)
                hoverRow = hits[h].id;
        }
    }
    void Wheel(float delta) {
        if (!open)
            return;
        if (mainSearch) {
            mainSearchChoice = -1;
            if (mainSearchDetail >= 0 && mainSearchDetailBox.Contains(mouseX, mouseY)) {
                mainSearchDetailOffset = std::clamp(mainSearchDetailOffset - delta * 2 * (fontHeight + 14 * uiScale),
                                                    0.f, mainSearchDetailMaximum);
                return;
            }
            mainSearchDetail = -1;
            mainSearchOffset = std::clamp(mainSearchOffset - delta * 2 * (fontHeight + 14 * uiScale),
                                          0.f, mainSearchMaximum);
            return;
        }
        if (trash)
            trashScroll =
                std::clamp(trashScroll - delta * 2 * (fontHeight + 14 * uiScale), 0.f, trashView.maximum);
        else
            scroll = std::clamp(scroll - delta * 2 * (fontHeight + 24.6f * uiScale), 0.f, listScroll.maximum);
        context.clear();
    }
    void StartRename(const std::string& id) {
        auto p = store.Find(id);
        if (!p || p->deleted)
            return;
        renaming = id;
        renameText = DecodeUTF8(p->name);
        renameSelectAll = true;
        searchFocus = false;
        context.clear();
        editorKey.clear();
        PrepareEditor();
    }
    void Character(char32_t cp) {
        if (!Editing())
            return;
        PrepareEditor();
        auto& out = EditText();
        if (cp == 8)
            editor.Delete(out, true);
        else
            editor.Insert(out, std::u32string(1, cp), mainSearch ? 128 : renaming.empty() ? 64 : 128);
        renameSelectAll = false;
        scroll = 0;
        if (mainSearch)
            mainSearchOffset = 0;
        caretSeconds = 0;
    }
    void UTF16(char16_t cp) {
        if (cp >= 0xd800 && cp <= 0xdbff) {
            highSurrogate = cp;
            return;
        }
        if (cp >= 0xdc00 && cp <= 0xdfff) {
            if (highSurrogate)
                Character(char32_t(0x10000 + ((highSurrogate - 0xd800) << 10) + (cp - 0xdc00)));
            highSurrogate = 0;
            return;
        }
        highSurrogate = 0;
        Character(cp);
    }
    void Enter() {
        if (mainSearch)
            return;
        try {
            if (!renaming.empty()) {
                store.Rename(renaming, renameText);
                renaming.clear();
            } else
                searchFocus = false;
        } catch (const std::exception& e) {
            Notify(e.what());
        }
    }
    void Import(const std::string& code) {
        try {
            auto id = store.Import(code);
            search.clear();
            scroll = 0;
            StartRename(id);
            Notify("Imported local preset");
        } catch (const std::exception& e) {
            Notify(e.what());
        }
    }
    void Activate(const PresetHit& hit, Settings& cfg) {
        try {
            switch (hit.action) {
            case 0:
                if (!mainSearch)
                    searchFocus = false;
                break;
            case 30:
                if (!mainSearchOpacity.initialized)
                    mainSearchOpacity.Snap(0.f);
                mainSearchOpacity.Tick(1.f, 0.f);
                open = mainSearch = searchFocus = true;
                trash = sorting = false;
                context.clear();
                renaming.clear();
                mainSearchText.clear();
                mainSearchOffset = 0;
                mainSearchMaximum = mainSearchHeightTarget = 0;
                mainSearchHeight.Snap(0);
                editorKey.clear();
                PrepareEditor();
                break;
            case 31:
                searchFocus = true;
                PrepareEditor();
                break;
            case 32:
                Close();
                break;
            case 33:
                if (hit.index >= 0 && std::size_t(hit.index) < mainSearchItems.size()) {
                    mainSearchTarget = mainSearchItems[std::size_t(hit.index)].target;
                    Close();
                }
                break;
            case 41:
                if (hit.index >= 0 && std::size_t(hit.index) < mainSearchItems.size() &&
                    !mainSearchItems[std::size_t(hit.index)].detailGroup.empty()) {
                    if (mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::Rage ||
                         mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::Ambience ||
                         mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::WorldMisc) {
                        mainSearchNativeRequest = hit.index;
                        mainSearchNativeAction = 41;
                        mainSearchNativeAnchor = hit.box;
                        mainSearchChoice = mainSearchDetail = -1;
                        break;
                    }
                    mainSearchDetail = mainSearchDetail == hit.index ? -1 : hit.index;
                    mainSearchDetailAnchor = hit.box;
                    mainSearchDetailOffset = 0;
                    mainSearchChoice = -1;
                }
                break;
            case 39:
                if (hit.index >= 0 && std::size_t(hit.index) < mainSearchItems.size() &&
                    mainSearchItems[std::size_t(hit.index)].enabled) {
                    if (mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::Players ||
                         mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::Rage ||
                         mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::Ambience ||
                         mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::WorldESP ||
                         mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::WorldMisc) {
                        mainSearchNativeRequest = hit.index;
                        mainSearchNativeAction = 39;
                        mainSearchNativeAnchor = hit.box;
                        mainSearchChoice = mainSearchDetail = -1;
                        break;
                    }
                    mainSearchColorRequest = hit.index;
                    mainSearchColorAnchor = hit.box;
                    mainSearchChoice = -1;
                }
                break;
            case 37:
                if (hit.index >= 0 && std::size_t(hit.index) < mainSearchItems.size() &&
                    mainSearchItems[std::size_t(hit.index)].enabled) {
                    if (mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::Rage ||
                        mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::Players ||
                        mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::Ambience ||
                        mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::WorldESP ||
                        mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::WorldMisc ||
                        mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::WorldHud ||
                        mainSearchItems[std::size_t(hit.index)].source == MainSearchSource::WorldView) {
                        mainSearchNativeRequest = hit.index;
                        mainSearchNativeAction = 37;
                        mainSearchNativeAnchor = hit.box;
                        mainSearchChoice = mainSearchDetail = -1;
                        break;
                    }
                    mainSearchChoice = mainSearchChoice == hit.index ? -1 : hit.index;
                    mainSearchChoiceAnchor = hit.box;
                }
                break;
            case 38:
                if (hit.index >= 0 && std::size_t(hit.index) < mainSearchItems.size()) {
                    const auto& item = mainSearchItems[std::size_t(hit.index)];
                    const int option = std::atoi(hit.id.c_str());
                    if (option >= 0 && std::size_t(option) < item.options.size()) {
                        const int old = int(MainSearchValue(cfg, item));
                        MainSearchSet(cfg, item, item.multi ? float(old ^ (1 << option)) : float(option));
                        if (!item.multi)
                            mainSearchChoice = -1;
                    }
                }
                break;
            case 34:
                if (hit.index >= 0 && std::size_t(hit.index) < mainSearchItems.size())
                    MainSearchToggle(cfg, mainSearchItems[std::size_t(hit.index)]);
                break;
            case 1:
                open = !open;
                trash = sorting = false;
                context.clear();
                renaming.clear();
                searchFocus = false;
                break;
            case 2:
                if (Active()) {
                    store.Save(store.selected, cfg);
                    saved[store.selected] = 2.5f;
                } else
                    store.Create(cfg);
                break;
            case 3:
                page = hit.index;
                searchFocus = false;
                renaming.clear();
                listScroll.Stop();
                trashView.Stop();
                extensionPanel = 0;
                trash = sorting = false;
                context.clear();
                break;
            case 4:
                store.Change([&] { store.automatic = !store.automatic; });
                break;
            case 5:
                trashAnchor = {mouseX + 1, mouseY + 1, 0, 0};
                trashPosition = mouseX >= 0 && mouseY >= 0;
                trash = !trash;
                sorting = false;
                context.clear();
                trashScroll = 0;
                break;
            case 6: {
                search.clear();
                auto id = store.Create(cfg, EncodeUTF8(Label("menu_presets_unnamed")));
                StartRename(id);
                scroll = 0;
                break;
            }
            case 7:
                FocusSearch();
                context.clear();
                sorting = trash = false;
                caretSeconds = 0;
                break;
            case 8:
                sortAnchor = {mouseX + 1, mouseY + 1, 0, 0};
                sortPosition = mouseX >= 0 && mouseY >= 0;
                sorting = !sorting;
                trash = false;
                context.clear();
                break;
            case 9:
                store.Change([&] { store.sort = hit.index; });
                sorting = false;
                break;
            case 10:
                store.LoadPreset(hit.id, cfg);
                changes.Observe(cfg);
                dirtySeconds = 0;
                searchFocus = false;
                renaming.clear();
                break;
            case 11:
                contextAnchor = {mouseX + 1, mouseY + 1, 0, 0};
                contextPosition = mouseX >= 0 && mouseY >= 0;
                context = context == hit.id ? "" : hit.id;
                trash = sorting = false;
                renaming.clear();
                searchFocus = false;
                break;
            case 12:
                store.Save(hit.id, cfg);
                saved[hit.id] = 2.5f;
                break;
            case 13:
                store.LoadPreset(hit.id, cfg);
                changes.Observe(cfg);
                dirtySeconds = 0;
                context.clear();
                break;
            case 14:
                clipboardOut = store.Share(hit.id, false);
                Notify("Local preset code copied");
                context.clear();
                break;
            case 15:
                clipboardOut = store.Share(hit.id, true);
                Notify("Local one-time code copied");
                context.clear();
                break;
            case 16:
                store.Duplicate(hit.id);
                context.clear();
                break;
            case 17:
                store.Remove(hit.id);
                context.clear();
                break;
            case 18:
                store.Restore(hit.id);
                break;
            case 19:
                store.Erase(hit.id);
                break;
            case 20:
                if (renaming != hit.id)
                    StartRename(hit.id);
                break;

            case 21:
                if (hit.index == 1) {
                    extensionPanel = 0;
                    apiDocsRequested = true;
                } else {
                    extensionPanel = extensionPanel == hit.index + 1 ? 0 : hit.index + 1;
                    if (hit.index == 0 && extensionPanel == 1) {
                        defaultAnchor = {mouseX + 1, mouseY + 1, 0, 0};
                        defaultPosition = mouseX >= 0 && mouseY >= 0;
                    }
                }
                break;

            case 25:
                if (open && page == 1 && extensionPanel == 1) {
                    for (auto& e : defaultExtensions)
                        if (e.id == hit.id && !e.external && e.prebuilt) {
                            e.active = !e.active;
                            break;
                        }
                }
                break;
            default:
                searchFocus = false;
                break;
            }
        } catch (const std::exception& e) {
            Notify(e.what());
        }
    }
    bool Click(float x, float y, bool down, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        int h = Hit(x, y);
        if (down) {
            if (mainSearch && mainSearchChoice >= 0 && (h < 0 || hits[h].layer != mainSearchChoiceLayer) &&
                (h < 0 || hits[h].action != 37 || hits[h].index != mainSearchChoice)) {
                mainSearchChoice = -1;
                held = -1;
                heldKey.clear();
                return true;
            }
            if (mainSearch && mainSearchDetail >= 0 && (h < 0 || hits[h].layer < 2) &&
                (h < 0 || hits[h].action != 41 || hits[h].index != mainSearchDetail)) {
                mainSearchDetail = -1;
                held = -1;
                heldKey.clear();
                return true;
            }
            if (mainSearch && (h < 0 || hits[h].layer == 0)) {
                Close();
                return true;
            }
            if (h >= 0 && (sorting || trash || !context.empty() || extensionPanel) && hits[h].layer < 2 &&
                !(hits[h].action == 21 && hits[h].index == 1)) {
                sorting = trash = false;
                context.clear();
                extensionPanel = 0;
                held = -1;
                heldKey.clear();
                return true;
            }
            held = h;
            heldKey = h >= 0 ? hits[h].key : "";
            if (h >= 0 && hits[h].action == 35) {
                mainSearchDrag = hits[h].index;
                mainSearchDragTrack = hits[h].box;
                MainSearchSlide(cfg, x);
                return true;
            }
            if (h >= 0 && hits[h].action == 23) {
                trashView.Press(y);
                trashScroll = trashView.offset;
                return true;
            }
            if (h >= 0 && hits[h].action == 22) {
                listScroll.Press(y);
                scroll = listScroll.offset;
                return true;
            }
            if (h >= 0 && Editing() &&
                (hits[h].action == 7 || hits[h].action == 31 || hits[h].key == "rename-" + renaming)) {
                if (hits[h].action == 7 && !renaming.empty())
                    FocusSearch();
                PrepareEditor();
                editor.Mouse(x - editorBox.x, false);
                renameSelectAll = false;
                caretSeconds = 0;
            }
            if (h < 0 && open) {
                if (extensionPanel == 1) {
                    extensionPanel = 0;
                    held = -1;
                    heldKey.clear();
                    return true;
                }
                Close();
                return true;
            }
            return h >= 0;
        }
        if (mainSearchDrag >= 0) {
            MainSearchSlide(cfg, x);
            mainSearchDrag = -1;
            held = -1;
            heldKey.clear();
            return true;
        }
        if (listScroll.dragging || trashView.dragging) {
            listScroll.Stop();
            trashView.Stop();
            held = -1;
            heldKey.clear();
            return true;
        }
        bool consumed = h >= 0 || !heldKey.empty();
        if (h >= 0 && hits[h].key == heldKey) {
            auto hit = hits[h];
            Activate(hit, cfg);
        }
        held = -1;
        heldKey.clear();
        return consumed;
    }
    void Measure(Fonts& fonts, const Settings& cfg, const Layout& layout, int width, int height) {

        if (trash && Visible(true).empty()) {
            trash = false;
            trashView.Stop();
            trashScroll = 0;
        }
        SyncMotion();
        MeasurePage(fonts, cfg, layout, width, height);

        if (!open || mainSearch || previousPage == page || pageBlend.value >= 1)
            return;
        auto current = std::move(layers);
        auto currentHits = std::move(hits);
        auto currentPopup = popup;
        auto currentList = listClip;
        auto currentSearch = searchBox;
        auto currentRename = renameBox;
        auto currentBody = bodyStart;
        int currentPage = page;
        float oldScroll = scroll;
        page = previousPage;
        MeasurePage(fonts, cfg, layout, width, height);
        auto old = std::move(layers);
        auto oldBody = bodyStart;
        page = currentPage;
        scroll = oldScroll;
        if (current.size() < 2 || old.size() < 2) {
            layers = std::move(current);
            hits = std::move(currentHits);
            return;
        }
        auto oldPopup = old[1].box;
        float t = pageBlend.value;
        Box bounds = currentPopup;
        bounds.h = std::max(currentPopup.h, oldPopup.h);
        bounds.y =
            std::clamp(selector.y + selector.h + 5 * cfg.scale, 0.f, std::max(0.f, float(height) - bounds.h));
        auto shiftDraw = [](PresetDraw& d, float x, float y) {
            d.box.x += x;
            d.box.y += y;
            if (d.clipped) {
                d.clip.x += x;
                d.clip.y += y;
            }
        };
        float dx = bounds.x - currentPopup.x, dy = bounds.y - currentPopup.y;
        layers.clear();
        layers.push_back(std::move(current[0]));
        PresetLayer surface = std::move(current[1]);
        surface.box = bounds;
        auto nowDraw = surface.draw;
        surface.draw.resize(currentBody);
        for (auto& d : surface.draw)
            shiftDraw(d, dx, dy);
        surface.draw[0].box = surface.draw[1].box = bounds;
        layers.push_back(std::move(surface));
        auto appendBody = [&](const std::vector<PresetDraw>& draw, std::size_t start, float alpha, float x,
                              float y) {
            PresetLayer body{bounds, 0, false, {}};
            for (std::size_t i = start; i < draw.size(); ++i) {
                auto d = draw[i];
                shiftDraw(d, x, y);
                d.color.a *= alpha;
                d.clip = d.clipped ? PresetIntersect(d.clip, bounds) : bounds;
                d.clipped = true;
                body.draw.push_back(std::move(d));
            }
            layers.push_back(std::move(body));
        };
        appendBody(old[1].draw, oldBody, 1 - t, bounds.x - oldPopup.x, bounds.y - oldPopup.y);
        appendBody(nowDraw, currentBody, t, dx, dy);

        hits = std::move(currentHits);
        for (auto& h : hits)
            if (h.layer == 1) {
                h.box.x += dx;
                h.box.y += dy;
                if (h.key == "popup-surface")
                    h.box = bounds;
                else
                    h.box = PresetIntersect(h.box, bounds);
            }
        for (auto& h : hits) {
            if (h.layer >= 2)
                h.layer += 2;
            else if (h.layer == 1 && h.key != "popup-surface" && h.key != "tab0" && h.key != "tab1")
                h.layer = 3;
        }
        for (std::size_t i = 2; i < current.size(); ++i) {
            auto layer = std::move(current[i]);
            layer.box.x += dx;
            layer.box.y += dy;
            for (auto& d : layer.draw)
                shiftDraw(d, dx, dy);
            layers.push_back(std::move(layer));
        }
        popup = bounds;
        listClip = currentList;
        listClip.x += dx;
        listClip.y += dy;
        searchBox = currentSearch;
        searchBox.x += dx;
        searchBox.y += dy;
        renameBox = currentRename;
        renameBox.x += dx;
        renameBox.y += dy;
        bodyStart = currentBody;
    }
    void MeasurePage(Fonts& fonts, const Settings& cfg, const Layout& layout, int width, int height) {
        uiScale = cfg.scale;
        anchor = layout;
        viewportW = width;
        viewportH = height;
        fontHeight = fonts.PixelHeight(1, 13 * cfg.scale);
        layers.clear();
        hits.clear();
        float s = cfg.scale, F = fontHeight;
        PresetMetrics metrics(s, F, true);
        float H = metrics.controlH, rowH = metrics.rowH;
        searchBox = renameBox = {};
        auto pal = CurrentPalette(cfg);
        auto alpha = [](Color c, float a) {
            c.a *= a;
            return c;
        };
        auto tw = [&](const std::u32string& t) { return fonts.NativeTextSize(1, 13 * s, t).w; };
        auto iw = [&](char32_t cp) { return fonts.NativeTextSize(3, 13 * s, std::u32string(1, cp)).w; };
        auto layer = [&](Box b, float radius, bool isPopup) {
            layers.push_back({b, radius, isPopup, {}});
            return int(layers.size()) - 1;
        };
        auto rect = [&](int l, Box b, Color c, float r = 0, float stroke = 0, unsigned corners = 15) {
            layers[l].draw.push_back({b, c, r, stroke, corners, {}, false});
        };
        auto txt = [&](int l, Box b, const std::u32string& t, Color c) {
            layers[l].draw.push_back({b, c, 0, 0, 15, t, false});
        };
        auto icon = [&](int l, Box b, char32_t cp, Color c) {
            float iw = fonts.NativeTextSize(3, 13 * s, std::u32string(1, cp)).w;
            b.x += (b.w - iw) * .5f;
            b.y += (b.h - F) * .5f;
            b.w = iw;
            b.h = F;
            layers[l].draw.push_back({b, c, 0, 0, 15, std::u32string(1, cp), true});
        };
        auto hit = [&](int l, Box b, int action, const std::string& id, int i, const std::string& key) {
            hits.push_back({b, l, action, i, id, key});
            tweens.try_emplace(key);
        };
        auto button = [&](int l, Box b, char32_t cp, int action, const std::string& id, int i,
                          const std::string& key, bool selected = false, bool disabled = false) {
            float v = tweens[key].value;
            if (selected || v > 0)
                rect(l, b, alpha(pal[33], selected ? .4f : v * .4f), 6 * s);
            icon(l, b, cp, disabled ? alpha(pal[0], .3f) : Mix(pal[0], pal[2], v));
            if (!disabled)
                hit(l, b, action, id, i, key);
        };
        auto surface = [&](Box b, float radius, const std::string& key) {
            int l = layer(b, radius, true);
            rect(l, b, pal[8], radius);
            rect(l, b, pal[11], radius, s);
            hit(l, b, 0, "", 0, key);
            return l;
        };
        auto editDraw = [&](int l, Box view, const std::u32string& value, Color col) {
            PrepareEditor();
            editor.Measure(fonts, 13 * s, value, view.w, renaming.empty());
            editorBox = view;
            auto push = [&](PresetDraw d) {
                d.clipped = true;
                d.clip = view;
                layers[l].draw.push_back(std::move(d));
            };
            if (editor.Selected()) {
                float a = editor.advance[editor.Begin()] - editor.scroll,
                      b = editor.advance[editor.End()] - editor.scroll;
                push({{view.x + a, view.y, b - a, F}, pal[37], 0, 0, 15, {}, false});
            }
            auto run = view;
            run.x -= editor.scroll;
            run.w = std::max(view.w + editor.scroll, tw(value));
            if (!value.empty()) {
                push({run, col, 0, 0, 15, value, false});
            }
            if (std::fmod(caretSeconds, 1.2f) < .8f) {
                float cx = view.x + editor.advance[editor.cursor] - editor.scroll;
                push({{cx, view.y, 1, F}, pal[0], 0, 0, 15, {}, false});
            }
        };
        auto constrain = [&](Box b) { return PresetPopupFit(b, width, height); };

        const float headerH = F + 12 * s;
        const float childH = std::trunc(layout.headerHeight - s + .49999997f);
        const float childOrigin = std::floor(s);
        const float childX = layout.content.x + childOrigin, childY = layout.content.y + childOrigin;
        const float centeredY =
            std::trunc((childH - headerH) * .5f + std::copysign(.49999997f, childH - headerH));

        headerLine = {layout.content.x + 11 * s, childY + childH, layout.content.w - 22 * s, s};
        int base =
            layer({layout.content.x, layout.content.y, layout.content.w, headerLine.y - layout.content.y + s},
                  0, false);
        headerSave = {childX + 10 * s, childY + centeredY, 35 * s, headerH};
        const Box headerSearch{layout.content.x + layout.content.w - 45 * s, headerSave.y, 35 * s, headerH};
        const auto active = Active();
        auto name = active ? DecodeUTF8(active->name) : Label("menu_presets_unnamed");
        float selectorW =
            std::min(std::max(0.f, layout.content.w - 91 * s),
                     std::min(230 * s, std::trunc(tw(name) + .95f) + std::trunc(iw(0xf107) + .95f) + 36 * s));
        selector = {headerSave.x + headerSave.w, headerSave.y, selectorW, headerH};

        rect(base, headerSave, alpha(pal[13], tweens["header-save"].value), metrics.frameRadius, 0, 5);
        float selectorState = selectorFill.initialized ? selectorFill.value : (open ? 1.f : 0.f);
        rect(base, selector, alpha(pal[33], .2f * selectorState), metrics.frameRadius, 0, 10);
        rect(base, {headerSave.x, headerSave.y, headerSave.w + selector.w, headerH}, pal[11],
             metrics.frameRadius, s);

        headerDivider = {headerSave.x + headerSave.w, headerSave.y, s, headerH};
        rect(base, headerDivider, pal[11]);
        rect(base, headerLine, pal[34]);
        layers[base].draw.back().pixelLine = true;
        layers[base].draw.back().uniformSeparator = true;
        float check = active ? savedFade[active->id].value : 0;
        button(base, headerSearch, 0xf002, 30, "", 0, "main-search");
        icon(base, headerSave, 0xf0c7, alpha(pal[0], 1 - check));
        if (check > 0)
            icon(base, headerSave, 0xf00c, alpha(pal[2], check));
        txt(base, {selector.x + 12 * s, selector.y + 6 * s, selector.w - 44 * s, F}, name, pal[0]);
        icon(base, {selector.x + selector.w - 30 * s, selector.y, 24 * s, headerH}, 0xf107, pal[0]);
        hit(base, headerSave, 2, "", 0, "header-save");
        hit(base, selector, 1, "", 0, "selector");
        if (mainSearch || (!open && mainSearchOpacity.value > 0.f)) {
            const auto groups = MainSearchGroups();
            const float row = F + 6 * s;
            const float pitch = GroupRowPitch(F, s);
            const float heading = fonts.PixelHeight(0, 10 * s);
            const auto searchMetrics = dump_menu::search_metrics(s, F, metrics.frameX, metrics.frameY);
            const float inputPaddingX = searchMetrics.paddingX;
            const float inputH = searchMetrics.inputHeight;
            float contentH = groups.empty() ? 0.f : 20 * s;
            for (const auto& group : groups)
                contentH += heading + 5 * s + GroupCardHeight(int(group.items.size()), F, s) + 15 * s;
            if (!groups.empty())
                contentH -= 15 * s;
            mainSearchHeightTarget = std::min(contentH, 450 * s);
            const float animatedH = std::max(0.f, mainSearchHeight.value);
            const bool resultsVisible = !groups.empty() || animatedH > 0;
            const float resultsH = resultsVisible ? std::max(F, animatedH) : 0.f;
            const float separatorH = resultsVisible ? s : 0.f;
            float pw = std::max(0.f, dump_menu::search_width(layout.content.w - 2 * childOrigin,
                                                            searchMetrics.inset));
            popup = constrain({childX + searchMetrics.inset, headerSave.y - metrics.frameY * .5f,
                               pw, inputH + separatorH + resultsH});
            int l = surface(popup, 10 * s, "main-search-surface");
            layers[l].searchSurface = true;
            layers[l].opacity = std::clamp(mainSearchOpacity.value, 0.f, 1.f);
            layers[l].draw.front().color.a = .95f;
            Box field{popup.x, popup.y, std::max(0.f, popup.w - inputPaddingX - 30 * s), inputH};
            Box close{popup.x + popup.w - inputPaddingX * .5f - 30 * s,
                      popup.y + (inputH - 30 * s) * .5f, 30 * s, 30 * s};
            searchBox = field;
            float magnifier = iw(0xf002);
            icon(l, {field.x + inputPaddingX, field.y, magnifier, inputH}, 0xf002, pal[1]);
            float textX = field.x + 2 * inputPaddingX + std::trunc(magnifier + .95f);
            Box text{textX, field.y + (inputH - F) * .5f,
                     std::max(0.f, field.w - (textX - field.x) - inputPaddingX), F};
            if (searchFocus)
                editDraw(l, text, mainSearchText, pal[0]);
            if (!searchFocus || mainSearchText.empty())
                txt(l, text, mainSearchText.empty() ? Label("menu_search") : mainSearchText,
                    mainSearchText.empty() ? pal[1] : pal[0]);
            hit(l, field, 31, "", 0, "main-search-input");
            button(l, close, 0xf00d, 32, "", 0, "main-search-close");
            if (resultsVisible) {
                rect(l, {popup.x, popup.y + inputH, popup.w, separatorH}, pal[34]);
                layers[l].draw.back().pixelLine = true;
                layers[l].draw.back().uniformSeparator = true;
            }
            Box clip{popup.x, popup.y + inputH + separatorH, popup.w,
                     std::max(0.f, popup.h - inputH - separatorH)};
            mainSearchMaximum = std::max(0.f, contentH - clip.h);
            mainSearchOffset = std::clamp(mainSearchOffset, 0.f, mainSearchMaximum);
            float x = popup.x + 10 * s, y = clip.y + 10 * s - mainSearchOffset;
            float inner = std::max(0.f, popup.w - 20 * s);
            auto drawSearchRow = [&](int l, Box b, std::size_t index, std::size_t rowIndex, std::size_t totalRows) {
                const auto& item = mainSearchItems[index];
                std::string key = "main-search-result-" + std::to_string(index);
                float motion = item.enabled ? tweens[key].value : 0.f;
                if (!item.description.empty())
                    hit(l, b, 36, "", int(index), key);
                rect(l, GroupRowHoverBounds(b, s), alpha(pal[33], .15f * motion), 15 * s);
                layers[l].draw.back().corners = GroupRowCorners(int(rowIndex), int(totalRows));
                float controlLeft = b.x + b.w;
                if (item.check) {
                    float h = F + 2 * s, center = b.y + b.h * .5f;
                    float frac = center - std::trunc(center);
                    Box control{b.x + b.w - 32 * s, center - h * .5f + frac, 32 * s, h - 2 * frac};
                    controlLeft = control.x;
                    float value = MainSearchValue(cfg, item) != 0 ? 1.f : 0.f;
                    auto& check = mainSearchChecks[{item.source, item.index}];
                    if (!check.initialized)
                        check.Snap(value);
                    float active = check.value;
                    float opacity = item.enabled ? 1.f : .5f;
                    rect(l, control, alpha(pal[22], opacity), h * .5f);
                    if (active > 0)
                        rect(l, control, alpha(pal[23], opacity * active), h * .5f);
                    float radius = std::max(0.f, h * .5f - 2 * s);
                    float cx = control.x + h * .5f + (control.w - h) * active;
                    rect(l, {cx - radius, center - radius, 2 * radius, 2 * radius},
                         alpha(Mix(pal[20], pal[21], active), item.enabled ? 1.f : .5f), radius);
                    if (item.enabled)
                        hit(l, GroupRowHoverBounds(b, s), 34, "", int(index), key);
                } else if (item.numeric) {
                    float value = MainSearchValue(cfg, item);
                    float fraction = item.maximum > item.minimum
                                         ? std::clamp((value - item.minimum) / (item.maximum - item.minimum),
                                                      0.f, 1.f)
                                         : 0.f;
                    float right = b.x + b.w;
                    std::string valueText = std::to_string(value);
                    while (!valueText.empty() && valueText.back() == '0')
                        valueText.pop_back();
                    if (!valueText.empty() && valueText.back() == '.')
                        valueText.pop_back();
                    auto display = item.display.empty() ? DecodeUTF8(valueText) : item.display;
                    float numberW =
                        std::min(std::max(24 * s, tw(display) + 12 * s), b.w * .42f);
                    float totalW = std::min(b.w * .68f, std::trunc(b.w / 2.2f) + 12 * s);
                    float sliderW = std::max(1.f, totalW - numberW - 12 * s);
                    Box track{right - numberW - 12 * s - sliderW, b.y + (row - 4 * s) * .5f,
                              sliderW, 4 * s};
                    controlLeft = track.x;
                    rect(l, track, pal[24], 2 * s);
                    rect(l, {track.x, track.y, track.w * fraction, track.h}, pal[25], 2 * s);
                    float radius = std::max(0.f, F * .5f - 3 * s);
                    float cx = track.x + track.w * fraction;
                    rect(l, {cx - radius, b.y + row * .5f - radius, 2 * radius, 2 * radius},
                         pal[26], radius);
                    Box valueBox{right - numberW, b.y + (row - F - 6 * s) * .5f, numberW, F + 6 * s};
                    rect(l, valueBox, pal[12], 6 * s);
                    rect(l, valueBox, pal[11], 6 * s, s);
                    txt(l, {valueBox.x + 6 * s, valueBox.y + 3 * s, valueBox.w - 12 * s, F},
                        display, item.enabled ? pal[14] : alpha(pal[14], .5f));
                    if (item.enabled && track.w > 0)
                        hit(l, {track.x, b.y, track.w, b.h}, 35, "", int(index), key);
                }
                if (!item.options.empty()) {
                    const int value = int(MainSearchValue(cfg, item));
                    std::u32string selected;
                    for (std::size_t n = 0; n < item.options.size(); ++n)
                        if (item.multi ? (value & (1 << n)) != 0 : value == int(n)) {
                            if (!selected.empty()) selected += U", ";
                            selected += item.options[n];
                        }
                    if (selected.empty()) selected = Label("menu_select");
                    float choiceWidth = std::min(std::trunc(b.w / 2.2f) + 12 * s, b.w * .5f);
                    Box control{b.x + b.w - choiceWidth, b.y + (row - F - 6 * s) * .5f, choiceWidth, F + 6 * s};
                    controlLeft = control.x;
                    rect(l, control, pal[12], 6 * s);
                    rect(l, control, pal[11], 6 * s, s);
                    Box textBox{control.x + 6 * s, control.y + 3 * s, std::max(0.f, control.w - 27 * s), F};
                    txt(l, textBox, selected, item.enabled ? pal[14] : alpha(pal[14], .5f));
                    layers[l].draw.back().clipped = true;
                    layers[l].draw.back().clip = textBox;
                    icon(l, {control.x + control.w - 22 * s, control.y, 20 * s, control.h}, 0xf107,
                         item.enabled ? pal[0] : alpha(pal[0], .5f));
                    if (item.enabled)
                        hit(l, control, 37, "", int(index), key + "-choice");
                }
                const bool hasDetail = !item.detailGroup.empty();
                const bool hasControl = item.check || item.numeric || !item.options.empty();
                const bool hasMore = hasDetail && hasControl;
                const float detailLeft = hasMore ? std::max(b.x, controlLeft - 29 * s) : controlLeft;
                float swatchLeft = -1.f;
                if (item.colorSlot >= 0 && item.colorCount > 0) {
                    const float left = std::max(b.x, (hasMore ? detailLeft : controlLeft) - 22 * s);
                    swatchLeft = left;
                    Box swatch{left, b.y + (row - 16 * s) * .5f, 16 * s, 16 * s};
                    auto first = MainSearchColor(cfg, item);
                    auto last = MainSearchColor(cfg, item, item.colorCount - 1);
                    Box rasterBox{std::floor(swatch.x) - 1, std::floor(swatch.y) - 1,
                                  std::ceil(swatch.x + swatch.w) - std::floor(swatch.x) + 2,
                                  std::ceil(swatch.y + swatch.h) - std::floor(swatch.y) + 2};
                    auto image = std::make_shared<Canvas>(int(rasterBox.w), int(rasterBox.h));
                    const bool gradient = item.colorCount > 1;
                    DrawPickerPreview(*image, {swatch.x - rasterBox.x, swatch.y - rasterBox.y, swatch.w, swatch.h},
                                      s, row, first, last, gradient, false);
                    PresetDraw preview{rasterBox, {1, 1, 1, item.enabled ? 1.f : .5f}};
                    preview.raster = image;
                    preview.rasterStamp = PickerPreviewStamp(first, last, gradient, false);
                    layers[l].draw.push_back(std::move(preview));
                    if (item.enabled)
                        hit(l, swatch, 39, "", int(index), key + "-color");
                }
                if (hasDetail) {
                    if (hasMore) {
                        Box detail{detailLeft, b.y, 22 * s, row};
                        const std::string detailKey = key + "-detail";
                        float hover = item.enabled ? tweens[detailKey].value : 0.f;
                        rect(l, detail, alpha(pal[33], .4f * hover), 15 * s / 1.6f);
                        icon(l, detail, 0xf141,
                             item.enabled ? Mix(pal[0], pal[2], motion) : alpha(pal[0], .5f));
                        if (item.enabled)
                            hit(l, detail, 41, "", int(index), detailKey);
                    } else {
                        Box detail{std::max(b.x, controlLeft - 24 * s),
                                   b.y + (row - 24 * s) * .5f, 24 * s, 24 * s};
                        button(l, detail, 0xf105, 41, "", int(index), key + "-detail",
                               mainSearchDetail == int(index), !item.enabled);
                    }
                }
                float labelRight = b.x + b.w - (hasMore ? detailLeft - 4 * s : controlLeft) +
                                   (hasDetail && !hasMore ? 24 * s : 0.f);
                Box labelBox{b.x, b.y + (row - F) * .5f,
                             std::max(0.f, b.w - labelRight), F};
                if (swatchLeft >= 0)
                    labelBox.w = std::min(labelBox.w, std::max(0.f, swatchLeft - b.x - 6 * s));
                txt(l, labelBox, item.label,
                    item.enabled ? Mix(pal[0], pal[2], motion) : alpha(pal[0], .5f));
                layers[l].draw.back().clip = labelBox;
                layers[l].draw.back().clipped = true;
            };
            const auto drawStart = layers[l].draw.size();
            const auto hitStart = hits.size();
            for (const auto& group : groups) {
                Box titleClip{x + 14 * s, y, std::max(0.f, inner - 28 * s), heading};
                auto title = group.title;
                for (auto& c : title) {
                    if (c >= U'a' && c <= U'z')
                        c -= 32;
                    else if (c >= U'а' && c <= U'я')
                        c -= 32;
                    else if (c == U'ё')
                        c = U'Ё';
                }
                float titleX = titleClip.x;
                std::size_t from = 0;
                while (from < title.size()) {
                    auto end = title.find(U"  ", from);
                    auto part = title.substr(from, end == std::u32string::npos ? end : end - from);
                    float partW = fonts.NativeTextSize(0, 10 * s, part).w;
                    txt(l, {titleX, y, partW, heading}, part, pal[3]);
                    auto& text = layers[l].draw.back();
                    text.font = 0;
                    text.textSize = 10;
                    text.clipped = true;
                    text.clip = titleClip;
                    titleX += partW;
                    if (end == std::u32string::npos)
                        break;
                    float arrowW = fonts.NativeTextSize(3, 10 * s, U"\uf105").w;
                    titleX += 4 * s;
                    layers[l].draw.push_back(
                        {{titleX, y, arrowW, heading}, pal[3], 0, 0, 15, U"\uf105", true});
                    auto& arrow = layers[l].draw.back();
                    arrow.textSize = 10;
                    arrow.clipped = true;
                    arrow.clip = titleClip;
                    titleX += arrowW + 4 * s;
                    from = end + 2;
                }
                float linkSize = 20 * s;
                Box link{std::min(titleX + 4 * s, titleClip.x + std::max(0.f, titleClip.w - linkSize)),
                         y + (heading - linkSize) * .5f, std::min(linkSize, titleClip.w), linkSize};
                const std::string linkKey = "main-search-group-" + std::to_string(group.items.front());
                float linkHover = tweens[linkKey].value;
                if (linkHover > 0)
                    rect(l, link, alpha(pal[33], .4f * linkHover), 6 * s);
                icon(l, link, 0xf0c1, Mix(pal[3], pal[2], linkHover));
                hit(l, link, 33, "", int(group.items.front()), linkKey);
                y += heading + 5 * s;
                Box card{x, y, inner, GroupCardHeight(int(group.items.size()), F, s)};
                rect(l, card, pal[40], 15 * s);
                rect(l, card, pal[11], 15 * s, s);
                y += 7 * s;
                std::size_t rowIndex = 0;
                for (const auto index : group.items) {
                    Box b{x + 14 * s, y, std::max(0.f, inner - 28 * s), row};
                    if (rowIndex) {
                        rect(l, GroupRowSeparator(b, s), pal[34]);
                        layers[l].draw.back().pixelLine = true;
                    }
                    drawSearchRow(l, b, index, rowIndex, group.items.size());
                    y += pitch;
                    ++rowIndex;
                }
                y = card.y + card.h + 15 * s;
            }
            if (mainSearchMaximum > 0 && clip.h > 0) {
                float thumbH = std::max(10 * s, clip.h * clip.h / (clip.h + mainSearchMaximum));
                float thumbY = clip.y + (clip.h - thumbH) * mainSearchOffset / mainSearchMaximum;
                rect(l, {clip.x + clip.w - 3 * s, thumbY, 3 * s, thumbH}, pal[18], 2 * s);
            }
            for (std::size_t i = drawStart; i < layers[l].draw.size(); ++i) {
                auto& draw = layers[l].draw[i];
                draw.clip = draw.clipped ? PresetIntersect(draw.clip, clip) : clip;
                draw.clipped = true;
            }
            for (std::size_t i = hitStart; i < hits.size(); ++i)
                hits[i].box = PresetIntersect(hits[i].box, clip);
            if (mainSearch && mainSearchDetail >= 0 && std::size_t(mainSearchDetail) < mainSearchItems.size()) {
                const auto& parent = mainSearchItems[std::size_t(mainSearchDetail)];
                std::vector<std::size_t> children;
                for (std::size_t i = 0; i < mainSearchItems.size(); ++i)
                    if (mainSearchItems[i].source == parent.source && mainSearchItems[i].group == parent.detailGroup)
                        children.push_back(i);
                if (!children.empty()) {
                    const float w = std::min(310 * s, float(width) - 12 * s);
                    const float full = 14 * s + float(children.size()) * pitch;
                    const float h = std::min(full, 355 * s);
                    Box b{mainSearchDetailAnchor.x + mainSearchDetailAnchor.w + 7 * s, mainSearchDetailAnchor.y, w, h};
                    if (b.x + b.w > width - 6 * s)
                        b.x = mainSearchDetailAnchor.x - w - 7 * s;
                    b = constrain(b);
                    mainSearchDetailBox = b;
                    mainSearchDetailMaximum = std::max(0.f, full - h);
                    mainSearchDetailOffset = std::clamp(mainSearchDetailOffset, 0.f, mainSearchDetailMaximum);
                    int dl = surface(b, 10 * s, "main-search-detail-surface");
                    layers[dl].opacity = layers[l].opacity;
                    const auto firstDraw = layers[dl].draw.size();
                    const auto firstHit = hits.size();
                    Box bounds{b.x + 7 * s, b.y + 7 * s, b.w - 14 * s, b.h - 14 * s};
                    for (std::size_t n = 0; n < children.size(); ++n) {
                        Box rowBox{b.x + 12 * s, b.y + 7 * s + float(n) * pitch - mainSearchDetailOffset,
                                   b.w - 24 * s, row};
                        if (n) {
                            rect(dl, GroupRowSeparator(rowBox, s), pal[34]);
                            layers[dl].draw.back().pixelLine = true;
                        }
                        drawSearchRow(dl, rowBox, children[n], n, children.size());
                    }
                    for (std::size_t i = firstDraw; i < layers[dl].draw.size(); ++i) {
                        auto& d = layers[dl].draw[i];
                        d.clip = d.clipped ? PresetIntersect(d.clip, bounds) : bounds;
                        d.clipped = true;
                    }
                    for (std::size_t i = firstHit; i < hits.size(); ++i)
                        hits[i].box = PresetIntersect(hits[i].box, bounds);
                    for (auto& d : layers[dl].draw)
                        d.color.a *= layers[dl].opacity;
                }
            }
            if (mainSearch && mainSearchChoice >= 0 && std::size_t(mainSearchChoice) < mainSearchItems.size()) {
                const auto& selected = mainSearchItems[std::size_t(mainSearchChoice)];
                if (!selected.options.empty()) {
                    float w = 140 * s;
                    for (const auto& option : selected.options)
                        w = std::max(w, tw(option) + 60 * s);
                    w = std::min(w, float(width) - 12 * s);
                    const float optionH = F + 14 * s;
                    const float h = optionH * float(selected.options.size()) + 14 * s;
                    Box cb = constrain({mainSearchChoiceAnchor.x + (mainSearchChoiceAnchor.w - w) * .5f,
                                        mainSearchChoiceAnchor.y + (mainSearchChoiceAnchor.h - h) * .5f, w, h});
                    int cl = surface(cb, 10 * s, "main-search-choice-surface");
                    mainSearchChoiceLayer = cl;
                    layers[cl].opacity = layers[l].opacity;
                    int value = int(MainSearchValue(cfg, selected));
                    for (std::size_t n = 0; n < selected.options.size(); ++n) {
                        Box b{cb.x + 7 * s, cb.y + 7 * s + float(n) * optionH, cb.w - 14 * s, optionH};
                        bool active = selected.multi ? (value & (1 << n)) != 0 : value == int(n);
                        std::string key = "main-search-choice-option-" + std::to_string(n);
                        rect(cl, b, alpha(pal[33], .4f * tweens[key].value), 9 * s);
                        if (active)
                            icon(cl, {b.x + 8 * s, b.y, 18 * s, b.h}, 0xf00c, pal[0]);
                        txt(cl, {b.x + 32 * s, b.y + 7 * s, std::max(0.f, b.w - 40 * s), F},
                            selected.options[n], active ? pal[2] : pal[14]);
                        hit(cl, b, 38, std::to_string(n), mainSearchChoice, key);
                    }
                    for (auto& draw : layers[cl].draw)
                        draw.color.a *= layers[cl].opacity;
                }
            }
            for (auto& draw : layers[l].draw)
                draw.color.a *= layers[l].opacity;
            if (!mainSearch)
                hits.erase(std::remove_if(hits.begin(), hits.end(), [l](const PresetHit& h) { return h.layer == l; }),
                           hits.end());
        } else if (open) {
            float pw = std::min(310 * s, float(width) - 12 * s),
                  ph = H + 40 * s +
                       std::min(300 * s, std::max(0.f, float(Visible().size()) * (rowH + 5 * s) - 5 * s)) +
                       28 * s;
            if (page == 1)
                ph = H + 90 * s;
            popup = constrain({selector.x, selector.y + selector.h + 5 * s, pw, ph});
            int l = surface(popup, metrics.frameRadius, "popup-surface");
            float x = popup.x + 7 * s, y = popup.y + 7 * s, inner = popup.w - 14 * s;
            float tabW0 = metrics.TabWidth(tw(Label("menu_presets")), tabExpand[0].value);
            Box tab1{x, y, tabW0, H};
            auto tab = [&](Box b, const char* key, char32_t cp, int idx) {
                auto c = page == idx ? pal[31] : pal[0];
                float expansion = tabExpand[idx].value;
                rect(l, b, alpha(pal[33], .4f * tabFill[idx].value), 1.3f * metrics.frameRadius);
                icon(l, {b.x + metrics.frameX, b.y, 17 * s, H}, cp, c);
                if (expansion > 0) {
                    auto start = layers[l].draw.size();
                    txt(l,
                        {b.x + metrics.frameX + metrics.TabLabelOffset(), b.y + metrics.frameY,
                         std::max(0.f, b.w - metrics.frameX - metrics.TabLabelOffset()), F},
                        Label(key), alpha(c, expansion));
                    for (std::size_t i = start; i < layers[l].draw.size(); ++i) {
                        layers[l].draw[i].clipped = true;
                        layers[l].draw[i].clip = b;
                    }
                }
                hit(l, b, 3, "", idx, "tab" + std::to_string(idx));
            };
            tab(tab1, "menu_presets", 0xf0c2, 0);
            bodyStart = layers[l].draw.size();
            if (page == 0) {
                Box autoB{x + inner - 3 * H, y, H, H}, trashB{x + inner - 2 * H, y, H, H},
                    createB{x + inner - H, y, H, H};
                button(l, autoB, 0xe590, 4, "", 0, "automatic", store.automatic);
                if (store.automatic)
                    icon(l, autoB, 0xe590, pal[31]);
                button(l, trashB, 0xe2b0, 5, "", 0, "trash", trash, Visible(true).empty());
                button(l, createB, 0x2b, 6, "", 0, "create");

                y += H + 5 * s;
                rect(l, {x, y, inner, s}, pal[34]);
                y += 6 * s;
                Box searchB{x, y, inner - H - 5 * s, H}, sortB{x + inner - H, y, H, H};
                searchBox = searchB;
                float field = searchTween.initialized ? searchTween.value : (searchFocus ? 1.f : 0.f);
                rect(l, searchB, Mix(pal[12], pal[13], field), metrics.frameRadius);
                rect(l, searchB, pal[11], metrics.frameRadius, s);
                float magnifier = iw(0xf002);
                icon(l, {searchB.x + metrics.frameX, searchB.y, magnifier, H}, 0xf002, pal[1]);
                float searchX = searchB.x + 2 * metrics.frameX + magnifier;
                Box searchText{searchX, searchB.y + metrics.frameY,
                               std::max(0.f, searchB.w - (searchX - searchB.x) - metrics.frameX), F};
                if (searchFocus)
                    editDraw(l, searchText, search, pal[0]);
                if (!searchFocus || search.empty())
                    txt(l, searchText, search.empty() ? Label("menu_search") : search,
                        search.empty() ? pal[1] : pal[0]);
                hit(l, searchB, 7, "", 0, "search");
                button(l, sortB, 0xf884, 8, "", 0, "sort", sorting);

                y += H + 5 * s;
                rect(l, {x, y, inner, s}, pal[34]);
                y += 6 * s;
                auto ids = AnimatedVisible();
                float animatedHeight = 0;
                for (auto& id : ids)
                    animatedHeight += (rowH + 5 * s) * rowVisibility[id].value;
                float listH = std::min(300 * s, std::max(0.f, animatedHeight - 5 * s));
                listClip = {x, y, inner, listH};

                popup.h = y - popup.y + listH + 7 * s;
                popup = constrain(popup);
                float shiftY = popup.y - layers[l].box.y;
                if (shiftY != 0) {
                    for (auto& d : layers[l].draw)
                        d.box.y += shiftY;
                    for (auto& h : hits)
                        if (h.layer == l)
                            h.box.y += shiftY;
                    y += shiftY;
                    listClip.y += shiftY;
                    sortB.y += shiftY;
                    trashB.y += shiftY;
                    searchBox.y += shiftY;
                }
                layers[l].box = popup;
                layers[l].draw[0].box = popup;
                layers[l].draw[1].box = popup;
                for (auto& h : hits)
                    if (h.key == "popup-surface")
                        h.box = popup;
                float totalH = std::max(0.f, animatedHeight - 5 * s);
                if (totalH > listH) {
                    listClip.w = std::max(0.f, inner - 10 * s);
                }
                listScroll.offset = scroll;
                listScroll.Layout(listClip, totalH, s);
                scroll = listScroll.offset;
                float maxOffset = listScroll.maximum, offset = scroll;
                float rowY = y - offset;
                for (std::size_t i = 0; i < ids.size(); ++i) {
                    auto id = ids[i];
                    float visibility = rowVisibility[id].value, ry = rowY;
                    rowY += (rowH + 5 * s) * visibility;
                    if (ry >= listClip.y + listClip.h)
                        break;
                    if (visibility <= 0 || ry + rowH < listClip.y)
                        continue;
                    auto drawStart = layers[l].draw.size(), hitStart = hits.size();
                    auto p = store.Find(id);
                    Box row{x, ry, listClip.w, rowH};
                    float border = rowBorder[id].value, fill = rowFill[id].value;
                    rect(l, row, pal[40], metrics.rowRadius);
                    rect(l, row, alpha(pal[33], .2f * fill), metrics.rowRadius);
                    rect(l, row, Mix(pal[11], alpha(pal[31], .4f), border), metrics.rowRadius, s);
                    hit(l, row, 10, id, 0, "row-" + id);

                    float bw = F + 2 * metrics.frameY, bh = F + metrics.frameY;
                    Box actionB{x + listClip.w - metrics.rowX - bw, ry + (rowH - bh) * .5f, bw, bh},
                        moreB{actionB.x - bw, actionB.y, bw, bh};
                    Box nameB{x + metrics.rowX, ry + metrics.rowY,
                              std::max(0.f, moreB.x - (x + metrics.rowX) - 8 * s), F};
                    auto text = renaming == id ? renameText : DecodeUTF8(p->name);
                    Box input = nameB;
                    input.w = std::min(nameB.w, tw(text) + 2 * s);
                    if (renaming == id) {
                        renameBox = input;
                        editDraw(l, input, text, Mix(pal[14], pal[2], border));
                    }

                    else
                        txt(l, input, text, Mix(pal[14], pal[2], border));
                    if (store.selected == id)
                        hit(l, input, 20, id, 0, "rename-" + id);
                    button(l, moreB, 0xf141, 11, id, 0, "more-" + id, context == id);
                    bool selected = store.selected == id;
                    button(l, actionB, selected ? 0xf0c7 : 0xf0ed, selected ? 12 : 13, id, 0,
                           (selected ? "save-" : "load-") + id);
                    if (selected && savedFade[id].value > 0) {
                        layers[l].draw.back().color.a *= 1 - savedFade[id].value;
                        icon(l, actionB, 0xf00c, alpha(pal[2], savedFade[id].value));
                    }
                    Box animatedClip =
                        PresetIntersect(listClip, {row.x, row.y, row.w, (rowH + 5 * s) * visibility});

                    for (std::size_t j = drawStart; j < layers[l].draw.size(); ++j) {
                        auto& draw = layers[l].draw[j];
                        draw.color.a *= visibility;
                        draw.clipped = true;
                        draw.clip = draw.clip.w > 0 ? PresetIntersect(draw.clip, listClip)
                                                    : (draw.text.empty() ? PresetAAClip(listClip) : listClip);
                    }
                    if (rowVisibility[id].target == 0)
                        hits.resize(hitStart);
                    else
                        for (std::size_t j = hitStart; j < hits.size(); ++j)
                            hits[j].box = PresetIntersect(hits[j].box, animatedClip);
                }
                if (maxOffset > 0) {
                    rect(l, listScroll.track, pal[17], 3 * s);
                    rect(l, listScroll.thumb, Mix(pal[18], pal[19], scrollFill.value), 3 * s);
                    hit(l, listScroll.track, 22, "", 0, "list-scroll");
                }

                if (sorting) {
                    auto opts = std::array<const char*, 3>{{"menu_presets_sort_newest",
                                                            "menu_presets_sort_recently_modified",
                                                            "menu_presets_sort_recently_alphabetical"}};
                    float menuW = 0;
                    for (auto k : opts)
                        menuW = std::max(menuW, tw(Label(k)));
                    menuW += 38 * s;
                    Box b = constrain({sortPosition ? sortAnchor.x : sortB.x,
                                       sortPosition ? sortAnchor.y : sortB.y + H + 5 * s, menuW,
                                       3 * (F + 14 * s) + 14 * s});
                    int sl = surface(b, metrics.frameRadius, "sort-surface");
                    for (int i = 0; i < 3; ++i) {
                        Box r{b.x + 7 * s, b.y + 7 * s + i * (F + 14 * s), b.w - 14 * s, F + 14 * s};
                        if (tweens["sort-" + std::to_string(i)].value > 0)
                            rect(sl, r, alpha(pal[33], .4f * tweens["sort-" + std::to_string(i)].value),
                                 metrics.frameRadius);
                        std::u32string label = i == 0   ? U"Newest First"
                                               : i == 1 ? U"Recently Modified"
                                                        : U"Alphabetical";
                        auto found = DefaultLanguageStrings().find(opts[i]);
                        if (found != DefaultLanguageStrings().end())
                            label = Label(opts[i]);
                        txt(sl, {r.x + 12 * s, r.y + 7 * s, r.w - 24 * s, F}, label,
                            Mix(pal[0], pal[2], tweens["sort-" + std::to_string(i)].value));
                        hit(sl, r, 9, "", i, "sort-" + std::to_string(i));
                    }
                }
                if (trash) {
                    auto deleted = Visible(true);
                    float stride = F + 14 * s, contentH = std::max(1, int(deleted.size())) * stride;
                    float trashW = 0;
                    for (auto& id : deleted)
                        trashW = std::max(trashW, tw(DecodeUTF8(store.Find(id)->name)));
                    trashW = std::max(trashW + 2 * H + 38 * s, 80 * s);
                    bool overflow = contentH + 14 * s > height - 6;
                    if (overflow)
                        trashW += 10 * s;
                    Box b = constrain({trashPosition ? trashAnchor.x : trashB.x,
                                       trashPosition ? trashAnchor.y : trashB.y + H + 5 * s, trashW,
                                       contentH + 14 * s});
                    int tl = surface(b, metrics.frameRadius, "trash-surface");
                    Box view{b.x + 7 * s, b.y + 7 * s, std::max(0.f, b.w - 14 * s - (overflow ? 10 * s : 0)),
                             std::max(0.f, b.h - 14 * s)};
                    trashView.offset = trashScroll;
                    trashView.Layout(view, contentH, s);
                    trashScroll = trashView.offset;
                    for (int i = 0; i < int(deleted.size()); ++i) {
                        Box row{view.x, view.y + i * stride - trashScroll, view.w, stride};
                        if (row.y + row.h <= view.y || row.y >= view.y + view.h)
                            continue;
                        auto p = store.Find(deleted[i]);
                        auto d0 = layers[tl].draw.size(), h0 = hits.size();
                        Box nameArea{row.x + 6 * s, row.y + 7 * s, std::max(0.f, row.w - 2 * H - 8 * s), F};
                        txt(tl, nameArea, DecodeUTF8(p->name), pal[0]);
                        hit(tl, nameArea, 24, p->id, 0, "trash-row-" + p->id);
                        button(tl, {row.x + row.w - 2 * H, row.y, H, row.h}, 0xf2ed, 19, p->id, 0,
                               "erase-" + p->id);
                        layers[tl].draw.back().color =
                            alpha(Color{.86f, .39f, .38f, 1}, .7f + .3f * tweens["erase-" + p->id].value);
                        button(tl, {row.x + row.w - H, row.y, H, row.h}, 0xf2ea, 18, p->id, 0,
                               "restore-" + p->id);
                        for (auto j = d0; j < layers[tl].draw.size(); ++j) {
                            auto& d = layers[tl].draw[j];
                            d.clipped = true;
                            d.clip = d.text.empty() ? PresetAAClip(view) : view;
                        }
                        for (auto j = h0; j < hits.size(); ++j)
                            hits[j].box = PresetIntersect(hits[j].box, view);
                    }
                    if (trashView.maximum > 0) {
                        rect(tl, trashView.track, pal[17], 3 * s);
                        rect(tl, trashView.thumb, Mix(pal[18], pal[19], trashScrollFill.value), 3 * s);
                        hit(tl, trashView.track, 23, "", 0, "trash-scroll");
                    }
                }
                if (!context.empty()) {
                    Box parent{};
                    for (auto& h : hits)
                        if (h.key == "more-" + context)
                            parent = h.box;
                    if (parent.w == 0)
                        context.clear();
                    else {
                        float contextW = 0;
                        for (auto k :
                             {"menu_presets_reload", "menu_presets_share", "menu_presets_shareonetime",
                              "menu_presets_duplicate", "menu_presets_delete"})
                            contextW = std::max(contextW, tw(Label(k)));
                        contextW += 50 * s + std::max(iw(0xf064), iw(0xf2ed));
                        Box b = constrain({contextPosition ? contextAnchor.x : parent.x,
                                           contextPosition ? contextAnchor.y : parent.y + parent.h + 5 * s,
                                           contextW, 5 * (F + 14 * s) + 28 * s});
                        int cl = surface(b, metrics.frameRadius, "context-surface");
                        auto keys = std::array<const char*, 6>{
                            {"menu_presets_reload", "menu_presets_share", "menu_presets_shareonetime",
                             "menu_presets_duplicate", "menu_presets_delete", ""}};
                        auto cps = std::array<char32_t, 5>{{0xf2f9, 0xf064, 0xf0c1, 0xf0c5, 0xf2ed}};
                        auto actions = std::array<int, 5>{{13, 14, 15, 16, 17}};
                        float cy = b.y + 7 * s;
                        for (int i = 0; i < 5; ++i) {
                            if (i == 1 || i == 4) {
                                rect(cl, {b.x + 7 * s, cy + 3 * s, b.w - 14 * s, s}, pal[34]);
                                cy += 7 * s;
                            }
                            Box r{b.x + 7 * s, cy, b.w - 14 * s, F + 14 * s};
                            Color col = i == 4 ? Color{.86f, .39f, .38f, 1} : pal[0];
                            if (tweens["ctx-" + std::to_string(i)].value > 0)
                                rect(cl, r, alpha(pal[33], .4f * tweens["ctx-" + std::to_string(i)].value),
                                     metrics.frameRadius);
                            icon(cl, {r.x + 7 * s, r.y, 20 * s, r.h}, cps[i], col);
                            txt(cl, {r.x + 34 * s, r.y + 7 * s, r.w - 41 * s, F}, Label(keys[i]), col);
                            hit(cl, r, actions[i], context, 0, "ctx-" + std::to_string(i));
                            cy += r.h;
                        }
                        layers[cl].box.h = std::min(b.h, cy - b.y + 7 * s);
                        layers[cl].draw[0].box.h = layers[cl].box.h;
                        layers[cl].draw[1].box.h = layers[cl].box.h;
                        for (auto& h : hits)
                            if (h.key == "context-surface")
                                h.box = layers[cl].box;
                    }
                }
            } else {
                for (int i = 0; i < 3; ++i) {
                    const char32_t cps[] = {0xe5eb, 0xf7ea, 0xf54e};
                    Box b{x + inner - (3 - i) * H, y, H, H};
                    if (i == 0) {

                        rect(l, b, alpha(pal[33], .4f * defaultButtonFill.value), metrics.frameRadius);
                        Color ink = alpha(pal[30], .7f + .3f * defaultButtonInk.value);
                        float glyphW = iw(cps[i]);

                        Box glyph{std::trunc(b.x + (b.w - glyphW) * .5f), std::trunc(b.y + (b.h - F) * .5f),
                                  glyphW, F};
                        layers[l].draw.push_back({glyph, ink, 0, 0, 15, std::u32string(1, cps[i]), true});
                        hit(l, b, 21, "", i, "extension-0");
                    } else
                        button(l, b, cps[i], 21, "", i, "extension-" + std::to_string(i),
                               i != 1 && extensionPanel == i + 1);
                }
                y += H + 5 * s;
                rect(l, {x, y, inner, s}, pal[34]);
                popup.h = H + 26 * s;
                layers[l].box = popup;
                layers[l].draw[0].box = layers[l].draw[1].box = popup;
                for (auto& h : hits)
                    if (h.key == "popup-surface")
                        h.box = popup;
                if (extensionPanel == 1) {

                    float rowF = fonts.PixelHeight(0, 13 * s);
                    auto rowWidth = [&](const std::u32string& t) {
                        return fonts.NativeTextSize(0, 13 * s, t).w;
                    };
                    float contentW = 0;
                    int count = 0;
                    float reloadW = std::trunc(iw(0xf2ea) + .95f), checkW = std::trunc(iw(0xf00c) + .95f);
                    for (const auto& e : defaultExtensions)
                        if (!e.external && e.prebuilt) {
                            contentW = std::max(contentW, std::trunc(rowWidth(DefaultLabel(e.name)) + .95f) +
                                                              rowF + 2 * metrics.frameY + 36 * s + reloadW);
                            ++count;
                        }
                    float stride = rowF + 14 * s;
                    Box b = constrain({defaultPosition ? defaultAnchor.x : x + inner - 3 * H,
                                       defaultPosition ? defaultAnchor.y : y + 6 * s,
                                       std::max(14 * s, std::trunc(contentW) + 14 * s),
                                       std::trunc(count * stride) + 14 * s});
                    int el = surface(b, 15 * s, "##prebuiltlist");
                    int row = 0;

                    float inset = std::max(s, std::trunc(7 * s * .5f)), cx = std::trunc(b.x + .5f + inset),
                          cy = std::trunc(b.y + .5f + s);
                    Box clip{cx, cy, std::max(0.f, std::trunc(b.x + b.w + .5f - inset) - cx),
                             std::max(0.f, std::trunc(b.y + b.h + .5f - s) - cy)};
                    for (const auto& e : defaultExtensions)
                        if (!e.external && e.prebuilt) {
                            std::string k = "prebuilt-" + e.id;
                            Box item{b.x + 7 * s, b.y + 7 * s + row++ * stride, b.w - 14 * s, stride};
                            auto& motion = defaultRowMotion[e.id];
                            auto d0 = layers[el].draw.size();

                            if (motion.fill.value > 0)
                                rect(el, item, alpha(pal[33], .4f * motion.fill.value), std::trunc(7.5f * s));

                            if (e.active)
                                layers[el].draw.push_back(
                                    {{item.x + 12 * s, item.y + (item.h - rowF) * .5f, checkW, rowF},
                                     pal[0],
                                     0,
                                     0,
                                     15,
                                     U"\uf00c",
                                     true});
                            float labelX = item.x + 24 * s + checkW;
                            txt(el,
                                {labelX, item.y + 7 * s, std::max(0.f, item.x + item.w - 12 * s - labelX),
                                 rowF},
                                DefaultLabel(e.name), Mix(pal[14], pal[2], motion.text.value));
                            layers[el].draw.back().font = 0;
                            for (auto di = d0; di < layers[el].draw.size(); ++di) {
                                auto& d = layers[el].draw[di];
                                d.clipped = true;
                                d.clip = d.text.empty() ? PresetAAClip(clip) : clip;
                            }
                            hit(el, PresetIntersect(item, clip), 25, e.id, 0, k);
                        }
                }
                if (extensionPanel == 3) {
                    Box b = constrain({x + inner - 3 * H, y + 6 * s, inner, F + 28 * s});
                    int el = surface(b, metrics.frameRadius, "extension-local-surface");
                    txt(el, {b.x + 12 * s, b.y + 14 * s, b.w - 24 * s, F},
                        U"External service is not connected", pal[3]);
                }
            }
        }
        for (std::size_t li = 2; li < layers.size(); ++li) {
            auto& child = layers[li];
            for (std::size_t di = 2; di < child.draw.size(); ++di) {
                auto& d = child.draw[di];
                d.clip = d.clipped ? PresetIntersect(d.clip, child.box) : child.box;
                d.clipped = true;
            }
            for (auto& h : hits)
                if (h.layer == int(li))
                    h.box = PresetIntersect(h.box, child.box);
        }
        if (TooltipAllowed() && hoverSeconds >= .3f) {
            auto h = hits[hovered];
            std::u32string title, body;
            const LocalPreset* p = nullptr;
            if (mainSearch && h.index >= 0 && std::size_t(h.index) < mainSearchItems.size()) {
                const auto& item = mainSearchItems[std::size_t(h.index)];
                Box row = h.box;
                for (const auto& candidate : hits)
                    if (candidate.action == 36 && candidate.index == h.index) {
                        row = candidate.box;
                        break;
                    }
                tooltipLast = PresetDescriptionTooltip(fonts, cfg, row, item.label, item.description,
                                                           width, height);
                tooltipStored = true;
            } else {
                if (h.action == 1 || h.action == 2)
                    p = Active();
                if (h.action == 30)
                    title = Label("menu_search");
                if (h.action == 12) {
                    title = Label("menu_presets_save");
                }
                if (h.action == 18 || h.action == 19) {
                    title = Label(h.action == 18 ? "menu_presets_recentlydeleted_restore"
                                                 : "menu_presets_recentlydeleted_removepermanently");
                }
                if (h.action == 25) {
                    title = U"Prebuilt tooltip goes here...";
                }
                if (h.action == 21) {
                    title = Label(h.index == 0   ? "menu_extensions_prebuilt"
                                  : h.index == 1 ? "menu_extensions_api"
                                                 : "menu_extensions_open_market");
                }
                if (h.action == 4) {
                    title = Label("menu_presets_automaticsave");
                }
                if (h.action == 5) {
                    title = Label("menu_presets_recentlydeleted");
                    body = Label("menu_presets_recentlydeleted_tooltip");
                }
                if (h.action == 6)
                    title = Label("menu_presets_create");
                if (h.action == 13)
                    title = Label("menu_presets_load");
                if (h.action == 10 || h.action == 20 || h.action == 24)
                    p = store.Find(h.id);
                if (p) {
                    title = DecodeUTF8(p->name);
                    body = DetailsBody(*p, PresetNow());
                }
                if (p) {

                    std::array<std::u32string, 2> labels{
                        {Label("menu_presets_author") + U":",
                         Label(p->deleted ? "menu_presets_deleted" : "menu_presets_modified") + U":"}};
                    std::array<std::u32string, 2> values{
                        {DecodeUTF8(p->author),
                         RelativeTime(p->deleted ? p->deleted : p->modified, PresetNow())}};
                    float textW = tw(title);
                    for (int i = 0; i < 2; ++i)
                        textW = std::max(textW, tw(labels[i]) + 3 * s + tw(values[i]));
                    Box b = constrain(
                        {h.box.x, h.box.y + h.box.h + 7 * s, std::min(400 * s, textW + 20 * s), 3 * F + 25 * s});
                    int tl = surface(b, 8 * s, "tooltip-surface");
                    txt(tl, {b.x + 10 * s, b.y + 10 * s, std::max(0.f, b.w - 20 * s), F}, title, pal[2]);
                    for (int i = 0; i < 2; ++i) {
                        float x = b.x + 10 * s, y = b.y + 15 * s + F * (i + 1), labelW = tw(labels[i]);
                        txt(tl, {x, y, std::max(0.f, std::min(labelW, b.w - 20 * s)), F}, labels[i], pal[0]);
                        x += labelW + 3 * s;
                        txt(tl, {x, y, std::max(0.f, b.x + b.w - 10 * s - x), F}, values[i], pal[31]);
                    }
                    hits.pop_back();
                    tooltipLast = std::move(layers.back());
                    layers.pop_back();
                    tooltipStored = true;
                } else if (!title.empty()) {
                    std::vector<std::u32string> lines;
                    std::u32string line, word;
                    float maxW = 320 * s;
                    auto append = [&] {
                        if (word.empty())
                            return;
                        auto test = line + (line.empty() ? U"" : U" ") + word;
                        if (tw(test) > maxW && !line.empty()) {
                            lines.push_back(line);
                            line = word;
                        } else
                            line = test;
                        word.clear();
                    };
                    for (auto cp : body) {
                        if (cp == U' ' || cp == U'\n') {
                            append();
                            if (cp == U'\n') {
                                lines.push_back(line);
                                line.clear();
                            }
                        } else
                            word += cp;
                    }
                    append();
                    if (!line.empty())
                        lines.push_back(line);
                    float textW = tw(title);
                    for (auto& t : lines)
                        textW = std::max(textW, tw(t));
                    Box b = constrain({h.box.x, h.box.y + h.box.h + 7 * s, std::min(400 * s, textW + 20 * s),
                                       F * (1 + lines.size()) + (lines.empty() ? 20 : 25) * s});
                    int tl = surface(b, 8 * s, "tooltip-surface");
                    txt(tl, {b.x + 10 * s, b.y + 10 * s, b.w - 20 * s, F}, title,
                        h.action == 25 ? pal[0] : pal[2]);
                    if (h.action == 25)
                        layers[tl].draw.back().font = 0;
                    for (int i = 0; i < int(lines.size()); ++i)
                        txt(tl, {b.x + 10 * s, b.y + 15 * s + F * (i + 1), b.w - 20 * s, F}, lines[i], pal[14]);
                    hits.pop_back();
                    tooltipLast = std::move(layers.back());
                    layers.pop_back();
                    tooltipStored = true;
                }
            }
        }
        if (tooltipStored && tooltipFade.value > 0) {
            auto tip = tooltipLast;
            tip.opacity = tooltipFade.value;
            for (auto& d : tip.draw)
                d.color.a *= tip.opacity;
            layers.push_back(std::move(tip));
        }
        if (noticeSeconds > 0 && !notice.empty()) {
            auto text = DecodeUTF8(notice);
            float w = std::min(float(width) - 20 * s, tw(text) + 24 * s);
            Box b{(width - w) * .5f, float(height) - F - 34 * s, w, F + 20 * s};
            int n = surface(b, 8 * s, "notice-surface");
            txt(n, {b.x + 12 * s, b.y + 10 * s, w - 24 * s, F}, text, pal[2]);
            hits.pop_back();
        }
    }
};
inline void PresetDrawText(Canvas& c, Fonts& f, const Settings& cfg, const PresetLayer& layer, float dx = 0,
                           float dy = 0) {
    for (const auto& d : layer.draw)
        if (d.pixelLine) {
            if (d.uniformSeparator) {
                auto b = d.box;
                b.x += dx;
                b.y += dy;
                auto clip = d.clipped ? d.clip : layer.box;
                clip.x += dx;
                clip.y += dy;
                DrawMenuSeparator(c, b, d.color, &clip);
                continue;
            }
            Box b{std::round(d.box.x + dx), std::round(d.box.y + dy), std::round(d.box.w),
                  std::max(1.f, std::round(d.box.h))};
            Box clip = d.clipped ? d.clip : layer.box;
            clip.x += dx;
            clip.y += dy;
            for (int y = int(b.y); y < int(b.y + b.h); ++y)
                for (int x = int(b.x); x < int(b.x + b.w); ++x)
                    if (clip.Contains(x + .5f, y + .5f))
                        c.Blend(x, y, d.color);
        }
    for (const auto& d : layer.draw)
        if (d.raster) {
            Box clip = d.clipped ? PresetIntersect(d.box, d.clip) : d.box;
            const auto& r = *d.raster;
            for (int y = 0; y < r.height; ++y)
                for (int x = 0; x < r.width; ++x) {
                    float gx = d.box.x + dx + x, gy = d.box.y + dy + y;
                    if (gx + .5f < clip.x + dx || gy + .5f < clip.y + dy ||
                        gx + .5f >= clip.x + dx + clip.w || gy + .5f >= clip.y + dy + clip.h)
                        continue;
                    const auto* p = r.rgba.data() + 4 * (std::size_t(y) * r.width + x);
                    float a = p[3] / 255.f;
                    if (a > 0)
                        c.Blend(int(gx), int(gy),
                                {p[0] / 255.f / a, p[1] / 255.f / a, p[2] / 255.f / a, a * d.color.a});
                }
        }
    for (auto& d : layer.draw)
        if (!d.text.empty()) {
            Box clip = d.clipped ? (d.espText ? d.clip : PresetIntersect(d.box, d.clip)) : d.box;
            clip.x += dx;
            clip.y += dy;
            if (d.espText)
                f.NativeESPText(c, d.font, d.textSize * cfg.scale, d.text, d.box.x + dx, d.box.y + dy,
                                d.color, &clip);
            else if (d.icon)
                f.NativeMergedIcon(c, layer.nativeHUDScale > 0 ? d.textSize : d.textSize * cfg.scale,
                                   d.text[0], d.box.x + dx, d.box.y + dy, d.color, 0, 0, &clip,
                                   layer.nativeHUDScale > 0 ? d.font : d.iconDestination);
            else
                f.NativeText(c, d.font, layer.nativeHUDScale > 0 ? d.textSize : d.textSize * cfg.scale,
                             d.text, d.box.x + dx, d.box.y + dy, d.color, 0, 0, &clip);
        }
}

// CPU visual-check counterpart of the original type=3 gradient/shadow=1
// primitive. The DX11 path below uses the existing original UI DXBC, not this
// software approximation of derivative AA.
inline void PresetIndicatorLineCPU(Canvas& c, const PresetDraw& d, Box clip) {
    const auto b = d.box;
    const float pad = d.indicatorGlow * .5f + 1;
    const float radius = std::clamp(d.radius, 0.f, .5f * std::min(b.w,b.h));
    auto packed = [](float x) { return std::floor(std::clamp(x,0.f,1.f)*255.f+.5f)/255.f; };
    const Color ink{packed(d.color.r),packed(d.color.g),packed(d.color.b),packed(d.color.a)};
    const float glowAlpha = packed(d.color.a * .75f);
    for (int y=std::max(0,int(std::floor(b.y-pad))); y<std::min(c.height,int(std::ceil(b.y+b.h+pad)));++y)
        for (int x=std::max(0,int(std::floor(b.x-pad))); x<std::min(c.width,int(std::ceil(b.x+b.w+pad)));++x) {
            const float px=x+.5f, py=y+.5f;
            if (!clip.Contains(px,py)) continue;
            const float v=(py-b.y)/b.h;
            const float ramp=std::clamp(std::min((v-.1f)/.4f,(.9f-v)/.4f),0.f,1.f);
            const float distance=BoxDistance(b,radius,px,py,0);
            const float fw=std::max(.001f,std::abs(BoxDistance(b,radius,px+1,py,0)-distance)+
                                             std::abs(BoxDistance(b,radius,px,py+1,0)-distance));
            const float coverage=1-Smooth((distance+fw)/(2*fw));
            const float fade=d.indicatorGlow>0 ? 1-Smooth((distance+d.indicatorGlow*.5f)/d.indicatorGlow):0;
            const float a=ramp*(ink.a*coverage*coverage+glowAlpha*fade*(1-coverage));
            c.Blend(x,y,{ink.r,ink.g,ink.b,a});
        }
}

inline void PresetHUDMaterialCPU(Canvas& c, const Canvas* blurred, const PresetDraw& d) {
    float radius = std::clamp(d.radius, 0.f, .5f * std::min(d.box.w, d.box.h));
    if (d.shadowSize > 0)
        DrawMenuShadow(c, d.box, radius, d.shadowSize, d.shadowColor, 0);
    if (blurred && d.backdropOpacity > 0) {
        for (int y = std::max(0, int(std::floor(d.box.y - 1)));
             y < std::min(c.height, int(std::ceil(d.box.y + d.box.h + 1))); ++y)
            for (int x = std::max(0, int(std::floor(d.box.x - 1)));
                 x < std::min(c.width, int(std::ceil(d.box.x + d.box.w + 1))); ++x) {
                float a = std::clamp(.5f - BoxDistance(d.box, radius, x + .5f, y + .5f, 0), 0.f, 1.f) *
                          d.backdropOpacity;
                for (int k = 0; k < 4; ++k) {
                    auto i = 4 * (std::size_t(y) * c.width + x) + k;
                    c.rgba[i] = static_cast<unsigned char>(
                        std::clamp(c.rgba[i] + a * (float(blurred->rgba[i]) - c.rgba[i]) + .5f, 0.f, 255.f));
                }
            }
    }
    c.RoundRect(d.box, radius, d.stroke ? Color{0, 0, 0, 0} : d.color, d.color, d.stroke, 0, d.corners,
                d.clipped ? &d.clip : nullptr);
}
inline void RenderPresetsCPU(Canvas& c, Fonts& f, const Settings& cfg, const PresetsUI& ui, int pass = 0) {
    for (auto& layer : ui.layers) {
        if (!PresetLayerInPass(layer, pass))
            continue;
        std::unique_ptr<Canvas> blurred;
        if (layer.nativeHUDScale > 0) {
            if (cfg.blur) {
                blurred = std::make_unique<Canvas>(c);
                BlurMenuBackdrop(*blurred, layer.box, 0, cfg.sigma * layer.nativeHUDScale, 1, 0, 0);
            }
        } else if (layer.popup) {
            if (layer.searchSurface) {
                if (cfg.blur)
                    BlurMenuBackdrop(c, ui.anchor.outer, 16 * cfg.scale, 5 * cfg.scale, layer.opacity);
                c.RoundRect(ui.anchor.outer, 16 * cfg.scale, {0, 0, 0, .2f * layer.opacity}, {0, 0, 0, 0}, 0);
            } else if (cfg.blur)
                BlurMenuBackdrop(c, layer.box, layer.radius, 5 * cfg.scale, layer.opacity);
            if (layer.shadow) {
                auto shadow = CurrentPalette(cfg)[38];
                shadow.a *= layer.opacity;
                DrawMenuShadow(c, layer.box, layer.radius, 18 * cfg.scale, shadow);
            }
        }
        for (auto& d : layer.draw)
            if (d.nativePreviewTeam < 0 && d.text.empty() && !d.raster && !d.pixelLine) {
                if (d.indicatorLine)
                    PresetIndicatorLineCPU(c, d, d.clipped ? PresetIntersect(layer.box, d.clip) : layer.box);
                else if (layer.nativeHUDScale > 0 || d.shadowSize > 0)
                    PresetHUDMaterialCPU(c, blurred.get(), d);
                else
                    c.RoundRect(d.box, d.radius, d.stroke ? Color{0, 0, 0, 0} : d.color, d.color, d.stroke, 0,
                                d.corners, d.clipped ? &d.clip : nullptr);
            }
        PresetDrawText(c, f, cfg, layer);
    }
}
}
