#pragma once
#include "menu_core.h"
namespace menu {

inline Box PresetPopupFit(Box b, int w, int h) {
    b.w = std::min(b.w, std::max(0.f, float(w) - 6));
    b.h = std::min(b.h, std::max(0.f, float(h) - 6));
    b.x = std::trunc(std::clamp(b.x, 0.f, std::max(0.f, float(w) - b.w)));
    b.y = std::trunc(std::clamp(b.y, 0.f, std::max(0.f, float(h) - b.h)));
    return b;
}
struct PresetScrollView {
    Box viewport{}, track{}, thumb{};
    float content = 0, offset = 0, maximum = 0, grab = 0;
    bool dragging = false;
    void Layout(Box view, float total, float scale) {
        viewport = view;
        content = std::max(total, view.h);
        maximum = std::max(0.f, content - view.h);
        offset = std::clamp(offset, 0.f, maximum);
        track = {view.x + view.w + 5 * scale, view.y, 5 * scale, view.h};
        float height =
            std::clamp(track.h * view.h / std::max(1.f, content), std::min(10 * scale, track.h), track.h);
        thumb = {track.x, track.y + (track.h - height) * (maximum > 0 ? offset / maximum : 0), track.w,
                 height};
        if (maximum <= 0)
            dragging = false;
    }
    void Drag(float y) {
        if (!dragging)
            return;
        float fraction = std::clamp((y - track.y - grab) / std::max(.001f, track.h - thumb.h), 0.f, 1.f);
        offset = fraction * maximum;
        thumb.y = track.y + fraction * (track.h - thumb.h);
    }
    void Press(float y) {
        dragging = true;
        grab = thumb.Contains(thumb.x + .5f, y) ? y - thumb.y : thumb.h * .5f;
        Drag(y);
    }
    void Stop() {
        dragging = false;
    }
};
}
