#pragma once

#include "ambience_texture_codec.h"
#include <cstring>
#include <functional>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
namespace menu {
struct AmbienceCodecInfo {
    AmbienceTextureCodec codec = AmbienceTextureCodec::Unknown;
    std::string detail;
};
using AmbienceDecompress =
    std::function<bool(unsigned, const unsigned char*, std::size_t, unsigned char*, std::size_t)>;
using AmbienceReadAt = std::function<bool(std::uint64_t, void*, std::size_t)>;
namespace ambience_metadata {
inline constexpr std::size_t MaxMetadata = 4 * 1024 * 1024, MaxInflated = 8 * 1024 * 1024;
inline constexpr char Algorithm[] = "Texture Compiler Version Image YCoCg Conversion";
inline constexpr char Compiler[] = "CompileTexture";
struct Invalid : std::runtime_error {
    explicit Invalid(const char* s) : std::runtime_error(s) {}
};
inline void Require(bool b, const char* s) {
    if (!b)
        throw Invalid(s);
}
struct Span {
    const unsigned char* p = nullptr;
    std::size_t n = 0;
    Span Sub(std::size_t at, std::size_t count) const {
        Require(at <= n && count <= n - at, "metadata range outside block");
        return {p + at, count};
    }
    std::uint32_t U32(std::size_t at) const {
        auto s = Sub(at, 4);
        return std::uint32_t(s.p[0]) | (std::uint32_t(s.p[1]) << 8) | (std::uint32_t(s.p[2]) << 16) |
               (std::uint32_t(s.p[3]) << 24);
    }
    std::uint16_t U16(std::size_t at) const {
        auto s = Sub(at, 2);
        return std::uint16_t(unsigned(s.p[0]) | (unsigned(s.p[1]) << 8));
    }
};
struct Cursor {
    Span s;
    Span Take(std::size_t count) {
        auto a = s.Sub(0, count);
        s = s.Sub(count, s.n - count);
        return a;
    }
    std::uint32_t U32() {
        auto a = Take(4);
        return a.U32(0);
    }
    unsigned U16() {
        auto a = Take(2);
        return a.U16(0);
    }
    unsigned U8() {
        return *Take(1).p;
    }
    std::size_t Count(std::size_t cap = MaxInflated) {
        auto n = U32();
        Require(n <= cap, "metadata count exceeds limit");
        return n;
    }
    std::string String() {
        std::size_t count = 0;
        while (count < s.n && s.p[count] && count < 4096)
            ++count;
        Require(count < s.n && count < 4096, "unterminated/oversized metadata string");
        std::string v(reinterpret_cast<const char*>(s.p), count);
        Take(count + 1);
        return v;
    }
};
inline std::string OffsetString(Span block, std::size_t field) {
    auto rel = static_cast<std::int32_t>(block.U32(field));
    auto at = std::int64_t(field) + rel;
    Require(at >= 0 && std::uint64_t(at) < block.n, "invalid REDI relative string");
    Cursor c{block.Sub(std::size_t(at), block.n - std::size_t(at))};
    return c.String();
}
inline AmbienceCodecInfo Redi(Span block) {
    Require(block.n >= 32, "short REDI");
    const auto offset = block.U32(24), count = block.U32(28);
    Require(count <= 4096, "too many REDI dependencies");
    const std::uint64_t start = 24ull + offset;
    Require(start <= block.n && std::uint64_t(count) * 16 <= block.n - start,
            "REDI dependencies outside block");
    bool ycocg = false;
    for (std::uint32_t i = 0; i < count; ++i) {
        auto at = std::size_t(start) + i * 16;
        auto algorithm = OffsetString(block, at), compiler = OffsetString(block, at + 4);
        if (compiler == Compiler && algorithm == Algorithm)
            ycocg = true;
    }
    return {ycocg ? AmbienceTextureCodec::YCoCg : AmbienceTextureCodec::RGB, "REDI CompileTexture"};
}
struct Lanes {
    Cursor b1, b2, b4, b8;
    bool Empty() const {
        return !b1.s.n && !b2.s.n && !b4.s.n && !b8.s.n;
    }
};
inline Lanes Split(Span bytes, std::size_t& offset, std::size_t c1, std::size_t c2, std::size_t c4,
                   std::size_t c8, bool legacy) {
    Lanes lanes;
    auto lane = [&](Cursor& dst, std::size_t count, std::size_t width) {
        if (!count)
            return;
        Require(count <= MaxInflated / width, "KV3 lane too large");
        offset = (offset + width - 1) & ~(width - 1);
        dst.s = bytes.Sub(offset, count * width);
        offset += count * width;
    };
    lane(lanes.b1, c1, 1);
    lane(lanes.b2, c2, 2);
    lane(lanes.b4, c4, 4);
    lane(lanes.b8, c8, 8);
    if (!c8 && legacy) {
        offset = (offset + 7) & ~std::size_t(7);
        bytes.Sub(offset, 0);
    }
    return lanes;
}
struct Node {
    enum Kind { Other, String, Object, Array } kind = Other;
    std::string text;
    std::vector<std::pair<std::string, Node>> fields;
    std::vector<Node> items;
    const Node* Field(const std::string& key) const {
        for (const auto& f : fields)
            if (f.first == key)
                return &f.second;
        return nullptr;
    }
};
class Kv3 {
    unsigned version_ = 0;
    std::size_t nodes_ = 0;
    Cursor types_, lengths_;
    Lanes main_, aux_;
    std::vector<std::string> strings_;
    unsigned Type() {
        unsigned t = types_.U8();
        if (t & 0x80)
            types_.Take(1);
        if (version_ >= 3) {
            if (t & 0x40)
                types_.Take(1);
            t &= 0x3f;
        } else
            t &= 0x7f;
        return t;
    }
    std::string Text() {
        auto id = static_cast<std::int32_t>(main_.b4.U32());
        if (id == -1)
            return {};
        Require(id >= 0 && std::size_t(id) < strings_.size(), "invalid KV3 string id");
        return strings_[std::size_t(id)];
    }
    Node Value(unsigned type, Lanes& lane, unsigned depth) {
        Require(depth <= 32 && ++nodes_ <= 65536, "KV3 nesting/node limit");
        Node n;
        switch (type) {
        case 1:
        case 13:
        case 14:
        case 15:
        case 16:
        case 17:
        case 18:
        case 26:
        case 27:
            return n;
        case 2:
        case 22:
        case 23:
            lane.b1.Take(1);
            return n;
        case 20:
        case 21:
            lane.b2.Take(2);
            return n;
        case 11:
        case 12:
        case 19:
            lane.b4.Take(4);
            return n;
        case 3:
        case 4:
        case 5:
            lane.b8.Take(8);
            return n;
        case 6:
            n.kind = Node::String;
            n.text = Text();
            return n;
        case 7: {
            Require(version_ == 1, "KV3 binary blobs unsupported in edit-info");
            main_.b1.Take(main_.b4.Count());
            return n;
        }
        case 9: {
            n.kind = Node::Object;
            auto count = (version_ >= 5 ? lengths_ : main_.b4).Count(4096);
            n.fields.reserve(count);
            for (std::size_t i = 0; i < count; ++i) {
                auto child = Type();
                auto name = Text();
                Require(!name.empty() && !n.Field(name), "invalid/duplicate KV3 member");
                n.fields.emplace_back(std::move(name), Value(child, main_, depth + 1));
            }
            return n;
        }
        case 8:
        case 10:
        case 24:
        case 25: {
            n.kind = Node::Array;
            auto count = (type == 24 || type == 25) ? main_.b1.U8() : main_.b4.Count(32768);
            Require(count <= 32768, "KV3 array limit");
            n.items.reserve(count);
            if (type == 8) {
                for (std::size_t i = 0; i < count; ++i)
                    n.items.push_back(Value(Type(), main_, depth + 1));
            } else {
                Require(count || version_ == 1, "empty typed KV3 array");
                const auto child = Type();
                auto& src = type == 25 && version_ >= 5 ? aux_ : main_;
                for (std::size_t i = 0; i < count; ++i)
                    n.items.push_back(Value(child, src, depth + 1));
            }
            return n;
        }
        default:
            throw Invalid("unsupported KV3 node type");
        }
    }
    static std::vector<unsigned char> Inflate(Cursor& input, unsigned method, std::size_t plain,
                                              std::size_t compressed, const AmbienceDecompress& decompress) {
        Require(plain && plain <= MaxInflated && compressed <= MaxMetadata, "KV3 buffer size limit");
        std::vector<unsigned char> out(plain);
        auto bytes = input.Take(method ? compressed : plain);
        if (!method)
            std::memcpy(out.data(), bytes.p, plain);
        else
            Require(bool(decompress) && decompress(method, bytes.p, bytes.n, out.data(), out.size()),
                    "KV3 decompressor unavailable/failed");
        return out;
    }
    void Strings(Cursor& bytes, std::size_t count) {
        Require(count <= 65536, "KV3 string count limit");
        strings_.reserve(count);
        for (std::size_t i = 0; i < count; ++i)
            strings_.push_back(bytes.String());
    }

public:
    Node Read(Span block, const AmbienceDecompress& decompress) {
        Cursor c{block};
        auto magic = c.U32();
        version_ = magic & 0xff;
        Require((magic & 0xffffff00) == 0x4b563300 && version_ >= 1 && version_ <= 5,
                "unsupported RED2 KV3 version");
        c.Take(16);
        auto method = c.U32();
        Require(method <= 2 && (version_ >= 2 || method != 2), "unsupported KV3 compression");
        std::size_t c1 = 0, c2 = 0, c4 = 0, c8 = 0, countTypes = 0, total = 0, compressed = 0, blocks = 0,
                    blobs = 0, blockSizes = 0;
        if (version_ == 1) {
            c1 = c.Count();
            c4 = c.Count();
            c8 = c.Count();
            total = c.Count();
            compressed = c.s.n;
        } else {
            Require(c.U16() == 0, "KV3 compression dictionary unsupported");
            c.U16();
            c1 = c.Count();
            c4 = c.Count();
            c8 = c.Count();
            countTypes = c.Count();
            c.Take(4);
            total = c.Count();
            compressed = c.Count();
            blocks = c.Count();
            blobs = c.Count();
        }
        if (version_ >= 4) {
            c2 = c.Count();
            blockSizes = c.Count();
        }

        Require(!blocks && !blobs && !blockSizes, "KV3 edit-info binary blobs unsupported");
        std::size_t plain1 = total, packed1 = compressed, plain2 = 0, packed2 = 0, b1 = 0, b2 = 0, b4 = 0,
                    b8 = 0, objects = 0;
        if (version_ >= 5) {
            plain1 = c.Count();
            packed1 = c.Count();
            plain2 = c.Count();
            packed2 = c.Count();
            b1 = c.Count();
            b2 = c.Count();
            b4 = c.Count();
            b8 = c.Count();
            c.Count();
            objects = c.Count(32768);
            c.Count();
            c.Count();
            Require(plain1 <= total && plain2 == total - plain1, "KV3 total size mismatch");
        }
        auto raw1 = Inflate(c, method, plain1, packed1, decompress);
        Span first{raw1.data(), raw1.size()};
        std::size_t at = 0;
        aux_ = Split(first, at, c1, c2, c4, c8, version_ < 5);
        auto stringCount = aux_.b4.Count(65536);
        std::vector<unsigned char> raw2;
        if (version_ >= 5) {
            Strings(aux_.b1, stringCount);
            Require(at == first.n, "unexpected KV3 auxiliary tail");
            raw2 = Inflate(c, method, plain2, packed2, decompress);
            Span second{raw2.data(), raw2.size()};
            at = objects * 4;
            lengths_.s = second.Sub(0, at);
            main_ = Split(second, at, b1, b2, b4, b8, false);
            types_.s = second.Sub(at, countTypes);
            at += countTypes;
            Require(second.U32(at) == 0xffeedd00 && at + 4 == second.n, "KV3 second buffer trailer");
        } else {
            main_ = aux_;
            Cursor strings{first.Sub(at, first.n - at)};
            auto before = strings.s.n;
            Strings(strings, stringCount);
            auto stringsSize = before - strings.s.n;
            std::size_t typesLength = 0;
            if (version_ == 1) {
                Require(strings.s.n >= 4, "short KV3 trailer");
                typesLength = strings.s.n - 4;
            } else {
                Require(countTypes >= stringsSize, "KV3 type count underflow");
                typesLength = countTypes - stringsSize;
            }
            types_.s = strings.Take(typesLength);
            Require(strings.U32() == 0xffeedd00 && !strings.s.n, "KV3 first buffer trailer");
        }
        Require(!c.s.n, "unexpected RED2 compressed tail");
        Node root = Value(Type(), main_, 0);
        Require(!types_.s.n && !lengths_.s.n && main_.Empty() && (version_ < 5 || aux_.Empty()),
                "KV3 lanes not consumed");
        return root;
    }
};
inline AmbienceCodecInfo Red2(Span block, const AmbienceDecompress& decompress) {
    Kv3 parser;
    auto root = parser.Read(block, decompress);
    Require(root.kind == Node::Object, "RED2 root is not object");
    auto deps = root.Field("m_SpecialDependencies");
    Require(deps && deps->kind == Node::Array && deps->items.size() <= 4096,
            "RED2 special dependencies missing/invalid");
    bool ycocg = false;
    for (const auto& dep : deps->items) {
        Require(dep.kind == Node::Object, "RED2 dependency is not object");
        auto algorithm = dep.Field("m_String"), compiler = dep.Field("m_CompilerIdentifier");
        Require(algorithm && compiler && algorithm->kind == Node::String && compiler->kind == Node::String,
                "RED2 dependency strings missing/invalid");
        if (compiler->text == Compiler && algorithm->text == Algorithm)
            ycocg = true;
    }
    return {ycocg ? AmbienceTextureCodec::YCoCg : AmbienceTextureCodec::RGB,
            "RED2 KV3 v" + std::to_string(block.U32(0) & 0xff) + " CompileTexture"};
}
}
inline AmbienceCodecInfo ReadAmbienceVtexCodec(const AmbienceReadAt& read, std::uint64_t size,
                                               const AmbienceDecompress& decompress = {}) {
    using namespace ambience_metadata;
    try {
        std::array<unsigned char, 16> h{};
        Require(size >= h.size() && read(0, h.data(), h.size()), "cannot read VTEX header");
        Span header{h.data(), h.size()};
        auto fileSize = header.U32(0);
        Require(header.U16(4) == 12 && fileSize >= 16 && fileSize <= size,
                "unsupported/truncated VTEX resource");
        const std::uint64_t table = 8ull + header.U32(8);
        auto count = header.U32(12);
        Require(count && count <= 256 && table >= 16 && table <= fileSize &&
                    std::uint64_t(count) * 12 <= fileSize - table,
                "invalid VTEX block table");
        std::vector<unsigned char> entries(std::size_t(count) * 12);
        Require(read(table, entries.data(), entries.size()), "cannot read VTEX block table");
        Span e{entries.data(), entries.size()};
        std::uint64_t offset = 0, dataOffset = 0;
        std::size_t bytes = 0, dataBytes = 0;
        bool red2 = false, found = false;
        for (std::uint32_t i = 0; i < count; ++i) {
            auto at = std::size_t(i) * 12;
            auto block = e.Sub(at, 12);
            const bool a = std::memcmp(block.p, "REDI", 4) == 0, b = std::memcmp(block.p, "RED2", 4) == 0,
                       d = std::memcmp(block.p, "DATA", 4) == 0;
            if (!a && !b && !d)
                continue;
            auto start = table + at + 4ull + block.U32(4);
            auto length = block.U32(8);
            Require(length && start >= table + entries.size() && start <= fileSize &&
                        length <= fileSize - start,
                    "invalid VTEX block range");
            if (d) {
                Require(!dataBytes, "ambiguous VTEX DATA blocks");
                dataOffset = start;
                dataBytes = length;
                continue;
            }
            Require(!found, "ambiguous VTEX edit-info blocks");
            Require(length <= MaxMetadata, "VTEX edit-info size limit");
            found = true;
            red2 = b;
            offset = start;
            bytes = length;
        }
        if (dataBytes && header.U16(6) != 0) {

            std::array<unsigned char, 28> texture{};
            Require(dataBytes >= texture.size() && read(dataOffset, texture.data(), texture.size()),
                    "cannot read VTEX DATA header");
            Span t{texture.data(), texture.size()};
            Require(t.U16(0) == 1, "unsupported VTEX DATA version");
            const auto format = texture[26];
            if ((format >= 15 && format <= 18) || format == 29 || format == 30)
                return {AmbienceTextureCodec::RGB, "raw JPEG/PNG/WebP VTEX; no color matrix"};
        }
        Require(found, "VTEX edit-info not available");
        std::vector<unsigned char> data(bytes);
        Require(read(offset, data.data(), data.size()), "cannot read VTEX edit-info");
        Span block{data.data(), data.size()};
        return red2 ? Red2(block, decompress) : Redi(block);
    } catch (const Invalid& e) {
        return {AmbienceTextureCodec::Unknown, e.what()};
    } catch (const std::exception&) {
        return {AmbienceTextureCodec::Unknown, "VTEX metadata read/allocation failed"};
    }
}
}
