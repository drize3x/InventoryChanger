#pragma once

inline void RageCapture(const RageValues& r, std::map<std::string, std::string>& out) {
    out["rage.version"] = "1";
    out["rage.selected"] = std::to_string(r.selected);
    out["rage.groups"] = std::to_string(r.weapons.size());
    for (std::size_t i = 0; i < RageSpecs.size(); ++i)
        out[std::string("rage.value.") + RageSpecs[i].id] = std::to_string(r.value[i]);
    for (std::size_t i = 0; i < r.colors.size(); ++i) {
        int j = 0;
        for (float v : {r.colors[i].r, r.colors[i].g, r.colors[i].b, r.colors[i].a})
            out["rage.color." + std::to_string(i) + "." + std::to_string(j++)] = std::to_string(v);
    }
    for (std::size_t g = 0; g < r.weapons.size(); ++g) {
        const auto& p = r.weapons[g];
        auto k = "rage.weapon." + std::to_string(g) + ".";
        out[k + "id"] = p.id;
        out[k + "name"] = p.name;
        out[k + "mask"] = std::to_string(p.weaponMask);
        out[k + "builtin"] = p.builtin ? "1" : "0";
        out[k + "active"] = p.active ? "1" : "0";
        out[k + "individual"] = p.individual ? "1" : "0";
        std::string equipment;
        for (const auto& name : p.equipment) {
            if (!equipment.empty())
                equipment += "|";
            equipment += name;
        }
        out[k + "equipment"] = equipment;
        for (std::size_t i = 0; i < RageSpecs.size(); ++i)
            if (RageSpecs[i].group == 1)
                out[k + RageSpecs[i].id] = std::to_string(p.value[i]);
    }
}
inline void RageRead(RageValues& target, const std::map<std::string, std::string>& values) {
    RageValues next;
    bool any = false;
    for (const auto& kv : values)
        if (kv.first.rfind("rage.", 0) == 0) {
            any = true;
            break;
        }
    if (!any) {
        target = std::move(next);
        return;
    }
    auto string = [&](const std::string& k) -> const std::string& {
        auto it = values.find(k);
        if (it == values.end())
            throw std::runtime_error("Incomplete Rage UI preset");
        return it->second;
    };
    auto num = [&](const std::string& k, float lo, float hi, bool integer = true) {
        const auto& s = string(k);
        std::size_t n = 0;
        float v = std::stof(s, &n);
        if (n != s.size() || !std::isfinite(v) || v < lo || v > hi || (integer && v != std::floor(v)))
            throw std::runtime_error("Invalid Rage UI value");
        return v;
    };
    if (string("rage.version") != "1")
        throw std::runtime_error("Unsupported Rage UI preset version");
    const int count = int(num("rage.groups", 11, 43));
    next.selected = int(num("rage.selected", -1, float(count - 1)));
    for (std::size_t i = 0; i < RageSpecs.size(); ++i) {
        const auto& d = RageSpecs[i];
        next.value[i] =
            num(std::string("rage.value.") + d.id, d.minimum, d.maximum, d.kind != RageKind::Decimal);
    }
    for (std::size_t i = 0; i < next.colors.size(); ++i) {
        if (i == 2) {
            bool present = false;
            for (int k = 0; k < 4; ++k)
                present = present || values.count("rage.color.2." + std::to_string(k));
            if (!present) {
                next.colors[2] = next.colors[1];
                continue;
            }
        }
        int j = 0;
        for (float* v : {&next.colors[i].r, &next.colors[i].g, &next.colors[i].b, &next.colors[i].a})
            *v = num("rage.color." + std::to_string(i) + "." + std::to_string(j++), 0, 1, false);
    }
    next.weapons.clear();
    std::set<std::string> seen;
    for (int g = 0; g < count; ++g) {
        auto k = "rage.weapon." + std::to_string(g) + ".";
        RageWeaponPreset p;
        p.id = string(k + "id");
        p.name = string(k + "name");
        p.builtin = num(k + "builtin", 0, 1) != 0;
        p.weaponMask = unsigned(num(k + "mask", 0, 2047));
        if (p.id.empty() || p.id.size() > 48 ||
            !std::all_of(p.id.begin(), p.id.end(),
                         [](unsigned char c) { return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9'); }) ||
            !seen.insert(p.id).second || !PresetName(DecodeUTF8(p.name), p.builtin))
            throw std::runtime_error("Invalid weapon group identity");
        if (g < 11) {
            if (!p.builtin || p.id != RageWeaponKeys[std::size_t(g)] || p.weaponMask != (1u << g))
                throw std::runtime_error("Invalid built-in weapon group");
        } else if (p.builtin)
            throw std::runtime_error("Invalid custom weapon group");

        bool extended =
            values.count(k + "active") || values.count(k + "individual") || values.count(k + "equipment");
        if (extended) {
            p.active = num(k + "active", 0, 1) != 0;
            p.individual = num(k + "individual", 0, 1) != 0;
            const auto& list = string(k + "equipment");
            if (list.size() > 1024)
                throw std::runtime_error("Equipment list too long");
            std::size_t at = 0;
            while (at < list.size()) {
                auto end = list.find('|', at);
                auto name = list.substr(at, end - at);
                if (!RageEquipmentKnown(name) ||
                    std::find(p.equipment.begin(), p.equipment.end(), name) != p.equipment.end())
                    throw std::runtime_error("Invalid equipment membership");
                p.equipment.push_back(name);
                if (end == std::string::npos)
                    break;
                at = end + 1;
                if (at == list.size())
                    throw std::runtime_error("Invalid equipment delimiter");
            }
        }
        for (std::size_t i = 0; i < RageSpecs.size(); ++i)
            if (RageSpecs[i].group == 1) {
                const auto& d = RageSpecs[i];
                p.value[i] = num(k + d.id, d.minimum, d.maximum, d.kind != RageKind::Decimal);
            }
        next.weapons.push_back(std::move(p));
    }
    target = std::move(next);
}
