#pragma once
#include "dt_demo_indicator.h"
#include "renderer_dx11.h"
namespace menu {
inline void DrawDTDemoGPU(wm::RendererDX11& r, ID3D11Texture2D* scene, ID3D11RenderTargetView* target, int w,
                          int h, Fonts& f, const Settings& cfg, const DTDemoIndicator& ui) {
    auto p = MeasureDTDemo(f, cfg, ui, w, h);
    const auto b = p.box;
    if (b.w <= 0 || b.h <= 0)
        return;
    auto pal = CurrentPalette(cfg);
    const float bgOpacity = std::clamp(cfg.worldMisc.value[2] / 100.f, 0.f, 1.f);
    auto fill = pal[45];
    fill.a *= p.alpha * bgOpacity;
    r.ClearClip();
    r.PrepareBackdrop(scene, cfg.sigma * p.scale, cfg.blur);
    if (cfg.blur && bgOpacity > 0)
        r.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {1, 1, 1, p.alpha * bgOpacity}, 8 * p.scale, 0, 0,
                           true, true);
    r.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {fill.r, fill.g, fill.b, fill.a}, 8 * p.scale);

    auto shadow = pal[38];
    shadow.a *= p.alpha * bgOpacity;
    r.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {0, 0, 0, 0}, 8 * p.scale, 0, 0, false, false,
                       10 * p.scale, {shadow.r, shadow.g, shadow.b, shadow.a}, 15, 0, 0, false, 0);

    auto accent = pal[31];
    accent.a *= p.alpha * std::clamp(cfg.worldMisc.value[1] / 100.f, 0.f, 1.f);
    r.DrawOriginalIndicatorLine(target, b.x - 1.5f * p.scale, b.y, 3 * p.scale, b.h,
                                {accent.r, accent.g, accent.b, accent.a}, 8 * p.scale, 10 * p.scale);
    int iw = int(std::ceil(b.w)), ih = int(std::ceil(b.h));
    if (iw <= 0 || ih <= 0)
        return;

    const float s = p.scale, cx = b.x + 10 * s + p.iconSize + 5 * s + p.textWidth + 5 * s + p.ringSize * .5f,
                cy = b.y + b.h * .5f;
    const float centerRadius = (p.ringSize - 5.5f * s) * .5f;
    constexpr float pi = 3.14159265358979323846f;
    r.DrawOriginalArc(target, cx, cy, p.ringSize, {.0392f, .0392f, .0392f, .502f * p.alpha}, 5.5f * s, 0,
                      2 * pi);
    auto line = pal[31];
    line.a *= p.alpha;
    if (p.progress > 0)
        r.DrawOriginalArc(target, cx, cy, 2 * (centerRadius + 1.75f * s), {line.r, line.g, line.b, line.a},
                          3.5f * s, pi * .5f - 2 * pi * p.progress, pi * .5f);
    Canvas ink(iw, ih);
    DrawDTDemoInk(ink, f, cfg, p, b.x, b.y, false);
    r.SetClip(b.x, b.y, b.w, b.h);
    r.DrawLayer(target, w, h, ink.rgba.data(), iw, ih, b.x, b.y, float(iw), 0, 369, true);
    r.ClearClip();
}
}
