#pragma once

#include "players_live_data.h"
#include "world_camera_engine.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <memory>
#include <string>
#include <vector>
namespace menu {
namespace world_hud_overlay {
inline constexpr unsigned SelectLeft = 1, SelectRight = 2, SelectTop = 4, SelectBottom = 8, SelectAll = 15;

inline constexpr int FirstSlot = 364, Slots = 5, DiscSlot = 4;
inline constexpr float RecoilFactor = 1.55f;
inline constexpr float MaxDiscFraction = .35f, MaxDiscPixels = 512.f;
inline constexpr float MaxPunchRadians = 1.2f;
inline constexpr double MinRasterInterval = 1.0 / 60.0;
inline constexpr int GlowPadFactor = 6, DiscQuality = 16;
}
inline bool HudSame(Color a, Color b) {
    return a.r == b.r && a.g == b.g && a.b == b.b && a.a == b.a;
}
inline Color HudSaneColor(Color c, Color fallback) {
    if (!std::isfinite(c.r) || !std::isfinite(c.g) || !std::isfinite(c.b) || !std::isfinite(c.a))
        return fallback;
    return {std::clamp(c.r, 0.f, 1.f), std::clamp(c.g, 0.f, 1.f), std::clamp(c.b, 0.f, 1.f),
            std::clamp(c.a, 0.f, 1.f)};
}

struct ScopeOverlayConfig {
    std::uint32_t mode = 0;
    bool gradient = false, tilted = false, glow = false;
    unsigned selection = world_hud_overlay::SelectAll;
    float offset = 8, size = 30, aspect = 0, spread = 24;
    Color single{0, 0, 0, 1}, inner{70.f / 255, 70.f / 255, 90.f / 255, 170.f / 255},
        outer{45.f / 255, 100.f / 255, 220.f / 255, 1};

    Color glowColor{65.f / 255, 55.f / 255, 60.f / 255, 1};
    bool Lines() const {
        return mode == 1;
    }
    bool operator==(const ScopeOverlayConfig& o) const {
        return mode == o.mode && gradient == o.gradient && tilted == o.tilted && glow == o.glow &&
               selection == o.selection && offset == o.offset && size == o.size && aspect == o.aspect &&
               spread == o.spread && HudSame(single, o.single) && HudSame(inner, o.inner) &&
               HudSame(outer, o.outer) && HudSame(glowColor, o.glowColor);
    }
};
struct InaccuracyOverlayConfig {
    bool on = false, follow = false, onlyInScope = false, invert = false;
    float fade = 45;
    Color color{0, 0, 0, 120.f / 255};
    bool operator==(const InaccuracyOverlayConfig& o) const {
        return on == o.on && follow == o.follow && onlyInScope == o.onlyInScope && invert == o.invert &&
               fade == o.fade && HudSame(color, o.color);
    }
};
struct HudOverlayConfig {
    ScopeOverlayConfig scope;
    InaccuracyOverlayConfig inaccuracy;
    bool Wanted() const {
        return scope.Lines() || inaccuracy.on;
    }

    ProbeRequest Probe(bool scoped) const {
        ProbeRequest r;
        const bool disc = inaccuracy.on && (!inaccuracy.onlyInScope || scoped),
                   lines = scope.Lines() && scope.gradient && scoped;
        r.inaccuracy = disc || lines;
        r.punch = disc && inaccuracy.follow;
        return r;
    }
    bool operator==(const HudOverlayConfig& o) const {
        return scope == o.scope && inaccuracy == o.inaccuracy;
    }
};

inline HudOverlayConfig HudOverlayReadConfig(const Settings& cfg) {
    static const WorldHudValues defaults;
    const auto& v = cfg.worldHud.value;
    auto num = [&](std::size_t i, float lo, float hi) {
        const float x = v[i];
        return std::isfinite(x) ? std::clamp(std::round(x), lo, hi) : defaults.value[i];
    };
    HudOverlayConfig c;
    c.scope.mode = std::uint32_t(num(1, 0, 2));
    c.scope.gradient = cfg.worldHud.scopeColorMode == 1;
    c.scope.selection = unsigned(num(2, 0, 15));
    c.scope.tilted = num(3, 0, 1) >= .5f;
    c.scope.offset = num(4, 0, 100);
    c.scope.size = num(5, 0, 100);
    c.scope.aspect = num(6, 0, 100);
    c.scope.spread = num(7, 24, 100);
    c.scope.glow = num(8, 0, 1) >= .5f;
    c.scope.single = HudSaneColor(cfg.worldHud.colors[0], defaults.colors[0]);
    c.scope.inner = HudSaneColor(cfg.worldHud.colors[1], defaults.colors[1]);
    c.scope.outer = HudSaneColor(cfg.worldHud.colors[2], defaults.colors[2]);
    c.scope.glowColor = HudSaneColor(cfg.worldHud.colors[3], defaults.colors[3]);
    c.inaccuracy.on = num(9, 0, 1) >= .5f;
    c.inaccuracy.follow = num(10, 0, 1) >= .5f;
    c.inaccuracy.onlyInScope = num(11, 0, 1) >= .5f;
    c.inaccuracy.invert = num(12, 0, 1) >= .5f;
    c.inaccuracy.fade = num(13, 5, 100);
    c.inaccuracy.color = HudSaneColor(cfg.worldHud.colors[4], defaults.colors[4]);
    return c;
}

struct HudScale {
    float fx = 0, fy = 0;
    bool ok = false;
};

inline HudScale HudScreenScale(const LiveESPMatrix& matrix, int width, int height) {
    HudScale s;
    if (width < 1 || height < 1 || width > 16384 || height > 16384)
        return s;
    for (float f : matrix.m)
        if (!std::isfinite(f))
            return s;
    auto length = [&](std::size_t row) {
        const float* p = matrix.m.data() + row;
        return std::sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]);
    };
    const float depth = length(12);
    if (!(depth > 1e-6f))
        return s;
    s.fx = length(0) / depth * float(width) * .5f;
    s.fy = length(4) / depth * float(height) * .5f;
    s.ok =
        std::isfinite(s.fx) && std::isfinite(s.fy) && s.fx > 0.f && s.fy > 0.f && s.fx < 1e6f && s.fy < 1e6f;
    return s;
}

inline void HudRecoilOffset(const ProbeSample& probe, const HudScale& scale, int width, int height, int& dx,
                            int& dy) {
    dx = dy = 0;
    if (!probe.hasPunch || !scale.ok || !std::isfinite(probe.punchYaw) || !std::isfinite(probe.punchPitch))
        return;
    const float k = world_hud_overlay::RecoilFactor * 3.14159265f / 180.f,
                m = world_hud_overlay::MaxPunchRadians;
    const float yaw = std::clamp(k * probe.punchYaw, -m, m), pitch = std::clamp(k * probe.punchPitch, -m, m);
    dx = int(std::lround(-scale.fx * std::tan(yaw)));
    dy = int(std::lround(scale.fy * std::tan(pitch)));
    dx = std::clamp(dx, -width / 2, width / 2);
    dy = std::clamp(dy, -height / 2, height / 2);
}

struct ScopeArm {
    bool present = false;
    int kind = 0, x = 0, y = 0, vx = 0, vy = 0, thickness = 1;
    float fx = 0, fy = 0;
    bool glow = false;
    Color inner{0, 0, 0, 1}, outer{0, 0, 0, 1};
    Color glowColor{0, 0, 0, 0};
};
using ScopeArms = std::array<ScopeArm, 4>;

struct ScopeArmKey {
    int vx = 0, vy = 0, thickness = 0;
    float fx = 0, fy = 0;
    bool glow = false;
    Color inner{0, 0, 0, 0}, outer{0, 0, 0, 0}, glowColor{0, 0, 0, 0};
    static ScopeArmKey Of(const ScopeArm& a) {
        ScopeArmKey k;
        k.vx = a.vx;
        k.vy = a.vy;
        k.thickness = a.thickness;
        k.fx = a.fx;
        k.fy = a.fy;
        k.glow = a.glow;
        k.inner = a.inner;
        k.outer = a.outer;
        if (a.glow)
            k.glowColor = a.glowColor;
        return k;
    }
    bool operator==(const ScopeArmKey& o) const {
        return vx == o.vx && vy == o.vy && thickness == o.thickness && fx == o.fx && fy == o.fy &&
               glow == o.glow && HudSame(inner, o.inner) && HudSame(outer, o.outer) &&
               HudSame(glowColor, o.glowColor);
    }
};
inline int ScopeThickness(bool gradient, int height) {
    return gradient ? std::max(1, int(std::floor(double(height) / 720.0 + .5)))
                    : std::max(1, int(std::lround(double(height) / 1080.0)));
}
inline ScopeArms ScopeLayout(const ScopeOverlayConfig& c, int width, int height, float inaccuracyPx) {
    ScopeArms arms{};
    if (!c.Lines() || width < 64 || height < 64 || width > 16384 || height > 16384)
        return arms;
    const int cx = width / 2, cy = height / 2, T = ScopeThickness(c.gradient, height);
    const float phase = (T & 1) ? .5f : 0.f;
    for (int k = 0; k < 4; ++k) {
        auto& a = arms[std::size_t(k)];
        a.kind = k;
        a.thickness = T;
        a.glow = c.gradient && c.glow;
        a.inner = c.gradient ? c.inner : c.single;
        a.outer = c.gradient ? c.outer : c.single;
        if (a.glow)
            a.glowColor = c.glowColor;
    }
    auto horizontal = [&](ScopeArm& a, int vx) {
        a.present = vx != 0;
        a.x = cx;
        a.y = cy;
        a.vx = vx;
        a.vy = 0;
        a.fx = 0;
        a.fy = phase;
    };
    auto vertical = [&](ScopeArm& a, int vy) {
        a.present = vy != 0;
        a.x = cx;
        a.y = cy;
        a.vx = 0;
        a.vy = vy;
        a.fx = phase;
        a.fy = 0;
    };
    if (!c.gradient) {
        horizontal(arms[0], -cx);
        horizontal(arms[1], width - cx);
        vertical(arms[2], -cy);
        vertical(arms[3], height - cy);
        return arms;
    }
    const float W = float(width), H = float(height);
    const float base = std::clamp(c.offset, 0.f, 100.f) * .01f * .25f * H;
    const float cone = std::isfinite(inaccuracyPx) && inaccuracyPx > 0.f ? std::min(inaccuracyPx, H) : 0.f;
    const float gap = base + cone * std::clamp(c.spread, 0.f, 100.f) * .01f,
                length = std::clamp(c.size, 0.f, 100.f) * .01f * .5f * H;
    const float stretch = std::max(.05f, 1.f + std::clamp(c.aspect, 0.f, 100.f) * .01f * (W / H - 1.f));
    const float d = .70710678f;
    static const float axis[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    const float diagonal[4][2] = {{-d, -d}, {d, d}, {d, -d}, {-d, d}};
    for (int k = 0; k < 4; ++k) {
        if (!(c.selection & (1u << k)))
            continue;
        const float dx = c.tilted ? diagonal[k][0] : axis[k][0], dy = c.tilted ? diagonal[k][1] : axis[k][1];
        auto& a = arms[std::size_t(k)];
        a.x = int(std::lround(float(cx) + dx * gap * stretch));
        a.y = int(std::lround(float(cy) + dy * gap));
        int vx = int(std::lround(dx * length * stretch)), vy = int(std::lround(dy * length));
        if (a.x < 0 || a.x > width || a.y < 0 || a.y > height)
            continue;
        float s = 1.f;
        if (vx < 0 && a.x + vx < 0)
            s = std::min(s, float(a.x) / float(-vx));
        if (vx > 0 && a.x + vx > width)
            s = std::min(s, float(width - a.x) / float(vx));
        if (vy < 0 && a.y + vy < 0)
            s = std::min(s, float(a.y) / float(-vy));
        if (vy > 0 && a.y + vy > height)
            s = std::min(s, float(height - a.y) / float(vy));
        if (s < 1.f) {
            vx = int(float(vx) * s);
            vy = int(float(vy) * s);
        }
        if (std::max(std::abs(vx), std::abs(vy)) < 2)
            continue;
        a.present = true;
        a.vx = vx;
        a.vy = vy;
        if (!c.tilted) {
            if (k < 2)
                a.fy = phase;
            else
                a.fx = phase;
        }
    }
    return arms;
}
struct ScopeArmFrame {
    int width = 0, height = 0, offX = 0, offY = 0;
};
inline ScopeArmFrame ScopeArmCanvas(const ScopeArm& a) {
    const int pad = a.glow ? world_hud_overlay::GlowPadFactor * a.thickness : 0,
              margin = a.thickness / 2 + 2 + pad;
    ScopeArmFrame f;
    f.offX = margin + std::max(0, -a.vx);
    f.offY = margin + std::max(0, -a.vy);
    f.width = std::abs(a.vx) + 2 * margin;
    f.height = std::abs(a.vy) + 2 * margin;
    return f;
}

inline std::shared_ptr<Canvas> ScopeArmRaster(const ScopeArm& a) {
    const auto f = ScopeArmCanvas(a);
    auto canvas = std::make_shared<Canvas>(std::max(1, f.width), std::max(1, f.height));
    const float len = std::sqrt(float(a.vx) * float(a.vx) + float(a.vy) * float(a.vy));
    if (!(len > 0.f))
        return canvas;
    const float ux = float(a.vx) / len, uy = float(a.vy) / len, ax = float(f.offX) + a.fx,
                ay = float(f.offY) + a.fy, half = float(a.thickness) * .5f;
    const float pad = a.glow ? float(world_hud_overlay::GlowPadFactor * a.thickness) : 0.f;
    for (int y = 0; y < canvas->height; ++y)
        for (int x = 0; x < canvas->width; ++x) {
            const float px = float(x) + .5f - ax, py = float(y) + .5f - ay, s = px * ux + py * uy,
                        perp = std::fabs(py * ux - px * uy);
            float cover = std::clamp(half + .5f - perp, 0.f, 1.f) * std::clamp(s + .5f, 0.f, 1.f) *
                          std::clamp(len - s + .5f, 0.f, 1.f);
            float halo = 0.f;
            if (pad > 0.f) {
                const float over = std::max(0.f, std::max(-s, s - len)),
                            dist = std::sqrt(perp * perp + over * over),
                            g = std::clamp(1.f - (dist - half) / pad, 0.f, 1.f);
                halo = g * g * .4f;
            }
            if (cover <= 0.f && halo <= 0.f)
                continue;
            if (halo > 0.f && cover < 1.f)
                canvas->Blend(x, y, a.glowColor, halo);
            if (cover <= 0.f)
                continue;
            const float t = len > 1.f ? std::clamp((s - .5f) / (len - 1.f), 0.f, 1.f) : 0.f;
            canvas->Blend(x, y, Mix(a.inner, a.outer, t), cover);
        }
    return canvas;
}

inline float HudDiscProfile(float t, float fade, bool invert) {
    const float f = std::clamp(fade, .05f, 1.f), u = std::clamp((t - (1.f - f)) / f, 0.f, 1.f),
                s = u * u * (3.f - 2.f * u);
    return invert ? 1.f - s : s;
}
struct HudDiscStyle {
    int radius = 0, fade = 45;
    bool invert = false;
    Color color{0, 0, 0, 120.f / 255};
    bool SameLook(const HudDiscStyle& o) const {
        return fade == o.fade && invert == o.invert && Canvas::Byte(color.r) == Canvas::Byte(o.color.r) &&
               Canvas::Byte(color.g) == Canvas::Byte(o.color.g) &&
               Canvas::Byte(color.b) == Canvas::Byte(o.color.b) &&
               Canvas::Byte(color.a) == Canvas::Byte(o.color.a);
    }
};

inline int HudDiscHalf(int radius) {
    return ((std::max(1, radius) + 3 + 31) / 32) * 32;
}

inline std::vector<std::uint32_t> HudDiscLut(const HudDiscStyle& s) {
    const int Q = world_hud_overlay::DiscQuality;
    std::vector<std::uint32_t> lut(std::size_t(std::max(1, s.radius) + 2) * std::size_t(Q));
    const float R = float(std::max(1, s.radius));
    for (std::size_t i = 0; i < lut.size(); ++i) {
        const float r = (float(i) + .5f) / float(Q), rim = std::clamp(R + .5f - r, 0.f, 1.f);
        const float a =
            std::clamp(HudDiscProfile(r / R, float(s.fade) * .01f, s.invert) * rim * s.color.a, 0.f, 1.f);
        const unsigned char px[4] = {Canvas::Byte(s.color.r * a), Canvas::Byte(s.color.g * a),
                                     Canvas::Byte(s.color.b * a), Canvas::Byte(a)};
        std::memcpy(&lut[i], px, 4);
    }
    return lut;
}

inline void HudDiscRaster(Canvas& c, const HudDiscStyle& s) {
    if (c.width < 2 || c.width != c.height || (c.width & 1))
        return;
    const int side = c.width, half = side / 2, Q = world_hud_overlay::DiscQuality;
    const auto lut = HudDiscLut(s);
    const std::size_t n = lut.size();
    std::vector<std::uint32_t> row(std::size_t(side), 0u);
    std::vector<float> sq(static_cast<std::size_t>(half));
    for (int a = 0; a < half; ++a) {
        const float dx = float(a) + .5f;
        sq[std::size_t(a)] = dx * dx;
    }
    for (int b = 0; b < half; ++b) {
        const float dy = float(b) + .5f, dy2 = dy * dy;
        for (int a = 0; a < half; ++a) {
            const float r = std::sqrt(sq[std::size_t(a)] + dy2);
            const std::size_t idx = std::size_t(r * float(Q));
            const std::uint32_t px = idx < n ? lut[idx] : 0u;
            row[std::size_t(half + a)] = px;
            row[std::size_t(half - 1 - a)] = px;
        }
        const std::size_t bytes = std::size_t(side) * 4;
        std::memcpy(c.rgba.data() + std::size_t(half - 1 - b) * bytes, row.data(), bytes);
        std::memcpy(c.rgba.data() + std::size_t(half + b) * bytes, row.data(), bytes);
    }
}

struct HudSprite {
    int slot = 0, x = 0, y = 0;
    std::shared_ptr<const Canvas> image;
    std::uint64_t stamp = 0;
};
struct HudOverlayInput {
    int width = 0, height = 0;
    double now = 0;
    bool scoped = false;
    bool hasProbe = false;
    ProbeSample probe;
    bool hasMatrix = false;
    LiveESPMatrix matrix;
};
class HudOverlayRenderer {
    struct ArmCache {
        ScopeArmKey key;
        std::shared_ptr<const Canvas> image;
        std::uint64_t stamp = 0;
    };
    struct DiscCache {
        HudDiscStyle style;
        std::shared_ptr<Canvas> canvas;
        std::uint64_t stamp = 0;
        double at = 0;
    };
    std::array<ArmCache, 4> arms_{};
    DiscCache disc_{};
    std::uint64_t stamps_ = 0;
    void ReleaseDisc() {
        disc_ = DiscCache{};
    }
    void BuildDisc(const InaccuracyOverlayConfig& c, const HudOverlayInput& in, const HudScale& scale,
                   bool probeOk, int width, int height) {
        float radius = 0.f;
        if (c.on && probeOk && scale.ok && (!c.onlyInScope || in.scoped))
            radius = in.probe.Tangent() * scale.fy;
        const float cap = std::min(world_hud_overlay::MaxDiscFraction * float(std::min(width, height)),
                                   world_hud_overlay::MaxDiscPixels);
        const int r = std::isfinite(radius) ? int(std::lround(std::min(radius, cap))) : 0;
        if (r < 1) {
            ReleaseDisc();
            return;
        }
        HudDiscStyle style;
        style.radius = r;
        style.fade = int(std::lround(std::clamp(c.fade, 5.f, 100.f)));
        style.invert = c.invert;
        style.color = c.color;
        bool rebuild = !disc_.canvas || !disc_.style.SameLook(style);
        if (!rebuild && r != disc_.style.radius) {
            if (in.now < disc_.at || in.now - disc_.at >= world_hud_overlay::MinRasterInterval)
                rebuild = true;
            else
                ++discThrottled;
        }
        if (rebuild) {
            const int side = 2 * HudDiscHalf(r);
            if (!disc_.canvas || disc_.canvas->width != side || disc_.canvas.use_count() != 1)
                disc_.canvas = std::make_shared<Canvas>(side, side);
            HudDiscRaster(*disc_.canvas, style);
            disc_.style = style;
            disc_.at = in.now;
            disc_.stamp = ++stamps_;
            ++discRasters;
        }
        int dx = 0, dy = 0;
        if (c.follow)
            HudRecoilOffset(in.probe, scale, width, height, dx, dy);
        const int half = disc_.canvas->width / 2;
        sprites.push_back({world_hud_overlay::DiscSlot, width / 2 + dx - half, height / 2 + dy - half,
                           disc_.canvas, disc_.stamp});
        discRadius = disc_.style.radius;
    }
    void BuildArms(const ScopeOverlayConfig& c, const HudOverlayInput& in, const HudScale& scale,
                   bool probeOk, int width, int height) {
        ScopeArms layout{};
        if (c.Lines() && in.scoped) {
            const float cone = c.gradient && probeOk && scale.ok ? in.probe.Tangent() * scale.fy : 0.f;
            layout = ScopeLayout(c, width, height, cone);
        }
        for (std::size_t k = 0; k < 4; ++k) {
            auto& cache = arms_[k];
            const auto& arm = layout[k];
            if (!arm.present) {
                cache = ArmCache{};
                continue;
            }
            const auto key = ScopeArmKey::Of(arm);
            if (!cache.image || !(cache.key == key)) {
                cache.image = ScopeArmRaster(arm);
                cache.key = key;
                cache.stamp = ++stamps_;
                ++armRasters;
            }
            const auto frame = ScopeArmCanvas(arm);
            sprites.push_back({int(k), arm.x - frame.offX, arm.y - frame.offY, cache.image, cache.stamp});
            ++armsDrawn;
        }
    }

public:
    std::vector<HudSprite> sprites;
    unsigned long long frames = 0, armRasters = 0, discRasters = 0, discThrottled = 0, armsDrawn = 0;
    int discRadius = 0;
    void Release() {
        sprites.clear();
        for (auto& a : arms_)
            a = ArmCache{};
        ReleaseDisc();
        discRadius = 0;
    }

    void Build(const HudOverlayConfig& cfg, const HudOverlayInput& in) {
        sprites.clear();
        ++frames;
        const bool dims = in.width >= 64 && in.height >= 64 && in.width <= 16384 && in.height <= 16384 &&
                          std::isfinite(in.now);
        if (!cfg.Wanted() || !dims) {
            for (auto& a : arms_)
                a = ArmCache{};
            ReleaseDisc();
            discRadius = 0;
            return;
        }
        const HudScale scale = in.hasMatrix ? HudScreenScale(in.matrix, in.width, in.height) : HudScale{};
        const bool probeOk =
            in.hasProbe && in.probe.valid && ProbePlausible(in.probe.inaccuracy, in.probe.spread);
        BuildDisc(cfg.inaccuracy, in, scale, probeOk, in.width, in.height);
        if (sprites.empty())
            discRadius = 0;
        BuildArms(cfg.scope, in, scale, probeOk, in.width, in.height);
    }
    std::string Summary() const {
        return "sprites=" + std::to_string(sprites.size()) + " discR=" + std::to_string(discRadius) +
               " rasters(arm/disc)=" + std::to_string(armRasters) + "/" + std::to_string(discRasters) +
               " throttled=" + std::to_string(discThrottled) + " frames=" + std::to_string(frames);
    }
};
}
