#pragma once
#include "watermark_speed_delay.h"
#include <cstring>
namespace menu {
struct WatermarkDelivery {
    float first = 0, second = 0;
};
struct WatermarkServerStability {
    float ms = 0;
    bool stalled = false;
};
struct WatermarkInputTiming {
    float receivedMs = 0, targetMs = 0;
};
struct WatermarkConnectionStatus {
    float seconds = 0;
    bool timedOut = false;
};
struct WatermarkNetworkRaw {
    std::optional<WatermarkDelivery> delivery, packetLoss, latePackets, jitter;
    std::optional<WatermarkDelivery> remoteFrame;
    std::optional<WatermarkConnectionStatus> connection;
    std::uintptr_t client = 0, channel = 0;
};
struct WatermarkNetworkVisible {
    std::optional<WatermarkDelivery> delivery, packetLoss, latePackets, jitter;
    std::optional<WatermarkServerStability> stability;
    std::optional<WatermarkConnectionStatus> connection;
};
inline float WatermarkNetworkNonnegative(float v) {
    return std::isfinite(v) ? std::max(0.f, v) : 0.f;
}
inline float WatermarkDeliveryPercent(float ratio) {
    return std::clamp(WatermarkNetworkNonnegative(ratio), 0.f, 1.f) * 100.f;
}

class WatermarkNetworkWarnings {
    std::optional<std::int64_t> deliveryStamp, serverStamp, lossStamp, lateStamp, jitterStamp;
    std::int64_t peakStamp = 0, lastNow = 0;
    float peakMs = 0, heldMs = 0;
    bool peakStalled = false, heldStalled = false;
    std::uintptr_t client = 0, channel = 0;

public:
    void Reset() {
        deliveryStamp.reset();
        serverStamp.reset();
        lossStamp.reset();
        lateStamp.reset();
        jitterStamp.reset();
        peakStamp = lastNow = 0;
        peakMs = heldMs = 0;
        peakStalled = heldStalled = false;
        client = channel = 0;
    }
    WatermarkNetworkVisible Sample(const WatermarkNetworkRaw& raw, std::int64_t now) {
        if (now < 0) {
            Reset();
            return {};
        }
        if (now < lastNow || raw.client != client || raw.channel != channel) {
            Reset();
            client = raw.client;
            channel = raw.channel;
        }
        lastNow = now;
        WatermarkNetworkVisible out;
        auto hold = [&](const std::optional<WatermarkDelivery>& pair, std::optional<std::int64_t>& stamp,
                        bool jitter) {
            std::optional<WatermarkDelivery> result;
            if (pair && std::isfinite(pair->first) && std::isfinite(pair->second)) {
                float maximum = std::max(pair->first, pair->second);
                if (jitter ? maximum >= 20.f : maximum > .01f)
                    stamp = now;
                if (stamp && now - *stamp < 3000000000LL)
                    result = pair;
            } else
                stamp.reset();
            return result;
        };
        out.packetLoss = hold(raw.packetLoss, lossStamp, false);
        out.latePackets = hold(raw.latePackets, lateStamp, false);
        out.jitter = hold(raw.jitter, jitterStamp, true);
        if (raw.delivery && std::isfinite(raw.delivery->first) && std::isfinite(raw.delivery->second)) {
            if (std::max(raw.delivery->first, raw.delivery->second) > .01f)
                deliveryStamp = now;
            if (deliveryStamp && now - *deliveryStamp < 3000000000LL)
                out.delivery = raw.delivery;
        } else
            deliveryStamp.reset();
        if (raw.remoteFrame && std::isfinite(raw.remoteFrame->first) &&
            std::isfinite(raw.remoteFrame->second)) {
            auto frame = *raw.remoteFrame;
            bool stalled = frame.first >= 100.f;
            float candidate = stalled ? frame.first : frame.second;
            if (candidate > peakMs) {
                peakMs = candidate;
                peakStalled = stalled;
            }
            if (now - peakStamp >= 350000000LL) {
                heldMs = peakMs;
                heldStalled = peakStalled;
                peakMs = 0;
                peakStalled = false;
                peakStamp = now;
            }
            if (stalled || frame.second >= 3.90625f)
                serverStamp = now;
            if (serverStamp && now - *serverStamp < 3000000000LL)
                out.stability = WatermarkServerStability{heldMs, heldStalled};
        } else {
            serverStamp.reset();
            peakStamp = now;
            peakMs = heldMs = 0;
            peakStalled = heldStalled = false;
        }
        if (raw.connection && std::isfinite(raw.connection->seconds) && raw.connection->seconds >= 1.f)
            out.connection = raw.connection;
        return out;
    }
};
inline bool WatermarkNetworkRange(const WatermarkKdModule& m, std::uintptr_t address, std::size_t size,
                                  bool executable) {
    for (const auto& s : m.sections)
        if (bool(s.flags & 0x20000000) == executable && (s.flags & 0x40000000) && address >= m.base + s.rva &&
            address - (m.base + s.rva) <= s.size && size <= s.size - (address - (m.base + s.rva)))
            return true;
    return false;
}
template <class Reader, std::size_t N>
bool WatermarkNetworkCode(Reader&& read, const WatermarkKdModule& module, std::uintptr_t object,
                          unsigned slot, std::array<unsigned char, N>& code, std::uintptr_t& function) {
    std::uintptr_t table = 0;
    function = 0;
    return object && read(object, table) && table && read(table + slot * 8, function) &&
           WatermarkNetworkRange(module, function, N, true) && read(function, code);
}
template <std::size_t N>
std::uint32_t WatermarkNetworkOffset(const std::array<unsigned char, N>& code, std::size_t at) {
    std::uint32_t offset = 0;
    if (at + 4 <= N)
        std::memcpy(&offset, code.data() + at, 4);
    return offset;
}
template <class Reader>
std::optional<float> WatermarkNetworkFloatGetter(Reader&& read, const WatermarkKdModule& module,
                                                 std::uintptr_t object, unsigned slot) {
    std::array<unsigned char, 9> code{};
    std::uintptr_t fn = 0;
    if (!WatermarkNetworkCode(read, module, object, slot, code, fn) || code[0] != 0xF3 || code[1] != 0x0F ||
        code[2] != 0x10 || code[3] != 0x81 || code[8] != 0xC3)
        return {};
    auto offset = WatermarkNetworkOffset(code, 4);
    float value = 0;
    if (offset > 0x1000000 || !read(object + offset, value))
        return {};
    return value;
}

inline constexpr std::array<int, 24> WatermarkFlowPattern{{0x83, 0xFA, 1,    0xB8, -1,   -1, -1,   -1,
                                                           0x41, 0xB8, -1,   -1,   -1,   -1, 0x41, 0x0F,
                                                           0x45, 0xC0, 0xF3, 0x0F, 0x10, 4,  8,    0xC3}};
template <class Reader>
std::optional<WatermarkDelivery> WatermarkNetworkFlowGetter(Reader&& read, const WatermarkKdModule& module,
                                                            std::uintptr_t object, unsigned slot,
                                                            bool percent) {
    std::array<unsigned char, 24> code{};
    std::uintptr_t fn = 0;
    if (!WatermarkNetworkCode(read, module, object, slot, code, fn) ||
        WatermarkKdMatches(code.data(), code.size(), WatermarkFlowPattern).size() != 1)
        return {};
    auto incoming = WatermarkNetworkOffset(code, 4), outgoing = WatermarkNetworkOffset(code, 10);
    float a = 0, b = 0;
    if (incoming > 0x1000000 || outgoing > 0x1000000 || !read(object + outgoing, a) ||
        !read(object + incoming, b))
        return {};
    return WatermarkDelivery{percent ? WatermarkDeliveryPercent(a) : WatermarkNetworkNonnegative(a),
                             percent ? WatermarkDeliveryPercent(b) : WatermarkNetworkNonnegative(b)};
}
inline constexpr std::array<int, 42> WatermarkRemoteFramePattern{
    {0x48, 0x85, 0xD2, 0x74, 8,    0x8B, 0x81, -1, -1, -1, -1,   0x89, 2, 0x4D,
     0x85, 0xC0, 0x74, 9,    0x8B, 0x81, -1,   -1, -1, -1, 0x41, 0x89, 0, 0x4D,
     0x85, 0xC9, 0x74, 9,    0x8B, 0x81, -1,   -1, -1, -1, 0x41, 0x89, 1, 0xC3}};
inline constexpr std::array<int, 28> WatermarkLastReceivePattern{
    {0xF2, 0x0F, 0x10, 5,  -1, -1,   -1,   -1,   0x0F, 0x57, 0xC9, 0xF2, 0x0F, 0x5C,
     0x81, -1,   -1,   -1, -1, 0x66, 0x0F, 0x5A, 0xC0, 0xF3, 0x0F, 0x5F, 0xC1, 0xC3}};
inline constexpr std::array<int, 54> WatermarkTimingOutPattern{
    {0xF3, 0x0F, 0x10, 0x81, -1,   -1,   -1,   -1,   0x0F, 0x2E, 5,    -1,   -1,   -1,
     -1,   0x7A, 5,    0x75, 3,    0x32, 0xC0, 0xC3, 0xF2, 0x0F, 0x10, 0x89, -1,   -1,
     -1,   -1,   0xF2, 0x0F, 0x58, 0x0D, -1,   -1,   -1,   -1,   0xF2, 0x0F, 0x10, 5,
     -1,   -1,   -1,   -1,   0x66, 0x0F, 0x2F, 0xC1, 0x0F, 0x97, 0xC0, 0xC3}};
template <class Reader, std::size_t N, class T>
bool WatermarkNetworkRipRead(Reader&& read, const WatermarkKdModule& module, std::uintptr_t fn,
                             const std::array<unsigned char, N>& code, std::size_t displacementAt,
                             std::size_t nextInstruction, T& value, std::uintptr_t& address) {
    std::int32_t delta = 0;
    auto raw = WatermarkNetworkOffset(code, displacementAt);
    std::memcpy(&delta, &raw, 4);
    auto signedAddress = std::int64_t(fn) + std::int64_t(nextInstruction) + delta;
    if (signedAddress <= 0)
        return false;
    address = std::uintptr_t(signedAddress);
    return WatermarkNetworkRange(module, address, sizeof(value), false) && read(address, value);
}

template <class Reader>
WatermarkNetworkRaw WatermarkReadNetworkWarnings(Reader&& read, const WatermarkKdModule& engine,
                                                 const WatermarkKdModule& network, std::uintptr_t global) {
    WatermarkNetworkRaw out;
    std::uintptr_t client = 0, channel = 0, clientTable = 0, channelTable = 0, current = 0, fn = 0;
    std::array<unsigned char, 96> layout{};
    if (!global || !read(global, client) || !client ||
        !WatermarkNetworkCode(read, engine, client, 38, layout, fn) ||
        !WatermarkChannelLayout(layout.data(), layout.size()) || !read(client + 0xF0, channel) || !channel ||
        !read(client, clientTable) || !read(channel, channelTable))
        return out;
    out.client = client;
    out.channel = channel;
    out.packetLoss = WatermarkNetworkFlowGetter(read, network, channel, 12, true);
    out.latePackets = WatermarkNetworkFlowGetter(read, network, channel, 13, true);
    out.jitter = WatermarkNetworkFlowGetter(read, network, channel, 14, false);
    auto first = WatermarkNetworkFloatGetter(read, engine, client, 68),
         second = WatermarkNetworkFloatGetter(read, engine, client, 69);
    if (first && second)
        out.delivery = WatermarkDelivery{WatermarkDeliveryPercent(*first), WatermarkDeliveryPercent(*second)};
    std::array<unsigned char, 42> remote{};
    if (WatermarkNetworkCode(read, network, channel, 21, remote, fn) &&
        WatermarkKdMatches(remote.data(), remote.size(), WatermarkRemoteFramePattern).size() == 1) {
        auto a = WatermarkNetworkOffset(remote, 7), b = WatermarkNetworkOffset(remote, 20);
        float avg = 0, deviation = 0;
        if (a <= 0x1000000 && b <= 0x1000000 && read(channel + a, avg) && read(channel + b, deviation)) {
            avg = WatermarkNetworkNonnegative(avg) * 1000.f;
            deviation = WatermarkNetworkNonnegative(deviation) * 1000.f;
            if (std::isfinite(avg) && std::isfinite(deviation))
                out.remoteFrame = WatermarkDelivery{avg, deviation};
        }
    }
    std::array<unsigned char, 28> age{};
    std::array<unsigned char, 54> timeout{};
    std::uintptr_t ageFn = 0, timeFn = 0;
    if (WatermarkNetworkCode(read, network, channel, 20, age, ageFn) &&
        WatermarkKdMatches(age.data(), age.size(), WatermarkLastReceivePattern).size() == 1 &&
        WatermarkNetworkCode(read, network, channel, 8, timeout, timeFn) &&
        WatermarkKdMatches(timeout.data(), timeout.size(), WatermarkTimingOutPattern).size() == 1) {
        auto lastOffset = WatermarkNetworkOffset(age, 15), timeoutOffset = WatermarkNetworkOffset(timeout, 4);
        double clock = 0, last = 0, duration = 0, otherClock = 0;
        float sentinel = 0, timeoutValue = 0;
        std::uintptr_t clockAt = 0, otherClockAt = 0, unused = 0;
        if (lastOffset <= 0x1000000 && timeoutOffset <= 0x1000000 &&
            lastOffset == WatermarkNetworkOffset(timeout, 26) &&
            WatermarkNetworkRipRead(read, network, ageFn, age, 4, 8, clock, clockAt) &&
            read(channel + lastOffset, last) && read(channel + timeoutOffset, timeoutValue) &&
            WatermarkNetworkRipRead(read, network, timeFn, timeout, 11, 15, sentinel, unused) &&
            WatermarkNetworkRipRead(read, network, timeFn, timeout, 34, 38, duration, unused) &&
            WatermarkNetworkRipRead(read, network, timeFn, timeout, 42, 46, otherClock, otherClockAt) &&
            clockAt == otherClockAt && std::isfinite(sentinel) && std::isfinite(duration) && duration >= 0) {
            float seconds = WatermarkNetworkNonnegative(float(clock - last));
            out.connection =
                WatermarkConnectionStatus{seconds, timeoutValue != sentinel && otherClock > last + duration};
        }
    }

    if (!read(global, current) || current != client || !read(client + 0xF0, current) || current != channel ||
        !read(client, current) || current != clientTable || !read(channel, current) ||
        current != channelTable)
        return {};
    return out;
}
}
