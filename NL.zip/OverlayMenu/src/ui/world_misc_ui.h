#pragma once
#include "hud_color_picker.h"
#include <iomanip>
#include <sstream>
#include "world_tooltip.h"
#include "world_misc_presentation.h"
#include "world_ambience_ui.h"
namespace menu {

struct WorldMiscUI {
    enum { Surface, Opener, Toggle, Slider, Select, Option, Swatch, Scroll, Details, RowHover };
    struct Hit {
        Box box;
        int kind, index = -1, option = -1;
        Box control{};
        int Key() const {
            return (kind == RowHover ? Slider : kind) * 10000 + (index + 2) * 32 + option + 1;
        }
    };
    PresetsUI paint;
    LanguageCatalog* languages = nullptr;
    HudColorPicker picker;

    WorldAmbienceUI ambience;
    Box overlayArea{};
    std::vector<Hit> hits;
    std::array<Box, 6> mainRows{};
    std::array<Box, WorldMiscSpecs.size()> rows{}, sliders{}, toggles{}, details{};

    struct PopupTransition {
        PresetMotion motion;
        std::vector<PresetLayer> cached;
    };
    std::map<int, PopupTransition> transitions;
    struct Marquee {
        float offset = 0, hoverTime = 0, overflow = 0, fullWidth = 0;
        int stableFrames = 0;
        PresetMotion returning;
    };
    std::map<int, Marquee> marquees;
    int hoverField = -1;
    bool TransitionActive(int key) const {
        if (page < 0)
            return false;
        if (key >= 2000)
            return color == key - 2000;
        if (key >= 1000)
            return choice == key - 1000;
        if (context == key)
            return true;
        for (const auto& p : contextParents)
            if (p.index == key)
                return true;
        return false;
    }
    void StartTransition(int key) {
        auto& t = transitions[key];
        if (!t.motion.initialized)
            t.motion.Snap(0);
        t.motion.Tick(1, 0);
    }
    void ClearTransient() {
        transitions.clear();
        marquees.clear();
        hoverField = -1;
    }
    std::map<int, PresetMotion> fills;
    std::array<PresetMotion, WorldMiscSpecs.size()> available, checked, sliderTip, fieldVisibility;
    PresetMotion groupFade, popupFade, tipFade;
    PresetLayer lastTip{};
    bool tipStored = false, visible = false, blocked = false, selectAll = false;
    struct ContextParent {
        int index;
        Box anchor;
        float scroll;
    };
    std::vector<ContextParent> contextParents;
    int colorCount = 1;
    int context = -1, embedded = -1;
    Box contextAnchor{}, contextPopup{}, contextBody{}, pickerBox{};
    float detailScroll = 0, detailMaxScroll = 0;
    std::map<int, PresetMotion> markers, reveals;
    std::map<int, float> markerTargets, revealTargets;
    int page = -1, faded = -1, choice = -1, color = -1, held = -1, focus = -1, drag = -1, editing = -1,
        hover = -1;
    float mainScroll = 0, mainMaxScroll = 0;
    float scale = 1, F = 18, mouseX = -1, mouseY = -1, scroll = 0, maxScroll = 0, hoverSeconds = 0;
    std::string numeric;
    Box card{}, popup{}, body{}, anchor{}, choiceBox{}, colorAnchor{};
    int detachedRoot = -1;
    bool searchSuppressRoot = false;
    std::size_t searchLayerStart = 0;
    void OpenDetached(int root, float x, float y) {
        Close(false);
        detachedRoot = root;
        Open(0);
        anchor = {x, y, 0, 0};
        visible = true;
        blocked = false;
    }
    static constexpr std::array<const char*, 6> Keys{
        {"menu_windows", "visuals_world_miscellaneous_removals", "visuals_world_miscellaneous_ambience",
         "visuals_world_miscellaneous_hitmarker", "visuals_world_miscellaneous_bullettracers",
         "visuals_world_miscellaneous_bulletimpacts"}};
    WorldMiscUI() {
        groupFade.Snap(0);
        popupFade.Snap(0);
    }
    std::u32string Label(const std::string& k) const {
        if (languages)
            return languages->Label(k);
        auto it = DefaultLanguageStrings().find(k);
        return DecodeUTF8(it == DefaultLanguageStrings().end() ? k : it->second);
    }
    bool Active() const {
        return page >= 0 || color >= 0 || ambience.Active();
    }
    bool Capturing() const {
        return held >= 0 || drag >= 0 || picker.held >= 0 || ambience.Capturing();
    }
    bool Editing() const {
        return editing >= 0 || (color >= 0 && picker.field >= 0) || ambience.Editing();
    }
    bool Enabled(int i, const Settings& cfg) const {
        if (!WorldMiscFieldVisible(i, cfg))
            return false;
        const auto& d = WorldMiscSpecs[std::size_t(i)];
        if (((i >= 32 && i <= 37) || (i >= 40 && i <= 45) || (i >= 48 && i <= 53)) &&
            cfg.worldMisc.value[54] != 0)
            return false;
        if (i == 1 || i == 2)
            return true;
        if (d.parent < 0)
            return true;
        const auto& p = WorldMiscSpecs[std::size_t(d.parent)];
        if (std::string(p.id) == "ragdolls")
            return cfg.worldMisc.value[std::size_t(d.parent)] == 2;
        return cfg.worldMisc.value[std::size_t(d.parent)] != 0 && Enabled(d.parent, cfg);
    }
    std::vector<std::u32string> Options(int i) const {
        std::vector<std::u32string> r;
        std::istringstream stream(WorldMiscSpecs[std::size_t(i)].options);
        std::string part;
        while (std::getline(stream, part, '|'))
            r.push_back(Label(std::string(WorldMiscSpecs[std::size_t(i)].key) + "_" + part));
        return r;
    }
    void CloseContext() {
        if (context >= 0)
            transitions[context].motion.Tick(0, 0);
        choice = editing = -1;
        CancelInput();
        if (contextParents.empty()) {
            context = -1;
            return;
        }
        auto parent = contextParents.back();
        contextParents.pop_back();
        context = parent.index;
        contextAnchor = parent.anchor;
        detailScroll = parent.scroll;
    }
    void OpenContext(int i, Box at) {
        if (context == i) {
            CloseContext();
            return;
        }
        if (context >= 0)
            contextParents.push_back({context, contextAnchor, detailScroll});
        context = i;
        StartTransition(i);
        contextAnchor = at;
        detailScroll = 0;
        choice = editing = -1;
        CancelInput();
    }
    void CancelInput() {
        held = drag = -1;
        picker.held = -1;
    }

    bool EmbeddedInput(float x, float y) const {
        return embedded >= 0 && context == embedded && picker.held < 0 && picker.field < 0 &&
               (held >= 0 || drag >= 0 || contextPopup.Contains(x, y));
    }
    void CloseEmbedded() {
        if (embedded >= 0 && context == embedded)
            CloseContext();
        embedded = -1;
    }
    void Close(bool animate = true, bool overlay = true) {
        if (overlay)
            ambience.Close(animate);
        if (!animate)
            ClearTransient();
        if (page >= 0 && animate)
            faded = page;
        else if (!animate) {
            faded = -1;
            popupFade.Snap(0);
        }
        contextParents.clear();
        embedded = -1;
        context = page = choice = color = editing = focus = -1;
        numeric.clear();
        CancelInput();
    }
    void Open(int p) {
        if (p == 2) {
            Close(false, false);
            ambience.Open();
            return;
        }
        ambience.Close(false);
        ClearTransient();
        page = p;
        contextParents.clear();
        context = embedded = -1;
        faded = -1;
        choice = color = editing = -1;
        scroll = 0;
        anchor = {mouseX >= 0 ? mouseX + 1 : card.x + card.w + 8 * scale, mouseY >= 0 ? mouseY + 1 : card.y,
                  0, 0};
        popupFade.Snap(0);
        CancelInput();
    }
    int HitAt(float x, float y) const {
        if (!visible || blocked)
            return -1;
        for (int i = int(hits.size()) - 1; i >= 0; --i)
            if (hits[std::size_t(i)].box.Contains(x, y))
                return i;
        return -1;
    }
    float Motion(const Hit& h) const {
        auto it = fills.find(h.Key());
        return it == fills.end() ? 0 : it->second.value;
    }
    std::string Number(int i, const Settings& c) const {
        std::ostringstream o;
        if (WorldMiscSpecs[std::size_t(i)].kind == WorldKind::Decimal)
            o << std::fixed << std::setprecision(2);
        o << c.worldMisc.value[std::size_t(i)];
        return o.str();
    }
    Settings ColorSettings(const Settings& cfg) const {
        Settings c = cfg;
        if (color >= 0)
            for (int n = 0; n < colorCount; ++n)
                c.worldHud.colors[std::size_t(colorCount > 1 ? 5 + n : 4)] =
                    cfg.worldMisc.colors[std::size_t(color + n)];
        return c;
    }
    void SyncColor(Settings& cfg, const Settings& c) {
        if (color >= 0)
            for (int n = 0; n < colorCount; ++n)
                cfg.worldMisc.colors[std::size_t(color + n)] =
                    c.worldHud.colors[std::size_t(colorCount > 1 ? 5 + n : 4)];
    }

    void SyncVisibility(const Settings& cfg, float dt) {
        for (std::size_t i = 0; i < fieldVisibility.size(); ++i)
            fieldVisibility[i].Tick(WorldMiscFieldVisible(int(i), cfg) ? 1.f : 0.f, dt);
        if (choice >= 0 && !WorldMiscFieldVisible(choice, cfg))
            choice = -1;
        if (color >= 18 && color <= 20 && !WorldMiscFieldVisible(94, cfg)) {
            color = -1;
            picker.held = picker.field = -1;
            CancelInput();
        }
        if (editing >= 0 && !WorldMiscFieldVisible(editing, cfg)) {
            editing = -1;
            numeric.clear();
        }
        auto stale = [&](int key) {
            if (key < 0)
                return false;
            for (const auto& h : hits)
                if (h.Key() == key) {
                    if (h.kind == Swatch)
                        return h.index >= 18 && h.index <= 20 && !WorldMiscFieldVisible(94, cfg);
                    return h.index >= 0 && !WorldMiscFieldVisible(h.index, cfg);
                }
            return false;
        };
        if (stale(held) || (drag >= 0 && !WorldMiscFieldVisible(drag, cfg)))
            CancelInput();
        if (stale(focus))
            focus = -1;
    }
    float FieldAmount(int i) const {
        return fieldVisibility[std::size_t(i)].value;
    }
    float BlockRows(const WorldMiscBlock& b) const {
        float n = b.colors ? 1.f : 0.f;
        for (int i : b.fields)
            n += FieldAmount(i);
        return n;
    }
    void Tick(float dt, const Settings& cfg) {
        ambience.Tick(dt, cfg);
        SyncVisibility(cfg, dt);
        groupFade.Tick(visible ? 1.f : 0.f, dt);
        popupFade.Tick(page >= 0 ? 1.f : 0.f, dt);
        if (page < 0 && popupFade.value < .001f)
            faded = -1;
        for (auto& e : markers)
            e.second.Tick(markerTargets[e.first], dt);
        for (auto& e : reveals)
            e.second.Tick(revealTargets[e.first], dt);
        for (auto& entry : transitions)
            entry.second.motion.Tick(TransitionActive(entry.first) ? 1.f : 0.f, dt);
        if (!visible || blocked)
            return;
        int h = HitAt(mouseX, mouseY);
        int key = h >= 0 ? hits[std::size_t(h)].Key() : -1;
        int field = h >= 0 ? hits[std::size_t(h)].index : -1;
        if (h >= 0 && (hits[std::size_t(h)].kind == Swatch || hits[std::size_t(h)].kind == Surface))
            field = -1;
        for (auto& entry : marquees) {
            auto& m = entry.second;
            bool over = entry.first == field && m.overflow > 0;
            if (over) {
                m.hoverTime = hoverField == field ? m.hoverTime + std::max(0.f, dt) : 0.f;
                if (m.stableFrames >= 5 && m.hoverTime > .3f) {
                    m.offset += 40 * scale * std::max(0.f, dt);
                    if (m.offset >= m.fullWidth + 20 * scale)
                        m.offset = m.overflow;
                }
                m.returning.Snap(m.offset);
            } else {
                m.hoverTime = 0;
                m.returning.Tick(0, dt, .25f);
                m.offset = m.returning.value;
            }
        }
        hoverField = field;
        for (const auto& t : hits)
            fills.try_emplace(t.Key());
        for (auto& kv : fills)
            kv.second.Tick(kv.first == held ? 1.f : kv.first == key ? .5f : 0.f, dt);
        for (std::size_t i = 0; i < available.size(); ++i) {
            available[i].Tick(Enabled(int(i), cfg) ? 1.f : .5f, dt);
            checked[i].Tick(cfg.worldMisc.value[i] != 0 ? 1.f : 0.f, dt);
            sliderTip[i].Tick(
                page >= 0 && choice < 0 && editing < 0 &&
                        (context < 0 || contextBody.Contains(mouseX, mouseY)) && Enabled(int(i), cfg) &&
                        (drag == int(i) || (sliders[i].w > 0 && sliders[i].Contains(mouseX, mouseY)))
                    ? 1.f
                    : 0.f,
                dt);
        }
        if (color >= 0)
            picker.Tick(dt);
        hoverSeconds += std::max(0.f, dt);
    }
    void Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        if (ambience.Active()) {
            ambience.Move(x, y, cfg);
            return;
        }
        int h = HitAt(x, y);
        if (h != hover) {
            hover = h;
            hoverSeconds = 0;
        }
        if (drag >= 0) {
            auto b = sliders[std::size_t(drag)];
            const auto& d = WorldMiscSpecs[std::size_t(drag)];
            cfg.worldMisc.Set(std::size_t(drag),
                              d.minimum + (d.maximum - d.minimum) *
                                              std::clamp((x - b.x) / std::max(1.f, b.w - 1), 0.f, 1.f));
        }
        if (color >= 0) {
            auto c = ColorSettings(cfg);
            picker.Move(x, y, c);
            SyncColor(cfg, c);
        }
    }
    bool Commit(Settings& cfg) {
        if (editing < 0)
            return true;
        try {
            std::size_t n = 0;
            float v = std::stof(numeric, &n);
            if (n != numeric.size() || !std::isfinite(v))
                return false;
            if (Enabled(editing, cfg))
                cfg.worldMisc.Set(std::size_t(editing), v);
            editing = -1;
            numeric.clear();
            return true;
        } catch (...) {
            return false;
        }
    }
    void Activate(const Hit& h, Settings& cfg) {
        SyncVisibility(cfg, 0);
        if (h.kind == Swatch) {
            if (h.index >= 18 && h.index <= 20 && !WorldMiscFieldVisible(94, cfg))
                return;
        } else if (h.index >= 0 && !WorldMiscFieldVisible(h.index, cfg))
            return;
        if (h.kind == Details) {
            OpenContext(h.index, {h.box.x + h.box.w + 7 * scale, h.box.y, 0, 0});
        } else if (h.kind == Opener) {
            if (page == h.index)
                Close();
            else
                Open(h.index);
        } else if (h.kind == Swatch) {
            color = h.index;
            StartTransition(2000 + color);
            colorCount = std::clamp(h.option, 1, 3);
            colorAnchor = h.box;
            picker.Reset(colorCount > 1 ? 5 : 4, false, colorCount > 1);
            if (colorCount > 1) {
                std::array<std::string, 3> labels{};
                if (color == 12) {
                    labels[0] = "visuals_world_miscellaneous_bulletimpacts_clientcolor";
                    labels[1] = "visuals_world_miscellaneous_bulletimpacts_servercolor";
                }
                if (color == 14) {
                    labels[0] = "visuals_world_miscellaneous_bulletimpacts_sparks_color";
                    labels[1] = "visuals_world_miscellaneous_bulletimpacts_sparks_glow";
                }
                picker.ConfigureEntries(colorCount, labels);
            }
            embedded = -1;
            if (context < 0 && page >= 0) {
                const int owner = WorldMiscPickerContext(color);
                if (owner >= 0) {
                    OpenContext(owner, {colorAnchor.x + colorAnchor.w + 7 * scale, colorAnchor.y, 0, 0});
                    embedded = owner;
                }
            }
        } else if (h.index >= 0 && Enabled(h.index, cfg)) {
            if (h.kind == Toggle &&
                !(h.index >= 103 && h.index < 126 && cfg.worldMisc.value[std::size_t(h.index)] != 0 &&
                  std::count_if(
                      cfg.worldMisc.value.begin() + 103, cfg.worldMisc.value.begin() + 126,
                      [](float v) { return v != 0; }) < 2))
                cfg.worldMisc.Set(std::size_t(h.index),
                                  cfg.worldMisc.value[std::size_t(h.index)] == 0 ? 1 : 0);
            if (h.kind == Select) {
                choice = choice == h.index ? -1 : h.index;
                if (choice >= 0)
                    StartTransition(1000 + choice);
                choiceBox = h.control;
            }
            if (h.kind == Option) {
                cfg.worldMisc.Set(std::size_t(h.index), float(h.option));
                choice = -1;
            }
        }
    }
    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        if (ambience.Active())
            return ambience.Click(x, y, down, cfg, ctrl);
        mouseX = x;
        mouseY = y;
        if (color >= 0 && !EmbeddedInput(x, y)) {
            if (down && editing >= 0 && !Commit(cfg))
                editing = -1;
            auto c = ColorSettings(cfg);
            bool consumed = picker.Click(x, y, down, c);
            SyncColor(cfg, c);
            if (!consumed && down) {
                color = -1;
                CancelInput();
                CloseEmbedded();
            }
            return true;
        }
        int n = HitAt(x, y);
        if (down) {
            if (n < 0)
                return false;
            auto h = hits[std::size_t(n)];
            if (h.kind == Surface) {
                if (choice >= 0)
                    choice = -1;
                else if (context >= 0 && !contextPopup.Contains(x, y)) {
                    CloseContext();
                } else if (!popup.Contains(x, y) && context < 0)
                    Close();
                return true;
            }
            if (editing >= 0 && !Commit(cfg))
                return true;
            held = h.Key();
            focus = held;
            if (h.kind == Slider && Enabled(h.index, cfg)) {
                if (ctrl) {
                    editing = h.index;
                    numeric = Number(editing, cfg);
                    selectAll = true;
                } else {
                    drag = h.index;
                    Move(x, y, cfg);
                }
            }
            return true;
        }
        bool consumed = held >= 0 || drag >= 0;
        if (n >= 0 && held == hits[std::size_t(n)].Key() && drag < 0 && editing < 0)
            Activate(hits[std::size_t(n)], cfg);
        CancelInput();
        return consumed;
    }
    bool Key(int k, Settings& cfg, bool shift = false, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        if (ambience.Active())
            return ambience.Key(k, cfg, shift, ctrl);
        if (color >= 0 && !(embedded >= 0 && editing >= 0)) {
            auto c = ColorSettings(cfg);
            if (picker.Key(k, c, ctrl)) {
                SyncColor(cfg, c);
                return true;
            }
            if (k == 27) {
                color = -1;
                CloseEmbedded();
            }
            return true;
        }
        if (editing >= 0) {
            if (k == 27)
                editing = -1;
            else if (k == 13)
                Commit(cfg);
            else if (ctrl && k == 'A')
                selectAll = true;
            else if (k == 8 || k == 46) {
                if (selectAll)
                    numeric.clear();
                else if (!numeric.empty())
                    numeric.pop_back();
                selectAll = false;
            }
            return true;
        }
        if (k == 27 && Active()) {
            if (choice >= 0)
                choice = -1;
            else if (context >= 0)
                CloseContext();
            else
                Close();
            return true;
        }
        if (k == 9) {
            std::vector<int> v;
            for (const auto& h : hits)
                if (h.kind != Surface && h.kind != RowHover && (page < 0 || h.kind != Opener))
                    v.push_back(h.Key());
            if (v.empty())
                return Active();
            auto it = std::find(v.begin(), v.end(), focus);
            int i =
                it == v.end() ? 0 : (int(it - v.begin()) + (shift ? -1 : 1) + int(v.size())) % int(v.size());
            focus = v[std::size_t(i)];
            return true;
        }
        for (const auto& h : hits)
            if (h.Key() == focus) {
                if (h.kind == Slider && (k == 37 || k == 39) && Enabled(h.index, cfg))
                    cfg.worldMisc.Set(
                        std::size_t(h.index),
                        cfg.worldMisc.value[std::size_t(h.index)] +
                            (k == 37 ? -1 : 1) *
                                (WorldMiscSpecs[std::size_t(h.index)].kind == WorldKind::Decimal ? .01f : 1));
                else if (k == 13 || k == 32)
                    Activate(h, cfg);
                else
                    return Active();
                return true;
            }
        return Active();
    }
    bool Character(char16_t c) {
        if (ambience.Active())
            return ambience.Character(c);
        if (color >= 0 && !(embedded >= 0 && editing >= 0))
            return picker.Character(c);
        if (editing < 0)
            return false;
        if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.') {
            if (selectAll) {
                numeric.clear();
                selectAll = false;
            }
            if (numeric.size() < 24)
                numeric += char(c);
        }
        return true;
    }
    bool Wheel(float delta, Settings& cfg) {
        if (!visible || blocked)
            return false;
        if (ambience.Active())
            return ambience.Wheel(delta, cfg);
        if (!Active()) {
            if (card.Contains(mouseX, mouseY) && mainMaxScroll > 0) {
                mainScroll = std::clamp(mainScroll - delta * 30 * scale, 0.f, mainMaxScroll);
                return true;
            }
            return false;
        }
        if (color >= 0 && !(embedded >= 0 && context == embedded && contextPopup.Contains(mouseX, mouseY)))
            return true;
        for (std::size_t i = 0; i < sliders.size(); ++i)
            if ((context < 0 || contextBody.Contains(mouseX, mouseY)) && sliders[i].w > 0 &&
                sliders[i].Contains(mouseX, mouseY) && Enabled(int(i), cfg)) {
                cfg.worldMisc.Set(i, cfg.worldMisc.value[i] + delta);
                return true;
            }
        if (context >= 0)
            detailScroll = std::clamp(detailScroll - delta * 30 * scale, 0.f, detailMaxScroll);
        else
            scroll = std::clamp(scroll - delta * 30 * scale, 0.f, maxScroll);
        return true;
    }
    bool Context(float x, float y, Settings& cfg) {
        if (!visible || blocked)
            return false;
        if (ambience.Active())
            return ambience.Context(x, y, cfg);
        if (color >= 0)
            return false;
        int n = HitAt(x, y);
        if (n < 0)
            return Active();
        const auto& h = hits[std::size_t(n)];
        if (h.kind != Toggle && h.kind != Select && h.kind != Details)
            return Active();
        if (!WorldMiscHasContext(h.index))
            return Active();
        OpenContext(h.index, {h.box.x + h.box.w + 7 * scale, h.box.y, 0, 0});
        (void)cfg;
        return true;
    }
    void Measure(Fonts& fonts, const Settings& cfg, Box position, int width, int height, bool shown,
                 bool modalBlocked) {
        SyncVisibility(cfg, 0);
        visible = shown;
        blocked = modalBlocked;
        scale = cfg.scale;
        F = fonts.PixelHeight(0, 13 * scale);
        paint.layers.clear();
        hits.clear();
        rows.fill({});
        sliders.fill({});
        toggles.fill({});
        details.fill({});

        if (!visible) {
            Close(false);
            ambience.visible = false;
            return;
        }
        if (blocked) {
            Close(false, false);
            hover = -1;
        }
        if (editing >= 0 && !Enabled(editing, cfg))
            editing = -1;
        if (drag >= 0 && !Enabled(drag, cfg))
            CancelInput();
        const float s = scale, H = F + 6 * s, R = F + 14 * s;
        auto pal = CurrentPalette(cfg);
        auto alpha = [](Color c, float a) {
            c.a *= a;
            return c;
        };
        Box localClip{};
        auto tw = [&](const std::u32string& t, int font = 0) {
            return std::trunc(fonts.NativeTextSize(font, 13 * s, t).w + .95f);
        };
        auto upper = [](std::u32string t) {
            for (auto& c : t)
                if (c >= U'a' && c <= U'z')
                    c -= 32;
            return t;
        };
        auto layer = [&](Box b, bool pop = false, float radius = 0) {
            paint.layers.push_back({b, radius, pop, {}});
            return int(paint.layers.size()) - 1;
        };
        auto rect = [&](int z, Box b, Color c, float radius = 0, float stroke = 0) {
            if (b.w <= 0 || b.h <= 0)
                return;
            PresetDraw d{b, c, radius, stroke, 15, {}, false};
            d.clipped = true;
            d.clip = paint.layers[std::size_t(z)].box;
            if (localClip.w > 0)
                d.clip = PresetIntersect(d.clip, localClip);
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto text = [&](int z, Box b, const std::u32string& t, Color c, int font = 0, float px = 13) {
            if (t.empty() || b.w <= 0 || b.h <= 0)
                return;
            PresetDraw d{b, c, 0, 0, 15, t, font == 3};
            d.font = font;
            d.textSize = px;
            d.clipped = true;
            d.clip = paint.layers[std::size_t(z)].box;
            if (localClip.w > 0)
                d.clip = PresetIntersect(d.clip, localClip);
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto hit = [&](Box b, int kind, int i = -1, int opt = -1, Box control = Box{}) {
            if (blocked)
                return;
            if (localClip.w > 0)
                b = PresetIntersect(b, localClip);
            if (b.w > 0 && b.h > 0)
                hits.push_back({b, kind, i, opt, control});
        };
        auto shape = [&](int z, Box b) {
            rect(z, b, pal[40], 15 * s);
            rect(z, b, pal[11], 15 * s, s);
        };
        auto surface = [&](Box b) {
            int z = layer(b, true, 15 * s);
            rect(z, b, pal[8], 15 * s);
            rect(z, b, pal[11], 15 * s, s);
            return z;
        };
        auto line = [&](int z, float x, float y, float w) {
            rect(z, {x, y, w, s}, pal[34]);
            paint.layers[std::size_t(z)].draw.back().pixelLine = true;
        };
        auto fadeLayers = [&](std::size_t begin, float amount) {
            for (std::size_t n = begin; n < paint.layers.size(); ++n) {
                paint.layers[n].opacity *= amount;
                for (auto& d : paint.layers[n].draw)
                    d.color.a *= amount;
            }
        };
        auto rememberTransition = [&](int key, std::size_t begin) {
            auto& t = transitions[key];
            if (!t.motion.initialized)
                t.motion.Snap(0);
            t.cached.assign(paint.layers.begin() + std::ptrdiff_t(begin), paint.layers.end());
            fadeLayers(begin, t.motion.value);
        };
        bool acceptingColors = false;
        auto sample = [&](int z, float right, float y, int idx, float a, int count = 1, float rowHeight = 0) {
            Box b{right - 16 * s, y + ((rowHeight > 0 ? rowHeight : R) - 16 * s) * .5f, 16 * s, 16 * s};
            Hit h{b, Swatch, idx, count};
            rect(z, {b.x - 3 * s, b.y - 3 * s, b.w + 6 * s, b.h + 6 * s}, alpha(pal[33], .4f * Motion(h) * a),
                 6 * s);
            auto image = std::make_shared<Canvas>(int(std::ceil(b.w)), int(std::ceil(b.h)));
            Color c = cfg.worldMisc.colors[std::size_t(idx)];
            Color last = cfg.worldMisc.colors[std::size_t(idx + count - 1)];
            bool gradient = count > 1 && idx != 0;
            DrawPickerPreview(*image, {0, 0, b.w, b.h}, s, H, c, last, gradient, false);
            PresetDraw d{b, {1, 1, 1, a}, 0, 0, 15, {}, false};
            d.raster = image;
            d.rasterStamp = PickerPreviewStamp(c, last, gradient, false);
            d.clipped = true;
            d.clip = paint.layers[std::size_t(z)].box;
            if (localClip.w > 0)
                d.clip = PresetIntersect(d.clip, localClip);
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
            if (acceptingColors)
                hit(b, Swatch, idx, count);
            return b;
        };
        float hf = fonts.PixelHeight(0, 10 * s), fullMain = 14 * s + 6 * H + 5 * 15 * s;
        if (detachedRoot < 0 && !searchSuppressRoot) {
            float mainHeight =
                position.h > 0 ? std::min(fullMain, std::max(2 * H, position.h - hf - 5 * s)) : fullMain;
            mainMaxScroll = fullMain - mainHeight;
            mainScroll = std::clamp(mainScroll, 0.f, mainMaxScroll);
            card = {position.x, position.y + hf + 5 * s, position.w, mainHeight};
            int z = layer({position.x, position.y, card.w, card.h + hf + 5 * s});
            text(z, {card.x + 14 * s, position.y, card.w - 28 * s, hf},
                 upper(Label("group_visuals_world_miscellaneous")), pal[3], 0, 10);
            shape(z, card);
            for (int n = 0; n < 6; ++n) {
                Box b{card.x + 14 * s, card.y + 7 * s + n * (H + 15 * s) - mainScroll, card.w - 28 * s, H};
                mainRows[std::size_t(n)] = b;
                localClip = card;
                if (n)
                    line(z, b.x, b.y - 8 * s, b.w);
                Hit h{{b.x - 13 * s, b.y - 6 * s, b.w + 26 * s, b.h + 12 * s}, Opener, n};
                rect(z, h.box, alpha(pal[33], .15f * Motion(h)), 15 * s);
                paint.layers[std::size_t(z)].draw.back().corners = n == 0 ? 3u : n == 5 ? 12u : 0u;
                text(z, {b.x, b.y + 3 * s, b.w - 24 * s, F}, Label(Keys[std::size_t(n)]), pal[0]);
                text(z, {b.x + b.w - 16 * s, b.y + 3 * s, 10 * s, F}, U"\uf105", pal[14], 3);
                hit(h.box, Opener, n);
                localClip = {};
            }
            for (auto& d : paint.layers[0].draw)
                d.color.a *= groupFade.value;
            if (mainMaxScroll > 0) {
                float h = std::max(10 * s, card.h * card.h / fullMain);
                rect(z,
                     {card.x + card.w - 4 * s, card.y + (card.h - h) * mainScroll / mainMaxScroll, 2 * s, h},
                     pal[25], s);
            }
        }
        if (embedded >= 0 && (color < 0 || context != embedded)) {
            if (context == embedded)
                CloseContext();
            embedded = -1;
        }
        pickerBox = {};
        if (color >= 0 && page >= 0) {
            picker.languages = languages;
            picker.SetMetrics(fonts, s);
            pickerBox = PresetPopupFit(
                {colorAnchor.x + colorAnchor.w + 7 * s, colorAnchor.y, 265 * s, picker.Height(s)}, width,
                height);
            if (embedded == 55 || embedded == 63) {
                const float windowF = F, windowR = windowF + 14 * s;
                float detailsHeight = 14 * s;
                for (const auto& block : WorldMiscBlocks(page, embedded))
                    detailsHeight += 14 * s + windowR * BlockRows(block) + 7 * s;
                const float available = std::max(1.f, float(height) - 12 * s);
                const float totalHeight = std::min(available, pickerBox.h + detailsHeight);
                pickerBox.y =
                    std::clamp(pickerBox.y, 6 * s, std::max(6 * s, float(height) - 6 * s - totalHeight));
                contextAnchor = {pickerBox.x, pickerBox.y + pickerBox.h, 0, 0};
            } else if (embedded >= 0) {
                contextAnchor = {pickerBox.x, pickerBox.y + pickerBox.h + 7 * s, 0, 0};
            }
        }
        const int shownPage = page >= 0 ? page : faded;
        const std::size_t popupBegin = paint.layers.size();
        searchLayerStart = popupBegin;
        auto drawWindow = [&](int ctx, Box requested, bool interactive) {
            const std::size_t transitionBegin = paint.layers.size();
            bool rootWindow = ctx < 0 || ctx == detachedRoot;
            acceptingColors = interactive && page >= 0;
            const float windowF = shownPage == 0 ? 17 * s : F, windowR = windowF + 14 * s;
            auto blocks = WorldMiscBlocks(shownPage, ctx);
            float total = 0;
            std::vector<float> amounts;
            for (std::size_t n = 0; n < blocks.size(); ++n) {
                const auto& b = blocks[n];
                float a = 1;
                if (b.reveal >= 0) {
                    revealTargets[b.reveal] = cfg.worldMisc.value[std::size_t(b.reveal)] != 0 ? 1.f : 0.f;
                    auto it = reveals.try_emplace(b.reveal).first;
                    if (!it->second.initialized)
                        it->second.Snap(revealTargets[b.reveal]);
                    a = it->second.value;
                }
                amounts.push_back(a);
                total += (14 * s + windowR * BlockRows(b) + 7 * s + (b.title.empty() ? 0 : hf + 5 * s) +
                          (b.separatorAt >= 0 ? 14 * s : 0)) *
                         a;
            }
            float windowWidth = rootWindow && detachedRoot >= 0 ? std::trunc(265 * s) : 265 * s;

            for (const auto& block : blocks)
                for (int i : block.fields) {
                    const auto& d = WorldMiscSpecs[std::size_t(i)];
                    if (shownPage == 0 || d.kind == WorldKind::Check || d.kind == WorldKind::Choice)
                        continue;
                    float need = tw(Label(d.key)) + 24 * s + 6 * s + (WorldMiscIcon(i) ? 32 * s : 0);
                    windowWidth = std::max(windowWidth, std::ceil(need / .6f + 28 * s));
                }
            const bool combined = ctx == embedded && (ctx == 55 || ctx == 63) && pickerBox.w > 0;
            const float titleH = combined || ctx == 102 ? 7 * s : windowF + 21 * s;
            if (embedded >= 0 && ctx == embedded && pickerBox.w > 0) {
                windowWidth = std::max(windowWidth, pickerBox.w);
                if (!combined &&
                    requested.y + std::min(titleH + total, std::max(1.f, float(height) - 12 * s)) >
                        float(height) - 6 * s)
                    requested = {pickerBox.x + pickerBox.w + 7 * s, pickerBox.y, 0, 0};
            }
            const float availableHeight = combined ? std::max(1.f, float(height) - 6 * s - requested.y)
                                                   : std::max(1.f, float(height) - 12 * s);
            Box box = PresetPopupFit(
                {requested.x, requested.y, windowWidth, std::min(titleH + total, availableHeight)}, width,
                height);
            Box area{box.x + 7 * s, box.y + titleH, box.w - 14 * s, std::max(0.f, box.h - titleH - 7 * s)};
            float ancestorOffset = 0;
            for (const auto& parent : contextParents)
                if (parent.index == ctx)
                    ancestorOffset = parent.scroll;
            float maximum = std::max(0.f, total - 7 * s - area.h), &offset = rootWindow ? scroll
                                                                             : ctx == context
                                                                                 ? detailScroll
                                                                                 : ancestorOffset;
            offset = std::clamp(offset, 0.f, maximum);
            if (rootWindow) {
                popup = box;
                body = area;
                maxScroll = maximum;
            } else if (ctx == context) {
                contextPopup = box;
                contextBody = area;
                detailMaxScroll = maximum;
            }
            if (interactive) {
                hits.clear();
                hit({0, 0, float(width), float(height)}, Surface);
            }
            Box surfaceBox = box;
            if (combined) {
                surfaceBox.y = pickerBox.y;
                surfaceBox.h = box.y + box.h - pickerBox.y;
            }
            int pz = surface(surfaceBox);
            if (interactive)
                hit(box, Surface);
            auto title =
                ctx < 0 ? Label(Keys[std::size_t(shownPage)]) : Label(WorldMiscSpecs[std::size_t(ctx)].key);

            if (ctx != 102 && !combined)
                text(pz,
                     {box.x + 14 * s, box.y + 7 * s, box.w - 28 * s,
                      fonts.PixelHeight(shownPage == 0 ? 1 : 2, shownPage == 0 ? 14 * s : 13 * s)},
                     title, pal[2], shownPage == 0 ? 1 : 2, shownPage == 0 ? 14 : 13);
            int bz = layer(area);
            float y = area.y - offset;
            for (std::size_t n = 0; n < blocks.size(); ++n) {
                const auto& block = blocks[n];
                float reveal = amounts[n];
                if (reveal <= .001f)
                    continue;
                float full = 14 * s + windowR * BlockRows(block) + (block.title.empty() ? 0 : hf + 5 * s) +
                             (block.separatorAt >= 0 ? 14 * s : 0),
                      bh = full * reveal;
                Box sectionClip = PresetIntersect({area.x, y, area.w, bh}, area);
                localClip = sectionClip;
                float cy = y;
                if (!block.title.empty()) {
                    text(bz, {area.x + 7 * s, cy, area.w - 14 * s, hf}, upper(Label(block.title)),
                         alpha(pal[3], reveal), 0, 10);
                    cy += hf + 5 * s;
                }
                Box cb{area.x, cy, area.w,
                       14 * s + windowR * BlockRows(block) + (block.separatorAt >= 0 ? 14 * s : 0)};
                if (!combined)
                    shape(bz, cb);
                cy += 7 * s;
                int mk = (ctx + 2) * 100 + shownPage * 10 + int(n);
                bool any = false;
                for (int i : block.fields)
                    if (WorldMiscSpecs[std::size_t(i)].kind == WorldKind::Check &&
                        cfg.worldMisc.value[std::size_t(i)] != 0)
                        any = true;
                markerTargets[mk] = any ? 1.f : 0.f;
                auto mi = markers.try_emplace(mk).first;
                if (!mi->second.initialized)
                    mi->second.Snap(markerTargets[mk]);
                float markerW = (tw(U"\uf00c", 3) + 12 * s) * mi->second.value;
                if (block.colors) {
                    Box row{cb.x + 7 * s, cy, cb.w - 14 * s, windowR};
                    localClip = PresetIntersect(sectionClip, row);
                    float right = row.x + row.w - 12 * s;
                    sample(bz, right, cy, 0, reveal, 3, windowR);
                    right -= 19 * s;
                    float iw = tw(U"\uf53f", 3);
                    text(bz, {row.x + 12 * s + (20 * s - iw) * .5f, cy + 7 * s, 20 * s, windowF}, U"\uf53f",
                         alpha(pal[14], reveal), 3);
                    text(bz, {row.x + 44 * s, cy + 7 * s, std::max(0.f, right - row.x - 44 * s), windowF},
                         Label("color"), alpha(pal[14], reveal));
                    cy += windowR;
                }
                int fieldNumber = 0;
                for (int i : block.fields) {
                    float fieldAmount = FieldAmount(i);
                    if (fieldAmount <= .001f) {
                        ++fieldNumber;
                        continue;
                    }
                    bool fieldVisible = WorldMiscFieldVisible(i, cfg);
                    if (fieldNumber++ == block.separatorAt) {
                        localClip = sectionClip;
                        line(bz, cb.x + 7 * s, cy + 7 * s, cb.w - 14 * s);
                        cy += 14 * s;
                    }
                    const auto& d = WorldMiscSpecs[std::size_t(i)];
                    Box row{cb.x + 7 * s, cy, cb.w - 14 * s, windowR};
                    localClip = PresetIntersect(sectionClip, {row.x, row.y, row.w, row.h * fieldAmount});
                    if (fieldVisible)
                        rows[std::size_t(i)] = localClip;
                    bool enabled = Enabled(i, cfg);
                    float a = (available[std::size_t(i)].initialized ? available[std::size_t(i)].value
                               : enabled                             ? 1.f
                                                                     : .5f) *
                              reveal * fieldAmount;
                    int kind = WorldMiscDetailsOnly(i)       ? Details
                               : d.kind == WorldKind::Check  ? Toggle
                               : d.kind == WorldKind::Choice ? Select
                                                             : Slider;
                    Hit h{row, kind, i};
                    float t = enabled ? Motion(h) : 0;
                    rect(bz, row, alpha(pal[33], .4f * t * a), 15 * s / 1.6f);
                    float left = row.x + 12 * s, right = row.x + row.w - 12 * s, labelRight = right;
                    Color ink = alpha(Mix(pal[14], pal[2],
                                          d.kind == WorldKind::Check
                                              ? std::max(t, cfg.worldMisc.value[std::size_t(i)])
                                              : t),
                                      a);

                    bool rightSwitch =
                        (shownPage == 0 || shownPage == 3 || shownPage == 4 || shownPage == 5) &&
                        ctx != 102 && !WorldMiscColorOnly(i) && !WorldMiscDetailsOnly(i);
                    if (d.kind == WorldKind::Check && !WorldMiscColorOnly(i) && !WorldMiscDetailsOnly(i)) {
                        if (rightSwitch) {
                            float nominal = windowF + 2 * s, center = cy + windowR * .5f,
                                  frac = center - std::trunc(center);
                            h.control = {right - 32 * s, center - nominal * .5f + frac, 32 * s,
                                         nominal - 2 * frac};
                            if (fieldVisible)
                                toggles[std::size_t(i)] = PresetIntersect(h.control, localClip);
                            float amount = checked[std::size_t(i)].initialized
                                               ? checked[std::size_t(i)].value
                                               : cfg.worldMisc.value[std::size_t(i)];
                            rect(bz, h.control, alpha(pal[22], a), nominal * .5f);
                            rect(bz, h.control, alpha(pal[23], a * amount), nominal * .5f);
                            float radius = nominal * .5f - 2 * s,
                                  cx = h.control.x + nominal * .5f + (h.control.w - nominal) * amount;
                            rect(bz, {cx - radius, center - radius, 2 * radius, 2 * radius},
                                 alpha(Mix(pal[20], pal[21], amount), a), radius);
                            labelRight = h.control.x - 6 * s;
                        } else {
                            h.control = {left, cy + 7 * s, tw(U"\uf00c", 3), windowF};
                            if (cfg.worldMisc.value[std::size_t(i)] != 0)
                                text(bz, h.control, U"\uf00c", alpha(pal[0], a * mi->second.value), 3);
                            left += markerW;
                        }
                    }
                    char32_t icon = WorldMiscIcon(i);
                    if (icon) {
                        auto glyph = std::u32string(1, icon);
                        float iw = tw(glyph, 3);
                        text(bz, {left + (20 * s - iw) * .5f, cy + 7 * s, 20 * s, windowF}, glyph, ink, 3);
                        left += 32 * s;
                    }
                    if (WorldMiscDetailsOnly(i)) {
                        auto hint = Label("menu_select");
                        float w = tw(hint) + 16 * s;
                        h.control = {right - w, cy, w, windowR};
                        text(bz, {right - w, cy + 7 * s, w - 16 * s + s, windowF}, hint, alpha(pal[14], a));
                        text(bz, {right - 10 * s, cy + 7 * s, 10 * s, windowF}, U"\uf107", alpha(pal[14], a),
                             3);
                        labelRight = right - w - 6 * s;
                    } else if (d.kind == WorldKind::Choice) {
                        auto opts = Options(i);
                        const auto& value = opts[std::size_t(int(cfg.worldMisc.value[std::size_t(i)]))];
                        float valueW = tw(value), arrowW = std::max(10 * s, tw(U"\uf105", 3)),
                              w = valueW + arrowW + 6 * s;
                        h.control = {right - w, cy, w, windowR};
                        text(bz, {right - w, cy + 7 * s, valueW + s, windowF}, value, alpha(pal[14], a));
                        text(bz, {right - 10 * s, cy + 7 * s, 10 * s, windowF}, U"\uf105", alpha(pal[14], a),
                             3);
                        labelRight = right - w - 6 * s;
                    } else if (d.kind != WorldKind::Check) {
                        float w = std::trunc(row.w / 2.5f);
                        Box b{right - w, cy + (windowR - 6 * s) * .5f, w, 6 * s};
                        sliders[std::size_t(i)] = PresetIntersect(b, sectionClip);
                        h.control = b;
                        float v = (cfg.worldMisc.value[std::size_t(i)] - d.minimum) / (d.maximum - d.minimum);
                        rect(bz, b, alpha(pal[24], a), 3 * s);
                        if (v > 0)
                            rect(bz, {b.x, b.y, b.w * v, b.h}, alpha(pal[25], a), 3 * s);
                        labelRight = b.x - 6 * s;
                        if (editing == i) {
                            rect(bz, {b.x, cy, b.w, windowR}, pal[12], 6 * s);
                            text(bz, {b.x + 6 * s, cy + 7 * s, b.w - 12 * s, windowF}, DecodeUTF8(numeric),
                                 pal[2]);
                        }
                    }
                    if (interactive && fieldVisible && !WorldMiscColorOnly(i)) {
                        if (kind == Slider) {
                            hit(row, RowHover, i, -1, h.control);
                            hit({h.control.x, cy, h.control.w, windowR}, kind, i, -1, h.control);
                        } else
                            hit(row, kind, i, -1, h.control);
                    }
                    acceptingColors = interactive && page >= 0 && enabled;
                    if (d.color >= 0 && i != 0) {
                        auto b = sample(bz, labelRight, cy, d.color, a, d.count, windowR);
                        labelRight = b.x - 3 * s;
                    }
                    if (ctx < 0 && WorldMiscDetailsButton(shownPage, i)) {
                        Box more{h.control.x - 29 * s, cy, 22 * s, windowR};
                        details[std::size_t(i)] = PresetIntersect(more, sectionClip);
                        Hit mh{more, Details, i};
                        float amount = context == i ? 1.f : Motion(mh);
                        rect(bz, more, alpha(pal[33], .4f * amount * a), 15 * s / 1.6f);
                        float iw = tw(U"\uf141", 3);
                        text(bz, {more.x + (more.w - iw) * .5f, cy + 7 * s, iw, windowF}, U"\uf141",
                             alpha(Mix(pal[14], pal[2], amount), a), 3);
                        if (interactive)
                            hit(more, Details, i);
                        labelRight = more.x - 4 * s;
                    }

                    Box viewport = PresetIntersect(
                        localClip, {left, cy + 7 * s, std::max(0.f, labelRight - left), windowF});
                    auto label = Label(d.key);
                    float fullWidth = tw(label);
                    auto& marquee = marquees[i];
                    float overflow = std::max(0.f, fullWidth - viewport.w);
                    if (std::abs(overflow - marquee.overflow) > .01f ||
                        std::abs(fullWidth - marquee.fullWidth) > .01f) {
                        marquee.offset = 0;
                        marquee.hoverTime = 0;
                        marquee.stableFrames = 0;
                        marquee.returning.Snap(0);
                    } else
                        marquee.stableFrames = std::min(5, marquee.stableFrames + 1);
                    marquee.overflow = overflow;
                    marquee.fullWidth = fullWidth;
                    Box savedClip = localClip;
                    localClip = viewport;
                    text(bz,
                         {left - marquee.offset, cy + 7 * s, std::max(viewport.w, fullWidth) + s, windowF},
                         label, ink);
                    if (marquee.offset > 0 && marquee.offset >= overflow)
                        text(bz,
                             {left - marquee.offset + fullWidth + 20 * s, cy + 7 * s, fullWidth + s, windowF},
                             label, ink);
                    localClip = savedClip;
                    cy += windowR * fieldAmount;
                }
                localClip = {};
                y += bh + 7 * s * reveal;
            }
            localClip = {};
            if (maximum > 0) {
                float th = std::max(10 * s, area.h * area.h / (area.h + maximum));
                rect(pz, {box.x + box.w - 5 * s, area.y + (area.h - th) * offset / maximum, 4 * s, th},
                     pal[18], 4 * s);
            }
            if (ctx >= 0 && !rootWindow)
                rememberTransition(ctx, transitionBegin);
        };
        if (shownPage >= 0) {
            if (!searchSuppressRoot)
                drawWindow(detachedRoot, anchor, page >= 0 && context < 0);
            for (auto& entry : transitions)
                if (entry.first < 1000 && !TransitionActive(entry.first) &&
                    entry.second.motion.value > .001f) {
                    auto begin = paint.layers.size();
                    paint.layers.insert(paint.layers.end(), entry.second.cached.begin(),
                                        entry.second.cached.end());
                    fadeLayers(begin, entry.second.motion.value);
                }
            if (context >= 0 && page >= 0) {
                for (const auto& parent : contextParents)
                    drawWindow(parent.index, parent.anchor, false);
                drawWindow(context, contextAnchor, true);
            }
        }
        if (choice >= 0 && page >= 0) {
            auto begin = paint.layers.size();
            auto opts = Options(choice);
            float w = choiceBox.w;
            for (const auto& t : opts)
                w = std::max(w, tw(t) + 38 * s);
            Box b = PresetPopupFit(
                {choiceBox.x + choiceBox.w + 7 * s, choiceBox.y, w, 14 * s + R * opts.size()}, width, height);
            hit({0, 0, float(width), float(height)}, Surface);
            int qz = surface(b);
            hit(b, Surface);
            for (int n = 0; n < int(opts.size()); ++n) {
                Box row{b.x + 7 * s, b.y + 7 * s + n * R, b.w - 14 * s, R};
                Hit h{row, Option, choice, n};
                rect(qz, row, alpha(pal[33], .4f * Motion(h)), 15 * s / 1.6f);
                text(qz, {row.x + 12 * s, row.y + 7 * s, row.w - 24 * s, F}, opts[std::size_t(n)],
                     cfg.worldMisc.value[std::size_t(choice)] == n ? pal[2] : pal[14]);
                hit(row, Option, choice, n);
            }
            rememberTransition(1000 + choice, begin);
        }
        if (page >= 0 && choice < 0 && editing < 0 && (color < 0 || embedded >= 0))
            for (std::size_t i = 0; i < sliders.size(); ++i) {
                auto b = sliders[i];
                float a = sliderTip[i].value;
                if (b.w <= 0 || a <= .001f || !Enabled(int(i), cfg) ||
                    (context >= 0 && !contextBody.Contains(b.x, b.y)))
                    continue;
                auto label = DecodeUTF8(Number(int(i), cfg));
                float w = tw(label), t = (cfg.worldMisc.value[i] - WorldMiscSpecs[i].minimum) /
                                         (WorldMiscSpecs[i].maximum - WorldMiscSpecs[i].minimum);
                Box tip =
                    PresetPopupFit({b.x + b.w * t - w * .5f - 7 * s, b.y - F - 14 * s, w + 14 * s, F + 9 * s},
                                   width, height);
                int tz = layer(tip, false, 8 * s);
                rect(tz, tip, alpha(pal[8], a), 8 * s);
                rect(tz, tip, alpha(pal[11], a), 8 * s, s);
                text(tz, {tip.x + 7 * s, tip.y + 4 * s, w, F}, label, alpha(pal[0], a));
            }
        for (std::size_t i = popupBegin; i < paint.layers.size(); ++i) {
            paint.layers[i].opacity *= popupFade.value;
            for (auto& d : paint.layers[i].draw)
                d.color.a *= popupFade.value;
        }
        if (color >= 0 && page >= 0) {
            auto begin = paint.layers.size();
            auto c = ColorSettings(cfg);
            Box b = pickerBox;
            int cz = (embedded == 55 || embedded == 63) ? layer(b) : surface(b);
            picker.Draw(paint, cz, fonts, c, b);
            picker.DrawMenus(paint, fonts, c, width, height);
            rememberTransition(2000 + color, begin);
        }
        for (auto& entry : transitions)
            if (entry.first >= 1000 && !TransitionActive(entry.first) && entry.second.motion.value > .001f) {
                auto begin = paint.layers.size();
                paint.layers.insert(paint.layers.end(), entry.second.cached.begin(),
                                    entry.second.cached.end());
                fadeLayers(begin, entry.second.motion.value * popupFade.value);
            }

        if (!searchSuppressRoot && detachedRoot < 0) {
            ambience.languages = languages;
            ambience.Measure(fonts, cfg, overlayArea, width, height, visible, blocked);
            paint.layers.insert(paint.layers.end(), ambience.paint.layers.begin(), ambience.paint.layers.end());
            if (ambience.Active())
                hits.clear();
        }
    }
};
}
