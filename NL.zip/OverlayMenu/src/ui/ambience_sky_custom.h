#pragma once
#include "ambience_sky_catalog.h"
#include <algorithm>
#include <cstdint>
#include <filesystem>
#include <iomanip>
#include <sstream>
#include <system_error>
#include <vector>
namespace menu {

inline constexpr const char* AmbienceSkyCustomPrefix = "materials/skybox/menustudio/";
inline bool AmbienceSkyCustomMaterial(const std::string& path) {
    const std::string prefix = AmbienceSkyCustomPrefix;
    if (path.size() <= prefix.size() + 5 || path.size() > 240 ||
        path.compare(0, prefix.size(), prefix) != 0 || path.substr(path.size() - 5) != ".vmat")
        return false;
    auto body = path.substr(prefix.size(), path.size() - prefix.size() - 5);
    if (body.empty() || body.front() == '/' || body.back() == '/' || body.find("//") != std::string::npos)
        return false;
    for (char c : body)
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' ||
              c == '-' || c == '/'))
            return false;
    return true;
}
inline bool AmbienceSkyMaterialAllowed(const std::string& path) {
    if (AmbienceSkyCustomMaterial(path))
        return true;
    for (std::size_t i = 1; i < AmbienceSkyCatalog.size(); ++i)
        if (path == AmbienceSkyCatalog[i].material)
            return true;
    return false;
}
inline std::string AmbienceSkyCustomId(const std::string& path) {
    if (!AmbienceSkyCustomMaterial(path))
        return {};
    std::uint64_t h = 14695981039346656037ull;
    for (unsigned char c : path) {
        h ^= c;
        h *= 1099511628211ull;
    }
    std::ostringstream s;
    s << "custom_" << std::hex << std::setw(16) << std::setfill('0') << h;
    return s.str();
}
struct AmbienceSkyCustomEntry {
    std::string id, label, material;
};
inline std::vector<AmbienceSkyCustomEntry> AmbienceScanCustomSkies(const std::filesystem::path& csgo) {
    std::vector<AmbienceSkyCustomEntry> out;
    std::error_code ec;
    const auto folder = csgo / std::filesystem::path(AmbienceSkyCustomPrefix);
    if (!std::filesystem::is_directory(folder, ec) || ec ||
        std::filesystem::is_symlink(std::filesystem::symlink_status(folder, ec)))
        return out;
    const auto canonicalRoot = std::filesystem::weakly_canonical(csgo, ec);
    if (ec)
        return out;
    const auto canonicalFolder = std::filesystem::weakly_canonical(folder, ec);
    if (ec)
        return out;
    const auto bounded = canonicalFolder.lexically_relative(canonicalRoot);
    if (bounded.empty() || bounded.is_absolute() || *bounded.begin() == "..")
        return out;
    std::filesystem::recursive_directory_iterator it(
        folder, std::filesystem::directory_options::skip_permission_denied, ec),
        end;
    unsigned visited = 0;
    for (; !ec && it != end && visited < 4096; it.increment(ec), ++visited) {
        const auto status = it->symlink_status(ec);
        if (ec)
            break;
        if (std::filesystem::is_symlink(status)) {
            it.disable_recursion_pending();
            continue;
        }
        if (it.depth() > 3) {
            it.disable_recursion_pending();
            continue;
        }
        if (!std::filesystem::is_regular_file(status) || it->path().extension() != L".vmat_c")
            continue;
        const auto size = it->file_size(ec);
        if (ec) {
            ec.clear();
            continue;
        }
        if (size < 16 || size > 16 * 1024 * 1024)
            continue;
        auto relative = it->path().lexically_relative(csgo).generic_u8string();
        if (relative.size() < 2)
            continue;
        relative.resize(relative.size() - 2);
        if (!AmbienceSkyCustomMaterial(relative))
            continue;
        auto label = it->path().lexically_relative(folder).generic_u8string();
        label.resize(label.size() - 7);
        out.push_back({AmbienceSkyCustomId(relative), label, relative});
        if (out.size() == 64)
            break;
    }
    std::sort(out.begin(), out.end(), [](const auto& a, const auto& b) { return a.material < b.material; });

    for (std::size_t i = 0; i < out.size(); ++i)
        for (std::size_t j = i + 1; j < out.size();)
            if (out[i].id == out[j].id)
                out.erase(out.begin() + j);
            else
                ++j;
    return out;
}
inline bool AmbienceSkyImageJob(const std::string& name) {
    return name.compare(0, 4, "sky_") == 0;
}
}
