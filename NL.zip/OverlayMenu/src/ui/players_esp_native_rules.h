#pragma once
#include "menu_core.h"
#include "equipment_icon_catalog.h"
#include <optional>
namespace menu {

inline std::optional<std::u32string> LiveESPWeaponLabel(const std::string& designer) {
    struct Name {
        const char* key;
        const char32_t* label;
    };
    static constexpr Name names[] = {{"ssg08", U"SSG 08"},
                                     {"c4", U"C4"},
                                     {"taser", U"Zeus x27"},
                                     {"flashbang", U"Flashbang"},
                                     {"smokegrenade", U"Smoke Grenade"},
                                     {"hegrenade", U"HE Grenade"},
                                     {"molotov", U"Molotov"},
                                     {"incgrenade", U"Incendiary Grenade"},
                                     {"ak47", U"AK-47"},
                                     {"aug", U"AUG"},
                                     {"awp", U"AWP"},
                                     {"bizon", U"PP-Bizon"},
                                     {"cz75a", U"CZ75-Auto"},
                                     {"deagle", U"Desert Eagle"},
                                     {"elite", U"Dual Berettas"},
                                     {"famas", U"FAMAS"},
                                     {"fiveseven", U"Five-SeveN"},
                                     {"g3sg1", U"G3SG1"},
                                     {"galilar", U"Galil AR"},
                                     {"glock", U"Glock-18"},
                                     {"hkp2000", U"P2000"},
                                     {"m249", U"M249"},
                                     {"m4a1", U"M4A4"},
                                     {"m4a1_silencer", U"M4A1-S"},
                                     {"mac10", U"MAC-10"},
                                     {"mag7", U"MAG-7"},
                                     {"mp5sd", U"MP5-SD"},
                                     {"mp7", U"MP7"},
                                     {"mp9", U"MP9"},
                                     {"negev", U"Negev"},
                                     {"nova", U"Nova"},
                                     {"p250", U"P250"},
                                     {"p90", U"P90"},
                                     {"revolver", U"R8 Revolver"},
                                     {"sawedoff", U"Sawed-Off"},
                                     {"scar20", U"SCAR-20"},
                                     {"sg556", U"SG 553"},
                                     {"tec9", U"Tec-9"},
                                     {"ump45", U"UMP-45"},
                                     {"usp_silencer", U"USP-S"},
                                     {"xm1014", U"XM1014"},
                                     {"decoy", U"Decoy Grenade"},
                                     {"tagrenade", U"Tactical Awareness Grenade"},
                                     {"healthshot", U"Healthshot"},
                                     {"knife", U"Knife"},
                                     {"knife_t", U"Knife"},
                                     {"bayonet", U"Bayonet"},
                                     {"knife_bayonet", U"Bayonet"},
                                     {"knife_karambit", U"Karambit"},
                                     {"knife_m9_bayonet", U"M9 Bayonet"},
                                     {"knife_butterfly", U"Butterfly Knife"}};
    if (designer.rfind("weapon_", 0) != 0)
        return {};
    const auto key = designer.substr(7);
    for (const auto& name : names)
        if (key == name.key)
            return std::u32string(name.label);

    return {};
}
inline std::optional<std::u32string> LiveESPImmunityLabel(std::optional<std::uint8_t> takesDamage,
                                                          std::optional<std::uint8_t> immunity,
                                                          std::optional<std::uint8_t> moveType) {
    if (!takesDamage)
        return {};
    if (*takesDamage != 1)
        return U"Immune";
    if (!immunity)
        return {};
    if (*immunity == 1)
        return U"Spawn";
    if (moveType && (*moveType == 7 || *moveType == 8))
        return U"Noclip";
    return {};
}
inline float LiveESPSlowedValue(float modifier, std::optional<float> simulationTime = {},
                                std::optional<float> gameTime = {}) {
    float value = modifier;
    if (simulationTime && gameTime && std::isfinite(*simulationTime) && std::isfinite(*gameTime))
        value += (*gameTime - *simulationTime) * .4f;
    return std::clamp(value, 0.f, 1.f);
}

inline int LiveESPGrenadeRank(int icon) {
    return icon == 6 ? 0 : icon == 7 ? 1 : icon == 8 ? 2 : icon == 5 ? 3 : icon == 4 ? 4 : 5;
}
}
