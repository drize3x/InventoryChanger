#pragma once
#include "startup_ui.h"
#include "renderer_dx11.h"
namespace menu {
inline void DrawStartupGPU(wm::RendererDX11& r, ID3D11Texture2D* scene, ID3D11RenderTargetView* target, int w,
                           int h, Fonts& fonts, const Settings& cfg, const StartupUI& ui) {
    auto p = MeasureStartup(fonts, cfg, ui, w);
    if (p.opacity <= 0)
        return;
    auto b = p.panel;
    auto rgba = [](Color c) { return std::array<float, 4>{c.r, c.g, c.b, c.a}; };
    r.ClearClip();
    r.PrepareBackdrop(scene, StartupBlurSigma(cfg.scale), cfg.blur);

    if (cfg.blur)
        r.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {1, 1, 1, p.opacity}, p.radius, .5f, 0, true, true);
    r.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {0, 0, 0, 0}, p.radius, 1, 0, false, false, p.shadowSize,
                       rgba(p.outer), 15, p.offsetX, p.offsetY);
    r.DrawOriginalRect(target, b.x, b.y, b.w, b.h, rgba(p.fill), p.radius, 1, 0, false, false, 8 * cfg.scale,
                       rgba(p.inner), 15, 0, 0, true);
    r.DrawOriginalRect(target, p.tile.x, p.tile.y, p.tile.w, p.tile.h, rgba(p.tileColor), 12 * cfg.scale);

    Canvas ink(std::max(1, int(std::ceil(b.w))), std::max(1, int(std::ceil(b.h))));
    DrawStartupInk(ink, fonts, cfg, p, b.x, b.y);
    r.SetClip(b.x, b.y, b.w, b.h);
    r.DrawLayer(target, w, h, ink.rgba.data(), ink.width, ink.height, b.x, b.y, float(ink.width), 0, 27,
                true);
    r.ClearClip();
}
}
