#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
namespace menu {

enum class AmbienceTextureCodec { Pending, RGB, YCoCg, SkyCube, Unknown };
inline const char* AmbienceCodecName(AmbienceTextureCodec c) {
    switch (c) {
    case AmbienceTextureCodec::Pending:
        return "pending";
    case AmbienceTextureCodec::RGB:
        return "RGB";
    case AmbienceTextureCodec::YCoCg:
        return "YCoCg";
    case AmbienceTextureCodec::SkyCube:
        return "native SkyCube";
    default:
        return "unknown";
    }
}

inline std::array<float, 4> AmbienceDecodeYCoCg(const std::array<float, 4>& p) {
    const float scale = p[2] * (255.f / 8.f) + 1.f, co = (p[0] - 128.f / 255.f) / scale,
                cg = (p[1] - 128.f / 255.f) / scale, y = p[3];
    return {std::clamp(y + co - cg, 0.f, 1.f), std::clamp(y + cg, 0.f, 1.f),
            std::clamp(y - co - cg, 0.f, 1.f), 1.f};
}

inline constexpr char AmbienceReadbackShader[] = R"HLSL(
Texture2D image:register(t0);SamplerState linearClamp:register(s0);
struct V{float4 p:SV_Position;float4 color:COLOR0;float2 uv:TEXCOORD0;};
V vs(uint id:SV_VertexID){V o;o.uv=float2((id<<1)&2,id&2);o.p=float4(o.uv*float2(2,-2)+float2(-1,1),0,1);o.color=float4(1,1,1,1);return o;}
float4 ps(V i):SV_Target{return image.SampleLevel(linearClamp,i.uv,0);}
float4 ycocg(V i):SV_Target{
 float4 t=image.SampleLevel(linearClamp,i.uv,0);
 float scale=t.b*(255.0/8.0)+1.0;
 float2 chroma=(t.rg-(128.0/255.0))/scale;
 return float4(saturate(float3(t.a+chroma.x-chroma.y,t.a+chroma.y,t.a-chroma.x-chroma.y)),1.0);
}
)HLSL";
}
