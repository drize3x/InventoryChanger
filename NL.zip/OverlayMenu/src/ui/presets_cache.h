#pragma once
#include "presets_ui.h"
#include <cstring>
namespace menu {

inline std::uint64_t PresetTextSignature(const PresetLayer& layer, const Settings& cfg,
                                         bool integerOrigin = false) {
    const float originX = integerOrigin ? std::floor(layer.box.x) : layer.box.x,
                originY = integerOrigin ? std::floor(layer.box.y) : layer.box.y;
    std::uint64_t hash = 14695981039346656037ull;
    auto number = [&](std::uint64_t value) {
        for (int i = 0; i < 8; ++i) {
            hash ^= (value >> (i * 8)) & 255;
            hash *= 1099511628211ull;
        }
    };
    number(layer.nativeHUDScale > 0);
    std::uint32_t scale = 0;
    static_assert(sizeof(scale) == sizeof(cfg.scale));
    std::memcpy(&scale, &cfg.scale, sizeof(scale));
    number(scale);
    number(std::uint64_t(std::max(1, int(std::ceil(layer.box.x + layer.box.w - originX)))));
    number(std::uint64_t(std::max(1, int(std::ceil(layer.box.y + layer.box.h - originY)))));
    for (const auto& d : layer.draw)
        if (d.pixelLine) {
            number(0x4c494e45);
            number(d.uniformSeparator);
            if (d.uniformSeparator)
                for (float v : {d.box.x - originX, d.box.y - originY, d.box.w, d.box.h}) {
                    std::uint32_t bits = 0;
                    std::memcpy(&bits, &v, sizeof bits);
                    number(bits);
                }
            for (float v : {std::round(d.box.x) - originX, std::round(d.box.y) - originY, d.box.w, d.box.h,
                            d.clip.x - originX, d.clip.y - originY, d.clip.w, d.clip.h}) {
                std::uint32_t bits = 0;
                std::memcpy(&bits, &v, sizeof bits);
                number(bits);
            }
            for (float v : {d.color.r, d.color.g, d.color.b, d.color.a})
                number(Canvas::Byte(v));
        }
    for (const auto& d : layer.draw)
        if (d.raster) {
            number(0x524153544552);
            number(d.clipped);
            for (float v : {d.box.x - originX, d.box.y - originY, d.box.w, d.box.h, d.color.a}) {
                std::uint32_t bits = 0;
                std::memcpy(&bits, &v, sizeof bits);
                number(bits);
            }
            number(d.rasterStamp);
            number(d.raster->width);
            number(d.raster->height);
            number(std::uint64_t(std::int64_t(std::trunc(d.box.x - originX))));
            number(std::uint64_t(std::int64_t(std::trunc(d.box.y - originY))));
            number(Canvas::Byte(d.color.a));
            if (d.clipped)
                for (float a : {d.clip.x - originX, d.clip.y - originY, d.clip.w, d.clip.h}) {
                    std::uint32_t bits = 0;
                    std::memcpy(&bits, &a, sizeof(bits));
                    number(bits);
                }
        }
    for (const auto& d : layer.draw)
        if (!d.text.empty()) {
            if (d.espText) {
                number(0x455350);
                number(1);
            }
            if (d.textSize != 13) {
                number(0x53495a45);
                std::uint32_t bits = 0;
                std::memcpy(&bits, &d.textSize, sizeof bits);
                number(bits);
            }
            if (!d.icon && d.font != 1) {
                number(0x464f4e54);
                number(d.font);
            }
            number(1);
            number(d.icon);
            number(d.iconDestination);
            number(std::uint64_t(std::int64_t(std::trunc(d.box.x - originX))));
            number(std::uint64_t(std::int64_t(std::trunc(d.box.y - originY))));

            if (d.icon) {
                float y = d.box.y - originY;
                if (y == 0)
                    y = 0;
                std::uint32_t bits = 0;
                std::memcpy(&bits, &y, sizeof(bits));
                number(bits);
            }
            number(Canvas::Byte(d.color.r));
            number(Canvas::Byte(d.color.g));
            number(Canvas::Byte(d.color.b));
            number(Canvas::Byte(d.color.a));
            Box clip = d.clipped ? (d.espText ? d.clip : PresetIntersect(d.box, d.clip)) : d.box;
            for (float edge :
                 {clip.x - originX, clip.y - originY, clip.x - originX + clip.w, clip.y - originY + clip.h})
                number(std::uint64_t(std::int64_t(std::ceil(edge - .5f))));
            number(d.icon ? 1 : d.text.size());
            if (d.icon)
                number(d.text.front());
            else
                for (char32_t cp : d.text)
                    number(cp);
        }
    number(0);
    return hash;
}
struct PresetGlyphLayer {
    std::unique_ptr<Canvas> glyphs;
    std::uint64_t signature = 0;
    void Reset() {
        glyphs.reset();
        signature = 0;
    }
    bool Update(Fonts& fonts, const Settings& cfg, const PresetLayer& layer, bool integerOrigin = false) {
        const float x = integerOrigin ? std::floor(layer.box.x) : layer.box.x,
                    y = integerOrigin ? std::floor(layer.box.y) : layer.box.y;
        const int w = std::max(1, int(std::ceil(layer.box.x + layer.box.w - x))),
                  h = std::max(1, int(std::ceil(layer.box.y + layer.box.h - y)));
        auto key = PresetTextSignature(layer, cfg, integerOrigin);
        if (glyphs && glyphs->width == w && glyphs->height == h && signature == key)
            return false;
        auto next = std::make_unique<Canvas>(w, h);
        PresetDrawText(*next, fonts, cfg, layer, -x, -y);
        glyphs = std::move(next);
        signature = key;
        return true;
    }
};
}
