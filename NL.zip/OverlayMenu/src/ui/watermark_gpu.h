#pragma once
#include "watermark_ui.h"
#include "renderer_dx11.h"
namespace menu {
inline void DrawWatermarkGPU(wm::RendererDX11& r, ID3D11Texture2D* scene, ID3D11RenderTargetView* target,
                             int w, int h, Fonts& fonts, const Settings& cfg, const WatermarkUI& ui) {
    auto p = MeasureWatermark(fonts, cfg, ui, w, h);
    if (p.opacity <= 0)
        return;
    auto b = p.panel;
    auto rgba = [](Color c) { return std::array<float, 4>{c.r, c.g, c.b, c.a}; };
    r.ClearClip();
    r.PrepareBackdrop(scene, cfg.sigma * p.scale, cfg.blur);

    if (cfg.blur)
        r.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {1, 1, 1, p.opacity}, p.radius, 0, 0, true, true);
    r.DrawOriginalRect(target, b.x, b.y, b.w, b.h, rgba(p.fill), p.radius);

    r.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {0, 0, 0, 0}, p.radius, 0, 0, false, false, p.shadow,
                       rgba(p.shadowColor), 15, 0, 0, false, 0);

    auto raster = WatermarkInkRasterBox(p, w, h);
    if (raster.w <= 0 || raster.h <= 0)
        return;
    Canvas ink(int(raster.w), int(raster.h));
    DrawWatermarkInk(ink, fonts, cfg, ui, p, raster.x, raster.y);
    float x0 = std::ceil(b.x - .5f), y0 = std::ceil(b.y - .5f), x1 = std::ceil(b.x + b.w - .5f),
          y1 = std::ceil(b.y + b.h - .5f);
    r.SetClip(x0, y0, std::max(0.f, x1 - x0), std::max(0.f, y1 - y0));
    r.DrawLayer(target, w, h, ink.rgba.data(), ink.width, ink.height, raster.x, raster.y, float(ink.width), 0,
                28, true);
    r.ClearClip();
}
}
