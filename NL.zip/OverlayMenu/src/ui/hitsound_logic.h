#pragma once
#include <array>
#include <algorithm>
namespace menu {

struct HitSoundConfig {
    std::array<int, 5> sound{{-1, -1, -1, -1, -1}};
    std::array<int, 5> volume{{100, 100, 100, 100, 100}};
    bool Wanted() const {
        for (int i = 0; i < 4; ++i)
            if (sound[i] >= 0 && sound[i] < 10 && volume[i] > 0)
                return true;
        return false;
    }
};
struct HitSoundEvent {
    int sound = -1, volume = 0;
};
inline int HitSoundHurtType(bool outgoing, bool incoming, int health, int hitgroup) {
    if (incoming)
        return 3;
    if (!outgoing)
        return -1;
    if (health == 0)
        return 2;
    return hitgroup == 1 ? 0 : 1;
}
inline HitSoundEvent HitSoundSelect(const HitSoundConfig& c, int type) {
    if (type < 0 || type >= 5 || c.sound[type] < 0 || c.sound[type] >= 10)
        return {};
    return {c.sound[type], std::clamp(c.volume[type], 0, 300)};
}
}
