#pragma once
#include <array>
#include <string>
namespace menu {

struct AmbienceSkyEntry {
    const char* id;
    const char* material;
};
inline constexpr std::array<AmbienceSkyEntry, 14> AmbienceSkyCatalog{{
    {"default", ""},
    {"anubis", "materials/skybox/sky_de_annubis.vmat"},
    {"aztec", "materials/skybox/sky_hr_aztec_02.vmat"},
    {"baggage", "materials/skybox/sky_ar_baggage_01.vmat"},
    {"cloudy", "materials/skybox/sky_csgo_cloudy01.vmat"},
    {"dust2", "materials/skybox/sky_de_dust2.vmat"},
    {"inferno", "materials/skybox/test/s2_de_inferno_sky01.vmat"},
    {"italy", "materials/skybox/cs_italy_s2_skybox_2.vmat"},
    {"mirage", "materials/skybox/sky_de_mirage.vmat"},
    {"nuke", "materials/skybox/sky_de_nuke.vmat"},
    {"overpass", "materials/skybox/sky_de_overpass_01.vmat"},
    {"office", "materials/skybox/cs_office_45_0.vmat"},
    {"train", "materials/skybox/sky_overcast_01.vmat"},
    {"vertigo", "materials/skybox/sky_de_vertigo.vmat"},
}};
inline int AmbienceSkyIndex(const std::string& id) {
    for (std::size_t i = 0; i < AmbienceSkyCatalog.size(); ++i)
        if (id == AmbienceSkyCatalog[i].id)
            return int(i);
    return -1;
}
inline std::string AmbienceSkyJobName(int index) {
    return index > 0 && index < int(AmbienceSkyCatalog.size())
               ? std::string("sky_") + AmbienceSkyCatalog[std::size_t(index)].id
               : std::string{};
}
inline int AmbienceSkyJobIndex(const std::string& name) {
    return name.compare(0, 4, "sky_") == 0 ? AmbienceSkyIndex(name.substr(4)) : -1;
}
}
