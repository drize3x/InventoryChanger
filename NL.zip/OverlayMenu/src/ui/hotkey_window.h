#pragma once
#include "presets_ui.h"
#include "keybind_model.h"
namespace menu {

inline float HotkeySetting(const Settings& cfg, const char* id) {
    for (std::size_t i = 0; i < WorldMiscSpecs.size(); ++i)
        if (std::string(WorldMiscSpecs[i].id) == id)
            return cfg.worldMisc.value[i];
    return 0;
}
struct HotkeyWindow {
    struct Row {
        MenuKeybind bind;
        PresetMotion reveal;
        bool live = false, valueIcon = false;
        std::u32string name, value;
    };
    std::vector<Row> rows;
    PresetMotion width, column, visibility;
    Box header{}, bounds{};
    float delta = 0;
    bool menuVisible = false, dragging = false, positioned = false;
    float positionX = 16, positionY = 0, grabX = 0, grabY = 0;
    HotkeyWindow() {
        visibility.Snap(0);
    }

    void Tick(float dt) {
        delta = std::max(0.f, std::isfinite(dt) ? dt : 0.f);
    }
    static float RowAlpha(float reveal) {
        return std::clamp((reveal - .25f) * 1.2f / .75f, 0.f, 1.f);
    }
    static std::u32string VisibleText(std::u32string text) {
        auto n = text.find(U"##");
        auto line = text.find(U'\n');
        return text.substr(0, std::min(n, line));
    }

    static std::u32string DisplayValue(const std::u32string& text) {
        std::size_t bytes = 0, end = 0;
        for (char32_t cp : text) {
            auto n = cp < 128 ? 1u : cp < 2048 ? 2u : cp < 65536 ? 3u : 4u;
            if (bytes + n > 20)
                break;
            bytes += n;
            ++end;
        }
        return end == text.size() ? text : text.substr(0, end) + U"...";
    }
    static float TextWidth(Fonts& f, int face, float px, const std::u32string& text) {
        return std::trunc(f.NativeTextSize(face, px, text).w + .95f);
    }
    static void Rect(PresetLayer& l, Box b, Color c, float radius = 0, float stroke = 0, float backdrop = 0,
                     float shadow = 0, Color shadowColor = {}) {
        if (b.w <= 0 || b.h <= 0)
            return;
        PresetDraw d{b, c, radius, stroke, 15, {}, false};
        d.backdropOpacity = backdrop;
        d.shadowSize = shadow;
        d.shadowColor = shadowColor;
        l.draw.push_back(std::move(d));
    }
    static void Text(PresetLayer& l, const Settings& cfg, Box b, const std::u32string& text, Color c,
                     int face, float px, bool icon = false) {
        if (b.w <= 0 || b.h <= 0 || text.empty())
            return;
        PresetDraw d{b, c, 0, 0, 15, text, icon};
        d.font = face;
        (void)cfg;
        d.textSize = px;
        d.clipped = true;
        d.clip = b;
        l.draw.push_back(std::move(d));
    }
    bool Pointer(float x, float y, bool down) {
        if (!down) {
            bool consumed = dragging;
            dragging = false;
            return consumed;
        }
        if (!menuVisible || visibility.value <= 0 || !header.Contains(x, y))
            return false;
        dragging = true;
        positioned = true;
        grabX = x - header.x;
        grabY = y - header.y;
        return true;
    }
    void Move(float x, float y) {
        if (x < 0 || y < 0) {
            dragging = false;
            return;
        }
        if (dragging) {
            positionX = x - grabX;
            positionY = y - grabY;
        }
    }
    template <class Label, class Value>
    void Measure(PresetsUI& paint, Fonts& fonts, const Settings& cfg, const KeybindRuntime& runtime,
                 int viewportW, int viewportH, bool menu, Label&& label, Value&& value) {
        paint.layers.clear();
        menuVisible = menu;
        float dt = delta;
        delta = 0;
        const bool enabled = HotkeySetting(cfg, "hotkeys") != 0;
        for (auto& row : rows)
            row.live = false;
        for (const auto& b : cfg.keybinds)
            if (b.shown && b.key && FindKeybindTarget(b.target) && runtime.Active(b.id)) {
                auto it = std::find_if(rows.begin(), rows.end(),
                                       [&](const Row& row) { return row.bind.id == b.id; });
                if (it == rows.end()) {
                    Row row;
                    row.bind = b;
                    row.reveal.Snap(0);
                    rows.push_back(std::move(row));
                    it = std::prev(rows.end());
                }
                it->bind = b;
                it->live = true;
                auto target = FindKeybindTarget(b.target);
                it->name = VisibleText(label(target.label));

                it->valueIcon = target.kind == WorldKind::Check && !target.color;
                it->value = it->valueIcon
                                ? std::u32string(1, b.value[0] ? char32_t(0xf205) : char32_t(0xf204))
                                : VisibleText(value(b));
            }

        bool anyLive = false;
        for (auto& row : rows) {
            row.reveal.Tick(row.live ? 1.f : 0.f, dt);
            anyLive |= row.live;
        }
        visibility.Tick(enabled && (menu || anyLive) ? 1.f : 0.f, dt);
        rows.erase(std::remove_if(rows.begin(), rows.end(),
                                  [](const Row& row) { return !row.live && row.reveal.value <= 0; }),
                   rows.end());
        if (!menu || !enabled)
            dragging = false;
        if (visibility.value <= 0 || viewportW <= 0 || viewportH <= 0) {
            header = {};
            bounds = {};
            return;
        }
        const float s = ScreenWindowScale(cfg), hp = 13 * s, bp = 12 * s;
        const float fh = fonts.PixelHeight(2, hp), fb = fonts.PixelHeight(0, bp), headerH = fh + 8 * s,
                    rowH = fb + 6 * s;
        const bool inverted = HotkeySetting(cfg, "hotkeys_style") != 0,
                   right = HotkeySetting(cfg, "hotkeys_rightaligned") != 0,
                   dynamic = HotkeySetting(cfg, "hotkeys_dynamicheader") != 0;
        auto title = label("window_hotkeylist");
        const std::u32string icon(1, char32_t(0xe1d2));
        float iw = TextWidth(fonts, 3, hp, icon), tw = TextWidth(fonts, 2, hp, title),
              intrinsic = 18 * s + iw + 12 * s + s + tw;

        float col = 0;
        for (const auto& row : rows)
            if (row.reveal.value > .25f)
                col = std::max(col, TextWidth(fonts, !inverted && row.valueIcon ? 3 : 0, bp,
                                              inverted ? row.name : row.value) +
                                        18 * s);
        if (!column.initialized || column.value == 0)
            column.Snap(col);
        else
            column.Tick(col, dt);
        float targetW = intrinsic;
        float totalH = headerH + 6 * s;
        for (const auto& row : rows) {
            if (row.reveal.value >= .25f || row.live)
                targetW = std::max(targetW, column.value +
                                                TextWidth(fonts, inverted && row.valueIcon ? 3 : 0, bp,
                                                          inverted ? row.value : row.name) +
                                                12 * s);
            totalH += (rowH + 4 * s) * row.reveal.value;
        }
        width.Tick(targetW, dt);

        float x = positioned ? positionX : 16 * s, y = positioned ? positionY : viewportH * .4f;
        x = std::clamp(x, 0.f, std::max(0.f, viewportW - std::min(width.value, float(viewportW))));
        y = std::clamp(y, 0.f, std::max(0.f, viewportH - std::min(totalH, float(viewportH))));
        x = std::trunc(x);
        y = std::trunc(y);
        if (positioned) {
            positionX = x;
            positionY = y;
        }
        header = {x, y, dynamic ? width.value : intrinsic + s, headerH};
        bounds = PresetIntersect(
            {x - 10 * s, y - 10 * s, std::max({width.value, targetW, header.w}) + 20 * s, totalH + 20 * s},
            {0, 0, float(viewportW), float(viewportH)});
        PresetLayer layer{bounds, 0, true, {}};
        layer.opacity = visibility.value;
        layer.nativeHUDScale = s;
        auto pal = CurrentPalette(cfg);
        const float a = visibility.value;
        auto fill = pal[45];
        fill.a *= a;
        auto shadow = pal[38];
        shadow.a *= a;
        Rect(layer, header, fill, 16 * s, 0, a, 18 * s, shadow);
        auto border = fill;
        border.a *= .2f;
        Rect(layer, header, border, 16 * s, 1);
        auto accent = pal[31];
        accent.a *= a;
        auto titleColor = pal[4];
        titleColor.a *= a;
        Text(layer, cfg, {x + 9 * s, y + 4 * s, iw, fh}, icon, accent, 2, hp, true);
        float sepX = x + 9 * s + iw + 6 * s;
        Rect(layer, {sepX, y + 4 * s, s, fh}, border);
        Text(layer, cfg, {sepX + 7 * s, y + 4 * s, tw, fh}, title, titleColor, 2, hp);
        float rowY = y + headerH + 6 * s;
        for (const auto& row : rows) {
            float reveal = row.reveal.value, alpha = RowAlpha(reveal) * a;
            auto shownValue = row.valueIcon ? row.value : DisplayValue(row.value);
            auto first = inverted ? row.name : shownValue, second = inverted ? shownValue : row.name;
            bool firstIcon = !inverted && row.valueIcon, secondIcon = inverted && row.valueIcon;
            float firstW = TextWidth(fonts, firstIcon ? 3 : 0, bp, inverted ? row.name : row.value) + 12 * s,
                  secondW =
                      TextWidth(fonts, secondIcon ? 3 : 0, bp, inverted ? row.value : row.name) + 12 * s;
            float rx = x - 8 * s + 8 * s * reveal, firstX = rx, secondX = rx + column.value;
            if (right && !inverted)
                firstX += column.value - firstW - 6 * s;
            if (right && inverted)
                secondX = x + width.value - secondW;

            if (alpha > 0) {
                auto cell = [&](float cx, float w, const std::u32string& text, bool iconValue) {
                    Box b{std::round(cx), std::round(rowY), w, rowH};
                    auto bg = pal[45];
                    bg.a *= .5f * alpha;
                    Rect(layer, b, bg, 8 * s, 0, alpha);
                    auto ink = pal[0];
                    ink.a *= alpha;
                    Text(layer, cfg, {b.x + 6 * s, b.y + 3 * s, w - 12 * s, fb}, text, ink, 0, bp, iconValue);
                };
                cell(firstX, firstW, first, firstIcon);
                cell(secondX, secondW, second, secondIcon);
            }
            rowY += (rowH + 4 * s) * reveal;
        }

        for (auto& d : layer.draw)
            if (!d.text.empty())
                d.clip = PresetIntersect(d.clip, bounds);
        paint.layers.push_back(std::move(layer));
    }
};
}
