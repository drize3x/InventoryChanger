#pragma once
#include "hud_color_picker.h"
namespace menu {

struct PlayersESPSettingsUI {
    enum { Surface, Toggle, Select, Option, Swatch, Mode, Point };
    struct Hit {
        Box box;
        int kind, index = -1, option = -1;
    };
    int item = -1, team = 0, choice = -1, color = -1, held = -1, focus = -1, point = 0;
    bool releaseGuard = false;
    float anchorX = 0, anchorY = 0, scale = 1, scroll = 0, maxScroll = 0, colorScroll = 0, colorMax = 0,
          mouseX = -1, mouseY = -1;
    Box box{}, choiceAnchor{}, colorAnchor{};
    std::vector<Hit> hits;
    HudColorPicker picker, nested;
    struct MenuFade {
        PresetMotion alpha;
        std::vector<PresetLayer> layers;
    };
    std::map<int, MenuFade> menus;
    int MenuKey() const {
        return choice != -1         ? 100 + choice
               : color >= 0         ? 200 + color
               : picker.formatsOpen ? 300
               : picker.headerOpen  ? 301
                                    : -1;
    }
    PresetMotion alpha;
    std::map<int, PresetMotion> hover, checked, available;
    std::vector<PresetLayer> cached;
    LanguageCatalog* languages = nullptr;

    struct Marquee {
        float offset = 0, hoverTime = 0, overflow = 0, fullWidth = 0;
        int stableFrames = 0;
        bool hovered = false, enabled = false;
        Box row{};
        std::u32string label;
        PresetMotion returning;
    };
    std::map<int, Marquee> marquees;

    static std::u32string MultiSummary(const std::vector<std::u32string>& names) {
        auto join = [&](bool initials) {
            std::u32string t;
            for (const auto& n : names) {
                if (!t.empty())
                    t += U", ";
                if (initials) {
                    if (!n.empty())
                        t += n.front();
                } else
                    t += n;
            }
            return t;
        };
        auto full = join(false);
        return full.size() >= 15 ? join(true) : full;
    }
    bool Active() const {
        return item >= 0;
    }
    bool Capturing() const {
        return Active() && (held >= 0 || picker.held >= 0 || nested.held >= 0 || releaseGuard);
    }
    bool Editing() const {
        return Active() && (color >= 0 ? nested.Editing() : picker.Editing());
    }
    void Cancel() {
        held = -1;
        picker.held = nested.held = -1;
    }
    void Close() {
        item = choice = color = focus = -1;
        releaseGuard = false;
        Cancel();
        picker.formatsOpen = picker.headerOpen = nested.formatsOpen = nested.headerOpen = false;
        alpha.Tick(0, 0);
    }
    void Open(int i, int t, float x, float y) {
        Cancel();
        item = i;
        team = t;
        choice = color = -1;
        point = 0;
        scroll = 0;
        anchorX = x;
        anchorY = y;
        releaseGuard = false;
        picker.Reset(4);
        nested.Reset(4);
        hover.clear();
        checked.clear();
        available.clear();
        marquees.clear();
        menus.clear();
        cached.clear();
        alpha.Snap(0);
        alpha.Tick(1, 0);
    }
    int HitAt(float x, float y) const {
        for (int n = int(hits.size()) - 1; n >= 0; --n)
            if (hits[std::size_t(n)].box.Contains(x, y))
                return n;
        return -1;
    }
    static int Key(const Hit& h) {
        return h.kind * 1024 + (h.index + 2) * 16 + h.option + 1;
    }

    void Tick(float dt, const Settings& cfg) {
        if (!Active() && alpha.value <= .001f) {
            cached.clear();
            menus.clear();
            hits.clear();
            hover.clear();
            checked.clear();
            available.clear();
            marquees.clear();
            picker.DropRasters();
            nested.DropRasters();
            return;
        }
        if (Active()) {
            const auto& v = cfg.players.espSettings[std::size_t(team)][std::size_t(item)];
            for (const auto& f : ESPFields(item)) {
                available[f.slot].Tick(ESPFieldEnabled(item, f.slot, v) ? 1.f : .5f, dt);
                if (f.kind == ESPFieldKind::Toggle)
                    checked[f.slot].Tick(v.value[std::size_t(f.slot)] ? 1.f : 0.f, dt);
            }
        }
        alpha.Tick(Active() ? 1.f : 0.f, dt);
        for (auto& m : menus)
            m.second.alpha.Tick(Active() && m.first == MenuKey() ? 1.f : 0.f, dt);
        picker.Tick(dt, Active() && choice == -1 && color < 0);
        nested.Tick(dt, Active() && color >= 0);
        int n = HitAt(mouseX, mouseY), hot = n >= 0 ? Key(hits[std::size_t(n)]) : -1;
        std::map<int, float> targets;
        for (const auto& h : hits) {
            int k = Key(h);
            float target = 0;
            if (Active()) {
                bool open = (h.kind == Select && choice == h.index) || (h.kind == Mode && choice == -2) ||
                            (h.kind == Swatch && color == h.index);
                bool interactive = (choice == -1 && color < 0) || (choice != -1 && h.kind == Option);
                if (open)
                    target = 1;
                else if (interactive) {
                    if (held == k)
                        target = 1;
                    else if (hot == k)
                        target = h.kind == Point ? .75f : .5f;
                    else if (h.kind == Point && point == h.index)
                        target = .5f;
                }
            }
            targets[k] = target;
            hover.try_emplace(k);
        }
        for (auto& entry : marquees) {
            auto& m = entry.second;
            bool over = Active() && choice == -1 && color < 0 && !picker.formatsOpen && !picker.headerOpen &&
                        m.enabled && m.row.Contains(mouseX, mouseY) && m.overflow > 0;
            if (over) {
                m.hoverTime = m.hovered ? m.hoverTime + std::max(0.f, dt) : 0.f;
                if (m.stableFrames >= 5 && m.hoverTime > .3f) {
                    m.offset += 40 * scale * std::max(0.f, dt);
                    if (m.offset >= m.fullWidth + 20 * scale)
                        m.offset = m.overflow;
                }
                m.returning.Snap(m.offset);
            } else {
                m.hoverTime = 0;
                m.returning.Tick(0, dt, .25f);
                m.offset = m.returning.value;
            }
            m.hovered = over;
        }
        for (auto& entry : hover) {
            auto t = targets.find(entry.first);
            entry.second.Tick(t == targets.end() ? 0.f : t->second, dt);
        }
    }
    std::u32string Label(const std::string& k) const {
        if (languages)
            return languages->Label(k);
        auto p = DefaultLanguageStrings().find(k);
        return DecodeUTF8(p == DefaultLanguageStrings().end() ? k : p->second);
    }

    int PrimaryColorIndex(const Settings& cfg) const {
        return ESPPointColorIndex(
            item, cfg.players.espSettings[std::size_t(team)][std::size_t(item)].colorMode, point);
    }
    int ColorIndex(const Settings& cfg) const {
        return color >= 0 ? color : PrimaryColorIndex(cfg);
    }
    Settings Proxy(const Settings& cfg, int index) const {
        Settings p = cfg;
        if (Active())
            p.worldHud.colors[4] =
                cfg.players.espSettings[std::size_t(team)][std::size_t(item)].colors[std::size_t(index)];
        return p;
    }
    Settings Proxy(const Settings& cfg) const {
        return Proxy(cfg, Active() ? ColorIndex(cfg) : 0);
    }
    void Sync(Settings& cfg, const Settings& p) {
        if (Active())
            cfg.players.espSettings[std::size_t(team)][std::size_t(item)]
                .colors[std::size_t(ColorIndex(cfg))] = p.worldHud.colors[4];
    }
    void Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        if (!Active())
            return;
        auto p = Proxy(cfg);
        if (color >= 0)
            nested.Move(x, y, p);
        else if (choice < 0)
            picker.Move(x, y, p);
        Sync(cfg, p);
    }
    std::vector<std::string> Options(int slot) const {
        if (slot == -2)
            return item == 3
                       ? std::vector<std::string>{"color_default", "color_static", "color_gradient"}
                       : std::vector<std::string>{"color_default",
                                                  item == 6 ? "visuals_preview_item_unarmored_color_separate"
                                                            : "color_gradient"};
        auto f = ESPFindField(item, slot);
        return f ? f->options : std::vector<std::string>{};
    }
    void Activate(const Hit& h, Settings& cfg) {
        auto& v = cfg.players.espSettings[std::size_t(team)][std::size_t(item)];
        if ((h.kind == Toggle || h.kind == Select) && !ESPFieldEnabled(item, h.index, v))
            return;
        if (h.kind == Toggle) {
            v.value[std::size_t(h.index)] ^= 1;
            return;
        }
        if (h.kind == Select || h.kind == Mode) {
            choice = h.kind == Mode ? -2 : h.index;
            choiceAnchor = h.box;
            Cancel();
            return;
        }
        if (h.kind == Option) {
            if (h.index == -2) {
                v.colorMode = h.option;
                point = 0;
                picker.Reset(4);
                choice = -1;
            } else {
                auto f = ESPFindField(item, h.index);
                if (!f)
                    return;
                if (f->kind == ESPFieldKind::Multi)
                    v.value[std::size_t(h.index)] ^= 1 << h.option;
                else {
                    v.value[std::size_t(h.index)] = h.option;
                    choice = -1;
                }
            }
            return;
        }
        if (h.kind == Point) {
            point = h.index;
            picker.syncedIndex = -1;
            return;
        }
        if (h.kind == Swatch) {
            color = h.index;
            colorAnchor = h.box;
            colorScroll = 0;
            nested.Reset(4);
            Cancel();
            return;
        }
    }
    bool Click(float x, float y, bool down, Settings& cfg) {
        if (!Active()) {
            if (!down && releaseGuard) {
                releaseGuard = false;
                return true;
            }
            return false;
        }
        mouseX = x;
        mouseY = y;
        if (!down && releaseGuard) {
            releaseGuard = false;
            Cancel();
            return true;
        }
        auto p = Proxy(cfg);
        if (choice == -1) {
            auto& cp = color >= 0 ? nested : picker;
            if (cp.Click(x, y, down, p)) {
                Sync(cfg, p);
                return true;
            }
            Sync(cfg, p);
            if (color >= 0) {
                if (down) {
                    color = -1;
                    releaseGuard = true;
                    Cancel();
                }
                return true;
            }
        }
        int n = HitAt(x, y);
        if (down) {
            if (n < 0) {
                Close();
                releaseGuard = true;
                return true;
            }
            const auto h = hits[std::size_t(n)];
            if (h.kind == Surface) {
                if (choice != -1) {
                    choice = -1;
                    releaseGuard = true;
                } else if (!box.Contains(x, y)) {
                    Close();
                    releaseGuard = true;
                }
                Cancel();
                return true;
            }
            held = focus = Key(h);
            return true;
        }
        int was = held;
        held = -1;
        if (n >= 0 && was == Key(hits[std::size_t(n)]))
            Activate(hits[std::size_t(n)], cfg);
        return true;
    }
    bool KeyInput(int key, Settings& cfg, bool shift = false, bool ctrl = false) {
        if (!Active())
            return false;
        auto p = Proxy(cfg);
        auto& cp = color >= 0 ? nested : picker;
        if (choice == -1 && cp.Key(key, p, ctrl)) {
            Sync(cfg, p);
            return true;
        }
        if (key == 27) {
            if (choice != -1)
                choice = -1;
            else if (color >= 0)
                color = -1;
            else
                Close();
            return true;
        }
        if (key == 9) {
            std::vector<int> list;
            for (const auto& h : hits)
                if (h.kind != Surface)
                    list.push_back(Key(h));
            if (!list.empty()) {
                auto p2 = std::find(list.begin(), list.end(), focus);
                int n = p2 == list.end() ? 0
                                         : (int(p2 - list.begin()) + (shift ? -1 : 1) + int(list.size())) %
                                               int(list.size());
                focus = list[std::size_t(n)];
            }
            return true;
        }
        if (key == 13 || key == 32) {
            for (const auto& h : hits)
                if (Key(h) == focus) {
                    Activate(h, cfg);
                    break;
                }
        }
        return true;
    }
    bool Character(char16_t c) {
        return Active() && (color >= 0 ? nested.Character(c) : picker.Character(c));
    }
    bool Wheel(float steps) {
        if (!Active())
            return false;
        if (color >= 0) {
            colorScroll = std::clamp(colorScroll - steps * 30 * scale, 0.f, colorMax);
            return true;
        }
        if (choice == -1)
            scroll = std::clamp(scroll - steps * 30 * scale, 0.f, maxScroll);
        return true;
    }
    void Draw(PresetsUI& ui, Fonts& fonts, const Settings& cfg, int width, int height) {
        picker.externalMenuTransitions = nested.externalMenuTransitions = true;
        hits.clear();
        scale = cfg.scale;
        if (!Active()) {
            if (alpha.value > .001f)
                for (auto l : cached) {
                    l.opacity *= alpha.value;
                    for (auto& d : l.draw)
                        d.color.a *= alpha.value;
                    ui.layers.push_back(std::move(l));
                }
            return;
        }
        picker.languages = nested.languages = languages;
        picker.SetMetrics(fonts, scale);
        nested.SetMetrics(fonts, scale);
        const float s = scale, F = fonts.PixelHeight(0, 13 * s), R = F + 14 * s;
        auto pal = CurrentPalette(cfg);
        const auto& v = cfg.players.espSettings[std::size_t(team)][std::size_t(item)];
        auto fields = ESPFields(item);
        if (item == 3 && v.value[6] && v.value[7]) {
            fields.push_back({-1, "visuals_preview_health_damage_start", ESPFieldKind::Color, {}, 0, 6});
            fields.push_back({-1, "visuals_preview_health_damage_peak", ESPFieldKind::Color, {}, 0, 7});
        }
        fields.erase(
            std::remove_if(fields.begin(), fields.end(),
                           [&](const ESPField& f) { return item == 3 && f.slot == 7 && !v.value[6]; }),
            fields.end());
        bool mode = ESPColorModes(item) > 1;
        int pointCount = ESPPointCount(item, v.colorMode);
        bool points = pointCount > 1;
        float top = (mode || points) ? R + 7 * s : 0;
        float ph = picker.Height(s),
              desired = top + ph + (fields.empty() ? 0 : 14 * s + float(fields.size()) * R) + 10 * s;

        box = PresetPopupFit(
            {anchorX, anchorY, 265 * s, std::min(desired, std::max(1.f, float(height) - 12 * s))}, width,
            height);
        maxScroll = std::max(0.f, desired - box.h);
        scroll = std::clamp(scroll, 0.f, maxScroll);
        auto start = ui.layers.size();
        ui.layers.push_back({box, 15 * s, true, {}});
        int z = int(ui.layers.size()) - 1;
        ui.layers.back().pixelAligned = true;
        auto rect = [&](int l, Box b, Color c, float radius = 0, float stroke = 0) {
            PresetDraw d{b, c, radius, stroke, 15, {}, false};
            d.clipped = true;
            d.clip = ui.layers[std::size_t(l)].box;
            ui.layers[std::size_t(l)].draw.push_back(std::move(d));
        };
        auto text = [&](int l, Box b, std::u32string t, Color c, int font = 0) {
            if (font == 3 && !t.empty()) {
                const auto& g = fonts.Get(3, 13 * s, t.front());
                b.x = std::trunc(b.x);
                b.y = std::trunc(b.y);
                b.w = std::max(b.w, float(g.left + g.w));
            }
            PresetDraw d{b, c, 0, 0, 15, std::move(t), font == 3};
            d.font = font;
            d.textSize = 13;
            d.clipped = true;
            d.clip = ui.layers[std::size_t(l)].box;
            ui.layers[std::size_t(l)].draw.push_back(std::move(d));
        };
        bool accept = true;
        auto hit = [&](int l, Box b, int kind, int idx = -1, int opt = -1) {
            if (!accept)
                return;
            b = PresetIntersect(b, ui.layers[std::size_t(l)].box);
            if (b.w > 0 && b.h > 0)
                hits.push_back({b, kind, idx, opt});
        };
        auto tw = [&](const std::u32string& t, int f = 0) {
            return std::trunc(fonts.NativeTextSize(f, 13 * s, t).w + .95f);
        };
        auto marquee = [&](Box viewport, const std::u32string& label, Color col, int key, Box row,
                           bool enabled) {
            const Box origin = viewport;
            viewport = PresetIntersect(viewport, box);
            auto& m = marquees[key];
            float full = tw(label), overflow = std::max(0.f, full - origin.w);
            if (m.label != label || std::abs(m.overflow - overflow) > .01f ||
                std::abs(m.fullWidth - full) > .01f) {
                m.offset = m.hoverTime = 0;
                m.stableFrames = 0;
                m.hovered = false;
                m.returning.Snap(0);
            } else
                m.stableFrames = std::min(5, m.stableFrames + 1);
            m.label = label;
            m.fullWidth = full;
            m.overflow = overflow;
            m.row = PresetIntersect(row, box);
            m.enabled = enabled;
            if (viewport.w <= 0 || viewport.h <= 0)
                return;
            auto draw = [&](float x) {
                text(z, {x, origin.y, std::max(origin.w, full) + s, origin.h}, label, col);
                ui.layers[std::size_t(z)].draw.back().clip = viewport;
            };
            draw(origin.x - m.offset);
            if (m.offset > 0 && m.offset >= overflow)
                draw(origin.x - m.offset + full + 20 * s);
        };
        auto swatch = [&](int l, Box b, int c) {
            auto bg = pal[33];
            bg.a *= .4f * hover[Key({{}, Swatch, c})].value;
            rect(l, {b.x - 3 * s, b.y - 3 * s, b.w + 6 * s, b.h + 6 * s}, bg, 6 * s);
            Box rb{std::floor(b.x) - 1, std::floor(b.y) - 1, std::ceil(b.x + b.w) - std::floor(b.x) + 2,
                   std::ceil(b.y + b.h) - std::floor(b.y) + 2};
            auto raster = std::make_shared<Canvas>(int(rb.w), int(rb.h));
            auto col = v.colors[std::size_t(c)];
            DrawPickerPreview(*raster, {b.x - rb.x, b.y - rb.y, b.w, b.h}, s, F + 6 * s, col, col, false,
                              false);
            PresetDraw d{rb, {1, 1, 1, 1}, 0, 0, 15, {}, false};
            d.raster = raster;
            d.rasterStamp = PickerPreviewStamp(col, col, false, false);
            d.clipped = true;
            d.clip = ui.layers[std::size_t(l)].box;
            ui.layers[std::size_t(l)].draw.push_back(std::move(d));
            hit(l, b, Swatch, c);
        };
        rect(z, box, pal[8], 15 * s);
        rect(z, box, pal[11], 15 * s, 1);
        hit(z, box, Surface);
        float y = box.y - scroll;
        if (mode) {
            auto opts = Options(-2);
            Box b{box.x + 10 * s, y + 10 * s,
                  std::min(140 * s, tw(Label(opts[std::size_t(v.colorMode)])) + 31 * s), F + 6 * s};
            auto base = pal[33];
            base.a *= .2f;
            float hv = hover[Key({{}, Mode})].value;
            rect(z, b, Mix(base, pal[13], hv), 6 * s);
            float aw = tw(U"\uf107", 3);
            text(z, {b.x + 6 * s, b.y + 3 * s, aw, F}, U"\uf107", pal[0], 3);
            text(z, {b.x + 9 * s + aw, b.y + 3 * s, b.w - aw - 15 * s, F},
                 Label(opts[std::size_t(v.colorMode)]), Mix(pal[14], pal[2], hv));
            hit(z, b, Mode);
        }
        if (points) {
            for (int n = 0; n < pointCount; ++n) {
                Box b{box.x + (mode ? 262.f - 33 * pointCount + 33 * n : 10.f + float(n) * 120) * s,
                      y + 10 * s, mode ? 26 * s : 112 * s, F + 6 * s};
                rect(z, b,
                     PickerButtonFill(pal[33], hover[Key({{}, Point, n})].initialized
                                                   ? hover[Key({{}, Point, n})].value
                                               : point == n ? .5f
                                                            : 0.f),
                     7.8f * s);
                Color c = v.colors[std::size_t(ESPPointColorIndex(item, v.colorMode, n))];
                rect(z, {b.x + 6 * s, b.y + (b.h - 14 * s) * .5f, 14 * s, 14 * s}, c, 4 * s);
                if (!mode)
                    text(z, {b.x + 26 * s, b.y + 3 * s, b.w - 32 * s, F},
                         Label(n ? "visuals_preview_item_hitboxes_selected"
                                 : "visuals_preview_item_hitboxes_available"),
                         pal[14]);
                hit(z, b, Point, n);
            }
        }
        auto proxy = Proxy(cfg, PrimaryColorIndex(cfg));
        picker.Draw(ui, z, fonts, proxy, {box.x, y + top, box.w, ph});
        picker.box = PresetIntersect(picker.box, box);
        y += top + ph;
        if (!fields.empty()) {
            rect(z, {box.x + 10 * s, y + 7 * s, 245 * s, s}, pal[34]);
            y += 14 * s;
        }
        for (const auto& f : fields) {
            accept = ESPFieldEnabled(item, f.slot, v);
            auto drawStart = ui.layers[std::size_t(z)].draw.size();
            Box b{box.x + 10 * s, y, 245 * s, R};
            auto hkey = Key({{}, f.kind == ESPFieldKind::Toggle ? Toggle : Select, f.slot});
            float hv = hover[hkey].value;
            auto bg = pal[33];
            bg.a *= .4f * hv;
            rect(z, b, bg, 15 * s / 1.6f);
            float right = b.x + b.w - 12 * s, left = b.x + 12 * s;
            char32_t glyph = ESPFieldIcon(f.slot);
            if (glyph) {
                float iw = tw(std::u32string(1, glyph), 3);
                text(z, {left + (20 * s - iw) * .5f, b.y + 7 * s, 20 * s, F}, std::u32string(1, glyph),
                     pal[14], 3);
                left += 32 * s;
            }
            if (f.kind == ESPFieldKind::Toggle) {
                float nom = F + 2 * s, center = b.y + R * .5f, frac = center - std::trunc(center);
                Box c{right - 32 * s, center - nom * .5f + frac, 32 * s, nom - 2 * frac};
                bool on = v.value[std::size_t(f.slot)] != 0;
                float ct = checked[f.slot].initialized ? checked[f.slot].value : on ? 1.f : 0.f;
                rect(z, c, pal[22], nom * .5f);
                auto overlay = pal[23];
                overlay.a *= ct;
                rect(z, c, overlay, nom * .5f);
                float r = nom * .5f - 2 * s;
                rect(z, {c.x + nom * .5f + (c.w - nom) * ct - r, center - r, 2 * r, 2 * r},
                     Mix(pal[20], pal[21], ct), r);
                hit(z, b, Toggle, f.slot);
                right = c.x - 6 * s;
            } else if (f.kind == ESPFieldKind::Choice || f.kind == ESPFieldKind::Multi) {
                int val = v.value[std::size_t(f.slot)];
                std::u32string label;
                if (f.kind == ESPFieldKind::Choice)
                    label = Label(f.options[std::size_t(val)]);
                else {
                    std::vector<std::u32string> selected;
                    for (std::size_t n = 0; n < f.options.size(); ++n)
                        if (val & (1 << n))
                            selected.push_back(Label(f.options[n]));
                    label = selected.empty() ? Label("menu_select") : MultiSummary(selected);
                }
                float aw = tw(U"\uf105", 3), cw = std::min(108 * s, tw(label) + aw + 3 * s);
                Box c{right - cw, b.y + 7 * s, cw, F};
                marquee({c.x, c.y, c.w - aw - 3 * s, F}, label, Mix(pal[14], pal[2], hv), f.slot * 2 + 1, b,
                        accept);
                text(z, {right - aw, c.y, aw, F}, U"\uf105", pal[14], 3);
                hit(z, b, Select, f.slot);
                right = c.x - 7 * s;
            }
            if (f.color >= 0) {
                Box c{right - 16 * s, b.y + (R - 16 * s) * .5f, 16 * s, 16 * s};
                swatch(z, c, f.color);
                right = c.x - 6 * s;
            }
            auto caption = Label(f.key);
            float room = std::max(0.f, right - left);
            marquee({left, b.y + 7 * s, room, F}, caption, Mix(pal[14], pal[2], hv), f.slot * 2, b, accept);
            float av = available[f.slot].initialized ? available[f.slot].value : accept ? 1.f : .5f;
            for (std::size_t d = drawStart; d < ui.layers[std::size_t(z)].draw.size(); ++d)
                ui.layers[std::size_t(z)].draw[d].color.a *= av;
            y += R;
        }
        accept = true;
        auto menusStart = ui.layers.size();
        if (choice != -1) {
            hits.push_back({{0, 0, float(width), float(height)}, Surface});
            auto opts = Options(choice);
            bool multi = choice >= 0 && ESPFindField(item, choice)->kind == ESPFieldKind::Multi;
            bool single = choice >= 0 && !multi;

            float pw = single ? 140 * s : choiceAnchor.w;
            for (const auto& key : opts)
                pw = std::max(pw, tw(Label(key)) + (single ? 38 : 54) * s);
            float hh = 14 * s + float(opts.size()) * R;
            Box b = choice == -2 ? PickerCompactPopup(choiceAnchor, pw, hh, s, float(width), float(height))
                                 : Box{std::clamp(choiceAnchor.x + choiceAnchor.w + 7 * s, 0.f,
                                                  std::max(0.f, float(width) - pw - 10 * s)),
                                       std::clamp(choiceAnchor.y + choiceAnchor.h * .5f - hh * .25f, 0.f,
                                                  std::max(0.f, float(height) - hh - 10 * s)),
                                       pw, hh};
            ui.layers.push_back({b, 15 * s, true, {}});
            int l = int(ui.layers.size()) - 1;
            rect(l, b, pal[8], 15 * s);
            rect(l, b, pal[11], 15 * s, s);
            hit(l, b, Surface);
            for (std::size_t n = 0; n < opts.size(); ++n) {
                Box r{b.x + 7 * s, b.y + 7 * s + float(n) * R, b.w - 14 * s, R};
                int val = choice == -2 ? v.colorMode : v.value[std::size_t(choice)];
                bool selected = multi ? (val & (1 << n)) != 0 : val == int(n);
                auto bg = pal[33];
                bg.a *= .4f * hover[Key({{}, Option, choice, int(n)})].value;
                rect(l, r, bg, 15 * s / 1.6f);
                if (multi && selected)
                    text(l, {r.x + 12 * s, r.y + 7 * s, 16 * s, F}, U"\uf00c", pal[0], 3);
                text(l, {r.x + (multi ? 34 : 12) * s, r.y + 7 * s, r.w - (multi ? 46 : 24) * s, F},
                     Label(opts[n]),
                     Mix(pal[14], pal[2], selected ? 1.f : hover[Key({{}, Option, choice, int(n)})].value));
                hit(l, r, Option, choice, int(n));
            }
        }
        if (color >= 0) {
            float full = nested.Height(s), fit = std::min(full, std::max(1.f, float(height) - 12 * s));
            colorMax = std::max(0.f, full - fit);
            colorScroll = std::clamp(colorScroll, 0.f, colorMax);
            Box b = PresetPopupFit({colorAnchor.x + colorAnchor.w + 7 * s, colorAnchor.y, 265 * s, fit},
                                   width, height);
            ui.layers.push_back({b, 15 * s, true, {}});
            int l = int(ui.layers.size()) - 1;
            rect(l, b, pal[8], 15 * s);
            rect(l, b, pal[11], 15 * s, 1);
            auto nestedProxy = Proxy(cfg, color);
            nested.Draw(ui, l, fonts, nestedProxy, {b.x, b.y - colorScroll, b.w, full});
            nested.box = b;
            nested.DrawMenus(ui, fonts, nestedProxy, width, height);
        } else if (choice == -1)
            picker.DrawMenus(ui, fonts, proxy, width, height);
        int live = MenuKey();
        if (ui.layers.size() > menusStart && live >= 0) {
            auto& m = menus[live];
            if (!m.alpha.initialized) {
                m.alpha.Snap(0);
                m.alpha.Tick(1, 0);
            }
            m.layers.assign(ui.layers.begin() + std::ptrdiff_t(menusStart), ui.layers.end());
        }
        ui.layers.resize(menusStart);
        for (auto& entry : menus) {
            auto& m = entry.second;
            if (entry.first != live)
                m.alpha.Tick(0, 0);
            if (m.alpha.value > .001f)
                for (auto l : m.layers) {
                    l.opacity *= m.alpha.value;
                    for (auto& d : l.draw)
                        d.color.a *= m.alpha.value;
                    ui.layers.push_back(std::move(l));
                }
        }
        cached.assign(ui.layers.begin() + std::ptrdiff_t(start), ui.layers.end());
        for (std::size_t n = start; n < ui.layers.size(); ++n) {
            ui.layers[n].opacity *= alpha.value;
            for (auto& d : ui.layers[n].draw)
                d.color.a *= alpha.value;
        }
    }
};
}
