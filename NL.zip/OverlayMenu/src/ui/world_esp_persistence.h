#pragma once

inline std::string WorldESPNumber(float n) {
    char b[32];
    std::snprintf(b, sizeof b, "%.9g", double(n));
    return b;
}
inline void WorldESPValidateNumber(float n, float lo, float hi, bool integral) {
    if (!std::isfinite(n) || n < lo || n > hi || (integral && n != std::floor(n)))
        throw std::runtime_error("Invalid World ESP value");
}
inline void WorldESPCapture(const WorldESPValues& v, std::map<std::string, std::string>& out) {
    WorldESPValues defaults;
    const std::string base = "world.esp.";
    out[base + "version"] = "1";
    auto number = [&](const std::string& k, float n, float initial, float lo, float hi, bool integral) {
        WorldESPValidateNumber(n, lo, hi, integral);
        if (n != initial)
            out[base + k] = WorldESPNumber(n);
    };
    auto color = [&](const std::string& k, Color c, Color d, bool locked = false) {
        for (float n : {c.r, c.g, c.b, c.a})
            WorldESPValidateNumber(n, 0, 1, false);
        if (locked && c.a != 1)
            throw std::runtime_error("Invalid World ESP smoke alpha");
        if (c.r == d.r && c.g == d.g && c.b == d.b && c.a == d.a)
            return;
        int j = 0;
        for (float n : {c.r, c.g, c.b, c.a})
            out[base + k + "." + std::to_string(j++)] = WorldESPNumber(n);
    };
    for (std::size_t i = 0; i < WorldESPSpecs.size(); ++i) {
        const auto& s = WorldESPSpecs[i];
        if (s.kind != WorldESPKind::Color)
            number(s.id, v.value[i], s.initial, s.minimum, s.maximum, s.kind != WorldESPKind::Decimal);
    }
    for (std::size_t i = 0; i < v.colors.size(); ++i)
        color("color." + std::to_string(i), v.colors[i], defaults.colors[i],
              WorldESPColorSpecs[i].alphaLocked);
    for (int i = 0; i < 24; ++i) {
        std::size_t n = std::size_t(i);
        const auto k = "item." + std::string(WorldESPItems[n].id) + ".";
        if (v.itemEnabled[n])
            out[base + k + "enabled"] = "1";
        for (const auto& f : WorldESPFields(i)) {
            int hi = f.kind == ESPFieldKind::Toggle  ? 1
                     : f.kind == ESPFieldKind::Multi ? (1 << f.options.size()) - 1
                                                     : int(f.options.size()) - 1;
            number(k + "value." + std::to_string(f.slot), float(v.items[n].value[std::size_t(f.slot)]),
                   float(defaults.items[n].value[std::size_t(f.slot)]), 0, float(hi), true);
        }
        for (int p = 0; p < WorldESPItems[n].points; ++p)
            color(k + "color." + std::to_string(p), v.items[n].colors[std::size_t(p)],
                  defaults.items[n].colors[std::size_t(p)]);
        for (const auto& f : WorldESPFields(i))
            if (f.color >= 0)
                color(k + "color." + std::to_string(f.color), v.items[n].colors[std::size_t(f.color)],
                      defaults.items[n].colors[std::size_t(f.color)]);
    }
}
inline void WorldESPRead(WorldESPValues& out, const std::map<std::string, std::string>& values) {
    WorldESPValues next;
    const std::string base = "world.esp.";
    auto begin = values.lower_bound(base);
    if (begin == values.end() || begin->first.rfind(base, 0) != 0) {
        out = next;
        return;
    }
    std::set<std::string> used;
    auto read = [&](const std::string& key, float initial, float lo, float hi, bool integral) {
        const auto k = base + key;
        auto it = values.find(k);
        if (it == values.end())
            return initial;
        used.insert(k);
        std::size_t count = 0;
        if (it->second.empty() || it->second.size() > 32)
            throw std::runtime_error("Invalid World ESP number");
        float n = std::stof(it->second, &count);
        if (count != it->second.size())
            throw std::runtime_error("Invalid World ESP number");
        WorldESPValidateNumber(n, lo, hi, integral);
        return n;
    };
    auto version = values.find(base + "version");
    if (version == values.end() || version->second != "1")
        throw std::runtime_error("Unsupported World ESP preset version");
    used.insert(version->first);
    auto color = [&](const std::string& k, Color initial, bool locked = false) {
        std::array<float, 4> ch{{initial.r, initial.g, initial.b, initial.a}};
        int present = 0;
        for (int j = 0; j < 4; ++j) {
            auto key = k + "." + std::to_string(j);
            if (values.count(base + key))
                ++present;
            ch[std::size_t(j)] = read(key, ch[std::size_t(j)], 0, 1, false);
        }
        if (present != 0 && present != 4)
            throw std::runtime_error("Incomplete World ESP color");
        if (locked && ch[3] != 1)
            throw std::runtime_error("Invalid World ESP smoke alpha");
        return Color{ch[0], ch[1], ch[2], ch[3]};
    };
    for (std::size_t i = 0; i < WorldESPSpecs.size(); ++i) {
        const auto& s = WorldESPSpecs[i];
        if (s.kind != WorldESPKind::Color)
            next.Set(i, read(s.id, s.initial, s.minimum, s.maximum, s.kind != WorldESPKind::Decimal));
    }
    for (std::size_t i = 0; i < next.colors.size(); ++i)
        next.colors[i] =
            color("color." + std::to_string(i), next.colors[i], WorldESPColorSpecs[i].alphaLocked);
    for (int i = 0; i < 24; ++i) {
        std::size_t n = std::size_t(i);
        auto k = "item." + std::string(WorldESPItems[n].id) + ".";
        next.itemEnabled[n] = read(k + "enabled", 0, 0, 1, true) != 0;
        for (const auto& f : WorldESPFields(i)) {
            int hi = f.kind == ESPFieldKind::Toggle  ? 1
                     : f.kind == ESPFieldKind::Multi ? (1 << f.options.size()) - 1
                                                     : int(f.options.size()) - 1;
            next.items[n].value[std::size_t(f.slot)] =
                int(read(k + "value." + std::to_string(f.slot),
                         float(next.items[n].value[std::size_t(f.slot)]), 0, float(hi), true));
        }
        for (int p = 0; p < WorldESPItems[n].points; ++p)
            next.items[n].colors[std::size_t(p)] =
                color(k + "color." + std::to_string(p), next.items[n].colors[std::size_t(p)]);
        for (const auto& f : WorldESPFields(i))
            if (f.color >= 0)
                next.items[n].colors[std::size_t(f.color)] =
                    color(k + "color." + std::to_string(f.color), next.items[n].colors[std::size_t(f.color)]);
    }
    for (auto it = begin; it != values.end() && it->first.rfind(base, 0) == 0; ++it)
        if (!used.count(it->first))
            throw std::runtime_error("Unknown World ESP preset field");
    out = next;
}
