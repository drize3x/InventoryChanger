#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstddef>
namespace menu {

// Dump RVA 0x687560..0x6875ae: density heights 26/29/34 and min(2*alpha, 1).
// Bottom-Center (index 4): 0x687ae6..0x687af2 adds 5*scale;
// 0x687b52..0x687b9c subtracts 8*scale, rounds and normalizes by -1080/height.
inline float WatermarkHudOffset(int anchor, int density, float scale, float alpha, int viewportHeight) {
    if (anchor != 4 || density < 0 || density > 2 || viewportHeight <= 0 || !std::isfinite(scale) ||
        scale <= 0 || scale > 10 || !std::isfinite(alpha))
        return 0;
    constexpr float h[] = {26, 29, 34};
    float q = std::clamp(alpha * 2.f, 0.f, 1.f);
    return -1080.f / float(viewportHeight) * std::round((h[density] - 3.f) * scale * q);
}
struct HudLength {
    float value = 0;
    std::uint32_t unit = 1;
};
struct HudPosition {
    std::uintptr_t vtable = 0;
    std::uint8_t id = 0, flag = 0;
    std::uint8_t padding[6]{};
    HudLength x{}, y{}, z{};
};
static_assert(sizeof(std::uintptr_t) == 8 && sizeof(HudPosition) == 40 && offsetof(HudPosition, x) == 16,
              "x64 Panorama position ABI");
inline bool HudSamePosition(const HudPosition& a, const HudPosition& b) {
    return a.vtable == b.vtable && a.id == b.id && a.flag == b.flag &&
           std::memcmp(&a.x, &b.x, 3 * sizeof(HudLength)) == 0;
}
inline bool HudCanOffset(const HudPosition& p) {
    return p.y.unit == 1 && std::isfinite(p.y.value) && std::abs(p.y.value) < 10000 && p.flag <= 1;
}
struct HudPropertyEntry {
    std::uint8_t id = 0, padding[7]{};
    std::uintptr_t property = 0;
};
static_assert(sizeof(HudPropertyEntry) == 16, "Panorama inline list ABI");

template <class Read, class Write>
bool HudDetachInline(Read&& read, Write&& write, std::uintptr_t list, std::uint8_t id,
                     std::uintptr_t expected) {
    std::int32_t count = 0;
    std::uintptr_t entries = 0;
    if (!list || !read(list, count) || count <= 0 || count > 512 || !read(list + 8, entries) || !entries)
        return false;
    int found = -1;
    HudPropertyEntry last{};
    for (int i = 0; i < count; ++i) {
        HudPropertyEntry e{};
        if (!read(entries + std::uintptr_t(i) * 16, e))
            return false;
        if (e.id == id) {
            if (found >= 0 || e.property != expected)
                return false;
            found = i;
        }
        if (i == count - 1)
            last = e;
    }
    if (found < 0)
        return false;
    if (found != count - 1 && !write(entries + std::uintptr_t(found) * 16, last))
        return false;
    --count;
    return write(list, count);
}
}
