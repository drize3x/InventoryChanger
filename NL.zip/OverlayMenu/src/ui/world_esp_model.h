#pragma once

enum class WorldESPKind { Check, Integer, Decimal, Choice, Multi, Color };
enum WorldESPField {
    BombEnabled,
    BombEffects,
    BombIndicator,
    DefuseIndicator,
    Defuser,
    BombDefused,
    WeaponsEnabled,
    WeaponsEffects,
    HostagesEnabled,
    RescueIndicator,
    GrenadesEnabled,
    SmokeRadius,
    InfernoRadius,
    ProjectileRadius,
    ColorizeSmoke,
    ColorizeMolotov,
    ColorizeExplosion,
    Effects,
    Trajectory,
    Proximity,
    TrajExponent,
    TrajThickness,
    TrajPoints,
    TrajShimmer,
    TrajStrength,
    TrajThrown,
    TrajPin,
    TrajPrecise,
    SmokeFade,
    SmokeGradient,
    SmokeOutline,
    SmokeGlowOpacity,
    SmokeGlow,
    InfernoFade,
    InfernoGradient,
    InfernoOutline,
    InfernoGlowOpacity,
    InfernoGlow,
    DisableDecals,
    ItemExponent,
    ItemThickness,
    ItemPoints,
    ItemShimmer,
    WorldESPFieldCount
};
struct WorldESPSpec {
    const char* id;
    const char* key;
    WorldESPKind kind;
    float minimum, maximum, initial;
    int page, owner, parent, color, count;
    char32_t icon;
    bool percent;
};
inline constexpr std::array<WorldESPSpec, 43> WorldESPSpecs{{
    {"bomb_enabled", "enabled", WorldESPKind::Check, 0.f, 1.f, 0.f, 0, -1, -1, 0, 1, 0x0, false},
    {"bomb_effects", "visuals_world_worldesp_bomb_colorizeeffects", WorldESPKind::Check, 0.f, 1.f, 0.f, 0, -1,
     -1, 1, 2, 0xf890, false},
    {"bomb_indicator", "visuals_world_worldesp_bomb_bombindicator", WorldESPKind::Check, 0.f, 1.f, 0.f, 0, -1,
     -1, -1, 0, 0xf1e2, false},
    {"defuse_indicator", "visuals_world_worldesp_bomb_defuseindicator", WorldESPKind::Check, 0.f, 1.f, 0.f, 0,
     -1, -1, 5, 2, 0xf0c4, false},
    {"defuser", "visuals_world_worldesp_bomb_defuser", WorldESPKind::Check, 0.f, 1.f, 0.f, 0, -1, -1, 7, 2,
     0xf0c4, false},
    {"bomb_defused", "visuals_world_worldesp_bomb_bombdefused", WorldESPKind::Color, 0.f, 1.f, 0.f, 0, -1, -1,
     9, 1, 0, false},
    {"weapons_enabled", "enabled", WorldESPKind::Check, 0.f, 1.f, 0.f, 1, -1, -1, 10, 1, 0x0, false},
    {"weapons_effects", "visuals_world_worldesp_weapons_colorizeeffects", WorldESPKind::Check, 0.f, 1.f, 0.f,
     1, -1, -1, 11, 2, 0xf890, false},
    {"hostages_enabled", "enabled", WorldESPKind::Check, 0.f, 1.f, 0.f, 2, -1, -1, 13, 1, 0x0, false},
    {"rescue_indicator", "visuals_world_worldesp_hostages_rescueindicator", WorldESPKind::Check, 0.f, 1.f,
     0.f, 2, -1, -1, 14, 1, 0xf4c4, false},
    {"grenades_enabled", "enabled", WorldESPKind::Check, 0.f, 1.f, 0.f, 3, -1, -1, 15, 1, 0x0, false},
    {"smoke_radius", "visuals_world_worldesp_grenades_smokeradius", WorldESPKind::Check, 0.f, 1.f, 0.f, 3, -1,
     -1, 16, 1, 0xe105, false},
    {"inferno_radius", "visuals_world_worldesp_grenades_molotovradius", WorldESPKind::Check, 0.f, 1.f, 0.f, 3,
     -1, -1, 17, 2, 0xe600, false},
    {"projectile_radius", "visuals_world_worldesp_grenades_projectileinfernoradius", WorldESPKind::Check, 0.f,
     1.f, 0.f, 3, -1, -1, 19, 2, 0xe600, false},
    {"colorize_smoke", "visuals_world_worldesp_grenades_colorizesmoke", WorldESPKind::Check, 0.f, 1.f, 0.f, 3,
     -1, -1, 21, 2, 0xf760, false},
    {"colorize_molotov", "visuals_world_worldesp_grenades_colorizemolotov", WorldESPKind::Check, 0.f, 1.f,
     0.f, 3, -1, -1, 23, 2, 0xf6df, false},
    {"colorize_explosion", "visuals_world_worldesp_grenades_colorizeexplosion", WorldESPKind::Check, 0.f, 1.f,
     0.f, 3, -1, -1, 25, 1, 0xe4e9, false},
    {"effects", "visuals_world_worldesp_grenades_effects", WorldESPKind::Multi, 0.f, 31.f, 31.f, 3, -1, -1,
     26, 1, 0x0, false},
    {"trajectory", "visuals_world_worldesp_grenadetrajectory", WorldESPKind::Check, 0.f, 1.f, 0.f, -1, -1, -1,
     27, 3, 0x0, false},
    {"proximity", "visuals_world_worldesp_grenadeproximitywarnings", WorldESPKind::Check, 0.f, 1.f, 0.f, -1,
     -1, -1, -1, 0, 0x0, false},
    {"trajectory_exponent", "visuals_world_worldesp_grenadetrajectory_exponent", WorldESPKind::Integer, 0.f,
     100.f, 30.f, 4, Trajectory, -1, -1, 0, 0xe0c9, false},
    {"trajectory_thickness", "visuals_world_worldesp_grenadetrajectory_thickness", WorldESPKind::Decimal,
     0.24f, 8.f, 0.24f, 4, Trajectory, -1, -1, 0, 0xf88e, false},
    {"trajectory_points", "visuals_world_worldesp_grenadetrajectory_pointsthickness", WorldESPKind::Decimal,
     0.24f, 8.f, 0.24f, 4, Trajectory, -1, -1, 0, 0xe105, false},
    {"trajectory_shimmer", "visuals_world_worldesp_grenadetrajectory_shimmer", WorldESPKind::Multi, 0.f, 3.f,
     0.f, 4, Trajectory, -1, -1, 0, 0xf890, false},
    {"trajectory_strength", "visuals_world_worldesp_grenadetrajectory_shimmer_strength",
     WorldESPKind::Integer, 0.f, 100.f, 50.f, 4, Trajectory, TrajShimmer, -1, 0, 0xe0c9, false},
    {"trajectory_thrown", "visuals_world_worldesp_grenadetrajectory_throwngrenades", WorldESPKind::Check, 0.f,
     1.f, 1.f, 4, Trajectory, -1, -1, 0, 0x0, false},
    {"trajectory_pin", "visuals_world_worldesp_grenadetrajectory_pinpulledonly", WorldESPKind::Check, 0.f,
     1.f, 0.f, 4, Trajectory, -1, -1, 0, 0x0, false},
    {"trajectory_precise", "visuals_world_worldesp_grenadetrajectory_precisetrajectory", WorldESPKind::Check,
     0.f, 1.f, 0.f, 4, Trajectory, -1, -1, 0, 0x0, false},
    {"smoke_fadeoffset", "visuals_world_worldesp_grenades_radiusoptions_fadeoffset", WorldESPKind::Integer,
     5.f, 100.f, 50.f, 3, SmokeRadius, -1, -1, 0, 0xf042, true},
    {"smoke_gradientopacity", "visuals_world_worldesp_grenades_radiusoptions_gradientopacity",
     WorldESPKind::Integer, 0.f, 100.f, 45.f, 3, SmokeRadius, -1, -1, 0, 0xf042, true},
    {"smoke_outlineopacity", "visuals_world_worldesp_grenades_radiusoptions_outlineopacity",
     WorldESPKind::Integer, 0.f, 100.f, 100.f, 3, SmokeRadius, -1, -1, 0, 0xe105, true},
    {"smoke_shadowopacity", "visuals_world_worldesp_grenades_radiusoptions_shadowopacity",
     WorldESPKind::Integer, 0.f, 100.f, 85.f, 3, SmokeRadius, -1, -1, 0, 0xe1c0, true},
    {"smoke_glow", "visuals_world_worldesp_grenades_radiusoptions_glow", WorldESPKind::Decimal, 0.f, 64.f,
     24.f, 3, SmokeRadius, -1, -1, 0, 0xf185, false},
    {"inferno_fadeoffset", "visuals_world_worldesp_grenades_radiusoptions_fadeoffset", WorldESPKind::Integer,
     5.f, 100.f, 50.f, 3, InfernoRadius, -1, -1, 0, 0xf042, true},
    {"inferno_gradientopacity", "visuals_world_worldesp_grenades_radiusoptions_gradientopacity",
     WorldESPKind::Integer, 0.f, 100.f, 45.f, 3, InfernoRadius, -1, -1, 0, 0xf042, true},
    {"inferno_outlineopacity", "visuals_world_worldesp_grenades_radiusoptions_outlineopacity",
     WorldESPKind::Integer, 0.f, 100.f, 100.f, 3, InfernoRadius, -1, -1, 0, 0xe105, true},
    {"inferno_shadowopacity", "visuals_world_worldesp_grenades_radiusoptions_shadowopacity",
     WorldESPKind::Integer, 0.f, 100.f, 85.f, 3, InfernoRadius, -1, -1, 0, 0xe1c0, true},
    {"inferno_glow", "visuals_world_worldesp_grenades_radiusoptions_glow", WorldESPKind::Decimal, 0.f, 64.f,
     24.f, 3, InfernoRadius, -1, -1, 0, 0xf185, false},
    {"disable_inferno_decals", "visuals_world_worldesp_grenades_colorizemolotov_disableinfernodecals",
     WorldESPKind::Check, 0.f, 1.f, 0.f, 3, ColorizeMolotov, -1, -1, 0, 0x0, false},
    {"grenade_item_exponent", "visuals_world_worldesp_grenadetrajectory_exponent", WorldESPKind::Integer, 0.f,
     100.f, 30.f, 5, 123, -1, -1, 0, 0xe0c9, false},
    {"grenade_item_thickness", "visuals_world_worldesp_grenadetrajectory_thickness", WorldESPKind::Decimal,
     0.24f, 8.f, 0.24f, 5, 123, -1, -1, 0, 0xf88e, false},
    {"grenade_item_points", "visuals_world_worldesp_grenadetrajectory_pointsthickness", WorldESPKind::Decimal,
     0.24f, 8.f, 0.24f, 5, 123, -1, -1, 0, 0xe105, false},
    {"grenade_item_shimmer", "visuals_world_worldesp_grenadetrajectory_shimmer", WorldESPKind::Integer, 0.f,
     100.f, 0.f, 5, 123, -1, -1, 0, 0xf890, false},
}};
struct WorldESPColorSpec {
    const char* key;
    Color initial;
    bool alphaLocked;
};

inline constexpr std::array<WorldESPColorSpec, 30> WorldESPColorSpecs{{
    {"color_universal", {145.f / 255, 240.f / 255, 145.f / 255, 255.f / 255}, false},
    {"visuals_world_worldesp_bomb_colorizeeffects_explosion",
     {15.f / 255, 130.f / 255, 255.f / 255, 255.f / 255},
     false},
    {"visuals_world_worldesp_bomb_colorizeeffects_light",
     {255.f / 255, 50.f / 255, 80.f / 255, 255.f / 255},
     false},
    {"", {180.f / 255, 210.f / 255, 240.f / 255, 255.f / 255}, false},
    {"", {255.f / 255, 0.f / 255, 0.f / 255, 255.f / 255}, false},
    {"", {180.f / 255, 210.f / 255, 240.f / 255, 255.f / 255}, false},
    {"", {255.f / 255, 0.f / 255, 0.f / 255, 255.f / 255}, false},
    {"", {180.f / 255, 210.f / 255, 240.f / 255, 255.f / 255}, false},
    {"", {255.f / 255, 0.f / 255, 0.f / 255, 255.f / 255}, false},
    {"", {180.f / 255, 210.f / 255, 240.f / 255, 160.f / 255}, false},
    {"color_universal", {255.f / 255, 255.f / 255, 255.f / 255, 220.f / 255}, false},
    {"visuals_world_worldesp_weapons_colorizeeffects_color_weapon",
     {170.f / 255, 65.f / 255, 190.f / 255, 255.f / 255},
     false},
    {"visuals_world_worldesp_weapons_colorizeeffects_color_impact",
     {80.f / 255, 110.f / 255, 200.f / 255, 255.f / 255},
     false},
    {"color_universal", {255.f / 255, 110.f / 255, 140.f / 255, 255.f / 255}, false},
    {"", {180.f / 255, 210.f / 255, 240.f / 255, 255.f / 255}, false},
    {"color_universal", {255.f / 255, 255.f / 255, 255.f / 255, 220.f / 255}, false},
    {"", {75.f / 255, 150.f / 255, 255.f / 255, 180.f / 255}, false},
    {"visuals_world_worldesp_grenades_molotovradius_lethal",
     {255.f / 255, 0.f / 255, 0.f / 255, 255.f / 255},
     false},
    {"visuals_world_worldesp_grenades_molotovradius_safe",
     {50.f / 255, 255.f / 255, 200.f / 255, 255.f / 255},
     false},
    {"visuals_world_worldesp_grenades_projectileinfernoradius_lethal",
     {255.f / 255, 128.f / 255, 80.f / 255, 255.f / 255},
     false},
    {"visuals_world_worldesp_grenades_projectileinfernoradius_safe",
     {210.f / 255, 255.f / 255, 200.f / 255, 128.f / 255},
     false},
    {"visuals_world_worldesp_grenades_colorizesmoke_ct",
     {75.f / 255, 127.f / 255, 155.f / 255, 255.f / 255},
     true},
    {"visuals_world_worldesp_grenades_colorizesmoke_t",
     {180.f / 255, 128.f / 255, 50.f / 255, 255.f / 255},
     true},
    {"visuals_world_worldesp_grenades_colorizemolotov_lethal",
     {255.f / 255, 0.f / 255, 0.f / 255, 255.f / 255},
     false},
    {"visuals_world_worldesp_grenades_colorizemolotov_safe",
     {50.f / 255, 255.f / 255, 200.f / 255, 255.f / 255},
     false},
    {"", {100.f / 255, 150.f / 255, 255.f / 255, 150.f / 255}, false},
    {"", {255.f / 255, 105.f / 255, 190.f / 255, 255.f / 255}, false},
    {"visuals_world_worldesp_grenadetrajectory_color_base",
     {255.f / 255, 70.f / 255, 100.f / 255, 255.f / 255},
     false},
    {"visuals_world_worldesp_grenadetrajectory_color_hit",
     {80.f / 255, 255.f / 255, 135.f / 255, 255.f / 255},
     false},
    {"visuals_world_worldesp_grenadetrajectory_color_teamdamage",
     {255.f / 255, 70.f / 255, 100.f / 255, 255.f / 255},
     false},
}};
enum class WorldESPFamily { Color, Icon, Text, Bar };
struct WorldESPItemSpec {
    const char* id;
    const char* key;
    int page;
    WorldESPFamily family;
    int points;
};
inline constexpr std::array<WorldESPItemSpec, 24> WorldESPItems{{
    {"bomb.icon", "visuals_world_worldesp_values_icon", 0, WorldESPFamily::Icon, 1},
    {"bomb.text", "visuals_world_worldesp_values_text", 0, WorldESPFamily::Text, 1},
    {"bomb.progressbar", "visuals_world_worldesp_values_progressbar", 0, WorldESPFamily::Bar, 1},
    {"bomb.timeremaining", "visuals_world_worldesp_values_timeremaining", 0, WorldESPFamily::Text, 1},
    {"bomb.damage", "visuals_world_worldesp_values_damage", 0, WorldESPFamily::Text, 2},
    {"bomb.distance", "visuals_world_worldesp_values_distance", 0, WorldESPFamily::Text, 1},
    {"bomb.glow", "visuals_world_worldesp_values_glow", 0, WorldESPFamily::Color, 1},
    {"weapons.icon", "visuals_world_worldesp_values_icon", 1, WorldESPFamily::Icon, 1},
    {"weapons.text", "visuals_world_worldesp_values_text", 1, WorldESPFamily::Text, 1},
    {"weapons.ammo", "visuals_world_worldesp_values_ammo", 1, WorldESPFamily::Bar, 1},
    {"weapons.distance", "visuals_world_worldesp_values_distance", 1, WorldESPFamily::Text, 1},
    {"weapons.glow", "visuals_world_worldesp_values_glow", 1, WorldESPFamily::Color, 1},
    {"hostages.boundingbox", "visuals_world_worldesp_values_boundingbox", 2, WorldESPFamily::Color, 1},
    {"hostages.progressbar", "visuals_world_worldesp_values_progressbar", 2, WorldESPFamily::Bar, 1},
    {"hostages.text", "visuals_world_worldesp_values_text", 2, WorldESPFamily::Text, 1},
    {"hostages.distance", "visuals_world_worldesp_values_distance", 2, WorldESPFamily::Text, 1},
    {"hostages.glow", "visuals_world_worldesp_values_glow", 2, WorldESPFamily::Color, 1},
    {"grenades.icon", "visuals_world_worldesp_values_icon", 3, WorldESPFamily::Icon, 1},
    {"grenades.text", "visuals_world_worldesp_values_text", 3, WorldESPFamily::Text, 1},
    {"grenades.progressbar", "visuals_world_worldesp_values_progressbar", 3, WorldESPFamily::Bar, 1},
    {"grenades.timeremaining", "visuals_world_worldesp_values_timeremaining", 3, WorldESPFamily::Text, 1},
    {"grenades.distance", "visuals_world_worldesp_values_distance", 3, WorldESPFamily::Text, 1},
    {"grenades.glow", "visuals_world_worldesp_values_glow", 3, WorldESPFamily::Color, 2},
    {"grenades.trajectory", "visuals_world_worldesp_values_trajectory", 3, WorldESPFamily::Color, 2},
}};
inline constexpr std::array<const char*, 6> WorldESPPageKeys{
    {"visuals_world_worldesp_bomb", "visuals_world_worldesp_weapons", "visuals_world_worldesp_hostages",
     "visuals_world_worldesp_grenades", "visuals_world_worldesp_grenadetrajectory",
     "visuals_world_worldesp_grenadeproximitywarnings"}};
inline const std::vector<ESPField>& WorldESPFields(int item) {
    const auto f = WorldESPItems.at(std::size_t(item)).family;
    return ESPFields(f == WorldESPFamily::Text   ? 2
                     : f == WorldESPFamily::Icon ? 24
                     : f == WorldESPFamily::Bar  ? 23
                                                 : 0);
}
inline ESPItemValues WorldESPItemInitial(int item) {
    const auto& spec = WorldESPItems.at(std::size_t(item));
    auto v = ESPInitial(spec.family == WorldESPFamily::Text   ? 2
                        : spec.family == WorldESPFamily::Icon ? 24
                        : spec.family == WorldESPFamily::Bar  ? 23
                                                              : 0);
    if (spec.family == WorldESPFamily::Text) {
        v.value[0] = 1;
        v.value[1] = 1;
    }
    if (spec.family == WorldESPFamily::Bar) {
        v.colors[0] = {100.f / 255, 145.f / 255, 1, 210.f / 255};
        v.value[5] = 0;
    }
    if (item == 9) {
        v.colors[0] = {160.f / 255, 200.f / 255, 1, 210.f / 255};
        v.value[5] = 1;
    }
    if (item == 4) {
        v.colors[0] = {1, 1, 1, 210.f / 255};
        v.colors[1] = {1, 50.f / 255, 80.f / 255, 210.f / 255};
    }
    if (item == 22 || item == 23) {
        v.colors[0] = {1, 145.f / 255, 145.f / 255, 210.f / 255};
        v.colors[1] = {165.f / 255, 145.f / 255, 1, 210.f / 255};
    }
    return v;
}
inline WorldKind WorldESPBindKind(WorldESPKind k) {
    return k == WorldESPKind::Check     ? WorldKind::Check
           : k == WorldESPKind::Integer ? WorldKind::Integer
           : k == WorldESPKind::Choice  ? WorldKind::Choice
           : k == WorldESPKind::Multi   ? WorldKind::Multi
                                        : WorldKind::Decimal;
}
inline std::vector<std::string> WorldESPOptions(int i) {
    if (i == Effects)
        return {"visuals_world_worldesp_grenades_effects_he", "visuals_world_worldesp_grenades_effects_flash",
                "visuals_world_worldesp_grenades_effects_smoke",
                "visuals_world_worldesp_grenades_effects_molotov",
                "visuals_world_worldesp_grenades_effects_decoy"};
    if (i == TrajShimmer)
        return {"visuals_world_worldesp_grenadetrajectory_shimmer_localgrenade",
                "visuals_world_worldesp_grenadetrajectory_throwngrenades"};
    return {};
}
struct WorldESPValues {
    std::array<float, WorldESPFieldCount> value{};
    std::array<Color, 30> colors{};
    std::array<bool, 24> itemEnabled{};
    std::array<ESPItemValues, 24> items{};
    WorldESPValues() {
        for (std::size_t i = 0; i < value.size(); ++i)
            value[i] = WorldESPSpecs[i].initial;
        for (std::size_t i = 0; i < colors.size(); ++i)
            colors[i] = WorldESPColorSpecs[i].initial;
        for (int i = 0; i < 24; ++i)
            items[std::size_t(i)] = WorldESPItemInitial(i);
    }
    void Set(std::size_t i, float n) {
        if (i >= value.size() || !std::isfinite(n))
            return;
        const auto& d = WorldESPSpecs[i];
        if (d.kind == WorldESPKind::Color)
            return;
        n = std::clamp(n, d.minimum, d.maximum);
        value[i] = d.kind == WorldESPKind::Decimal ? std::round(n * 100.f) / 100.f : std::round(n);
    }
    void SetColor(std::size_t i, Color c) {
        if (i >= colors.size())
            return;
        for (float n : {c.r, c.g, c.b, c.a})
            if (!std::isfinite(n))
                return;
        c = {std::clamp(c.r, 0.f, 1.f), std::clamp(c.g, 0.f, 1.f), std::clamp(c.b, 0.f, 1.f),
             WorldESPColorSpecs[i].alphaLocked ? 1.f : std::clamp(c.a, 0.f, 1.f)};
        colors[i] = c;
    }
    bool operator==(const WorldESPValues& b) const {
        if (value != b.value || itemEnabled != b.itemEnabled)
            return false;
        auto same = [](Color x, Color y) { return x.r == y.r && x.g == y.g && x.b == y.b && x.a == y.a; };
        for (std::size_t i = 0; i < colors.size(); ++i)
            if (!same(colors[i], b.colors[i]))
                return false;
        for (int i = 0; i < 24; ++i) {
            const auto& x = items[std::size_t(i)];
            const auto& y = b.items[std::size_t(i)];
            for (const auto& f : WorldESPFields(i))
                if (x.value[std::size_t(f.slot)] != y.value[std::size_t(f.slot)])
                    return false;
            for (int n = 0; n < WorldESPItems[std::size_t(i)].points; ++n)
                if (!same(x.colors[std::size_t(n)], y.colors[std::size_t(n)]))
                    return false;
            for (const auto& f : WorldESPFields(i))
                if (f.color >= 0 && !same(x.colors[std::size_t(f.color)], y.colors[std::size_t(f.color)]))
                    return false;
        }
        return true;
    }
    bool operator!=(const WorldESPValues& b) const {
        return !(*this == b);
    }
};
inline bool WorldESPEnabled(int i, const WorldESPValues& v) {
    int p = WorldESPSpecs.at(std::size_t(i)).parent;
    return p < 0 || v.value[std::size_t(p)] != 0;
}
inline bool WorldESPAuto(int i, float v) {
    return (i == TrajThickness || i == TrajPoints || i == ItemThickness || i == ItemPoints) && v < .25f;
}

inline bool WorldESPDetailsButton(int i) {
    return i == Trajectory;
}
