#pragma once
#include "watermark_network.h"
#include <limits>
namespace menu {
inline constexpr std::array<int, 109> WatermarkAllInputAnchorPattern{
    {0x48, 0x8d, 0x96, 0x54, 0x2,  0x0,  0x0, 0x48, 0x89, 0xac, 0x24, 0xb8, 0x0,  0x0,  0x0,  0x48,
     0x89, 0xbc, 0x24, 0xc0, 0x0,  0x0,  0x0, 0xe8, -1,   -1,   -1,   -1,   0x8b, 0xae, 0x88, 0x2,
     0x0,  0x0,  0x8b, 0x9e, 0x58, 0x2,  0x0, 0x0,  0x85, 0xed, 0xf,  -1,   0x96, 0x2,  0x0,  0x0,
     0x85, 0xdb, 0xf,  -1,   0x8e, 0x2,  0x0, 0x0,  0x4c, 0x89, 0xb4, 0x24, 0x88, 0x0,  0x0,  0x0,
     0x48, 0x8d, 0xd,  -1,   -1,   -1,   -1,  0x4c, 0x89, 0xbc, 0x24, 0x80, 0x0,  0x0,  0x0,  0xf,
     0x29, 0x74, 0x24, 0x70, 0xe8, -1,   -1,  -1,   -1,   0xf3, 0xf,  0x10, 0x35, -1,   -1,   -1,
     -1,   0xf3, 0xf,  0x10, 0x8e, 0x5c, 0x2, 0x0,  0x0,  0xf3, 0xf,  0x5e, 0xf0}};
inline constexpr std::array<int, 54> WatermarkAllInputTargetPattern{
    {0x40, 0x53, 0x48, 0x83, 0xec, 0x50, 0x48, 0x8b, 0x5, -1, -1,   -1,  -1,   0x48, 0x8b, 0xd9, 0xf,  0x29,
     0x74, 0x24, 0x40, 0x48, 0x8d, 0xd,  -1,   -1,   -1,  -1, 0x66, 0xf, 0x6e, 0x70, 0x58, 0xf,  0x5b, 0xf6,
     0xe8, -1,   -1,   -1,   -1,   0x48, 0x8b, 0x5,  -1,  -1, -1,   -1,  0xf3, 0xf,  0x5f, 0xf0, 0x80, 0x78}};
inline constexpr std::array<int, 32> WatermarkAllPredictionCountPattern{
    {0x48, 0x8b, 0xc4, 0x48, 0x89, 0x58, 0x10, 0x57, 0x48, 0x81, 0xec, 0x90, 0x0,  0x0,  0x0,  0x83,
     0xb9, 0xc,  0x1,  0x0,  0x0,  0x0,  0x8b, 0xfa, 0xf,  0x29, 0x70, 0xe8, 0x48, 0x8b, 0xd9, 0xf}};
inline constexpr std::array<int, 32> WatermarkAllClockStartPattern{
    {0x48, 0x8b, 0xc4, 0x55, 0x41, 0x54, 0x41, 0x55, 0x41, 0x56, 0x41, 0x57, 0x48, 0x8d, 0x68, 0xb8,
     0x48, 0x81, 0xec, 0x20, 0x1,  0x0,  0x0,  0x48, 0x89, 0x70, 0xd0, 0x45, 0x33, 0xf6, 0x48, 0x89}};
inline constexpr std::array<int, 160> WatermarkAllTrafficPattern{
    {0x40, 0x57, 0x48, 0x83, 0xec, 0x30, 0x48, 0x89, 0x74, 0x24, 0x48, 0x48, 0x8b, 0xf9, 0x8b, 0xf2,
     0x8b, 0x91, 0xc8, 0x8e, 0x0,  0x0,  0x85, 0xd2, 0x74, 0x60, 0xf2, 0xf,  0x10, 0x5,  -1,   -1,
     -1,   -1,   0x66, 0xf,  0x2e, 0x81, 0xf8, 0x8e, 0x0,  0x0,  0x7a, 0x2,  0x74, 0x4c, 0xf2, 0xf,
     0x11, 0x81, 0xf8, 0x8e, 0x0,  0x0,  0x4c, 0x8d, 0x87, 0x0,  0x8f, 0x0,  0x0,  0x48, 0x89, 0x5c,
     0x24, 0x40, 0x45, 0x33, 0xc9, 0x8b, 0x99, 0x38, 0x8f, 0x0,  0x0,  0x48, 0x8b, 0xd,  -1,   -1,
     -1,   -1,   0x48, 0xc7, 0x44, 0x24, 0x20, 0x0,  0x0,  0x0,  0x0,  0x48, 0x8b, 0x1,  0xff, 0x90,
     0x80, 0x0,  0x0,  0x0,  0x8b, 0x87, 0x38, 0x8f, 0x0,  0x0,  0x3b, 0xd8, 0xf,  0x4e, 0xd8, 0x89,
     0x9f, 0x38, 0x8f, 0x0,  0x0,  0x48, 0x8b, 0x5c, 0x24, 0x40, 0x83, 0xfe, 0x1,  0x48, 0x8b, 0x74,
     0x24, 0x48, 0x75, 0xe,  0xf3, 0xf,  0x10, 0x87, 0x1c, 0x8f, 0x0,  0x0,  0x48, 0x83, 0xc4, 0x30,
     0x5f, 0xc3, 0xf3, 0xf,  0x10, 0x87, 0x14, 0x8f, 0x0,  0x0,  0x48, 0x83, 0xc4, 0x30, 0x5f, 0xc3}};
inline constexpr std::array<int, 32> WatermarkAllAddressPattern{
    {0x40, 0x53, 0x48, 0x83, 0xec, 0x20, 0x48, 0x8b, 0xd9, 0x48, 0x81, 0xc1, 0x94, 0x8e, 0x0,  0x0,
     0x8b, 0x51, 0x1c, 0x85, 0xd2, 0xf,  0x84, 0x9e, 0x0,  0x0,  0x0,  0x83, 0xea, 0x1,  0x74, 0x12}};
inline constexpr std::array<int, 41> WatermarkAllLoopbackPattern{
    {0x48, 0x83, 0xec, 0x28, 0x48, 0x81, 0xc1, 0x94, 0x8e, 0x0,  0x0,  0x83, 0x79, 0x1c,
     0x0,  0x75, 0x11, 0xff, 0x15, -1,   -1,   -1,   -1,   0x84, 0xc0, 0x74, 0x7,  0xb0,
     0x1,  0x48, 0x83, 0xc4, 0x28, 0xc3, 0x32, 0xc0, 0x48, 0x83, 0xc4, 0x28, 0xc3}};
inline constexpr std::array<int, 11> WatermarkAllPlaybackPattern{
    {0x83, 0xb9, 0xb0, 0x8e, 0x0, 0x0, 0x4, 0xf, 0x94, 0xc0, 0xc3}};

inline std::optional<float> WatermarkNativeSignedRound(float value) {
    if (!std::isfinite(value) || value <= -2147483520.f || value >= 2147483520.f)
        return {};
    float result = std::trunc(value + (value < 0 ? -.4999999701976776f : .4999999701976776f));
    return result == 0 ? 0.f : result;
}
struct WatermarkNetworkAllLayout {
    std::uint32_t count = 0, received = 0;
    bool input = false;
};

template <class SpanReader>
WatermarkNetworkAllLayout WatermarkResolveNetworkAllSpan(SpanReader&& read, const WatermarkKdModule& engine) {
    WatermarkNetworkAllLayout out;
    std::size_t matches = 0;
    for (const auto& section : engine.sections) {
        if (!(section.flags & 0x20000000) || !section.size || section.size > 64u * 1024u * 1024u)
            continue;
        std::vector<unsigned char> bytes(section.size);
        if (!read(engine.base + section.rva, bytes.data(), bytes.size()))
            continue;
        auto found = WatermarkKdMatches(bytes.data(), bytes.size(), WatermarkAllInputAnchorPattern);
        matches += found.size();
    }
    out.input = matches == 1;
    if (out.input) {
        out.count = 0x258;
        out.received = 0x25C;
    }
    return out;
}
template <class Reader, std::size_t N>
bool WatermarkAllQuery(Reader&& read, const WatermarkKdModule& module, std::uintptr_t object, unsigned slot,
                       const std::array<int, N>& pattern, std::uintptr_t& fn) {
    std::array<unsigned char, N> bytes{};
    return WatermarkNetworkCode(read, module, object, slot, bytes, fn) &&
           WatermarkKdMatches(bytes.data(), bytes.size(), pattern).size() == 1;
}
template <class Reader, class Query>
std::optional<WatermarkInputTiming>
WatermarkReadInputTiming(Reader&& read, const WatermarkKdModule& engine, std::uintptr_t client,
                         const WatermarkNetworkAllLayout& layout, Query&& query) {
    if (!layout.input || !client)
        return {};
    std::int32_t count = 0, again = 0;
    float received = 0, target = 0;
    std::uintptr_t fn = 0;
    if (!read(client + layout.count, count) || count <= 0 || !read(client + layout.received, received) ||
        !std::isfinite(received) ||
        !WatermarkAllQuery(read, engine, client, 64, WatermarkAllInputTargetPattern, fn) ||
        !query(fn, client, target) || !std::isfinite(target) || !read(client + layout.count, again) ||
        again != count)
        return {};
    received *= 1000.f;
    target *= 1000.f;
    if (!std::isfinite(received) || !std::isfinite(target))
        return {};
    return WatermarkInputTiming{received, target};
}

template <class Reader>
std::optional<float> WatermarkReadPredictionLead(Reader&& read, const WatermarkKdModule& engine,
                                                 const WatermarkKdModule& clientModule,
                                                 std::uintptr_t networkClient, std::uintptr_t service,
                                                 std::uintptr_t prediction) {
    std::array<unsigned char, 8> getter{};
    std::uintptr_t fn = 0, object = 0, table = 0, again = 0;
    if (!networkClient || !prediction || !read(prediction, table) ||
        !WatermarkNetworkCode(read, engine, service, 23, getter, fn) || getter[0] != 0x48 ||
        getter[1] != 0x8B || getter[2] != 0x81 || getter[7] != 0xC3)
        return {};
    auto member = WatermarkNetworkOffset(getter, 3);
    if (member > 0x10000 || !read(service + member, object) || object != networkClient)
        return {};
    std::array<unsigned char, 8> clock{};
    if (!WatermarkNetworkCode(read, engine, object, 4, clock, fn) ||
        clock != std::array<unsigned char, 8>{{0x48, 0x8D, 0x81, 0x90, 0, 0, 0, 0xC3}})
        return {};
    if (!WatermarkAllQuery(read, engine, object, 25, WatermarkAllClockStartPattern, fn))
        return {};
    std::array<unsigned char, 6> clockStore{};
    std::array<unsigned char, 8> clockRead{};
    if (!WatermarkNetworkRange(engine, fn + 0x279, 6, true) || !read(fn + 0x279, clockStore) ||
        clockStore != std::array<unsigned char, 6>{{0x89, 0x86, 0xCC, 0, 0, 0}} ||
        !WatermarkNetworkRange(engine, fn + 0x5F5, 8, true) || !read(fn + 0x5F5, clockRead) ||
        clockRead != std::array<unsigned char, 8>{{0xF3, 0x0F, 0x10, 0xB6, 0xC0, 0, 0, 0}})
        return {};
    std::array<unsigned char, 32> countCode{};
    if (!WatermarkAllQuery(read, clientModule, prediction, 19, WatermarkAllPredictionCountPattern, fn) ||
        !read(fn, countCode))
        return {};
    auto countOffset = WatermarkNetworkOffset(countCode, 17);
    std::int32_t count = 0, check = 0;
    float time = 0, enabled = 0, fraction = 0;
    if (countOffset > 0x10000 || !read(prediction + countOffset, count) || count <= 0 ||
        !read(object + 0xC0, time) || !read(object + 0xC4, enabled) || !read(object + 0xCC, fraction) ||
        !std::isfinite(time) || !std::isfinite(enabled) || !std::isfinite(fraction) ||
        !read(prediction + countOffset, check) || check != count || !read(prediction, again) ||
        again != table)
        return {};
    float part = enabled != 0 ? fraction : 0.f;
    if (std::abs(part) > 1000000.f)
        return {};
    float whole = 0, remaining = part;
    if (part < 0 || part >= 1) {
        remaining = std::modf(part, &whole);
        if (remaining < 0) {
            remaining += 1.f;
            if (remaining >= 1.f)
                remaining = 0;
            else
                whole -= 1.f;
        }
    }
    auto tickSum = std::int64_t(count) + std::int64_t(whole);
    if (tickSum < std::numeric_limits<std::int32_t>::min() ||
        tickSum > std::numeric_limits<std::int32_t>::max())
        return {};
    float ticks = float(std::int32_t(tickSum));
    float result = (ticks * .015625f + remaining * .015625f - time) * 1000.f;
    float secondTime = 0, secondEnabled = 0, secondFraction = 0;
    if (!std::isfinite(result) || !read(object + 0xC0, secondTime) || secondTime != time ||
        !read(object + 0xC4, secondEnabled) || secondEnabled != enabled ||
        !read(object + 0xCC, secondFraction) || secondFraction != fraction ||
        !read(service + member, again) || again != object)
        return {};
    return result;
}
template <class Reader>
std::optional<std::string> WatermarkReadServerText(Reader&& read, std::uintptr_t address) {
    if (!address)
        return std::string("Unconnected");
    std::string text;
    for (std::size_t i = 0; i < 255; ++i) {
        unsigned char byte = 0;
        if (!read(address + i, byte))
            return {};
        if (!byte)
            return text;
        if (byte < 32 || byte >= 127)
            return {};
        text.push_back(char(byte));
    }
    return {};
}
template <class Reader, class Query>
std::optional<WatermarkDelivery> WatermarkReadNetworkTraffic(Reader&& read, const WatermarkKdModule& module,
                                                             std::uintptr_t channel, Query&& query) {
    std::uintptr_t fn = 0;
    float outgoing = 0, incoming = 0;
    if (!WatermarkAllQuery(read, module, channel, 15, WatermarkAllTrafficPattern, fn) ||
        !query(fn, channel, 0, outgoing) || !query(fn, channel, 1, incoming))
        return {};
    return WatermarkDelivery{WatermarkNetworkNonnegative(outgoing), WatermarkNetworkNonnegative(incoming)};
}
template <class Reader, class BoolQuery, class AddressQuery>
std::optional<std::string> WatermarkReadServerAddress(Reader&& read, const WatermarkKdModule& module,
                                                      std::uintptr_t channel, BoolQuery&& boolean,
                                                      AddressQuery&& addressQuery) {
    std::uintptr_t fn = 0;
    bool local = false, playback = false;
    if (!WatermarkAllQuery(read, module, channel, 6, WatermarkAllLoopbackPattern, fn) ||
        !boolean(fn, channel, local))
        return {};
    if (local)
        return std::string("Local Server");
    if (!WatermarkAllQuery(read, module, channel, 7, WatermarkAllPlaybackPattern, fn) ||
        !boolean(fn, channel, playback))
        return {};
    if (playback)
        return std::string("Local Server");
    std::uintptr_t address = 0;
    if (!WatermarkAllQuery(read, module, channel, 1, WatermarkAllAddressPattern, fn) ||
        !addressQuery(fn, channel, address))
        return {};
    return WatermarkReadServerText(read, address);
}
}
