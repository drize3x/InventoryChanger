#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>
namespace menu::svg {

struct Bitmap {
    int width = 0, height = 0;
    std::vector<unsigned char> rgba;
};

namespace detail {
constexpr double kPi = 3.14159265358979323846;
struct Pt {
    double x = 0, y = 0;
};
struct Color {
    double r = 0, g = 0, b = 0, a = 1;
};
struct Mat {
    double a = 1, b = 0, c = 0, d = 1, e = 0, f = 0;
    Pt Apply(Pt p) const {
        return {a * p.x + c * p.y + e, b * p.x + d * p.y + f};
    }
    double Det() const {
        return a * d - b * c;
    }
    double Scale() const {
        return std::sqrt(std::fabs(Det()));
    }
};
inline Mat Mul(const Mat& A, const Mat& B) {
    return {A.a * B.a + A.c * B.b, A.b * B.a + A.d * B.b,       A.a * B.c + A.c * B.d,
            A.b * B.c + A.d * B.d, A.a * B.e + A.c * B.f + A.e, A.b * B.e + A.d * B.f + A.f};
}
inline bool Invert(const Mat& m, Mat& o) {
    const double det = m.Det();
    if (!(std::fabs(det) > 1e-14))
        return false;
    const double i = 1 / det;
    o = {m.d * i, -m.b * i, -m.c * i, m.a * i, (m.c * m.f - m.d * m.e) * i, (m.b * m.e - m.a * m.f) * i};
    return true;
}
inline double Clamp(double v, double lo, double hi) {
    return v < lo ? lo : v > hi ? hi : v;
}
inline bool Space(char c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f';
}
inline std::string Trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && Space(s[a]))
        ++a;
    while (b > a && Space(s[b - 1]))
        --b;
    return s.substr(a, b - a);
}
inline std::string Lower(std::string s) {
    for (auto& c : s)
        if (c >= 'A' && c <= 'Z')
            c = char(c + 32);
    return s;
}
inline bool StartsWith(const std::string& s, size_t at, const char* lit) {
    const size_t n = std::strlen(lit);
    return s.compare(at, n, lit) == 0;
}

inline double ParseDecimal(const char* s, const char* q) {
    bool neg = false;
    if (s < q && (*s == '+' || *s == '-')) {
        neg = *s == '-';
        ++s;
    }
    unsigned long long mant = 0;
    int exp10 = 0, sig = 0;
    for (; s < q && *s >= '0' && *s <= '9'; ++s) {
        if (sig < 19) {
            mant = mant * 10ull + (unsigned long long)(*s - '0');
            if (mant > 0)
                ++sig;
        } else
            ++exp10;
    }
    if (s < q && *s == '.') {
        for (++s; s < q && *s >= '0' && *s <= '9'; ++s)
            if (sig < 19) {
                mant = mant * 10ull + (unsigned long long)(*s - '0');
                if (mant > 0)
                    ++sig;
                --exp10;
            }
    }
    if (s < q && (*s == 'e' || *s == 'E')) {
        ++s;
        bool eneg = false;
        if (s < q && (*s == '+' || *s == '-')) {
            eneg = *s == '-';
            ++s;
        }
        int e = 0;
        for (; s < q && *s >= '0' && *s <= '9'; ++s)
            if (e < 100000)
                e = e * 10 + (*s - '0');
        exp10 += eneg ? -e : e;
    }
    if (mant == 0)
        return 0;
    static const double kPow10[23] = {1e0,  1e1,  1e2,  1e3,  1e4,  1e5,  1e6,  1e7,  1e8,  1e9,  1e10, 1e11,
                                      1e12, 1e13, 1e14, 1e15, 1e16, 1e17, 1e18, 1e19, 1e20, 1e21, 1e22};
    const int n = exp10 < 0 ? -exp10 : exp10;
    const double scale = n <= 22 ? kPow10[n] : std::pow(10.0, double(n));
    const double m = double(mant), v = exp10 < 0 ? m / scale : m * scale;
    return neg ? -v : v;
}

inline bool ReadNumber(const char*& p, const char* end, double& out) {
    while (p < end && (Space(*p) || *p == ','))
        ++p;
    const char* s = p;
    const char* q = p;
    if (q < end && (*q == '+' || *q == '-'))
        ++q;
    bool digits = false;
    while (q < end && *q >= '0' && *q <= '9') {
        ++q;
        digits = true;
    }
    if (q < end && *q == '.') {
        ++q;
        while (q < end && *q >= '0' && *q <= '9') {
            ++q;
            digits = true;
        }
    }
    if (!digits)
        return false;
    if (q < end && (*q == 'e' || *q == 'E')) {
        const char* e = q + 1;
        if (e < end && (*e == '+' || *e == '-'))
            ++e;
        if (e < end && *e >= '0' && *e <= '9') {
            while (e < end && *e >= '0' && *e <= '9')
                ++e;
            q = e;
        }
    }
    out = Clamp(ParseDecimal(s, q), -1e9, 1e9);
    p = q;
    return true;
}

inline double ParseNumber(const std::string& t) {
    const char* p = t.data();
    double x = 0;
    return ReadNumber(p, t.data() + t.size(), x) ? x : 0;
}
inline std::vector<double> NumberList(const std::string& v) {
    std::vector<double> out;
    const char* p = v.data();
    const char* e = p + v.size();
    double x;
    while (ReadNumber(p, e, x))
        out.push_back(x);
    return out;
}
inline bool Length(const std::string& text, double base, double& out) {
    const std::string v = Trim(text);
    if (v.empty())
        return false;
    const char* p = v.data();
    const char* e = p + v.size();
    double x;
    if (!ReadNumber(p, e, x))
        return false;
    std::string unit = Lower(Trim(std::string(p, e)));
    if (unit.empty() || unit == "px")
        out = x;
    else if (unit == "%")
        out = x * base / 100;
    else if (unit == "pt")
        out = x * 4 / 3;
    else if (unit == "pc")
        out = x * 16;
    else if (unit == "mm")
        out = x * 96 / 25.4;
    else if (unit == "cm")
        out = x * 96 / 2.54;
    else if (unit == "in")
        out = x * 96;
    else if (unit == "em")
        out = x * 16;
    else if (unit == "ex")
        out = x * 8;
    else
        return false;
    return true;
}

struct Node {
    std::string tag, text;
    std::vector<std::pair<std::string, std::string>> attr;
    std::vector<std::unique_ptr<Node>> kids;
    Node* parent = nullptr;
    const std::string* Get(const char* k) const {
        for (const auto& a : attr)
            if (a.first == k)
                return &a.second;
        return nullptr;
    }
    std::string Str(const char* k, const char* def = "") const {
        auto v = Get(k);
        return v ? *v : std::string(def);
    }
};
inline void AppendUtf8(std::string& out, unsigned cp) {
    if (cp < 0x80)
        out.push_back(char(cp));
    else if (cp < 0x800) {
        out.push_back(char(0xC0 | (cp >> 6)));
        out.push_back(char(0x80 | (cp & 63)));
    } else if (cp < 0x10000) {
        out.push_back(char(0xE0 | (cp >> 12)));
        out.push_back(char(0x80 | ((cp >> 6) & 63)));
        out.push_back(char(0x80 | (cp & 63)));
    } else {
        out.push_back(char(0xF0 | (cp >> 18)));
        out.push_back(char(0x80 | ((cp >> 12) & 63)));
        out.push_back(char(0x80 | ((cp >> 6) & 63)));
        out.push_back(char(0x80 | (cp & 63)));
    }
}
inline std::string Entities(const std::string& s) {
    if (s.find('&') == std::string::npos)
        return s;
    std::string out;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] != '&') {
            out.push_back(s[i]);
            continue;
        }
        const size_t semi = s.find(';', i);
        if (semi == std::string::npos || semi - i > 10) {
            out.push_back('&');
            continue;
        }
        const std::string name = s.substr(i + 1, semi - i - 1);
        if (name == "amp")
            out.push_back('&');
        else if (name == "lt")
            out.push_back('<');
        else if (name == "gt")
            out.push_back('>');
        else if (name == "quot")
            out.push_back('"');
        else if (name == "apos")
            out.push_back('\'');
        else if (name.size() > 1 && name[0] == '#') {
            const bool hex = name[1] == 'x' || name[1] == 'X';
            const unsigned long cp = std::strtoul(name.c_str() + (hex ? 2 : 1), nullptr, hex ? 16 : 10);
            if (cp > 0 && cp < 0x110000)
                AppendUtf8(out, unsigned(cp));
        } else {
            out.push_back('&');
            continue;
        }
        i = semi;
    }
    return out;
}
inline std::string LocalName(const std::string& n) {
    const auto c = n.rfind(':');
    return c == std::string::npos ? n : n.substr(c + 1);
}
struct Document {
    std::unique_ptr<Node> root;
    std::map<std::string, const Node*> ids;
    int nodes = 0;
    const Node* Svg() const {
        if (!root)
            return nullptr;
        for (const auto& k : root->kids)
            if (k->tag == "svg")
                return k.get();
        return nullptr;
    }
};
inline void IndexIds(Document& d, const Node& n) {
    if (auto id = n.Get("id"))
        d.ids.emplace(*id, &n);
    for (const auto& k : n.kids)
        IndexIds(d, *k);
}
inline bool ParseXml(const std::string& s, Document& doc) {
    doc.root = std::make_unique<Node>();
    doc.root->tag = "#root";
    Node* cur = doc.root.get();
    size_t p = 0;
    const size_t n = s.size();
    int depth = 0;
    while (p < n) {
        if (s[p] != '<') {
            size_t q = s.find('<', p);
            if (q == std::string::npos)
                q = n;
            if (cur != doc.root.get())
                cur->text += Entities(s.substr(p, q - p));
            p = q;
            continue;
        }
        if (StartsWith(s, p, "<!--")) {
            const size_t q = s.find("-->", p + 4);
            if (q == std::string::npos)
                return false;
            p = q + 3;
            continue;
        }
        if (StartsWith(s, p, "<![CDATA[")) {
            const size_t q = s.find("]]>", p + 9);
            if (q == std::string::npos)
                return false;
            if (cur != doc.root.get())
                cur->text += s.substr(p + 9, q - p - 9);
            p = q + 3;
            continue;
        }
        if (StartsWith(s, p, "<?")) {
            const size_t q = s.find("?>", p + 2);
            if (q == std::string::npos)
                return false;
            p = q + 2;
            continue;
        }
        if (StartsWith(s, p, "<!")) {
            int br = 0;
            size_t q = p + 2;
            for (; q < n; ++q) {
                if (s[q] == '[')
                    ++br;
                else if (s[q] == ']')
                    --br;
                else if (s[q] == '>' && br <= 0)
                    break;
            }
            if (q >= n)
                return false;
            p = q + 1;
            continue;
        }
        if (StartsWith(s, p, "</")) {
            const size_t q = s.find('>', p);
            if (q == std::string::npos)
                return false;
            if (cur->parent) {
                cur = cur->parent;
                --depth;
            }
            p = q + 1;
            continue;
        }

        size_t q = p + 1;
        while (q < n && !Space(s[q]) && s[q] != '/' && s[q] != '>')
            ++q;
        auto node = std::make_unique<Node>();
        node->tag = LocalName(s.substr(p + 1, q - p - 1));
        bool selfClose = false;
        for (;;) {
            while (q < n && Space(s[q]))
                ++q;
            if (q >= n)
                return false;
            if (s[q] == '>') {
                ++q;
                break;
            }
            if (s[q] == '/') {
                selfClose = true;
                ++q;
                continue;
            }
            size_t a = q;
            while (q < n && !Space(s[q]) && s[q] != '=' && s[q] != '>' && s[q] != '/')
                ++q;
            std::string name = LocalName(s.substr(a, q - a));
            while (q < n && Space(s[q]))
                ++q;
            std::string value;
            if (q < n && s[q] == '=') {
                ++q;
                while (q < n && Space(s[q]))
                    ++q;
                if (q < n && (s[q] == '"' || s[q] == '\'')) {
                    const char quote = s[q];
                    const size_t e = s.find(quote, q + 1);
                    if (e == std::string::npos)
                        return false;
                    value = Entities(s.substr(q + 1, e - q - 1));
                    q = e + 1;
                } else {
                    const size_t b = q;
                    while (q < n && !Space(s[q]) && s[q] != '>')
                        ++q;
                    value = Entities(s.substr(b, q - b));
                }
            }
            if (!name.empty() && node->Get(name.c_str()) == nullptr)
                node->attr.emplace_back(name, value);
            else if (name.empty() && q < n)
                ++q;
        }
        if (++doc.nodes > 40000 || depth > 96)
            return false;
        node->parent = cur;
        Node* raw = node.get();
        cur->kids.push_back(std::move(node));
        if (!selfClose) {
            cur = raw;
            ++depth;
        }
        p = q;
    }
    IndexIds(doc, *doc.root);
    return doc.Svg() != nullptr;
}

struct Selector {
    std::string tag, id;
    std::vector<std::string> classes;
    int spec = 0;
};
struct Rule {
    Selector sel;
    std::vector<std::pair<std::string, std::string>> decl;
    int order = 0;
};
inline std::vector<std::pair<std::string, std::string>> Declarations(const std::string& text) {
    std::vector<std::pair<std::string, std::string>> out;
    size_t p = 0;
    while (p < text.size()) {
        size_t e = text.find(';', p);
        if (e == std::string::npos)
            e = text.size();
        const std::string item = text.substr(p, e - p);
        const size_t c = item.find(':');
        if (c != std::string::npos) {
            std::string v = Trim(item.substr(c + 1));
            const size_t imp = v.find("!important");
            if (imp != std::string::npos)
                v = Trim(v.substr(0, imp));
            out.emplace_back(Lower(Trim(item.substr(0, c))), v);
        }
        p = e + 1;
    }
    return out;
}
inline void ParseCss(const std::string& css, std::vector<Rule>& rules) {
    std::string s;
    for (size_t i = 0; i < css.size(); ++i) {
        if (css[i] == '/' && i + 1 < css.size() && css[i + 1] == '*') {
            const size_t e = css.find("*/", i + 2);
            if (e == std::string::npos)
                break;
            i = e + 1;
        } else
            s.push_back(css[i]);
    }
    size_t p = 0;
    while (p < s.size()) {
        const size_t open = s.find('{', p);
        if (open == std::string::npos)
            break;
        int depth = 1;
        size_t close = open + 1;
        for (; close < s.size() && depth > 0; ++close) {
            if (s[close] == '{')
                ++depth;
            else if (s[close] == '}')
                --depth;
        }
        if (depth > 0)
            break;
        --close;
        const std::string head = Trim(s.substr(p, open - p)), body = s.substr(open + 1, close - open - 1);
        p = close + 1;
        if (head.empty() || head[0] == '@')
            continue;
        size_t a = 0;
        while (a <= head.size()) {
            size_t b = head.find(',', a);
            if (b == std::string::npos)
                b = head.size();
            std::string one = Trim(head.substr(a, b - a));
            a = b + 1;
            if (one.empty())
                continue;
            if (one.find_first_of(" >+~:[") != std::string::npos)
                continue;
            Selector sel;
            size_t i = 0;
            while (i < one.size()) {
                const char kind = one[i];
                size_t j = i + (kind == '.' || kind == '#' ? 1 : 0);
                size_t k = j;
                while (k < one.size() && one[k] != '.' && one[k] != '#')
                    ++k;
                const std::string name = one.substr(j, k - j);
                if (kind == '.') {
                    sel.classes.push_back(name);
                    sel.spec += 10;
                } else if (kind == '#') {
                    sel.id = name;
                    sel.spec += 100;
                } else if (name != "*") {
                    sel.tag = Lower(name);
                    sel.spec += 1;
                }
                i = k;
            }
            Rule r;
            r.sel = sel;
            r.decl = Declarations(body);
            r.order = int(rules.size());
            rules.push_back(std::move(r));
        }
    }
}
inline bool Matches(const Selector& s, const Node& n) {
    if (!s.tag.empty() && s.tag != n.tag)
        return false;
    if (!s.id.empty() && n.Str("id") != s.id)
        return false;
    if (!s.classes.empty()) {
        const std::string cls = " " + n.Str("class") + " ";
        for (const auto& c : s.classes) {
            std::string needle = " " + c + " ";
            std::string flat = cls;
            for (auto& ch : flat)
                if (Space(ch))
                    ch = ' ';
            if (flat.find(needle) == std::string::npos)
                return false;
        }
    }
    return true;
}
inline void CollectCss(const Node& n, std::string& out) {
    if (n.tag == "style")
        out += n.text + "\n";
    for (const auto& k : n.kids)
        CollectCss(*k, out);
}

inline bool NamedColor(const std::string& name, Color& c) {
    struct E {
        const char* n;
        unsigned v;
    };
    static const E table[] = {
        {"black", 0x000000},    {"white", 0xffffff},     {"red", 0xff0000},       {"lime", 0x00ff00},
        {"blue", 0x0000ff},     {"yellow", 0xffff00},    {"cyan", 0x00ffff},      {"aqua", 0x00ffff},
        {"magenta", 0xff00ff},  {"fuchsia", 0xff00ff},   {"gray", 0x808080},      {"grey", 0x808080},
        {"silver", 0xc0c0c0},   {"maroon", 0x800000},    {"olive", 0x808000},     {"green", 0x008000},
        {"purple", 0x800080},   {"teal", 0x008080},      {"navy", 0x000080},      {"orange", 0xffa500},
        {"gold", 0xffd700},     {"brown", 0xa52a2a},     {"pink", 0xffc0cb},      {"darkgray", 0xa9a9a9},
        {"darkgrey", 0xa9a9a9}, {"lightgray", 0xd3d3d3}, {"lightgrey", 0xd3d3d3}, {"dimgray", 0x696969},
        {"tan", 0xd2b48c},      {"khaki", 0xf0e68c},     {"beige", 0xf5f5dc},     {"ivory", 0xfffff0}};
    for (const auto& e : table)
        if (name == e.n) {
            c = {double((e.v >> 16) & 255) / 255, double((e.v >> 8) & 255) / 255, double(e.v & 255) / 255, 1};
            return true;
        }
    return false;
}
inline bool ParseColor(const std::string& text, const Color& current, Color& out) {
    const std::string v = Lower(Trim(text));
    if (v.empty())
        return false;
    if (v == "currentcolor") {
        out = current;
        return true;
    }
    if (v == "transparent") {
        out = {0, 0, 0, 0};
        return true;
    }
    if (v[0] == '#') {
        auto hex = [&](char ch) -> int {
            return ch >= '0' && ch <= '9' ? ch - '0' : ch >= 'a' && ch <= 'f' ? ch - 'a' + 10 : -1;
        };
        std::vector<int> d;
        for (size_t i = 1; i < v.size(); ++i) {
            const int h = hex(v[i]);
            if (h < 0)
                return false;
            d.push_back(h);
        }
        if (d.size() == 3 || d.size() == 4) {
            out = {d[0] * 17 / 255.0, d[1] * 17 / 255.0, d[2] * 17 / 255.0,
                   d.size() == 4 ? d[3] * 17 / 255.0 : 1};
            return true;
        }
        if (d.size() == 6 || d.size() == 8) {
            out = {(d[0] * 16 + d[1]) / 255.0, (d[2] * 16 + d[3]) / 255.0, (d[4] * 16 + d[5]) / 255.0,
                   d.size() == 8 ? (d[6] * 16 + d[7]) / 255.0 : 1};
            return true;
        }
        return false;
    }
    if (v.compare(0, 3, "rgb") == 0) {
        const size_t o = v.find('('), c = v.find(')');
        if (o == std::string::npos || c == std::string::npos || c < o)
            return false;
        std::vector<double> part;
        std::vector<bool> pct;
        const std::string body = v.substr(o + 1, c - o - 1);
        size_t a = 0;
        while (a < body.size()) {
            size_t b = body.find_first_of(",/ ", a);
            if (b == std::string::npos)
                b = body.size();
            std::string item = Trim(body.substr(a, b - a));
            a = b + 1;
            if (item.empty())
                continue;
            const bool pc = item.back() == '%';
            if (pc)
                item.pop_back();
            part.push_back(ParseNumber(item));
            pct.push_back(pc);
        }
        if (part.size() < 3)
            return false;
        auto ch = [&](size_t i) { return Clamp(pct[i] ? part[i] / 100 : part[i] / 255, 0, 1); };
        out = {ch(0), ch(1), ch(2), part.size() > 3 ? Clamp(pct[3] ? part[3] / 100 : part[3], 0, 1) : 1};
        return true;
    }
    return NamedColor(v, out);
}
struct PaintSpec {
    enum Kind { None, Solid, Url } kind = None;
    Color c{0, 0, 0, 1};
    std::string url;
};
struct Style {
    PaintSpec fill{PaintSpec::Solid, {0, 0, 0, 1}, {}}, stroke;
    double fillOpacity = 1, strokeOpacity = 1, strokeWidth = 1, miter = 4, dashOffset = 0, opacity = 1,
           stopOpacity = 1;
    bool evenOdd = false, clipEvenOdd = false, hidden = false, none = false;
    int cap = 0, join = 0;
    std::vector<double> dash;
    Color color{0, 0, 0, 1}, stopColor{0, 0, 0, 1};
    std::string clip;
};
using Props = std::map<std::string, std::string>;
inline PaintSpec ParsePaint(const std::string& text, const Color& current, const PaintSpec& fallback) {
    const std::string v = Trim(text);
    PaintSpec p;
    if (Lower(v) == "none") {
        p.kind = PaintSpec::None;
        return p;
    }
    if (v.compare(0, 4, "url(") == 0) {
        const size_t c = v.find(')');
        if (c == std::string::npos)
            return fallback;
        std::string id = Trim(v.substr(4, c - 4));
        if (!id.empty() && (id[0] == '"' || id[0] == '\''))
            id = id.substr(1, id.size() - 2);
        if (!id.empty() && id[0] == '#')
            id = id.substr(1);
        p.kind = PaintSpec::Url;
        p.url = id;
        Color fb;
        const std::string rest = Trim(v.substr(c + 1));
        if (!rest.empty() && ParseColor(rest, current, fb))
            p.c = fb;
        else
            p.c = {0, 0, 0, 0};
        return p;
    }
    Color c;
    if (ParseColor(v, current, c)) {
        p.kind = PaintSpec::Solid;
        p.c = c;
        return p;
    }
    return fallback;
}
inline Style Resolve(const Style& parent, const Props& pr, bool root) {
    Style s = parent;
    s.opacity = 1;
    s.clip.clear();
    s.none = false;
    s.stopOpacity = 1;
    s.stopColor = {0, 0, 0, 1};
    (void)root;
    auto get = [&](const char* k) -> const std::string* {
        auto it = pr.find(k);
        return it == pr.end() || it->second == "inherit" ? nullptr : &it->second;
    };
    auto num = [&](const char* k, double& out, double base = 1) {
        if (auto v = get(k)) {
            double x;
            if (Length(*v, base, x))
                out = x;
        }
    };
    if (auto v = get("color")) {
        Color c;
        if (ParseColor(*v, s.color, c))
            s.color = c;
    }
    if (auto v = get("fill"))
        s.fill = ParsePaint(*v, s.color, s.fill);
    if (auto v = get("stroke"))
        s.stroke = ParsePaint(*v, s.color, s.stroke);
    auto frac = [&](const char* k, double& out) {
        if (auto v = get(k)) {
            double x;
            const std::string t = Trim(*v);
            if (!t.empty() && Length(t, 1, x))
                out = Clamp(x, 0, 1);
        }
    };
    frac("fill-opacity", s.fillOpacity);
    frac("stroke-opacity", s.strokeOpacity);
    frac("opacity", s.opacity);
    frac("stop-opacity", s.stopOpacity);
    num("stroke-width", s.strokeWidth, 1);
    num("stroke-miterlimit", s.miter);
    num("stroke-dashoffset", s.dashOffset);
    if (auto v = get("fill-rule"))
        s.evenOdd = Lower(Trim(*v)) == "evenodd";
    if (auto v = get("clip-rule"))
        s.clipEvenOdd = Lower(Trim(*v)) == "evenodd";
    if (auto v = get("stroke-linecap")) {
        const auto t = Lower(Trim(*v));
        s.cap = t == "round" ? 1 : t == "square" ? 2 : 0;
    }
    if (auto v = get("stroke-linejoin")) {
        const auto t = Lower(Trim(*v));
        s.join = t == "round" ? 1 : t == "bevel" ? 2 : 0;
    }
    if (auto v = get("stroke-dasharray")) {
        const auto t = Lower(Trim(*v));
        s.dash.clear();
        if (t != "none") {
            s.dash = NumberList(*v);
            double sum = 0;
            for (double d : s.dash) {
                if (d < 0) {
                    sum = -1;
                    break;
                }
                sum += d;
            }
            if (!(sum > 0))
                s.dash.clear();
            else if (s.dash.size() % 2) {
                auto copy = s.dash;
                s.dash.insert(s.dash.end(), copy.begin(), copy.end());
            }
        }
    }
    if (auto v = get("display"))
        s.none = Lower(Trim(*v)) == "none";
    if (auto v = get("visibility")) {
        const auto t = Lower(Trim(*v));
        s.hidden = t == "hidden" || t == "collapse";
    }
    if (auto v = get("stop-color")) {
        Color c;
        if (ParseColor(*v, s.color, c))
            s.stopColor = c;
    }
    if (auto v = get("clip-path")) {
        const std::string t = Trim(*v);
        if (t.compare(0, 4, "url(") == 0) {
            const size_t c = t.find(')');
            if (c != std::string::npos) {
                std::string id = Trim(t.substr(4, c - 4));
                if (!id.empty() && (id[0] == '"' || id[0] == '\''))
                    id = id.substr(1, id.size() - 2);
                if (!id.empty() && id[0] == '#')
                    id = id.substr(1);
                s.clip = id;
            }
        }
    }
    return s;
}
inline Mat ParseTransform(const std::string& text) {
    Mat m;
    size_t p = 0;
    const std::string s = text;
    while (p < s.size()) {
        while (p < s.size() && (Space(s[p]) || s[p] == ','))
            ++p;
        if (p >= s.size())
            break;
        size_t q = p;
        while (q < s.size() && s[q] != '(' && !Space(s[q]))
            ++q;
        const std::string name = s.substr(p, q - p);
        while (q < s.size() && s[q] != '(')
            ++q;
        const size_t close = s.find(')', q);
        if (q >= s.size() || close == std::string::npos)
            break;
        const auto v = NumberList(s.substr(q + 1, close - q - 1));
        p = close + 1;
        Mat t;
        if (name == "matrix" && v.size() >= 6)
            t = {v[0], v[1], v[2], v[3], v[4], v[5]};
        else if (name == "translate" && !v.empty())
            t = {1, 0, 0, 1, v[0], v.size() > 1 ? v[1] : 0};
        else if (name == "scale" && !v.empty())
            t = {v[0], 0, 0, v.size() > 1 ? v[1] : v[0], 0, 0};
        else if (name == "rotate" && !v.empty()) {
            const double a = v[0] * kPi / 180, c = std::cos(a), sn = std::sin(a);
            t = {c, sn, -sn, c, 0, 0};
            if (v.size() >= 3) {
                Mat pre{1, 0, 0, 1, v[1], v[2]}, post{1, 0, 0, 1, -v[1], -v[2]};
                t = Mul(pre, Mul(t, post));
            }
        } else if (name == "skewx" || name == "skewX") {
            if (!v.empty())
                t = {1, 0, std::tan(v[0] * kPi / 180), 1, 0, 0};
        } else if (name == "skewy" || name == "skewY") {
            if (!v.empty())
                t = {1, std::tan(v[0] * kPi / 180), 0, 1, 0, 0};
        } else
            continue;
        m = Mul(m, t);
    }
    return m;
}

struct Cmd {
    char t = 'M';
    double v[6] = {0, 0, 0, 0, 0, 0};
};
inline Cmd MakeCmd(char t, double a = 0, double b = 0, double c = 0, double d = 0, double e = 0,
                   double f = 0) {
    Cmd k;
    k.t = t;
    k.v[0] = a;
    k.v[1] = b;
    k.v[2] = c;
    k.v[3] = d;
    k.v[4] = e;
    k.v[5] = f;
    return k;
}
inline double AngleBetween(double ux, double uy, double vx, double vy) {
    const double len = std::sqrt((ux * ux + uy * uy) * (vx * vx + vy * vy));
    if (!(len > 0))
        return 0;
    const double a = std::acos(Clamp((ux * vx + uy * vy) / len, -1, 1));
    return ux * vy - uy * vx < 0 ? -a : a;
}

inline void ArcTo(std::vector<Cmd>& out, double x0, double y0, double rx, double ry, double deg, bool large,
                  bool sweep, double x, double y) {
    if (x0 == x && y0 == y)
        return;
    rx = std::fabs(rx);
    ry = std::fabs(ry);
    if (!(rx > 1e-12) || !(ry > 1e-12)) {
        out.push_back(MakeCmd('L', x, y));
        return;
    }
    const double phi = deg * kPi / 180, cp = std::cos(phi), sp = std::sin(phi);
    const double dx = (x0 - x) / 2, dy = (y0 - y) / 2, x1 = cp * dx + sp * dy, y1 = -sp * dx + cp * dy;
    const double lam = x1 * x1 / (rx * rx) + y1 * y1 / (ry * ry);
    if (lam > 1) {
        const double s = std::sqrt(lam);
        rx *= s;
        ry *= s;
    }
    const double num = rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1,
                 den = rx * rx * y1 * y1 + ry * ry * x1 * x1;
    double coef = den > 0 ? std::sqrt(std::max(0.0, num / den)) : 0;
    if (large == sweep)
        coef = -coef;
    const double cxp = coef * rx * y1 / ry, cyp = -coef * ry * x1 / rx;
    const double cx = cp * cxp - sp * cyp + (x0 + x) / 2, cy = sp * cxp + cp * cyp + (y0 + y) / 2;
    const double ux = (x1 - cxp) / rx, uy = (y1 - cyp) / ry, vx = (-x1 - cxp) / rx, vy = (-y1 - cyp) / ry;
    const double th = AngleBetween(1, 0, ux, uy);
    double dth = AngleBetween(ux, uy, vx, vy);
    if (!sweep && dth > 0)
        dth -= 2 * kPi;
    else if (sweep && dth < 0)
        dth += 2 * kPi;
    const int n = std::max(1, int(std::ceil(std::fabs(dth) / (kPi / 2) - 1e-9)));
    const double step = dth / n, k = 4.0 / 3.0 * std::tan(step / 4);
    auto map = [&](double px, double py) {
        return Pt{cp * rx * px - sp * ry * py + cx, sp * rx * px + cp * ry * py + cy};
    };
    for (int i = 0; i < n; ++i) {
        const double a1 = th + step * i, a2 = a1 + step;
        const Pt c1 = map(std::cos(a1) - k * std::sin(a1), std::sin(a1) + k * std::cos(a1)),
                 c2 = map(std::cos(a2) + k * std::sin(a2), std::sin(a2) - k * std::cos(a2));
        const Pt e = i == n - 1 ? Pt{x, y} : map(std::cos(a2), std::sin(a2));
        out.push_back(MakeCmd('C', c1.x, c1.y, c2.x, c2.y, e.x, e.y));
    }
}
inline std::vector<Cmd> ParsePath(const std::string& d) {
    std::vector<Cmd> out;
    const char* p = d.data();
    const char* e = p + d.size();
    double cx = 0, cy = 0, sx = 0, sy = 0, lx = 0, ly = 0;
    char cmd = 0, kind = 0;
    bool started = false, afterClose = false;
    auto skip = [&] {
        while (p < e && (Space(*p) || *p == ','))
            ++p;
    };
    auto flag = [&](bool& f) {
        skip();
        if (p < e && (*p == '0' || *p == '1')) {
            f = *p == '1';
            ++p;
            return true;
        }
        return false;
    };
    for (;;) {
        skip();
        if (p >= e || out.size() > 200000)
            break;
        const char c = *p;
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
            cmd = c;
            ++p;
        } else {
            if (cmd == 0 || cmd == 'Z' || cmd == 'z')
                break;
            if (cmd == 'M')
                cmd = 'L';
            else if (cmd == 'm')
                cmd = 'l';
        }
        const bool rel = cmd >= 'a';
        const char up = char(rel ? cmd - 32 : cmd);
        if (!started && up != 'M')
            break;
        if (up == 'Z') {
            out.push_back(MakeCmd('Z'));
            cx = sx;
            cy = sy;
            kind = 'Z';
            afterClose = true;
            continue;
        }
        double a[7] = {0, 0, 0, 0, 0, 0, 0};
        auto need = [&](int from, int to) {
            for (int i = from; i < to; ++i)
                if (!ReadNumber(p, e, a[i]))
                    return false;
            return true;
        };
        const double ox = rel ? cx : 0, oy = rel ? cy : 0;
        bool ok = true;
        const bool needMove = afterClose && up != 'M';
        const size_t before = out.size();
        switch (up) {
        case 'M': {
            ok = need(0, 2);
            if (!ok)
                break;
            out.push_back(MakeCmd('M', a[0] + ox, a[1] + oy));
            cx = sx = a[0] + ox;
            cy = sy = a[1] + oy;
            started = true;
            afterClose = false;
            kind = 'M';
            break;
        }
        case 'L': {
            ok = need(0, 2);
            if (!ok)
                break;
            out.push_back(MakeCmd('L', a[0] + ox, a[1] + oy));
            cx = a[0] + ox;
            cy = a[1] + oy;
            kind = 'L';
            break;
        }
        case 'H': {
            ok = need(0, 1);
            if (!ok)
                break;
            out.push_back(MakeCmd('L', a[0] + ox, cy));
            cx = a[0] + ox;
            kind = 'L';
            break;
        }
        case 'V': {
            ok = need(0, 1);
            if (!ok)
                break;
            out.push_back(MakeCmd('L', cx, a[0] + oy));
            cy = a[0] + oy;
            kind = 'L';
            break;
        }
        case 'C': {
            ok = need(0, 6);
            if (!ok)
                break;
            out.push_back(MakeCmd('C', a[0] + ox, a[1] + oy, a[2] + ox, a[3] + oy, a[4] + ox, a[5] + oy));
            lx = a[2] + ox;
            ly = a[3] + oy;
            cx = a[4] + ox;
            cy = a[5] + oy;
            kind = 'C';
            break;
        }
        case 'S': {
            ok = need(0, 4);
            if (!ok)
                break;
            const double x1 = kind == 'C' ? 2 * cx - lx : cx, y1 = kind == 'C' ? 2 * cy - ly : cy;
            out.push_back(MakeCmd('C', x1, y1, a[0] + ox, a[1] + oy, a[2] + ox, a[3] + oy));
            lx = a[0] + ox;
            ly = a[1] + oy;
            cx = a[2] + ox;
            cy = a[3] + oy;
            kind = 'C';
            break;
        }
        case 'Q':
        case 'T': {
            double qx, qy, x, y;
            if (up == 'Q') {
                ok = need(0, 4);
                if (!ok)
                    break;
                qx = a[0] + ox;
                qy = a[1] + oy;
                x = a[2] + ox;
                y = a[3] + oy;
            } else {
                ok = need(0, 2);
                if (!ok)
                    break;
                qx = kind == 'Q' ? 2 * cx - lx : cx;
                qy = kind == 'Q' ? 2 * cy - ly : cy;
                x = a[0] + ox;
                y = a[1] + oy;
            }
            out.push_back(MakeCmd('C', cx + 2.0 / 3 * (qx - cx), cy + 2.0 / 3 * (qy - cy),
                                  x + 2.0 / 3 * (qx - x), y + 2.0 / 3 * (qy - y), x, y));
            lx = qx;
            ly = qy;
            cx = x;
            cy = y;
            kind = 'Q';
            break;
        }
        case 'A': {
            bool large = false, sweep = false;
            ok = need(0, 3) && flag(large) && flag(sweep) && need(5, 7);
            if (!ok)
                break;
            const double x = a[5] + ox, y = a[6] + oy;
            ArcTo(out, cx, cy, a[0], a[1], a[2], large, sweep, x, y);
            cx = x;
            cy = y;
            kind = 'A';
            break;
        }
        default:
            ok = false;
            break;
        }
        if (!ok)
            break;
        if (needMove) {
            out.insert(out.begin() + std::ptrdiff_t(before), MakeCmd('M', sx, sy));
            afterClose = false;
        }
    }
    return out;
}

struct Poly {
    std::vector<Pt> pts;
    bool closed = false;
};
using Ring = std::vector<Pt>;
inline void FlattenCubic(std::vector<Pt>& out, Pt p0, Pt p1, Pt p2, Pt p3, double tol) {
    const double d1 = std::hypot(p0.x - 2 * p1.x + p2.x, p0.y - 2 * p1.y + p2.y),
                 d2 = std::hypot(p1.x - 2 * p2.x + p3.x, p1.y - 2 * p2.y + p3.y);
    int n = int(std::ceil(std::sqrt(0.75 * std::max(d1, d2) / std::max(tol, 1e-9))));
    n = std::max(1, std::min(n, 256));
    for (int i = 1; i <= n; ++i) {
        const double t = double(i) / n, u = 1 - t, b0 = u * u * u, b1 = 3 * u * u * t, b2 = 3 * u * t * t,
                     b3 = t * t * t;
        out.push_back(
            {b0 * p0.x + b1 * p1.x + b2 * p2.x + b3 * p3.x, b0 * p0.y + b1 * p1.y + b2 * p2.y + b3 * p3.y});
    }
}
inline std::vector<Poly> Flatten(const std::vector<Cmd>& cmds, const Mat& m, double tol) {
    std::vector<Poly> out;
    Pt cur, start;
    bool open = false;
    for (const auto& c : cmds) {
        switch (c.t) {
        case 'M': {
            out.emplace_back();
            cur = m.Apply({c.v[0], c.v[1]});
            start = cur;
            out.back().pts.push_back(cur);
            open = true;
            break;
        }
        case 'L': {
            if (!open)
                break;
            cur = m.Apply({c.v[0], c.v[1]});
            out.back().pts.push_back(cur);
            break;
        }
        case 'C': {
            if (!open)
                break;
            const Pt p1 = m.Apply({c.v[0], c.v[1]}), p2 = m.Apply({c.v[2], c.v[3]}),
                     p3 = m.Apply({c.v[4], c.v[5]});
            FlattenCubic(out.back().pts, cur, p1, p2, p3, tol);
            cur = p3;
            break;
        }
        case 'Z': {
            if (!open)
                break;
            out.back().closed = true;
            cur = start;
            open = false;
            break;
        }
        default:
            break;
        }
    }
    return out;
}
inline std::vector<Poly> Dash(const std::vector<Poly>& in, const std::vector<double>& dash, double offset) {
    double total = 0;
    for (double d : dash)
        total += d;
    if (!(total > 0) || dash.empty())
        return in;
    std::vector<Poly> out;
    size_t pieces = 0;
    for (const auto& poly : in) {
        std::vector<Pt> pts = poly.pts;
        if (poly.closed && !pts.empty())
            pts.push_back(pts.front());
        if (pts.size() < 2) {
            out.push_back(poly);
            continue;
        }
        double off = std::fmod(offset, total);
        if (off < 0)
            off += total;
        size_t idx = 0;
        while (off > dash[idx] || (off == dash[idx] && dash[idx] > 0)) {
            off -= dash[idx];
            idx = (idx + 1) % dash.size();
        }
        double remain = dash[idx] - off;
        bool on = idx % 2 == 0;
        Poly cur;
        if (on)
            cur.pts.push_back(pts[0]);
        for (size_t i = 0; i + 1 < pts.size(); ++i) {
            const Pt a = pts[i], b = pts[i + 1];
            const double len = std::hypot(b.x - a.x, b.y - a.y);
            double pos = 0;
            while (len - pos > remain) {
                pos += remain;
                const Pt q{a.x + (b.x - a.x) * pos / len, a.y + (b.y - a.y) * pos / len};
                if (on) {
                    cur.pts.push_back(q);
                    out.push_back(cur);
                    cur = Poly();
                    if (++pieces > 20000)
                        return out;
                } else {
                    cur = Poly();
                    cur.pts.push_back(q);
                }
                on = !on;
                idx = (idx + 1) % dash.size();
                remain = dash[idx];
            }
            remain -= len - pos;
            if (on)
                cur.pts.push_back(b);
        }
        if (on && !cur.pts.empty())
            out.push_back(cur);
    }
    return out;
}
inline void AddCircle(std::vector<Ring>& out, Pt c, double r, int n) {
    Ring ring;
    for (int i = 0; i < n; ++i) {
        const double a = 2 * kPi * i / n;
        ring.push_back({c.x + r * std::cos(a), c.y + r * std::sin(a)});
    }
    out.push_back(std::move(ring));
}

inline void Stroke(const std::vector<Poly>& in, double width, int cap, int join, double miter, double tol,
                   std::vector<Ring>& out) {
    const double hw = width / 2;
    if (!(hw > 0))
        return;
    const int circleN = std::max(
        8, std::min(64, int(std::ceil(kPi / std::acos(std::max(0.0, 1 - tol / std::max(hw, tol)))))));
    for (const auto& poly : in) {
        std::vector<Pt> p;
        for (const auto& q : poly.pts)
            if (p.empty() || std::hypot(q.x - p.back().x, q.y - p.back().y) > 1e-9)
                p.push_back(q);
        bool closed = poly.closed;
        if (closed && p.size() > 1 && std::hypot(p.front().x - p.back().x, p.front().y - p.back().y) <= 1e-9)
            p.pop_back();
        if (p.size() == 1) {
            if (cap == 1)
                AddCircle(out, p[0], hw, circleN);
            else if (cap == 2)
                out.push_back({{p[0].x - hw, p[0].y - hw},
                               {p[0].x + hw, p[0].y - hw},
                               {p[0].x + hw, p[0].y + hw},
                               {p[0].x - hw, p[0].y + hw}});
            continue;
        }
        if (p.size() < 2)
            continue;
        if (closed && p.size() < 3)
            closed = false;
        const size_t n = p.size(), segs = closed ? n : n - 1;
        std::vector<Pt> dir(segs);
        for (size_t i = 0; i < segs; ++i) {
            const Pt a = p[i], b = p[(i + 1) % n];
            const double len = std::hypot(b.x - a.x, b.y - a.y);
            const Pt d{(b.x - a.x) / len, (b.y - a.y) / len};
            dir[i] = d;
            const Pt nn{-d.y * hw, d.x * hw};
            out.push_back({{a.x + nn.x, a.y + nn.y},
                           {b.x + nn.x, b.y + nn.y},
                           {b.x - nn.x, b.y - nn.y},
                           {a.x - nn.x, a.y - nn.y}});
        }
        for (size_t i = closed ? 0 : 1, last = closed ? n : n - 1; i < last; ++i) {
            const Pt d0 = dir[(i + segs - 1) % segs], d1 = dir[i % segs], v = p[i % n];
            const double cross = d0.x * d1.y - d0.y * d1.x, dot = d0.x * d1.x + d0.y * d1.y;
            if (std::fabs(cross) < 1e-9 && dot > 0)
                continue;
            if (join == 1 && dot < 0.995) {
                AddCircle(out, v, hw, circleN);
                continue;
            }
            const double s = cross > 0 ? -1 : 1;
            const Pt n0{-d0.y * hw * s, d0.x * hw * s}, n1{-d1.y * hw * s, d1.x * hw * s},
                A{v.x + n0.x, v.y + n0.y}, B{v.x + n1.x, v.y + n1.y};
            if (join == 0 && 1 + dot > 1e-12 && std::sqrt(2 / (1 + dot)) <= miter) {
                const double k = 1 / (1 + dot);
                out.push_back({v, A, {v.x + (n0.x + n1.x) * k, v.y + (n0.y + n1.y) * k}, B});
            } else
                out.push_back({v, A, B});
        }
        if (!closed && cap != 0) {
            auto addCap = [&](Pt v, Pt d) {
                if (cap == 1) {
                    AddCircle(out, v, hw, circleN);
                    return;
                }
                const Pt nn{-d.y * hw, d.x * hw};
                out.push_back({{v.x + nn.x, v.y + nn.y},
                               {v.x + nn.x + d.x * hw, v.y + nn.y + d.y * hw},
                               {v.x - nn.x + d.x * hw, v.y - nn.y + d.y * hw},
                               {v.x - nn.x, v.y - nn.y}});
            };
            addCap(p[0], {-dir[0].x, -dir[0].y});
            addCap(p[n - 1], dir[segs - 1]);
        }
    }
}

struct Mask {
    int x0 = 0, y0 = 0, w = 0, h = 0;
    std::vector<float> a;
    float At(int x, int y) const {
        x -= x0;
        y -= y0;
        return x < 0 || y < 0 || x >= w || y >= h ? 0.f : a[size_t(y) * size_t(w) + size_t(x)];
    }
};
struct Edge {
    double x0, y0, x1, y1;
    int dir;
};
inline void Rasterize(const std::vector<Ring>& rings, bool evenOdd, int W, int H, Mask& out) {
    out = Mask{};
    double minx = 1e30, miny = 1e30, maxx = -1e30, maxy = -1e30;
    std::vector<Edge> edges;
    for (const auto& ring : rings) {
        const size_t n = ring.size();
        if (n < 2)
            continue;
        for (size_t i = 0; i < n; ++i) {
            const Pt a = ring[i], b = ring[(i + 1) % n];
            if (!(std::isfinite(a.x) && std::isfinite(a.y)))
                return;
            minx = std::min(minx, a.x);
            maxx = std::max(maxx, a.x);
            miny = std::min(miny, a.y);
            maxy = std::max(maxy, a.y);
            if (a.y == b.y)
                continue;
            edges.push_back(a.y < b.y ? Edge{a.x, a.y, b.x, b.y, 1} : Edge{b.x, b.y, a.x, a.y, -1});
        }
    }
    if (edges.empty())
        return;
    const int bx0 = std::max(0, int(std::floor(std::max(minx, -1.0)))),
              bx1 = std::min(W, int(std::ceil(std::min(maxx, double(W) + 1)))),
              by0 = std::max(0, int(std::floor(std::max(miny, -1.0)))),
              by1 = std::min(H, int(std::ceil(std::min(maxy, double(H) + 1))));
    if (bx1 <= bx0 || by1 <= by0)
        return;
    std::sort(edges.begin(), edges.end(), [](const Edge& a, const Edge& b) { return a.y0 < b.y0; });
    const int w = bx1 - bx0, h = by1 - by0, sub = (w * h > 96 * 96) ? 16 : 32;
    const double weight = 1.0 / sub;
    out.x0 = bx0;
    out.y0 = by0;
    out.w = w;
    out.h = h;
    out.a.assign(size_t(w) * size_t(h), 0.f);
    std::vector<size_t> active;
    size_t next = 0;
    std::vector<std::pair<double, int>> xs;
    std::vector<double> row(size_t(w) + 2), diff(size_t(w) + 2);
    const double left = bx0, right = bx1;
    for (int y = by0; y < by1; ++y) {
        std::fill(row.begin(), row.end(), 0.0);
        std::fill(diff.begin(), diff.end(), 0.0);
        for (int s = 0; s < sub; ++s) {
            const double ys = y + (s + 0.5) / sub;
            while (next < edges.size() && edges[next].y0 <= ys)
                active.push_back(next++);
            active.erase(
                std::remove_if(active.begin(), active.end(), [&](size_t i) { return edges[i].y1 <= ys; }),
                active.end());
            if (active.empty())
                continue;
            xs.clear();
            for (size_t i : active) {
                const Edge& e = edges[i];
                xs.emplace_back(e.x0 + (ys - e.y0) * (e.x1 - e.x0) / (e.y1 - e.y0), e.dir);
            }
            std::sort(xs.begin(), xs.end(),
                      [](const std::pair<double, int>& a, const std::pair<double, int>& b) {
                          return a.first < b.first;
                      });
            int wind = 0;
            double start = 0;
            for (const auto& c : xs) {
                const bool was = evenOdd ? (wind & 1) != 0 : wind != 0;
                wind += c.second;
                const bool in = evenOdd ? (wind & 1) != 0 : wind != 0;
                if (!was && in)
                    start = c.first;
                else if (was && !in) {
                    double xa = std::max(start, left), xb = std::min(c.first, right);
                    if (xb <= xa)
                        continue;
                    xa -= left;
                    xb -= left;
                    const int ia = int(std::floor(xa)), ib = int(std::floor(xb));
                    if (ia == ib)
                        row[size_t(ia)] += (xb - xa) * weight;
                    else {
                        row[size_t(ia)] += (ia + 1 - xa) * weight;
                        diff[size_t(ia) + 1] += weight;
                        diff[size_t(ib)] -= weight;
                        row[size_t(ib)] += (xb - ib) * weight;
                    }
                }
            }
        }
        double run = 0;
        for (int x = 0; x < w; ++x) {
            run += diff[size_t(x)];
            out.a[size_t(y - by0) * size_t(w) + size_t(x)] = float(Clamp(row[size_t(x)] + run, 0, 1));
        }
    }
}
inline double SignedArea(const Ring& r) {
    double a = 0;
    for (size_t i = 0; i < r.size(); ++i) {
        const Pt p = r[i], q = r[(i + 1) % r.size()];
        a += p.x * q.y - q.x * p.y;
    }
    return a / 2;
}

inline std::vector<Ring> ToDevice(const std::vector<Ring>& in, const Mat& m) {
    std::vector<Ring> out;
    out.reserve(in.size());
    for (const auto& r : in) {
        Ring d;
        d.reserve(r.size());
        for (const auto& p : r)
            d.push_back(m.Apply(p));
        const double a = SignedArea(d);
        if (std::fabs(a) < 1e-12)
            continue;
        if (a < 0)
            std::reverse(d.begin(), d.end());
        out.push_back(std::move(d));
    }
    return out;
}

struct Layer {
    int w = 0, h = 0;
    std::vector<float> p;
    void Init(int W, int H) {
        w = W;
        h = H;
        p.assign(size_t(W) * size_t(H) * 4, 0.f);
    }
};
struct Box {
    double x0 = 1e30, y0 = 1e30, x1 = -1e30, y1 = -1e30;
    bool Empty() const {
        return x1 < x0 || y1 < y0;
    }
    void Add(Pt p) {
        x0 = std::min(x0, p.x);
        y0 = std::min(y0, p.y);
        x1 = std::max(x1, p.x);
        y1 = std::max(y1, p.y);
    }
};
struct Stop {
    double off = 0;
    Color c;
};
struct Gradient {
    bool radial = false;
    std::vector<Stop> stops;
    int spread = 0;
    Mat inv;
    double x1 = 0, y1 = 0, x2 = 1, y2 = 0, cx = .5, cy = .5, r = .5, fx = .5, fy = .5;
};
inline Color GradientColor(const Gradient& g, double t) {
    const auto& st = g.stops;
    if (g.spread == 1) {
        t = std::fmod(t, 2.0);
        if (t < 0)
            t += 2;
        if (t > 1)
            t = 2 - t;
    } else if (g.spread == 2)
        t -= std::floor(t);
    t = Clamp(t, 0, 1);
    if (t <= st.front().off)
        return st.front().c;
    for (size_t i = 1; i < st.size(); ++i) {
        if (t <= st[i].off) {
            const double a = st[i - 1].off, b = st[i].off, u = b > a ? (t - a) / (b - a) : 1;
            const Color x = st[i - 1].c, y = st[i].c;
            return {x.r + (y.r - x.r) * u, x.g + (y.g - x.g) * u, x.b + (y.b - x.b) * u,
                    x.a + (y.a - x.a) * u};
        }
    }
    return st.back().c;
}
inline Color GradientAt(const Gradient& g, double px, double py) {
    const Pt u = g.inv.Apply({px, py});
    double t = 0;
    if (!g.radial) {
        const double dx = g.x2 - g.x1, dy = g.y2 - g.y1, den = dx * dx + dy * dy;
        t = den > 0 ? ((u.x - g.x1) * dx + (u.y - g.y1) * dy) / den : 0;
    } else {
        double fx = g.fx, fy = g.fy;
        const double fdx = fx - g.cx, fdy = fy - g.cy, fl = std::hypot(fdx, fdy);
        if (fl > g.r * 0.999) {
            const double k = g.r * 0.999 / fl;
            fx = g.cx + fdx * k;
            fy = g.cy + fdy * k;
        }
        const double dx = g.cx - fx, dy = g.cy - fy, ex = u.x - fx, ey = u.y - fy;
        const double A = g.r * g.r - (dx * dx + dy * dy), B = ex * dx + ey * dy, C = ex * ex + ey * ey;
        t = A > 0 ? (-B + std::sqrt(std::max(0.0, B * B + A * C))) / A : 0;
    }
    return GradientColor(g, t);
}
struct PaintSrc {
    bool grad = false;
    Color c;
    Gradient g;
};

inline void FillMask(Layer& L, const Mask& m, const PaintSrc& ps, double alpha) {
    for (int y = 0; y < m.h; ++y) {
        for (int x = 0; x < m.w; ++x) {
            const float cov = m.a[size_t(y) * size_t(m.w) + size_t(x)];
            if (cov <= 0.f)
                continue;
            const int px = m.x0 + x, py = m.y0 + y;
            if (px < 0 || py < 0 || px >= L.w || py >= L.h)
                continue;
            const Color c = ps.grad ? GradientAt(ps.g, px + 0.5, py + 0.5) : ps.c;
            const double na = c.a * cov * alpha;
            if (!(na > 0))
                continue;
            float* q = &L.p[(size_t(py) * size_t(L.w) + size_t(px)) * 4];
            const float inv = float(1 - na);
            q[0] = q[0] * inv + float(c.r * na);
            q[1] = q[1] * inv + float(c.g * na);
            q[2] = q[2] * inv + float(c.b * na);
            q[3] = q[3] * inv + float(na);
        }
    }
}

constexpr long kMaxOps = 40000000;
struct Ctx {
    const Document* doc = nullptr;
    std::vector<Rule> rules;
    int W = 0, H = 0, depth = 0, layers = 0;
    double vw = 100, vh = 100;
    long ops = 0;
};
inline Props NodeProps(const Ctx& c, const Node& n) {
    Props pr;
    for (const auto& a : n.attr)
        pr[a.first] = a.second;
    std::vector<const Rule*> hit;
    for (const auto& r : c.rules)
        if (Matches(r.sel, n))
            hit.push_back(&r);
    std::stable_sort(hit.begin(), hit.end(),
                     [](const Rule* a, const Rule* b) { return a->sel.spec < b->sel.spec; });
    for (const Rule* r : hit)
        for (const auto& d : r->decl)
            pr[d.first] = d.second;
    if (auto s = n.Get("style"))
        for (const auto& d : Declarations(*s))
            pr[d.first] = d.second;
    return pr;
}
inline const Node* HrefNode(const Document& d, const Node& n) {
    const std::string* h = n.Get("href");
    if (!h)
        return nullptr;
    const std::string v = Trim(*h);
    if (v.size() < 2 || v[0] != '#')
        return nullptr;
    const auto it = d.ids.find(v.substr(1));
    return it == d.ids.end() ? nullptr : it->second;
}
inline double Len(const Ctx& c, const Node& n, const char* k, double base, double def = 0) {
    (void)c;
    double v = def;
    if (auto s = n.Get(k)) {
        double x;
        if (Length(*s, base, x))
            v = x;
    }
    return v;
}
inline bool IsShape(const std::string& t) {
    return t == "path" || t == "rect" || t == "circle" || t == "ellipse" || t == "line" || t == "polyline" ||
           t == "polygon";
}
inline bool ShapeCmds(const Ctx& c, const Node& n, std::vector<Cmd>& out) {
    const std::string& t = n.tag;
    const double vd = std::sqrt((c.vw * c.vw + c.vh * c.vh) / 2);
    out.clear();
    if (t == "path") {
        out = ParsePath(n.Str("d"));
        return out.size() >= 2;
    }
    if (t == "rect") {
        const double x = Len(c, n, "x", c.vw), y = Len(c, n, "y", c.vh), w = Len(c, n, "width", c.vw),
                     h = Len(c, n, "height", c.vh);
        if (!(w > 0 && h > 0))
            return false;
        double rx = -1, ry = -1;
        if (auto s = n.Get("rx")) {
            double v;
            if (Length(*s, c.vw, v) && v >= 0)
                rx = v;
        }
        if (auto s = n.Get("ry")) {
            double v;
            if (Length(*s, c.vh, v) && v >= 0)
                ry = v;
        }
        if (rx < 0 && ry >= 0)
            rx = ry;
        if (ry < 0 && rx >= 0)
            ry = rx;
        rx = std::min(std::max(rx, 0.0), w / 2);
        ry = std::min(std::max(ry, 0.0), h / 2);
        if (rx <= 0 || ry <= 0) {
            out = {MakeCmd('M', x, y), MakeCmd('L', x + w, y), MakeCmd('L', x + w, y + h),
                   MakeCmd('L', x, y + h), MakeCmd('Z')};
            return true;
        }
        out.push_back(MakeCmd('M', x + rx, y));
        out.push_back(MakeCmd('L', x + w - rx, y));
        ArcTo(out, x + w - rx, y, rx, ry, 0, false, true, x + w, y + ry);
        out.push_back(MakeCmd('L', x + w, y + h - ry));
        ArcTo(out, x + w, y + h - ry, rx, ry, 0, false, true, x + w - rx, y + h);
        out.push_back(MakeCmd('L', x + rx, y + h));
        ArcTo(out, x + rx, y + h, rx, ry, 0, false, true, x, y + h - ry);
        out.push_back(MakeCmd('L', x, y + ry));
        ArcTo(out, x, y + ry, rx, ry, 0, false, true, x + rx, y);
        out.push_back(MakeCmd('Z'));
        return true;
    }
    if (t == "circle" || t == "ellipse") {
        const double cx = Len(c, n, "cx", c.vw), cy = Len(c, n, "cy", c.vh);
        double rx, ry;
        if (t == "circle")
            rx = ry = Len(c, n, "r", vd);
        else {
            rx = Len(c, n, "rx", c.vw);
            ry = Len(c, n, "ry", c.vh);
        }
        if (!(rx > 0 && ry > 0))
            return false;
        out.push_back(MakeCmd('M', cx + rx, cy));
        ArcTo(out, cx + rx, cy, rx, ry, 0, false, true, cx, cy + ry);
        ArcTo(out, cx, cy + ry, rx, ry, 0, false, true, cx - rx, cy);
        ArcTo(out, cx - rx, cy, rx, ry, 0, false, true, cx, cy - ry);
        ArcTo(out, cx, cy - ry, rx, ry, 0, false, true, cx + rx, cy);
        out.push_back(MakeCmd('Z'));
        return true;
    }
    if (t == "line") {
        out = {MakeCmd('M', Len(c, n, "x1", c.vw), Len(c, n, "y1", c.vh)),
               MakeCmd('L', Len(c, n, "x2", c.vw), Len(c, n, "y2", c.vh))};
        return true;
    }
    if (t == "polyline" || t == "polygon") {
        const auto v = NumberList(n.Str("points"));
        if (v.size() < 4)
            return false;
        for (size_t i = 0; i + 1 < v.size(); i += 2)
            out.push_back(MakeCmd(i == 0 ? 'M' : 'L', v[i], v[i + 1]));
        if (t == "polygon")
            out.push_back(MakeCmd('Z'));
        return true;
    }
    return false;
}
inline Mat ViewBoxMatrix(double vx, double vy, double vw, double vh, double dw, double dh,
                         const std::string& par) {
    const double sx = dw / vw, sy = dh / vh;
    std::string align = "xmidymid";
    bool slice = false;
    const std::string s = Lower(Trim(par));
    size_t p = 0;
    while (p < s.size()) {
        while (p < s.size() && Space(s[p]))
            ++p;
        size_t q = p;
        while (q < s.size() && !Space(s[q]))
            ++q;
        const std::string tok = s.substr(p, q - p);
        p = q;
        if (tok == "slice")
            slice = true;
        else if (tok == "none" || (!tok.empty() && tok[0] == 'x'))
            align = tok;
    }
    if (align == "none")
        return {sx, 0, 0, sy, -vx * sx, -vy * sy};
    const double k = slice ? std::max(sx, sy) : std::min(sx, sy), ex = dw - vw * k, ey = dh - vh * k;
    const double fx = align.compare(0, 4, "xmin") == 0   ? 0
                      : align.compare(0, 4, "xmax") == 0 ? 1
                                                         : 0.5,
                 fy = align.find("ymin") != std::string::npos   ? 0
                      : align.find("ymax") != std::string::npos ? 1
                                                                : 0.5;
    return {k, 0, 0, k, -vx * k + ex * fx, -vy * k + ey * fy};
}
inline void BoxOf(const Ctx& c, const Node& n, const Mat& m, Box& b, int depth) {
    if (depth > 16)
        return;
    const std::string& t = n.tag;
    if (IsShape(t)) {
        std::vector<Cmd> cmds;
        if (!ShapeCmds(c, n, cmds))
            return;
        for (const auto& p : Flatten(cmds, m, 0.1))
            for (const auto& q : p.pts)
                b.Add(q);
        return;
    }
    if (t == "g" || t == "a" || t == "svg" || t == "switch") {
        for (const auto& k : n.kids) {
            Mat mm = m;
            if (auto tr = k->Get("transform"))
                mm = Mul(m, ParseTransform(*tr));
            BoxOf(c, *k, mm, b, depth + 1);
        }
        return;
    }
    if (t == "use") {
        const Node* ref = HrefNode(*c.doc, n);
        if (!ref)
            return;
        Mat mm = Mul(m, Mat{1, 0, 0, 1, Len(c, n, "x", c.vw), Len(c, n, "y", c.vh)});
        if (auto tr = ref->Get("transform"))
            mm = Mul(mm, ParseTransform(*tr));
        BoxOf(c, *ref, mm, b, depth + 1);
    }
}
inline bool MakePaint(const Ctx& c, const PaintSpec& ps, const Mat& m, const Box& bb, PaintSrc& out) {
    if (ps.kind == PaintSpec::None)
        return false;
    if (ps.kind == PaintSpec::Solid) {
        out.grad = false;
        out.c = ps.c;
        return ps.c.a > 0;
    }
    const auto it = c.doc->ids.find(ps.url);
    const Node* gn = it == c.doc->ids.end() ? nullptr : it->second;
    if (!gn || (gn->tag != "linearGradient" && gn->tag != "radialGradient")) {
        if (ps.c.a > 0) {
            out.grad = false;
            out.c = ps.c;
            return true;
        }
        return false;
    }
    Gradient g;
    g.radial = gn->tag == "radialGradient";
    auto attr = [&](const char* k) -> const std::string* {
        const Node* n = gn;
        for (int i = 0; i < 16 && n; ++i) {
            if (auto v = n->Get(k))
                return v;
            n = HrefNode(*c.doc, *n);
        }
        return nullptr;
    };
    {
        const Node* n = gn;
        std::vector<const Node*> st;
        for (int i = 0; i < 16 && n && st.empty(); ++i) {
            for (const auto& k : n->kids)
                if (k->tag == "stop")
                    st.push_back(k.get());
            n = HrefNode(*c.doc, *n);
        }
        double prev = 0;
        for (const Node* s : st) {
            double off = 0;
            if (auto v = s->Get("offset")) {
                double x;
                if (Length(*v, 1, x))
                    off = x;
            }
            off = std::max(Clamp(off, 0, 1), prev);
            prev = off;
            const Style sty = Resolve(Style(), NodeProps(c, *s), false);
            Stop sp;
            sp.off = off;
            sp.c = sty.stopColor;
            sp.c.a *= sty.stopOpacity;
            g.stops.push_back(sp);
        }
    }
    if (g.stops.empty())
        return false;
    const std::string* gu = attr("gradientUnits");
    const bool obb = !(gu && Trim(*gu) == "userSpaceOnUse");
    if (obb && (bb.Empty() || !(bb.x1 > bb.x0) || !(bb.y1 > bb.y0)))
        return false;
    const double vd = std::sqrt((c.vw * c.vw + c.vh * c.vh) / 2);
    auto coord = [&](const char* k, double def, double base) {
        double v = def * (obb ? 1 : base);
        if (auto s = attr(k)) {
            double x;
            if (Length(*s, obb ? 1 : base, x))
                v = x;
        }
        return v;
    };
    if (!g.radial) {
        g.x1 = coord("x1", 0, c.vw);
        g.y1 = coord("y1", 0, c.vh);
        g.x2 = coord("x2", 1, c.vw);
        g.y2 = coord("y2", 0, c.vh);
        if (g.x1 == g.x2 && g.y1 == g.y2) {
            out.grad = false;
            out.c = g.stops.back().c;
            return out.c.a > 0;
        }
    } else {
        g.cx = coord("cx", .5, c.vw);
        g.cy = coord("cy", .5, c.vh);
        g.r = coord("r", .5, vd);
        g.fx = g.cx;
        g.fy = g.cy;
        if (attr("fx"))
            g.fx = coord("fx", .5, c.vw);
        if (attr("fy"))
            g.fy = coord("fy", .5, c.vh);
        if (!(g.r > 0)) {
            out.grad = false;
            out.c = g.stops.back().c;
            return out.c.a > 0;
        }
    }
    if (const std::string* sm = attr("spreadMethod")) {
        const std::string t = Trim(*sm);
        g.spread = t == "reflect" ? 1 : t == "repeat" ? 2 : 0;
    }
    Mat full = m;
    if (obb)
        full = Mul(full, Mat{bb.x1 - bb.x0, 0, 0, bb.y1 - bb.y0, bb.x0, bb.y0});
    if (const std::string* gt = attr("gradientTransform"))
        full = Mul(full, ParseTransform(*gt));
    if (!Invert(full, g.inv))
        return false;
    out.grad = true;
    out.g = g;
    return true;
}
inline void ClipAdd(Ctx& c, const Node& n, const Mat& m, const Style& parent, Mask& out, int depth) {
    if (depth > 8 || c.ops > kMaxOps)
        return;
    if (!IsShape(n.tag) && n.tag != "use")
        return;
    const Style st = Resolve(parent, NodeProps(c, n), false);
    if (st.none || st.hidden)
        return;
    Mat mm = m;
    if (auto t = n.Get("transform"))
        mm = Mul(m, ParseTransform(*t));
    if (n.tag == "use") {
        const Node* ref = HrefNode(*c.doc, n);
        if (ref)
            ClipAdd(c, *ref, Mul(mm, Mat{1, 0, 0, 1, Len(c, n, "x", c.vw), Len(c, n, "y", c.vh)}), st, out,
                    depth + 1);
        return;
    }
    std::vector<Cmd> cmds;
    if (!ShapeCmds(c, n, cmds))
        return;
    std::vector<Ring> rings;
    for (auto& p : Flatten(cmds, mm, 0.04)) {
        c.ops += long(p.pts.size());
        if (p.pts.size() >= 3)
            rings.push_back(std::move(p.pts));
    }
    Mask mk;
    Rasterize(rings, st.clipEvenOdd, c.W, c.H, mk);
    for (int y = 0; y < mk.h; ++y)
        for (int x = 0; x < mk.w; ++x) {
            const float cv = mk.a[size_t(y) * size_t(mk.w) + size_t(x)];
            if (cv <= 0.f)
                continue;
            float& d = out.a[size_t(mk.y0 + y) * size_t(c.W) + size_t(mk.x0 + x)];
            d = 1 - (1 - d) * (1 - cv);
        }
}
inline bool ClipMask(Ctx& c, const Node& cp, const Mat& m, const Box& bb, const Style& parent, Mask& out) {
    Mat cm = m;
    const std::string* cu = cp.Get("clipPathUnits");
    if (cu && Trim(*cu) == "objectBoundingBox") {
        if (bb.Empty() || !(bb.x1 > bb.x0) || !(bb.y1 > bb.y0))
            return false;
        cm = Mul(cm, Mat{bb.x1 - bb.x0, 0, 0, bb.y1 - bb.y0, bb.x0, bb.y0});
    }
    if (auto t = cp.Get("transform"))
        cm = Mul(cm, ParseTransform(*t));
    const Style cst = Resolve(parent, NodeProps(c, cp), false);
    out = Mask{};
    out.w = c.W;
    out.h = c.H;
    out.a.assign(size_t(c.W) * size_t(c.H), 0.f);
    for (const auto& k : cp.kids)
        ClipAdd(c, *k, cm, cst, out, 0);
    return true;
}
inline void Composite(Layer& dst, const Layer& src, double opacity, const Mask* clip) {
    const size_t n = size_t(dst.w) * size_t(dst.h);
    for (size_t i = 0; i < n; ++i) {
        float k = float(opacity);
        if (clip)
            k *= clip->a[i];
        const float* s = &src.p[i * 4];
        if (s[3] <= 0.f || k <= 0.f)
            continue;
        float* d = &dst.p[i * 4];
        const float inv = 1.f - s[3] * k;
        d[0] = d[0] * inv + s[0] * k;
        d[1] = d[1] * inv + s[1] * k;
        d[2] = d[2] * inv + s[2] * k;
        d[3] = d[3] * inv + s[3] * k;
    }
}

inline void DrawShape(Ctx& c, const Node& n, const Mat& m, const Style& st, Layer& L) {
    if (st.hidden)
        return;
    std::vector<Cmd> cmds;
    if (!ShapeCmds(c, n, cmds) || cmds.size() < 2)
        return;
    const double sc = std::max(std::hypot(m.a, m.b), std::hypot(m.c, m.d));
    if (!(sc > 1e-9))
        return;
    const double tol = 0.04;
    const std::vector<Poly> user = Flatten(cmds, Mat{}, tol / sc);
    Box bb;
    size_t pts = 0;
    for (const auto& p : user) {
        pts += p.pts.size();
        for (const auto& q : p.pts)
            bb.Add(q);
    }
    c.ops += long(pts);
    if (c.ops > kMaxOps)
        return;
    if (st.fill.kind != PaintSpec::None && st.fillOpacity > 0) {
        PaintSrc ps;
        if (MakePaint(c, st.fill, m, bb, ps)) {
            std::vector<Ring> rings;
            for (const auto& p : user) {
                if (p.pts.size() < 3)
                    continue;
                Ring r;
                r.reserve(p.pts.size());
                for (const auto& q : p.pts)
                    r.push_back(m.Apply(q));
                rings.push_back(std::move(r));
            }
            Mask mk;
            Rasterize(rings, st.evenOdd, c.W, c.H, mk);
            FillMask(L, mk, ps, st.fillOpacity);
        }
    }
    if (st.stroke.kind != PaintSpec::None && st.strokeWidth > 0 && st.strokeOpacity > 0) {
        PaintSrc ps;
        if (MakePaint(c, st.stroke, m, bb, ps)) {
            const std::vector<Poly> dashed = st.dash.empty() ? user : Dash(user, st.dash, st.dashOffset);
            std::vector<Ring> pieces;
            Stroke(dashed, st.strokeWidth, st.cap, st.join, st.miter, tol / sc, pieces);
            c.ops += long(pieces.size()) * 8;
            if (c.ops > kMaxOps)
                return;
            Mask mk;
            Rasterize(ToDevice(pieces, m), false, c.W, c.H, mk);
            FillMask(L, mk, ps, st.strokeOpacity);
        }
    }
}
inline void RenderElement(Ctx& c, const Node& n, const Mat& ctm, const Style& parent, Layer& dst,
                          bool isRoot) {
    if (c.depth >= 32 || c.ops > kMaxOps)
        return;
    const std::string& t = n.tag;
    const bool shape = IsShape(t);
    if (!shape && t != "g" && t != "a" && t != "svg" && t != "use" && t != "switch")
        return;
    const Style st = Resolve(parent, NodeProps(c, n), isRoot);
    if (st.none)
        return;
    Mat m = ctm;
    if (!isRoot)
        if (auto tr = n.Get("transform"))
            m = Mul(ctm, ParseTransform(*tr));
    const bool layered = (st.opacity < 0.999999 || !st.clip.empty()) && c.layers < 8;
    Layer tmp;
    Layer* target = &dst;
    if (layered) {
        tmp.Init(c.W, c.H);
        target = &tmp;
        ++c.layers;
    }
    ++c.depth;
    ++c.ops;
    auto kids = [&](const Mat& mk, const Style& sk) {
        for (const auto& k : n.kids)
            RenderElement(c, *k, mk, sk, *target, false);
    };
    if (shape)
        DrawShape(c, n, m, st, *target);
    else if (t == "g" || t == "a")
        kids(m, st);
    else if (t == "svg") {
        if (isRoot)
            kids(m, st);
        else {
            const double x = Len(c, n, "x", c.vw), y = Len(c, n, "y", c.vh),
                         w = Len(c, n, "width", c.vw, c.vw), h = Len(c, n, "height", c.vh, c.vh);
            Mat mm = Mul(m, Mat{1, 0, 0, 1, x, y});
            const auto vb = NumberList(n.Str("viewBox"));
            if (vb.size() == 4 && vb[2] > 0 && vb[3] > 0 && w > 0 && h > 0)
                mm = Mul(mm, ViewBoxMatrix(vb[0], vb[1], vb[2], vb[3], w, h, n.Str("preserveAspectRatio")));
            kids(mm, st);
        }
    } else if (t == "switch") {
        for (const auto& k : n.kids) {
            if (k->Get("requiredExtensions"))
                continue;
            if (const std::string* sl = k->Get("systemLanguage")) {
                if (Lower(*sl).find("en") == std::string::npos)
                    continue;
            }
            RenderElement(c, *k, m, st, *target, false);
            break;
        }
    } else if (t == "use") {
        if (const Node* ref = HrefNode(*c.doc, n)) {
            const Mat mm = Mul(m, Mat{1, 0, 0, 1, Len(c, n, "x", c.vw), Len(c, n, "y", c.vh)});
            if (ref->tag == "symbol" || ref->tag == "svg") {
                Mat vm = mm;
                const auto vb = NumberList(ref->Str("viewBox"));
                const double w = Len(c, n, "width", c.vw, Len(c, *ref, "width", c.vw, c.vw)),
                             h = Len(c, n, "height", c.vh, Len(c, *ref, "height", c.vh, c.vh));
                if (vb.size() == 4 && vb[2] > 0 && vb[3] > 0 && w > 0 && h > 0)
                    vm = Mul(
                        vm, ViewBoxMatrix(vb[0], vb[1], vb[2], vb[3], w, h, ref->Str("preserveAspectRatio")));
                const Style rs = Resolve(st, NodeProps(c, *ref), false);
                for (const auto& k : ref->kids)
                    RenderElement(c, *k, vm, rs, *target, false);
            } else
                RenderElement(c, *ref, mm, st, *target, false);
        }
    }
    --c.depth;
    if (layered) {
        --c.layers;
        Mask mk;
        const Mask* cm = nullptr;
        if (!st.clip.empty()) {
            const auto it = c.doc->ids.find(st.clip);
            if (it != c.doc->ids.end() && it->second->tag == "clipPath") {
                Box bb;
                BoxOf(c, n, Mat{}, bb, 0);
                if (ClipMask(c, *it->second, m, bb, st, mk))
                    cm = &mk;
            }
        }
        Composite(dst, tmp, st.opacity, cm);
    }
}
}

inline bool Render(const std::string& svg, int width, int height, Bitmap& out) {
    using namespace detail;
    out = Bitmap{};
    Document doc;
    if (svg.empty() || svg.size() > (size_t(4) << 20) || !ParseXml(svg, doc))
        return false;
    const Node* root = doc.Svg();
    if (!root)
        return false;
    double vbx = 0, vby = 0, vbw = 0, vbh = 0;
    bool hasVb = false;
    {
        const auto v = NumberList(root->Str("viewBox"));
        if (v.size() == 4 && v[2] > 0 && v[3] > 0) {
            vbx = v[0];
            vby = v[1];
            vbw = v[2];
            vbh = v[3];
            hasVb = true;
        }
    }
    double dw = 0, dh = 0;
    bool hasW = false, hasH = false;
    {
        double x;
        const std::string* s = root->Get("width");
        if (s && s->find('%') == std::string::npos && Length(*s, 0, x) && x > 0) {
            dw = x;
            hasW = true;
        }
        s = root->Get("height");
        if (s && s->find('%') == std::string::npos && Length(*s, 0, x) && x > 0) {
            dh = x;
            hasH = true;
        }
    }
    if (!hasW && !hasH) {
        if (!hasVb)
            return false;
        dw = vbw;
        dh = vbh;
    } else if (!hasW)
        dw = hasVb ? dh * vbw / vbh : dh;
    else if (!hasH)
        dh = hasVb ? dw * vbh / vbw : dw;
    if (!(dw > 0 && dh > 0))
        return false;
    int W = width, H = height;
    if (W <= 0 && H <= 0) {
        W = int(std::ceil(dw));
        H = int(std::ceil(dh));
    } else if (W <= 0)
        W = int(std::ceil(H * dw / dh));
    else if (H <= 0)
        H = int(std::ceil(W * dh / dw));
    if (W < 1 || H < 1 || W > 1024 || H > 1024)
        return false;
    Ctx c;
    c.doc = &doc;
    c.W = W;
    c.H = H;
    c.vw = hasVb ? vbw : dw;
    c.vh = hasVb ? vbh : dh;
    std::string css;
    CollectCss(*doc.root, css);
    ParseCss(css, c.rules);
    Mat m{W / dw, 0, 0, H / dh, 0, 0};
    if (hasVb)
        m = Mul(m, ViewBoxMatrix(vbx, vby, vbw, vbh, dw, dh, root->Str("preserveAspectRatio")));
    Layer layer;
    layer.Init(W, H);
    RenderElement(c, *root, m, Style(), layer, true);
    const size_t count = size_t(W) * size_t(H) * 4;
    out.width = W;
    out.height = H;
    out.rgba.resize(count);
    for (size_t i = 0; i < count; ++i)
        out.rgba[i] = (unsigned char)std::lround(Clamp(layer.p[i], 0, 1) * 255);
    return true;
}

inline std::string ExtractPayload(const std::string& bytes) {
    size_t a = bytes.find("<?xml");
    const size_t b = bytes.find("<svg");
    if (a == std::string::npos || (b != std::string::npos && b < a))
        a = b;
    if (a == std::string::npos)
        return {};
    const size_t e = bytes.rfind("</svg>");
    if (e == std::string::npos || e < a)
        return {};
    return bytes.substr(a, e + 6 - a);
}
inline bool IsBlank(const Bitmap& b) {
    for (size_t i = 3; i < b.rgba.size(); i += 4)
        if (b.rgba[i] > 8)
            return false;
    return true;
}

}
