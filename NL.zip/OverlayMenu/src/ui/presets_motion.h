#pragma once
#include "menu_core.h"
namespace menu {

struct PresetMotion {
    float value = 0, from = 0, target = 0, elapsed = 0;
    bool initialized = false;
    void Snap(float x) {
        value = from = target = x;
        elapsed = .2f;
        initialized = true;
    }
    void Tick(float next, float dt, float duration = .2f) {
        if (!initialized) {
            Snap(next);
            return;
        }
        if (next != target) {
            from = value;
            target = next;
            elapsed = 0;
            return;
        }
        elapsed = std::min(duration, elapsed + std::max(0.f, dt));
        float t = std::clamp(elapsed / duration, 0.f, 1.f);
        value = from + (target - from) * (1 - (1 - t) * (1 - t) * (1 - t));
    }
};

struct PresetMetrics {
    float scale, F, frameX, frameY, frameRadius, rowX, rowY, rowRadius, rowH, controlH;
    explicit PresetMetrics(float s, float fontHeight, bool doubled = false)
        : scale(s), F(fontHeight), frameX((doubled ? 12 : 6) * s), frameY((doubled ? 6 : 3) * s),
          frameRadius(6 * s), rowX(12 * s), rowY(7 * s * 1.4f), rowRadius(std::trunc(15 * s * .5f)),
          rowH(F + 2 * rowY), controlH(F + 2 * frameY) {}

    float TabLabelOffset() const {
        return 17 * scale + 6 * scale;
    }
    float TabWidth(float labelWidth, float expansion) const {
        return 17 * scale + 2 * frameX + (labelWidth + 6 * scale) * expansion;
    }
};
}
