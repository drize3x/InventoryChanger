#pragma once
#include "players_preview_bridge_patterns.h"
namespace menu {
namespace ambience_patterns {
inline constexpr char MapRegistration[] = "48 8D 05 ? ? ? ? 48 89 45 F0 4C 8D 05 ? ? ? ? 0F 28 45 F0 48 8D "
                                          "55 F0 48 8D 0D ? ? ? ? 66 0F 7F 45 F0 E8 ? ? ? ?";
inline constexpr char MapCallback[] = "48 8B 0D ? ? ? ? 48 8B 01 48 FF A0 08 02 00 00";
inline constexpr char MapGetter[] =
    "48 83 EC 28 E8 ? ? ? ? 84 C0 74 0C 48 8D 05 ? ? ? ? 48 83 C4 28 C3 48 8B 0D ? ? ? ? 48 85 C9 74 23 83 "
    "B9 30 02 00 00 02 7C 1A 48 8B 89 18 02 00 00";
inline constexpr char PlayingCallback[] = "48 8B 0D ? ? ? ? 48 8B 01 48 FF A0 38 01 00 00";
inline constexpr char PlayingGetter[] =
    "48 8B 05 ? ? ? ? 48 85 C0 74 15 80 B8 3F 14 2C 00 00 75 0C 83 B8 30 02 00 00 06 7C 03 B0 01 C3 32 C0 C3";
inline constexpr char ConnectedGetter[] =
    "48 8B 05 ? ? ? ? 48 85 C0 74 0B 83 B8 30 02 00 00 02 0F 9D C0 C3 C3";

inline constexpr char ConnectingCallback[] =
    "48 83 EC 28 48 8B 0D ? ? ? ? 48 8B 01 FF 90 50 01 00 00 84 C0 75 61 48 8B 0D ? ? ? ? 48 8B 01 FF 90 F0 "
    "01 00 00 84 C0 75 4D 48 8B 0D ? ? ? ? 48 8B 01 FF 90 40 01 00 00 84 C0 75 39 48 8B 0D ? ? ? ? 48 8D 54 "
    "24 38 48 89 5C 24 20 48 8B 19 FF 93 10 03 00 00 48 8B 0D ? ? ? ? 8B 10 FF 93 48 01 00 00 48 8B 5C 24 20 "
    "48 85 C0 0F 95 C0 48 83 C4 28 C3 B0 01 48 83 C4 28 C3";
inline constexpr char SetImageTail[] =
    "4C 8D 4B 40 45 33 C0 48 8B D7 48 8B CB 4C 8B 74 24 38 48 8B 5C 24 40 48 83 C4 20 5F E9 ? ? ? ?";
inline constexpr char ProxyStore[] =
    "48 89 9E C8 00 00 00 48 8D BE 90 00 00 00 44 88 27 48 8B CB 48 8B 03 FF 50 58";
inline constexpr char ProxyTexture[] = "48 8B 51 10 48 85 D2 74 17 48 8B 42 30 48 85 C0 75 10 48 8B 42 38 48 "
                                       "85 C0 74 05 48 8B 40 20 C3 33 C0 C3";
inline constexpr char LoadedState[] = "C7 47 10 07 00 00 00 48 8D 56 20 89 47 2C 4C 8D 8E 80 00 00 00";
inline constexpr char TextureLoad[] =
    "40 53 57 48 83 EC 28 C6 41 10 00 48 8B FA 48 8B D9 48 85 D2 0F 84 ? ? ? ?";
inline constexpr char ResourceStore[] = "48 8B 06 48 89 43 28 4C 89 3E 48 8B 54 24 40";
inline constexpr char CreateSRV[] =
    "4D 8D 4E 10 4C 8D 44 24 30 49 8B D4 48 8B 88 88 0F 00 00 48 8B 01 FF 50 38";
}
struct AmbienceNativeBindings {
    PreviewBridgeBindings bridge;
    std::uintptr_t mapGlobal = 0, mapCallback = 0, engineClientVtable = 0, mapGetter = 0;
    std::uintptr_t playingCallback = 0, playingGetter = 0, connectingCallback = 0, connectedGetter = 0;
    std::uintptr_t imagePanelVtable = 0, proxyVtable = 0, dataVtable = 0, textureVtable = 0,
                   dxTextureVtable = 0;

    static constexpr unsigned ImageProxy = 0xc8, ProxyData = 0x10, DataTexture = 0x30, TextureHandle = 0x28,
                              TextureSRV = 0x10;
};
inline bool ResolvePanoramaImageNative(const HudScanImage& c, const HudScanImage& p, const HudScanImage& r,
                                       AmbienceNativeBindings& b, std::string& diagnostic) {
    std::ostringstream log;
    auto fail = [&](const char* s) {
        diagnostic = log.str() + "FAIL " + s;
        return false;
    };
    auto one = [&](const HudScanImage& im, const char* name, std::uintptr_t& vt) {
        auto v = im.Vtables(name);
        log << name << " tables=" << v.size() << "; ";
        if (v.size() != 1)
            return false;
        vt = v[0];
        return true;
    };
    auto match = [&](const HudScanImage& im, std::uintptr_t at, const char* sig) {
        auto pat = HudPattern(sig);
        for (std::size_t i = 0; i < pat.size(); ++i) {
            unsigned char q = 0;
            if (!im.Read(at + i, q) || (pat[i] >= 0 && q != pat[i]))
                return false;
        }
        return !pat.empty();
    };
    auto unique = [&](const HudScanImage& im, const char* sig, std::uintptr_t& at) {
        auto v = im.Find(sig, true, 2);
        if (v.size() != 1)
            return false;
        at = v[0];
        return true;
    };
    if (!one(c, ".?AVCImagePanel@panorama@@", b.imagePanelVtable) ||
        !one(p, ".?AVCImageProxySource@panorama@@", b.proxyVtable) ||
        !one(p, ".?AVCImageData@panorama@@", b.dataVtable) ||
        !one(p, ".?AVCSource2UITexture@panorama@@", b.textureVtable) ||
        !one(r, ".?AVCTextureDx11@@", b.dxTextureVtable))
        return fail("image types");
    auto regs = c.Find("45 33 C0 48 8D 15 ? ? ? ? 48 8D 0D ? ? ? ? E8 ? ? ? ?", true, 4096);
    unsigned images = 0;
    std::uintptr_t setImage = 0;
    if (regs.size() >= 4096)
        return fail("image registration scan limit");
    for (auto at : regs)
        if (c.Text(c.Rip(at + 10), "SetImage")) {
            bool typed = false;
            for (unsigned slot = 0; slot < 256; ++slot) {
                std::uintptr_t fn = 0;
                if (!c.Read(b.imagePanelVtable + slot * 8, fn) || !c.Contains(fn, 1, 0x20000000))
                    break;
                if (fn <= at && at - fn < 32)
                    typed = true;
            }
            if (!typed)
                return fail("SetImage registration outside typed ImagePanel");
            setImage = c.Rip(at + 3);
            ++images;
        }
    std::uintptr_t tail = 0, store = 0;
    if (images != 1 || !unique(c, ambience_patterns::SetImageTail, tail) || tail < setImage ||
        tail - setImage > 512 || !unique(c, ambience_patterns::ProxyStore, store))
        return fail("SetImage / proxy store instructions");
    auto load = c.Rip(tail + 28, 1, 5);
    if (!c.Contains(load, 1, 0x20000000) || store < load || store - load > 512)
        return fail("SetImage native-loader edge");
    std::uintptr_t fn = 0;
    if (!p.Read(b.proxyVtable + 0x20, fn) || !match(p, fn, ambience_patterns::ProxyTexture))
        return fail("typed proxy texture getter");
    for (auto spec : std::vector<std::pair<unsigned, const char*>>{
             {0x18, "8B 41 30 C3"}, {0x20, "8B 41 34 C3"}, {0x50, "0F B6 41 10 C3"}})
        if (!p.Read(b.textureVtable + spec.first, fn) || !match(p, fn, spec.second))
            return fail("typed UITexture dimensions/ready getters");
    std::uintptr_t loaded = 0, textureLoad = 0, resourceStore = 0, srv = 0;
    if (!unique(p, ambience_patterns::LoadedState, loaded) ||
        !unique(p, ambience_patterns::TextureLoad, textureLoad) ||
        !unique(p, ambience_patterns::ResourceStore, resourceStore) || resourceStore < textureLoad ||
        resourceStore - textureLoad > 512 || !unique(r, ambience_patterns::CreateSRV, srv))
        return fail("VTEX completion / handle / DX11 SRV contracts");
    diagnostic = log.str() + "typed ImagePanel/Proxy/Data/UITexture/DX11 image contracts";
    return true;
}
inline bool ResolveAmbienceNative(const HudScanImage& c, const HudScanImage& p, const HudScanImage& e,
                                  const HudScanImage& r, AmbienceNativeBindings& out,
                                  std::string& diagnostic) {
    out = {};
    AmbienceNativeBindings b;
    std::ostringstream log;
    auto fail = [&](const char* s) {
        diagnostic = log.str() + "FAIL " + s;
        return false;
    };
    std::string bridgeLog;
    if (!ResolvePreviewBridge(c, p, b.bridge, bridgeLog)) {
        diagnostic = bridgeLog;
        return false;
    }
    auto one = [&](const HudScanImage& im, const char* name, std::uintptr_t& vt) {
        auto v = im.Vtables(name);
        log << name << " tables=" << v.size() << "; ";
        if (v.size() != 1)
            return false;
        vt = v[0];
        return true;
    };
    auto match = [&](const HudScanImage& im, std::uintptr_t at, const char* sig) {
        auto pat = HudPattern(sig);
        for (std::size_t i = 0; i < pat.size(); ++i) {
            unsigned char q = 0;
            if (!im.Read(at + i, q) || (pat[i] >= 0 && q != pat[i]))
                return false;
        }
        return !pat.empty();
    };
    auto regs = c.Find(ambience_patterns::MapRegistration, true, 4096);
    unsigned maps = 0;
    if (regs.size() >= 4096)
        return fail("map registration scan limit");
    for (auto at : regs)
        if (c.Text(c.Rip(at + 26), "GetMapBSPName") &&
            c.Text(c.Rip(at + 11), "Returns the name of the bsp file eg 'de_dust2'")) {
            b.mapCallback = c.Rip(at);
            if (!match(c, b.mapCallback, ambience_patterns::MapCallback))
                return fail("named BSP callback ABI");
            b.mapGlobal = c.Rip(b.mapCallback);
            if (!c.Contains(b.mapGlobal, 8, 0x80000000, 0x20000000))
                return fail("engine client global");
            ++maps;
        }
    if (maps != 1 || !one(e, ".?AVCEngineClient@@", b.engineClientVtable) ||
        !e.Read(b.engineClientVtable + 0x208, b.mapGetter) ||
        !match(e, b.mapGetter, ambience_patterns::MapGetter) || !e.Text(e.Rip(b.mapGetter + 13), "dedicated"))
        return fail("named BSP / typed engine getter");
    unsigned playing = 0, connecting = 0;
    for (auto at : regs) {
        const auto callback = c.Rip(at);

        if (c.Text(c.Rip(at + 26), "IsLocalPlayerPlayingMatch") &&
            match(c, callback, ambience_patterns::PlayingCallback)) {
            if (c.Rip(callback) != b.mapGlobal)
                return fail("playing callback global");
            b.playingCallback = callback;
            ++playing;
        }
        if (c.Text(c.Rip(at + 26), "IsConnectedOrConnectingToServer")) {
            if (!match(c, callback, ambience_patterns::ConnectingCallback))
                return fail("connecting callback ABI");
            for (unsigned offset : {4u, 24u, 44u, 64u, 90u})
                if (c.Rip(callback + offset) != b.mapGlobal)
                    return fail("connecting callback global");
            b.connectingCallback = callback;
            ++connecting;
        }
    }
    if (playing != 1 || connecting != 1 || !e.Read(b.engineClientVtable + 0x138, b.playingGetter) ||
        !match(e, b.playingGetter, ambience_patterns::PlayingGetter) ||
        !e.Read(b.engineClientVtable + 0x140, b.connectedGetter) ||
        !match(e, b.connectedGetter, ambience_patterns::ConnectedGetter) ||
        e.Rip(b.playingGetter) != e.Rip(b.mapGetter + 25) ||
        e.Rip(b.connectedGetter) != e.Rip(b.playingGetter))
        return fail("typed connection / in-game getters");
    for (unsigned slot : {0x148u, 0x150u, 0x1f0u, 0x310u}) {
        std::uintptr_t fn = 0;
        if (!e.Read(b.engineClientVtable + slot, fn) || !e.Contains(fn, 1, 0x20000000))
            return fail("connecting virtual edges");
    }
    std::string imageLog;
    if (!ResolvePanoramaImageNative(c, p, r, b, imageLog)) {
        diagnostic = log.str() + imageLog;
        return false;
    }
    log << imageLog << "; ";
    out = b;
    diagnostic =
        log.str() +
        "resolved named BSP + connection/in-game + SetImage, typed proxy/data/UITexture/DX11; no fixed RVAs";
    return true;
}
}
