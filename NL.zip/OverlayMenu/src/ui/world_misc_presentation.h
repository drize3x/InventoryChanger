#pragma once

struct WorldMiscBlock {
    std::string title;
    std::vector<int> fields;
    bool colors = false;
    int reveal = -1;
    int separatorAt = -1;
};

inline int WorldMiscVisibilityItem(int i) {
    switch (i) {
    case 96:
    case 99:
        return 106;
    case 97:
        return 109;
    case 98:
        return 110;
    case 100:
        return 108;
    case 94:
        return 111;
    case 101:
        return 123;
    default:
        return -1;
    }
}
inline bool WorldMiscFieldVisible(int i, const menu::Settings& cfg) {
    int item = WorldMiscVisibilityItem(i);
    return item < 0 || cfg.worldMisc.value[std::size_t(item)] != 0;
}
inline bool WorldMiscColorOnly(int i) {
    return i == 93 || i == 94;
}
inline bool WorldMiscDetailsOnly(int i) {
    return i == 102;
}
inline bool WorldMiscWindowsContext(int i) {
    return i == 3 || i == 76 || i == 77 || i == 80 || i == 81 || i == 84 || i == 102;
}
inline char32_t WorldMiscIcon(int i) {
    static constexpr std::array<char32_t, 27> windows{
        {0xf641, 0xe1d2, 0xf06e, 0xe59f, 0xe1c2, 0xe19b, 0xf7cb, 0xf071, 0xf7c7, 0,      0,      0, 0, 0,
         0,      0xf276, 0xf320, 0xf576, 0xe600, 0xf007, 0xf06a, 0xf062, 0xf062, 0xf160, 0xf538, 0, 0}};
    if (i >= 76 && i <= 102)
        return windows[std::size_t(i - 76)];
    static constexpr std::array<char32_t, 23> itemIcons{
        {0xf641, 0xf007, 0xf0c2, 0xe473, 0xe29e, 0xf538, 0xf2db, 0xf643, 0xe0e3, 0xe089, 0xf646, 0xf625,
         0xf690, 0xe2cf, 0xf233, 0xe1cc, 0xe097, 0xf017, 0xf83e, 0xf11c, 0xf04e, 0xe099, 0xf601}};
    if (i >= 103 && i < 126)
        return itemIcons[std::size_t(i - 103)];
    if (i == 1 || i == 6)
        return 0xe41e;
    if (i == 2 || i == 7)
        return 0xe269;
    if (i == 3)
        return 0xf120;
    if (i == 24 || i == 55)
        return 0xf05b;
    if (i == 26)
        return 0xe54d;
    if (i == 28)
        return 0xe41c;
    if (i == 25 || i == 27 || i == 29 || i == 31 || i == 39 || i == 47 || i == 62 || i == 68)
        return 0xe29e;
    if (i == 30)
        return 0xf007;
    if (i == 38)
        return 0xf503;
    if (i == 46)
        return 0xf6a4;
    if (i == 54)
        return 0xf1de;
    if (i == 63 || i == 65)
        return 0xf890;
    if (i == 56)
        return 0xf88e;
    if (i == 57 || i == 59 || i == 64)
        return 0xe105;
    if (i == 58)
        return 0xf042;
    if (i == 60)
        return 0xe1c0;
    if (i == 61)
        return 0xf185;
    if (i == 66)
        return 0xe365;
    if (i == 67)
        return 0xf062;
    for (int base : {32, 40, 48, 70}) {
        if (i == base)
            return 0xf1b2;
        if (i == base + 1)
            return 0xe1c0;
        if (i == base + 2 || i == base + 3)
            return 0xf88e;
        if (i == base + 4 || i == base + 5)
            return 0xf185;
    }
    return 0;
}
inline bool WorldMiscHasContext(int i) {
    return WorldMiscWindowsContext(i) || i == 21 || i == 30 || i == 38 || i == 46 || i == 54 || i == 55 ||
           i == 63;
}

inline int WorldMiscPickerContext(int color) {
    for (int i : {30, 38, 46, 55, 63})
        if (menu::WorldMiscSpecs[std::size_t(i)].color == color)
            return i;
    return -1;
}

inline bool WorldMiscDetailsButton(int page, int i) {
    return (page == 0 && WorldMiscWindowsContext(i)) || (page == 4 && i == 54);
}
inline std::vector<WorldMiscBlock> WorldMiscBlocks(int page, int context) {

    if (context == 76)
        return {{"", {102, 91, 92, 93, 94}}, {"", {95, 96, 97, 98, 99, 100, 101}}};
    if (context == 77)
        return {{"", {88, 89, 90}}};
    if (context == 80)
        return {{"", {85}}};
    if (context == 81)
        return {{"", {86}}};
    if (context == 84)
        return {{"", {87}}};
    if (context == 102) {
        std::vector<int> items;
        for (int i = 103; i < 126; ++i)
            items.push_back(i);
        return {{"", items}};
    }
    if (context == 3)
        return {{"", {4, 5, 6, 7}}};
    if (context == 21)
        return {{"", {22, 23}}};
    if (context == 55)
        return {{"", {56, 57, 58, 59, 60, 61, 62}}};
    if (context == 63)
        return {{"", {64, 65, 66, 67, 68}}};
    for (int root : {30, 38, 46, 54})
        if (context == root) {
            int base = root == 54 ? 70 : root + 2;
            return {{"", {base, base + 1, base + 2, base + 3, base + 4, base + 5}}};
        }
    if (page == 0)
        return {{"", {76, 77, 78, 3}}, {"", {1, 2, 79, 80, 81, 82, 83, 84}, true, -1, 2}};
    if (page == 1)
        return {{"visuals_world_miscellaneous_removals_hud", {8, 9, 10, 11, 12}},
                {"visuals_world_miscellaneous_removals_effects", {13, 14, 15, 16, 17, 18, 19, 20}},
                {"", {21}}};
    if (page == 3)
        return {{"", {24, 25}}, {"", {26, 27}}, {"", {28, 29}}};
    if (page == 4)
        return {{"", {30, 31}}, {"", {38, 39}}, {"", {46, 47}}, {"", {54}}};
    if (page == 5)
        return {{"", {55, 63}}};
    return {};
}
