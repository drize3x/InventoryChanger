#pragma once
#include "menu_core.h"
#include <chrono>
#include <deque>
#include <functional>
#include <limits>
namespace menu {

struct WatermarkFrameStats {
    std::deque<std::int64_t> stamps;
    std::int64_t lastUpdate = 0;
    bool started = false, valid = false;
    int fps = 0, onePercentLow = 0, minimum = 0, maximum = 0;
    float stability = 1;
    static int Reciprocal(double seconds) {
        double v = std::floor(1 / seconds + .5);
        return int(std::clamp(v, 0., double(std::numeric_limits<int>::max())));
    }
    bool Sample(std::int64_t now) {
        if (now < 0)
            return false;
        if (!started) {
            started = true;
            lastUpdate = now;
            stamps.push_back(now);
            return false;
        }
        if (now <= stamps.back())
            return false;
        stamps.push_back(now);
        if (stamps.size() > 5000)
            stamps.pop_front();
        while (!stamps.empty() && stamps.front() < now - 1000000000LL)
            stamps.pop_front();
        if (now - lastUpdate < 1000000000LL)
            return false;
        lastUpdate = now;
        if (stamps.size() < 2)
            return false;
        std::vector<double> durations;
        durations.reserve(stamps.size() - 1);
        for (std::size_t i = 1; i < stamps.size(); ++i)
            durations.push_back(double(stamps[i] - stamps[i - 1]) / 1e9);
        std::sort(durations.begin(), durations.end(), std::greater<double>());
        fps = int(durations.size());
        std::size_t index = durations.size() / 100;
        index = index ? index - 1 : 0;
        onePercentLow = Reciprocal(durations[index]);
        minimum = Reciprocal(durations.front());
        maximum = Reciprocal(durations.back());
        stability = std::clamp(1.f - .25f * float(maximum - minimum) / float(fps), 0.f, 1.f);
        valid = true;
        return true;
    }
};
inline std::int64_t WatermarkFrameNanoseconds() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
               std::chrono::steady_clock::now().time_since_epoch())
        .count();
}

struct WatermarkColorMotion {
    Color value{}, from{}, target{};
    float elapsed = 0;
    bool initialized = false;
    static bool Same(Color a, Color b) {
        return a.r == b.r && a.g == b.g && a.b == b.b && a.a == b.a;
    }
    void Tick(Color next, float dt) {
        if (!initialized) {
            value = from = target = next;
            elapsed = .3f;
            initialized = true;
            return;
        }
        if (!Same(next, target)) {
            from = value;
            target = next;
            elapsed = 0;
        }
        if (!std::isfinite(dt) || dt < 0)
            dt = 0;
        elapsed = std::min(.3f, elapsed + dt);
        float t = elapsed / .3f;
        value = Mix(from, target, 1 - (1 - t) * (1 - t) * (1 - t));
    }
};
inline Color WatermarkPaletteRGBA8(Color c) {
    auto q = [](float x) { return float(Canvas::Byte(x)) / 255.f; };
    return {q(c.r), q(c.g), q(c.b), q(c.a)};
}
}
