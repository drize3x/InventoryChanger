#pragma once
#include "players_live_data.h"
namespace menu {
template <class R> bool EntityHandleMatches(R&& read, std::uintptr_t pawn, std::uint32_t handle) {
    std::uintptr_t identity = 0;
    std::uint32_t raw = 0, flags = 0;
    if (!pawn || !handle || handle >= 0xfffffffeu || !read(pawn + 0x10, identity) || !identity ||
        !read(identity + 0x10, raw) || raw == 0xffffffffu || !read(identity + 0x30, flags))
        return false;
    const auto serial = (raw >> 15) - (flags & 1u);
    return ((serial << 15) | (raw & 0x7fffu)) == handle;
}

}
