#pragma once

struct PlayersESPLayout {
    std::array<std::vector<int>, 4> list{};
    bool active = false;
    PlayersESPLayout() {
        list[0] = {3};
        list[1] = {1};
        list[2] = {6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 27};
        list[3] = {4, 23, 2, 21, 22, 24, 25, 26};
    }
    static bool Movable(int item) {
        return item >= 1 && item <= 27 && item != 5;
    }
    static bool Bar(int item) {
        return item == 3 || item == 4 || item == 23;
    }
    bool Valid() const {
        std::array<bool, 29> seen{};
        for (const auto& side : list) {
            if (side.size() > 26)
                return false;
            bool text = false;
            for (int item : side) {
                if (!Movable(item) || seen[std::size_t(item)] || (Bar(item) && text))
                    return false;
                seen[std::size_t(item)] = true;
                if (!Bar(item))
                    text = true;
            }
        }
        for (int item = 1; item <= 27; ++item)
            if (Movable(item) && !seen[std::size_t(item)])
                return false;
        return true;
    }
    bool operator==(const PlayersESPLayout& other) const {
        return active == other.active && list == other.list;
    }
    bool operator!=(const PlayersESPLayout& other) const {
        return !(*this == other);
    }
};
