#pragma once
#include "menu_core.h"
#include <map>
#include <cctype>
#include <sstream>
#include <iomanip>
#include "language_defaults.h"
namespace menu {
inline std::u32string DecodeUTF8(const std::string& s) {
    std::u32string out;
    for (std::size_t i = 0; i < s.size();) {
        auto c = static_cast<unsigned char>(s[i++]);
        std::uint32_t cp = c;
        int n = 0;
        if (c >= 0xc2 && c <= 0xdf) {
            cp = c & 31;
            n = 1;
        } else if (c >= 0xe0 && c <= 0xef) {
            cp = c & 15;
            n = 2;
        } else if (c >= 0xf0 && c <= 0xf4) {
            cp = c & 7;
            n = 3;
        } else if (c >= 128)
            throw std::runtime_error("Invalid UTF-8");
        for (int j = 0; j < n; ++j) {
            if (i >= s.size() || (static_cast<unsigned char>(s[i]) & 0xc0) != 0x80)
                throw std::runtime_error("Invalid UTF-8");
            cp = (cp << 6) | (s[i++] & 63);
        }
        if ((n == 1 && cp < 128) || (n == 2 && cp < 2048) || (n == 3 && cp < 65536) || cp > 0x10ffff ||
            (cp >= 0xd800 && cp <= 0xdfff))
            throw std::runtime_error("Invalid UTF-8");
        out.push_back(char32_t(cp));
    }
    return out;
}
inline std::string EncodeUTF8(const std::u32string& text) {
    std::string out;
    for (auto cp : text) {
        if (cp < 128)
            out += char(cp);
        else if (cp < 2048) {
            out += char(0xc0 | (cp >> 6));
            out += char(0x80 | (cp & 63));
        } else if (cp < 65536) {
            out += char(0xe0 | (cp >> 12));
            out += char(0x80 | ((cp >> 6) & 63));
            out += char(0x80 | (cp & 63));
        } else {
            out += char(0xf0 | (cp >> 18));
            out += char(0x80 | ((cp >> 12) & 63));
            out += char(0x80 | ((cp >> 6) & 63));
            out += char(0x80 | (cp & 63));
        }
    }
    return out;
}

struct LangJSON {
    std::string text;
    std::size_t pos = 0;
    explicit LangJSON(std::string value) : text(std::move(value)) {
        if (text.size() > 4 * 1024 * 1024)
            throw std::runtime_error("Language file exceeds 4 MiB");
        if (text.substr(0, 3) == "\xef\xbb\xbf")
            pos = 3;
    }
    void Space() {
        while (pos < text.size() && std::isspace(static_cast<unsigned char>(text[pos])))
            ++pos;
    }
    bool Take(char c) {
        Space();
        if (pos < text.size() && text[pos] == c) {
            ++pos;
            return true;
        }
        return false;
    }
    void Need(char c) {
        if (!Take(c))
            throw std::runtime_error("Invalid language JSON");
    }
    unsigned Hex4() {
        unsigned v = 0;
        for (int i = 0; i < 4; ++i) {
            if (pos >= text.size())
                throw std::runtime_error("Invalid JSON Unicode");
            char c = text[pos++];
            unsigned n = c >= '0' && c <= '9'   ? unsigned(c - '0')
                         : c >= 'a' && c <= 'f' ? unsigned(c - 'a' + 10)
                         : c >= 'A' && c <= 'F' ? unsigned(c - 'A' + 10)
                                                : 16;
            if (n == 16)
                throw std::runtime_error("Invalid JSON Unicode");
            v = (v << 4) | n;
        }
        return v;
    }
    std::string String() {
        Need('"');
        std::string s;
        bool ended = false;
        while (pos < text.size()) {
            unsigned char c = text[pos++];
            if (c == '"') {
                ended = true;
                break;
            }
            if (c < 32)
                throw std::runtime_error("JSON control character");
            if (c != '\\') {
                s += char(c);
                continue;
            }
            if (pos >= text.size())
                throw std::runtime_error("JSON escape");
            char e = text[pos++];
            switch (e) {
            case '"':
            case '\\':
            case '/':
                s += e;
                break;
            case 'b':
                s += '\b';
                break;
            case 'f':
                s += '\f';
                break;
            case 'n':
                s += '\n';
                break;
            case 'r':
                s += '\r';
                break;
            case 't':
                s += '\t';
                break;
            case 'u': {
                unsigned cp = Hex4();
                if (cp >= 0xd800 && cp <= 0xdbff) {
                    if (pos + 2 > text.size() || text.substr(pos, 2) != "\\u")
                        throw std::runtime_error("JSON surrogate");
                    pos += 2;
                    unsigned lo = Hex4();
                    if (lo < 0xdc00 || lo > 0xdfff)
                        throw std::runtime_error("JSON surrogate");
                    cp = 0x10000 + ((cp - 0xd800) << 10) + (lo - 0xdc00);
                } else if (cp >= 0xdc00 && cp <= 0xdfff)
                    throw std::runtime_error("JSON surrogate");
                s += EncodeUTF8(std::u32string(1, char32_t(cp)));
                break;
            }
            default:
                throw std::runtime_error("JSON escape");
            }
        }
        if (!ended)
            throw std::runtime_error("Unterminated JSON string");
        DecodeUTF8(s);
        return s;
    }
    std::map<std::string, std::string> Object() {
        Need('{');
        std::map<std::string, std::string> out;
        if (Take('}'))
            return out;
        do {
            auto k = String();
            Need(':');
            auto v = String();
            if (!out.emplace(k, v).second)
                throw std::runtime_error("Duplicate JSON key");
        } while (Take(','));
        Need('}');
        return out;
    }
    std::map<std::string, std::map<std::string, std::string>> Parse() {
        Need('{');
        std::map<std::string, std::map<std::string, std::string>> out;
        if (!Take('}')) {
            do {
                auto k = String();
                Need(':');
                auto v = Object();
                if (!out.emplace(k, std::move(v)).second)
                    throw std::runtime_error("Duplicate language section");
            } while (Take(','));
            Need('}');
        }
        Space();
        if (pos != text.size())
            throw std::runtime_error("Trailing JSON data");
        return out;
    }
    static std::string Quote(const std::string& text) {
        std::string s = "\"";
        for (unsigned char c : text) {
            switch (c) {
            case '"':
                s += "\\\"";
                break;
            case '\\':
                s += "\\\\";
                break;
            case '\n':
                s += "\\n";
                break;
            case '\r':
                s += "\\r";
                break;
            case '\t':
                s += "\\t";
                break;
            default:
                if (c < 32) {
                    const char* hex = "0123456789abcdef";
                    s += "\\u00";
                    s += hex[c >> 4];
                    s += hex[c & 15];
                } else
                    s += char(c);
            }
        }
        return s + '"';
    }
};
struct LanguageRecord {
    std::string name = "English", shortName = "en", localizedName = "English", base = "en";
    bool custom = false;
    std::map<std::string, std::string> strings;
};
struct LanguageCatalog {
    std::filesystem::path root;
    std::vector<LanguageRecord> entries;
    int selected = 0;
    std::vector<std::string> warnings;
    LanguageCatalog() {
        LanguageRecord en;
        for (auto& kv : DefaultLanguageStrings())
            en.strings.emplace(kv.first, kv.second);
        entries.push_back(std::move(en));
    }
    static bool SafeCode(const std::string& code) {
        if (code.empty() || code.size() > 7)
            return false;
        for (unsigned char c : code)
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' ||
                  c == '-'))
                return false;
        std::string upper = code;
        for (char& c : upper)
            c = char(std::toupper(static_cast<unsigned char>(c)));
        if (upper == "CON" || upper == "PRN" || upper == "AUX" || upper == "NUL" ||
            (upper.size() == 4 && (upper.substr(0, 3) == "COM" || upper.substr(0, 3) == "LPT") &&
             upper[3] >= '0' && upper[3] <= '9'))
            return false;
        return true;
    }
    int Index(const std::string& code) const {
        std::string a = code;
        for (char& c : a)
            c = char(std::tolower(static_cast<unsigned char>(c)));
        for (int i = 0; i < int(entries.size()); ++i) {
            std::string b = entries[i].shortName;
            for (char& c : b)
                c = char(std::tolower(static_cast<unsigned char>(c)));
            if (a == b)
                return i;
        }
        return -1;
    }
    void Load(const std::filesystem::path& dir) {
        root = dir;
        warnings.clear();
        std::error_code ec;
        if (!std::filesystem::exists(root, ec))
            return;
        std::vector<std::filesystem::path> files;
        for (auto& e : std::filesystem::directory_iterator(root)) {
            if (e.is_regular_file() && e.path().extension() == ".json")
                files.push_back(e.path());
        }
        std::sort(files.begin(), files.end());
        for (auto& path : files) {
            if (entries.size() >= 64) {
                warnings.push_back("Language file limit reached");
                break;
            }
            try {
                if (std::filesystem::file_size(path) > 4 * 1024 * 1024)
                    throw std::runtime_error("Language file exceeds 4 MiB");
                std::ifstream f(path, std::ios::binary);
                if (!f)
                    throw std::runtime_error("Cannot read language");
                std::string text((std::istreambuf_iterator<char>(f)), {});
                auto json = LangJSON(std::move(text)).Parse();
                auto& info = json.at("info");
                LanguageRecord record;
                record.name = info.at("full_name");
                record.localizedName = info.at("loc_name");
                record.shortName = path.stem().string();
                record.base = info.at("base_lang");
                record.custom = true;
                record.strings = json.at("strings");
                if (!SafeCode(record.shortName) || Index(record.shortName) >= 0 || record.name.empty() ||
                    record.localizedName.empty())
                    throw std::runtime_error("Invalid or duplicate language");
                entries.push_back(std::move(record));
            } catch (const std::exception& e) {
                warnings.push_back(path.filename().string() + ": " + e.what());
            }
        }
        std::ifstream pref(root / "selected.txt");
        std::string code;
        if (pref >> code) {
            int i = Index(code);
            if (i >= 0)
                selected = i;
        }
    }
    void Select(int i) {
        if (i < 0 || i >= int(entries.size()))
            return;
        selected = i;
        if (!root.empty()) {
            std::filesystem::create_directories(root);
            std::ofstream f(root / "selected.txt", std::ios::trunc);
            if (!f)
                throw std::runtime_error("Cannot save selected language");
            f << entries[i].shortName;
        }
    }

    static std::u32string Brand(std::u32string s) {
        static const std::u32string names[][2] = {{U"Neverlose", U"Neverlose"}, {U"NEVERLOSE", U"NEVERLOSE"}};
        for (const auto& n : names)
            for (std::size_t at = s.find(n[0]); at != std::u32string::npos;
                 at = s.find(n[0], at + n[1].size()))
                s.replace(at, n[0].size(), n[1]);
        return s;
    }
    std::u32string Label(const std::string& key) const {
        auto& map = entries.at(std::size_t(selected)).strings;
        auto it = map.find(key);
        if (it != map.end())
            return Brand(DecodeUTF8(it->second));
        auto f = DefaultLanguageStrings().find(key);
        return f == DefaultLanguageStrings().end() ? DecodeUTF8(key) : Brand(DecodeUTF8(f->second));
    }
    std::string CreateError(const std::array<std::u32string, 3>& values) const {
        if (values[0].empty())
            return "menu_user_language_new_name_cantbeempty";
        if (values[1].empty())
            return "menu_user_language_new_shortname_cantbemepty";
        if (Index(EncodeUTF8(values[1])) >= 0)
            return "menu_user_language_new_shortname_exists";
        if (!SafeCode(EncodeUTF8(values[1])))
            return "Short name: use 1-7 ASCII letters, digits, - or _.";
        if (values[2].empty())
            return "menu_user_language_new_localizedname_cantbeempty";
        return {};
    }
    void Create(const std::array<std::u32string, 3>& values, int baseIndex) {
        auto error = CreateError(values);
        if (!error.empty())
            throw std::runtime_error(error);
        if (baseIndex < 0 || baseIndex >= int(entries.size()))
            throw std::runtime_error("Invalid base language");
        if (root.empty())
            throw std::runtime_error("Language storage is not configured");
        LanguageRecord r;
        r.name = EncodeUTF8(values[0]);
        r.shortName = EncodeUTF8(values[1]);
        r.localizedName = EncodeUTF8(values[2]);
        r.base = entries[baseIndex].shortName;
        r.custom = true;
        r.strings = entries[baseIndex].strings;
        std::filesystem::create_directories(root);
        auto dest = root / (r.shortName + ".json");
        if (std::filesystem::exists(dest))
            throw std::runtime_error("Language file already exists");
        auto temp = root / (r.shortName + ".json.tmp");
        std::ofstream f(temp, std::ios::binary | std::ios::trunc);
        if (!f)
            throw std::runtime_error("Cannot create language file");
        auto q = LangJSON::Quote;
        f << "{\n  \"info\": {\n    \"name\": " << q(r.name) << ",\n    \"full_name\": " << q(r.name)
          << ",\n    \"loc_name\": " << q(r.localizedName) << ",\n    \"base_lang\": " << q(r.base)
          << "\n  },\n  \"strings\": {\n";
        bool first = true;
        for (auto& kv : r.strings) {
            if (!first)
                f << ",\n";
            first = false;
            f << "    " << q(kv.first) << ": " << q(kv.second);
        }
        f << "\n  }\n}\n";
        f.close();
        if (!f) {
            std::filesystem::remove(temp);
            throw std::runtime_error("Cannot write language file");
        }
        std::filesystem::rename(temp, dest);
        entries.push_back(std::move(r));
    }
    void Remove(int i) {
        if (i <= 0 || i >= int(entries.size()) || !entries[i].custom)
            return;
        if (root.empty())
            throw std::runtime_error("Language storage is not configured");
        if (!std::filesystem::remove(root / (entries[i].shortName + ".json")))
            throw std::runtime_error("Language file not found");
        entries.erase(entries.begin() + i);
        Select(selected == i ? 0 : selected > i ? selected - 1 : selected);
    }
    void Reload(int i) {
        if (i <= 0 || i >= int(entries.size()))
            return;
        auto code = entries[i].shortName;
        LanguageCatalog next;
        next.Load(root);
        int index = next.Index(code);
        if (index < 0)
            throw std::runtime_error("Language not reloaded; check JSON");
        entries[i] = std::move(next.entries[index]);
    }
};
}
