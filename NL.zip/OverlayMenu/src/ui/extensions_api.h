#pragma once
namespace menu {

inline constexpr char ExtensionsApiURL[] = "https://docs2.neverlose.cc/cs2";
}
