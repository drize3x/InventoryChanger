#pragma once
#include "world_view_ui.h"

namespace menu {
struct SearchNativeEditor {
    enum class Mode { None, Players, Rage, Ambience, WorldESP, WorldMisc, WorldHud, WorldView };
    Mode mode = Mode::None;
    PlayersUI players;
    RageUI rage;
    WorldAmbienceUI ambience;
    WorldESPUI esp;
    WorldMiscUI misc;
    WorldHudUI hud;
    WorldViewUI view;
    bool viewDirect = false;
    bool miscRoot = false;

    bool Active() const {
        return mode == Mode::Players ? players.Active() :
               mode == Mode::Rage ? rage.Active() :
               mode == Mode::Ambience ? ambience.open && (ambience.context >= 0 || ambience.color >= 0 || ambience.choice >= 0 || ambience.menu >= 0 || ambience.editing >= 0) :
               mode == Mode::WorldESP ? esp.Active() :
               mode == Mode::WorldMisc ? (miscRoot ? misc.page >= 0 :
                   misc.color >= 0 || misc.choice >= 0 || misc.context >= 0 || misc.editing >= 0) :
               mode == Mode::WorldHud ? hud.Active() :
               mode == Mode::WorldView && (viewDirect ? view.panel >= 0 : view.choice >= 0);
    }
    void Close() {
        if (mode == Mode::Players && players.Active())
            players.Close();
        else if (mode == Mode::Rage && rage.Active())
            rage.Close();
        else if (mode == Mode::Ambience && ambience.open)
            ambience.Close();
        else if (mode == Mode::WorldESP && esp.Active())
            esp.Close();
        else if (mode == Mode::WorldMisc && misc.page >= 0)
            misc.Close();
        else if (mode == Mode::WorldHud && hud.Active())
            hud.Close();
        else if (mode == Mode::WorldView && view.panel >= 0)
            view.Close();
    }
    void Open(const PresetsUI& ui, Settings& cfg, LanguageCatalog* languages,
              const WorldAmbienceUI* sourceAmbience = nullptr) {
        const int n = ui.mainSearchNativeRequest;
        if (n < 0 || std::size_t(n) >= ui.mainSearchItems.size())
            return;
        const auto& item = ui.mainSearchItems[std::size_t(n)];
        Close();
        if (item.source == MainSearchSource::Players &&
            (ui.mainSearchNativeAction == 39 || ui.mainSearchNativeAction == 37) &&
            item.index >= 0 && std::size_t(item.index) < PlayersSpecs.size()) {
            mode = Mode::Players;
            players.languages = languages;
            players.visible = true;
            players.blocked = false;
            players.scale = cfg.scale;
            players.page = PlayersSpecs[std::size_t(item.index)].group >= 2 ? 1 : 0;
            if (ui.mainSearchNativeAction == 39)
                players.OpenSwatch(item.index, ui.mainSearchNativeAnchor);
            else {
                players.choice = item.index;
                players.searchChoiceAnchor = true;
                players.searchChoiceBox = ui.mainSearchNativeAnchor;
                players.choiceAnchor = ui.mainSearchNativeAnchor;
                players.Start(1000 + item.index);
            }
        } else if (item.source == MainSearchSource::Ambience && item.index >= 0 &&
                   std::size_t(item.index) < AmbienceSpecs.size()) {
            mode = Mode::Ambience;
            ambience.Open();
            ambience.languages = languages;
            ambience.visible = true;
            ambience.blocked = false;
            ambience.scale = cfg.scale;
            ambience.profile = item.profile;
            ambience.popupFade.Snap(1);
            if (sourceAmbience) {
                ambience.skyImageQuery = sourceAmbience->skyImageQuery;
                ambience.skyRefresh = sourceAmbience->skyRefresh;
                ambience.skyOpenFolder = sourceAmbience->skyOpenFolder;
                ambience.skyCustomQuery = sourceAmbience->skyCustomQuery;
                ambience.currentMap = sourceAmbience->currentMap;
                ambience.mapImageQuery = sourceAmbience->mapImageQuery;
                ambience.mapImageLoader = sourceAmbience->mapImageLoader;
                ambience.hostClipboard = sourceAmbience->hostClipboard;
            }
            if (ui.mainSearchNativeAction == 39)
                ambience.OpenColor(item.colorSlot, item.colorCount, ui.mainSearchNativeAnchor);
            else if (ui.mainSearchNativeAction == 41)
                ambience.OpenContext(item.index, ui.mainSearchNativeAnchor);
            else if (ui.mainSearchNativeAction == 37) {
                ambience.choice = item.index;
                ambience.choiceBox = ui.mainSearchNativeAnchor;
                ambience.StartTransition(1000 + item.index);
            }
        } else if (item.source == MainSearchSource::WorldView && item.index >= 0 &&
                   std::size_t(item.index) < WorldViewSpecs.size() && ui.mainSearchNativeAction == 37) {
            mode = Mode::WorldView;
            view.Close(false);
            view.languages = languages;
            view.hudEnabled = false;
            view.visible = true;
            view.blocked = false;
            view.scale = cfg.scale;
            view.Open(WorldViewSpecs[std::size_t(item.index)].page);
            view.searchDetached = true;
            view.searchAnchor = ui.mainSearchNativeAnchor;
            viewDirect = view.panel >= 4;
            if (!viewDirect)
                view.choice = item.index;
        } else if (item.source == MainSearchSource::WorldHud && item.index >= 0 &&
                   std::size_t(item.index) < WorldHudSpecs.size() && ui.mainSearchNativeAction == 37) {
            mode = Mode::WorldHud;
            hud.Close(false);
            hud.languages = languages;
            hud.visible = true;
            hud.blocked = false;
            hud.scale = cfg.scale;
            hud.searchDetached = true;
            hud.choice = item.index;
            hud.choiceAnchor = ui.mainSearchNativeAnchor;
            hud.directPosition = false;
        } else if (item.source == MainSearchSource::WorldMisc && item.index >= 0 &&
                   std::size_t(item.index) < WorldMiscSpecs.size() &&
                   WorldMiscSpecs[std::size_t(item.index)].page != 2) {
            mode = Mode::WorldMisc;
            misc.Close(false);
            misc.languages = languages;
            misc.visible = true;
            misc.blocked = false;
            misc.scale = cfg.scale;
            miscRoot = ui.mainSearchNativeAction == 41;
            misc.searchSuppressRoot = !miscRoot;
            misc.detachedRoot = miscRoot ? item.index : -1;
            misc.Open(WorldMiscSpecs[std::size_t(item.index)].page);
            misc.anchor = {ui.mainSearchNativeAnchor.x + ui.mainSearchNativeAnchor.w + 7 * cfg.scale,
                           ui.mainSearchNativeAnchor.y, 0, 0};
            if (ui.mainSearchNativeAction == 39) {
                WorldMiscUI::Hit hit{ui.mainSearchNativeAnchor, WorldMiscUI::Swatch,
                                     item.colorSlot, item.colorCount};
                misc.Activate(hit, cfg);
            } else if (ui.mainSearchNativeAction == 37) {
                misc.choice = item.index;
                misc.choiceBox = ui.mainSearchNativeAnchor;
                misc.StartTransition(1000 + item.index);
            }
        } else if (item.source == MainSearchSource::WorldESP && item.index >= 0 &&
                   std::size_t(item.index) < WorldESPSpecs.size()) {
            mode = Mode::WorldESP;
            esp.Close(true);
            esp.languages = languages;
            esp.visible = true;
            esp.blocked = false;
            esp.scale = cfg.scale;
            esp.searchDetached = true;
            if (ui.mainSearchNativeAction == 39)
                esp.OpenColor(item.index, ui.mainSearchNativeAnchor);
            else if (ui.mainSearchNativeAction == 37) {
                esp.choice = item.index;
                esp.choiceAnchor = ui.mainSearchNativeAnchor;
                esp.choiceFade.Open(item.index);
                esp.popupFade.Snap(0);
                esp.popupFade.Tick(1, 0);
            }
        } else if (item.source == MainSearchSource::Rage && item.index >= 0 &&
                   item.index < RageFieldCount) {
            mode = Mode::Rage;
            rage.languages = languages;
            rage.visible = true;
            rage.blocked = false;
            rage.scale = cfg.scale;
            if (ui.mainSearchNativeAction == 39) {
                RageUI::Hit hit{ui.mainSearchNativeAnchor, RageUI::ColorPoint, item.index};
                rage.Activate(hit, cfg);
            } else if (ui.mainSearchNativeAction == 41) {
                int detail = RageUI::Detail(item.index);
                if (detail >= 0)
                    rage.OpenPopup(detail, ui.mainSearchNativeAnchor);
            } else if (ui.mainSearchNativeAction == 37) {
                rage.choice = item.index;
                rage.searchChoiceAnchor = true;
                rage.searchChoiceBox = ui.mainSearchNativeAnchor;
                rage.choiceMotion.Snap(0);
            }
        }
    }
    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl) {
        if (!Active())
            return false;
        if (mode == Mode::Players)
            players.Click(x, y, down, cfg, ctrl);
        else if (mode == Mode::Rage)
            rage.Click(x, y, down, cfg, ctrl);
        else if (mode == Mode::Ambience)
            ambience.Click(x, y, down, cfg, ctrl);
        else if (mode == Mode::WorldESP)
            esp.Click(x, y, down, cfg, ctrl);
        else if (mode == Mode::WorldMisc)
            misc.Click(x, y, down, cfg, ctrl);
        else if (mode == Mode::WorldHud)
            hud.Click(x, y, down, cfg, ctrl);
        else
            view.Click(x, y, down, cfg, ctrl);
        return true;
    }
    void Move(float x, float y, Settings& cfg) {
        if (mode == Mode::Players && players.Active())
            players.Move(x, y, cfg);
        else if (mode == Mode::Rage && rage.Active())
            rage.Move(x, y, cfg);
        else if (mode == Mode::Ambience && Active())
            ambience.Move(x, y, cfg);
        else if (mode == Mode::WorldESP && Active())
            esp.Move(x, y, cfg);
        else if (mode == Mode::WorldMisc && Active())
            misc.Move(x, y, cfg);
        else if (mode == Mode::WorldHud && Active())
            hud.Move(x, y, cfg);
        else if (mode == Mode::WorldView && Active())
            view.Move(x, y, cfg);
    }
    void Tick(float dt, const Settings& cfg) {
        if (mode == Mode::Players) {
            players.Tick(dt, cfg);
            if (!players.Active() && players.transitions.empty())
                mode = Mode::None;
        } else if (mode == Mode::Rage) {
            rage.Tick(dt, cfg);
            if (!rage.Active() && std::none_of(rage.transitions.begin(), rage.transitions.end(),
                    [](const auto& entry) { return entry.second.motion.value > .001f; }))
                mode = Mode::None;
        } else if (mode == Mode::Ambience) {
            ambience.Tick(dt, cfg);
            if (!Active() && std::none_of(ambience.transitions.begin(), ambience.transitions.end(),
                    [](const auto& entry) { return entry.second.motion.value > .001f; })) {
                ambience.Close(false);
                mode = Mode::None;
            }
        } else if (mode == Mode::WorldESP) {
            esp.Tick(dt, cfg);
            if (!esp.Active() && esp.popupFade.value <= .001f)
                mode = Mode::None;
        } else if (mode == Mode::WorldMisc) {
            if (!Active() && misc.page >= 0)
                misc.Close();
            misc.Tick(dt, cfg);
            if (misc.page < 0 && misc.popupFade.value <= .001f)
                mode = Mode::None;
        } else if (mode == Mode::WorldHud) {
            hud.Tick(dt, cfg);
            if (!hud.Active() && hud.popupFade.value <= .001f)
                mode = Mode::None;
        } else if (mode == Mode::WorldView) {
            if (!Active() && view.panel >= 0)
                view.Close();
            view.Tick(dt, cfg);
            if (view.panel < 0 && view.popupFade.value <= .001f && view.choiceTransition.value <= .001f)
                mode = Mode::None;
        }
    }
    bool Key(int key, Settings& cfg, bool shift, bool ctrl) {
        if (!Active())
            return false;
        if (mode == Mode::Players)
            return players.Key(key, cfg, shift, ctrl);
        if (mode == Mode::Rage)
            return rage.Key(key, cfg, shift, ctrl);
        if (mode == Mode::Ambience)
            return ambience.Key(key, cfg, shift, ctrl);
        if (mode == Mode::WorldESP)
            return esp.Key(key, cfg, shift, ctrl);
        if (mode == Mode::WorldMisc)
            return misc.Key(key, cfg, shift, ctrl);
        if (mode == Mode::WorldHud)
            return hud.Key(key, cfg, shift, ctrl);
        return view.Key(key, cfg, shift, ctrl);
    }
    bool Character(char16_t c) {
        if (!Active())
            return false;
        if (mode == Mode::Players)
            return players.Character(c);
        if (mode == Mode::Rage)
            return rage.Character(c);
        if (mode == Mode::Ambience)
            return ambience.Character(c);
        if (mode == Mode::WorldESP)
            return esp.Character(c);
        if (mode == Mode::WorldMisc)
            return misc.Character(c);
        if (mode == Mode::WorldHud)
            return hud.Character(c);
        return view.Character(c);
    }
    bool Wheel(float delta, Settings& cfg) {
        if (!Active())
            return false;
        if (mode == Mode::Players)
            return players.Wheel(delta, cfg);
        if (mode == Mode::Rage)
            return rage.Wheel(delta, cfg);
        if (mode == Mode::Ambience)
            return ambience.Wheel(delta, cfg);
        if (mode == Mode::WorldESP)
            return esp.Wheel(delta, cfg);
        if (mode == Mode::WorldMisc)
            return misc.Wheel(delta, cfg);
        if (mode == Mode::WorldHud)
            return hud.Wheel(delta, cfg);
        return view.Wheel(delta, cfg);
    }
    void Draw(PresetsUI& ui, Fonts& fonts, const Settings& cfg, const Layout& layout, int width, int height) {
        if (mode == Mode::None)
            return;
        PresetsUI* paint = nullptr;
        std::size_t first = 0;
        if (mode == Mode::Players) {
            players.Measure(fonts, cfg, layout, ui.headerLine, width, height, true, false);
            paint = &players.paint;
            first = players.searchLayerStart;
        } else if (mode == Mode::Rage) {
            rage.Measure(fonts, cfg, layout, ui.headerLine, width, height, true, false);
            paint = &rage.paint;
            first = rage.searchLayerStart;
        } else if (mode == Mode::Ambience) {
            ambience.Measure(fonts, cfg, ui.headerLine, width, height, true, false);
            paint = &ambience.paint;
            first = ambience.searchLayerStart;
        } else if (mode == Mode::WorldESP) {
            esp.Measure(fonts, cfg, ui.headerLine, width, height, true, false);
            paint = &esp.paint;
            first = esp.searchLayerStart;
        } else if (mode == Mode::WorldMisc) {
            misc.Measure(fonts, cfg, ui.headerLine, width, height, true, false);
            paint = &misc.paint;
            first = misc.searchLayerStart;
        } else if (mode == Mode::WorldHud) {
            hud.Measure(fonts, cfg, layout, ui.headerLine, ui.headerLine, width, height, true, false);
            paint = &hud.paint;
            first = std::min(std::size_t(1), paint->layers.size());
        } else {
            State state;
            state.selected = 2;
            state.selectedVisual = 1;
            view.MeasurePage(fonts, cfg, state, layout, ui.headerLine, width, height, false);
            paint = &view.paint;
            first = view.searchLayerStart;
        }
        const std::size_t end = mode == Mode::WorldView ? view.searchLayerEnd : paint->layers.size();
        for (std::size_t i = first; i < end; ++i) {
            auto layer = paint->layers[i];
            layer.searchOverlay = true;
            layer.opacity *= ui.mainSearchOpacity.value;
            for (auto& draw : layer.draw) {
                draw.color.a *= ui.mainSearchOpacity.value;
                draw.shadowColor.a *= ui.mainSearchOpacity.value;
                draw.backdropOpacity *= ui.mainSearchOpacity.value;
            }
            ui.layers.push_back(std::move(layer));
        }
    }
};
}
