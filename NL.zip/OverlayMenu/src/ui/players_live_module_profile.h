#pragma once
#include "watermark_kd_schema.h"
namespace menu {

template <class Reader> bool LiveESPVerifyNativeLayout(Reader&& read, const WatermarkKdModule& module) {
    const bool oldBuild = module.timestamp == 0x6ada7340u && module.size == 0x29a0000u;
    const bool rageBuild = module.timestamp == 0x6aebc4dau && module.size == 0x29a3000u;
    const bool updateBuild = module.timestamp == 0x6af4a59cu && module.size == 0x298a000u;
    if (!oldBuild && !rageBuild && !updateBuild)
        return false;
    const auto rva0 = oldBuild ? 0x7cc7e0u : (rageBuild ? 0x7ccfc0u : 0x7c6680u);
    const auto rva1 = oldBuild ? 0xab14c3u : (rageBuild ? 0xab1f63u : 0xaa4b23u);
    const auto rva2 = oldBuild ? 0x1778430u : (rageBuild ? 0x177abd0u : 0x176f080u);
    const auto rva3 = oldBuild ? 0x1778490u : (rageBuild ? 0x177ac30u : 0x176f0e0u);
    const unsigned char guard0[] = {0x48, 0x8b, 0x81, 0x88, 0x3, 0x0, 0x0, 0xf3,
                                    0xf,  0x10, 0x80, 0xdc, 0x7, 0x0, 0x0, 0xc3};
    for (std::size_t i = 0; i < sizeof(guard0); ++i) {
        unsigned char value = 0;
        if (!read(module.base + rva0 + i, value) || value != guard0[i])
            return false;
    }
    const unsigned char guard1[] = {0x48, 0x8b, 0x8b, 0xc0, 0x1,  0x0,  0x0,  0x48, 0x85, 0xc9,
                                    0x74, 0x54, 0x48, 0x8b, 0xc6, 0x48, 0xc1, 0xe0, 0x5,  0xf,
                                    0x28, 0x4,  0x8,  0xf,  0x28, 0x4c, 0x8,  0x10};
    for (std::size_t i = 0; i < sizeof(guard1); ++i) {
        unsigned char value = 0;
        if (!read(module.base + rva1 + i, value) || value != guard1[i])
            return false;
    }
    const unsigned char guard2[] = {0x85, 0xd2, 0x78, 0x16, 0x3b, 0x91, 0x78, 0x1,  0x0, 0x0,
                                    0x7d, 0xe,  0x48, 0x8b, 0x81, 0xb0, 0x1,  0x0,  0x0, 0x48,
                                    0x63, 0xd2, 0x8b, 0x4,  0x90, 0xc3, 0x33, 0xc0, 0xc3};
    for (std::size_t i = 0; i < sizeof(guard2); ++i) {
        unsigned char value = 0;
        if (!read(module.base + rva2 + i, value) || value != guard2[i])
            return false;
    }
    const unsigned char guard3[] = {0x85, 0xd2, 0x78, 0x17, 0x3b, 0x91, 0x78, 0x1,  0x0,  0x0,  0x7d,
                                    0xf,  0x48, 0x8b, 0x81, 0x80, 0x1,  0x0,  0x0,  0x48, 0x63, 0xd2,
                                    0xf,  0xbf, 0x4,  0x50, 0xc3, 0xb8, 0xff, 0xff, 0xff, 0xff, 0xc3};
    for (std::size_t i = 0; i < sizeof(guard3); ++i) {
        unsigned char value = 0;
        if (!read(module.base + rva3 + i, value) || value != guard3[i])
            return false;
    }
    return true;
}
}
