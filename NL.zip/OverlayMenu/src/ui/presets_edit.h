#pragma once
#include "menu_core.h"
namespace menu {

struct PresetEditor {
    struct Snapshot {
        std::u32string text;
        std::size_t cursor, anchor;
    };
    std::size_t cursor = 0, anchor = 0;
    float scroll = 0;
    std::u32string observed;
    std::vector<Snapshot> undo, redo;
    std::vector<float> advance;
    static std::size_t Bytes(const std::u32string& s) {
        std::size_t n = 0;
        for (auto c : s)
            n += c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
        return n;
    }
    void Reset(const std::u32string& s, bool select = false) {
        observed = s;
        cursor = s.size();
        anchor = select ? 0 : cursor;
        scroll = 0;
        undo.clear();
        redo.clear();
        advance.clear();
    }
    void Sync(const std::u32string& s) {
        if (observed != s)
            Reset(s);
        cursor = std::min(cursor, s.size());
        anchor = std::min(anchor, s.size());
    }
    bool Selected() const {
        return cursor != anchor;
    }
    std::size_t Begin() const {
        return std::min(cursor, anchor);
    }
    std::size_t End() const {
        return std::max(cursor, anchor);
    }
    void Save(const std::u32string& s) {
        undo.push_back({s, cursor, anchor});
        if (undo.size() > 100)
            undo.erase(undo.begin());
        redo.clear();
    }
    void Erase(std::u32string& s) {
        s.erase(Begin(), End() - Begin());
        cursor = anchor = Begin();
    }
    bool Insert(std::u32string& s, const std::u32string& input, std::size_t capacity) {
        Sync(s);
        std::u32string clean;
        auto probe = s;
        probe.erase(Begin(), End() - Begin());
        for (auto c : input) {
            if (c < 32 || c == 127 || c == 0x2028 || c == 0x2029 || c > 0x10ffff ||
                (c >= 0xd800 && c <= 0xdfff))
                continue;
            auto trial = probe;
            trial.insert(Begin(), clean + std::u32string(1, c));
            if (Bytes(trial) >= capacity)
                break;
            clean.push_back(c);
        }
        if (clean.empty())
            return false;
        Save(s);
        Erase(s);
        s.insert(cursor, clean);
        cursor += clean.size();
        anchor = cursor;
        observed = s;
        return true;
    }
    bool Delete(std::u32string& s, bool back, bool word = false) {
        Sync(s);
        auto c = cursor, a = anchor;
        if (!Selected()) {
            if (back) {
                if (!cursor)
                    return false;
                --cursor;
                if (word)
                    while (cursor && s[cursor - 1] != U' ')
                        --cursor;
            } else {
                if (cursor == s.size())
                    return false;
                ++cursor;
                if (word)
                    while (cursor < s.size() && s[cursor] != U' ')
                        ++cursor;
            }
        }
        auto endCursor = cursor, endAnchor = anchor;
        cursor = c;
        anchor = a;
        Save(s);
        cursor = endCursor;
        anchor = endAnchor;
        Erase(s);
        observed = s;
        return true;
    }

    bool History(std::u32string& s, bool forward) {
        Sync(s);
        auto& from = forward ? redo : undo;
        auto& to = forward ? undo : redo;
        if (from.empty())
            return false;
        to.push_back({s, cursor, anchor});
        auto st = std::move(from.back());
        from.pop_back();
        s = std::move(st.text);
        cursor = st.cursor;
        anchor = st.anchor;
        observed = s;
        return true;
    }
    void Move(const std::u32string& s, int direction, bool shift, bool word = false) {
        Sync(s);
        std::size_t next = cursor;
        if (!shift && Selected() && !word)
            next = direction < 0 ? Begin() : End();
        else if (direction < 0) {
            if (next)
                --next;
            if (word)
                while (next && s[next - 1] != U' ')
                    --next;
        } else {
            if (next < s.size())
                ++next;
            if (word)
                while (next < s.size() && s[next] != U' ')
                    ++next;
        }
        cursor = next;
        if (!shift)
            anchor = cursor;
    }
    void Home(const std::u32string& s, bool end, bool shift) {
        Sync(s);
        cursor = end ? s.size() : 0;
        if (!shift)
            anchor = cursor;
    }
    void All(const std::u32string& s) {
        Sync(s);
        anchor = 0;
        cursor = s.size();
    }
    std::u32string Selection(const std::u32string& s) const {
        return s.substr(Begin(), End() - Begin());
    }
    void Measure(Fonts& f, float px, const std::u32string& s, float width, bool horizontalScroll = true,
                 int face = 1) {
        Sync(s);
        advance.assign(s.size() + 1, 0);
        for (std::size_t i = 1; i < advance.size(); ++i)
            advance[i] = f.NativeTextSize(face, px, s.substr(0, i)).w;
        if (!horizontalScroll) {
            scroll = 0;
            return;
        }
        float caret = advance[cursor], quarter = width * .25f;
        if (caret < scroll)
            scroll = std::max(0.f, caret - quarter);
        else if (caret > scroll + width - 1)
            scroll = caret - width + quarter;
        scroll = std::clamp(scroll, 0.f, std::max(0.f, advance.back() - width + 1));
    }
    void Mouse(float local, bool extend) {
        if (advance.empty())
            return;
        float x = local + scroll;
        std::size_t i = 0;
        while (i + 1 < advance.size() && x >= (advance[i] + advance[i + 1]) * .5f)
            ++i;
        cursor = i;
        if (!extend)
            anchor = cursor;
    }
};
}
