#pragma once

struct PlayersESPItemSpec {
    const char* id;
    const char* key;
    int category;
};
inline constexpr std::array<const char*, 5> PlayersESPCategories{
    {"visuals_preview_category_main", "visuals_preview_category_flags", "visuals_preview_category_weapon",
     "visuals_preview_category_aimbot", "visuals_preview_category_extensions"}};
inline constexpr std::array<PlayersESPItemSpec, 29> PlayersESPItems{{
    {"main.boundingbox", "visuals_preview_item_boundingbox", 0},
    {"main.name", "visuals_preview_item_name", 0},
    {"main.distance", "visuals_preview_item_distance", 0},
    {"main.healthbar", "visuals_preview_item_healthbar", 0},
    {"main.ammobar", "visuals_preview_item_ammobar", 0},
    {"main.skeleton", "visuals_preview_item_skeleton", 0},
    {"flags.unarmored", "visuals_preview_item_unarmored", 1},
    {"flags.defuser", "visuals_preview_item_defuser", 1},
    {"flags.blind", "visuals_preview_item_blind", 1},
    {"flags.scoped", "visuals_preview_item_scoped", 1},
    {"flags.reload", "visuals_preview_item_reload", 1},
    {"flags.immunity", "visuals_preview_item_immunity", 1},
    {"flags.slowed", "visuals_preview_item_slowed", 1},
    {"flags.vulnerable", "visuals_preview_item_vulnerable", 1},
    {"flags.bomb", "visuals_preview_item_bomb", 1},
    {"flags.hostage", "visuals_preview_item_hostage", 1},
    {"flags.defuse", "visuals_preview_item_defuse", 1},
    {"flags.pinpulled", "visuals_preview_item_pinpulled", 1},
    {"flags.money", "visuals_preview_item_money", 1},
    {"flags.orderpriority", "visuals_preview_item_orderpriority", 1},
    {"flags.delay", "visuals_preview_item_delay", 1},
    {"weapon.text", "visuals_preview_item_text", 2},
    {"weapon.icon", "visuals_preview_item_icon", 2},
    {"weapon.readinessbar", "visuals_preview_item_readinessbar", 2},
    {"weapon.bomb", "visuals_preview_item_bomb", 2},
    {"weapon.defuser", "visuals_preview_item_defuser", 2},
    {"weapon.taser", "visuals_preview_item_taser", 2},
    {"aimbot.hitchance", "visuals_preview_item_hitchance", 3},
    {"aimbot.hitboxes", "visuals_preview_item_hitboxes", 3},
}};

#include "players_esp_settings_model.h"
