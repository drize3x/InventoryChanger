#pragma once

#include "watermark_hud_patterns.h"
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>
namespace menu {
namespace world_scoreboard_patterns {
inline constexpr char GameStateType[] = ".?AVCUiComponent_GameState@@";
inline constexpr char LazySingleton[] =
    "B9 ? ? ? ? E8 ? ? ? ? 48 85 C0 74 ? 48 8B C8 E8 ? ? ? ? 48 89 05 ? ? ? ?";
inline constexpr unsigned LazySizeAt = 1, LazyCtorAt = 18, LazyStoreAt = 23, LazyEnd = 30;
inline constexpr char RankingName[] = "GetPlayerCompetitiveRanking";
inline constexpr std::uint8_t RevealNone = 0, RevealGame = 1, RevealOurs = 2;
inline constexpr unsigned CtorWindow = 0x60, NativeBack = 0x40, NativeWindow = 0x400, HandlerGap = 0x18,
                          HandlerWindow = 0x100;
}
struct ScoreboardRankBindings {
    std::uintptr_t global = 0, vtable = 0, native = 0, handler = 0;
    std::uint32_t field = 0, objectSize = 0;
    bool Valid() const {
        return global && vtable && native && field && objectSize && field < objectSize;
    }
};

inline std::vector<std::uintptr_t> ScoreboardRipRefs(const HudScanImage& c, unsigned char op0,
                                                     unsigned char op1, unsigned char op2,
                                                     std::uintptr_t target, std::size_t limit = 64) {
    std::vector<std::uintptr_t> hits;
    for (const auto& part : c.parts) {
        if (!(part.flags & 0x20000000) || part.bytes.size() < 7)
            continue;
        for (std::size_t i = 0; i + 7 <= part.bytes.size(); ++i) {
            if (part.bytes[i] != op0 || part.bytes[i + 1] != op1 || part.bytes[i + 2] != op2)
                continue;
            std::int32_t d = 0;
            std::memcpy(&d, part.bytes.data() + i + 3, 4);
            if (std::int64_t(part.start + i) + 7 + d == std::int64_t(target)) {
                hits.push_back(part.start + i);
                if (hits.size() >= limit)
                    return hits;
            }
        }
    }
    return hits;
}
inline bool ResolveScoreboardRanks(const HudScanImage& c, ScoreboardRankBindings& out,
                                   std::string& diagnostic) {
    using namespace world_scoreboard_patterns;
    out = {};
    ScoreboardRankBindings b;
    std::ostringstream log;
    log << std::hex;
    auto fail = [&](const char* s) {
        diagnostic = log.str() + "FAIL " + s;
        return false;
    };

    auto tables = c.Vtables(GameStateType, 0);
    log << "GameState tables=" << tables.size() << "; ";
    if (tables.size() != 1)
        return fail("typed CUiComponent_GameState vtable");
    b.vtable = tables[0];

    auto sites = c.Find(LazySingleton, true, 4096);
    log << "lazy sites=" << sites.size() << "; ";
    if (sites.empty() || sites.size() >= 4096)
        return fail("lazy singleton sites");
    std::vector<std::uintptr_t> typed;
    for (auto a : sites) {
        const auto ctor = c.Rip(a + LazyCtorAt, 1, 5);
        if (!c.Contains(ctor, CtorWindow, 0x20000000))
            continue;
        bool stores = false;
        for (unsigned i = 0; i + 10 <= CtorWindow && !stores; ++i) {
            unsigned char q[10]{};
            if (!c.Bytes(ctor + i, q, 10))
                break;
            if (q[0] == 0x48 && q[1] == 0x8d && q[2] == 0x05 && q[7] == 0x48 && q[8] == 0x89 &&
                (q[9] == 0x01 || q[9] == 0x03 || q[9] == 0x06 || q[9] == 0x07) && c.Rip(ctor + i) == b.vtable)
                stores = true;
        }
        if (!stores)
            continue;
        const auto global = c.Rip(a + LazyStoreAt);
        std::uint32_t size = 0;
        if (!c.Read(a + LazySizeAt, size))
            return fail("allocation size");
        if (!b.global) {
            b.global = global;
            b.objectSize = size;
        } else if (b.global != global || b.objectSize != size)
            return fail("typed constructor stored into two singletons");
        typed.push_back(a);
    }
    log << "typed sites=" << typed.size() << " global=+" << (b.global - c.module.base)
        << " size=" << b.objectSize << "; ";
    if (typed.empty())
        return fail("no lazy site constructs the typed object");
    if (!c.Contains(b.global, 8, 0x80000000, 0x20000000))
        return fail("singleton pointer outside writable data");
    if (b.objectSize < 0x10 || b.objectSize > 0x100000)
        return fail("allocation size range");

    std::vector<int> name;
    for (const char* p = RankingName;; ++p) {
        name.push_back(static_cast<unsigned char>(*p));
        if (!*p)
            break;
    }
    std::vector<std::uintptr_t> strings;
    for (auto s : c.Find(name, false, 16)) {
        unsigned char before = 1;
        if (c.Read(s - 1, before) && before == 0)
            strings.push_back(s);
    }
    log << "name strings=" << strings.size() << "; ";
    if (strings.size() != 1)
        return fail("method name string");
    auto refs = ScoreboardRipRefs(c, 0x48, 0x8d, 0x0d, strings[0]);
    log << "name refs=" << refs.size() << "; ";
    if (refs.size() != 1)
        return fail("method registration");
    for (unsigned back = 7; back <= NativeBack && !b.native; ++back) {
        unsigned char q[3]{};
        if (c.Bytes(refs[0] - back, q, 3) && q[0] == 0x48 && q[1] == 0x8d && q[2] == 0x05)
            b.native = c.Rip(refs[0] - back);
    }
    if (!b.native || !c.Contains(b.native, NativeWindow, 0x20000000))
        return fail("registered native");
    log << "native=+" << (b.native - c.module.base) << "; ";
    bool thisInR15 = false;
    for (unsigned i = 0; i + 3 <= 0x40; ++i) {
        unsigned char q[3]{};
        if (c.Bytes(b.native + i, q, 3) && q[0] == 0x4c && q[1] == 0x8b && q[2] == 0xf9)
            thisInR15 = true;
    }
    if (!thisInR15)
        return fail("native keeps this in r15");
    unsigned compares = 0;
    for (unsigned i = 0; i + 8 <= NativeWindow; ++i) {
        unsigned char q[8]{};
        if (!c.Bytes(b.native + i, q, 8))
            break;
        if (q[0] == 0x41 && q[1] == 0x80 && q[2] == 0xbf && q[7] == 0) {
            std::uint32_t f = 0;
            std::memcpy(&f, q + 3, 4);
            b.field = f;
            ++compares;
        }
    }
    log << "reveal tests=" << compares << " field=+" << b.field << "; ";
    if (compares != 1)
        return fail("exactly one cmp byte [r15+field],0 in the native");
    if (!b.field || b.field >= b.objectSize)
        return fail("field outside the singleton allocation");

    std::vector<std::uintptr_t> handlers;
    for (auto a : sites) {
        if (c.Rip(a + LazyStoreAt) != b.global)
            continue;
        for (unsigned gap = 0; gap + 5 <= HandlerGap; ++gap) {
            unsigned char op = 0;
            if (!c.Read(a + LazyEnd + gap, op) || op != 0xe9)
                continue;
            const auto target = c.Rip(a + LazyEnd + gap, 1, 5);
            if (!c.Contains(target, HandlerWindow, 0x20000000))
                continue;
            for (unsigned i = 0; i + 7 <= HandlerWindow; ++i) {
                unsigned char q[7]{};
                if (!c.Bytes(target + i, q, 7))
                    break;
                std::uint32_t f = 0;
                std::memcpy(&f, q + 2, 4);
                if (q[0] == 0xc6 && q[1] >= 0x80 && q[1] <= 0x87 && q[1] != 0x84 && f == b.field &&
                    q[6] == RevealGame) {
                    if (std::find(handlers.begin(), handlers.end(), target) == handlers.end())
                        handlers.push_back(target);
                    break;
                }
            }
        }
    }
    log << "writers=" << handlers.size();
    if (!handlers.empty())
        log << " handler=+" << (handlers[0] - c.module.base);
    log << "; ";
    if (handlers.empty())
        return fail("the game's own reveal writer");
    b.handler = handlers[0];
    out = b;
    diagnostic = log.str() + "resolved typed singleton + named native field + game writer; no fixed RVAs";
    return true;
}
}
