#pragma once
#include "presets_ui.h"
#include "hud_color_picker.h"
#include "popup_paint_transition.h"
#include "world_tooltip.h"
#include "group_row_geometry.h"
#include <iomanip>
#include <sstream>
namespace menu {

struct WorldESPHit {
    Box box{};
    int kind = 0, index = -1, option = -1;
    Box control{};
    int Key() const {
        return kind * 100000 + (index + 3) * 32 + option + 1;
    }
};
struct WorldESPUI {
    enum {
        Surface,
        Open,
        Toggle,
        Slider,
        Select,
        Option,
        Swatch,
        Chip,
        ItemToggle,
        ItemSelect,
        ItemSwatch,
        Scrollbar,
        Details
    };
    PresetsUI paint;
    std::size_t searchLayerStart = 0;
    LanguageCatalog* languages = nullptr;
    std::vector<WorldESPHit> hits;
    std::array<Box, 6> mainRows{};
    std::array<Box, WorldESPFieldCount> rows{}, sliders{}, details{};
    std::array<Box, 24> chips{};
    Box card{}, popup{}, commonBox{}, commonDivider{}, editorBox{}, nestedBox{}, selectionBox{}, anchor{},
        editorAnchor{}, nestedAnchor{}, choiceAnchor{};
    int page = -1, color = -1, item = -1, nested = -1, choice = -1, held = -1, drag = -1, editing = -1,
        focus = -1;
    bool visible = false, blocked = false, selectAll = false, releaseGuard = false;
    float scale = 1, F = 18, mouseX = -1, mouseY = -1, scroll = 0, maxScroll = 0, editorScroll = 0,
          editorMax = 0, nestedScroll = 0, nestedMax = 0, choiceScroll = 0, choiceMax = 0, hoverTime = 0;
    int viewportW = 1600, viewportH = 1100, hoverKey = -1, scrollDrag = -1;
    std::string numeric;
    std::array<Box, 4> scrollTracks{}, scrollThumbs{};
    HudColorPicker picker, nestedPicker;
    PresetMotion popupFade, tooltipFade;
    PopupPaintTransition editorFade, nestedFade, choiceFade;
    std::map<int, PresetMotion> hover, checks;
    struct Marquee {
        float offset = 0, time = 0, overflow = 0, full = 0;
        int stable = 0;
        bool over = false;
        Box row{};
        std::u32string label;
        PresetMotion returning;
    };
    std::map<int, Marquee> marquees;
    std::vector<PresetLayer> cached;
    std::u32string Label(const std::string& k) const {
        if (k.empty())
            return {};
        if (languages)
            return languages->Label(k);
        auto p = DefaultLanguageStrings().find(k);
        return DecodeUTF8(p == DefaultLanguageStrings().end() ? k : p->second);
    }
    static std::u32string Upper(std::u32string t) {
        for (auto& c : t) {
            if (c >= U'a' && c <= U'z')
                c -= 32;
            else if (c >= 0x430 && c <= 0x44f)
                c -= 32;
            else if (c == 0x451)
                c = 0x401;
        }
        return t;
    }
    bool searchDetached = false;
    bool Active() const {
        return page >= 0 || color >= 0 || item >= 0 || (searchDetached && choice >= 0);
    }
    bool PickerActive() const {
        return color >= 0 || item >= 0;
    }
    bool Capturing() const {
        return held >= 0 || drag >= 0 || scrollDrag >= 0 || releaseGuard || picker.held >= 0 ||
               nestedPicker.held >= 0;
    }
    bool Editing() const {
        return editing >= 0 || (PickerActive() && (nested >= 0 ? nestedPicker.Editing() : picker.Editing()));
    }
    void CancelInput() {
        held = drag = scrollDrag = -1;
        picker.held = nestedPicker.held = -1;
    }
    void Close(bool immediate = false) {
        page = color = item = nested = choice = editing = focus = -1;
        numeric.clear();
        CancelInput();
        releaseGuard = false;
        picker.field = nestedPicker.field = -1;
        picker.formatsOpen = picker.headerOpen = nestedPicker.formatsOpen = nestedPicker.headerOpen = false;
        if (immediate) {
            cached.clear();
            popupFade.Snap(0);
            editorFade.Clear();
            nestedFade.Clear();
            choiceFade.Clear();
        } else
            popupFade.Tick(0, 0);
    }
    int HitAt(float x, float y) const {
        if (!visible || blocked)
            return -1;
        for (int n = int(hits.size()) - 1; n >= 0; --n)
            if (hits[std::size_t(n)].box.Contains(x, y))
                return n;
        return -1;
    }
    void OpenPage(int p, float x = -1, float y = -1) {
        Close(true);
        page = p;
        scroll = 0;
        anchor = {x >= 0 ? x + 1 : card.x + card.w + 8 * scale, y >= 0 ? y + 1 : card.y, 0, 0};
        popupFade.Snap(0);
        popupFade.Tick(1, 0);
    }
    void ConfigurePicker() {
        int count =
            item >= 0 ? WorldESPItems[std::size_t(item)].points : WorldESPSpecs[std::size_t(color)].count;
        picker.Reset(count > 1 ? 5 : 4, false, count > 1);
        std::array<std::string, 3> names{};
        if (item >= 0) {
            if (item == 22 || item == 23) {
                names[0] = "visuals_world_worldesp_values_grenades_lethal";
                names[1] = "visuals_world_worldesp_values_grenades_utility";
            }
        } else {
            int first = WorldESPSpecs[std::size_t(color)].color;
            for (int n = 0; n < count; ++n) {
                names[std::size_t(n)] = WorldESPColorSpecs[std::size_t(first + n)].key;
                if (WorldESPColorSpecs[std::size_t(first + n)].alphaLocked)
                    picker.alphaLockMask |= 1u << unsigned(count > 1 ? 5 + n : 4);
            }
        }
        picker.ConfigureEntries(count, names);
    }
    void OpenColor(int i, Box at) {
        color = i;
        item = nested = choice = editing = -1;
        editorScroll = 0;
        editorAnchor = {at.x + at.w + 7 * scale, at.y, 0, 0};
        CancelInput();
        ConfigurePicker();
        nestedFade.Clear();
        choiceFade.Clear();
        editorFade.Open(i);
        if (page < 0) {
            popupFade.Snap(0);
            popupFade.Tick(1, 0);
        }
    }
    void OpenItem(int i, float x, float y) {
        item = i;
        color = nested = choice = editing = -1;
        editorScroll = 0;
        editorAnchor = {x + 1, y + 1, 0, 0};
        CancelInput();
        ConfigurePicker();
        nestedFade.Clear();
        choiceFade.Clear();
        editorFade.Open(100 + i);
    }
    void OpenNested(int c, Box at) {
        nested = c;
        choice = editing = -1;
        nestedScroll = 0;
        nestedAnchor = {at.x + at.w + 7 * scale, at.y, 0, 0};
        nestedPicker.Reset(4);
        CancelInput();
        choiceFade.Clear();
        nestedFade.Open(c);
    }
    Settings Proxy(const Settings& cfg, bool child = false) const {
        Settings p = cfg;
        if (child) {
            p.worldHud.colors[4] = cfg.worldESP.items[std::size_t(item)].colors[std::size_t(nested)];
            return p;
        }
        if (!PickerActive())
            return p;
        int count =
            item >= 0 ? WorldESPItems[std::size_t(item)].points : WorldESPSpecs[std::size_t(color)].count;
        for (int n = 0; n < count; ++n)
            p.worldHud.colors[std::size_t(count > 1 ? 5 + n : 4)] =
                item >= 0 ? cfg.worldESP.items[std::size_t(item)].colors[std::size_t(n)]
                          : cfg.worldESP.colors[std::size_t(WorldESPSpecs[std::size_t(color)].color + n)];
        return p;
    }
    void Sync(Settings& cfg, const Settings& p, bool child = false) {
        if (child) {
            cfg.worldESP.items[std::size_t(item)].colors[std::size_t(nested)] = p.worldHud.colors[4];
            return;
        }
        if (!PickerActive())
            return;
        int count =
            item >= 0 ? WorldESPItems[std::size_t(item)].points : WorldESPSpecs[std::size_t(color)].count;
        for (int n = 0; n < count; ++n) {
            Color c = p.worldHud.colors[std::size_t(count > 1 ? 5 + n : 4)];
            if (item >= 0)
                cfg.worldESP.items[std::size_t(item)].colors[std::size_t(n)] = c;
            else
                cfg.worldESP.SetColor(std::size_t(WorldESPSpecs[std::size_t(color)].color + n), c);
        }
    }
    std::vector<std::string> Options(int i) const {
        if (i < 100)
            return WorldESPOptions(i);
        if (item >= 0)
            for (const auto& f : WorldESPFields(item))
                if (f.slot == i - 100)
                    return f.options;
        return {};
    }
    bool IsMulti(int i) const {
        if (i < 100)
            return WorldESPSpecs[std::size_t(i)].kind == WorldESPKind::Multi;
        for (const auto& f : WorldESPFields(item))
            if (f.slot == i - 100)
                return f.kind == ESPFieldKind::Multi;
        return false;
    }
    int ChoiceValue(int i, const Settings& cfg) const {
        return i < 100 ? int(cfg.worldESP.value[std::size_t(i)])
                       : cfg.worldESP.items[std::size_t(item)].value[std::size_t(i - 100)];
    }
    std::u32string Summary(int i, const Settings& cfg) const {
        auto options = Options(i);
        int v = ChoiceValue(i, cfg);
        if (!IsMulti(i))
            return options.empty() ? U""
                                   : Label(options[std::size_t(std::clamp(v, 0, int(options.size()) - 1))]);
        std::u32string t;
        for (std::size_t n = 0; n < options.size(); ++n)
            if (v & (1 << n)) {
                if (!t.empty())
                    t += U", ";
                t += Label(options[n]);
            }
        if (t.size() >= 15) {
            t.clear();
            for (std::size_t n = 0; n < options.size(); ++n)
                if (v & (1 << n)) {
                    auto label = Label(options[n]);
                    if (!t.empty())
                        t += U", ";
                    if (!label.empty())
                        t += label.front();
                }
        }
        return t.empty() ? Label("menu_select") : t;
    }
    std::string Number(int i, const Settings& cfg) const {
        std::ostringstream s;
        if (WorldESPSpecs[std::size_t(i)].kind == WorldESPKind::Decimal)
            s << std::fixed << std::setprecision(2);
        s << cfg.worldESP.value[std::size_t(i)];
        return s.str();
    }
    std::u32string ValueLabel(int i, const Settings& cfg) const {
        auto v = cfg.worldESP.value[std::size_t(i)];
        if (WorldESPAuto(i, v))
            return Label("value_auto");
        auto s = DecodeUTF8(Number(i, cfg));
        if (WorldESPSpecs[std::size_t(i)].percent)
            s += U"%";
        return s;
    }
    void BeginEdit(int i, const Settings& cfg) {
        if (!WorldESPEnabled(i, cfg.worldESP))
            return;
        editing = i;
        numeric = Number(i, cfg);
        selectAll = true;
        drag = -1;
    }
    bool Commit(Settings& cfg) {
        if (editing < 0)
            return true;
        try {
            std::size_t n = 0;
            float v = std::stof(numeric, &n);
            if (n != numeric.size() || !std::isfinite(v))
                return false;
            cfg.worldESP.Set(std::size_t(editing), v);
            editing = -1;
            numeric.clear();
            return true;
        } catch (...) {
            return false;
        }
    }
    std::string TooltipKey() const {
        if (choice >= 0 || nested >= 0 || Editing() || drag >= 0 || picker.held >= 0)
            return {};
        int n = HitAt(mouseX, mouseY);
        if (n < 0)
            return {};
        const auto& hit = hits[std::size_t(n)];
        if (hit.kind != Toggle && hit.kind != Slider && hit.kind != Select)
            return {};
        int i = hit.index;
        if (i == TrajPoints || i == ItemPoints || i == TrajPrecise)
            return std::string(WorldESPSpecs[std::size_t(i)].key) + "_tooltip";
        return {};
    }
    void Tick(float dt, const Settings& cfg) {
        dt = std::max(0.f, dt);
        popupFade.Tick(Active() ? 1.f : 0.f, dt);
        editorFade.Tick(PickerActive() ? 1.f : 0.f, dt);
        nestedFade.Tick(nested >= 0 ? 1.f : 0.f, dt);
        choiceFade.Tick(choice >= 0 ? 1.f : 0.f, dt);
        if (!visible || blocked)
            return;
        int n = HitAt(mouseX, mouseY), hot = n >= 0 ? hits[std::size_t(n)].Key() : -1;
        for (const auto& h : hits) {
            bool open = (h.kind == Open && h.index == page) ||
                        ((h.kind == Swatch || h.kind == Details) && h.index == color) ||
                        (h.kind == Select && h.index == choice) ||
                        (h.kind == ItemSelect && 100 + h.index == choice);
            hover[h.Key()].Tick(open || h.Key() == held ? 1.f : hot == h.Key() ? .5f : 0.f, dt);
        }
        for (int i = 0; i < WorldESPFieldCount; ++i)
            checks[i].Tick(cfg.worldESP.value[std::size_t(i)] != 0 ? 1.f : 0.f, dt);
        for (int i = 0; i < 24; ++i)
            checks[100 + i].Tick(cfg.worldESP.itemEnabled[std::size_t(i)] ? 1.f : 0.f, dt);
        if (item >= 0)
            for (const auto& f : WorldESPFields(item))
                checks[200 + f.slot].Tick(
                    cfg.worldESP.items[std::size_t(item)].value[std::size_t(f.slot)] != 0 ? 1.f : 0.f, dt);
        picker.Tick(dt, PickerActive() && nested < 0 && choice < 0);
        nestedPicker.Tick(dt, nested >= 0 && choice < 0);
        for (auto& pair : marquees) {
            auto& m = pair.second;
            bool over = m.row.Contains(mouseX, mouseY) && m.overflow > 0 && hot == pair.first;
            if (over) {
                m.time = m.over ? m.time + dt : 0;
                if (m.stable >= 5 && m.time > .3f) {
                    m.offset += 40 * scale * dt;
                    if (m.offset >= m.full + 20 * scale)
                        m.offset = m.overflow;
                }
                m.returning.Snap(m.offset);
            } else {
                m.time = 0;
                m.returning.Tick(0, dt, .25f);
                m.offset = m.returning.value;
            }
            m.over = over;
        }
        hoverTime += dt;
        tooltipFade.Tick(!TooltipKey().empty() && hoverTime >= .3f ? 1.f : 0.f, dt);
    }
    void DragTo(float x, Settings& cfg) {
        if (drag < 0 || !WorldESPEnabled(drag, cfg.worldESP))
            return;
        const auto& b = sliders[std::size_t(drag)];
        const auto& s = WorldESPSpecs[std::size_t(drag)];
        cfg.worldESP.Set(std::size_t(drag),
                         s.minimum + std::clamp((x - b.x) / std::max(1.f, b.w - 1), 0.f, 1.f) *
                                         (s.maximum - s.minimum));
    }
    float& ScrollValue(int i) {
        return i == 0 ? scroll : i == 1 ? editorScroll : i == 2 ? nestedScroll : choiceScroll;
    }
    float ScrollMaximum(int i) const {
        return i == 0 ? maxScroll : i == 1 ? editorMax : i == 2 ? nestedMax : choiceMax;
    }
    void ScrollTo(float y) {
        if (scrollDrag < 0)
            return;
        const auto b = scrollTracks[std::size_t(scrollDrag)], t = scrollThumbs[std::size_t(scrollDrag)];
        float hi = ScrollMaximum(scrollDrag);
        ScrollValue(scrollDrag) = std::clamp((y - b.y - t.h * .5f) / std::max(1.f, b.h - t.h) * hi, 0.f, hi);
    }
    void Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        int n = HitAt(x, y), k = n >= 0 ? hits[std::size_t(n)].Key() : -1;
        if (k != hoverKey) {
            hoverKey = k;
            hoverTime = 0;
        }
        if (x == -1 && y == -1)
            return;
        if (scrollDrag >= 0) {
            ScrollTo(y);
            return;
        }
        if (drag >= 0) {
            DragTo(x, cfg);
            return;
        }
        if (PickerActive() && choice < 0) {
            bool child = nested >= 0;
            auto p = Proxy(cfg, child);
            (child ? nestedPicker : picker).Move(x, y, p);
            Sync(cfg, p, child);
        }
    }
    void Activate(const WorldESPHit& h, Settings& cfg) {
        if (h.kind == Open) {
            OpenPage(h.index, mouseX, mouseY);
            return;
        }
        if (h.kind == Swatch || h.kind == Details) {
            OpenColor(h.index, h.box);
            return;
        }
        if (h.kind == Chip) {
            cfg.worldESP.itemEnabled[std::size_t(h.index)] = !cfg.worldESP.itemEnabled[std::size_t(h.index)];
            return;
        }
        if (h.kind == ItemSwatch) {
            OpenNested(h.index, h.box);
            return;
        }
        if (h.kind == ItemToggle) {
            cfg.worldESP.items[std::size_t(item)].value[std::size_t(h.index)] ^= 1;
            return;
        }
        if (h.kind == Toggle) {
            if (WorldESPEnabled(h.index, cfg.worldESP))
                cfg.worldESP.Set(std::size_t(h.index),
                                 cfg.worldESP.value[std::size_t(h.index)] == 0 ? 1.f : 0.f);
            return;
        }
        if (h.kind == Select || h.kind == ItemSelect) {
            if (h.kind == Select && !WorldESPEnabled(h.index, cfg.worldESP))
                return;
            choice = h.index + (h.kind == ItemSelect ? 100 : 0);
            choiceAnchor = h.box;
            choiceScroll = 0;
            choiceFade.Open(choice);
            return;
        }
        if (h.kind == Option) {
            int v = ChoiceValue(h.index, cfg);
            bool multi = IsMulti(h.index);
            v = multi ? v ^ (1 << h.option) : h.option;
            if (h.index < 100)
                cfg.worldESP.Set(std::size_t(h.index), float(v));
            else
                cfg.worldESP.items[std::size_t(item)].value[std::size_t(h.index - 100)] = v;
            if (!multi)
                choice = -1;
        }
    }
    void CloseTop() {
        if (choice >= 0)
            choice = -1;
        else if (nested >= 0) {
            nested = -1;
            nestedPicker.Reset(4);
        } else if (item >= 0) {
            item = -1;
            picker.Reset(4);
        } else if (color >= 0) {
            color = -1;
            picker.Reset(4);
        } else
            Close();
        editing = -1;
        numeric.clear();
        CancelInput();
        releaseGuard = true;
    }
    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl = false) {
        mouseX = x;
        mouseY = y;
        if (!visible || blocked) {
            CancelInput();
            return false;
        }
        if (!down && releaseGuard) {
            releaseGuard = false;
            CancelInput();
            return true;
        }
        int n = HitAt(x, y);
        if (!Active() && n < 0 && !Capturing())
            return false;
        if (down && editing >= 0 && (n < 0 || hits[std::size_t(n)].index != editing) && !Commit(cfg))
            return true;
        if (PickerActive() && choice < 0 && editing < 0) {
            bool child = nested >= 0;
            auto& cp = child ? nestedPicker : picker;
            auto p = Proxy(cfg, child);
            bool capture = cp.held >= 0 || cp.formatsOpen || cp.headerOpen || cp.HitAt(x, y) >= 0 ||
                           cp.box.Contains(x, y) || cp.Editing();
            if (capture && cp.Click(x, y, down, p)) {
                Sync(cfg, p, child);
                return true;
            }
            Sync(cfg, p, child);
        }
        if (down) {
            if (n < 0) {
                if (Active()) {
                    CloseTop();
                    return true;
                }
                return false;
            }
            const auto h = hits[std::size_t(n)];
            if (h.kind == Surface) {
                if (h.index == -2)
                    CloseTop();
                return Active() || releaseGuard;
            }
            held = focus = h.Key();
            if (h.kind == Scrollbar) {
                scrollDrag = h.index;
                ScrollTo(y);
                return true;
            }
            if (h.kind == Slider) {
                if (!WorldESPEnabled(h.index, cfg.worldESP))
                    return true;
                if (ctrl)
                    BeginEdit(h.index, cfg);
                else {
                    if (!Commit(cfg))
                        return true;
                    drag = h.index;
                    DragTo(x, cfg);
                }
            }
            return true;
        }
        if (scrollDrag >= 0)
            ScrollTo(y);
        if (drag >= 0)
            DragTo(x, cfg);
        bool consumed = held >= 0 || drag >= 0 || scrollDrag >= 0 || Active();
        int was = held, wasDrag = drag;
        CancelInput();
        if (n >= 0 && was == hits[std::size_t(n)].Key() && wasDrag < 0 && editing < 0)
            Activate(hits[std::size_t(n)], cfg);
        return consumed;
    }
    bool Context(float x, float y, Settings&) {
        int n = HitAt(x, y);
        if (n >= 0 && hits[std::size_t(n)].kind == Chip) {
            OpenItem(hits[std::size_t(n)].index, x, y);
            return true;
        }
        return false;
    }
    bool Key(int k, Settings& cfg, bool shift = false, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        if (editing >= 0) {
            if (k == 27) {
                editing = -1;
                numeric.clear();
            } else if (k == 13)
                Commit(cfg);
            else if (ctrl && k == 'A')
                selectAll = true;
            else if (k == 8 || k == 46) {
                if (selectAll)
                    numeric.clear();
                else if (!numeric.empty())
                    numeric.pop_back();
                selectAll = false;
            }
            return true;
        }
        if (PickerActive() && choice < 0) {
            bool child = nested >= 0;
            auto p = Proxy(cfg, child);
            if ((child ? nestedPicker : picker).Key(k, p, ctrl)) {
                Sync(cfg, p, child);
                return true;
            }
        }
        if (k == 27 && Active()) {
            CloseTop();
            releaseGuard = false;
            return true;
        }
        if (k == 33 || k == 34) {
            float delta = (k == 33 ? -1.f : 1.f) * 150 * scale;
            if (choice >= 0)
                choiceScroll = std::clamp(choiceScroll + delta, 0.f, choiceMax);
            else if (nested >= 0)
                nestedScroll = std::clamp(nestedScroll + delta, 0.f, nestedMax);
            else if (PickerActive())
                editorScroll = std::clamp(editorScroll + delta, 0.f, editorMax);
            else if (page >= 0)
                scroll = std::clamp(scroll + delta, 0.f, maxScroll);
            else
                return false;
            return true;
        }
        if (k == 9) {
            std::vector<int> list;
            std::size_t start = 0;
            for (std::size_t i = 0; i < hits.size(); ++i)
                if (hits[i].kind == Surface && hits[i].index == -2)
                    start = i;
            for (std::size_t i = start; i < hits.size(); ++i)
                if (hits[i].kind != Surface && hits[i].kind != Scrollbar)
                    list.push_back(hits[i].Key());
            if (list.empty())
                return Active();
            auto it = std::find(list.begin(), list.end(), focus);
            int index = it == list.end() ? (shift ? int(list.size()) - 1 : 0)
                                         : (int(it - list.begin()) + (shift ? -1 : 1) + int(list.size())) %
                                               int(list.size());
            focus = list[std::size_t(index)];
            return true;
        }
        for (const auto& h : hits)
            if (h.Key() == focus) {
                if (h.kind == Slider && (k == 37 || k == 39)) {
                    if (WorldESPEnabled(h.index, cfg.worldESP)) {
                        float step =
                            WorldESPSpecs[std::size_t(h.index)].kind == WorldESPKind::Decimal ? .01f : 1.f;
                        cfg.worldESP.Set(std::size_t(h.index),
                                         cfg.worldESP.value[std::size_t(h.index)] +
                                             (k == 37 ? -step : step) * (shift ? 10 : 1));
                    }
                    return true;
                }
                if (k == 13 || k == 32) {
                    if (h.kind == Slider)
                        BeginEdit(h.index, cfg);
                    else
                        Activate(h, cfg);
                    return true;
                }
            }
        return Active();
    }
    bool Character(char16_t c) {
        if (editing >= 0) {
            if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.') {
                if (selectAll) {
                    numeric.clear();
                    selectAll = false;
                }
                if (numeric.size() < 20)
                    numeric += char(c);
            }
            return true;
        }
        return PickerActive() && (nested >= 0 ? nestedPicker.Character(c) : picker.Character(c));
    }
    bool Wheel(float steps, Settings& cfg) {
        if (!visible || blocked || !Active())
            return false;
        if (choice >= 0) {
            choiceScroll = std::clamp(choiceScroll - steps * 30 * scale, 0.f, choiceMax);
            return true;
        }
        int n = HitAt(mouseX, mouseY);
        if (n >= 0 && hits[std::size_t(n)].kind == Slider && editing < 0 &&
            WorldESPEnabled(hits[std::size_t(n)].index, cfg.worldESP)) {
            int i = hits[std::size_t(n)].index;
            cfg.worldESP.Set(
                std::size_t(i),
                cfg.worldESP.value[std::size_t(i)] +
                    steps * (WorldESPSpecs[std::size_t(i)].kind == WorldESPKind::Decimal ? .01f : 1.f));
            return true;
        }
        if (nested >= 0)
            nestedScroll = std::clamp(nestedScroll - steps * 30 * scale, 0.f, nestedMax);
        else if (PickerActive())
            editorScroll = std::clamp(editorScroll - steps * 30 * scale, 0.f, editorMax);
        else
            scroll = std::clamp(scroll - steps * 30 * scale, 0.f, maxScroll);
        return true;
    }

    Fonts* fonts_ = nullptr;
    const Settings* cfg_ = nullptr;
    std::array<Color, 46> pal_{};
    float TW(const std::u32string& t, int f = 0, float px = 13) const {
        return std::trunc(fonts_->NativeTextSize(f, px * scale, t).w + .95f);
    }
    int Layer(Box b, bool pop = false) {
        paint.layers.push_back({b, 15 * scale, pop, {}});
        paint.layers.back().pixelAligned = true;
        return int(paint.layers.size()) - 1;
    }
    void Rect(int z, Box b, Color c, float radius = 0, float stroke = 0, Box extra = {}) {
        if (b.w <= 0 || b.h <= 0)
            return;
        PresetDraw d{b, c, radius, stroke, 15, {}, false};
        d.clipped = true;
        d.clip = paint.layers[std::size_t(z)].box;
        if (extra.w > 0)
            d.clip = PresetIntersect(d.clip, extra);
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
    }
    void Text(int z, Box b, std::u32string t, Color c, int font = 0, float px = 13, Box clip = {}) {
        if (b.w <= 0 || b.h <= 0)
            return;
        PresetDraw d{b, c, 0, 0, 15, std::move(t), font == 3};
        d.font = font;
        d.textSize = px;
        d.clipped = true;
        d.clip = paint.layers[std::size_t(z)].box;
        if (clip.w > 0)
            d.clip = PresetIntersect(d.clip, clip);
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
    }
    void Hit(int z, Box b, int kind, int i = -1, int o = -1, Box control = {}) {
        if (blocked)
            return;
        b = PresetIntersect(b, paint.layers[std::size_t(z)].box);
        if (b.w > 0 && b.h > 0)
            hits.push_back({b, kind, i, o, control});
    }
    void Barrier() {
        if (!blocked)
            hits.push_back({{0, 0, float(viewportW), float(viewportH)}, Surface, -2});
    }
    void SurfaceAt(int z, Box b) {
        Rect(z, b, pal_[8], 15 * scale);
        Rect(z, b, pal_[11], 15 * scale, scale);
        Hit(z, b, Surface);
    }
    void AlphaFrom(std::size_t first, float a) {
        for (std::size_t n = first; n < paint.layers.size(); ++n) {
            paint.layers[n].opacity *= a;
            for (auto& d : paint.layers[n].draw) {
                d.color.a *= a;
                d.shadowColor.a *= a;
            }
        }
    }
    float Hover(int kind, int i = -1, int opt = -1) const {
        auto p = hover.find(WorldESPHit{{}, kind, i, opt}.Key());
        return p == hover.end() ? 0.f : p->second.value;
    }
    static Color Alpha(Color c, float a) {
        c.a *= a;
        return c;
    }
    void Separator(int z, float x, float y, float w) {
        Rect(z, {x, y, w, scale}, pal_[34]);
        paint.layers[std::size_t(z)].draw.back().pixelLine = true;
    }
    void MarqueeText(int z, Box b, const std::u32string& label, Color col, int key, Box row) {
        auto& m = marquees[key];
        float full = TW(label), overflow = std::max(0.f, full - b.w);
        if (m.label != label || std::abs(m.overflow - overflow) > .01f) {
            m.offset = m.time = 0;
            m.stable = 0;
            m.returning.Snap(0);
        } else
            m.stable = std::min(5, m.stable + 1);
        m.full = full;
        m.overflow = overflow;
        m.label = label;
        m.row = PresetIntersect(row, paint.layers[std::size_t(z)].box);
        if (b.w <= 0)
            return;
        Text(z, {b.x - m.offset, b.y, std::max(b.w, full) + scale, b.h}, label, col, 0, 13, b);
        if (m.offset > 0 && m.offset >= overflow)
            Text(z, {b.x - m.offset + full + 20 * scale, b.y, full + scale, b.h}, label, col, 0, 13, b);
    }
    void Preview(int z, Box b, Color first, Color last, int action, int index, bool gradient = false) {
        float s = scale;
        Rect(z, {b.x - 3 * s, b.y - 3 * s, b.w + 6 * s, b.h + 6 * s},
             Alpha(pal_[33], .4f * Hover(action, index)), 6 * s);
        Box rb{std::floor(b.x) - 1, std::floor(b.y) - 1, std::ceil(b.x + b.w) - std::floor(b.x) + 2,
               std::ceil(b.y + b.h) - std::floor(b.y) + 2};
        auto image = std::make_shared<Canvas>(int(rb.w), int(rb.h));
        DrawPickerPreview(*image, {b.x - rb.x, b.y - rb.y, b.w, b.h}, s, F + 6 * s, first, last, gradient,
                          false);
        PresetDraw d{rb, {1, 1, 1, 1}, 0, 0, 15, {}, false};
        d.raster = image;
        d.rasterStamp = PickerPreviewStamp(first, last, gradient, false);
        d.clipped = true;
        d.clip = paint.layers[std::size_t(z)].box;
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        Hit(z, b, action, index);
    }
    Box Switch(int z, Box row, float right, int action, int i, int motionKey, bool on, bool enabled = true) {
        float s = scale, nom = F + 2 * s, center = row.y + row.h * .5f, frac = center - std::trunc(center);
        Box b{right - 32 * s, center - nom * .5f + frac, 32 * s, nom - 2 * frac};
        auto q = checks.find(motionKey);
        float t = q == checks.end() || !q->second.initialized ? (on ? 1.f : 0.f) : q->second.value;
        float a = enabled ? 1.f : .5f;
        Rect(z, b, Alpha(pal_[22], a), nom * .5f);
        Rect(z, b, Alpha(pal_[23], a * t), nom * .5f);
        float r = nom * .5f - 2 * s, cx = b.x + nom * .5f + (b.w - nom) * t;
        Rect(z, {cx - r, center - r, 2 * r, 2 * r}, Alpha(Mix(pal_[20], pal_[21], t), a), r);
        Hit(z, row, action, i, -1, b);
        return b;
    }
    void DrawField(int z, Box b, int i, bool root = false) {
        const auto& d = WorldESPSpecs[std::size_t(i)];
        const auto& v = cfg_->worldESP;
        bool enabled = WorldESPEnabled(i, v);
        float s = scale, a = enabled ? 1.f : .5f;
        rows[std::size_t(i)] = PresetIntersect(b, paint.layers[std::size_t(z)].box);
        int action = d.kind == WorldESPKind::Check                                        ? Toggle
                     : d.kind == WorldESPKind::Integer || d.kind == WorldESPKind::Decimal ? Slider
                     : d.kind == WorldESPKind::Color                                      ? Swatch
                                                                                          : Select;
        auto h = WorldESPHit{{}, action, i};
        float hv = Hover(action, i);
        if (!root)
            Rect(z, b, Alpha(pal_[33], .4f * hv * a), 15 * s / 1.6f);
        float left = b.x + (root ? 0 : 12 * s), right = b.x + b.w - (root ? 6 * s : 12 * s);
        if (d.icon && !root) {
            auto glyph = std::u32string(1, d.icon);
            float iw = TW(glyph, 3);
            Text(z, {left + (20 * s - iw) * .5f, b.y + 7 * s, 20 * s, F}, glyph, Alpha(pal_[14], a), 3);
            left += 32 * s;
        }
        float labelRight = right;
        Box control{};
        if (d.kind == WorldESPKind::Check) {
            control = Switch(z, b, right, Toggle, i, i, v.value[std::size_t(i)] != 0, enabled);
            right = labelRight = control.x - 7 * s;
        }
        if (WorldESPDetailsButton(i)) {

            float iw = TW(U"\uf141", 3), w = iw + 12 * s;
            Box more{right - w, b.y, w, b.h};
            details[std::size_t(i)] = PresetIntersect(more, paint.layers[std::size_t(z)].box);
            float amount = Hover(Details, i);
            Rect(z, more, Alpha(pal_[33], .4f * amount * a), 15 * s / 1.6f);
            Text(z, {more.x + 6 * s, b.y + (root ? 3 : 7) * s, iw, F}, U"\uf141",
                 Alpha(Mix(pal_[14], pal_[2], amount), a), 3);
            Hit(z, more, Details, i);
            labelRight = more.x - 7 * s;
        } else if (d.color >= 0) {
            float ph = 16 * s;
            Box cb{right - ph, b.y + (b.h - ph) * .5f, ph, ph};
            Preview(z, cb, v.colors[std::size_t(d.color)], v.colors[std::size_t(d.color + d.count - 1)],
                    Swatch, i, d.count > 1);
            labelRight = cb.x - 7 * s;
        }
        if (action == Slider) {
            float w = std::trunc(b.w / 2.5f);
            control = {right - w, b.y + (b.h - 6 * s) * .5f, w, 6 * s};
            sliders[std::size_t(i)] = control;
            float t = (v.value[std::size_t(i)] - d.minimum) / (d.maximum - d.minimum);
            Rect(z, control, Alpha(pal_[24], a), 3 * s);
            if (t > 0)
                Rect(z, control, Alpha(pal_[25], a), 3 * s, 0, {control.x, control.y, w * t, control.h});
            labelRight = control.x - 7 * s;
            Hit(z, {control.x, b.y, control.w, b.h}, Slider, i, -1, control);
            if (editing == i) {
                Box edit{control.x, b.y, control.w, b.h};
                Rect(z, edit, pal_[12], 6 * s);
                Rect(z, edit, pal_[11], 6 * s, s);
                Text(z, {edit.x + 6 * s, edit.y + 7 * s, edit.w - 12 * s, F}, DecodeUTF8(numeric + "|"),
                     pal_[2]);
            }
        }
        if (action == Select) {
            auto summary = Summary(i, *cfg_);
            float aw = TW(U"\uf105", 3), w = std::min(b.w * .48f, TW(summary) + aw + 4 * s);
            if (d.color >= 0)
                right = labelRight;
            Box cb{right - w, b.y, w, b.h};
            Text(z, {cb.x, cb.y + 7 * s, std::max(0.f, w - aw - 4 * s), F}, summary, Alpha(pal_[14], a));
            Text(z, {right - aw, b.y + 7 * s, aw, F}, U"\uf105", Alpha(pal_[14], a), 3);
            Hit(z, b, Select, i, -1, cb);
            if (d.color >= 0) {
                float ph = 16 * s;
                Box sw{b.x + b.w - 12 * s - ph, b.y + (b.h - ph) * .5f, ph, ph};
                Hit(z, sw, Swatch, i);
            }
            labelRight = cb.x - 7 * s;
        }
        Color ink = d.kind == WorldESPKind::Check && v.value[std::size_t(i)] != 0
                        ? pal_[2]
                        : Mix(pal_[14], pal_[2], hv);
        MarqueeText(z, {left, b.y + (root ? 3 : 7) * s, std::max(0.f, labelRight - left), F}, Label(d.key),
                    Alpha(ink, a), h.Key(), b);
        if (root) {
            float motion = Hover(Toggle, i);
            if (motion > 0) {
            }
        }
    }
    std::vector<int> EditorFields() const {
        std::vector<int> list;
        int owner = item >= 0 ? 100 + item : color;
        for (int i = 0; i < WorldESPFieldCount; ++i)
            if (WorldESPSpecs[std::size_t(i)].owner == owner)
                list.push_back(i);
        return list;
    }
    void DrawItemField(int z, Box b, const ESPField& f) {
        float s = scale;
        const auto& v = cfg_->worldESP.items[std::size_t(item)];
        bool toggle = f.kind == ESPFieldKind::Toggle;
        int action = toggle ? ItemToggle : ItemSelect;
        int key = WorldESPHit{{}, action, f.slot}.Key();
        float hv = Hover(action, f.slot);
        Rect(z, b, Alpha(pal_[33], .4f * hv), 15 * s / 1.6f);
        float left = b.x + 12 * s, right = b.x + b.w - 12 * s;
        char32_t glyph = ESPFieldIcon(f.slot);
        if (glyph) {
            auto t = std::u32string(1, glyph);
            float iw = TW(t, 3);
            Text(z, {left + (20 * s - iw) * .5f, b.y + 7 * s, 20 * s, F}, t, pal_[14], 3);
            left += 32 * s;
        }
        float labelRight = right;
        if (toggle) {
            auto c = Switch(z, b, right, ItemToggle, f.slot, 200 + f.slot, v.value[std::size_t(f.slot)] != 0);
            right = labelRight = c.x - 7 * s;
        } else {
            auto text = Summary(100 + f.slot, *cfg_);
            float aw = TW(U"\uf105", 3), w = std::min(b.w * .5f, TW(text) + aw + 4 * s);
            Box c{right - w, b.y, w, b.h};
            Text(z, {c.x, b.y + 7 * s, w - aw - 4 * s, F}, text, pal_[14]);
            Text(z, {right - aw, b.y + 7 * s, aw, F}, U"\uf105", pal_[14], 3);
            Hit(z, b, ItemSelect, f.slot, -1, c);
            labelRight = c.x - 7 * s;
        }
        if (f.color >= 0) {
            float ph = 16 * s;
            Box cb{right - ph, b.y + (b.h - ph) * .5f, ph, ph};
            Preview(z, cb, v.colors[std::size_t(f.color)], v.colors[std::size_t(f.color)], ItemSwatch,
                    f.color);
            labelRight = cb.x - 7 * s;
        }
        MarqueeText(z, {left, b.y + 7 * s, std::max(0.f, labelRight - left), F}, Label(f.key),
                    toggle && v.value[std::size_t(f.slot)] != 0 ? pal_[2] : Mix(pal_[14], pal_[2], hv), key,
                    b);
    }
    void ScrollMark(int z, Box b, float at, float max, int index) {
        if (max <= 0)
            return;
        float s = scale;
        Box track{b.x + b.w - 6 * s, b.y + 7 * s, 4 * s, std::max(0.f, b.h - 14 * s)};
        float th = std::min(track.h, std::max(10 * s, track.h * track.h / (track.h + max)));
        scrollTracks[std::size_t(index)] = track;
        scrollThumbs[std::size_t(index)] = {track.x, track.y + (track.h - th) * at / max, track.w, th};
        Rect(z, track, pal_[17], 4 * s);
        Rect(z, scrollThumbs[std::size_t(index)], pal_[18], 4 * s);
        Hit(z, track, Scrollbar, index, -1, track);
    }
    void Measure(Fonts& fonts, const Settings& cfg, Box at, int width, int height, bool show, bool disabled) {
        visible = show;
        blocked = disabled;
        scale = cfg.scale;
        F = fonts.PixelHeight(0, 13 * scale);
        viewportW = width;
        viewportH = height;
        fonts_ = &fonts;
        cfg_ = &cfg;
        auto palette = CurrentPalette(cfg);
        std::copy(palette.begin(), palette.end(), pal_.begin());
        paint.layers.clear();
        hits.clear();
        rows.fill({});
        sliders.fill({});
        details.fill({});
        chips.fill({});
        commonBox = commonDivider = {};
        picker.hits.clear();
        nestedPicker.hits.clear();
        if (!visible) {
            Close(true);
            fonts_ = nullptr;
            cfg_ = nullptr;
            return;
        }
        if (blocked) {
            Close(true);
            focus = -1;
        }
        float s = scale, H = F + 6 * s, R = F + 14 * s, headerF = fonts.PixelHeight(0, 10 * s);
        card = {at.x, at.y + headerF + 5 * s, std::max(1.f, at.w), 14 * s + 6 * H + 5 * 15 * s};

        int z = Layer({at.x, at.y, at.w, headerF + 5 * s + card.h});
        Text(z, {card.x + 14 * s, at.y, card.w - 28 * s, headerF},
             Upper(Label("group_visuals_world_worldesp")), pal_[3], 0, 10);
        Rect(z, card, pal_[40], 15 * s);
        Rect(z, card, pal_[11], 15 * s, s);
        for (int p = 0; p < 6; ++p) {
            Box b{card.x + 14 * s, card.y + 7 * s + float(p) * (H + 15 * s), card.w - 28 * s, H};
            mainRows[std::size_t(p)] = b;
            if (p)
                Separator(z, b.x, b.y - 8 * s, b.w);
            int index = p == 4 ? Trajectory : Proximity;
            int action = p < 4 ? Open : Toggle;
            float hv = Hover(action, p < 4 ? p : index);
            if (hv > 0) {
                Rect(z, GroupRowHoverBounds(b, s), Alpha(pal_[33], .15f * hv), 15 * s);
                paint.layers[std::size_t(z)].draw.back().corners = p == 0 ? 3u : p == 5 ? 12u : 0u;
            }
            if (p < 4) {
                auto col = Mix(pal_[0], pal_[2], hv);
                float aw = TW(U"\uf105", 3);
                MarqueeText(z, {b.x, b.y + 3 * s, b.w - aw - 12 * s, F},
                            Label(WorldESPPageKeys[std::size_t(p)]), col, WorldESPHit{{}, Open, p}.Key(), b);
                Text(z, {b.x + b.w - 6 * s - aw, b.y + 3 * s, aw, F}, U"\uf105", col, 3);
                Hit(z, GroupRowHoverBounds(b, s), Open, p);
            } else
                DrawField(z, b, index, true);
        }
        std::size_t popStart = paint.layers.size();
        searchLayerStart = popStart;
        if (page >= 0) {
            const std::array<int, 4> masters{{BombEnabled, WeaponsEnabled, HostagesEnabled, GrenadesEnabled}};
            std::vector<int> extra;
            for (int i = 0; i < WorldESPFieldCount; ++i) {
                const auto& d = WorldESPSpecs[std::size_t(i)];
                if (d.page == page && d.owner < 0 && i != masters[std::size_t(page)] && i != BombDefused)
                    extra.push_back(i);
            }
            float pw = 265 * s, chipWidth = pw - 28 * s, x = 0;
            int lines = 1;
            for (int i = 0; i < 24; ++i)
                if (WorldESPItems[std::size_t(i)].page == page) {
                    float cw = std::min(chipWidth, TW(Label(WorldESPItems[std::size_t(i)].key)) + 12 * s);
                    if (x > 0 && x + cw > chipWidth) {
                        ++lines;
                        x = 0;
                    }
                    x += cw + 7 * s;
                }
            float extraHeight = extra.empty() ? 0.f : 14 * s + float(extra.size()) * R + 7 * s;
            float commonHeight =
                28 * s + float(page == 0 ? 2 : 1) * R + float(lines) * H + float(lines - 1) * 7 * s;
            float full = 20 * s + extraHeight + commonHeight;
            popup = PresetPopupFit(
                {anchor.x, anchor.y, pw, std::min(full, std::max(1.f, float(height) - 12 * s))}, width,
                height);
            maxScroll = std::max(0.f, full - popup.h);
            scroll = std::clamp(scroll, 0.f, maxScroll);
            Barrier();
            int pz = Layer(popup, true);
            SurfaceAt(pz, popup);
            float y = popup.y + 10 * s - scroll;
            if (!extra.empty()) {
                Box group{popup.x + 7 * s, y, pw - 14 * s, float(extra.size()) * R + 14 * s};
                Rect(pz, group, pal_[40], 15 * s);
                Rect(pz, group, pal_[11], 15 * s, s);
                y += 7 * s;
                for (int i : extra) {
                    DrawField(pz, {popup.x + 14 * s, y, pw - 28 * s, R}, i);
                    y += R;
                }
                y += 14 * s;
            }
            commonBox = {popup.x + 7 * s, y, pw - 14 * s, commonHeight};
            Rect(pz, commonBox, pal_[40], 15 * s);
            Rect(pz, commonBox, pal_[11], 15 * s, s);
            y += 7 * s;
            DrawField(pz, {popup.x + 14 * s, y, pw - 28 * s, R}, masters[std::size_t(page)]);
            y += R;
            if (page == 0) {
                DrawField(pz, {popup.x + 14 * s, y, pw - 28 * s, R}, BombDefused);
                y += R;
            }
            commonDivider = {popup.x + 14 * s, y + 7 * s, pw - 28 * s, s};
            Separator(pz, commonDivider.x, commonDivider.y, commonDivider.w);
            y += 14 * s;
            x = popup.x + 14 * s;
            for (int i = 0; i < 24; ++i) {
                const auto& d = WorldESPItems[std::size_t(i)];
                if (d.page != page)
                    continue;
                float cw = std::min(chipWidth, TW(Label(d.key)) + 12 * s);
                if (x > popup.x + 14 * s && x + cw > popup.x + pw - 14 * s) {
                    x = popup.x + 14 * s;
                    y += H + 7 * s;
                }
                Box b{x, y, cw, H};
                chips[std::size_t(i)] = PresetIntersect(b, popup);
                bool on = cfg.worldESP.itemEnabled[std::size_t(i)];
                float t = checks[100 + i].initialized ? checks[100 + i].value
                          : on                        ? 1.f
                                                      : 0.f,
                      hv = Hover(Chip, i);
                Rect(pz, b, pal_[40], 6 * s);
                Rect(pz, b, Mix(pal_[11], Alpha(pal_[31], .4f), t), 6 * s, s);
                Rect(pz, b, Alpha(pal_[33], .2f * hv), 6 * s);
                MarqueeText(pz, {b.x + 6 * s, b.y + 3 * s, b.w - 12 * s, F}, Label(d.key),
                            Mix(pal_[14], pal_[2], t), WorldESPHit{{}, Chip, i}.Key(), b);
                Hit(pz, b, Chip, i);
                x += cw + 7 * s;
            }
            ScrollMark(pz, popup, scroll, maxScroll, 0);
        }
        if (PickerActive()) {
            auto editorStart = paint.layers.size();
            picker.languages = languages;
            picker.SetMetrics(fonts, s);
            auto proxy = Proxy(cfg);
            picker.Sync(proxy);
            auto fields = EditorFields();
            const auto itemFields = item >= 0 ? WorldESPFields(item) : std::vector<ESPField>{};
            float ph = picker.Height(s), rowCount = float(fields.size() + itemFields.size());
            float full = ph + (rowCount > 0 ? 14 * s + rowCount * R : 0) + 10 * s;
            editorBox = PresetPopupFit({editorAnchor.x, editorAnchor.y, 265 * s,
                                        std::min(full, std::max(1.f, float(height) - 12 * s))},
                                       width, height);
            editorMax = std::max(0.f, full - editorBox.h);
            editorScroll = std::clamp(editorScroll, 0.f, editorMax);
            Barrier();
            int ez = Layer(editorBox, true);
            SurfaceAt(ez, editorBox);
            float y = editorBox.y - editorScroll;
            picker.Draw(paint, ez, fonts, proxy, {editorBox.x, y, 265 * s, ph});
            picker.box = PresetIntersect(picker.box, editorBox);
            y += ph;
            if (rowCount > 0) {
                Separator(ez, editorBox.x + 10 * s, y + 7 * s, 245 * s);
                y += 14 * s;
            }
            for (const auto& f : itemFields) {
                DrawItemField(ez, {editorBox.x + 10 * s, y, 245 * s, R}, f);
                y += R;
            }
            for (int i : fields) {
                if (i == TrajThrown) {
                    Separator(ez, editorBox.x + 10 * s, y, 245 * s);
                }
                DrawField(ez, {editorBox.x + 10 * s, y, 245 * s, R}, i);
                y += R;
            }
            ScrollMark(ez, editorBox, editorScroll, editorMax, 1);
            editorFade.FinishPaint(paint, editorStart);
            if (nested >= 0) {
                auto nestedStart = paint.layers.size();
                nestedPicker.languages = languages;
                nestedPicker.SetMetrics(fonts, s);
                auto child = Proxy(cfg, true);
                nestedPicker.Sync(child);
                float fullChild = nestedPicker.Height(s);
                nestedBox = PresetPopupFit({nestedAnchor.x, nestedAnchor.y, 265 * s,
                                            std::min(fullChild, std::max(1.f, float(height) - 12 * s))},
                                           width, height);
                nestedMax = std::max(0.f, fullChild - nestedBox.h);
                nestedScroll = std::clamp(nestedScroll, 0.f, nestedMax);
                Barrier();
                int nz = Layer(nestedBox, true);
                SurfaceAt(nz, nestedBox);
                nestedPicker.Draw(paint, nz, fonts, child,
                                  {nestedBox.x, nestedBox.y - nestedScroll, 265 * s, fullChild});
                nestedPicker.box = nestedBox;
                ScrollMark(nz, nestedBox, nestedScroll, nestedMax, 2);
                nestedPicker.DrawMenus(paint, fonts, child, width, height);
                nestedFade.FinishPaint(paint, nestedStart);
            } else if (choice < 0)
                picker.DrawMenus(paint, fonts, proxy, width, height);
        }
        if (choice >= 0) {
            auto choiceStart = paint.layers.size();
            auto opts = Options(choice);
            bool multi = IsMulti(choice);
            float mark = multi ? TW(U"\uf00c", 3) + 12 * s : 0, pw = 140 * s;
            for (const auto& k : opts)
                pw = std::max(pw, TW(Label(k)) + 38 * s + mark);
            pw = std::min(pw, std::max(1.f, float(width) - 12 * s));
            float full = 14 * s + float(opts.size()) * R;
            selectionBox = PresetPopupFit({choiceAnchor.x + choiceAnchor.w + 7 * s, choiceAnchor.y, pw,
                                           std::min(full, std::max(1.f, float(height) - 12 * s))},
                                          width, height);
            choiceMax = std::max(0.f, full - selectionBox.h);
            choiceScroll = std::clamp(choiceScroll, 0.f, choiceMax);
            Barrier();
            int cz = Layer(selectionBox, true);
            SurfaceAt(cz, selectionBox);
            int v = ChoiceValue(choice, cfg);
            for (std::size_t n = 0; n < opts.size(); ++n) {
                Box b{selectionBox.x + 7 * s, selectionBox.y + 7 * s + float(n) * R - choiceScroll,
                      selectionBox.w - 14 * s, R};
                float hv = Hover(Option, choice, int(n));
                bool selected = multi ? (v & (1 << n)) != 0 : v == int(n);
                Rect(cz, b, Alpha(pal_[33], .4f * hv), 15 * s / 1.6f);
                if (multi && selected)
                    Text(cz, {b.x + 12 * s, b.y + 7 * s, mark, F}, U"\uf00c", pal_[0], 3);
                Text(cz, {b.x + 12 * s + mark, b.y + 7 * s, b.w - 24 * s - mark, F}, Label(opts[n]),
                     Mix(pal_[14], pal_[2], selected ? 1.f : hv));
                Hit(cz, b, Option, choice, int(n));
            }
            ScrollMark(cz, selectionBox, choiceScroll, choiceMax, 3);
            choiceFade.FinishPaint(paint, choiceStart);
        }

        int over = HitAt(mouseX, mouseY);
        if (over >= 0 && choice < 0 && nested < 0 && editing < 0) {
            const auto& h = hits[std::size_t(over)];
            if (h.kind == Slider && WorldESPEnabled(h.index, cfg.worldESP)) {
                auto value = ValueLabel(h.index, cfg);
                float tw = TW(value);
                auto track = sliders[std::size_t(h.index)];
                auto tip = PresetPopupFit(
                    {track.x + (track.w - tw) * .5f - 7 * s, track.y - F - 14 * s, tw + 14 * s, F + 9 * s},
                    width, height);
                int tz = Layer(tip, true);
                Rect(tz, tip, pal_[8], 8 * s);
                Rect(tz, tip, pal_[11], 8 * s, s);
                Text(tz, {tip.x + 7 * s, tip.y + 4 * s, tw, F}, value, pal_[0]);
            }
        }
        auto tipKey = TooltipKey();
        if (!tipKey.empty() && hoverTime >= .3f && tooltipFade.value > .001f) {
            int n = HitAt(mouseX, mouseY);
            if (n >= 0) {
                const auto& h = hits[std::size_t(n)];
                auto layer =
                    WorldDescriptionTooltip(fonts, cfg, h.box, Label(WorldESPSpecs[std::size_t(h.index)].key),
                                            Label(tipKey), width, height);
                for (auto& d : layer.draw)
                    d.color.a *= tooltipFade.value;
                layer.opacity = tooltipFade.value;
                paint.layers.push_back(std::move(layer));
            }
        }
        if (Active()) {
            if (!PickerActive())
                editorFade.AppendClosing(paint);
            if (nested < 0)
                nestedFade.AppendClosing(paint);
            if (choice < 0)
                choiceFade.AppendClosing(paint);
            cached.assign(paint.layers.begin() + std::ptrdiff_t(popStart), paint.layers.end());
            AlphaFrom(popStart, popupFade.value);
        } else if (popupFade.value > .001f) {
            for (auto layer : cached) {
                layer.opacity *= popupFade.value;
                for (auto& d : layer.draw)
                    d.color.a *= popupFade.value;
                paint.layers.push_back(std::move(layer));
            }
        } else
            cached.clear();
        if (blocked) {
            hits.clear();
            picker.hits.clear();
            nestedPicker.hits.clear();
        }
        fonts_ = nullptr;
        cfg_ = nullptr;
    }
};
}
