#pragma once

#include "entity_identity.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <tuple>
namespace menu {
namespace world_view_index {
inline constexpr std::size_t Fov = 0, FovValue = 1, Aspect = 2, AspectScaling = 3, AspectValue = 4,
                             Landing = 5, ScopeFov = 6, ScopeX1 = 7, ScopeX2 = 8, InstantScope = 9,
                             ShowViewmodel = 10, ForceViewmodelFov = 11, ViewmodelFov = 12,
                             ViewmodelFovValue = 13, Position = 14, X = 15, Y = 16, Z = 17, Angles = 18,
                             Pitch = 19, Yaw = 20, Roll = 21, Modifiers = 22, Bobbing = 23, RotationSway = 24,
                             VelocitySway = 25, InAir = 26, LowerWeapon = 27, LadderBob = 28,
                             ThirdPerson = 29, Disablers = 30, Distance = 31, Overhead = 32, Spectating = 33,
                             Recoil = 34;
}

namespace world_view_recoil {
inline constexpr std::uint32_t NoShake = 1u, NoRecoil = 2u, NoViewmodelRecoil = 4u, NoBurstSway = 8u,
                               All = 15u;
}
struct ViewConfig {
    bool fov = false, viewmodelFov = false, viewmodelPosition = false;
    std::uint32_t fovValue = 90;
    float viewmodelFovValue = 60, x = 0, y = 0, z = 0;

    bool aspect = false, aspectVertical = false, landing = false, scopeFov = false, instantScope = false,
         showViewmodel = true, forceViewmodelFov = true, viewmodelAngles = false, modifiers = false;
    float aspectValue = 75, scopeX1 = 100, scopeX2 = 100, pitch = 0, yaw = 0, roll = 0, bobbing = 100,
          rotationSway = 100, velocitySway = 100, inAir = 100, lowerWeapon = 100, ladderBob = 100;
    std::uint32_t recoil = 0;
    std::uint32_t scopeOverlay = 0;
    bool WantsViewmodel() const {
        return viewmodelFov || viewmodelPosition;
    }

    bool ModifiersActive() const {
        return modifiers && (bobbing != 100.f || rotationSway != 100.f || velocitySway != 100.f ||
                             inAir != 100.f || lowerWeapon != 100.f || ladderBob != 100.f);
    }
    bool WantsCalcView() const {
        return fov || scopeFov || instantScope ||
               (recoil & (world_view_recoil::NoShake | world_view_recoil::NoRecoil)) != 0;
    }
    bool WantsAimPunch() const {
        return (recoil & (world_view_recoil::NoRecoil | world_view_recoil::NoViewmodelRecoil)) != 0;
    }
    bool WantsSway() const {
        return viewmodelAngles || ModifiersActive() ||
               (recoil & (world_view_recoil::NoViewmodelRecoil | world_view_recoil::NoBurstSway)) != 0;
    }
    bool WantsBurst() const {
        return (recoil & world_view_recoil::NoBurstSway) != 0;
    }

    bool WantsScopedViewmodel() const {
        return showViewmodel && scopeOverlay != 0;
    }
    bool WantsScopedViewmodelFov() const {
        return showViewmodel && forceViewmodelFov && scopeOverlay != 0;
    }
    bool WantsScopePass() const {
        return scopeOverlay == 1 || scopeOverlay == 2;
    }
    bool WantsCamera() const {
        return aspect || landing || WantsCalcView() || WantsAimPunch() || WantsSway() ||
               WantsScopedViewmodel() || WantsScopePass();
    }
    bool Any() const {
        return fov || WantsViewmodel() || WantsCamera();
    }
    bool operator==(const ViewConfig& o) const {
        return std::tie(fov, viewmodelFov, viewmodelPosition, fovValue, viewmodelFovValue, x, y, z, aspect,
                        aspectVertical, landing, scopeFov, instantScope, showViewmodel, forceViewmodelFov,
                        viewmodelAngles, modifiers, aspectValue, scopeX1, scopeX2, pitch, yaw, roll, bobbing,
                        rotationSway, velocitySway, inAir, lowerWeapon, ladderBob, recoil, scopeOverlay) ==
               std::tie(o.fov, o.viewmodelFov, o.viewmodelPosition, o.fovValue, o.viewmodelFovValue, o.x, o.y,
                        o.z, o.aspect, o.aspectVertical, o.landing, o.scopeFov, o.instantScope,
                        o.showViewmodel, o.forceViewmodelFov, o.viewmodelAngles, o.modifiers, o.aspectValue,
                        o.scopeX1, o.scopeX2, o.pitch, o.yaw, o.roll, o.bobbing, o.rotationSway,
                        o.velocitySway, o.inAir, o.lowerWeapon, o.ladderBob, o.recoil, o.scopeOverlay);
    }
};

inline float ViewSetting(const Settings& cfg, std::size_t index) {
    const auto& d = WorldViewSpecs[index];
    const float v = cfg.worldView.value[index];
    return std::isfinite(v) ? std::clamp(v, d.minimum, d.maximum) : d.initial;
}

static_assert(WorldViewSpecs[world_view_index::Recoil].minimum == 0.f &&
                  WorldViewSpecs[world_view_index::Recoil].maximum == float(world_view_recoil::All),
              "Visual Recoil spec must span exactly the four option bits");
inline ViewConfig ViewReadConfig(const Settings& cfg) {
    namespace wi = world_view_index;
    ViewConfig c;
    c.fov = ViewSetting(cfg, wi::Fov) != 0;
    c.fovValue = std::uint32_t(std::lround(ViewSetting(cfg, wi::FovValue)));
    c.viewmodelFov = ViewSetting(cfg, wi::ViewmodelFov) != 0;
    c.viewmodelFovValue = ViewSetting(cfg, wi::ViewmodelFovValue);
    c.viewmodelPosition = ViewSetting(cfg, wi::Position) != 0;
    c.x = ViewSetting(cfg, wi::X);
    c.y = ViewSetting(cfg, wi::Y);
    c.z = ViewSetting(cfg, wi::Z);

    c.aspect = ViewSetting(cfg, wi::Aspect) != 0;
    c.aspectVertical = ViewSetting(cfg, wi::AspectScaling) >= .5f;
    c.aspectValue = ViewSetting(cfg, wi::AspectValue);
    c.landing = ViewSetting(cfg, wi::Landing) != 0;
    c.scopeFov = ViewSetting(cfg, wi::ScopeFov) != 0;
    c.scopeX1 = ViewSetting(cfg, wi::ScopeX1);
    c.scopeX2 = ViewSetting(cfg, wi::ScopeX2);
    c.instantScope = ViewSetting(cfg, wi::InstantScope) != 0;
    c.showViewmodel = ViewSetting(cfg, wi::ShowViewmodel) != 0;
    c.forceViewmodelFov = ViewSetting(cfg, wi::ForceViewmodelFov) != 0;
    c.viewmodelAngles = ViewSetting(cfg, wi::Angles) != 0;
    c.pitch = ViewSetting(cfg, wi::Pitch);
    c.yaw = ViewSetting(cfg, wi::Yaw);
    c.roll = ViewSetting(cfg, wi::Roll);
    c.modifiers = ViewSetting(cfg, wi::Modifiers) != 0;
    c.bobbing = ViewSetting(cfg, wi::Bobbing);
    c.rotationSway = ViewSetting(cfg, wi::RotationSway);
    c.velocitySway = ViewSetting(cfg, wi::VelocitySway);
    c.inAir = ViewSetting(cfg, wi::InAir);
    c.lowerWeapon = ViewSetting(cfg, wi::LowerWeapon);
    c.ladderBob = ViewSetting(cfg, wi::LadderBob);
    c.recoil = std::uint32_t(std::lround(ViewSetting(cfg, wi::Recoil)));

    const float overlay = cfg.worldHud.value[1];
    c.scopeOverlay = std::isfinite(overlay) ? std::uint32_t(std::clamp(std::lround(overlay), 0l, 2l)) : 0u;
    return c;
}

inline bool ViewApplyViewmodel(const ViewConfig& c, float* offset, float* fov) {
    bool changed = false;
    if (c.viewmodelPosition && offset && std::isfinite(c.x) && std::isfinite(c.y) && std::isfinite(c.z)) {
        offset[0] = c.x;
        offset[1] = c.y;
        offset[2] = c.z;
        changed = true;
    }
    if (c.viewmodelFov && fov && std::isfinite(c.viewmodelFovValue)) {
        *fov = c.viewmodelFovValue;
        changed = true;
    }
    return changed;
}

class ViewSharedConfig {
    enum Bit : std::uint32_t {
        ViewmodelFov = 1u,
        ViewmodelPosition = 2u,
        Aspect = 4u,
        AspectVertical = 8u,
        Landing = 16u,
        ScopeFov = 32u,
        InstantScope = 64u,
        ShowViewmodel = 128u,
        ForceViewmodelFov = 256u,
        ViewmodelAngles = 512u,
        Modifiers = 1024u,
        Fov = 2048u
    };
    static constexpr std::size_t Floats = 16;
    std::atomic<std::uint32_t> flags_{0}, misc_{0}, fovValue_{90};
    std::array<std::atomic<float>, Floats> value_{};

public:
    void Store(const ViewConfig& c) {
        const float v[Floats] = {
            c.viewmodelFovValue, c.x,     c.y,           c.z,        c.aspectValue, c.scopeX1,
            c.scopeX2,           c.pitch, c.yaw,         c.roll,     c.bobbing,     c.rotationSway,
            c.velocitySway,      c.inAir, c.lowerWeapon, c.ladderBob};
        for (std::size_t i = 0; i < Floats; ++i)
            value_[i].store(v[i], std::memory_order_relaxed);
        misc_.store((c.recoil & 0xffu) | ((c.scopeOverlay & 0xffu) << 8), std::memory_order_relaxed);
        fovValue_.store(c.fovValue, std::memory_order_relaxed);
        flags_.store((c.viewmodelFov ? ViewmodelFov : 0u) | (c.viewmodelPosition ? ViewmodelPosition : 0u) |
                         (c.aspect ? Aspect : 0u) | (c.aspectVertical ? AspectVertical : 0u) |
                         (c.landing ? Landing : 0u) | (c.scopeFov ? ScopeFov : 0u) |
                         (c.instantScope ? InstantScope : 0u) | (c.showViewmodel ? ShowViewmodel : 0u) |
                         (c.forceViewmodelFov ? ForceViewmodelFov : 0u) |
                         (c.viewmodelAngles ? ViewmodelAngles : 0u) | (c.modifiers ? Modifiers : 0u) |
                         (c.fov ? Fov : 0u),
                     std::memory_order_release);
    }
    void Clear() {
        flags_.store(0, std::memory_order_release);
    }
    ViewConfig Load() const {
        ViewConfig c;
        const auto flags = flags_.load(std::memory_order_acquire);
        c.viewmodelFov = (flags & ViewmodelFov) != 0;
        c.viewmodelPosition = (flags & ViewmodelPosition) != 0;
        c.aspect = (flags & Aspect) != 0;
        c.aspectVertical = (flags & AspectVertical) != 0;
        c.landing = (flags & Landing) != 0;
        c.scopeFov = (flags & ScopeFov) != 0;
        c.instantScope = (flags & InstantScope) != 0;
        c.showViewmodel = (flags & ShowViewmodel) != 0;
        c.forceViewmodelFov = (flags & ForceViewmodelFov) != 0;
        c.viewmodelAngles = (flags & ViewmodelAngles) != 0;
        c.modifiers = (flags & Modifiers) != 0;
        c.fov = (flags & Fov) != 0;
        c.fovValue = fovValue_.load(std::memory_order_relaxed);
        const auto misc = misc_.load(std::memory_order_relaxed);
        c.recoil = misc & 0xffu;
        c.scopeOverlay = (misc >> 8) & 0xffu;
        float v[Floats];
        for (std::size_t i = 0; i < Floats; ++i)
            v[i] = value_[i].load(std::memory_order_relaxed);
        c.viewmodelFovValue = v[0];
        c.x = v[1];
        c.y = v[2];
        c.z = v[3];
        c.aspectValue = v[4];
        c.scopeX1 = v[5];
        c.scopeX2 = v[6];
        c.pitch = v[7];
        c.yaw = v[8];
        c.roll = v[9];
        c.bobbing = v[10];
        c.rotationSway = v[11];
        c.velocitySway = v[12];
        c.inAir = v[13];
        c.lowerWeapon = v[14];
        c.ladderBob = v[15];
        return c;
    }
};

struct ViewContext {
    std::uintptr_t entities = 0, localGlobal = 0;
    std::uint32_t localFlag = 0, pawnHandle = 0, desiredFov = 0, scoped = 0;

    std::uint32_t weaponServices = 0, activeWeapon = 0, zoomLevel = 0, viewPunch = 0, cameraFov = 0,
                  ownerHandle = 0, scene = 0, absOrigin = 0, aimPunchServices = 0;

    std::uint32_t life = 0, health = 0, weaponSubclass = 0, weaponType = 0;

    std::uint32_t itemDefinition = 0;
    bool valid = false;
};
struct ViewFrame {
    bool valid = false, scoped = false;
    std::uintptr_t controller = 0, pawn = 0, weapon = 0;
    std::uint32_t pawnHandle = 0, desired = 0, zoomLevel = 0;
    std::uint32_t weaponId = 0;
    bool alive = false;
    int weaponType = -1;
};

template <class R> ViewFrame ViewResolve(R&& read, const ViewContext& c, bool withWeapon = false) {
    ViewFrame f;
    if (!c.valid || !c.entities || !c.localFlag || !c.pawnHandle)
        return f;
    const auto local = WatermarkKdLocalController(read, c.entities, c.localGlobal, c.localFlag);
    if (!local.ok || !local.value)
        return f;
    f.valid = true;
    f.controller = local.value;
    std::uint32_t handle = 0;
    if (c.desiredFov) {
        std::uint32_t desired = 0;
        if (read(local.value + c.desiredFov, desired) && desired >= 1 && desired <= 170)
            f.desired = desired;
    }
    if (read(local.value + c.pawnHandle, handle)) {
        const auto pawn = WatermarkPawn(read, c.entities, handle);
        if (pawn && EntityHandleMatches(read, *pawn, handle)) {
            f.pawn = *pawn;
            f.pawnHandle = handle;
            std::uint8_t scoped = 0;
            f.scoped = c.scoped && read(*pawn + c.scoped, scoped) && scoped != 0;
            if (withWeapon && c.life && c.health) {
                std::uint8_t life = 255;
                int health = 0;
                f.alive = read(*pawn + c.life, life) && life == 0 && read(*pawn + c.health, health) &&
                          health > 0 && health <= 10000;
            }
            if ((f.scoped || withWeapon) && c.weaponServices && c.activeWeapon) {
                std::uintptr_t services = 0;
                std::uint32_t weaponHandle = 0;
                if (read(*pawn + c.weaponServices, services) && services &&
                    read(services + c.activeWeapon, weaponHandle) && weaponHandle != 0xffffffffu &&
                    weaponHandle != 0xfffffffeu) {
                    const auto weapon = WatermarkPawn(read, c.entities, weaponHandle);
                    if (weapon && EntityHandleMatches(read, *weapon, weaponHandle)) {
                        f.weapon = *weapon;
                        std::uint32_t zoom = 0;
                        if (c.zoomLevel && read(*weapon + c.zoomLevel, zoom) && zoom <= 2u)
                            f.zoomLevel = zoom;
                        if (c.weaponSubclass && c.weaponType) {
                            std::uintptr_t data = 0;
                            int type = 0;
                            if (read(*weapon + c.weaponSubclass + 8, data) && data &&
                                read(data + c.weaponType, type) && type >= 0 && type <= 32)
                                f.weaponType = type;
                        }
                        if (c.itemDefinition) {
                            std::uint16_t id = 0;
                            if (read(*weapon + c.itemDefinition, id) && id != 0 && id <= 0x2000)
                                f.weaponId = id;
                        }
                    }
                }
            }
        }
    }

    const auto again = WatermarkKdLocalController(read, c.entities, c.localGlobal, c.localFlag);
    if (!again.ok || again.value != local.value)
        return ViewFrame{};
    return f;
}

struct ViewFovState {
    std::uintptr_t controller = 0;
    std::uint32_t original = 0, applied = 0;
    bool owned = false, faulted = false;
    unsigned long long writes = 0, restores = 0, foreign = 0, failures = 0;
    unsigned consecutiveFailures = 0;
};
enum class ViewFovAction { None, Applied, Restored, Failed };
inline constexpr std::uint32_t ViewFovMin = 30, ViewFovMax = 135;
inline constexpr unsigned ViewFovFailureLimit = 8;
template <class R, class W>
ViewFovAction ViewFovStep(R&& read, W&& write, const ViewContext& c, const ViewFrame& f,
                          const ViewConfig& cfg, ViewFovState& s) {
    if (!c.valid) {
        s.owned = false;
        s.controller = 0;
        return ViewFovAction::None;
    }
    if (!c.desiredFov || !f.valid || !f.controller)
        return ViewFovAction::None;
    if (s.owned && s.controller != f.controller)
        s.owned = false;
    if (s.faulted)
        return ViewFovAction::None;
    const auto address = f.controller + c.desiredFov;
    std::uint32_t current = 0;
    if (!read(address, current))
        return ViewFovAction::None;
    const auto commit = [&](std::uint32_t value) {
        if (write(address, value)) {
            s.consecutiveFailures = 0;
            return true;
        }
        ++s.failures;
        if (++s.consecutiveFailures >= ViewFovFailureLimit)
            s.faulted = true;
        return false;
    };

    const bool want = cfg.fov && (!f.scoped || cfg.scopeFov);
    if (want) {
        const auto target = std::clamp(cfg.fovValue, ViewFovMin, ViewFovMax);
        if (!s.owned) {
            s.owned = true;
            s.controller = f.controller;
            s.original = current;
            s.applied = current;
        } else if (current != s.applied && current != target) {
            s.original = current;
            ++s.foreign;
        }
        if (current == target) {
            s.applied = target;
            return ViewFovAction::None;
        }
        if (!commit(target))
            return ViewFovAction::Failed;
        s.applied = target;
        ++s.writes;
        return ViewFovAction::Applied;
    }
    if (!s.owned)
        return ViewFovAction::None;
    s.owned = false;
    if (current != s.applied) {
        ++s.foreign;
        return ViewFovAction::None;
    }
    if (current == s.original)
        return ViewFovAction::None;
    if (!commit(s.original)) {
        s.owned = true;
        return ViewFovAction::Failed;
    }
    ++s.restores;
    return ViewFovAction::Restored;
}
}
