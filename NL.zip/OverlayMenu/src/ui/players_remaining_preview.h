#pragma once
#include "players_esp_preview.h"
#include "players_preview_icons.h"
#include "players_preview_hover.h"
namespace menu {

struct PlayersRemainingPreview {
    struct IconRaster {
        std::shared_ptr<const Canvas> source, image, shadow;
        std::vector<float> key;
        std::uint64_t stamp = 0, shadowStamp = 0;
    };
    std::array<IconRaster, LiveEquipmentIconCount> icons{};
    PlayersMainPreview readiness;
    inline static constexpr std::array<const char32_t*, 15> FlagSamples{
        {U"NA", U"Kit", U"Blind", U"Zoom", U"Reload", U"Immune", U"Slow", U"Vuln", U"C4", U"Vip", U"Defuse",
         U"Pin", U"$16000", U"Sim", U"10 Ms"}};
    static Color Ink(int i, const ESPItemValues& v) {

        return v.colorMode == 1 && (i == 6 || i == 12 || i == 20) ? v.colors[8] : v.colors[0];
    }
    const IconRaster* Raster(unsigned icon, float height, Color color, bool inverted) {
        auto source = GamePreviewIcons().Get(icon);
        if (!source || !std::isfinite(height) || height <= 0)
            return nullptr;
        const int h = std::clamp(int(std::round(height)), 1, 128),
                  w = std::clamp(int(std::round(float(source->width) * h / source->height)), 1, 512);
        std::vector<float> key{float(w), float(h), color.r, color.g, color.b, color.a, float(inverted)};
        auto& cache = icons.at(icon);
        if (cache.source == source && cache.key == key)
            return &cache;
        auto image = std::make_shared<Canvas>(w, h);
        auto shadow = std::make_shared<Canvas>(w, h);
        auto alpha = [&](int x, int y) {
            x = std::clamp(x, 0, source->width - 1);
            y = std::clamp(y, 0, source->height - 1);
            return source->rgba[4 * (std::size_t(y) * source->width + x) + 3] / 255.f;
        };
        for (int y = 0; y < h; ++y)
            for (int x = 0; x < w; ++x) {
                float sx = (float(x) + .5f) * source->width / w - .5f,
                      sy = (float(y) + .5f) * source->height / h - .5f;
                if (inverted)
                    sx = source->width - 1 - sx;
                int ix = int(std::floor(sx)), iy = int(std::floor(sy));
                float fx = sx - ix, fy = sy - iy;
                float top = alpha(ix, iy) * (1 - fx) + alpha(ix + 1, iy) * fx,
                      bottom = alpha(ix, iy + 1) * (1 - fx) + alpha(ix + 1, iy + 1) * fx;
                float coverage = top * (1 - fy) + bottom * fy;
                image->Blend(x, y, color, coverage);

                shadow->Blend(x, y, {0, 0, 0, .5f * std::clamp(color.a, 0.f, 1.f)}, coverage);
            }
        std::uint64_t hash = 14695981039346656037ull;
        for (auto c : image->rgba) {
            hash ^= c;
            hash *= 1099511628211ull;
        }
        std::uint64_t shadowHash = 14695981039346656037ull;
        for (auto c : shadow->rgba) {
            shadowHash ^= c;
            shadowHash *= 1099511628211ull;
        }
        cache.source = std::move(source);
        cache.image = std::move(image);
        cache.shadow = std::move(shadow);
        cache.key = std::move(key);
        cache.stamp = hash;
        cache.shadowStamp = shadowHash;
        return &cache;
    }
    template <class FontPicker, class CasePicker>
    void Draw(PresetLayer& layer, Fonts& fonts, Box child, Box bbox, float s, bool universal,
              const std::array<bool, 29>& enabled, const std::array<ESPItemValues, 29>& values,
              float bottomStack, FontPicker&& fontPicker, CasePicker&& casePicker,
              PlayersPreviewHover* hover = nullptr, int globalScale = 0) {
        auto stepFor = [&](int i) { return ESPSizeStep(values[std::size_t(i)], s, universal, globalScale); };
        float rightStack = 0;
        auto text = [&](int i, const std::u32string& sample, bool right) {
            const auto& v = values[std::size_t(i)];
            auto f = fontPicker(v.value[0], 1.f + .25f * stepFor(i), true);
            auto label = casePicker(sample, v.value[1]);
            auto size = fonts.ESPTextSize(f.face, f.px, label);
            float w = std::min(std::trunc(size.w + .95f), 400 * s);
            Box b = right ? PlayersMainPreview::Anchored(
                                child, {bbox.x + bbox.w + 2, bbox.y + rightStack, w, size.h}, s)
                          : PlayersMainPreview::DistanceBox(child, bbox, w, size.h, bottomStack, s);
            auto start = layer.draw.size();
            PlayersMainPreview::Text(layer, child, b, label, Ink(i, v), {f.face, f.px}, s);
            if (hover) {
                hover->Add(i, b);
                hover->Mark(layer, start, i);
            }
            (right ? rightStack : bottomStack) += size.h + 2;
        };
        for (int i = 6; i <= 20; ++i)
            if (enabled[std::size_t(i)])
                text(i, FlagSamples[std::size_t(i - 6)], true);
        if (enabled[27])
            text(27, U"65%", true);
        if (enabled[21])
            text(21, U"SSG 08", false);
        if (enabled[22]) {
            const float iconHeight = std::round(14.f * (1.f + stepFor(22) * .25f));
            const auto& v = values[22];
            const int selection = v.value[15];
            struct Row {
                std::vector<std::pair<unsigned, const IconRaster*>> items;
                float width = 0;
            };
            Row weapon, grenades;
            auto append = [&](Row& row, PreviewIcon id) {
                auto r = Raster(unsigned(id), iconHeight, v.colors[0], v.value[8] != 0);
                if (r) {
                    if (!row.items.empty())
                        row.width += 2;
                    row.items.push_back({unsigned(id), r});
                    row.width += r->image->width;
                }
            };
            if (selection & 1)
                append(weapon, PreviewIcon::SSG08);

            if (selection & 2)
                for (auto id :
                     {PreviewIcon::HE, PreviewIcon::Molotov, PreviewIcon::Smoke, PreviewIcon::Flash})
                    append(grenades, id);
            bool both = (selection & 3) == 3;
            float height =
                (selection & 1 ? iconHeight : 0) + (selection & 2 ? iconHeight : 0) + (both ? 3 * s : 0);
            auto b = PlayersMainPreview::DistanceBox(child, bbox, std::max(weapon.width, grenades.width),
                                                     height, bottomStack, s);
            auto start = layer.draw.size();
            auto rowDraw = [&](const Row& row, float y) {
                y = std::trunc(y);
                float x = b.x + (b.w - row.width) * .5f;
                for (const auto& entry : row.items) {
                    auto* r = entry.second;
                    PresetDraw d{{std::trunc(x), y, float(r->image->width), float(r->image->height)},
                                 {1, 1, 1, 1},
                                 0,
                                 0,
                                 15,
                                 {},
                                 false};
                    d.clipped = true;
                    d.clip = child;

                    auto shadow = d;
                    shadow.box.x += 1;
                    shadow.box.y += 1;
                    shadow.raster = r->shadow;
                    shadow.rasterStamp = r->shadowStamp;
                    layer.draw.push_back(std::move(shadow));
                    d.raster = r->image;
                    d.rasterStamp = r->stamp;
                    layer.draw.push_back(std::move(d));

                    if (entry.first == unsigned(PreviewIcon::Flash)) {
                        auto f = PlayersMainPreview::BarFont(2);
                        auto size = fonts.ESPTextSize(f.face, f.px, U"2");
                        PlayersMainPreview::Text(layer, child,
                                                 {std::trunc(x + r->image->width - size.w),
                                                  y + iconHeight - size.h, size.w, size.h},
                                                 U"2", {1, 1, 1, .8f}, f, s);
                    }
                    x += r->image->width + 2;
                }
            };

            if (selection & 1) {
                rowDraw(weapon, b.y);
            }
            if (selection & 2) {
                rowDraw(grenades, b.y + (both ? iconHeight + 3 * s : 0));
            }
            if (hover && (!weapon.items.empty() || !grenades.items.empty())) {
                hover->Add(22, b);
                hover->Mark(layer, start, 22);
            }
            if (selection)
                bottomStack += height + 2;
        }
        if (enabled[23]) {
            const auto& v = values[23];
            auto noText = v;
            noText.value[5] = 0;
            Box shifted = bbox;
            shifted.y += bottomStack;
            auto start = layer.draw.size();
            float step = readiness.Bar(layer, fonts, child, shifted, s, universal, false, noText,
                                       hover ? hover->Side(23) : -1, stepFor(23));
            auto f = PlayersMainPreview::BarFont((2 + stepFor(23)));
            auto label = v.value[5] == 0 ? U"" : v.value[5] == 2 ? U"50%" : U"50";
            auto size = fonts.ESPTextSize(f.face, f.px, label);
            auto bar = PlayersMainPreview::BarBox(child, shifted, (2 + stepFor(23)), false, s);
            bool vertical = hover && PlayersPreviewHover::Vertical(hover->Side(23));
            if (vertical) {
                bar.w = float((2 + stepFor(23)));
                bar.h = PlayersMainPreview::Round(bbox.h);
            }
            if (*label) {
                Box b =
                    vertical
                        ? Box{std::trunc(bar.x + bar.w - size.w * .5f - 1),
                              std::trunc(bar.y + bar.h * .5f - size.h * .5f), size.w, size.h}
                        : Box{std::trunc(bar.x + std::trunc(bar.w * .5f) - std::trunc(size.w + .95f) * .5f),
                              bar.y + std::trunc((bar.h - size.h) * .5f), size.w, size.h};
                PlayersMainPreview::Text(layer, child, b, label, {1, 1, 1, 1}, f, s);
            }
            if (!vertical && *label)
                step =
                    PlayersMainPreview::AmmoStack((2 + stepFor(23)), fonts.PixelHeight(f.face, f.px), true);
            if (hover)
                hover->Bar(23, layer, start, bar, step);
            bottomStack += PlayersMainPreview::AmmoStack((2 + stepFor(23)), fonts.PixelHeight(f.face, f.px),
                                                         *label != 0);
        }

        std::vector<const IconRaster*> equipment;
        std::vector<int> equipmentItems;
        float equipmentWidth = 0, equipmentHeight = 0;
        bool anyEquipment = false;
        for (int i = 24; i <= 26; ++i)
            if (enabled[std::size_t(i)]) {
                anyEquipment = true;
                const auto& v = values[std::size_t(i)];
                auto r = Raster(unsigned(i == 24   ? PreviewIcon::C4
                                         : i == 25 ? PreviewIcon::Defuser
                                                   : PreviewIcon::Taser),
                                14.f * (1.f + stepFor(i) * .25f), v.colors[0], v.value[8] != 0);
                if (r) {
                    equipmentHeight = std::max(equipmentHeight, float(r->image->height));
                    if (!equipment.empty())
                        equipmentWidth += 2;
                    equipment.push_back(r);
                    equipmentItems.push_back(i);
                    equipmentWidth += r->image->width;
                }
            }
        if (anyEquipment) {
            auto b =
                PlayersMainPreview::DistanceBox(child, bbox, equipmentWidth, equipmentHeight, bottomStack, s);
            float x = b.x;
            std::size_t ei = 0;
            for (auto* r : equipment) {
                int item = equipmentItems[ei++];
                if (hover)
                    hover->Add(item, {std::trunc(x), b.y, float(r->image->width), float(r->image->height)});
                PresetDraw d{{std::trunc(x), b.y, float(r->image->width), float(r->image->height)},
                             {1, 1, 1, 1},
                             0,
                             0,
                             15,
                             {},
                             false};
                d.raster = r->image;
                d.rasterStamp = r->stamp;
                d.clipped = true;
                d.clip = child;
                d.previewItem = item;
                layer.draw.push_back(std::move(d));
                x += r->image->width + 2;
            }
        }
    }
};
}
