#pragma once
#include "profile_popup.h"
#include "renderer_dx11.h"
namespace menu {
class ProfileGPUCache {
    struct Layer {
        std::unique_ptr<Canvas> glyphs;
        std::uint64_t revision = 0;
    };
    std::array<Layer, 15> layers;

public:
    void Reset() {
        for (auto& layer : layers) {
            layer.glyphs.reset();
            layer.revision = 0;
        }
    }
    void Draw(wm::RendererDX11& renderer, ID3D11Texture2D* scene, ID3D11RenderTargetView* target, int w,
              int h, Fonts& fonts, const Settings& cfg, const ProfileUI& ui, bool force = false) {
        if (!ui.open) {
            Reset();
            return;
        }
        for (int index : ui.Layers()) {
            if (ui.LayerOpacity(index) <= 0)
                continue;

            const bool about = index == 3 && ui.MenuOverlay();
            float radius = index == 3 && ui.modal == 4 ? ui.ChatRadius()
                                                       : (about        ? 16
                                                          : index == 6 ? 10
                                                                       : 15) *
                                                             cfg.scale;
            renderer.ClearClip();
            renderer.PrepareBackdrop(scene, ui.BlurSigma(cfg, index), cfg.blur);
            auto bounds = ui.LayerBox(cfg, index);
            int gw = std::max(1, int(std::ceil(bounds.w))), gh = std::max(1, int(std::ceil(bounds.h)));
            auto& layer = layers[std::size_t(index)];
            bool upload = force || !layer.glyphs || layer.glyphs->width != gw || layer.glyphs->height != gh ||
                          layer.revision != ui.revision;
            if (upload) {
                layer.glyphs = std::make_unique<Canvas>(gw, gh);
                ProfileText(*layer.glyphs, fonts, cfg, ui, -bounds.x, -bounds.y, index);
                for (int y = 0; y < gh; ++y)
                    for (int x = 0; x < gw; ++x)
                        if (BoxDistance({0, 0, bounds.w, bounds.h}, radius, x + .5f, y + .5f) > 0)
                            std::fill_n(layer.glyphs->rgba.data() + 4 * (std::size_t(y) * gw + x), 4, 0);
                layer.revision = ui.revision;
            }

            auto shadow = ui.LayerShadowColor(cfg, index);
            if (!about)
                renderer.DrawOriginalRect(target, bounds.x, bounds.y, bounds.w, bounds.h, {0, 0, 0, 0},
                                          radius, 0, 0, false, false, 18 * cfg.scale,
                                          {shadow.r, shadow.g, shadow.b, shadow.a});
            renderer.SetClip(bounds.x, bounds.y, bounds.w, bounds.h);
            for (auto shape : ProfileShapes(cfg, ui, index, &fonts)) {
                auto b = shape.box;
                if (shape.surface && cfg.blur) {
                    if (index == 3 && ui.modal == 4)
                        renderer.SetClip(bounds.x, bounds.y + ui.BackdropSkipTop(cfg, index), bounds.w,
                                         bounds.h - ui.BackdropSkipTop(cfg, index));
                    renderer.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {1, 1, 1, ui.LayerOpacity(index)},
                                              shape.radius, 1, 0, true, true);
                    renderer.SetClip(bounds.x, bounds.y, bounds.w, bounds.h);
                }
                auto clip = shape.contentClip ? ui.ContentClip(cfg, index) : bounds;
                renderer.SetClip(clip.x, clip.y, clip.w, clip.h);
                auto c = shape.color;
                renderer.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {c.r, c.g, c.b, c.a}, shape.radius,
                                          shape.surface ? 1.f : 0.f, shape.stroke, false, false, 0, {},
                                          shape.corners);
            }
            renderer.SetClip(bounds.x, bounds.y, bounds.w, bounds.h);
            renderer.DrawLayer(target, w, h, layer.glyphs->rgba.data(), gw, gh, bounds.x, bounds.y, float(gw),
                               0, index >= 8 ? 29 + index - 8 : 19 + index, upload);
            renderer.ClearClip();
        }
    }
};
}
