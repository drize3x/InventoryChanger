#pragma once
#include <cstdint>
#include <optional>
#include <cmath>
namespace menu {

inline float WatermarkKdRatio(std::int32_t kills, std::int32_t deaths) {
    return float(kills) / (deaths == 0 ? 1.f : float(deaths));
}
struct WatermarkKdOffsets {
    std::uint32_t services = 0, stats = 0, kills = 0, deaths = 0, localFlag = 0;
};

template <class Reader>
std::optional<float> WatermarkReadKd(Reader&& read, bool inGame, std::uintptr_t controller,
                                     const WatermarkKdOffsets& offsets) {
    if (!inGame)
        return {};
    if (!controller)
        return 0.f;
    std::uintptr_t services = 0, current = 0;
    if (!read(controller + offsets.services, services))
        return {};
    if (!services)
        return 0.f;
    std::int32_t kills = 0, deaths = 0;
    if (!read(services + offsets.stats + offsets.kills, kills) ||
        !read(services + offsets.stats + offsets.deaths, deaths))
        return {};
    if (!read(controller + offsets.services, current) || current != services)
        return {};
    return WatermarkKdRatio(kills, deaths);
}
}
