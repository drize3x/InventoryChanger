#pragma once

#include "rage_aim_core.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <optional>
#include <vector>
namespace menu::rage_aim {
struct ESPBoxRecord {
    std::uint32_t handle = 0;
    unsigned slot = 0;
    int tick = 0;
    std::uint64_t updated = 0;
    bool selected = false;
    Vec3 eye{}, point{};
    Volume volume{};
    float drawAlpha = 0;
};
inline std::optional<unsigned> ESPBoxSlot(int index) {
    if (index < 0 || index == 1)
        return {};
    if (index == 13)
        index = 16;
    else if (index == 14)
        index = 18;
    if (index >= 19)
        return {};
    return unsigned(index);
}
inline double ESPBoxAlpha(std::uint64_t now, std::uint64_t updated) {
    if (now < updated)
        return 0;
    double age = (now - updated) / 1000.;
    if (age <= .115625)
        return 1.;
    return std::clamp(1. - (age - .115625) / .1, 0., 1.);
}
struct ESPBoxTracker {
    std::vector<ESPBoxRecord> records;
    void Clear() {
        records.clear();
    }
    void Prune(std::uint64_t now) {
        records.erase(std::remove_if(records.begin(), records.end(),
                                     [&](const auto& e) { return now < e.updated || now - e.updated > 216; }),
                      records.end());
    }
    bool Observe(std::uint32_t handle, int index, int tick, std::uint64_t now, Vec3 eye, Vec3 point,
                 const Volume& volume) {
        auto slot = ESPBoxSlot(index);
        if (!slot || !handle || !volume.valid || (volume.shape != 0 && volume.shape != 2) || !Finite(eye) ||
            !Finite(point))
            return false;
        auto it = std::find_if(records.begin(), records.end(),
                               [&](const auto& x) { return x.handle == handle && x.slot == *slot; });
        if (it == records.end()) {
            if (records.size() >= 1024)
                return false;
            records.push_back({handle, *slot, tick, now, false, eye, point, volume});
            return true;
        }
        bool selected = it->tick == tick && it->selected;
        *it = {handle, *slot, tick, now, selected, eye, point, volume};
        return true;
    }
    void Select(const Plan& p, int tick) {
        if (!p.hasTarget || !Finite(p.angles))
            return;
        constexpr double pi = 3.14159265358979323846;
        for (auto& x : records) {
            if (x.handle != p.target || x.tick != tick)
                continue;
            double dx = x.point.x - x.eye.x, dy = x.point.y - x.eye.y, dz = x.point.z - x.eye.z;
            double xy = std::hypot(dx, dy);
            if (xy < 1e-9)
                continue;
            double pitch = -std::atan2(dz, xy) * 180 / pi, yaw = std::atan2(dy, dx) * 180 / pi;
            if (std::abs(pitch - p.angles.pitch) < 1e-6 &&
                std::abs(std::remainder(yaw - p.angles.yaw, 360.)) < 1e-6)
                x.selected = true;
        }
    }
};
inline Vec3 ESPBoxAdd(Vec3 a, Vec3 b) {
    return {a.x + b.x, a.y + b.y, a.z + b.z};
}
inline Vec3 ESPBoxSub(Vec3 a, Vec3 b) {
    return {a.x - b.x, a.y - b.y, a.z - b.z};
}
inline Vec3 ESPBoxMul(Vec3 a, double v) {
    return {a.x * v, a.y * v, a.z * v};
}
inline Vec3 ESPBoxCross(Vec3 a, Vec3 b) {
    return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}
inline std::optional<Vec3> ESPBoxUnit(Vec3 v) {
    double n = std::hypot(std::hypot(v.x, v.y), v.z);
    if (!std::isfinite(n) || n < 1e-9)
        return {};
    return ESPBoxMul(v, 1. / n);
}
inline std::optional<Vec3> ESPBoxWorld(Vec3 p, const Volume& v) {
    double n = std::sqrt(v.qx * v.qx + v.qy * v.qy + v.qz * v.qz + v.qw * v.qw);
    if (!std::isfinite(n) || n < 1e-9 || !Finite(p) || !Finite(v.origin))
        return {};
    Vec3 q{v.qx / n, v.qy / n, v.qz / n};
    double w = v.qw / n;
    auto t = ESPBoxMul(ESPBoxCross(q, p), 2.);
    auto out = ESPBoxAdd(v.origin, ESPBoxAdd(p, ESPBoxAdd(ESPBoxMul(t, w), ESPBoxCross(q, t))));
    return Finite(out) ? std::optional<Vec3>(out) : std::nullopt;
}

inline std::vector<Vec3> ESPBoxWorldPoints(const ESPBoxRecord& r) {
    const auto& v = r.volume;
    std::vector<Vec3> out;
    if (!v.valid || !Finite(v.lo) || !Finite(v.hi) || !std::isfinite(v.radius))
        return out;
    if (v.shape == 0) {
        if (v.lo.x > v.hi.x || v.lo.y > v.hi.y || v.lo.z > v.hi.z)
            return out;
        for (int n = 0; n < 8; ++n) {
            auto p =
                ESPBoxWorld({n & 1 ? v.hi.x : v.lo.x, n & 2 ? v.hi.y : v.lo.y, n & 4 ? v.hi.z : v.lo.z}, v);
            if (!p)
                return {};
            out.push_back(*p);
        }
        return out;
    }
    if (v.shape != 2 || v.radius <= 0 || v.radius > 100)
        return out;
    auto a = ESPBoxWorld(v.lo, v), b = ESPBoxWorld(v.hi, v);
    if (!a || !b)
        return {};
    auto axis = ESPBoxUnit(ESPBoxSub(*b, *a));
    if (!axis)
        axis = ESPBoxUnit(ESPBoxSub(*a, r.eye));
    if (!axis)
        return {};
    auto view = ESPBoxUnit(ESPBoxSub(ESPBoxMul(ESPBoxAdd(*a, *b), .5), r.eye));
    if (!view)
        return {};
    auto u = ESPBoxUnit(ESPBoxCross(*axis, *view));
    if (!u)
        u = ESPBoxUnit(ESPBoxCross(*axis, {0, 0, 1}));
    if (!u)
        u = ESPBoxUnit(ESPBoxCross(*axis, {0, 1, 0}));
    if (!u)
        return {};
    auto w = ESPBoxUnit(ESPBoxCross(*axis, *u));
    if (!w)
        return {};
    constexpr double pi = 3.14159265358979323846;
    double radius = v.radius * 1.25;
    for (auto end : {*a, *b})
        for (int i = 0; i < 8; ++i) {
            double ang = i * pi / 4.;
            out.push_back(ESPBoxAdd(
                end,
                ESPBoxMul(ESPBoxAdd(ESPBoxMul(*u, std::cos(ang)), ESPBoxMul(*w, std::sin(ang))), radius)));
        }
    return out;
}
}
