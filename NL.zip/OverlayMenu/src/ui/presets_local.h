#pragma once

#include "language_catalog.h"
#include "keybind_model.h"
#include <cstdio>
#include <random>
#include <set>
#include <functional>
namespace menu {
struct LocalPreset {
    std::string id, name = "Unnamed", author;
    std::int64_t created = 0, modified = 0, deleted = 0;
    std::map<std::string, std::string> values;
};
inline std::int64_t PresetNow() {
    return std::int64_t(std::time(nullptr));
}
inline std::string PresetID() {
    std::random_device rng;
    const char* h = "0123456789abcdef";
    std::string id;
    for (int i = 0; i < 16; ++i) {
        unsigned b = rng() & 255;
        id += h[b >> 4];
        id += h[b & 15];
    }
    return id;
}
inline std::string PresetObject(const std::map<std::string, std::string>& m) {
    std::string s = "{";
    for (auto& kv : m) {
        if (s.size() > 1)
            s += ",";
        s += LangJSON::Quote(kv.first) + ":" + LangJSON::Quote(kv.second);
    }
    return s + "}";
}
inline bool PresetSafeID(const std::string& id) {
    return id.size() == 32 && std::all_of(id.begin(), id.end(), [](char c) {
               return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f');
           });
}
inline bool PresetName(const std::u32string& name, bool empty = false) {
    if ((name.empty() && !empty) || name.size() > 128)
        return false;
    for (auto cp : name)
        if (cp < 32 || cp == 127 || cp == 0x2028 || cp == 0x2029 || (cp >= 0x202a && cp <= 0x202e) ||
            (cp >= 0x2066 && cp <= 0x2069))
            return false;
    return true;
}
inline std::int64_t PresetInteger(const std::string& s) {
    std::size_t n = 0;
    auto v = std::stoll(s, &n);
    if (n != s.size() || v < 0)
        throw std::runtime_error("Invalid preset timestamp");
    return v;
}
inline std::string Preset64(const std::string& s) {
    static const char* abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    unsigned value = 0;
    int bits = -6;
    for (unsigned char c : s) {
        value = (value << 8) | c;
        bits += 8;
        while (bits >= 0) {
            out += abc[(value >> bits) & 63];
            bits -= 6;
        }
    }
    if (bits > -6)
        out += abc[((value << 8) >> (bits + 8)) & 63];
    while (out.size() % 4)
        out += '=';
    return out;
}

inline constexpr std::size_t PresetCodeLimit = 1024 * 1024;
inline std::string PresetUn64(const std::string& s) {
    if (s.empty() || s.size() > PresetCodeLimit || s.size() % 4)
        throw std::runtime_error("Invalid preset code");
    const std::string abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    unsigned value = 0;
    int bits = -8;
    bool pad = false;
    for (char c : s) {
        if (c == '=') {
            pad = true;
            continue;
        }
        auto n = abc.find(c);
        if (pad || n == std::string::npos)
            throw std::runtime_error("Invalid preset code");
        value = (value << 6) | unsigned(n);
        bits += 6;
        if (bits >= 0) {
            out += char((value >> bits) & 255);
            bits -= 8;
        }
    }
    if (Preset64(out) != s)
        throw std::runtime_error("Invalid preset code padding");
    return out;
}
#include "rage_persistence.h"
#include "players_esp_layout_persistence.h"
#include "world_ambience_persistence.h"
#include "world_esp_persistence.h"
#include "inventory_persistence.h"
inline std::map<std::string, std::string> PresetCapture(const Settings& c) {
    std::map<std::string, std::string> values = {{"espScale", std::to_string(c.espScale)},
                                                 {"windowsScale", std::to_string(c.windowsScale)},
                                                 {"theme", std::to_string(c.theme)},
                                                 {"scale", std::to_string(c.scale)},
                                                 {"text", std::to_string(c.textPx)},
                                                 {"face", std::to_string(c.face)},
                                                 {"blur", c.blur ? "1" : "0"},
                                                 {"sigma", std::to_string(c.sigma)},
                                                 {"customAccent", c.customAccent ? "1" : "0"},
                                                 {"red", std::to_string(c.accent.r)},
                                                 {"green", std::to_string(c.accent.g)},
                                                 {"blue", std::to_string(c.accent.b)}};
    values["movement.bunnyhop"] = c.movementBunnyHop ? "1" : "0";
    values["movement.jumpbug.enabled"] = c.movementJumpBug ? "1" : "0";
    for (int i = 0; i < 4; ++i)
        values["movement.jumpbug.mode." + std::to_string(i)] =
            c.movementJumpBugModes[std::size_t(i)] ? "1" : "0";
    values["hitsound.enabled"] = c.hitSoundEnabled ? "1" : "0";
    for (int i = 0; i < 5; ++i) {
        values["hitsound.sound." + std::to_string(i)] = std::to_string(c.hitSoundForType[std::size_t(i)]);
        values["hitsound.volume." + std::to_string(i)] = std::to_string(c.hitSoundVolume[std::size_t(i)]);
    }
    values["movement.air.enabled"] = c.movementAirStrafe ? "1" : "0";
    for (int i = 0; i < 6; ++i)
        values["movement.air.mode." + std::to_string(i)] = c.movementAirModes[std::size_t(i)] ? "1" : "0";
    for (int i = 0; i < 4; ++i)
        values["movement.air.value." + std::to_string(i)] =
            std::to_string(c.movementAirValues[std::size_t(i)]);
    for (std::size_t i = 0; i < WorldViewSpecs.size(); ++i)
        values[std::string("world.view.") + WorldViewSpecs[i].id] = std::to_string(c.worldView.value[i]);
    for (std::size_t i = 0; i < WorldHudSpecs.size(); ++i)
        values[std::string("world.hud.") + WorldHudSpecs[i].id] = std::to_string(c.worldHud.value[i]);
    values["world.hud.scopeColorMode"] = std::to_string(c.worldHud.scopeColorMode);
    for (std::size_t i = 0; i < c.worldHud.colors.size(); ++i) {
        const auto& a = c.worldHud.colors[i];
        int j = 0;
        for (float n : {a.r, a.g, a.b, a.a})
            values["world.hud.color." + std::to_string(i) + "." + std::to_string(j++)] = std::to_string(n);
    }
    for (int i = 0; i < 3; ++i)
        values["world.hud.colorEnabled." + std::to_string(i)] =
            c.worldHud.penetrationColorEnabled[std::size_t(i)] ? "1" : "0";
    for (std::size_t i = 0; i < WorldMiscSpecs.size(); ++i)
        values[std::string("world.misc.") + WorldMiscSpecs[i].id] = std::to_string(c.worldMisc.value[i]);
    for (std::size_t i = 0; i < c.worldMisc.colors.size(); ++i) {
        const auto& a = c.worldMisc.colors[i];
        int j = 0;
        for (float n : {a.r, a.g, a.b, a.a})
            values["world.misc.color." + std::to_string(i) + "." + std::to_string(j++)] = std::to_string(n);
    }
    for (std::size_t i = 0; i < c.watermarkOrder.size(); ++i)
        values["watermark.order." + std::to_string(i)] = std::to_string(c.watermarkOrder[i]);
    for (std::size_t i = 0; i < PlayersSpecs.size(); ++i)
        values[std::string("players.") + PlayersSpecs[i].id] = std::to_string(c.players.value[i]);
    for (std::size_t i = 0; i < c.players.colors.size(); ++i) {
        int j = 0;
        for (float n :
             {c.players.colors[i].r, c.players.colors[i].g, c.players.colors[i].b, c.players.colors[i].a})
            values["players.color." + std::to_string(i) + "." + std::to_string(j++)] = std::to_string(n);
    }
    for (std::size_t team = 0; team < 2; ++team)
        for (std::size_t i = 0; i < PlayersESPItems.size(); ++i)
            values["players.esp." + std::to_string(team) + "." + PlayersESPItems[i].id] =
                c.players.espEnabled[team][i] ? "1" : "0";
    for (std::size_t t = 0; t < 2; ++t)
        for (int i = 0; i < 29; ++i) {
            const auto& a = c.players.espSettings[t][std::size_t(i)];
            auto k =
                "players.espSettings." + std::to_string(t) + "." + PlayersESPItems[std::size_t(i)].id + ".";
            values[k + "mode"] = std::to_string(a.colorMode);
            values[k + "sizeStep"] = std::to_string(a.sizeStep);
            for (const auto& f : ESPFields(i))
                values[k + "value." + std::to_string(f.slot)] = std::to_string(a.value[std::size_t(f.slot)]);
            for (std::size_t j = 0; j < a.colors.size(); ++j) {
                int c2 = 0;
                for (float v2 : {a.colors[j].r, a.colors[j].g, a.colors[j].b, a.colors[j].a})
                    values[k + "color." + std::to_string(j) + "." + std::to_string(c2++)] =
                        std::to_string(v2);
            }
        }
    values["players.universalScaling"] = c.players.universalScaling ? "1" : "0";
    PlayersESPLayoutCapture(c.players.espLayout, values);
    RageCapture(c.rage, values);
    AmbienceCapture(c.worldAmbience, values);
    WorldESPCapture(c.worldESP, values);
    InventoryCapture(c.inventory, values);
    KeybindCapture(c, values);
    return values;
}
inline void PresetApply(Settings& c, const std::map<std::string, std::string>& v) {
    Settings next = c;
    auto num = [&](const char* key, float lo, float hi) {
        auto it = v.find(key);
        if (it == v.end())
            throw std::runtime_error("Incomplete presentation preset");
        std::size_t used = 0;
        float n = std::stof(it->second, &used);
        if (used != it->second.size() || !std::isfinite(n) || n < lo || n > hi)
            throw std::runtime_error("Invalid presentation value");
        return n;
    };
    auto discrete = [&](const char* k, int hi) {
        float n = num(k, 0, float(hi));
        if (n != std::floor(n))
            throw std::runtime_error("Invalid discrete presentation value");
        return int(n);
    };
    if (v.count("espScale"))
        next.espScale = discrete("espScale", 5);
    if (v.count("windowsScale"))
        next.windowsScale = discrete("windowsScale", 5);
    next.movementBunnyHop = v.count("movement.bunnyhop") ? discrete("movement.bunnyhop", 1) != 0 : false;
    next.movementJumpBug =
        v.count("movement.jumpbug.enabled") ? discrete("movement.jumpbug.enabled", 1) != 0 : false;
    next.movementJumpBugModes = {{false, false, false, false}};
    for (int i = 0; i < 4; ++i) {
        auto k = "movement.jumpbug.mode." + std::to_string(i);
        if (v.count(k))
            next.movementJumpBugModes[std::size_t(i)] = discrete(k.c_str(), 1) != 0;
    }
    next.hitSoundEnabled = v.count("hitsound.enabled") ? discrete("hitsound.enabled", 1) != 0 : true;
    next.hitSoundForType = {{0, 0, 0, 0, 0}};
    next.hitSoundVolume = {{100, 100, 100, 100, 100}};
    for (int i = 0; i < 5; ++i) {
        auto a = "hitsound.sound." + std::to_string(i), b = "hitsound.volume." + std::to_string(i);
        if (v.count(a)) {
            float n = num(a.c_str(), -1, 9);
            if (n != std::floor(n))
                throw std::runtime_error("Invalid hitsound selection");
            next.hitSoundForType[std::size_t(i)] = int(n);
        }
        if (v.count(b))
            next.hitSoundVolume[std::size_t(i)] = discrete(b.c_str(), 300);
    }
    next.movementAirStrafe =
        v.count("movement.air.enabled") ? discrete("movement.air.enabled", 1) != 0 : false;
    next.movementAirModes = {{false, true, false, false, false, false}};
    next.movementAirValues = {{100, 65, 50, 45}};
    for (int i = 0; i < 6; ++i) {
        auto k = "movement.air.mode." + std::to_string(i);
        if (v.count(k))
            next.movementAirModes[std::size_t(i)] = discrete(k.c_str(), 1) != 0;
    }
    if (!next.movementAirModes[1] && !next.movementAirModes[2])
        next.movementAirModes[1] = true;
    for (int i = 0; i < 4; ++i) {
        auto k = "movement.air.value." + std::to_string(i);
        if (v.count(k))
            next.movementAirValues[std::size_t(i)] = discrete(k.c_str(), i == 2 ? 201 : i == 3 ? 90 : 100);
    }
    next.theme = discrete("theme", 1);
    next.scale = num("scale", .5f, 2);
    next.textPx = num("text", 10, 18);
    next.face = discrete("face", 2);
    next.blur = discrete("blur", 1) != 0;
    next.sigma = num("sigma", .1f, 6.5f);
    next.customAccent = discrete("customAccent", 1) != 0;
    next.accent = {num("red", 0, 1), num("green", 0, 1), num("blue", 0, 1), 1};
    next.worldView = WorldViewValues{};
    bool hasWorld = false;
    for (auto& kv : v)
        if (kv.first.rfind("world.view.", 0) == 0)
            hasWorld = true;
    if (hasWorld)
        for (std::size_t i = 0; i < WorldViewSpecs.size(); ++i) {
            const auto& d = WorldViewSpecs[i];
            std::string key = std::string("world.view.") + d.id;
            float n = num(key.c_str(), d.minimum, d.maximum);
            if (d.kind != WorldKind::Decimal && n != std::floor(n))
                throw std::runtime_error("Invalid World View value");
            next.worldView.Set(i, n);
        }
    next.worldHud = WorldHudValues{};
    bool hasHud = false;
    for (const auto& kv : v)
        if (kv.first.rfind("world.hud.", 0) == 0)
            hasHud = true;
    if (hasHud) {
        for (std::size_t i = 0; i < WorldHudSpecs.size(); ++i) {
            const auto& d = WorldHudSpecs[i];
            std::string key = std::string("world.hud.") + d.id;
            float n = num(key.c_str(), d.minimum, d.maximum);
            if (n != std::floor(n))
                throw std::runtime_error("Invalid World HUD integer");
            next.worldHud.Set(i, n);
        }
        next.worldHud.scopeColorMode = discrete("world.hud.scopeColorMode", 1);
        for (std::size_t i = 0; i < next.worldHud.colors.size(); ++i) {
            auto& a = next.worldHud.colors[i];
            int j = 0;
            for (float* n : {&a.r, &a.g, &a.b, &a.a}) {
                std::string k = "world.hud.color." + std::to_string(i) + "." + std::to_string(j++);
                *n = num(k.c_str(), 0, 1);
            }
        }
        for (int i = 0; i < 3; ++i) {
            std::string k = "world.hud.colorEnabled." + std::to_string(i);
            next.worldHud.penetrationColorEnabled[std::size_t(i)] = discrete(k.c_str(), 1) != 0;
        }
    }
    next.players = PlayersValues{};
    bool hasPlayers = false;
    for (const auto& kv : v)
        if (kv.first.rfind("players.", 0) == 0)
            hasPlayers = true;
    if (hasPlayers) {
        for (std::size_t i = 0; i < PlayersSpecs.size(); ++i) {
            const auto& d = PlayersSpecs[i];
            auto k = std::string("players.") + d.id;
            float n = num(k.c_str(), d.minimum, d.maximum);
            if (d.kind != WorldKind::Decimal && n != std::floor(n))
                throw std::runtime_error("Invalid Players integer");
            next.players.Set(i, n);
        }
        for (std::size_t i = 0; i < next.players.colors.size(); ++i) {
            auto& a = next.players.colors[i];
            int j = 0;
            for (float* n : {&a.r, &a.g, &a.b, &a.a}) {
                auto k = "players.color." + std::to_string(i) + "." + std::to_string(j++);
                *n = num(k.c_str(), 0, 1);
            }
        }
    }
    for (std::size_t team = 0; team < 2; ++team)
        for (std::size_t i = 0; i < PlayersESPItems.size(); ++i) {
            auto key = "players.esp." + std::to_string(team) + "." + PlayersESPItems[i].id;
            if (v.count(key))
                next.players.espEnabled[team][i] = discrete(key.c_str(), 1) != 0;
        }
    for (std::size_t t = 0; t < 2; ++t)
        for (int i = 0; i < 29; ++i) {
            auto& a = next.players.espSettings[t][std::size_t(i)];
            auto k =
                "players.espSettings." + std::to_string(t) + "." + PlayersESPItems[std::size_t(i)].id + ".";
            bool any = false;
            for (const auto& kv : v)
                if (kv.first.rfind(k, 0) == 0) {
                    any = true;
                    break;
                }
            if (!any)
                continue;
            if (v.count(k + "sizeStep"))
                a.sizeStep = discrete((k + "sizeStep").c_str(), 4);
            a.colorMode = discrete((k + "mode").c_str(), ESPColorModes(i) - 1);
            for (const auto& f : ESPFields(i)) {
                int hi = f.kind == ESPFieldKind::Multi    ? (1 << int(f.options.size())) - 1
                         : f.kind == ESPFieldKind::Choice ? int(f.options.size()) - 1
                                                          : 1;
                a.value[std::size_t(f.slot)] = discrete((k + "value." + std::to_string(f.slot)).c_str(), hi);
            }
            for (std::size_t j = 0; j < a.colors.size(); ++j) {
                int c2 = 0;
                for (float* v2 : {&a.colors[j].r, &a.colors[j].g, &a.colors[j].b, &a.colors[j].a})
                    *v2 = num((k + "color." + std::to_string(j) + "." + std::to_string(c2++)).c_str(), 0, 1);
            }
        }
    if (v.count("players.universalScaling"))
        next.players.universalScaling = discrete("players.universalScaling", 1) != 0;
    next.worldMisc = WorldMiscValues{};
    bool hasMisc = false;
    for (const auto& kv : v)
        if (kv.first.rfind("world.misc.", 0) == 0)
            hasMisc = true;
    if (hasMisc) {
        for (std::size_t i = 0; i < WorldMiscSpecs.size(); ++i) {
            const auto& d = WorldMiscSpecs[i];
            auto k = std::string("world.misc.") + d.id;
            if (i >= 69 && v.find(k) == v.end())
                continue;
            float n = num(k.c_str(), d.minimum, d.maximum);
            if (d.kind != WorldKind::Decimal && n != std::floor(n))
                throw std::runtime_error("Invalid World Misc integer");
            next.worldMisc.Set(i, n);
        }
        for (std::size_t i = 0; i < next.worldMisc.colors.size(); ++i) {
            if (i >= 16) {
                int present = 0;
                for (int j = 0; j < 4; ++j)
                    present +=
                        v.count("world.misc.color." + std::to_string(i) + "." + std::to_string(j)) ? 1 : 0;
                if (present == 0)
                    continue;
                if (present != 4)
                    throw std::runtime_error("Incomplete Windows color");
            }
            auto& a = next.worldMisc.colors[i];
            int j = 0;
            for (float* n : {&a.r, &a.g, &a.b, &a.a}) {
                auto k = "world.misc.color." + std::to_string(i) + "." + std::to_string(j++);
                *n = num(k.c_str(), 0, 1);
            }
        }
    }
    next.watermarkOrder = Settings{}.watermarkOrder;
    bool hasOrder = false;
    for (const auto& kv : v)
        if (kv.first.rfind("watermark.order.", 0) == 0)
            hasOrder = true;
    if (hasOrder) {
        std::array<bool, 23> seen{};
        for (std::size_t i = 0; i < next.watermarkOrder.size(); ++i) {
            auto key = "watermark.order." + std::to_string(i);
            int n = discrete(key.c_str(), 22);
            if (seen[std::size_t(n)])
                throw std::runtime_error("Duplicate Watermark item");
            seen[std::size_t(n)] = true;
            next.watermarkOrder[i] = n;
        }
    }
    PlayersESPLayoutRead(next.players.espLayout, v);
    WorldESPRead(next.worldESP, v);
    AmbienceRead(next.worldAmbience, v);
    RageRead(next.rage, v);
    InventoryRead(next.inventory, v);
    KeybindRead(next, v);
    c = next;
}
struct PresetStore {
    std::filesystem::path root;
    std::vector<LocalPreset> items;
    std::string selected;
    bool automatic = false;
    int sort = 0;
    std::set<std::string> consumed;
    std::vector<std::string> warnings;
    const LocalPreset* Find(const std::string& id) const {
        for (auto& p : items)
            if (p.id == id)
                return &p;
        return nullptr;
    }
    LocalPreset* Find(const std::string& id) {
        for (auto& p : items)
            if (p.id == id)
                return &p;
        return nullptr;
    }
    std::string Serialize() const {
        std::string s = "{\"meta\":" + PresetObject({{"version", "1"},
                                                     {"selected", selected},
                                                     {"automatic", automatic ? "1" : "0"},
                                                     {"sort", std::to_string(sort)}});
        std::map<std::string, std::string> ledger;
        for (auto& c : consumed)
            ledger[c] = "1";
        s += ",\"consumed\":" + PresetObject(ledger);
        for (auto& p : items) {
            auto m = p.values;
            m["id"] = p.id;
            m["name"] = p.name;
            m["author"] = p.author;
            m["created"] = std::to_string(p.created);
            m["modified"] = std::to_string(p.modified);
            m["deleted"] = std::to_string(p.deleted);
            s += "," + LangJSON::Quote(p.id) + ":" + PresetObject(m);
        }
        return s + "}\n";
    }
    void Flush() const {
        if (root.empty())
            return;
        auto payload = Serialize();
        if (payload.size() > 4 * 1024 * 1024)
            throw std::runtime_error("Local preset file exceeds 4 MiB");
        std::filesystem::create_directories(root);
        auto path = root / "presets.json", temp = root / "presets.json.tmp",
             backup = root / "presets.json.bak";
        {
            std::ofstream f(temp, std::ios::binary | std::ios::trunc);
            if (!f)
                throw std::runtime_error("Cannot write local presets");
            f << payload;
            f.close();
            if (!f)
                throw std::runtime_error("Cannot finish writing local presets");
        }
        std::error_code ec;
        std::filesystem::remove(backup, ec);
        bool old = std::filesystem::exists(path);
        if (old)
            std::filesystem::rename(path, backup);
        try {
            std::filesystem::rename(temp, path);
        } catch (...) {
            if (old)
                std::filesystem::rename(backup, path, ec);
            throw;
        }
        std::filesystem::remove(backup, ec);
    }
    void Change(const std::function<void()>& fn) {
        auto oldItems = items;
        auto oldSelected = selected;
        auto oldConsumed = consumed;
        bool oldAuto = automatic;
        int oldSort = sort;
        try {
            fn();
            Flush();
        } catch (...) {
            items = std::move(oldItems);
            selected = std::move(oldSelected);
            consumed = std::move(oldConsumed);
            automatic = oldAuto;
            sort = oldSort;
            throw;
        }
    }
    void Load(const std::filesystem::path& dir, std::int64_t now = PresetNow()) {
        PresetStore next;
        next.Read(dir, now);
        *this = std::move(next);
    }
    void Read(const std::filesystem::path& dir, std::int64_t now) {
        root = dir;
        items.clear();
        selected.clear();
        consumed.clear();
        warnings.clear();
        auto path = root / "presets.json", backup = root / "presets.json.bak";
        if (!std::filesystem::exists(path) && std::filesystem::exists(backup))
            std::filesystem::rename(backup, path);
        if (!std::filesystem::exists(path))
            return;
        if (std::filesystem::file_size(path) > 4 * 1024 * 1024)
            throw std::runtime_error("Local preset file is too large");
        std::ifstream f(path, std::ios::binary);
        if (!f)
            throw std::runtime_error("Cannot read local presets");
        auto json = LangJSON(std::string((std::istreambuf_iterator<char>(f)), {})).Parse();
        auto meta = json.at("meta");
        if (meta.at("version") != "1")
            throw std::runtime_error("Unsupported preset version");
        selected = meta.at("selected");
        automatic = meta.at("automatic") == "1";
        sort = std::clamp(int(PresetInteger(meta.at("sort"))), 0, 2);
        for (auto& kv : json) {
            if (kv.first == "meta")
                continue;
            if (kv.first == "consumed") {
                for (auto& c : kv.second) {
                    if (!PresetSafeID(c.first) || consumed.size() >= 4096)
                        throw std::runtime_error("Invalid one-time ledger");
                    consumed.insert(c.first);
                }
                continue;
            }
            if (items.size() >= 256 || !PresetSafeID(kv.first))
                throw std::runtime_error("Invalid preset catalog");
            auto m = kv.second;
            LocalPreset p;
            p.id = m.at("id");
            if (p.id != kv.first)
                throw std::runtime_error("Preset ID mismatch");
            p.name = m.at("name");
            p.author = m.at("author");
            p.created = PresetInteger(m.at("created"));
            p.modified = PresetInteger(m.at("modified"));
            p.deleted = PresetInteger(m.at("deleted"));
            if (!PresetName(DecodeUTF8(p.name)) || !PresetName(DecodeUTF8(p.author), true))
                throw std::runtime_error("Invalid preset name");
            for (auto key : {"id", "name", "author", "created", "modified", "deleted"})
                m.erase(key);
            Settings checked;
            PresetApply(checked, m);
            p.values = std::move(m);
            items.push_back(std::move(p));
        }
        if (!Find(selected) || Find(selected)->deleted)
            selected.clear();
        Purge(now);
    }

    void Autoload(Settings& cfg) {
        const LocalPreset* active = Find(selected);
        if (!active || active->deleted) {
            const LocalPreset* newest = nullptr;
            for (const auto& p : items)
                if (!p.deleted && (!newest || p.modified > newest->modified ||
                                   (p.modified == newest->modified && p.id < newest->id)))
                    newest = &p;
            if (newest) {
                auto id = newest->id;
                Change([&] { selected = id; });
            } else if (items.size() < 256)
                Create(cfg);
            else {
                warnings.push_back("No active preset; restore or erase an item from Recently Deleted");
                return;
            }
            active = Find(selected);
        }
        if (active)
            PresetApply(cfg, active->values);
    }
    void Purge(std::int64_t now) {
        bool expired = std::any_of(items.begin(), items.end(), [&](const LocalPreset& p) {
            return p.deleted && now >= p.deleted && now - p.deleted >= 7 * 86400;
        });
        if (expired)
            Change([&] {
                items.erase(std::remove_if(items.begin(), items.end(),
                                           [&](const LocalPreset& p) {
                                               return p.deleted && now >= p.deleted &&
                                                      now - p.deleted >= 7 * 86400;
                                           }),
                            items.end());
            });
    }
    std::string Create(const Settings& cfg, std::string name = "Unnamed", std::int64_t now = PresetNow()) {
        if (items.size() >= 256)
            throw std::runtime_error("Local preset limit: 256");
        auto id = PresetID();
        if (!PresetName(DecodeUTF8(name)))
            throw std::runtime_error("Invalid preset name");
        Change([&] {
            LocalPreset p;
            p.id = id;
            p.name = name;
            auto author = cfg.userName;
            author.resize(std::min<std::size_t>(author.size(), 128));
            if (!PresetName(author, true))
                throw std::runtime_error("Invalid author name");
            p.author = EncodeUTF8(author);
            p.created = p.modified = now;
            p.values = PresetCapture(cfg);
            items.push_back(p);
            selected = id;
        });
        return id;
    }
    void Save(const std::string& id, const Settings& cfg, std::int64_t now = PresetNow()) {
        Change([&] {
            auto p = Find(id);
            if (!p || p->deleted)
                throw std::runtime_error("Preset not found");
            p->values = PresetCapture(cfg);
            p->modified = now;
        });
    }
    void LoadPreset(const std::string& id, Settings& cfg) {
        auto p = Find(id);
        if (!p || p->deleted)
            throw std::runtime_error("Preset not found");
        Settings next = cfg;
        PresetApply(next, p->values);
        Change([&] { selected = id; });
        cfg = next;
    }
    void Rename(const std::string& id, const std::u32string& name) {
        if (!PresetName(name))
            throw std::runtime_error("Name must contain 1-128 characters");
        Change([&] {
            auto p = Find(id);
            if (!p || p->deleted)
                throw std::runtime_error("Preset not found");
            p->name = EncodeUTF8(name);
            p->modified = PresetNow();
        });
    }
    std::string Duplicate(const std::string& id) {
        auto p = Find(id);
        if (!p || p->deleted || items.size() >= 256)
            throw std::runtime_error("Cannot duplicate preset");
        auto next = *p;
        next.id = PresetID();
        auto name = DecodeUTF8(next.name);
        name.resize(std::min<std::size_t>(name.size(), 121));
        next.name = EncodeUTF8(name) + " (copy)";
        next.created = next.modified = PresetNow();
        Change([&] { items.push_back(next); });
        return next.id;
    }
    void Remove(const std::string& id, std::int64_t now = PresetNow()) {
        Change([&] {
            auto p = Find(id);
            if (!p)
                throw std::runtime_error("Preset not found");
            p->deleted = now;
            if (selected == id)
                selected.clear();
        });
    }
    void Restore(const std::string& id) {
        Change([&] {
            auto p = Find(id);
            if (!p || !p->deleted)
                throw std::runtime_error("Deleted preset not found");
            p->deleted = 0;
        });
    }
    void Erase(const std::string& id) {
        Change([&] {
            items.erase(std::remove_if(items.begin(), items.end(),
                                       [&](const LocalPreset& p) { return p.id == id && p.deleted; }),
                        items.end());
        });
    }
    std::string Share(const std::string& id, bool once) const {
        auto p = Find(id);
        if (!p || p->deleted)
            throw std::runtime_error("Preset not found");
        auto meta = std::map<std::string, std::string>{
            {"version", "1"}, {"name", p->name}, {"author", p->author}, {"token", once ? PresetID() : ""}};
        return "MSCFG1:" +
               Preset64("{\"meta\":" + PresetObject(meta) + ",\"values\":" + PresetObject(p->values) + "}");
    }
    std::string Import(const std::string& code, std::int64_t now = PresetNow()) {
        if (code.substr(0, 7) != "MSCFG1:" || code.size() > PresetCodeLimit + 7 || items.size() >= 256)
            throw std::runtime_error("Invalid local preset code");
        auto json = LangJSON(PresetUn64(code.substr(7))).Parse();
        auto meta = json.at("meta");
        if (meta.at("version") != "1")
            throw std::runtime_error("Unsupported local preset code");
        auto token = meta.at("token");
        if (!token.empty() && (!PresetSafeID(token) || consumed.count(token) || consumed.size() >= 4096))
            throw std::runtime_error("One-time code already used or invalid");
        LocalPreset p;
        p.id = PresetID();
        p.name = meta.at("name");
        p.author = meta.at("author");
        if (!PresetName(DecodeUTF8(p.name)) || !PresetName(DecodeUTF8(p.author), true))
            throw std::runtime_error("Invalid shared preset name");
        p.created = p.modified = now;
        p.values = json.at("values");
        Settings checked;
        PresetApply(checked, p.values);
        Change([&] {
            items.push_back(p);
            if (!token.empty())
                consumed.insert(token);
        });
        return p.id;
    }
};
}
