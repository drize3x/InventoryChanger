#pragma once
#include "menu_core.h"
#include "presets_motion.h"
#include "watermark_fps.h"
#include "watermark_hud.h"
#include "watermark_kd.h"
#include "watermark_speed_delay.h"
#include "watermark_network.h"
#include "watermark_network_all.h"
#include <optional>
#include <sstream>
#include <iomanip>
#include <locale>
namespace menu {

inline std::size_t WatermarkSetting(const char* id) {
    for (std::size_t i = 0; i < WorldMiscSpecs.size(); ++i)
        if (std::string(WorldMiscSpecs[i].id) == id)
            return i;
    throw std::logic_error("Unknown watermark setting");
}
inline float WatermarkValue(const Settings& c, const char* id) {
    return c.worldMisc.value[WatermarkSetting(id)];
}
inline bool WatermarkEnabled(const Settings& c) {
    return WatermarkValue(c, "watermark") != 0;
}
struct WatermarkItemSpec {
    const char* id;
    char32_t glyph;
};
inline constexpr std::array<WatermarkItemSpec, 23> WatermarkItems{{{"logo", 0xf641},
                                                                   {"username", 0xf007},
                                                                   {"preset", 0xf0c2},
                                                                   {"framerate", 0xe473},
                                                                   {"time", 0xe29e},
                                                                   {"memoryload", 0xf538},
                                                                   {"cpuload", 0xf2db},
                                                                   {"cpufrequency", 0xf643},
                                                                   {"cpucores", 0xe0e3},
                                                                   {"gpuload", 0xe089},
                                                                   {"kd", 0xf646},
                                                                   {"speed", 0xf625},
                                                                   {"latency", 0xf690},
                                                                   {"loss", 0xe2cf},
                                                                   {"var", 0xf233},
                                                                   {"connectivityissues", 0xe1cc},
                                                                   {"packetloss", 0xe097},
                                                                   {"latepackets", 0xf017},
                                                                   {"networkjitter", 0xf83e},
                                                                   {"inputtiming", 0xf11c},
                                                                   {"predictionlead", 0xf04e},
                                                                   {"networktraffic", 0xe099},
                                                                   {"serveraddress", 0xf601}}};
struct WatermarkData {

    std::array<std::u32string, 23> text{};
    std::array<float, 23> severity{};
    std::optional<WatermarkDelivery> delivery, packetLoss, latePackets, jitter, networkTraffic;
    std::optional<WatermarkInputTiming> inputTiming;
    std::optional<float> predictionLeadMs;
    std::optional<std::string> serverAddress;
    std::optional<WatermarkServerStability> serverStability;
    std::optional<WatermarkConnectionStatus> connectionStatus;
    std::vector<float> cpuCores;
    std::optional<float> fps, onePercentLow, fpsStability, memoryUsedGB, memoryTotalGB, cpuLoad, maxCpuLoad,
        cpuGHz, maxCpuGHz, gpuLoad, kdRatio, speed, networkLatencyMs, delayMs;
};
inline std::u32string WatermarkNumber(float n, int precision = 0) {
    std::ostringstream s;
    s.imbue(std::locale::classic());
    s << std::fixed << std::setprecision(precision) << n;
    return ASCII(s.str());
}

inline bool WatermarkValid(const std::optional<float>& n) {
    return n && std::isfinite(*n) && *n >= 0;
}
inline int WatermarkPercent(float n) {
    return int(std::floor(std::clamp(n, 0.f, 100.f) + .5f));
}
inline std::u32string WatermarkPercentText(float n) {
    return ASCII(std::to_string(WatermarkPercent(n)));
}
inline std::u32string WatermarkSignedNumber(float n, int precision) {
    std::ostringstream stream;
    stream.imbue(std::locale::classic());
    stream << std::showpos << std::fixed << std::setprecision(precision) << (n == 0 ? 0.f : n);
    return ASCII(stream.str());
}
inline std::u32string WatermarkFlowLabel(WatermarkDelivery pair, const std::u32string& suffix,
                                         bool integer = false) {
    char32_t arrow = pair.first == pair.second ? U'\uf07d' : pair.first > pair.second ? U'\uf062' : U'\uf063';
    float value = std::max(pair.first, pair.second);
    if (integer) {
        auto n = WatermarkNativeSignedRound(value);
        if (!n)
            return {};
        value = *n;
    }
    return WatermarkNumber(value, integer ? 0 : 1) + suffix + std::u32string(1, arrow);
}
inline bool WatermarkPairValid(const std::optional<WatermarkDelivery>& pair) {
    return pair && std::isfinite(pair->first) && std::isfinite(pair->second);
}
inline std::u32string WatermarkTrafficText(float value) {
    value = WatermarkNetworkNonnegative(value);
    return value >= 1000000.f ? WatermarkNumber(value / 1000000.f, 1) + U"M"
           : value >= 1000.f  ? WatermarkNumber(value / 1000.f) + U"K"
                              : WatermarkNumber(value) + U"B";
}
inline std::u32string WatermarkFormat(const Settings& c, const WatermarkData& d, int item) {
    if (!d.text[std::size_t(item)].empty())
        return d.text[std::size_t(item)];
    switch (item) {
    case 1:
        return c.userName;
    case 3: {
        auto valid = [](const std::optional<float>& v) { return v && std::isfinite(*v) && *v >= 0; };
        int mode = std::clamp(int(WatermarkValue(c, "watermark_fpsstatistics")), 0, 2);
        if (mode == 1)
            return valid(d.onePercentLow) ? WatermarkNumber(*d.onePercentLow) + U" FPS (1%L)"
                                          : std::u32string{};
        if (!valid(d.fps) || (mode == 2 && !valid(d.onePercentLow)))
            return {};
        auto text = WatermarkNumber(*d.fps) + U" FPS";
        if (mode == 2)
            text += U" " + WatermarkNumber(*d.onePercentLow) + U" (1%L)";
        return text;
    }

    case 5: {
        if (!WatermarkValid(d.memoryUsedGB) || !WatermarkValid(d.memoryTotalGB) || *d.memoryTotalGB <= 0 ||
            *d.memoryUsedGB > *d.memoryTotalGB)
            return {};
        int mode = std::clamp(int(WatermarkValue(c, "watermark_ramdetails")), 0, 2);
        auto pct = WatermarkPercentText(float(double(*d.memoryUsedGB) / double(*d.memoryTotalGB)) * 100);
        auto fraction =
            WatermarkNumber(*d.memoryUsedGB, 1) + U" / " + WatermarkNumber(*d.memoryTotalGB, 1) + U" GB";
        return mode == 0 ? pct + U"% MEM" : mode == 1 ? fraction : fraction + U" (" + pct + U"%)";
    }
    case 6: {
        if (!WatermarkValid(d.cpuLoad))
            return {};
        auto text = WatermarkPercentText(*d.cpuLoad) + U"%";
        if (WatermarkValue(c, "watermark_max_cpu_load") && WatermarkValid(d.maxCpuLoad))
            text += U" / \uf062 " + WatermarkPercentText(*d.maxCpuLoad) + U"%";
        return text + U" CPU";
    }
    case 7: {
        if (!WatermarkValid(d.cpuGHz))
            return {};
        auto text = WatermarkNumber(std::clamp(*d.cpuGHz, 0.f, 9.99f), 2);
        if (WatermarkValue(c, "watermark_max_cpu_frequency") && WatermarkValid(d.maxCpuGHz))
            text += U" / \uf062 " + WatermarkNumber(std::clamp(*d.maxCpuGHz, 0.f, 9.99f), 2);
        return text + U" GHz";
    }
    case 9:
        return WatermarkValid(d.gpuLoad) ? WatermarkPercentText(*d.gpuLoad) + U"% GPU" : std::u32string{};
    case 10: {
        if (!d.kdRatio || !std::isfinite(*d.kdRatio))
            return {};

        float value = std::floor(std::max(0.f, *d.kdRatio) * 100.f) / 100.f;
        auto text = WatermarkNumber(value, 2);
        while (!text.empty() && text.back() == U'0')
            text.pop_back();
        if (!text.empty() && text.back() == U'.')
            text.pop_back();
        return text + U" KD";
    }
    case 11:
        return WatermarkValid(d.speed) ? WatermarkNumber(*d.speed) + U" SPEED" : std::u32string{};
    case 12: {
        if (!WatermarkValid(d.delayMs) || *d.delayMs < 5.f)
            return {};
        auto value = WatermarkDelayInteger(*d.delayMs);
        return value ? ASCII(std::to_string(*value)) + U" MS" : std::u32string{};
    }
    case 13: {
        if (!d.delivery || !std::isfinite(d.delivery->first) || !std::isfinite(d.delivery->second))
            return {};
        auto v = *d.delivery;
        char32_t arrow = v.first == v.second ? U'\uf07d' : v.first > v.second ? U'\uf062' : U'\uf063';
        return WatermarkNumber(std::max(v.first, v.second), 1) + U"% DLV " + std::u32string(1, arrow);
    }
    case 14: {
        if (!d.serverStability)
            return {};
        auto v = WatermarkDelayInteger(d.serverStability->ms);
        if (!v)
            return {};
        return (d.serverStability->stalled ? U"VAR " : U"VAR ±") + ASCII(std::to_string(*v)) + U" MS";
    }
    case 15: {
        if (!d.connectionStatus || !std::isfinite(d.connectionStatus->seconds) ||
            d.connectionStatus->seconds < 1)
            return {};
        return d.connectionStatus->timedOut
                   ? U"TIMED OUT"
                   : U"TIMING OUT " + WatermarkNumber(d.connectionStatus->seconds, 1) + U"S";
    }
    case 16:
        return WatermarkPairValid(d.packetLoss) ? WatermarkFlowLabel(*d.packetLoss, U"% LOSS ")
                                                : std::u32string{};
    case 17:
        return WatermarkPairValid(d.latePackets) ? WatermarkFlowLabel(*d.latePackets, U"% LATE ")
                                                 : std::u32string{};
    case 18:
        return WatermarkPairValid(d.jitter) ? WatermarkFlowLabel(*d.jitter, U"MS JITTER ", true)
                                            : std::u32string{};
    case 19: {
        if (!d.inputTiming)
            return {};
        auto n = WatermarkNativeSignedRound(d.inputTiming->receivedMs - d.inputTiming->targetMs);
        return n ? U"RCV " + WatermarkSignedNumber(*n, 0) + U" MS" : std::u32string{};
    }
    case 20: {
        if (!d.predictionLeadMs)
            return {};
        auto ms = WatermarkNativeSignedRound(*d.predictionLeadMs),
             tenth = WatermarkNativeSignedRound((*d.predictionLeadMs / 15.625f) * 10.f);
        if (!ms || !tenth)
            return {};
        auto ticks = WatermarkSignedNumber(*tenth / 10.f, 1);
        int units = std::clamp(int(WatermarkValue(c, "watermark_predictionunits")), 0, 2);
        return units == 1 ? U"PRED " + ticks + U" T"
                          : U"PRED " + WatermarkSignedNumber(*ms, 0) + U" MS" +
                                (units == 2 ? U" (" + ticks + U"T)" : U"");
    }
    case 21:
        return WatermarkPairValid(d.networkTraffic)
                   ? U"\uf063 " + WatermarkTrafficText(d.networkTraffic->second) + U" / \uf062 " +
                         WatermarkTrafficText(d.networkTraffic->first)
                   : std::u32string{};
    case 22:
        return d.serverAddress ? ASCII(*d.serverAddress) : std::u32string{};
    default:
        return {};
    }
}
struct WatermarkFpsColors {
    Color text, icon;
};
inline WatermarkFpsColors WatermarkFpsColorTargets(const Settings& c, const WatermarkData& d) {
    auto pal = CurrentPalette(c);
    WatermarkFpsColors colors{WatermarkPaletteRGBA8(pal[4]), WatermarkPaletteRGBA8(pal[31])};
    if (!d.fps || !std::isfinite(*d.fps) || *d.fps < 0)
        return colors;
    float fps = std::floor(*d.fps + .5f);
    float stability =
        d.fpsStability && std::isfinite(*d.fpsStability) ? std::clamp(*d.fpsStability, 0.f, 1.f) : 1.f;
    bool instability = WatermarkValue(c, "watermark_fps_instability") != 0;

    if (fps < 33 || (instability && stability <= .35f))
        colors.text = colors.icon = c.worldMisc.colors[17];
    else {
        if (fps < 65)
            colors.text = c.worldMisc.colors[16];
        if (fps < 65 || (instability && stability <= .65f))
            colors.icon = c.worldMisc.colors[16];
    }
    return colors;
}

inline WatermarkFpsColors WatermarkTelemetryColorTargets(const Settings& c, const WatermarkData& d,
                                                         int item) {
    auto pal = CurrentPalette(c);
    WatermarkFpsColors out{WatermarkPaletteRGBA8(pal[4]), WatermarkPaletteRGBA8(pal[31])};
    int pct = -1;
    if (item == 5 && WatermarkValid(d.memoryUsedGB) && WatermarkValid(d.memoryTotalGB) &&
        *d.memoryTotalGB > 0)
        pct = WatermarkPercent(float(double(*d.memoryUsedGB) / double(*d.memoryTotalGB)) * 100);
    else if (item == 6 && WatermarkValid(d.cpuLoad))
        pct = WatermarkPercent(*d.cpuLoad);
    else if (item == 9 && WatermarkValid(d.gpuLoad))
        pct = WatermarkPercent(*d.gpuLoad);
    int level = item == 5                ? (pct >= 86   ? 2
                                            : pct >= 61 ? 1
                                                        : 0)
                : item == 6              ? (pct >= 91   ? 2
                                            : pct >= 71 ? 1
                                                        : 0)
                : item == 9 && pct >= 91 ? 2
                                         : 0;
    if (item == 12 && WatermarkValid(d.delayMs) && *d.delayMs >= 100.f)
        level = 2;
    if (item == 13 && d.delivery) {
        float v = std::max(d.delivery->first, d.delivery->second);
        level = v >= 2.f ? 2 : v > .01f ? 1 : 0;
    }
    if (item == 14 && d.serverStability)
        level = d.serverStability->stalled || d.serverStability->ms >= 7.8125f ? 2 : 1;
    if (item == 15 && d.connectionStatus && d.connectionStatus->seconds >= 1)
        level = d.connectionStatus->timedOut ? 2 : 1;
    if (item == 16 && WatermarkPairValid(d.packetLoss)) {
        float v = std::max(d.packetLoss->first, d.packetLoss->second);
        level = v >= 2.f ? 2 : v > .01f ? 1 : 0;
    }
    if (item == 17 && WatermarkPairValid(d.latePackets)) {
        float v = std::max(d.latePackets->first, d.latePackets->second);
        level = v >= 2.f ? 2 : v > .01f ? 1 : 0;
    }
    if (item == 18 && WatermarkPairValid(d.jitter))
        level = std::max(d.jitter->first, d.jitter->second) >= 20.f ? 2 : 0;
    if (item == 19 && d.inputTiming)
        level = d.inputTiming->receivedMs < 0                         ? 2
                : d.inputTiming->targetMs > d.inputTiming->receivedMs ? 1
                                                                      : 0;
    if (item == 20 && d.predictionLeadMs && *d.predictionLeadMs >= 100.f)
        level = 2;
    if (level)
        out.text = out.icon = c.worldMisc.colors[std::size_t(15 + level)];
    return out;
}

inline bool WatermarkInlineIcon(char32_t cp) {
    return cp == U'\uf062' || cp == U'\uf063' || cp == U'\uf07d';
}
inline float WatermarkTextWidth(Fonts& f, int face, float px, const std::u32string& text) {
    if (std::none_of(text.begin(), text.end(), WatermarkInlineIcon))
        return f.NativeTextSize(face, px, text).w;
    float width = 0;
    for (auto cp : text)
        width += std::ceil(f.Get(WatermarkInlineIcon(cp) ? 3 : face, px, cp).advance);
    return width;
}
inline void WatermarkText(Canvas& canvas, Fonts& f, int face, float px, const std::u32string& text, float x,
                          float y, Color color, float ox, float oy, const Box* clip) {
    std::size_t start = 0;
    for (std::size_t at = 0; at <= text.size(); ++at) {
        if (at < text.size() && !WatermarkInlineIcon(text[at]))
            continue;
        auto run = text.substr(start, at - start);
        if (!run.empty()) {
            f.NativeText(canvas, face, px, run, x, y, color, ox, oy, clip);
            x += f.NativeTextSize(face, px, run).w;
        }
        if (at < text.size()) {
            f.NativeMergedIcon(canvas, px, text[at], x, y, color, ox, oy, clip, face);
            x += std::ceil(f.Get(3, px, text[at]).advance);
        }
        start = at + 1;
    }
}

inline float WatermarkCoreWidth(std::size_t count, float scale) {
    return count ? float(count) * std::trunc(2 * scale) + float(count - 1) * std::trunc(scale) : 0.f;
}
struct WatermarkCoreBar {
    Box box;
    float split = 0;
    bool high = false;
};
inline WatermarkCoreBar WatermarkCoreGeometry(Box cell, float fontHeight, float scale, int density,
                                              std::size_t index, float load) {
    float padding = (density == 0 ? 2.f : 3.f) * scale;
    float cursorY = cell.y + (cell.h - fontHeight) * .5f - scale;
    float bottom = cursorY + fontHeight - padding, fullHeight = std::max(1.f, fontHeight - 2 * padding);
    load = std::isfinite(load) ? std::clamp(load, 0.f, 1.f) : 0.f;
    float height = std::clamp(fullHeight * load, std::min(fullHeight, 2.f), fullHeight);
    float top = std::trunc(bottom - height + .5f);
    return {{cell.x + float(index) * (std::trunc(2 * scale) + std::trunc(scale)), top, std::trunc(2 * scale),
             bottom - top},
            std::trunc(top + .5f * height + .5f),
            load > .5f};
}

inline void WatermarkCoreGradient(Canvas& c, Box box, Color top, Color bottom, const Box& clip) {
    if (box.w <= 0 || box.h <= 0)
        return;
    for (int y = std::max(0, int(std::ceil(box.y - .5f)));
         y < std::min(c.height, int(std::ceil(box.y + box.h - .5f))); ++y)
        for (int x = std::max(0, int(std::ceil(box.x - .5f)));
             x < std::min(c.width, int(std::ceil(box.x + box.w - .5f))); ++x)
            if (clip.Contains(x + .5f, y + .5f))
                c.Blend(x, y, Mix(top, bottom, std::clamp((y + .5f - box.y) / box.h, 0.f, 1.f)));
}

struct WatermarkWidth {
    float value = 0, target = 0, from = 0;
    double changed = 0;
    bool initialized = false;
    float Resolve(float next, double now, bool reset = false) {
        if (!initialized || reset || next > value) {
            value = target = from = next;
            changed = now;
            initialized = true;
            return value;
        }
        if (next != target) {
            from = value;
            target = next;
            changed = now;
        }
        float t = std::clamp(float((now - changed - .025) / .2), 0.f, 1.f);
        value = from + (target - from) * (1 - (1 - t) * (1 - t) * (1 - t));
        return value;
    }
};

struct WatermarkPosition {
    float value = 0, target = 0, from = 0;
    double changed = 0;
    bool initialized = false;
    void Snap(float x, double now) {
        value = target = from = x;
        changed = now;
        initialized = true;
    }
    float Resolve(float x, double now) {
        if (!initialized) {
            Snap(x, now);
            return value;
        }

        if (x != target) {
            from = value;
            target = x;
            changed = now;
            return value;
        }
        float t = std::clamp(float((now - changed) / .2), 0.f, 1.f);
        value = from + (target - from) * (1 - (1 - t) * (1 - t) * (1 - t));
        return value;
    }
};
inline std::array<int, 23> WatermarkOrder(const Settings& c) {
    std::array<bool, 23> seen{};
    for (int n : c.watermarkOrder) {
        if (n < 0 || n >= 23 || seen[std::size_t(n)])
            return Settings{}.watermarkOrder;
        seen[std::size_t(n)] = true;
    }
    return c.watermarkOrder;
}
struct WatermarkUI {
    WatermarkData data;
    PresetMotion opacity;
    std::array<PresetMotion, 23> items;
    std::array<std::u32string, 23> displayedText{};
    std::vector<float> displayedCores;
    std::vector<PresetMotion> coreMotion;
    std::array<WatermarkColorMotion, 5> telemetryTextColor{}, telemetryIconColor{};
    std::array<WatermarkColorMotion, 8> networkTextColor{}, networkIconColor{};
    mutable std::array<WatermarkWidth, 23> widths{};
    mutable std::array<WatermarkPosition, 23> positions{};
    std::array<PresetMotion, 23> interactionMotion{};
    int hoverItem = -1;
    int heldItem = -1;
    float pointerX = 0, grabOffset = 0;
    bool positionMotion = false;
    std::int64_t lastHeldMilliseconds = -1000;
    std::int64_t MotionMilliseconds() const {
        return std::int64_t(std::floor(seconds * 1000.));
    }
    void BeginPositionMotion() {
        positionMotion = true;
        lastHeldMilliseconds = MotionMilliseconds();
    }

    bool PositionMotionActive() const {
        return positionMotion && (heldItem >= 0 || MotionMilliseconds() - lastHeldMilliseconds <= 999);
    }
    mutable float measuredScale = 0;
    mutable int measuredDensity = -1;
    double seconds = 0;
    WatermarkDelayMotion delayMotion;
    WatermarkColorMotion delayTextColor, delayIconColor;
    WatermarkFrameStats frameStats;
    WatermarkColorMotion fpsTextColor, fpsIconColor;
    void SyncInteractionTargets() {
        for (std::size_t i = 0; i < interactionMotion.size(); ++i)
            interactionMotion[i].Tick(heldItem == int(i) ? 1.f : hoverItem == int(i) ? .5f : 0.f, 0, .2f);
    }
    void Frame(std::int64_t now = WatermarkFrameNanoseconds()) {
        if (frameStats.Sample(now)) {
            data.fps = float(frameStats.fps);
            data.onePercentLow = float(frameStats.onePercentLow);
            data.fpsStability = frameStats.stability;
        }
    }
    void Tick(float dt, const Settings& c, bool ready = true) {
        if (!std::isfinite(dt) || dt < 0)
            dt = 0;

        seconds += dt;
        for (std::size_t i = 0; i < interactionMotion.size(); ++i)
            interactionMotion[i].Tick(ready ? (heldItem == int(i)    ? 1.f
                                               : hoverItem == int(i) ? .5f
                                                                     : 0.f)
                                            : 0.f,
                                      dt, .2f);
        if (heldItem >= 0)
            lastHeldMilliseconds = MotionMilliseconds();
        data.delayMs = delayMotion.Tick(data.networkLatencyMs, dt);
        auto delayColors = WatermarkTelemetryColorTargets(c, data, 12);
        delayTextColor.Tick(delayColors.text, dt);
        delayIconColor.Tick(delayColors.icon, dt);
        auto colors = WatermarkFpsColorTargets(c, data);
        fpsTextColor.Tick(colors.text, dt);
        fpsIconColor.Tick(colors.icon, dt);
        for (int item = 5; item <= 9; ++item) {
            auto target = WatermarkTelemetryColorTargets(c, data, item);
            auto n = std::size_t(item - 5);
            telemetryTextColor[n].Tick(target.text, dt);
            telemetryIconColor[n].Tick(target.icon, dt);
        }
        for (int item = 13; item <= 20; ++item) {
            auto target = WatermarkTelemetryColorTargets(c, data, item);
            auto n = std::size_t(item - 13);
            networkTextColor[n].Tick(target.text, dt);
            networkIconColor[n].Tick(target.icon, dt);
        }
        if (!data.cpuCores.empty()) {
            auto old = coreMotion.size();
            coreMotion.resize(data.cpuCores.size());
            for (std::size_t i = old; i < coreMotion.size(); ++i)
                coreMotion[i].Snap(0);
            displayedCores.resize(coreMotion.size());
            for (std::size_t i = 0; i < coreMotion.size(); ++i) {
                float load = std::isfinite(data.cpuCores[i]) ? std::clamp(data.cpuCores[i], 0.f, 1.f) : 0;
                coreMotion[i].Tick(load, dt, .2f);
                displayedCores[i] = coreMotion[i].value;
            }
        }
        bool any =
            WatermarkValue(c, "watermark_avatar") && c.avatar && c.avatar->width > 0 && c.avatar->height > 0;
        for (std::size_t i = 0; i < items.size(); ++i) {
            auto id = std::string("watermark_item_") + WatermarkItems[i].id;
            auto text = WatermarkFormat(c, data, int(i));
            bool present = i == 0 || (i == 8 ? !data.cpuCores.empty() : !text.empty());
            bool selected = WatermarkValue(c, id.c_str()) && present;
            any |= selected;
            if (present)
                displayedText[i] = std::move(text);

            items[i].Tick(ready && selected ? 1.f : 0.f, dt);
        }
        opacity.Tick(ready && WatermarkEnabled(c) && any ? 1.f : 0.f, dt);
    }
    void HostClock() {
        auto now = std::time(nullptr);
        std::tm tm{};
#ifdef _WIN32
        if (localtime_s(&tm, &now) != 0)
            return;
#else
        if (!localtime_r(&now, &tm))
            return;
#endif
        char s[16]{};
        if (std::strftime(s, sizeof(s), "%H:%M:%S", &tm))
            data.text[4] = ASCII(s);
    }
};
struct WatermarkCell {
    int item = 0;
    Box box{};
    float opacity = 0;
    std::u32string text;
    Color color{}, iconColor{};
    float inkOffset = 0, slotX = 0;
};
struct WatermarkPaint {
    Box panel{}, avatarBox{};
    float opacity = 0, radius = 0, shadow = 0, px = 12, scale = 1, fontHeight = 0;
    int font = 1;
    Color fill{}, shadowColor{}, separator{};
    std::vector<WatermarkCell> cells;
};

inline Box WatermarkItemButtonBox(const WatermarkPaint& p, const WatermarkCell& cell) {
    float y = cell.box.y + (cell.box.h - p.fontHeight) * .5f - p.scale;
    return {cell.box.x - 4 * p.scale, y - p.scale, cell.box.w + 8 * p.scale, p.fontHeight + 2 * p.scale};
}
inline Color WatermarkItemHoverColor(const Settings& cfg, float motion, float opacity) {
    auto fill = CurrentPalette(cfg)[33];
    fill.a *= .5f * motion * opacity;
    return WatermarkPaletteRGBA8(fill);
}
// Keep native HUD movement tied to the same opacity and window DPI as the
// rendered watermark, not menu visibility/scale. Do not gate on the enabled
// checkbox here: the HUD returns smoothly while the watermark fades out.
inline float WatermarkGameHudOffset(const Settings& cfg, const WatermarkUI& ui,
                                    int viewportHeight, bool ready) {
    if (!ready)
        return 0;
    const float position = WatermarkValue(cfg, "watermark_position");
    const float density = WatermarkValue(cfg, "watermark_density");
    if (!std::isfinite(position) || position < 0 || position > 5 ||
        !std::isfinite(density) || density < 0 || density > 2)
        return 0;
    return WatermarkHudOffset(int(position), int(density), ScreenWindowScale(cfg),
                              ui.opacity.value, viewportHeight);
}

inline WatermarkPaint MeasureWatermark(Fonts& f, const Settings& c, const WatermarkUI& ui, int width,
                                       int height) {
    WatermarkPaint p;
    float s = ScreenWindowScale(c);
    p.scale = s;
    p.opacity = std::clamp(ui.opacity.value, 0.f, 1.f);
    if (p.opacity <= 0 || width <= 0 || height <= 0)
        return p;
    int density = std::clamp(int(WatermarkValue(c, "watermark_density")), 0, 2);
    constexpr float heights[] = {26, 29, 34}, padding[] = {9, 10, 12}, fontSizes[] = {10, 12, 13};
    p.font = density;
    p.px = fontSizes[density] * s;
    p.fontHeight = f.PixelHeight(p.font, p.px);
    float H = heights[density] * s, pad = padding[density] * s, x = pad, lastAdvance = 0;
    bool metricsChanged = ui.measuredScale != s || ui.measuredDensity != density;
    ui.measuredScale = s;
    ui.measuredDensity = density;
    auto pal = CurrentPalette(c);
    p.fill = pal[45];
    p.fill.a *= p.opacity;
    p.shadowColor = pal[38];
    p.shadowColor.a *= p.opacity;
    p.separator = pal[45];
    p.separator.a = 0;
    p.shadow = 18 * s;
    for (int ordered : WatermarkOrder(c)) {
        std::size_t i = std::size_t(ordered);
        float a = std::clamp(ui.items[i].value, 0.f, 1.f);
        if (a <= 0) {
            ui.widths[i].initialized = false;
            continue;
        }
        auto text = ui.displayedText[i];
        if (i != 0 && i != 8 && text.empty())
            continue;
        if (i == 8 && ui.displayedCores.empty())
            continue;
        float raw = i == 0   ? std::round(H * .37f * 79.3f / 46.7f)
                    : i == 8 ? WatermarkCoreWidth(ui.displayedCores.size(), s)
                             : WatermarkTextWidth(f, p.font, p.px, text) +
                                   std::ceil(f.Get(3, p.px, WatermarkItems[i].glyph).advance) + 5 * s;
        float w = ui.widths[i].Resolve(raw, ui.seconds, metricsChanged);
        Color color = pal[4], iconColor = pal[31];
        float severity = std::isfinite(ui.data.severity[i]) ? std::clamp(ui.data.severity[i], 0.f, 1.f) : 0;
        if (i == 3) {
            auto targets = WatermarkFpsColorTargets(c, ui.data);
            color = ui.fpsTextColor.initialized ? ui.fpsTextColor.value : targets.text;
            iconColor = ui.fpsIconColor.initialized ? ui.fpsIconColor.value : targets.icon;
        } else if (i == 12) {
            auto targets = WatermarkTelemetryColorTargets(c, ui.data, 12);
            color = ui.delayTextColor.initialized ? ui.delayTextColor.value : targets.text;
            iconColor = ui.delayIconColor.initialized ? ui.delayIconColor.value : targets.icon;
        } else if (i >= 13 && i <= 20) {
            auto targets = WatermarkTelemetryColorTargets(c, ui.data, int(i));
            auto n = i - 13;
            color = ui.networkTextColor[n].initialized ? ui.networkTextColor[n].value : targets.text;
            iconColor = ui.networkIconColor[n].initialized ? ui.networkIconColor[n].value : targets.icon;
        } else if (i >= 5 && i <= 9) {
            auto targets = WatermarkTelemetryColorTargets(c, ui.data, int(i));
            auto n = i - 5;
            color = ui.telemetryTextColor[n].initialized ? ui.telemetryTextColor[n].value : targets.text;
            iconColor = ui.telemetryIconColor[n].initialized ? ui.telemetryIconColor[n].value : targets.icon;
        } else if (severity > 0)
            iconColor = color = Mix(c.worldMisc.colors[16], c.worldMisc.colors[17], severity);

        float visible = std::round(w * a);
        p.cells.push_back(
            {int(i), {x, 0, visible, H}, a, text, color, iconColor, std::max(0.f, std::round(w - raw))});
        lastAdvance = std::round((w + 11 * s) * a);
        x += lastAdvance;
    }
    bool avatar =
        WatermarkValue(c, "watermark_avatar") && c.avatar && c.avatar->width > 0 && c.avatar->height > 0;

    float W = p.cells.empty() ? 0
                              : x - lastAdvance + p.cells.back().box.w -
                                    std::round(11 * s * (1 - p.cells.back().opacity)) + pad;
    if (avatar) {

        float h = H - 10 * s;
        if (p.cells.empty()) {
            W = H;
            p.avatarBox = {5 * s, 5 * s, h, h};
        } else {
            p.avatarBox = {W + 10 * s - pad, 5 * s, h, h};
            W += H + 5 * s - pad;
        }
    }
    if (W <= 0) {
        p.opacity = 0;
        return p;
    }
    W = std::max(1.f, W);
    int pos = std::clamp(int(WatermarkValue(c, "watermark_position")), 0, 5);
    float X = pos == 0 || pos == 5 ? 5 * s : pos == 1 || pos == 4 ? (width - W) * .5f : width - W - 5 * s;
    float Y = pos < 3 ? 5 * s : height - H - 5 * s;

    p.panel = {std::max(0.f, X), std::max(0.f, Y), W, H};
    p.radius = std::clamp(16 * s, 0.f, .5f * std::min(W, H));
    if (avatar) {
        p.avatarBox.x += p.panel.x;
        p.avatarBox.y += p.panel.y;
    }
    bool positionActive = ui.PositionMotionActive();
    for (auto& cell : p.cells) {
        cell.box.x += p.panel.x;
        cell.box.y += p.panel.y;
        cell.slotX = cell.box.x;
        auto& motion = ui.positions[std::size_t(cell.item)];
        float local = cell.box.x - p.panel.x;
        if (metricsChanged || !positionActive)
            motion.Snap(local, ui.seconds);
        if (ui.heldItem == cell.item)
            motion.Snap(ui.pointerX - ui.grabOffset - p.panel.x, ui.seconds);
        else if (positionActive)
            motion.Resolve(local, ui.seconds);
        cell.box.x = p.panel.x + motion.value;
    }
    return p;
}

inline float WatermarkItemInkAlpha(float alpha) {
    return (std::clamp(alpha, .6f, 1.f) - .6f) / (1.f - .6f);
}

inline Box WatermarkInkRasterBox(const WatermarkPaint& p, int width, int height) {
    float x = std::clamp(std::floor(p.panel.x), 0.f, float(width)),
          y = std::clamp(std::floor(p.panel.y), 0.f, float(height));
    return {x, y, std::max(0.f, std::min(float(width), std::ceil(p.panel.x + p.panel.w)) - x),
            std::max(0.f, std::min(float(height), std::ceil(p.panel.y + p.panel.h)) - y)};
}
inline void DrawWatermarkInk(Canvas& c, Fonts& f, const Settings& cfg, const WatermarkUI& ui,
                             const WatermarkPaint& p, float ox = 0, float oy = 0) {
    float s = p.scale;
    Box panelClip{p.panel.x - ox, p.panel.y - oy, p.panel.w, p.panel.h};
    for (std::size_t i = 0; i < p.cells.size(); ++i) {
        const auto& cell = p.cells[i];
        auto b = cell.box;
        Box clip = panelClip;
        float hover = ui.interactionMotion[std::size_t(cell.item)].value;
        if (hover > 0) {
            auto fill = WatermarkItemHoverColor(cfg, hover, p.opacity);
            auto h = WatermarkItemButtonBox(p, cell);
            h.x -= ox;
            h.y -= oy;
            c.RoundRect(h, 6 * s, fill, {0, 0, 0, 0}, 0, 0, 15, &clip);
        }
        b.x += cell.inkOffset;
        float a = p.opacity * WatermarkItemInkAlpha(cell.opacity);
        Color color = cell.color;
        color.a *= a;
        Color iconColor = cell.iconColor;
        iconColor.a *= a;
        if (cell.item == 0) {
            float h = b.h * .37f, w = h * 79.3f / 46.7f;
            float yy = b.y + (b.h - h) * .5f;
            for (int y = int(std::floor(yy)); y < int(std::ceil(yy + h)); ++y)
                for (int x = int(std::floor(b.x)); x < int(std::ceil(b.x + w)); ++x) {
                    float u = (x + .5f - b.x) / w * 51 - .5f, v = (y + .5f - yy) / h * 30 - .5f;
                    int ix = int(std::floor(u)), iy = int(std::floor(v));
                    float fx = u - ix, fy = v - iy, rgba[4]{};
                    for (int dy = 0; dy < 2; ++dy)
                        for (int dx = 0; dx < 2; ++dx) {
                            auto q = wm::LogoRGBA +
                                     4 * (std::clamp(iy + dy, 0, 29) * 51 + std::clamp(ix + dx, 0, 50));
                            float k = (dx ? fx : 1 - fx) * (dy ? fy : 1 - fy), alpha = q[3] / 255.f;
                            for (int j = 0; j < 3; ++j)
                                rgba[j] += q[j] / 255.f * alpha * k;
                            rgba[3] += alpha * k;
                        }
                    if (rgba[3] > 0 && clip.Contains(x - ox + .5f, y - oy + .5f))
                        c.Blend(int(x - ox), int(y - oy),
                                {rgba[0] / rgba[3], rgba[1] / rgba[3], rgba[2] / rgba[3], rgba[3] * a});
                }
        } else if (cell.item == 8) {
            std::array<Color, 3> colors{};
            for (std::size_t n = 0; n < colors.size(); ++n) {
                colors[n] = cfg.worldMisc.colors[18 + n];
                colors[n].a *= a;
                colors[n] = WatermarkPaletteRGBA8(colors[n]);
            }
            for (std::size_t n = 0; n < ui.displayedCores.size(); ++n) {
                auto bar = WatermarkCoreGeometry(b, p.fontHeight, s, p.font, n, ui.displayedCores[n]);
                bar.box.x -= ox;
                bar.box.y -= oy;
                bar.split -= oy;
                if (!bar.high)
                    WatermarkCoreGradient(c, bar.box, colors[1], colors[0], clip);
                else {
                    float bottom = bar.box.y + bar.box.h;
                    WatermarkCoreGradient(c, {bar.box.x, bar.split, bar.box.w, bottom - bar.split}, colors[1],
                                          colors[0], clip);
                    WatermarkCoreGradient(c, {bar.box.x, bar.box.y, bar.box.w, bar.split - bar.box.y},
                                          colors[2], colors[1], clip);
                }
            }
        } else {
            float y = b.y + (b.h - f.PixelHeight(p.font, p.px)) * .5f - s;
            f.NativeMergedIcon(c, p.px, WatermarkItems[std::size_t(cell.item)].glyph, b.x, y, iconColor, ox,
                               oy, &clip, p.font);
            float iw = std::ceil(f.Get(3, p.px, WatermarkItems[std::size_t(cell.item)].glyph).advance);
            WatermarkText(c, f, p.font, p.px, cell.text, b.x + iw + 5 * s, y, color, ox, oy, &clip);
        }
    }
    if (p.avatarBox.w > 0 && cfg.avatar) {
        auto b = p.avatarBox;
        b.x -= ox;
        b.y -= oy;
        DrawImage(c, *cfg.avatar, b, true, p.opacity);
    }
}
inline void RenderWatermarkCPU(Canvas& c, Fonts& f, const Settings& cfg, const WatermarkUI& ui) {
    auto p = MeasureWatermark(f, cfg, ui, c.width, c.height);
    if (p.opacity <= 0)
        return;
    if (cfg.blur)
        BlurMenuBackdrop(c, p.panel, p.radius, cfg.sigma * p.scale, p.opacity, 0, 0);
    c.RoundRect(p.panel, p.radius, p.fill);
    DrawMenuShadow(c, p.panel, p.radius, p.shadow, p.shadowColor, 0);
    DrawWatermarkInk(c, f, cfg, ui, p);
}
}
