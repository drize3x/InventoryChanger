#pragma once

inline void PlayersESPLayoutCapture(const std::array<PlayersESPLayout, 2>& layouts,
                                    std::map<std::string, std::string>& values) {
    for (std::size_t team = 0; team < layouts.size(); ++team) {
        const auto& layout = layouts[team];
        if (!layout.Valid())
            throw std::runtime_error("Invalid ESP layout");
        const auto prefix = "players.espLayout." + std::to_string(team) + ".";
        values[prefix + "active"] = layout.active ? "1" : "0";
        for (std::size_t side = 0; side < 4; ++side) {
            std::string text;
            for (int item : layout.list[side]) {
                if (!text.empty())
                    text += ",";
                text += std::to_string(item);
            }
            values[prefix + "side." + std::to_string(side)] = text;
        }
    }
}
inline void PlayersESPLayoutRead(std::array<PlayersESPLayout, 2>& layouts,
                                 const std::map<std::string, std::string>& values) {
    const std::string prefix = "players.espLayout.";
    std::size_t keys = 0;
    for (const auto& kv : values)
        if (kv.first.rfind(prefix, 0) == 0)
            ++keys;

    std::array<PlayersESPLayout, 2> next{};
    if (!keys) {
        layouts = next;
        return;
    }
    if (keys != 10)
        throw std::runtime_error("Incomplete ESP layout");
    for (std::size_t team = 0; team < 2; ++team) {
        auto& layout = next[team];
        const auto base = prefix + std::to_string(team) + ".";
        auto active = values.find(base + "active");
        if (active == values.end() || (active->second != "0" && active->second != "1"))
            throw std::runtime_error("Invalid ESP layout active flag");
        layout.active = active->second == "1";
        for (std::size_t side = 0; side < 4; ++side) {
            const auto it = values.find(base + "side." + std::to_string(side));
            if (it == values.end() || it->second.size() > 100)
                throw std::runtime_error("Invalid ESP layout side");
            auto& list = layout.list[side];
            list.clear();
            const auto& text = it->second;
            std::size_t at = 0;
            while (at < text.size()) {
                const auto comma = text.find(',', at), end = comma == std::string::npos ? text.size() : comma;
                const auto token = text.substr(at, end - at);
                if (token.empty() || token.size() > 2 || token[0] == '0' ||
                    !std::all_of(token.begin(), token.end(), [](char c) { return c >= '0' && c <= '9'; }))
                    throw std::runtime_error("Invalid ESP layout item");
                list.push_back(std::stoi(token));
                if (comma == std::string::npos)
                    break;
                at = comma + 1;
                if (at == text.size())
                    throw std::runtime_error("Invalid ESP layout trailing separator");
            }
        }
        if (!layout.Valid())
            throw std::runtime_error("Duplicate/missing/invalid ESP layout item or bar order");
    }
    layouts = std::move(next);
}
