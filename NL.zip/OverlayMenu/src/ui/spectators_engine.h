#pragma once
#include <array>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>
#include "players_live_data.h"
namespace menu {

struct SpectatorsOffsets {
    std::uint32_t localFlag = 0, pawnHandle = 0, observerPawn = 0, name = 0, team = 0, observerServices = 0,
                  observerTarget = 0, observerMode = 0;
    std::optional<std::uint32_t> controllerPawn, steamID, actualMoveType, moveType;
    bool Valid() const {
        return localFlag && pawnHandle && (observerPawn || (controllerPawn && *controllerPawn)) &&
               name && team && observerServices &&
               observerTarget && observerMode;
    }
};
struct SpectatorsContext {
    std::uintptr_t entities = 0, localGlobal = 0;
    SpectatorsOffsets offsets{};
    bool valid = false;
};
struct SpectatorEntry {
    std::uint32_t slot = 0;
    std::string name;
    std::uint8_t team = 0;
    std::uint64_t steamID = 0;
    std::shared_ptr<const ProfileImage> avatar;
};
struct SpectatorsFrame {
    bool valid = false, transient = false;
    std::vector<SpectatorEntry> entries;
    int controllers = 0, observers = 0;
    const char* stage = "not sampled";

    int activePawns = 0, observerFallbacks = 0, notPlayerTargets = 0;
    std::uint32_t localIndex = 0, observedIndex = 0;
};

struct SpectatorsDiagnostics {
    const char* stage = "not sampled";
    bool valid = false, transient = false, contextValid = false, pawnOffset = false, moveOffsets = false;
    int controllers = 0, observers = 0, entries = 0, activePawns = 0, observerFallbacks = 0,
        notPlayerTargets = 0;
    std::uint32_t localIndex = 0, observedIndex = 0;
    std::string Line() const {
        return std::string("stage=") + stage + " valid=" + std::to_string(valid) +
               " transient=" + std::to_string(transient) + " context=" + std::to_string(contextValid) +
               " offsets(m_hPawn/movetype)=" + std::to_string(pawnOffset) + std::to_string(moveOffsets) +
               "; controllers=" + std::to_string(controllers) +
               " pawns(m_hPawn)=" + std::to_string(activePawns) +
               " fallbacks(m_hObserverPawn)=" + std::to_string(observerFallbacks) +
               " observers=" + std::to_string(observers) +
               " not-player-targets=" + std::to_string(notPlayerTargets) +
               " entries=" + std::to_string(entries) + "; localIndex=" + std::to_string(localIndex) +
               " observedIndex=" + std::to_string(observedIndex);
    }
};

inline std::string SpectatorsTruncateName(const std::string& raw) {
    constexpr std::size_t limit = 32;
    if (raw.size() <= limit)
        return raw;
    std::size_t end = limit;
    while (end > 0 && (static_cast<unsigned char>(raw[end]) & 0xC0) == 0x80)
        --end;
    return raw.substr(0, end) + "..";
}
constexpr std::uint8_t SpectatorsMoveTypeObserver = 8;
constexpr std::uint8_t SpectatorsModeInEye = 2, SpectatorsModeChase = 3;
inline bool SpectatorsHandleValid(std::uint32_t handle) {
    return handle && handle < 0xFFFFFFFEu;
}

template <class Reader>
std::uintptr_t SpectatorsObserverPawn(Reader&& read, std::uintptr_t global, std::uintptr_t controller,
                                      const SpectatorsOffsets& o, bool* fallback = nullptr) {
    std::uint32_t handle = 0;
    if (fallback)
        *fallback = false;
    if (o.controllerPawn && read(controller + *o.controllerPawn, handle) && SpectatorsHandleValid(handle)) {
        auto pawn = WatermarkPawn(read, global, handle);
        if (pawn)
            return *pawn;
    }
    if (o.observerPawn && read(controller + o.observerPawn, handle) && SpectatorsHandleValid(handle)) {
        auto pawn = WatermarkPawn(read, global, handle);
        if (pawn) {
            if (fallback)
                *fallback = true;
            return *pawn;
        }
    }
    return 0;
}

template <class Reader>
bool SpectatorsServices(Reader&& read, std::uintptr_t pawn, const SpectatorsOffsets& o, std::uint8_t& mode,
                        std::uint32_t& target) {
    std::uintptr_t services = 0;
    mode = 0;
    target = 0xFFFFFFFFu;
    if (!pawn || !read(pawn + o.observerServices, services) || !services)
        return false;
    return read(services + o.observerMode, mode) && read(services + o.observerTarget, target);
}
template <class Reader>
bool SpectatorsIsObserverPawn(Reader&& read, std::uintptr_t pawn, const SpectatorsOffsets& o) {

    if (!o.actualMoveType && !o.moveType)
        return true;
    std::uint8_t value = 0;
    if (o.actualMoveType && read(pawn + *o.actualMoveType, value) && value == SpectatorsMoveTypeObserver)
        return true;
    if (o.moveType && read(pawn + *o.moveType, value) && value == SpectatorsMoveTypeObserver)
        return true;
    return false;
}
template <class Reader> SpectatorsFrame SpectatorsCollect(Reader&& read, const SpectatorsContext& c) {
    SpectatorsFrame frame;
    const auto& o = c.offsets;
    if (!c.valid || !o.Valid() || !c.entities) {
        frame.stage = "context unavailable";
        return frame;
    }
    frame.stage = "local controller unavailable";
    frame.transient = true;
    auto local = WatermarkKdLocalController(read, c.entities, c.localGlobal, o.localFlag);
    if (!local.ok || !local.value)
        return frame;
    frame.stage = "entity root/page unavailable";
    std::uintptr_t root = 0, page = 0;
    if (!read(c.entities, root) || !root || !read(root + 0x10, page) || !page)
        return frame;

    std::array<std::uintptr_t, 65> controllers{};
    std::array<std::uint32_t, 65> pawnIndex{};
    for (int slot = 1; slot <= 64; ++slot) {
        std::uintptr_t controller = 0;
        if (!read(page + std::uintptr_t(slot) * 0x70, controller) || !controller)
            continue;
        controllers[std::size_t(slot)] = controller;
        std::uint32_t handle = 0;
        if (read(controller + o.pawnHandle, handle) && SpectatorsHandleValid(handle))
            pawnIndex[std::size_t(slot)] = handle & 0x7FFFu;
    }
    const auto playerPawn = [&](std::uint32_t index) {
        if (!index)
            return false;
        for (const auto i : pawnIndex)
            if (i == index)
                return true;
        return false;
    };
    std::uint32_t localHandle = 0;
    read(local.value + o.pawnHandle, localHandle);
    std::uint32_t localIndex = SpectatorsHandleValid(localHandle) ? (localHandle & 0x7FFFu) : 0u;

    std::uint32_t observedIndex = 0;
    {
        const auto pawn = SpectatorsObserverPawn(read, c.entities, local.value, o);
        std::uint8_t mode = 0;
        std::uint32_t target = 0;
        if (pawn && SpectatorsServices(read, pawn, o, mode, target) &&
            (mode == SpectatorsModeInEye || mode == SpectatorsModeChase) && SpectatorsHandleValid(target) &&
            playerPawn(target & 0x7FFFu))
            observedIndex = target & 0x7FFFu;
    }
    frame.localIndex = localIndex;
    frame.observedIndex = observedIndex;
    if (!localIndex && !observedIndex) {
        frame.stage = "no local target";
        frame.transient = false;
        frame.valid = true;
        return frame;
    }
    frame.stage = "collected";
    for (int slot = 1; slot <= 64; ++slot) {
        const std::uintptr_t controller = controllers[std::size_t(slot)];
        if (!controller || controller == local.value)
            continue;
        ++frame.controllers;
        bool fallback = false;
        const auto pawn = SpectatorsObserverPawn(read, c.entities, controller, o, &fallback);
        if (!pawn)
            continue;
        if (fallback)
            ++frame.observerFallbacks;
        else
            ++frame.activePawns;
        std::uint8_t mode = 0;
        std::uint32_t target = 0;
        if (!SpectatorsServices(read, pawn, o, mode, target) ||
            (mode != SpectatorsModeInEye && mode != SpectatorsModeChase) || !SpectatorsHandleValid(target) ||
            !SpectatorsIsObserverPawn(read, pawn, o))
            continue;
        ++frame.observers;
        const std::uint32_t index = target & 0x7FFFu;
        if (!playerPawn(index)) {
            ++frame.notPlayerTargets;
            continue;
        }
        if (!((localIndex && index == localIndex) || (observedIndex && index == observedIndex)))
            continue;
        SpectatorEntry e;
        e.slot = std::uint32_t(slot);
        std::string name;
        if (!LiveESPString(read, controller + o.name, name) || name.empty())
            continue;
        e.name = SpectatorsTruncateName(name);
        std::uint8_t team = 0;
        if (!read(pawn + o.team, team) || (team != 2 && team != 3)) {
            team = 0;
            read(controller + o.team, team);
        }
        e.team = team;
        if (o.steamID) {
            std::uint64_t id = 0;
            if (read(controller + *o.steamID, id))
                e.steamID = id;
        }
        frame.entries.push_back(std::move(e));
    }
    std::uintptr_t again = 0;
    if (!read(c.entities, again) || again != root || !read(root + 0x10, again) || again != page) {
        frame.entries.clear();
        frame.stage = "frame identity changed";
        frame.transient = true;
        return frame;
    }
    auto currentLocal = WatermarkKdLocalController(read, c.entities, c.localGlobal, o.localFlag);
    if (!currentLocal.ok || currentLocal.value != local.value) {
        frame.entries.clear();
        frame.stage = "frame identity changed";
        frame.transient = true;
        return frame;
    }
    frame.valid = true;
    frame.transient = false;
    return frame;
}
inline SpectatorsDiagnostics SpectatorsDiagnose(const SpectatorsContext& c, const SpectatorsFrame& f) {
    SpectatorsDiagnostics d;
    d.stage = f.stage;
    d.valid = f.valid;
    d.transient = f.transient;
    d.contextValid = c.valid;
    d.pawnOffset = bool(c.offsets.controllerPawn);
    d.moveOffsets = c.offsets.actualMoveType || c.offsets.moveType;
    d.controllers = f.controllers;
    d.observers = f.observers;
    d.entries = int(f.entries.size());
    d.activePawns = f.activePawns;
    d.observerFallbacks = f.observerFallbacks;
    d.notPlayerTargets = f.notPlayerTargets;
    d.localIndex = f.localIndex;
    d.observedIndex = f.observedIndex;
    return d;
}
}
