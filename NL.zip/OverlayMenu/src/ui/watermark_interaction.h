#pragma once
#include "watermark_ui.h"
#include "world_view_ui.h"
#include <limits>
namespace menu {

struct WatermarkInteraction {
    static Settings Presentation(const Settings& cfg) {
        auto scaled = cfg;
        scaled.scale = ScreenWindowScale(cfg);
        return scaled;
    }
    WorldMiscUI settings;
    float lastLocal = 0;
    bool pointerOwned = false;
    float dragScale = 1;
    int dragDensity = 0;

    WatermarkInteraction() {
        settings.detachedRoot = 76;
    }
    bool Active() const {
        return settings.Active();
    }
    bool Capturing(const WatermarkUI& ui) const {
        return ui.heldItem >= 0 || pointerOwned || settings.Capturing();
    }
    void Cancel(WatermarkUI& ui, bool close = false) {
        ui.heldItem = -1;
        pointerOwned = false;
        if (close)
            ui.hoverItem = -1;
        ui.SyncInteractionTargets();
        settings.CancelInput();
        if (close)
            settings.Close(false);
    }
    void Measure(Fonts& fonts, const Settings& cfg, int w, int h, bool enabled,
                 LanguageCatalog* languages = nullptr) {
        settings.languages = languages;
        auto scaled = Presentation(cfg);
        settings.Measure(fonts, scaled, {}, w, h, enabled, false);
    }
    void Tick(float dt, const Settings& cfg) {
        settings.Tick(dt, cfg);
    }
    static int ItemAt(const WatermarkPaint& p, float x, float y) {
        if (p.opacity < .99f || !p.panel.Contains(x, y))
            return -1;
        for (const auto& c : p.cells)
            if (c.opacity >= .99f && WatermarkItemButtonBox(p, c).Contains(x, y))
                return c.item;
        return -1;
    }
    bool Context(Fonts& fonts, Settings& cfg, WatermarkUI& ui, int w, int h, float x, float y, bool allowed) {
        if (!allowed)
            return false;
        if (Active()) {
            settings.Context(x, y, cfg);
            return true;
        }
        auto p = MeasureWatermark(fonts, cfg, ui, w, h);
        if (p.opacity < .99f || !p.panel.Contains(x, y))
            return false;
        Cancel(ui);
        ui.hoverItem = -1;
        ui.SyncInteractionTargets();
        settings.OpenDetached(76, x + 1, y + 1);
        Measure(fonts, cfg, w, h, true, settings.languages);
        return true;
    }
    bool Click(Fonts& fonts, Settings& cfg, WatermarkUI& ui, int w, int h, float x, float y, bool down,
               bool allowed, bool ctrl = false) {
        if (!allowed) {
            Cancel(ui, true);
            return false;
        }
        if (Active() || settings.Capturing()) {
            bool owned = Active() || pointerOwned;
            settings.Click(x, y, down, cfg, ctrl);
            pointerOwned = down;
            return owned;
        }
        if (!down) {
            bool owned = pointerOwned || ui.heldItem >= 0;
            Cancel(ui);
            return owned;
        }
        auto p = MeasureWatermark(fonts, cfg, ui, w, h);
        int item = ItemAt(p, x, y);
        if (item < 0)
            return false;
        dragScale = p.scale;
        dragDensity = int(WatermarkValue(cfg, "watermark_density"));
        ui.heldItem = ui.hoverItem = item;
        ui.SyncInteractionTargets();
        ui.pointerX = x;
        ui.BeginPositionMotion();
        pointerOwned = true;
        for (const auto& c : p.cells)
            if (c.item == item) {
                ui.grabOffset = x - c.box.x;
                lastLocal = x - p.panel.x;
            }
        return true;
    }
    bool Move(Fonts& fonts, Settings& cfg, WatermarkUI& ui, int w, int h, float x, float y, bool down,
              bool allowed) {
        if (!allowed) {
            bool owned = Capturing(ui);
            Cancel(ui, true);
            return owned;
        }
        if (Active()) {
            ui.hoverItem = -1;
            ui.SyncInteractionTargets();
            settings.Move(x, y, cfg);
            return true;
        }
        if (ui.heldItem < 0) {
            ui.hoverItem = ItemAt(MeasureWatermark(fonts, cfg, ui, w, h), x, y);
            ui.SyncInteractionTargets();
            return pointerOwned;
        }
        if (!down) {
            Cancel(ui);
            return true;
        }

        auto id = std::string("watermark_item_") + WatermarkItems[std::size_t(ui.heldItem)].id;
        if (ScreenWindowScale(cfg) != dragScale ||
            int(WatermarkValue(cfg, "watermark_density")) != dragDensity || !WatermarkEnabled(cfg) ||
            !WatermarkValue(cfg, id.c_str()) || ui.items[std::size_t(ui.heldItem)].value < .99f) {
            Cancel(ui);
            return true;
        }
        ui.pointerX = x;
        auto p = MeasureWatermark(fonts, cfg, ui, w, h);
        float local = x - p.panel.x;
        if (std::abs(local - lastLocal) < 3.f)
            return true;
        lastLocal = local;
        int target = -1;
        float distance = std::numeric_limits<float>::max();
        for (const auto& cell : p.cells) {
            if (cell.opacity < .99f)
                continue;
            float d = std::abs(x - (cell.slotX + cell.box.w * .5f));
            if (d < distance) {
                target = cell.item;
                distance = d;
            }
        }
        if (target < 0 || target == ui.heldItem)
            return true;
        auto order = WatermarkOrder(cfg);
        auto from = std::find(order.begin(), order.end(), ui.heldItem),
             to = std::find(order.begin(), order.end(), target);

        if (from < to)
            std::rotate(from, from + 1, to + 1);
        else
            std::rotate(to, from, from + 1);
        cfg.watermarkOrder = order;
        return true;
    }
};
}
