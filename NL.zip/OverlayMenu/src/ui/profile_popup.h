#pragma once
#include "menu_core.h"
#include "presets_edit.h"
#include "color_picker_common.h"
#include <cstdio>
#include <map>
#include "profile_labels.h"
#include "language_catalog.h"
namespace menu {
inline constexpr std::array<const char*, 11> ProfileKeys{
    {"menu_user_language", "menu_user_menuscale", "menu_user_espscale", "menu_user_windowsscale",
     "menu_user_units", "menu_user_style", "menu_user_safemode", "menu_user_synchronization",
     "menu_user_developermode", "window_about", "window_chat"}};

inline constexpr std::array<char32_t, 11> ProfileIcons{
    {0xf0ac, 0xf88e, 0xf894, 0xf2d2, 0xf61c, 0xf576, 0xe247, 0xe23e, 0xf7ea, 0xf1f9, 0xf086}};
inline constexpr std::array<char32_t, 2> AboutLinkIcons{{0xf14d, 0xf105}};
inline constexpr std::array<const char*, 2> AboutURLs{
    {"https://neverlose.cc/tickets", "https://neverlose.cc/tos"}};
inline constexpr const char* AboutUpdated = "Sep 16 2026";

inline constexpr char32_t AboutFooter[] = U"Neverlose © 2020-2026";

struct AboutLayout {
    Box overlay, logo, badge, account, links, footer;
    std::array<Box, 4> rows;
    std::array<Box, 2> linkRows;
    std::array<Box, 4> separators;
};

inline Box ProfilePixelBox(Box b) {
    b.x = std::trunc(b.x);
    b.y = std::trunc(b.y);
    return b;
}
struct ProfilePopupLayout {
    Box panel, header, avatar, renew, theme, swatch, sync;
    std::array<Box, 11> rows{};
    std::array<Box, 3> dividers{};
    float fullHeight = 0;
};
inline std::u32string ProfileDate(const Settings& cfg) {
    if (!cfg.subscriptionEnd)
        return cfg.userDetail;
    auto t = std::time_t(cfg.subscriptionEnd);
    std::tm date{};
#ifdef _WIN32
    if (localtime_s(&date, &t))
        return U"-";
#else
    if (!localtime_r(&t, &date))
        return U"-";
#endif
    char text[80]{};
    return std::strftime(text, sizeof text, "%B %d %Y", &date) ? ASCII(text) : U"-";
}
inline Color ProfileHSV(float h, float s, float v) {
    float x = h * 6;
    int i = int(x);
    float f = x - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
    switch (i % 6) {
    case 0:
        return {v, t, p, 1};
    case 1:
        return {q, v, p, 1};
    case 2:
        return {p, v, t, 1};
    case 3:
        return {p, q, v, 1};
    case 4:
        return {t, p, v, 1};
    default:
        return {v, p, q, 1};
    }
}
struct ProfileUI {
    bool open = false, pressed = false, synchronization = false, developerVisible = false;
    int dropdown = -1, hover = -1, held = -1;

    struct SubmenuWindow {
        DumpTween alpha;
        std::shared_ptr<ProfileUI> closing;
    };
    std::map<int, SubmenuWindow> submenuWindows;
    void SetDropdown(int next) {
        if (next == dropdown)
            return;
        if (HoverSubmenu(dropdown)) {
            auto frozen = std::make_shared<ProfileUI>(*this);
            frozen->submenuWindows.clear();
            auto& old = submenuWindows[dropdown];
            if (old.alpha.value == 0 && old.alpha.target == 0)
                old.alpha.value = old.alpha.target = old.alpha.from = 1;
            old.closing = std::move(frozen);
            old.alpha.Tick(0, 0);
        }
        dropdown = next;
        if (HoverSubmenu(next)) {
            auto& fresh = submenuWindows[next];
            fresh.closing.reset();
            fresh.alpha.Tick(1, 0);
        }
        ++revision;
    }
    int SubmenuRow(int layer) const {
        return layer == 1 ? dropdown : layer >= 8 && layer < 15 ? layer - 8 : -1;
    }
    const ProfileUI* ClosingSubmenu(int layer) const {
        auto it = submenuWindows.find(SubmenuRow(layer));
        return layer >= 8 && it != submenuWindows.end() ? it->second.closing.get() : nullptr;
    }
    void TickSubmenus(float dt) {
        if (!std::isfinite(dt) || dt < 0)
            dt = 0;
        if (HoverSubmenu(dropdown) && !submenuWindows.count(dropdown))
            submenuWindows[dropdown].alpha.Tick(1, 0);
        for (auto it = submenuWindows.begin(); it != submenuWindows.end();) {
            auto& w = it->second;
            float before = w.alpha.value;
            w.alpha.Tick(it->first == dropdown ? 1.f : 0.f, dt);
            if (before != w.alpha.value)
                ++revision;
            if (it->first != dropdown && w.alpha.value == 0) {
                it = submenuWindows.erase(it);
                ++revision;
            } else
                ++it;
        }
    }
    int hoverSuppressedRow = -1;
    static bool HoverSubmenu(int row) {
        return (row >= 0 && row <= 4) || row == 6;
    }
    float pointerX = 0, pointerY = 0;
    bool pointerKnown = false;

    static bool HeadingToSubmenu(Box parent, Box child, float prevX, float prevY, float px, float py) {
        float edge = child.x, sign = .5f;
        if (child.x > parent.x)
            sign = -.5f;
        else
            edge += child.w;
        float slack = std::clamp(std::abs(prevX - edge) * .3f, 5.f, 30.f);
        float ax = prevX + sign, ay = prevY, bx = edge,
              by = prevY + std::max(child.y - slack - prevY, -100.f);
        float cx = edge, cy = prevY + std::min(child.y + child.h + slack - prevY, 100.f);
        auto cross = [](float x, float y, float x1, float y1, float x2, float y2) {
            return (x - x2) * (y1 - y2) - (x1 - x2) * (y - y2);
        };
        bool a = cross(px, py, ax, ay, bx, by) < 0, b = cross(px, py, bx, by, cx, cy) < 0,
             c = cross(px, py, cx, cy, ax, ay) < 0;
        return a == b && b == c;
    }
    int viewportW = 1200, viewportH = 800, menuScale = 0, espScale = 0, windowsScale = 0, units = 0,
        safeMode = 1;
    float x = 0, y = 0, initialScale = 1, scroll = 0;
    std::uint64_t revision = 1;
    std::array<DumpTween, 11> rowTween{}, rowTextTween{};
    DumpTween syncTween, renewTween, baseTween, pickerSaveTween, pickerFormatTween, chatScrollHover;
    std::array<DumpTween, 3> pickerFieldTween{};
    std::array<DumpTween, 2> languageActionTween{};
    std::array<DumpTween, 2> chatButtonTween{}, chatButtonTextTween{};
    DumpTween chatInputTween;
    std::array<DumpTween, 2> buttonTween{};
    std::array<DumpTween, 3> fieldTween{}, modeFill{}, modeText{};
    std::vector<DumpTween> optionFill, optionText, baseOptionFill, baseOptionText;
    int optionChannel = -2;
    float renewTextWidth = 0, fontSize = 0, fontSizeScale = 0;

    DumpTween themeFillTween, themeTextTween, modalCloseFill, modalCloseInk;
    std::vector<DumpTween> languageButtonFill, languageButtonInk;
    Color LanguageButtonFill(const Settings& cfg, int i) const {
        auto c = CurrentPalette(cfg)[33];
        c.a *= .4f * (i < int(languageButtonFill.size()) ? languageButtonFill[i].value : 0.f);
        return c;
    }
    Color LanguageButtonInk(const Settings& cfg, int i) const {
        auto c = CurrentPalette(cfg)[30];
        c.a *= .7f + .3f * (i < int(languageButtonInk.size()) ? languageButtonInk[i].value : 0.f);
        return c;
    }
    Color ThemeFill(const Settings& cfg) const {
        auto c = CurrentPalette(cfg)[33];
        c.a *= .4f * themeFillTween.value;
        return c;
    }
    Color ThemeInk(const Settings& cfg) const {
        auto c = CurrentPalette(cfg)[30];
        c.a *= .7f + .3f * themeTextTween.value;
        return c;
    }
    LanguageCatalog languages;
    int modal = 0, field = 0, baseLanguage = 0, deleteLanguage = -1, languageScroll = 0, baseScroll = 0;
    std::array<PresetEditor, 3> formEditors{};
    std::array<std::u32string, 3> fields{};
    std::string error;
    int action = 0, editLanguage = -1;
    bool picker = false, baseOpen = false;
    float hue = .622f, saturation = .69f, value = 1;
    char16_t highSurrogate = 0;
    menu::Layout anchorLayout{};
    bool anchorDirty = true;
    float anchorScale = 0;
    Color swatchFrom{.31f, .49f, 1, 1}, swatchTarget{.31f, .49f, 1, 1};
    DumpTween swatchTween, styleSwatchTween;
    bool swatchReady = false;
    NativeColorWidth hexWidthTween;
    std::string widthColor;
    float hexWidthTarget = 84, hexHashWidth = 7;
    Box menuBounds{};
    bool aboutClosing = false;
    DumpTween aboutTween, extensionsTween;
    std::array<DumpTween, 2> aboutLinkTween{};

    struct ChatMessage {
        std::u32string author, body;
        std::string time;
        int role = 0;
    };
    std::vector<ChatMessage> chatMessages;
    std::u32string chatInput;
    bool chatFocus = true, chatActive = true, hostFocused = true;
    float chatX = -1, chatY = -1, chatW = 300, chatH = 500, dragX = 0, dragY = 0;
    int chatScroll = 0;
    float chatFriendWidth = 37, chatSendWidth = 77, chatContentHeight = 0;
    float caretSeconds = 0;
    bool CaretVisible() const {
        return std::fmod(caretSeconds, 1.2f) <= .8f;
    }
    float languageActionX = -1, languageActionY = -1, languageActionWidth = 110;
    float languageWidth = 170;
    std::vector<Color> pickerSaved;
    std::vector<DumpTween> pickerSavedTween;
    int languageActions = -1, pickerMode = 2, pickerField = -1;
    bool pickerModes = false, pickerMenuRelease = false, colorSelectAll = false;
    PickerFormatMetrics pickerMetrics{};
    float pickerMetricsScale = 0;
    std::u32string colorInput;
    std::array<std::u32string, 3> tipLines{};
    std::array<float, 2> tipHeights{{100, 100}}, tipWidths{{280, 280}};
    float hoverSeconds = 0, chatTipWidth = 140;
    int descriptionOwner = -1;
    DumpTween tipTween;
    ProfileUI() = default;
    void SetSwatchColor(Color col, bool immediate = false) {
        if (!swatchReady || immediate) {
            swatchFrom = swatchTarget = col;
            swatchReady = true;
            swatchTween = {};
            swatchTween.value = swatchTween.target = swatchTween.from = 1;
            return;
        }
        if (ColorKey(col) == ColorKey(swatchTarget))
            return;
        swatchFrom = Mix(swatchFrom, swatchTarget, swatchTween.value);
        swatchTarget = col;
        swatchTween = {};
        swatchTween.target = 1;
        swatchTween.elapsed = 0;
        ++revision;
    }
    Color SwatchColor(const Settings& cfg) const {
        return swatchReady ? Mix(swatchFrom, swatchTarget, swatchTween.value) : CurrentPalette(cfg)[31];
    }
    float FormHeight(const Settings& cfg) const {
        return RuntimeFontSize(cfg.scale) + 12 * cfg.scale * cfg.scale;
    }
    float BlurSigma(const Settings& cfg, int layer) const {
        if (auto child = ClosingSubmenu(layer))
            return child->BlurSigma(cfg, 1);
        return ((layer == 3 && (modal == 3 || modal == 4)) || (layer == 1 && dropdown == 0) ? 5.f
                                                                                            : cfg.sigma) *
               cfg.scale;
    }
    static bool HasDescription(int row) {
        return row == 6 || row == 7;
    }
    int DescriptionCandidate() const {
        if (modal == 4)
            return hostFocused && hover == 902 ? 901 : -1;
        return !modal && !picker && dropdown < 0 && languageActions < 0 && HasDescription(hover) ? hover : -1;
    }
    int DescriptionRow() const {
        if (modal == 4)
            return descriptionOwner == 901 ? 901 : -1;
        return !modal && !picker && dropdown < 0 && languageActions < 0 && HasDescription(descriptionOwner)
                   ? descriptionOwner
                   : -1;
    }
    float DescriptionAlpha() const {
        return std::clamp(tipTween.value, 0.f, 1.f);
    }
    bool MenuOverlay() const {
        return (modal >= 1 && modal <= 3) || modal == 5;
    }
    Box ChatBox(const Settings& cfg) const {
        float s = cfg.scale, w = std::min(chatW * s, float(viewportW) - 6 * s),
              h = std::min(chatH * s, float(viewportH) - 6 * s);
        return ProfilePixelBox(
            {chatX < 0 ? (viewportW - w) * .5f : std::clamp(chatX, 0.f, std::max(0.f, viewportW - w)),
             chatY < 0 ? (viewportH - h) * .5f : std::clamp(chatY, 0.f, std::max(0.f, viewportH - h)), w, h});
    }

    Box ChatTitle(const Settings& cfg) const {
        auto b = ChatBox(cfg);
        return {b.x, b.y, b.w - ChatClose(cfg).w, ChatHeaderH(cfg.scale)};
    }
    Box ChatClose(const Settings& cfg) const {
        auto b = ChatBox(cfg);
        float f = RuntimeFontSize(cfg.scale);
        return {b.x + b.w - f - 12 * cfg.scale, b.y, f + 12 * cfg.scale, f + 6 * cfg.scale};
    }
    bool ChatActive() const {
        return chatActive && hostFocused;
    }
    void SetHostFocused(bool focused) {
        if (hostFocused != focused) {
            hostFocused = focused;
            ++revision;
        }
    }
    static Color ChatAuthorColor(int role) {
        switch (role) {
        case 2:
            return {1, .07f, .57f, 1};
        case 3:
            return {1, 0, 0, 1};
        case 4:
            return {.2f, 1, .2f, 1};
        default:
            return {0, .58f, .73f, 1};
        }
    }
    Box ChatCaret(const Settings& cfg, float advance) const {
        auto b = ChatInputBox(cfg);
        return {std::floor(b.x + 12 * cfg.scale + advance), b.y + 6 * cfg.scale + .5f, 1,
                std::max(1.f, RuntimeFontSize(cfg.scale) - 2)};
    }

    Box ChatResize(const Settings& cfg) const {
        auto b = ChatBox(cfg);
        return {b.x + b.w - 12 * cfg.scale, b.y + b.h - 12 * cfg.scale, 12 * cfg.scale, 12 * cfg.scale};
    }

    float ChatRadius() const {
        return 12.f;
    }
    Color ChatBackground(const Settings& cfg) const {
        auto c = CurrentPalette(cfg)[45];
        auto q = [](float v) { return std::floor(std::clamp(v, 0.f, 1.f) * 255.f + .5f) / 255.f; };
        return {q(c.r), q(c.g), q(c.b), q(c.a)};
    }

    Box ChatContentClip(const Settings& cfg) const {
        auto b = ChatBox(cfg);
        float s = cfg.scale, border = 0;
        float inset = std::max(border, std::trunc(10 * s * .5f));
        float left = std::trunc(b.x + .5f + inset), right = std::trunc(b.x + b.w + .5f - inset);
        float top = std::trunc(b.y + ChatHeaderH(s) + .5f + s), bottom = std::trunc(b.y + b.h + .5f - border);
        return {left, top, std::max(0.f, right - left), std::max(0.f, bottom - top)};
    }
    Box ChatComposer(const Settings& cfg) const {
        auto b = ChatBox(cfg);
        float s = cfg.scale;
        return {b.x + 10 * s, b.y + b.h - ChatComposerH(s) - 10 * s, b.w - 20 * s, ChatComposerH(s)};
    }
    Box ChatInputBox(const Settings& cfg) const {
        auto b = ChatComposer(cfg);
        b.w = std::max(1.f, b.w - (chatFriendWidth + chatSendWidth - 12 + 10) * cfg.scale);
        return b;
    }

    Box ChatButton(const Settings& cfg, bool friendCode) const {
        auto input = ChatInputBox(cfg);
        float s = cfg.scale;
        return {input.x + input.w + 5 * s + (friendCode ? 0 : (chatFriendWidth + 5) * s), input.y,
                (friendCode ? chatFriendWidth : chatSendWidth) * s, input.h};
    }
    Box ChatHistory(const Settings& cfg) const {
        auto b = ChatBox(cfg);
        float s = cfg.scale;
        return {b.x + 10 * s, b.y + ChatHeaderH(s) + 10 * s, b.w - 20 * s,
                std::max(1.f, b.h - ChatHeaderH(s) - ChatComposerH(s) - 31 * s)};
    }

    static bool ChatFriendCode(const std::u32string& t) {
        if (t.size() != 10 || t[5] != U'-')
            return false;
        for (std::size_t i = 0; i < t.size(); ++i)
            if (i != 5 && !((t[i] >= U'A' && t[i] <= U'Z') || (t[i] >= U'0' && t[i] <= U'9')))
                return false;
        return true;
    }
    struct ChatDrawLine {
        std::u32string text;
        float x, y, w;
        Color color;
        bool separator = false;
        int code = -1;
        std::u32string codeKey{};
    };
    std::vector<DumpTween> chatCodeTween;
    std::vector<Box> chatCodeBoxes;
    std::vector<std::pair<Box, int>> chatCodeHits;
    std::vector<std::u32string> chatCodeKeys, chatCodeWords;
    std::u32string chatSelectedCode;
    float chatInputScroll = 0;
    std::u32string chatMeasuredInput;
    float chatMeasuredInputWidth = 0;

    static float ChatFollowCursor(float previous, float cursor, float width) {
        if (cursor < previous)
            return std::trunc(std::max(0.f, cursor - width * .25f));
        if (cursor - width >= previous)
            return std::trunc(cursor - width + width * .25f);
        return previous;
    }
    void MeasureChatInput(Fonts& fonts, const Settings& cfg) {
        float width = std::max(1.f, ChatInputBox(cfg).w);
        if (chatInput.empty())
            chatInputScroll = 0;
        else if (chatFocus && ChatActive() &&
                 (chatMeasuredInput != chatInput || chatMeasuredInputWidth != width))
            chatInputScroll = ChatFollowCursor(chatInputScroll,
                                               fonts.NativeTextSize(0, 13 * cfg.scale, chatInput).w, width);
        chatMeasuredInput = chatInput;
        chatMeasuredInputWidth = width;
    }
    std::vector<ChatDrawLine> ChatLines(Fonts& fonts, const Settings& cfg, float width, float& height) const {
        float s = cfg.scale, cy = 0, f = RuntimeFontSize(s),
              gap = std::trunc(fonts.NativeTextSize(0, 13 * s, U" ").w + .95f) * s;
        auto pal = CurrentPalette(cfg);
        std::vector<ChatDrawLine> lines;
        std::vector<std::u32string> keys;
        auto size = [&](const std::u32string& t) {
            auto b = fonts.NativeTextSize(0, 13 * s, t);
            b.w = std::trunc(b.w + .95f);
            return b;
        };
        auto draw = [&](const std::u32string& t, float x, float y, float w, Color color, int id = -1,
                        const std::u32string& key = U"") {
            std::size_t first = 0;
            float yy = y;
            for (std::size_t i = 0; i <= t.size(); ++i)
                if (i == t.size() || t[i] == U'\n') {
                    if (i < t.size() || i > first || t.empty())
                        lines.push_back({t.substr(first, i - first), x, yy, w, color, false, id, key});
                    first = i + 1;
                    yy += f;
                }
        };
        for (std::size_t mi = 0; mi < chatMessages.size(); ++mi) {
            auto& message = chatMessages[mi];
            auto time = ASCII(message.time);
            auto authorSize = size(message.author), timeSize = size(time);
            draw(message.author, 0, cy, authorSize.w, ChatAuthorColor(message.role));
            draw(time, width - timeSize.w, cy, timeSize.w, pal[1]);
            cy += std::max(authorSize.h, timeSize.h) + 2.5f * s;
            float x = 0, lineH = 0;
            std::size_t first = 0;

            for (std::size_t i = 0; i <= message.body.size(); ++i)
                if (i == message.body.size() || message.body[i] == U' ') {
                    auto word = message.body.substr(first, i - first);
                    auto wordSize = size(word);

                    if (wordSize.w > width - x) {
                        cy += std::max(f, lineH);
                        x = 0;
                        lineH = 0;
                    }
                    int id = -1;
                    float t = 0;
                    std::u32string key;
                    if (ChatFriendCode(word)) {
                        key = ASCII(std::to_string(mi)) + U":" + word;
                        auto found = std::find(keys.begin(), keys.end(), key);
                        id = int(found - keys.begin());
                        if (found == keys.end())
                            keys.push_back(key);
                        auto old = std::find(chatCodeKeys.begin(), chatCodeKeys.end(), key);
                        if (old != chatCodeKeys.end())
                            t = chatCodeTween[std::size_t(old - chatCodeKeys.begin())].value;
                    }
                    draw(word, x, cy, wordSize.w, id >= 0 ? Mix(pal[30], pal[31], t) : pal[30], id, key);

                    lineH = std::max(lineH, wordSize.h);
                    x += wordSize.w + gap;
                    first = i + 1;
                }
            cy += std::max(f, lineH) + 5 * s;
            if (mi + 1 < chatMessages.size()) {
                lines.push_back({U"", 0, cy, width, pal[34], true});
                cy += 6 * s;
            }
        }
        height = chatMessages.empty() ? 0 : cy - 5 * s;
        return lines;
    }
    void MeasureChatCodes(Fonts& fonts, const Settings& cfg) {
        auto h = ChatHistory(cfg);
        float total = 0;
        auto lines = ChatLines(fonts, cfg, h.w - (ChatOverflow(cfg) ? 15 * cfg.scale : 0), total);
        float offset = std::max(0.f, total - h.h - chatScroll * 18 * cfg.scale);
        auto oldKeys = std::move(chatCodeKeys);
        auto oldTween = std::move(chatCodeTween);
        chatCodeBoxes.clear();
        chatCodeHits.clear();
        chatCodeWords.clear();
        chatCodeKeys.clear();
        chatCodeTween.clear();
        for (auto& line : lines)
            if (line.code >= 0) {
                if (int(chatCodeBoxes.size()) <= line.code) {
                    chatCodeBoxes.resize(line.code + 1);
                    chatCodeWords.resize(line.code + 1);
                    chatCodeKeys.resize(line.code + 1);
                    chatCodeTween.resize(line.code + 1);
                    chatCodeKeys[line.code] = line.codeKey;
                    chatCodeWords[line.code] = line.text;
                    auto old = std::find(oldKeys.begin(), oldKeys.end(), line.codeKey);
                    if (old != oldKeys.end())
                        chatCodeTween[line.code] = oldTween[std::size_t(old - oldKeys.begin())];
                }
                Box b{h.x + line.x, h.y + line.y - offset, line.w, RuntimeFontSize(cfg.scale)};
                chatCodeBoxes[line.code] = b;
                chatCodeHits.push_back({b, line.code});
            }
    }
    bool ChatOverflow(const Settings& cfg) const {
        return chatContentHeight > ChatHistory(cfg).h;
    }
    Box ChatScrollTrack(const Settings& cfg) const {
        auto b = ChatHistory(cfg);
        float s = cfg.scale;
        return {b.x + b.w - 5 * s, b.y + 10 * s, 5 * s, std::max(1.f, b.h - 20 * s)};
    }
    Box ChatScrollThumb(const Settings& cfg) const {
        auto b = ChatScrollTrack(cfg);
        float s = cfg.scale;
        float visible = ChatHistory(cfg).h;
        float h =
            std::clamp(b.h * visible / std::max(visible, chatContentHeight), std::min(10 * s, b.h), b.h);
        float maxOffset = std::max(0.f, chatContentHeight - visible),
              offset = std::max(0.f, maxOffset - chatScroll * 18 * s);
        return {b.x, b.y + (b.h - h) * (maxOffset > 0 ? offset / maxOffset : 0), b.w, h};
    }
    void ScrollChatTo(const Settings& cfg, float py) {
        auto track = ChatScrollTrack(cfg), thumb = ChatScrollThumb(cfg);
        float fraction =
            std::clamp((py - track.y - thumb.h * .5f) / std::max(1.f, track.h - thumb.h), 0.f, 1.f);
        float steps =
            (1 - fraction) * std::max(0.f, chatContentHeight - ChatHistory(cfg).h) / (18 * cfg.scale);
        chatScroll = int(fraction == 0 ? std::ceil(steps) : std::round(steps));
        ++revision;
    }
    void StartChat(State& state) {
        modal = 4;
        SetDropdown(-1);
        picker = baseOpen = false;
        languageActions = -1;
        chatFocus = true;
        chatActive = true;
        caretSeconds = 0;
        state.profileOpen = false;
        hover = -1;
        error.clear();
        ++revision;
    }
    void SendChat(const Settings& cfg) {
        if (chatInput.find_first_not_of(U" \t\r\n") == std::u32string::npos)
            return;
        auto now = std::time(nullptr);
        std::tm date{};
#ifdef _WIN32
        localtime_s(&date, &now);
#else
        localtime_r(&now, &date);
#endif
        char clock[32]{};
        std::strftime(clock, sizeof clock, "[%d.%m.%Y %H:%M]", &date);
        chatMessages.push_back({cfg.userName, chatInput, clock});
        if (chatMessages.size() > 200)
            chatMessages.erase(chatMessages.begin());
        chatInput.clear();
        chatScroll = 0;
        ++revision;
    }
    std::u32string chatAuthor = U"Preview";
    void SendChatInput() {
        Settings local;
        local.userName = chatAuthor;
        SendChat(local);
    }
    Box DescriptionBox(const Settings& cfg) const {
        int row = DescriptionRow();
        if (row < 0)
            return {};
        if (row == 901) {
            auto item = ChatButton(cfg, true);
            float s = cfg.scale, w = std::min(chatTipWidth * s, float(viewportW) - 6 * s),
                  h = RuntimeFontSize(s) + 20 * s;
            return {std::trunc(
                        std::clamp(item.x + item.w + 15 * s, 3 * s, std::max(3 * s, viewportW - w - 3 * s))),
                    std::trunc(std::clamp(item.y + (item.h - h) * .5f, 3 * s,
                                          std::max(3 * s, viewportH - h - 3 * s))),
                    w, h};
        }
        auto item = Layout(cfg).rows[row];
        float s = cfg.scale, w = std::min(tipWidths[row - 6] * s, float(viewportW) - 20 * s),
              h = tipHeights[row - 6] * s;
        float xx = item.x + item.w + 15 * s;
        return {std::trunc(std::clamp(xx, 3 * s, std::max(3 * s, viewportW - w - 3 * s))),
                std::trunc(
                    std::clamp(item.y + (item.h - h) * .5f, 3 * s, std::max(3 * s, viewportH - h - 3 * s))),
                w, h};
    }
    Box LanguageActions(const Settings& cfg) const {
        if (languageActions < 0)
            return {};
        auto row = OptionBox(cfg, languageActions);
        float s = cfg.scale, w = languageActionWidth * s, h = (2 * ItemUnits(s) + 21) * s;
        auto trigger = LanguageActionBox(cfg, languageActions, false);
        float px = languageActionX >= 0 ? languageActionX : trigger.x + trigger.w * .5f + 1,
              py = languageActionY >= 0 ? languageActionY : row.y + row.h * .5f + 1;
        return ProfilePixelBox({std::clamp(px, 3 * s, std::max(3 * s, viewportW - w - 3 * s)),
                                std::clamp(py, 3 * s, std::max(3 * s, viewportH - h - 3 * s)), w, h});
    }
    Box LanguageActionItem(const Settings& cfg, bool remove) const {
        auto b = LanguageActions(cfg);
        return {b.x + 7 * cfg.scale, b.y + (remove ? ItemUnits(cfg.scale) + 14 : 7) * cfg.scale,
                b.w - 14 * cfg.scale, ItemUnits(cfg.scale) * cfg.scale};
    }
    Color ModalCloseFill(const Settings& cfg) const {
        auto c = CurrentPalette(cfg)[33];
        c.a *= .4f * modalCloseFill.value;
        return c;
    }
    Color ModalCloseInk(const Settings& cfg) const {
        auto c = CurrentPalette(cfg)[30];
        c.a *= .7f + .3f * modalCloseInk.value;
        return c;
    }
    Box FormCaret(const Settings& cfg, int i, float advance) const {
        auto f = FormField(cfg, i);
        return {std::floor(f.x + 12 * cfg.scale * cfg.scale + advance), f.y + 6 * cfg.scale * cfg.scale + .5f,
                1, std::max(1.f, RuntimeFontSize(cfg.scale) - 2)};
    }
    Box ModalClose(const Settings& cfg) const {
        auto b = ModalBox(cfg);
        float h = modal == 1 ? FormHeight(cfg) : 13 * cfg.scale + 12 * cfg.scale * cfg.scale;
        return {b.x + b.w - 14 * cfg.scale - h, b.y + 7 * cfg.scale, h, h};
    }

    void SetMenuLayout(const menu::Layout& l) {
        anchorLayout = l;
        if (menuBounds.x != l.outer.x || menuBounds.y != l.outer.y || menuBounds.w != l.outer.w ||
            menuBounds.h != l.outer.h) {
            menuBounds = l.outer;
            anchorDirty = true;
            ++revision;
        }
    }
    float AboutAlpha() const {
        return std::clamp(aboutTween.value, 0.f, 1.f);
    }
    void StartAbout() {
        modal = 3;
        SetDropdown(-1);
        picker = baseOpen = false;
        aboutClosing = false;
        aboutTween = {};
        aboutTween.target = 1;
        aboutTween.elapsed = 0;
        aboutLinkTween = {};
        error.clear();
        ++revision;
    }
    void DismissAbout(State& state) {
        aboutClosing = true;
        aboutTween.Tick(0, 0);
        state.profileOpen = false;
        CancelPress();
        ++revision;
    }
    bool Visible(int row) const {
        return row >= 0 && row < 11 && (row != 8 || developerVisible);
    }
    static bool Enabled(int row) {
        return row >= 0 && row < 11;
    }
    std::u32string Label(const std::string& key) const {
        if (key == "menu_user_synchronization_tooltip") {
            if (languages.selected >= 0 && languages.selected < int(languages.entries.size()) &&
                languages.entries[std::size_t(languages.selected)].shortName == "ru")
                return U"Показывает AT в таблице для пользователей с включённой синхронизацией. Отправляет "
                       U"запросы игрокам матча через Steam. Скины не передаются.";
            return U"Shows NL in the scoreboard for users with Synchronization enabled. Sends presence "
                   U"requests to players in the match through Steam. No skins are shared.";
        }
        return languages.Label(key);
    }

    void Measure(Fonts& fonts, const Settings& cfg) {
        fontSize = fonts.PixelHeight(0, 13 * cfg.scale);
        fontSizeScale = cfg.scale;
        chatAuthor = cfg.userName;
        pickerMetrics = MeasurePickerFormat(fonts, cfg.scale, pickerMode);
        pickerMetricsScale = cfg.scale;
        SetSwatchColor(CurrentPalette(cfg)[31]);
        if (modal == 1)
            for (int i = 0; i < 3; ++i)
                formEditors[i].Measure(fonts, 13 * cfg.scale, fields[i],
                                       std::max(1.f, FormField(cfg, i).w - 24 * cfg.scale * cfg.scale), true,
                                       0);
        chatTipWidth =
            (std::trunc(fonts.NativeTextSize(0, 13 * cfg.scale, Label("window_chat_sendfriendcode")).w +
                        .95f) +
             20 * cfg.scale) /
            cfg.scale;
        chatFriendWidth =
            std::trunc(fonts.NativeTextSize(3, 13 * cfg.scale, U"\uf064").w + .95f) / cfg.scale + 24;
        chatSendWidth =
            (std::trunc(fonts.NativeTextSize(3, 13 * cfg.scale, U"\uf1d8").w + .95f) +
             std::trunc(fonts.NativeTextSize(0, 13 * cfg.scale, Label("window_chat_sendmessage")).w + .95f)) /
                cfg.scale +
            36;
        if (modal == 4) {
            float oldHeight = chatContentHeight;
            auto history = ChatHistory(cfg);
            ChatLines(fonts, cfg, history.w, chatContentHeight);
            if (ChatOverflow(cfg))
                ChatLines(fonts, cfg, history.w - 15 * cfg.scale, chatContentHeight);
            MeasureChatCodes(fonts, cfg);
            MeasureChatInput(fonts, cfg);
            if (oldHeight != chatContentHeight)
                ++revision;
        }
        auto hex = ColorFieldText(cfg, 0);
        if (pickerMode == 2 && pickerField == 0)
            hex = colorInput;
        while (!hex.empty() && (hex.front() == U'#' || hex.front() == U' ' || hex.front() == U'\t'))
            hex.erase(hex.begin());
        hexHashWidth = std::trunc(fonts.Width(1, 12 * cfg.scale, U"#") + .95f) / cfg.scale;
        hexWidthTarget =
            18 + hexHashWidth + 1 + 12 + std::trunc(fonts.Width(1, 12 * cfg.scale, hex) + .95f) / cfg.scale;
        if (picker) {
            auto col = CurrentPalette(cfg)[31];
            char rgba[9]{};
            std::snprintf(rgba, sizeof rgba, "%08X", ColorKey(col));
            hexWidthTween.Observe(hexWidthTarget, widthColor != rgba);
            widthColor = rgba;
        }
        for (int row : {6, 7}) {
            std::u32string result, line, word;
            float widest = fonts.Width(2, 13 * cfg.scale, Label(ProfileKeys[row]));
            int lines = 0;
            auto flush = [&]() {
                widest = std::max(widest, fonts.Width(0, 13 * cfg.scale, line));
                result += line + U"\n";
                line.clear();
                ++lines;
            };
            auto append = [&]() {
                if (!line.empty() && fonts.Width(0, 13 * cfg.scale, line + U" " + word) > 350 * cfg.scale)
                    flush();
                if (!line.empty() && !word.empty())
                    line += U" ";
                line += word;
                word.clear();
            };
            for (char32_t cp : Label(std::string(ProfileKeys[row]) + "_tooltip")) {
                if (cp == U' ' || cp == U'\n') {
                    append();
                    if (cp == U'\n')
                        flush();
                } else
                    word += cp;
            }
            append();
            if (!line.empty())
                flush();
            const float F = fontSize / cfg.scale;
            float th = 20 + F + 10 + F * float(lines), tw = 20 + widest / cfg.scale;
            if (result != tipLines[row - 6] || tipWidths[row - 6] != tw || tipHeights[row - 6] != th) {
                tipLines[row - 6] = result;
                tipHeights[row - 6] = th;
                tipWidths[row - 6] = tw;
                ++revision;
            }
        }

        float intrinsic = 0;
        auto languageOptions = Options(0);
        for (std::size_t i = 0; i < languageOptions.size(); ++i) {
            bool decorated = i == languages.entries.size() ||
                             (i < languages.entries.size() && languages.entries[i].custom);
            float label = std::trunc(
                fonts.NativeTextSize(0, 13 * cfg.scale, SelectableLabel(languageOptions[i])).w + .95f);
            intrinsic = std::max(intrinsic, label + 24 * cfg.scale + (decorated ? 32 * cfg.scale : 0));
        }
        float lw = (std::trunc(intrinsic) + 14 * cfg.scale) / cfg.scale;
        if (languageWidth != lw) {
            languageWidth = lw;
            ++revision;
        }
        float actionWidth =
            70 + std::max(std::trunc(fonts
                                         .NativeTextSize(0, 13 * cfg.scale,
                                                         SelectableLabel(Label("menu_user_language_edit")))
                                         .w +
                                     .95f),
                          std::trunc(fonts
                                         .NativeTextSize(0, 13 * cfg.scale,
                                                         SelectableLabel(Label("menu_user_language_delete")))
                                         .w +
                                     .95f)) /
                     cfg.scale;
        if (actionWidth != languageActionWidth) {
            languageActionWidth = actionWidth;
            ++revision;
        }
        float width =
            std::trunc(fonts.Width(0, 13 * cfg.scale, Label("menu_user_license_renew")) + .95f) / cfg.scale;
        if (width != renewTextWidth) {
            renewTextWidth = width;
            ++revision;
        }
    }
    void ApplyLanguage(Settings& cfg) const {
        for (std::size_t i = 0; i < Tabs.size(); ++i)
            cfg.captions[i] = Label(Tabs[i].key);
    }
    void Storage(const std::filesystem::path& dir) {
        languages.Load(dir);
        ++revision;
    }
    void CancelPress() {
        pressed = false;
        held = -1;
        highSurrogate = 0;
    }
    void Close(State& state) {
        languageActions = -1;
        pickerField = -1;
        pickerModes = false;
        hoverSeconds = 0;
        descriptionOwner = -1;
        tipTween = {};
        open = false;
        submenuWindows.clear();
        dropdown = -1;
        held = hover = -1;
        pressed = false;
        modal = 0;
        picker = baseOpen = false;
        state.profileOpen = false;
        aboutClosing = false;
        aboutTween = {};
        ++revision;
    }
    void Escape(State& state) {
        if (modal == 3) {
            DismissAbout(state);
            return;
        }
        if (modal == 4 || modal == 5) {
            Close(state);
            return;
        }
        if (languageActions >= 0)
            languageActions = -1;
        else if (modal) {
            modal = 0;
            baseOpen = false;
        } else if (picker)
            picker = false;
        else if (dropdown >= 0) {
            hoverSuppressedRow = dropdown;
            SetDropdown(-1);
        } else
            Close(state);
        CancelPress();
        ++revision;
    }
    ProfilePopupLayout Layout(const Settings& cfg) const {
        const float s = cfg.scale, w = 230 * s, font = RuntimeFontSize(s), pad = 7 * s, rowH = font + 2 * pad;
        ProfilePopupLayout p;
        p.panel = {x, y, w, 0};
        float oy = y - scroll;

        const float headerH = std::max(40 * s, 3 * font) + 2 * pad;
        p.header = {x + pad, oy + pad, w - 2 * pad, headerH};
        p.avatar = {p.header.x + 12 * s, p.header.y + pad, 40 * s, 40 * s};
        p.renew = {p.avatar.x + p.avatar.w + 10 * s - 6 * s, p.avatar.y + 2 * font, (renewTextWidth + 12) * s,
                   font};
        float cy = p.header.y + headerH;
        auto separator = [&](int index) {
            cy += 3 * s;
            p.dividers[index] = {x + pad + 12 * s, cy, w - 2 * (pad + 12 * s), s};
            cy += 4 * s;
        };
        separator(0);
        for (int i = 0; i < 11; ++i) {
            if (i == 6)
                separator(1);
            if (i == 9)
                separator(2);
            if (!Visible(i))
                continue;
            p.rows[i] = {x + pad, cy, w - 2 * pad, rowH};
            cy += rowH;
        }
        p.fullHeight = cy - oy + pad;
        p.panel.h = std::min(p.fullHeight, std::max(1.f, float(viewportH) - 20.f));
        auto style = p.rows[5];
        float right = style.x + style.w - 12 * s;

        p.swatch = {right - 16 * s, style.y + (style.h - 16 * s) * .5f, 16 * s, 16 * s};

        p.theme = {right - (font + 6 * s) - 20 * s, style.y + (style.h - 20 * s) * .5f, 20 * s, 20 * s};

        auto sync = p.rows[7];
        float center = sync.y + sync.h * .5f, frac = center - std::trunc(center), half = SyncNominal(s) * .5f;
        p.sync = {sync.x + sync.w - 12 * s - 32 * s, center - half + frac, 32 * s, 2 * half - 2 * frac};
        return p;
    }

    float RuntimeFontSize(float s) const {
        return fontSize > 0 && fontSizeScale == s
                   ? fontSize
                   : std::ceil(13 * s * 2189 / 2048.f) + std::ceil(13 * s * 600 / 2048.f);
    }
    float SyncNominal(float s) const {
        return RuntimeFontSize(s) + 2 * s;
    }
    float ItemUnits(float s) const {
        return RuntimeFontSize(s) / s + 14;
    }
    float ChatHeaderH(float s) const {
        return RuntimeFontSize(s) + 7 * s;
    }
    float LayerOpacity(int layer) const {
        if (layer == 1 || layer >= 8) {
            auto it = submenuWindows.find(SubmenuRow(layer));
            if (it != submenuWindows.end())
                return std::clamp(it->second.alpha.value, 0.f, 1.f);
        }
        return layer == 6                 ? DescriptionAlpha()
               : layer == 3 && modal == 3 ? AboutAlpha()
               : layer == 3 && modal == 5 ? std::clamp(extensionsTween.value, 0.f, 1.f)
                                          : 1.f;
    }
    float BackdropSkipTop(const Settings&, int) const {
        return 0.f;
    }
    Color LayerShadowColor(const Settings& cfg, int layer) const {
        auto col = CurrentPalette(cfg)[38];
        col.a *= LayerOpacity(layer);
        return col;
    }

    Box ChatHeaderFill(const Settings& cfg) const {
        auto b = ChatBox(cfg);
        b.h = ChatHeaderH(cfg.scale) - cfg.scale;
        return b;
    }
    Box ChatHeaderSeparator(const Settings& cfg) const {
        auto b = ChatBox(cfg);
        return {b.x, b.y + ChatHeaderH(cfg.scale) - cfg.scale, b.w, cfg.scale};
    }
    float ChatComposerH(float s) const {
        return RuntimeFontSize(s) + 12 * s;
    }
    Box SyncDot(const Settings& cfg) const {
        auto p = Layout(cfg);
        float s = cfg.scale, h = SyncNominal(s), r = h * .5f - 2 * s,
              cx = p.sync.x + h * .5f + (p.sync.w - h) * syncTween.value,
              cy = p.rows[7].y + p.rows[7].h * .5f;
        return {cx - r, cy - r, 2 * r, 2 * r};
    }
    void Clamp(const Settings& cfg) {
        if (open && (anchorDirty || anchorScale != cfg.scale)) {
            auto b = ProfileBox(anchorLayout, cfg.scale);
            x = b.x + b.w - 5 * cfg.scale;
            y = b.y + (b.h - Layout(cfg).panel.h) * .5f;
            anchorScale = cfg.scale;
            anchorDirty = false;
        }
        auto p = Layout(cfg);
        scroll = std::clamp(scroll, 0.f, std::max(0.f, p.fullHeight - p.panel.h));
        float safe = 3 * cfg.scale;
        float minX = viewportW > 2 * safe ? std::min(safe, std::max(0.f, viewportW - p.panel.w)) : 0.f,
              minY = viewportH > 2 * safe ? std::min(safe, std::max(0.f, viewportH - p.panel.h)) : 0.f;
        x = std::clamp(x, minX, std::max(minX, viewportW - p.panel.w - safe));
        y = std::clamp(y, minY, std::max(minY, viewportH - p.panel.h - safe));
        x = std::trunc(x);
        y = std::trunc(y);
    }
    void Open(const menu::Layout& l, const Settings& cfg, State& state, int w, int h) {
        pointerKnown = false;
        hoverSuppressedRow = -1;
        viewportW = w;
        viewportH = h;
        SetMenuLayout(l);
        auto b = ProfileBox(l, cfg.scale);
        open = true;
        submenuWindows.clear();
        dropdown = -1;
        hover = held = -1;
        rowTween = {};
        rowTextTween = {};
        themeFillTween = {};
        themeTextTween = {};
        modalCloseFill = {};
        modalCloseInk = {};
        languageButtonFill.clear();
        languageButtonInk.clear();
        if (synchronization)
            rowTextTween[7].value = rowTextTween[7].target = rowTextTween[7].from = 1;
        renewTween = {};
        SetSwatchColor(CurrentPalette(cfg)[31], true);
        scroll = 0;
        initialScale = cfg.scale;
        x = b.x + b.w - 5 * cfg.scale;
        y = b.y + (b.h - Layout(cfg).panel.h) * .5f;
        Clamp(cfg);
        state.profileOpen = true;
        ++revision;
    }

    static std::u32string SelectableLabel(const std::u32string& label) {
        auto n = label.find(U'\n'), id = label.find(U"##");
        return label.substr(0, std::min(n, id));
    }
    Color LanguageTextColor(const Settings& cfg, int i) const {
        auto pal = CurrentPalette(cfg);
        return Mix(pal[14], pal[2],
                   i >= 0 && i < int(optionText.size()) ? optionText[i].value
                                                        : (i == languages.selected ? 1.f : 0.f));
    }
    Box LanguageContentClip(const Settings& cfg) const {
        auto b = Dropdown(cfg);
        float border = cfg.scale, inset = std::max(border, std::trunc(7 * cfg.scale * .5f));
        float x0 = std::trunc(b.x + .5f + inset), y0 = std::trunc(b.y + .5f + border),
              x1 = std::trunc(b.x + b.w + .5f - inset), y1 = std::trunc(b.y + b.h + .5f - border);
        return {x0, y0, std::max(0.f, x1 - x0), std::max(0.f, y1 - y0)};
    }
    std::vector<std::u32string> Options(int row) const {
        if (row == 0) {
            std::vector<std::u32string> a;
            for (auto& l : languages.entries)
                a.push_back(DecodeUTF8(l.localizedName) + U" (" + DecodeUTF8(l.name) + U")");
            a.push_back(Label("menu_user_language_new"));
            return a;
        }
        if (row == 1)
            return {U"Auto", U"75%", U"100%", U"125%", U"150%", U"175%", U"200%"};
        if (row == 2 || row == 3)
            return {U"Auto", U"100%", U"125%", U"150%", U"175%", U"200%"};
        if (row == 4)
            return {Label("menu_user_units_auto"), Label("menu_user_units_metric"),
                    Label("menu_user_units_imperial")};
        if (row == 6)
            return {Label("menu_user_safemode_disabled"), Label("menu_user_safemode_automatic"),
                    Label("menu_user_safemode_forcedon")};
        return {};
    }
    int VisibleLanguageCount() const {
        return std::min(9, int(languages.entries.size()));
    }
    int LanguageGroupGap(int i) const {
        bool official = false;
        for (int n = languageScroll; n < std::min(i, int(languages.entries.size())); ++n)
            if (!languages.entries[n].custom)
                official = true;
        return official && i < int(languages.entries.size()) && languages.entries[i].custom ? 7 : 0;
    }
    float OptionY(int i, float s) const {
        float yy = 7;
        bool groupGap = false;
        int begin = dropdown == 0 ? languageScroll : 0;
        for (int n = begin; n <= i; ++n) {
            if (dropdown == 0 && !groupGap && LanguageGroupGap(n)) {
                yy += 7;
                groupGap = true;
            }
            if (n == i)
                break;
            yy += ItemUnits(s);
        }
        return yy;
    }
    Box Dropdown(const Settings& cfg) const {
        if (dropdown < 0)
            return {};
        auto row = Layout(cfg).rows[dropdown];
        float s = cfg.scale, w = (dropdown == 0 ? languageWidth : 140.f) * s;
        int n = dropdown == 0 ? VisibleLanguageCount() + 1 : int(Options(dropdown).size());
        float h = (14 + ItemUnits(s) * float(n) +
                   (dropdown == 0 && std::any_of(languages.entries.begin(), languages.entries.end(),
                                                 [](const LanguageRecord& item) { return item.custom; })
                        ? 7
                        : 0)) *
                  s;
        if (dropdown == 0)
            h = std::trunc((RuntimeFontSize(s) + 14 * s) * n +
                           (std::any_of(languages.entries.begin(), languages.entries.end(),
                                        [](const LanguageRecord& item) { return item.custom; })
                                ? 7 * s
                                : 0)) +
                14 * s;
        h = std::min(h, std::max(1.f, float(viewportH) - 20.f));
        return ProfilePixelBox(
            {std::clamp(row.x + row.w + 7 * s, 0.f, std::max(0.f, viewportW - w - 10 * s)),
             std::clamp(row.y + row.h * .5f - h * .25f, 0.f, std::max(0.f, viewportH - h - 10 * s)), w, h});
    }
    Box ContentClip(const Settings& cfg, int layer) const {
        if (auto child = ClosingSubmenu(layer))
            return child->ContentClip(cfg, 1);
        return layer == 1 && dropdown == 0 ? LanguageContentClip(cfg) : ChatContentClip(cfg);
    }
    Box OptionBox(const Settings& cfg, int i) const {
        auto b = Dropdown(cfg);
        int visual =
            dropdown == 0 && i == int(languages.entries.size()) ? languageScroll + VisibleLanguageCount() : i;
        return {b.x + 7 * cfg.scale, b.y + OptionY(visual, cfg.scale) * cfg.scale, b.w - 14 * cfg.scale,
                ItemUnits(cfg.scale) * cfg.scale};
    }

    Box LanguageActionBox(const Settings& cfg, int i, bool) const {
        auto b = OptionBox(cfg, i);
        float side = 20 * cfg.scale;
        return {b.x + b.w - 32 * cfg.scale, b.y + (b.h - side) * .5f, side, side};
    }
    Box ModalBox(const Settings& cfg) const {
        if (modal == 3)
            return menuBounds;
        if (modal == 4)
            return ChatBox(cfg);
        float s = cfg.scale, w = std::min(350 * s, std::max(1.f, menuBounds.w - 20 * s)),
              h = modal == 1 ? 119 * s + 5 * FormHeight(cfg) : 160 * s;
        if (!error.empty())
            h += 39 * s;
        return ProfilePixelBox(
            {menuBounds.x + (menuBounds.w - w) * .5f, menuBounds.y + (menuBounds.h - h) * .5f, w, h});
    }
    AboutLayout About(const Settings& cfg, float badgeTextWidth = 0) const {
        const float s = cfg.scale, font = RuntimeFontSize(s), fpY = 3 * s, item = 7 * s, sep = s,
                    padX = 14 * s, padY = 7 * s;
        AboutLayout a{};
        a.overlay = menuBounds;
        float logoH = 36 * s, logoW = logoH * (338.3f / 48.5f);
        a.logo = {menuBounds.x + (menuBounds.w - logoW) * .5f, menuBounds.y + (menuBounds.h - logoH) * .2f,
                  logoW, logoH};
        float badgeW = badgeTextWidth + 12 * s;
        a.badge = {menuBounds.x + (menuBounds.w - badgeW) * .5f, a.logo.y + logoH + 5 * s, badgeW,
                   font + 2 * fpY};
        const float panelW = 300 * s, rowH = font + 2 * fpY, pitch = rowH + 2 * item + sep;
        a.account = {menuBounds.x + (menuBounds.w - panelW) * .5f, a.badge.y + a.badge.h + 15 * s, panelW,
                     2 * padY + 4 * rowH + 3 * (2 * item + sep)};
        for (int i = 0; i < 4; ++i) {
            a.rows[i] = {a.account.x + padX, a.account.y + padY + i * pitch, panelW - 2 * padX, rowH};
            if (i < 3)
                a.separators[i] = {a.rows[i].x, a.rows[i].y + rowH + item, a.rows[i].w, sep};
        }
        a.links = {a.account.x, a.account.y + a.account.h + 17 * s, panelW,
                   2 * padY + 2 * rowH + 2 * item + sep};
        for (int i = 0; i < 2; ++i)
            a.linkRows[i] = {a.links.x + padX, a.links.y + padY + i * pitch, panelW - 2 * padX, rowH};
        a.separators[3] = {a.links.x + padX, a.linkRows[0].y + rowH + item, panelW - 2 * padX, sep};
        a.footer = {menuBounds.x, a.links.y + a.links.h + 17 * s, menuBounds.w, font};
        return a;
    }
    Box AboutLogoBox(const Settings& cfg) const {
        return About(cfg).logo;
    }
    Box AboutRow(const Settings& cfg, int i) const {
        return About(cfg).rows.at(std::size_t(i));
    }
    Box AboutLink(const Settings& cfg, int i) const {
        return About(cfg).linkRows.at(std::size_t(i));
    }
    Box AboutLinkHit(const Settings& cfg, int i) const {
        auto a = About(cfg);
        auto b = a.linkRows.at(std::size_t(i));
        return {a.links.x + cfg.scale, b.y - 6 * cfg.scale, a.links.w - 2 * cfg.scale, b.h + 12 * cfg.scale};
    }
    Box FormField(const Settings& cfg, int i) const {
        auto b = ModalBox(cfg);
        float s = cfg.scale;
        float inner = b.w - 28 * s;
        float width = std::trunc(inner / 2.2f) + 24 * s * s, fh = FormHeight(cfg);
        return {b.x + b.w - 14 * s - width, b.y + 22 * s + fh + i * (fh + 15 * s), std::max(1.f, width), fh};
    }
    Box ModalButton(const Settings& cfg, bool confirm) const {
        auto b = ModalBox(cfg);
        float s = cfg.scale, w = 75 * s;
        return {b.x + b.w - 14 * s - (confirm ? w : 2 * w + 5 * s), b.y + b.h - 37 * s, w, 30 * s};
    }

    std::vector<int> BaseLanguages() const {
        std::vector<int> ids;
        for (int i = 0; i < int(languages.entries.size()); ++i)
            if (!languages.entries[i].custom)
                ids.push_back(i);
        return ids;
    }
    Box BaseDropdown(const Settings& cfg) const {
        auto f = FormField(cfg, 3);
        float h = (12 + ItemUnits(cfg.scale) * std::min(6, int(BaseLanguages().size()))) * cfg.scale;
        return ProfilePixelBox(
            {f.x, std::clamp(f.y - h * .5f, 10.f, std::max(10.f, viewportH - h - 10 * cfg.scale)), f.w, h});
    }

    float PickerFont(const Settings& cfg) const {
        return pickerMetricsScale == cfg.scale ? pickerMetrics.font : 12 * cfg.scale;
    }
    float PickerFooterY(const Settings& cfg) const {
        return PickerBox(cfg).y + 292 * cfg.scale;
    }
    Box PickerBox(const Settings& cfg) const {
        auto row = Layout(cfg).rows[5];
        float s = cfg.scale, w = 265 * s,
              h = 308 * s + PickerFont(cfg) +
                  (pickerSaved.empty() ? 0.f : (8.f + 27.f * std::ceil(float(pickerSaved.size()) / 9)) * s);
        return ProfilePixelBox(
            {std::clamp(row.x + row.w + 10 * s, 3 * s, std::max(3 * s, viewportW - w - 3 * s)),
             std::clamp(row.y, 3 * s, std::max(3 * s, viewportH - h - 3 * s)), w, h});
    }
    Box SVBox(const Settings& cfg) const {
        auto b = PickerBox(cfg);
        float s = cfg.scale;
        return {b.x + 10 * s, b.y + 10 * s, 245 * s, 245 * s};
    }
    Box SVMarker(const Settings& cfg) const {
        auto b = SVBox(cfg);
        float r = 8 * cfg.scale;
        float cx = std::clamp(std::round(b.x + saturation * b.w), b.x + 2, b.x + b.w - 2),
              cy = std::clamp(std::round(b.y + (1 - value) * b.h), b.y + 2, b.y + b.h - 2);
        return {cx - r, cy - r, 2 * r, 2 * r};
    }
    Box HueBox(const Settings& cfg) const {
        auto b = SVBox(cfg);
        return {b.x, b.y + b.h + 12 * cfg.scale, b.w, 8 * cfg.scale};
    }
    Box PickerModeBox(const Settings& cfg) const {
        auto b = PickerBox(cfg);
        float s = cfg.scale;
        return {b.x + 10 * s, PickerFooterY(cfg), pickerMetricsScale == s ? pickerMetrics.opener : 49 * s,
                PickerFont(cfg) + 6 * s};
    }
    Box PickerValueBox(const Settings& cfg, int i) const {
        auto b = PickerModeBox(cfg);
        float s = cfg.scale, right = PickerSave(cfg).x - 3 * s;
        if (pickerMode == 2) {
            float w = hexWidthTween.value * s;
            return {right - w, b.y, w, b.h};
        }
        float w = pickerMetricsScale == s ? pickerMetrics.component : 33 * s;
        return {right - 3 * w - 6 * s + i * (w + 3 * s), b.y, w, b.h};
    }
    Box PickerHexTextBox(const Settings& cfg) const {
        auto b = PickerValueBox(cfg, 0);
        float offset = (24 + hexHashWidth + 1) * cfg.scale;
        b.x += offset;
        b.w -= offset + 6 * cfg.scale;
        b.w += .5f;
        return b;
    }
    Box PickerValueSwatch(const Settings& cfg) const {
        auto b = PickerValueBox(cfg, 0);
        return {b.x + 6 * cfg.scale, b.y + (b.h - 12 * cfg.scale) * .5f, 12 * cfg.scale, 12 * cfg.scale};
    }
    Box PickerSave(const Settings& cfg) const {
        auto b = PickerBox(cfg);
        float h = PickerFont(cfg) + 6 * cfg.scale;
        return {b.x + b.w - 10 * cfg.scale - h, PickerFooterY(cfg), h, h};
    }
    Box PickerSavedBox(const Settings& cfg, int i) const {
        auto b = PickerBox(cfg);
        return {b.x + (10 + 27 * ((int(pickerSaved.size()) - 1 - i) % 9)) * cfg.scale,
                PickerFooterY(cfg) + PickerFont(cfg) +
                    (21 + 27 * ((int(pickerSaved.size()) - 1 - i) / 9)) * cfg.scale,
                20 * cfg.scale, 20 * cfg.scale};
    }
    static std::uint32_t ColorKey(Color col) {
        return std::uint32_t(Canvas::Byte(col.r)) | (std::uint32_t(Canvas::Byte(col.g)) << 8) |
               (std::uint32_t(Canvas::Byte(col.b)) << 16) | (std::uint32_t(Canvas::Byte(col.a)) << 24);
    }

    void RememberColor(Color col) {
        auto key = ColorKey(col);
        pickerSaved.erase(std::remove_if(pickerSaved.begin(), pickerSaved.end(),
                                         [&](Color c) { return ColorKey(c) == key; }),
                          pickerSaved.end());
        pickerSaved.push_back(col);
        ++revision;
    }
    Box PickerReset(const Settings&) const {
        return {};
    }
    Box PickerModesBox(const Settings& cfg) const {
        float s = cfg.scale;
        auto m = pickerMetrics;
        float w = pickerMetricsScale == s ? m.width : 100 * s, h = 3 * (PickerFont(cfg) + 14 * s) + 14 * s;
        return PickerCompactPopup(PickerModeBox(cfg), w, h, s, float(viewportW), float(viewportH));
    }
    Box PickerModeItem(const Settings& cfg, int i) const {
        auto b = PickerModesBox(cfg);
        float s = cfg.scale, R = PickerFont(cfg) + 14 * s;
        return {b.x + 7 * s, b.y + 7 * s + i * R, b.w - 14 * s, R};
    }
    void SyncColor(const Settings& cfg) {
        auto col = CurrentPalette(cfg)[31];
        SetSwatchColor(col);
        float mx = std::max({col.r, col.g, col.b}), mn = std::min({col.r, col.g, col.b}), d = mx - mn;
        value = mx;
        saturation = mx ? d / mx : 0;
        if (d) {
            float h = mx == col.r   ? (col.g - col.b) / d
                      : mx == col.g ? 2 + (col.b - col.r) / d
                                    : 4 + (col.r - col.g) / d;
            hue = std::fmod(h / 6 + 1, 1.f);
        }
    }
    std::u32string ColorFieldText(const Settings& cfg, int i) const {
        auto col = CurrentPalette(cfg)[31];
        if (pickerMode == 2) {
            char hex[16]{};
            std::snprintf(hex, sizeof hex, "#%02X%02X%02X", int(std::round(col.r * 255)),
                          int(std::round(col.g * 255)), int(std::round(col.b * 255)));
            return ASCII(hex);
        }
        float v = pickerMode == 0 ? (i == 0   ? col.r
                                     : i == 1 ? col.g
                                              : col.b) *
                                        255
                                  : (i == 0   ? hue
                                     : i == 1 ? saturation
                                              : value) *
                                        255;
        return ASCII(std::to_string(int(std::round(v))));
    }
    bool ColorEditKey(int key, bool ctrl = false) {
        if (!picker || pickerField < 0)
            return false;
        if (ctrl && key == 65) {
            colorSelectAll = true;
            caretSeconds = 0;
            ++revision;
            return true;
        }
        if (key == 46) {
            if (colorSelectAll)
                colorInput.clear();
            else if (!colorInput.empty())
                colorInput.pop_back();
            colorSelectAll = false;
            caretSeconds = 0;
            ++revision;
            return true;
        }
        return false;
    }
    void BeginColorInput(const Settings& cfg, int i) {
        caretSeconds = 0;
        pickerField = i;
        colorInput = ColorFieldText(cfg, i);
        colorSelectAll = true;
        ++revision;
    }
    void ApplyColorInput(Settings& cfg) {
        try {
            auto str = EncodeUTF8(colorInput);
            Color col = CurrentPalette(cfg)[31];
            if (pickerMode == 2) {
                if (!str.empty() && str[0] == '#')
                    str.erase(0, 1);
                if (str.size() != 6)
                    return;
                std::size_t end = 0;
                auto rgb = std::stoul(str, &end, 16);
                if (end != 6)
                    return;
                col = {float((rgb >> 16) & 255) / 255, float((rgb >> 8) & 255) / 255, float(rgb & 255) / 255,
                       1};
            } else {
                std::size_t end = 0;
                float v = std::stof(str, &end);
                if (end != str.size() || !std::isfinite(v))
                    return;
                if (pickerMode == 0) {
                    v = std::clamp(v, 0.f, 255.f) / 255;
                    if (pickerField == 0)
                        col.r = v;
                    else if (pickerField == 1)
                        col.g = v;
                    else
                        col.b = v;
                } else {
                    if (pickerField == 0)
                        hue = std::clamp(v / 255, 0.f, 1.f);
                    else if (pickerField == 1)
                        saturation = std::clamp(v / 255, 0.f, 1.f);
                    else
                        value = std::clamp(v / 255, 0.f, 1.f);
                    col = ProfileHSV(hue, saturation, value);
                }
            }
            float mx = std::max({col.r, col.g, col.b}), mn = std::min({col.r, col.g, col.b}), delta = mx - mn;
            value = mx;
            saturation = mx > 0 ? delta / mx : 0;
            if (delta > 0) {
                float h = mx == col.r   ? (col.g - col.b) / delta
                          : mx == col.g ? 2 + (col.b - col.r) / delta
                                        : 4 + (col.r - col.g) / delta;
                hue = std::fmod(h / 6 + 1, 1.f);
            }
            cfg.accent = col;
            cfg.customAccent = true;
            SetSwatchColor(col);
            pickerField = -1;
            ++revision;
        } catch (const std::exception&) {
        }
    }
    void EditColor(const Settings& cfg, float px, float py, Settings& out) {
        auto sv = SVBox(cfg), hb = HueBox(cfg);
        if (held == 300) {
            saturation = std::clamp((px - sv.x) / sv.w, 0.f, 1.f);
            value = 1 - std::clamp((py - sv.y) / sv.h, 0.f, 1.f);
        }
        if (held == 301)
            hue = std::clamp((px - hb.x) / hb.w, 0.f, .9999f);
        out.accent = ProfileHSV(hue, saturation, value);
        out.customAccent = true;
        SetSwatchColor(out.accent);
        ++revision;
    }
    int Hit(const Settings& cfg, float px, float py) const {
        if (!open)
            return -1;
        if (modal == 5)
            return -2;
        if (modal == 4) {
            if (ChatHistory(cfg).Contains(px, py))
                for (auto& hit : chatCodeHits)
                    if (hit.first.Contains(px, py))
                        return 10000 + hit.second;
            if (ChatOverflow(cfg) && ChatScrollTrack(cfg).Contains(px, py))
                return 906;
            if (ChatClose(cfg).Contains(px, py))
                return 900;
            if (ChatContentClip(cfg).Contains(px, py) && ChatButton(cfg, false).Contains(px, py))
                return 901;
            if (ChatContentClip(cfg).Contains(px, py) && ChatButton(cfg, true).Contains(px, py))
                return 902;
            if (ChatInputBox(cfg).Contains(px, py))
                return 903;
            if (ChatResize(cfg).Contains(px, py))
                return 905;
            if (ChatTitle(cfg).Contains(px, py))
                return 904;
            return -2;
        }
        if (languageActions >= 0) {
            if (LanguageActionItem(cfg, false).Contains(px, py))
                return 700 + languageActions;
            if (LanguageActionItem(cfg, true).Contains(px, py))
                return 800 + languageActions;
            if (LanguageActions(cfg).Contains(px, py))
                return -2;
        }
        if (modal) {
            if (modal != 3 && ModalClose(cfg).Contains(px, py))
                return 420;
            if (modal == 3) {
                if (aboutClosing || !menuBounds.Contains(px, py))
                    return -2;
                for (int i = 0; i < 2; ++i)
                    if (AboutLinkHit(cfg, i).Contains(px, py))
                        return 430 + i;
                auto a = About(cfg);
                if (a.account.Contains(px, py) || a.links.Contains(px, py))
                    return -2;
                return 420;
            }
            if (baseOpen) {
                auto b = BaseDropdown(cfg);
                auto ids = BaseLanguages();
                for (int i = 0; i < std::min(6, int(ids.size()) - baseScroll); ++i)
                    if (Box{b.x + 6 * cfg.scale, b.y + (6 + ItemUnits(cfg.scale) * i) * cfg.scale,
                            b.w - 12 * cfg.scale, ItemUnits(cfg.scale) * cfg.scale}
                            .Contains(px, py))
                        return 600 + ids[baseScroll + i];
                if (b.Contains(px, py))
                    return -2;
            }
            if (ModalButton(cfg, false).Contains(px, py))
                return 410;
            if (ModalButton(cfg, true).Contains(px, py))
                return 411;
            if (modal == 1)
                for (int i = 0; i < 4; ++i)
                    if (FormField(cfg, i).Contains(px, py))
                        return 400 + i;
            return -2;
        }
        if (picker) {
            if (pickerModes) {
                for (int i = 0; i < 3; ++i)
                    if (PickerModeItem(cfg, i).Contains(px, py))
                        return 320 + i;
                if (PickerModesBox(cfg).Contains(px, py))
                    return -2;
            }
            if (PickerModeBox(cfg).Contains(px, py))
                return 303;
            for (int i = 0; i < (pickerMode == 2 ? 1 : 3); ++i)
                if (PickerValueBox(cfg, i).Contains(px, py))
                    return 310 + i;
            if (SVBox(cfg).Contains(px, py))
                return 300;
            if (HueBox(cfg).Contains(px, py))
                return 301;
            if (PickerSave(cfg).Contains(px, py))
                return 304;
            for (int i = 0; i < int(pickerSaved.size()); ++i)
                if (PickerSavedBox(cfg, i).Contains(px, py))
                    return 340 + i;
            if (PickerBox(cfg).Contains(px, py))
                return -2;
        }
        if (dropdown >= 0) {
            auto a = Options(dropdown);
            for (int i = 0; i < int(a.size()); ++i) {
                if (dropdown == 0 && i < int(languages.entries.size()) &&
                    (i < languageScroll || i >= languageScroll + VisibleLanguageCount()))
                    continue;
                auto b = OptionBox(cfg, i);
                if (!Dropdown(cfg).Contains(px, py))
                    continue;
                if (dropdown == 0 && i < int(languages.entries.size()) && languages.entries[i].custom) {
                    if (LanguageActionBox(cfg, i, false).Contains(px, py))
                        return 1000 + i;
                }
                if (b.Contains(px, py))
                    return 100 + i;
            }
            if (Dropdown(cfg).Contains(px, py))
                return -2;
        }
        auto p = Layout(cfg);
        if (!p.panel.Contains(px, py))
            return -1;
        if (p.renew.Contains(px, py))
            return 200;
        if (p.theme.Contains(px, py))
            return 201;
        if (p.swatch.Contains(px, py))
            return 202;
        for (int i = 0; i < 11; ++i)
            if (Visible(i) && p.rows[i].Contains(px, py))
                return i;
        return -1;
    }
    void Move(const Settings& cfg, float px, float py) {
        if (modal == 1 && held >= 400 && held <= 402) {
            int i = held - 400;
            auto f = FormField(cfg, i);
            formEditors[i].Mouse(px - f.x - 12 * cfg.scale * cfg.scale, true);
            caretSeconds = 0;
            ++revision;
        }
        if (modal == 4 && held == 906) {
            ScrollChatTo(cfg, py);
            return;
        }
        if (modal == 4 && held == 904) {
            auto b = ChatBox(cfg);
            chatX = std::clamp(px - dragX, 0.f, std::max(0.f, viewportW - b.w));
            chatY = std::clamp(py - dragY, 0.f, std::max(0.f, viewportH - b.h));
            ++revision;
        }
        if (modal == 4 && held == 905) {
            auto b = ChatBox(cfg);
            chatW = std::clamp((px - b.x + dragX) / cfg.scale, 300.f,
                               std::max(300.f, (viewportW - b.x) / cfg.scale));
            chatH = std::clamp((py - b.y + dragY) / cfg.scale, 300.f,
                               std::max(300.f, (viewportH - b.y) / cfg.scale));
            ++revision;
        }
        int n = Hit(cfg, px, py);
        if (n != hover) {
            hover = n;
            hoverSeconds = 0;
            ++revision;
        }

        if (n != hoverSuppressedRow)
            hoverSuppressedRow = -1;
        if (open && hostFocused && !modal && !picker && languageActions < 0 && held < 0) {
            auto parent = Layout(cfg).panel;
            bool heading = dropdown >= 0 && pointerKnown &&
                           HeadingToSubmenu(parent, Dropdown(cfg), pointerX, pointerY, px, py);
            if (!heading && HoverSubmenu(n) && Visible(n) && Enabled(n) && n != hoverSuppressedRow) {
                if (dropdown != n) {
                    SetDropdown(n);
                    ++revision;
                }
            } else if (!heading && dropdown >= 0 && n != dropdown && parent.Contains(px, py) &&
                       (n < 100 || n == 200 || n == 201 || n == 202)) {
                SetDropdown(-1);
                ++revision;
            }
        }
        pointerKnown = open && hostFocused && px >= 0 && py >= 0;
        pointerX = px;
        pointerY = py;
    }
    void Tick(float dt) {
        if (!open)
            return;
        TickSubmenus(dt);
        if (modal == 5) {
            float before = extensionsTween.value;
            extensionsTween.Tick(1.f, dt);
            if (before != extensionsTween.value)
                ++revision;
            return;
        }

        auto step = [&](DumpTween& t, float target) {
            float before = t.value;
            t.Tick(target, dt);
            if (before != t.value)
                ++revision;
        };

        const float themeTarget = held == 201 ? 1.f : hover == 201 ? .5f : 0.f;
        step(themeFillTween, themeTarget);
        step(themeTextTween, themeTarget);
        float closeTarget = modal == 1 ? (held == 420 ? 1.f : hover == 420 ? .5f : 0.f) : 0.f;
        step(modalCloseFill, closeTarget);
        step(modalCloseInk, closeTarget);

        pickerSavedTween.resize(pickerSaved.size());
        for (int i = 0; i < int(pickerSaved.size()); ++i)
            step(pickerSavedTween[i], picker && hover == 340 + i ? (held == 340 + i ? 1.f : .5f) : 0.f);
        for (int i = 0; i < 3; ++i)
            step(pickerFieldTween[i], picker ? (pickerField == i ? 1.f : hover == 310 + i ? .5f : 0.f) : 0.f);
        for (int i = 0; i < int(chatCodeTween.size()); ++i)
            step(chatCodeTween[i],
                 modal == 4 && hostFocused && hover == 10000 + i ? (held == 10000 + i ? 1.f : .8f) : 0.f);
        step(chatScrollHover, modal == 4 && hover == 906 ? (held == 906 ? 1.f : .8f) : 0.f);
        for (int i = 0; i < 2; ++i)
            step(languageActionTween[i], languageActions >= 0 && hover == (i ? 800 : 700) + languageActions
                                             ? (held == hover ? 1.f : .5f)
                                             : 0.f);
        step(pickerFormatTween, picker ? (pickerModes    ? 1.f
                                          : hover == 303 ? (held == 303 ? 1.f : .5f)
                                                         : 0.f)
                                       : 0.f);
        step(styleSwatchTween, picker ? 1.f : hover == 202 ? (held == 202 ? 1.f : .5f) : 0.f);
        step(swatchTween, 1);
        step(pickerSaveTween, picker && hover == 304 ? (held == 304 ? 1.f : .5f) : 0.f);
        for (int i = 0; i < 2; ++i) {
            float target =
                modal == 4 && hostFocused && hover == 901 + i ? (held == 901 + i ? 1.f : .5f) : 0.f;
            step(chatButtonTween[i], target);
            step(chatButtonTextTween[i], target);
        }
        step(chatInputTween, modal == 4 && ChatActive() ? (chatFocus ? 1.f : hover == 903 ? .5f : 0.f) : 0.f);
        if (picker) {
            float before = hexWidthTween.value;
            hexWidthTween.Tick(dt);
            if (before != hexWidthTween.value)
                ++revision;
        }
        step(baseTween, baseOpen ? 1.f : hover == 403 ? .5f : 0.f);
        for (int i = 0; i < 2; ++i)
            step(buttonTween[i], held == 410 + i ? 1.f : hover == 410 + i ? .5f : 0.f);
        if (baseOpen) {
            baseOptionFill.resize(languages.entries.size());
            baseOptionText.resize(languages.entries.size());
            for (int i = 0; i < int(languages.entries.size()); ++i) {
                float t = hover == 600 + i ? (held == 600 + i ? 1.f : .5f) : 0.f;
                step(baseOptionFill[i], t);
                step(baseOptionText[i], i == baseLanguage ? 1.f : t);
            }
        }
        for (int i = 0; i < 3; ++i) {
            float target = picker && pickerModes && hover == 320 + i ? (held == 320 + i ? 1.f : .5f) : 0.f;
            step(modeFill[i], target);
            step(modeText[i], i == pickerMode ? 1.f : target);
        }
        if (optionChannel != dropdown) {
            optionChannel = dropdown;
            optionFill.clear();
            optionText.clear();
            languageButtonFill.clear();
            languageButtonInk.clear();
        }
        if (dropdown == 0) {
            languageButtonFill.resize(languages.entries.size());
            languageButtonInk.resize(languages.entries.size());
            for (int i = 0; i < int(languages.entries.size()); ++i) {
                float target = languages.entries[i].custom ? (held == 1000 + i    ? 1.f
                                                              : hover == 1000 + i ? .5f
                                                                                  : 0.f)
                                                           : 0.f;
                step(languageButtonFill[i], target);
                step(languageButtonInk[i], target);
            }
        }
        if (dropdown >= 0) {
            auto count = Options(dropdown).size();
            optionFill.resize(count);
            optionText.resize(count);
            for (int i = 0; i < int(count); ++i) {
                bool child = dropdown == 0 && i < int(languages.entries.size()) &&
                             languages.entries[i].custom && hover == 1000 + i;
                float target = (hover == 100 + i || child)
                                   ? (held == 100 + i || (child && held == 1000 + i) ? 1.f : .5f)
                                   : 0.f;
                step(optionFill[i], target);
                step(optionText[i],
                     dropdown == 0 && i < int(languages.entries.size()) && i == languages.selected ? 1.f
                                                                                                   : target);
            }
        }
        for (int i = 0; i < 3; ++i) {
            float old = fieldTween[i].value;
            fieldTween[i].Tick(modal == 1 ? (field == i ? 1.f : hover == 400 + i ? .5f : 0.f) : 0.f, dt);
            if (old != fieldTween[i].value)
                ++revision;
        }
        bool beforeCaret = CaretVisible();
        caretSeconds += std::max(0.f, dt);
        if (CaretVisible() != beforeCaret)
            ++revision;
        hoverSeconds += std::max(0.f, dt);
        float oldTip = tipTween.value;
        bool tipVisible = DescriptionCandidate() >= 0 && hoverSeconds >= .3f;
        if (tipVisible)
            descriptionOwner = DescriptionCandidate();
        tipTween.Tick(tipVisible ? 1.f : 0.f, dt);
        if (!tipVisible && tipTween.value == 0)
            descriptionOwner = -1;
        if (oldTip != tipTween.value)
            ++revision;
        if (modal == 3) {
            float before = AboutAlpha();
            aboutTween.Tick(aboutClosing ? 0.f : 1.f, dt);
            if (before != AboutAlpha())
                ++revision;
            for (int i = 0; i < 2; ++i) {
                float old = aboutLinkTween[i].value;
                aboutLinkTween[i].Tick(held == 430 + i ? 1.f : hover == 430 + i ? .5f : 0.f, dt);
                if (old != aboutLinkTween[i].value)
                    ++revision;
            }
            if (aboutClosing && AboutAlpha() == 0) {
                open = false;
                modal = 0;
                aboutClosing = false;
                ++revision;
            }
            return;
        }
        for (int i = 0; i < 11; ++i) {

            bool over = hover == i || dropdown == i || (i == 5 && (hover == 201 || hover == 202));
            bool active = over && (held == i || (i == 5 && (held == 201 || held == 202)));
            float target = Visible(i) ? (active ? 1.f : over ? .5f : 0.f) : 0.f;
            float before = rowTween[i].value, oldText = rowTextTween[i].value;
            rowTween[i].Tick(target, dt);
            rowTextTween[i].Tick(i == 7 && synchronization ? 1.f : target, dt);
            if (before != rowTween[i].value || oldText != rowTextTween[i].value)
                ++revision;
        }
        float oldRenew = renewTween.value;
        renewTween.Tick(hover == 200 ? (held == 200 ? 1.f : .5f) : 0.f, dt);
        if (oldRenew != renewTween.value)
            ++revision;
        float b = syncTween.value;
        syncTween.Tick(synchronization ? 1.f : 0.f, dt);
        if (b != syncTween.value)
            ++revision;
    }
    void Wheel(const Settings& cfg, float delta) {
        if (modal == 4) {
            chatScroll = std::clamp(
                chatScroll + int(delta * 3), 0,
                int(std::ceil(std::max(0.f, chatContentHeight - ChatHistory(cfg).h) / (18 * cfg.scale))));
            ++revision;
            return;
        }
        if (baseOpen) {
            baseScroll = std::clamp(baseScroll + int(delta > 0 ? -1 : 1), 0,
                                    std::max(0, int(BaseLanguages().size()) - 6));
        } else if (dropdown == 0) {
            languageScroll = std::clamp(languageScroll + int(delta > 0 ? -1 : 1), 0,
                                        std::max(0, int(languages.entries.size()) - VisibleLanguageCount()));
        } else if (!modal) {
            scroll -= delta * 33 * cfg.scale;
            Clamp(cfg);
        }
        ++revision;
    }
    void Character(char32_t cp) {
        caretSeconds = 0;
        if (modal == 4 && chatFocus && ChatActive()) {
            if (cp == 13) {
                SendChatInput();
                return;
            }
            if (cp == 8) {
                if (!chatInput.empty())
                    chatInput.pop_back();
            } else if (cp >= 32 && cp != 127 && cp <= 0x10ffff && !(cp >= 0xd800 && cp <= 0xdfff)) {
                auto next = chatInput + cp;
                if (EncodeUTF8(next).size() <= 127)
                    chatInput = std::move(next);
            }
            ++revision;
            return;
        }
        if (picker && pickerField >= 0) {
            if (colorSelectAll && (cp == 8 || cp >= 32)) {
                colorInput.clear();
                colorSelectAll = false;
            }
            if (cp == 8) {
                if (!colorInput.empty())
                    colorInput.pop_back();
            } else if ((cp >= U'0' && cp <= U'9') || (cp >= U'a' && cp <= U'f') ||
                       (cp >= U'A' && cp <= U'F') || cp == U'#' || cp == U'.') {
                if (colorInput.size() < 12)
                    colorInput += cp;
            }
            ++revision;
            return;
        }
        if (modal != 1 || field < 0 || field > 2)
            return;
        auto& text = fields[field];
        if (cp == 8)
            formEditors[field].Delete(text, true);
        else
            formEditors[field].Insert(text, std::u32string(1, cp), field == 1 ? 8 : 48);
        error.clear();
        ++revision;
    }
    void UTF16(char16_t c) {
        if (c >= 0xd800 && c <= 0xdbff) {
            highSurrogate = c;
            return;
        }
        if (c >= 0xdc00 && c <= 0xdfff && highSurrogate) {
            char32_t cp = 0x10000 + ((highSurrogate - 0xd800) << 10) + (c - 0xdc00);
            highSurrogate = 0;
            Character(cp);
            return;
        }
        highSurrogate = 0;
        Character(c);
    }

    bool FormEditKey(int key, bool control = false, bool shift = false) {
        if (modal != 1 || field < 0 || field > 2)
            return false;
        auto& e = formEditors[field];
        auto& t = fields[field];
        e.Sync(t);
        switch (key) {
        case 0x25:
            e.Move(t, -1, shift, control);
            break;
        case 0x27:
            e.Move(t, 1, shift, control);
            break;
        case 0x24:
            e.Home(t, false, shift);
            break;
        case 0x23:
            e.Home(t, true, shift);
            break;
        case 0x2e:
            e.Delete(t, false, control);
            break;
        default:
            if (control && key == 'A')
                e.All(t);
            else if (control && key == 'Z')
                e.History(t, shift);
            else if (control && key == 'Y')
                e.History(t, true);
            else
                return false;
        }
        caretSeconds = 0;
        error.clear();
        ++revision;
        return true;
    }
    void Tab(bool reverse = false) {
        caretSeconds = 0;
        if (modal == 1) {
            field = (field + (reverse ? 2 : 1)) % 3;
            ++revision;
        }
    }

    void OpenExtensions(const menu::Layout& l, const Settings& cfg, State& state, int w, int h) {
        Open(l, cfg, state, w, h);
        modal = 5;
        extensionsTween = {};
        extensionsTween.target = 1;
        extensionsTween.elapsed = 0;
        state.profileOpen = false;
        ++revision;
    }
    void StartCreate() {
        modalCloseFill = {};
        modalCloseInk = {};
        fieldTween = {};
        fieldTween[0].value = fieldTween[0].target = fieldTween[0].from = 1;
        caretSeconds = 0;
        languageActions = -1;
        modal = 1;
        fields = {};
        formEditors = {};
        field = 0;
        baseLanguage = languages.selected;
        if (languages.entries[baseLanguage].custom) {
            int parent = languages.Index(languages.entries[baseLanguage].base);
            baseLanguage = parent >= 0 && !languages.entries[parent].custom ? parent : 0;
        }
        auto ids = BaseLanguages();
        auto it = std::find(ids.begin(), ids.end(), baseLanguage);
        baseScroll = std::clamp(int(it - ids.begin()), 0, std::max(0, int(ids.size()) - 6));
        baseOpen = false;
        SetDropdown(-1);
        picker = false;
        error.clear();
        ++revision;
    }
    bool Click(const menu::Layout& l, Settings& cfg, State& state, float px, float py, bool down, int w,
               int h) {
        viewportW = w;
        viewportH = h;
        SetMenuLayout(l);
        bool foot = ProfileBox(l, cfg.scale).Contains(px, py);
        if (!open) {
            if (down && foot) {
                pressed = true;
                return true;
            }
            if (!down && pressed) {
                pressed = false;
                if (foot)
                    Open(l, cfg, state, w, h);
                return true;
            }
            return false;
        }
        if (modal == 5) {
            if (down && !menuBounds.Contains(px, py))
                Close(state);
            return true;
        }
        int hit = Hit(cfg, px, py);
        if (!down && pickerMenuRelease) {
            pickerMenuRelease = false;
            held = -1;
            return true;
        }
        if (down && pickerModes && hit != 303 && !(hit >= 320 && hit <= 322)) {
            pickerModes = false;
            held = -1;
            pickerMenuRelease = true;
            ++revision;
            return true;
        }
        if (down) {
            if (pickerField >= 0 && hit != 310 + pickerField)
                ApplyColorInput(cfg);
            if (languageActions >= 0 && hit < 700) {
                languageActions = -1;
                ++revision;
                return true;
            }
            held = hit;
            if (modal == 1 && hit >= 400 && hit <= 402) {
                field = hit - 400;
                baseOpen = false;
                auto f = FormField(cfg, field);
                formEditors[field].Mouse(px - f.x - 12 * cfg.scale * cfg.scale, false);
                caretSeconds = 0;
                ++revision;
            }
            if (modal == 4) {
                bool active = ChatBox(cfg).Contains(px, py);
                if (chatActive != active) {
                    chatActive = active;
                    ++revision;
                }
                if (!active)
                    chatFocus = false;
                if (hit == 906)
                    ScrollChatTo(cfg, py);
                auto b = ChatBox(cfg);
                if (hit == 904) {
                    dragX = px - b.x;
                    dragY = py - b.y;
                }
                if (hit == 905) {
                    dragX = b.x + b.w - px;
                    dragY = b.y + b.h - py;
                }
            }
            if (modal == 3 && hit == 420) {
                DismissAbout(state);
                return true;
            }
            if (picker && (hit == 300 || hit == 301))
                EditColor(cfg, px, py, cfg);
            if (!modal && hit == -1) {
                if (picker) {
                    picker = false;
                    ++revision;
                } else if (dropdown >= 0) {
                    SetDropdown(-1);
                    ++revision;
                } else
                    Close(state);
            }
            return true;
        }
        if (held == 300 || held == 301) {
            EditColor(cfg, px, py, cfg);
            held = -1;
            return true;
        }
        if (hit != held) {
            held = -1;
            return true;
        }
        held = -1;
        try {
            if (modal == 4) {
                if (hit >= 10000) {
                    int index = hit - 10000;
                    if (index < int(chatCodeWords.size()))
                        chatSelectedCode = chatCodeWords[index];
                } else if (hit == 900)
                    Close(state);
                else if (hit == 901)
                    SendChat(cfg);
                else if (hit == 903) {
                    chatFocus = true;
                    caretSeconds = 0;
                } else if (hit != 902)
                    chatFocus = false;
                ++revision;
                return true;
            }
            if (modal) {
                if (modal == 3) {
                    if (!aboutClosing && hit >= 430 && hit <= 431)
                        action = 3 + hit - 430;
                    ++revision;
                    return true;
                }
                if (hit == 420) {
                    modal = 0;
                    baseOpen = false;
                    error.clear();
                } else if (hit == 410) {
                    modal = 0;
                    baseOpen = false;
                    error.clear();
                } else if (hit == 411) {
                    if (modal == 1) {
                        error = languages.CreateError(fields);
                        if (error.empty()) {
                            languages.Create(fields, baseLanguage);
                            modal = 0;
                            SetDropdown(0);
                        }
                    } else if (modal == 2) {
                        languages.Remove(deleteLanguage);
                        ApplyLanguage(cfg);
                        deleteLanguage = -1;
                        modal = 0;
                        SetDropdown(0);
                    } else
                        modal = 0;
                } else if (modal == 1 && hit >= 400 && hit <= 402) {
                    field = hit - 400;
                    caretSeconds = 0;
                    baseOpen = false;
                } else if (modal == 1 && hit == 403) {
                    baseOpen = !baseOpen;
                } else if (hit >= 600 && hit < 600 + int(languages.entries.size()) &&
                           !languages.entries[hit - 600].custom) {
                    baseLanguage = hit - 600;
                    baseOpen = false;
                }
                ++revision;
                return true;
            }
            if (hit == 200) {
                action = 1;
                ++revision;
                return true;
            }
            if (hit == 201) {
                cfg.theme = 1 - cfg.theme;
                SyncColor(cfg);
                ++revision;
                return true;
            }
            if (hit == 202 || hit == 5) {
                picker = !picker;
                if (picker)
                    SyncColor(cfg);
                pickerField = -1;
                pickerModes = false;
                SetDropdown(-1);
                ++revision;
                return true;
            }
            if (hit == 304) {
                RememberColor(CurrentPalette(cfg)[31]);
                return true;
            }
            if (hit >= 340 && hit < 340 + int(pickerSaved.size())) {
                cfg.accent = pickerSaved[hit - 340];
                cfg.customAccent = true;
                SyncColor(cfg);
                ++revision;
                return true;
            }
            if (hit == 302) {
                cfg.customAccent = false;
                SyncColor(cfg);
                ++revision;
                return true;
            }
            if (hit == 303) {
                pickerModes = !pickerModes;
                ++revision;
                return true;
            }
            if (hit >= 320 && hit <= 322) {
                pickerMode = hit - 320;
                pickerModes = false;
                pickerField = -1;
                ++revision;
                return true;
            }
            if (hit >= 310 && hit <= 312) {
                BeginColorInput(cfg, hit - 310);
                return true;
            }
            if (hit >= 1000 && hit < 1064) {
                languageActions = hit - 1000;
                languageActionX = px + 1;
                languageActionY = py + 1;
                languageActionTween = {};
                ++revision;
                return true;
            }
            if (hit >= 800) {
                languageActions = -1;
                deleteLanguage = hit - 800;
                modal = 2;
                baseOpen = false;
                error.clear();
                ++revision;
                return true;
            }
            if (hit >= 700) {
                languageActions = -1;
                editLanguage = hit - 700;
                action = 2;
                ++revision;
                return true;
            }
            if (hit >= 100 && hit < 200 && dropdown >= 0) {
                int i = hit - 100;
                if (dropdown == 0) {
                    if (i == int(languages.entries.size())) {
                        StartCreate();
                        return true;
                    }
                    languages.Select(i);
                    ApplyLanguage(cfg);
                } else if (dropdown == 1) {
                    const float v[] = {0, .75f, 1, 1.25f, 1.5f, 1.75f, 2};
                    menuScale = i;
                    cfg.scale = i ? v[i] : initialScale;
                } else if (dropdown == 2) {
                    espScale = i;
                    cfg.espScale = i;
                } else if (dropdown == 3) {
                    windowsScale = i;
                    cfg.windowsScale = i;
                } else if (dropdown == 4)
                    units = i;
                else if (dropdown == 6)
                    safeMode = i;
                SetDropdown(-1);
                Clamp(cfg);
                ++revision;
                return true;
            }
            if (hit == 7) {
                synchronization = !synchronization;
                SetDropdown(-1);
                ++revision;
                return true;
            }
            if (hit == 9) {
                StartAbout();
                state.profileOpen = false;
                return true;
            }
            if (hit == 10) {
                StartChat(state);
                return true;
            }
            if (Visible(hit) && Enabled(hit) && HoverSubmenu(hit)) {
                SetDropdown(hit);
                hoverSuppressedRow = -1;
            } else
                SetDropdown(-1);
            picker = false;
            ++revision;
            return true;
        } catch (const std::exception& e) {
            error = e.what();
            ++revision;
            return true;
        }
    }
    std::u32string Value(const Settings& cfg, int i) const {
        if (i == 0)
            return DecodeUTF8(languages.entries[languages.selected].localizedName);
        if (i == 1)
            return menuScale == 0 ? U"Auto" : ASCII(std::to_string(int(std::round(cfg.scale * 100))) + "%");
        if (i == 2)
            return Options(i).at(std::clamp(cfg.espScale, 0, 5));
        if (i == 3)
            return Options(i).at(std::clamp(cfg.windowsScale, 0, 5));
        if (i == 4)
            return Options(i).at(units);
        if (i == 6)
            return Options(i).at(safeMode);
        return {};
    }
    std::vector<int> Layers() const {
        std::vector<int> a;
        if (!open)
            return a;
        if (modal) {
            a.push_back(3);
            if (baseOpen && modal == 1)
                a.push_back(4);
            if (DescriptionRow() == 901 && DescriptionAlpha() > 0)
                a.push_back(6);
            return a;
        }
        a.push_back(0);
        for (const auto& e : submenuWindows)
            if (e.first != dropdown && e.second.closing && e.second.alpha.value > 0)
                a.push_back(8 + e.first);
        if (dropdown >= 0)
            a.push_back(1);
        if (picker) {
            a.push_back(2);
            if (pickerModes)
                a.push_back(7);
        }
        if (languageActions >= 0)
            a.push_back(5);
        if (DescriptionRow() >= 0 && DescriptionAlpha() > 0)
            a.push_back(6);
        return a;
    }
    Box LayerBox(const Settings& cfg, int layer) const {
        if (auto child = ClosingSubmenu(layer))
            return child->LayerBox(cfg, 1);
        Box b = layer == 0   ? Layout(cfg).panel
                : layer == 1 ? Dropdown(cfg)
                : layer == 2 ? PickerBox(cfg)
                : layer == 3 ? (MenuOverlay() ? menuBounds : ChatBox(cfg))
                : layer == 5 ? LanguageActions(cfg)
                : layer == 6 ? DescriptionBox(cfg)
                : layer == 7 ? PickerModesBox(cfg)
                             : BaseDropdown(cfg);
        b.x = std::trunc(b.x);
        b.y = std::trunc(b.y);
        return b;
    }
    Box Bounds(const Settings& cfg) const {
        Box b = MenuOverlay() ? menuBounds : Layout(cfg).panel;
        for (int layer : Layers()) {
            auto d = LayerBox(cfg, layer);
            float right = std::max(b.x + b.w, d.x + d.w), bt = std::max(b.y + b.h, d.y + d.h);
            b.x = std::min(b.x, d.x);
            b.y = std::min(b.y, d.y);
            b.w = right - b.x;
            b.h = bt - b.y;
        }
        return b;
    }
};

inline Box ProfileSeparator(Box box, Box) {
    box.y = std::round(box.y);
    return box;
}
struct ProfileShape {
    Box box;
    Color color;
    float radius = 0, stroke = 0;
    bool surface = false;
    unsigned corners = 15;
    bool contentClip = false;
};
inline std::vector<ProfileShape> ProfileShapes(const Settings& cfg, const ProfileUI& ui, int layer = 0,
                                               Fonts* fonts = nullptr) {
    std::vector<ProfileShape> shapes;
    if (!ui.open)
        return shapes;
    if (auto child = ui.ClosingSubmenu(layer)) {
        shapes = ProfileShapes(cfg, *child, 1, fonts);
        for (auto& shape : shapes)
            shape.color.a *= ui.LayerOpacity(layer);
        return shapes;
    }
    float s = cfg.scale;
    auto pal = CurrentPalette(cfg);
    auto b = ui.LayerBox(cfg, layer);
    if (layer == 3 && ui.modal == 3) {
        auto a = ui.About(cfg, fonts ? std::trunc(fonts->Width(0, 13 * s, U"Counter-Strike 2") + .95f) : 0.f);
        float alpha = ui.AboutAlpha();
        auto add = [&](Box box, Color color, float rounding = 0, float stroke = 0, bool surface = false,
                       unsigned corners = 15) {
            color.a *= alpha;
            shapes.push_back({box, color, rounding, stroke, surface, corners});
        };
        auto dim = pal[9];
        dim.a *= .85f;
        add(a.overlay, dim, 16 * s, 0, true);
        add(a.badge, pal[12], 6 * s);
        add(a.badge, pal[11], 6 * s, s);
        for (auto panel : {a.account, a.links}) {
            add(panel, pal[40], 15 * s);
            add(panel, pal[11], 15 * s, s);
        }
        for (auto line : a.separators)
            add(ProfileSeparator(line, b), pal[34]);
        for (int i = 0; i < 2; ++i) {
            auto color = pal[33];
            color.a *= .15f * ui.aboutLinkTween[i].value;
            add(ui.AboutLinkHit(cfg, i), color, 15 * s, 0, false, i == 0 ? 3u : 12u);
        }
        return shapes;
    }
    if (layer == 3 && ui.modal == 5) {
        auto dim = pal[8];
        dim.a *= ui.LayerOpacity(layer);
        shapes.push_back({b, dim, 16 * s, 0, true});
        return shapes;
    }
    if (layer == 6) {
        float alpha = ui.DescriptionAlpha();
        auto fill = pal[8], border = pal[11];
        fill.a *= alpha;
        border.a *= alpha;
        shapes.push_back({b, fill, 10 * s, 0, true});
        shapes.push_back({b, border, 10 * s, s, false});
        return shapes;
    }
    if (layer == 3 && ui.MenuOverlay()) {
        auto dim = pal[9];
        dim.a *= .85f;
        shapes.push_back({b, dim, 16 * s, 0, true});
        auto panel = ui.ModalBox(cfg);
        shapes.push_back({panel, pal[40], 15 * s, 0, false});
        shapes.push_back({panel, pal[11], 15 * s, s, false});
        auto line = [&](float y) {
            shapes.push_back(
                {ProfileSeparator({panel.x + 14 * s, y, panel.w - 28 * s, s}, b), pal[34], 0, 0, false});
        };
        line(panel.y + (ui.modal == 1 ? 14 * s + ui.FormHeight(cfg) : 44 * s));
        if (ui.modal == 1)
            for (int i = 0; i < 3; ++i)
                line(ui.FormField(cfg, i).y + ui.FormHeight(cfg) + 7 * s);
        line(ui.ModalButton(cfg, true).y - 8 * s);

        if (ui.modal == 1)
            shapes.push_back({ui.ModalClose(cfg), ui.ModalCloseFill(cfg), 6 * s, 0, false});
        if (ui.modal == 1)
            for (int i = 0; i < 4; ++i) {
                auto field = ui.FormField(cfg, i);
                auto col = Mix(pal[12], pal[13], i < 3 ? ui.fieldTween[i].value : ui.baseTween.value);
                shapes.push_back({field, col, 6 * s, 0, false});
                if (i < 3)
                    shapes.push_back({field, pal[11], 6 * s, s, false});
            }
        for (bool confirm : {false, true}) {
            float t = ui.buttonTween[confirm ? 1 : 0].value;
            auto accent = pal[31];
            accent.a *= .4f;
            auto col = confirm ? Mix(pal[28], pal[29], t) : Mix(pal[11], accent, t);
            shapes.push_back({ui.ModalButton(cfg, confirm), col, 6 * s, 0, false});
        }
        return shapes;
    }
    if (layer == 3 && ui.modal == 4) {

        auto body = b;
        float top = ui.ChatHeaderH(s) - s;
        body.y += top;
        body.h -= top;
        shapes.push_back({b, {0, 0, 0, 0}, ui.ChatRadius(), 0, true});
        shapes.push_back({body, ui.ChatBackground(cfg), ui.ChatRadius(), 0, false, 12});
    } else
        shapes.push_back({b, pal[8], 15 * s, 0, true});

    if (!(layer == 3 && ui.modal == 4))
        shapes.push_back({b, pal[11], 15 * s, s, false});
    if (layer == 0) {
        auto p = ui.Layout(cfg);
        auto renewFill = pal[33];
        renewFill.a *= .4f * ui.renewTween.value;
        if (renewFill.a > 0)
            shapes.push_back({p.renew, renewFill, 6 * s, 0, false});
        for (auto line : p.dividers)
            shapes.push_back({ProfileSeparator(line, b), pal[34], 0, 0, false});
        for (int i = 0; i < 11; ++i)
            if (ui.Visible(i)) {
                auto col = pal[33];
                col.a *= .4f * ui.rowTween[i].value;
                if (col.a > 0)
                    shapes.push_back({p.rows[i], col, std::trunc(7.5f * s), 0, false});
            }

        shapes.push_back({p.theme, ui.ThemeFill(cfg), 6 * s, 0, false});
        auto chipFill = PickerButtonFill(pal[33], ui.styleSwatchTween.value);
        shapes.push_back({{p.swatch.x - 4 * s, p.swatch.y - 4 * s, p.swatch.w + 8 * s, p.swatch.h + 8 * s},
                          chipFill,
                          6 * s,
                          0,
                          false});
        shapes.push_back({p.swatch, ui.SwatchColor(cfg), 6 * s, 0, false});
        const float syncRound = ui.SyncNominal(s) * .5f;
        shapes.push_back({p.sync, pal[22], syncRound, 0, false});
        auto overlay = pal[23];
        overlay.a *= ui.syncTween.value;
        shapes.push_back({p.sync, overlay, syncRound, 0, false});
        auto dot = ui.SyncDot(cfg);
        shapes.push_back({dot, Mix(pal[20], pal[21], ui.syncTween.value), dot.w * .5f, 0, false});
    }
    if (layer == 1)
        for (int i = 0; i < int(ui.optionFill.size()); ++i) {
            auto col = pal[33];
            col.a *= .4f * ui.optionFill[i].value;
            if (col.a > 0)
                shapes.push_back({ui.OptionBox(cfg, i), col, std::trunc(7.5f * s), 0, false});
        }
    if (layer == 1 && ui.dropdown == 0) {
        for (int i = 0; i < int(ui.languages.entries.size()); ++i)
            if (ui.languages.entries[i].custom) {
                auto col = ui.LanguageButtonFill(cfg, i);
                shapes.push_back({ui.LanguageActionBox(cfg, i, false), col, 6 * s, 0, false});
            }
        for (int i = 1; i < int(ui.languages.entries.size()); ++i)
            if (ui.LanguageGroupGap(i) && !ui.LanguageGroupGap(i - 1)) {
                auto row = ui.OptionBox(cfg, i);
                shapes.push_back({ProfileSeparator({row.x + 12 * s, row.y - 4 * s, row.w - 24 * s, s}, b),
                                  pal[34], 0, 0, false});
            }
    }
    if (layer == 3 && ui.modal == 4) {
        shapes.push_back(
            {ui.ChatHeaderFill(cfg), pal[ui.ChatActive() ? 16 : 15], ui.ChatRadius(), 0, false, 3});
        auto composer = ui.ChatInputBox(cfg);
        shapes.push_back({composer, Mix(pal[12], pal[13], ui.chatInputTween.value), 6 * s, 0, false});
        shapes.push_back({composer, pal[11], 6 * s, s, false});
        shapes.push_back({ui.ChatHeaderSeparator(cfg), pal[34], 0, 0, false});
        shapes.push_back(
            {ProfileSeparator({b.x + 10 * s, composer.y - 6 * s, b.w - 20 * s, s}, b), pal[34], 0, 0, false});
        for (bool friendCode : {false, true}) {
            int i = friendCode ? 1 : 0;
            auto btn = ui.ChatButton(cfg, friendCode);
            float t = ui.chatButtonTextTween[i].value;
            auto accent = pal[31];
            accent.a *= .4f;
            shapes.push_back({btn, friendCode ? pal[40] : Mix(pal[28], pal[29], t), 6 * s, 0, false});
            if (friendCode)
                shapes.push_back({btn, Mix(pal[11], accent, t), 6 * s, s, false});
            if (friendCode) {
                auto overlay = pal[33];
                overlay.a *= .2f * ui.chatButtonTween[i].value;
                shapes.push_back({btn, overlay, 6 * s, 0, false});
            }
        }
        if (ui.ChatOverflow(cfg)) {
            auto track = ui.ChatScrollTrack(cfg);
            shapes.push_back({track, pal[17], 3 * s, 0, false});
            shapes.push_back(
                {ui.ChatScrollThumb(cfg), Mix(pal[18], pal[19], ui.chatScrollHover.value), 3 * s, 0, false});
        }
    }

    if (layer == 2) {
        auto modeFill = PickerButtonFill(pal[33], ui.pickerFormatTween.value);
        shapes.push_back({ui.PickerModeBox(cfg), modeFill, 6 * s, 0, false});
        auto hue = ui.HueBox(cfg);
        shapes.push_back({{hue.x, hue.y + hue.h + 7 * s, hue.w, s}, pal[34], 0, 0, false});
        if (!ui.pickerSaved.empty()) {
            auto f = ui.PickerSave(cfg);
            shapes.push_back({{hue.x, f.y + f.h + 7 * s, hue.w, s}, pal[34], 0, 0, false});
        }
        for (int i = 0; i < (ui.pickerMode == 2 ? 1 : 3); ++i) {
            auto color = PickerFieldFill(pal[33], ui.pickerFieldTween[i].value);
            shapes.push_back({ui.PickerValueBox(cfg, i), color, 6 * s, 0, false});
        }
        auto saveFill = PickerButtonFill(pal[33], ui.pickerSaveTween.value);
        if (saveFill.a > 0)
            shapes.push_back({ui.PickerSave(cfg), saveFill, 6 * s, 0, false});
        if (ui.pickerMode == 2)
            shapes.push_back({ui.PickerValueSwatch(cfg), ui.SwatchColor(cfg), 3 * s, 0, false});
        for (int i = 0; i < int(ui.pickerSaved.size()); ++i) {
            auto tile = ui.PickerSavedBox(cfg, i);
            float motion = i < int(ui.pickerSavedTween.size()) ? ui.pickerSavedTween[i].value : 0;
            auto hover = PickerButtonFill(pal[33], motion);
            shapes.push_back(
                {{tile.x - 4 * s, tile.y - 4 * s, tile.w + 8 * s, tile.h + 8 * s}, hover, 6 * s, 0, false});
        }
    }
    if (layer == 4) {
        auto drop = ui.BaseDropdown(cfg);
        auto ids = ui.BaseLanguages();
        for (int i = 0; i < std::min(6, int(ids.size()) - ui.baseScroll); ++i) {
            int n = ids[ui.baseScroll + i];
            auto col = pal[33];
            col.a *= .4f * (n < int(ui.baseOptionFill.size()) ? ui.baseOptionFill[n].value : 0.f);
            shapes.push_back({{drop.x + 6 * s, drop.y + (6 + ui.ItemUnits(s) * i) * s, drop.w - 12 * s,
                               ui.ItemUnits(s) * s},
                              col,
                              std::trunc(7.5f * s),
                              0,
                              false});
        }
    }
    if (layer == 5) {
        shapes.push_back(
            {ProfileSeparator({b.x + 19 * s, b.y + (ui.ItemUnits(s) + 10) * s, b.w - 38 * s, s}, b), pal[34],
             0, 0, false});
        for (bool remove : {false, true}) {
            auto col = pal[33];
            col.a *= .4f * ui.languageActionTween[remove ? 1 : 0].value;
            if (col.a > 0)
                shapes.push_back({ui.LanguageActionItem(cfg, remove), col, std::trunc(7.5f * s), 0, false});
        }
    }
    if (layer == 7)
        for (int i = 0; i < 3; ++i) {
            auto col = pal[33];
            col.a *= .4f * ui.modeFill[i].value;
            if (col.a > 0)
                shapes.push_back({ui.PickerModeItem(cfg, i), col, 15 * s / 1.6f, 0, false});
        }

    if (layer == 1)
        for (auto& shape : shapes)
            shape.color.a *= ui.LayerOpacity(layer);

    if (layer == 1 && ui.dropdown == 0) {
        auto q = [](float v) { return std::floor(std::clamp(v, 0.f, 1.f) * 255 + .5f) / 255; };
        for (std::size_t i = 0; i < shapes.size(); ++i) {
            auto& sh = shapes[i];
            sh.color = {q(sh.color.r), q(sh.color.g), q(sh.color.b), q(sh.color.a)};
            if (i >= 2)
                sh.contentClip = true;
        }
    }
    if (layer == 3 && ui.modal == 4)
        for (auto& shape : shapes)
            if (!shape.surface && shape.box.y >= b.y + ui.ChatHeaderH(s))
                shape.contentClip = true;
    return shapes;
}
inline void ProfileText(Canvas& c, Fonts& fonts, const Settings& cfg, const ProfileUI& ui, float dx = 0,
                        float dy = 0, int layer = 0, float inheritedOpacity = 1) {
    if (!ui.open)
        return;
    if (auto child = ui.ClosingSubmenu(layer)) {
        ProfileText(c, fonts, cfg, *child, dx, dy, 1, ui.LayerOpacity(layer));
        return;
    }
    const float submenuAlpha = layer == 1 ? inheritedOpacity * ui.LayerOpacity(1) : 1.f;
    float s = cfg.scale;
    auto pal = CurrentPalette(cfg);
    auto shift = [&](Box b) {
        b.x += dx;
        b.y += dy;
        return b;
    };
    Box widgetClip{};
    const Box* activeTextClip = nullptr;
    auto text = [&](const std::u32string& str, Box b, Color col, float size = 13, int face = 0) {
        col.a *= submenuAlpha;
        if (layer == 3 && ui.modal == 3)
            col.a *= ui.AboutAlpha();
        fonts.Text(c, face, size * s, str, shift(b), col, face == 3, activeTextClip);
    };
    auto icon = [&](char32_t cp, Box b, Color col, float size = 13) {
        text(std::u32string(1, cp), b, col, size, 3);
    };

    if (layer == 3 && ui.modal == 5) {
        auto b = ui.LayerBox(cfg, layer);
        auto clip = shift(b);
        auto color = pal[2];
        color.a *= ui.LayerOpacity(layer);
        fonts.NativeText(c, 2, 19 * s, ui.Label("menu_extensions_manage_title"), b.x + 16 * s, b.y + 12 * s,
                         color, -dx, -dy, &clip);
        return;
    }
    auto wrapped = [&](const std::u32string& value, Box box, Color color, float size) {
        std::u32string line;
        float cy = box.y;
        auto flush = [&]() {
            if (cy + size * s <= box.y + box.h + .01f)
                text(line, {box.x, cy, box.w, (size + 3) * s}, color, size);
            line.clear();
            cy += (size + 3) * s;
        };
        std::u32string word;
        auto append = [&]() {
            if (!line.empty() && fonts.Width(0, size * s, line + U" " + word) > box.w)
                flush();
            if (!line.empty())
                line += U" ";
            line += word;
            word.clear();
        };
        for (char32_t cp : value) {
            if (cp == U' ' || cp == U'\n') {
                append();
                if (cp == U'\n')
                    flush();
            } else
                word += cp;
        }
        append();
        if (!line.empty())
            flush();
    };
    if (layer == 0) {
        auto p = ui.Layout(cfg);
        if (cfg.avatar)
            DrawAvatar(c, *cfg.avatar, shift(p.avatar));
        float tx = p.avatar.x + p.avatar.w + 10 * s;
        float tw = p.panel.x + p.panel.w - 19 * s - tx;
        text(cfg.userName, {tx, p.avatar.y, tw, ui.RuntimeFontSize(s)}, pal[2]);
        auto till = ui.Label("menu_user_license") + U":";
        float tillW = std::trunc(fonts.Width(0, 13 * s, till) + .95f);
        text(till, {tx, p.avatar.y + ui.RuntimeFontSize(s), std::min(tillW, tw), ui.RuntimeFontSize(s)},
             pal[0]);

        float dateX = tx + tillW + 4 * s;
        text(cfg.subscriptionEnd ? ProfileDate(cfg) : U"—",
             {dateX, p.avatar.y + ui.RuntimeFontSize(s), std::max(0.f, tx + tw - dateX),
              ui.RuntimeFontSize(s)},
             pal[0]);
        auto renew = pal[31];
        renew.a *= .8f * (.7f + .3f * ui.renewTween.value);
        auto renewLabel = p.renew;
        renewLabel.x += 6 * s;
        renewLabel.w = std::max(0.f, renewLabel.w - 12 * s);
        text(ui.Label("menu_user_license_renew"), renewLabel, renew);
        for (int i = 0; i < 11; ++i)
            if (ui.Visible(i)) {
                auto b = p.rows[i];
                auto rowColor = Mix(pal[14], pal[2], ui.rowTextTween[i].value);
                float left = b.x + 12 * s;
                icon(ProfileIcons[i], {left, b.y, 20 * s, b.h}, rowColor);
                left += 32 * s;
                float right = b.x + b.w - 12 * s;
                float labelRight = i == 5 ? p.theme.x - 4 * s : i == 7 ? p.sync.x - 4 * s : right;
                auto v = ui.Value(cfg, i);
                if (!v.empty()) {
                    float arrow = std::trunc(fonts.Width(3, 13 * s, U"\uf105") + .95f),
                          vw = std::min(std::trunc(fonts.Width(0, 13 * s, v) + .95f),
                                        std::max(0.f, right - arrow - 5 * s - left));
                    labelRight = std::min(labelRight, right - arrow - 3 * s - vw - 7 * s);
                }
                text(ui.Label(ProfileKeys[i]), {left, b.y, std::max(1.f, labelRight - left), b.h}, rowColor);
                if (!v.empty()) {
                    float arrow = std::trunc(fonts.Width(3, 13 * s, U"\uf105") + .95f),
                          vw = std::trunc(fonts.Width(0, 13 * s, v) + .95f);
                    float maxw = std::max(0.f, right - arrow - 5 * s - left);
                    vw = std::min(vw, maxw);

                    text(v, {right - arrow - 3 * s - vw, b.y, vw, b.h}, pal[14]);
                    icon(0xf105, {right - arrow, b.y, arrow, b.h}, pal[14]);
                }
            }

        auto theme = p.theme;
        char32_t cp = cfg.theme ? 0xf186 : 0xf185;
        float iw = fonts.NativeTextSize(3, 13 * s, std::u32string(1, cp)).w;
        float gx = std::trunc((theme.x + (theme.x + theme.w)) * .5f - iw * .5f);
        float gy = std::trunc((theme.y + (theme.y + theme.h)) * .5f - ui.RuntimeFontSize(s) * .5f);
        auto clip = shift(theme);
        fonts.NativeMergedIcon(c, 13 * s, cp, gx, gy, ui.ThemeInk(cfg), -dx, -dy, &clip);
    }

    if (layer == 1 && ui.dropdown == 0) {
        auto a = ui.Options(0);
        auto windowClip = shift(ui.LanguageContentClip(cfg));
        auto clipped = [&](Box b) {
            b = shift(b);
            float x = std::max(b.x, windowClip.x), y = std::max(b.y, windowClip.y),
                  r = std::min(b.x + b.w, windowClip.x + windowClip.w),
                  d = std::min(b.y + b.h, windowClip.y + windowClip.h);
            return Box{x, y, std::max(0.f, r - x), std::max(0.f, d - y)};
        };
        const float f = ui.RuntimeFontSize(s);
        for (int i = 0; i < int(a.size()); ++i) {
            if (i < int(ui.languages.entries.size()) &&
                (i < ui.languageScroll || i >= ui.languageScroll + ui.VisibleLanguageCount()))
                continue;
            auto row = ui.OptionBox(cfg, i);
            float left = row.x + 12 * s, right = row.x + row.w - 12 * s;
            auto col = ui.LanguageTextColor(cfg, i);
            col.a *= submenuAlpha;
            bool create = i == int(ui.languages.entries.size()),
                 custom = !create && ui.languages.entries[i].custom;

            if (create) {
                float iw = fonts.NativeTextSize(3, 13 * s, U"\uf055").w;
                float ix = left + std::max(0.f, (20 * s - iw) * .5f);
                auto clip = clipped({left, row.y, 20 * s, row.h});
                fonts.NativeMergedIcon(c, 13 * s, 0xf055, ix, row.y + (row.h - f) * .5f, col, -dx, -dy,
                                       &clip);
                left += 32 * s;
            }
            if (custom)
                right -= 26 * s;
            auto clip = clipped({left, row.y, std::max(0.f, right - left), row.h});
            fonts.NativeText(c, 0, 13 * s, ProfileUI::SelectableLabel(a[i]), left, row.y + (row.h - f) * .5f,
                             col, -dx, -dy, &clip);
            if (custom) {
                auto button = ui.LanguageActionBox(cfg, i, false);
                float iw = fonts.NativeTextSize(3, 13 * s, U"\uf142").w;
                float gx = std::trunc(button.x + (button.w - iw) * .5f),
                      gy = std::trunc(button.y + (button.h - f) * .5f);
                auto buttonClip = clipped(button);
                auto ink = ui.LanguageButtonInk(cfg, i);
                ink.a *= submenuAlpha;
                fonts.NativeMergedIcon(c, 13 * s, 0xf142, gx, gy, ink, -dx, -dy, &buttonClip);
            }
        }
    }
    if (layer == 1 && ui.dropdown != 0) {
        auto a = ui.Options(ui.dropdown);
        for (int i = 0; i < int(a.size()); ++i) {
            if (ui.dropdown == 0 && i < int(ui.languages.entries.size()) &&
                (i < ui.languageScroll || i >= ui.languageScroll + ui.VisibleLanguageCount()))
                continue;
            auto row = ui.OptionBox(cfg, i);
            float left = row.x + 12 * s;
            bool custom =
                ui.dropdown == 0 && i < int(ui.languages.entries.size()) && ui.languages.entries[i].custom;
            bool create = ui.dropdown == 0 && i == int(ui.languages.entries.size());
            float right = custom ? ui.LanguageActionBox(cfg, i, false).x - 4 * s : row.x + row.w - 12 * s;
            if (create) {
                float iw = fonts.Width(3, 13 * s, U"\uf055");
                icon(0xf055, {left + std::trunc((20 * s - iw) * .5f), row.y, iw, row.h}, pal[14]);
                left += 32 * s;
            }
            text(a[i], {left, row.y, right - left, row.h},
                 Mix(pal[14], pal[2], i < int(ui.optionText.size()) ? ui.optionText[i].value : 0.f));
            if (custom)
                icon(0xf142, ui.LanguageActionBox(cfg, i, false), pal[14]);
        }
    }

    if (layer == 2) {
        for (int i = 0; i < int(ui.pickerSaved.size()); ++i)
            DrawPickerSaved(c, shift(ui.PickerSavedBox(cfg, i)), s, ui.pickerSaved[i], pal[30]);
        auto sv = shift(ui.SVBox(cfg)), hb = shift(ui.HueBox(cfg));
        for (int y = std::max(0, int(sv.y)); y < std::min(c.height, int(std::ceil(sv.y + sv.h))); ++y)
            for (int x = std::max(0, int(sv.x)); x < std::min(c.width, int(std::ceil(sv.x + sv.w))); ++x) {
                float cov = std::clamp(.5f - BoxDistance(sv, 8 * s, x + .5f, y + .5f), 0.f, 1.f);
                auto col = ProfileHSV(ui.hue, std::clamp((x - sv.x) / sv.w, 0.f, 1.f),
                                      1 - std::clamp((y - sv.y) / sv.h, 0.f, 1.f));
                col.a = cov;
                c.Blend(x, y, col);
            }
        for (int y = std::max(0, int(hb.y)); y < std::min(c.height, int(std::ceil(hb.y + hb.h))); ++y)
            for (int x = std::max(0, int(hb.x)); x < std::min(c.width, int(std::ceil(hb.x + hb.w))); ++x) {
                auto col = ProfileHSV(std::clamp((x - hb.x) / hb.w, 0.f, .9999f), 1, 1);
                col.a = std::clamp(.5f - BoxDistance(hb, 4 * s, x + .5f, y + .5f), 0.f, 1.f);
                c.Blend(x, y, col);
            }
        auto mark = shift(ui.SVMarker(cfg));
        DrawMenuCircleShadow(c, mark.x + 8 * s, mark.y + 8 * s, 8 * s, 2 * s, 2 * s, 10 * s,
                             {0, 0, 0, 128.f / 255.f});
        c.RoundRect(mark, 8 * s, {1, 1, 1, 1});
        c.RoundRect({mark.x + 2 * s, mark.y + 2 * s, 12 * s, 12 * s}, 6 * s,
                    ProfileHSV(ui.hue, ui.saturation, ui.value));

        auto globalHue = ui.HueBox(cfg);
        float mx = std::round(globalHue.x + ui.hue * globalHue.w) + dx, my = hb.y + hb.h * .5f;
        c.RoundRect({mx - 6 * s, my - 10 * s, 12 * s, 20 * s}, 8 * s, {1, 1, 1, 1});
        c.RoundRect({mx - 3 * s, my - 7 * s, 6 * s, 14 * s}, 8 * s, ProfileHSV(ui.hue, 1, 1));

        auto native = [&](const std::u32string& value, float x, float y, Color color, int face = 1,
                          float px = 12) {
            auto clip = shift(ui.PickerBox(cfg));
            if (face == 3)
                fonts.NativeMergedIcon(c, px * s, value[0], x, y, color, -dx, -dy, &clip);
            else
                fonts.NativeText(c, face, px * s, value, x, y, color, -dx, -dy, &clip);
        };
        auto mode = ui.PickerModeBox(cfg);
        float af = fonts.PixelHeight(2, 11 * s), aw = ui.pickerMetrics.arrow;
        native(U"\uf107", mode.x + 6 * s, mode.y + (mode.h - af) * .5f + s, pal[0], 3, 11);
        native(PickerFormatLabel(ui.pickerMode), mode.x + 9 * s + aw, mode.y + 3 * s,
               Mix(pal[14], pal[2], ui.pickerFormatTween.value));
        for (int i = 0; i < (ui.pickerMode == 2 ? 1 : 3); ++i) {
            auto box = ui.PickerValueBox(cfg, i);
            if (ui.pickerMode != 2)
                native(ui.pickerField == i ? ui.colorInput : ui.ColorFieldText(cfg, i), box.x + 6 * s,
                       box.y + 3 * s, pal[14]);
            else {
                auto value = ui.pickerField == i ? ui.colorInput : ui.ColorFieldText(cfg, i);
                while (!value.empty() &&
                       (value.front() == U'#' || value.front() == U' ' || value.front() == U'\t'))
                    value.erase(value.begin());
                native(U"#" + value, box.x + 24 * s, box.y + 3 * s, pal[14]);
            }
        }

        auto save = ui.PickerSave(cfg);
        float iw = fonts.NativeTextSize(3, 12 * s, U"\ue197").w;
        native(U"\ue197", save.x + (save.w - iw) * .5f, save.y + 3 * s,
               Mix(pal[14], pal[2], ui.pickerSaveTween.value), 3, 12);
    }

    if (layer == 3) {
        auto b = ui.ModalBox(cfg);
        float pad = 14 * s;
        std::string title = ui.modal == 1   ? "menu_user_language_new_title"
                            : ui.modal == 2 ? "menu_user_language_delete_prompt_title"
                            : ui.modal == 3 ? "window_about"
                                            : "window_chat";
        if (ui.modal == 2) {
            text(ui.Label(title), {b.x + pad, b.y + 7 * s, b.w - 53 * s, 25 * s}, pal[2], 14, 1);
            auto close = ui.ModalClose(cfg);
            float cw = fonts.Width(3, 14 * s, U"\uf00d");
            close.x += (close.w - cw) * .5f;
            close.w = cw;
            icon(0xf00d, close, pal[14], 14);
        }
        if (ui.modal == 1) {
            auto titleClip =
                Box{b.x + pad, b.y + 7 * s, b.w - 2 * pad - ui.FormHeight(cfg) - 7 * s, ui.FormHeight(cfg)};
            auto clip = shift(titleClip);
            float F = fonts.PixelHeight(1, 14 * s), H = ui.FormHeight(cfg);
            fonts.NativeText(c, 1, 14 * s, ui.Label(title), b.x + pad, b.y + 7 * s + (H - F) * .5f, pal[2],
                             -dx, -dy, &clip);
            auto close = ui.ModalClose(cfg);
            float cw = fonts.NativeTextSize(3, 14 * s, U"\uf00d").w;
            auto closeClip = shift(close);
            fonts.NativeMergedIcon(c, 14 * s, 0xf00d, close.x + (close.w - cw) * .5f,
                                   close.y + (close.h - F) * .5f, ui.ModalCloseInk(cfg), -dx, -dy, &closeClip,
                                   1);
        }
        if (ui.modal == 1) {
            const char* keys[] = {"menu_user_language_new_name", "menu_user_language_new_shortname",
                                  "menu_user_language_new_localizedname",
                                  "menu_user_language_new_baselanguage"};
            const float F = ui.RuntimeFontSize(s);
            auto panelClip = shift(b);
            for (int i = 0; i < 4; ++i) {
                auto f = ui.FormField(cfg, i);
                fonts.NativeText(c, 0, 13 * s, ui.Label(keys[i]), b.x + pad, f.y + (f.h - F) * .5f, pal[0],
                                 -dx, -dy, &panelClip);
                auto value =
                    i < 3 ? ui.fields[i] : DecodeUTF8(ui.languages.entries[ui.baseLanguage].localizedName);
                float fpx = 12 * s * s;
                Box ink{f.x + fpx, f.y, f.w - 2 * fpx, f.h};

                if (i < 3) {
                    auto edit = ui.formEditors[i];
                    edit.Measure(fonts, 13 * s, value, std::max(1.f, ink.w), true, 0);
                    float offset = edit.scroll;
                    auto clip = shift(ink);
                    if (i == ui.field && edit.Selected()) {
                        auto lo = edit.advance[edit.Begin()] - offset, hi = edit.advance[edit.End()] - offset;
                        Box selected{
                            std::max(ink.x, ink.x + lo), f.y + 6 * s * s,
                            std::max(0.f, std::min(ink.x + ink.w, ink.x + hi) - std::max(ink.x, ink.x + lo)),
                            F};
                        if (selected.w > 0)
                            c.RoundRect(shift(selected), 0, pal[37]);
                    }
                    fonts.NativeText(c, 0, 13 * s, value, ink.x - offset, f.y + 6 * s * s, pal[0], -dx, -dy,
                                     &clip);
                    if (i == ui.field && ui.CaretVisible()) {
                        auto caret = shift(ui.FormCaret(cfg, i, edit.advance[edit.cursor] - offset));
                        if (clip.Contains(caret.x, caret.y))
                            c.RoundRect(caret, 0, pal[14]);
                    }
                } else {
                    auto clip = shift(ink);
                    fonts.NativeText(c, 0, 13 * s, value, ink.x, f.y + 6 * s * s, pal[0], -dx, -dy, &clip);
                    float iw = fonts.NativeTextSize(3, 11 * s, U"\uf107").w,
                          af = fonts.PixelHeight(2, 11 * s);
                    fonts.NativeMergedIcon(c, 11 * s, 0xf107, f.x + f.w - fpx - iw, f.y + (f.h - af) * .5f,
                                           pal[14], -dx, -dy, &panelClip, 2);
                }
            }
        } else if (ui.modal == 2) {
            std::u32string name =
                ui.deleteLanguage > 0 && ui.deleteLanguage < int(ui.languages.entries.size())
                    ? DecodeUTF8(ui.languages.entries[ui.deleteLanguage].localizedName)
                    : U"";
            auto prompt = ui.Label("menu_user_language_delete_prompt");
            auto at = prompt.find(U"{language}");
            if (at != std::u32string::npos)
                prompt.replace(at, 10, name);
            wrapped(prompt, {b.x + pad, b.y + 48 * s, b.w - 2 * pad, 36 * s}, pal[0], 12);
        } else if (ui.modal == 3) {
            auto a = ui.About(cfg, std::trunc(fonts.Width(0, 13 * s, U"Counter-Strike 2") + .95f));
            if (cfg.aboutLogo)
                DrawImage(c, *cfg.aboutLogo, shift(a.logo), false, ui.AboutAlpha());
            text(U"Counter-Strike 2",
                 {a.badge.x + 6 * s, a.badge.y + 3 * s, a.badge.w - 12 * s, ui.RuntimeFontSize(s)}, pal[2]);
            const char* keys[] = {"window_about_username", "window_about_branch", "window_about_updated",
                                  "window_about_license"};
            const std::u32string values[] = {cfg.userName, cfg.aboutBranch, ASCII(AboutUpdated),
                                             ProfileDate(cfg)};
            for (int i = 0; i < 4; ++i) {
                auto row = ui.AboutRow(cfg, i);
                float vw = std::trunc(fonts.Width(0, 13 * s, values[i]) + .95f);
                text(ui.Label(keys[i]), row, pal[2]);
                text(values[i], {row.x + row.w - vw, row.y, vw, row.h}, pal[31]);
            }
            const char* linkKeys[] = {"window_about_reportissue", "window_about_legal"};
            for (int i = 0; i < 2; ++i) {
                auto row = ui.AboutLink(cfg, i);
                text(ui.Label(linkKeys[i]), {row.x, row.y, row.w - 20 * s, row.h}, pal[0]);
                float iw = fonts.Width(3, 13 * s, std::u32string(1, AboutLinkIcons[i]));
                icon(AboutLinkIcons[i], {row.x + row.w - (20 * s + iw) * .5f, row.y, iw, row.h}, pal[0]);
            }
            float fw = std::trunc(fonts.Width(0, 13 * s, AboutFooter) + .95f);
            text(AboutFooter, {a.footer.x + (a.footer.w - fw) * .5f, a.footer.y, fw, a.footer.h}, pal[0]);
        } else if (ui.modal == 4) {
            auto titleIcon = pal[31];
            titleIcon.a *= .75f;
            float titleIconWidth = std::trunc(fonts.Width(3, 12 * s, U"\uf086") + .95f);
            icon(0xf086, {b.x + 6 * s, b.y, titleIconWidth, ui.ChatHeaderH(s)}, titleIcon, 12);
            float labelX = b.x + 6 * s + titleIconWidth + 5 * s;
            text(ui.Label("window_chat"),
                 {labelX, b.y, std::max(0.f, ui.ChatClose(cfg).x - labelX), ui.ChatHeaderH(s)}, pal[2], 12,
                 2);
            auto close = ui.ChatClose(cfg);
            float cw = fonts.Width(3, 13 * s, U"\uf00d");
            close.x += (close.w - cw) * .5f;
            close.w = cw;
            icon(0xf00d, close, pal[2]);
            widgetClip = shift(ui.ChatContentClip(cfg));
            activeTextClip = &widgetClip;
            auto history = ui.ChatHistory(cfg);
            Canvas messages(std::max(1, int(std::ceil(history.w))), std::max(1, int(std::ceil(history.h))));
            float contentHeight = 0;
            auto lines =
                ui.ChatLines(fonts, cfg, history.w - (ui.ChatOverflow(cfg) ? 15 * s : 0), contentHeight);
            float offset = std::max(0.f, contentHeight - history.h - ui.chatScroll * 18 * s);
            for (auto& line : lines) {
                if (line.separator)
                    messages.RoundRect({line.x, line.y - offset, line.w, s}, 0, line.color);
                else
                    fonts.NativeText(messages, 0, 13 * s, line.text, history.x + line.x,
                                     history.y + line.y - offset, line.color, std::trunc(history.x),
                                     std::trunc(history.y));
            }
            auto at = shift(history);
            for (int yy = 0; yy < messages.height; ++yy)
                for (int xx = 0; xx < messages.width; ++xx) {
                    auto px = messages.rgba.data() + 4 * (std::size_t(yy) * messages.width + xx);
                    float a = px[3] / 255.f;
                    if (a > 0)
                        c.Blend(int(at.x) + xx, int(at.y) + yy,
                                {px[0] / 255.f / a, px[1] / 255.f / a, px[2] / 255.f / a, a});
                }
            auto input = ui.ChatInputBox(cfg);
            auto clip = shift({input.x - s, input.y - s, input.w + 2 * s, input.h + 2 * s});
            input.x += 12 * s;
            float advance = fonts.NativeTextSize(0, 13 * s, ui.chatInput).w - ui.chatInputScroll;
            fonts.NativeText(c, 0, 13 * s,
                             ui.chatInput.empty() ? ui.Label("window_chat_message") : ui.chatInput,
                             input.x - ui.chatInputScroll, input.y + 6 * s,
                             ui.chatInput.empty() ? pal[1] : pal[0], -dx, -dy, &clip);
            if (ui.chatFocus && ui.ChatActive() && ui.CaretVisible()) {
                auto caret = shift(ui.ChatCaret(cfg, advance));
                if (clip.Contains(caret.x, caret.y))
                    c.RoundRect(caret, 0, pal[14]);
            }
            for (bool friendCode : {false, true}) {
                auto btn = ui.ChatButton(cfg, friendCode);
                char32_t glyph = friendCode ? 0xf064 : 0xf1d8;
                float iw = fonts.NativeTextSize(3, 13 * s, std::u32string(1, glyph)).w,
                      lw = friendCode
                               ? 0
                               : fonts.NativeTextSize(0, 13 * s, ui.Label("window_chat_sendmessage")).w,
                      gap = friendCode ? 0 : 12 * s;
                float start = btn.x + (btn.w - iw - lw - gap) * .5f;
                float t = ui.chatButtonTextTween[friendCode ? 1 : 0].value;
                auto col = friendCode ? Mix(pal[14], pal[2], t) : Mix(pal[43], pal[44], t);
                icon(glyph, {start, btn.y, iw, btn.h}, col);
                if (!friendCode)
                    text(ui.Label("window_chat_sendmessage"), {start + iw + gap, btn.y, lw, btn.h}, col);
            }
        }
        if (ui.modal != 4 && !ui.error.empty())
            wrapped(ui.Label(ui.error), {b.x + pad, b.y + b.h - 74 * s, b.w - 2 * pad, 29 * s},
                    {.86f, .39f, .38f, 1}, 11);
        auto buttonText = [&](const std::u32string& label, Box button, Color color) {
            if (ui.modal == 2) {
                float width = fonts.Width(0, 13 * s, label);
                button.x += (button.w - width) * .5f;
                button.w = width;
                text(label, button, color);
                return;
            }
            float width = fonts.NativeTextSize(0, 13 * s, label).w;
            auto clip = shift(button);
            fonts.NativeText(c, 0, 13 * s, label, button.x + (button.w - width) * .5f,
                             button.y + (button.h - ui.RuntimeFontSize(s)) * .5f, color, -dx, -dy, &clip);
        };
        if (ui.modal == 1 || ui.modal == 2) {
            buttonText(ui.Label("menu_user_language_new_cancel"), ui.ModalButton(cfg, false),
                       Mix(pal[14], pal[2], ui.buttonTween[0].value));
            buttonText(ui.modal == 1 ? ui.Label("menu_user_language_new_create")
                                     : ui.Label("menu_user_language_delete"),
                       ui.ModalButton(cfg, true), Mix(pal[43], pal[44], ui.buttonTween[1].value));
        }
    }

    if (layer == 5) {
        auto clip = shift(ui.LanguageActions(cfg));
        for (bool remove : {false, true}) {
            auto row = ui.LanguageActionItem(cfg, remove);
            float left = row.x + 12 * s, ty = row.y + (row.h - ui.RuntimeFontSize(s)) * .5f;
            auto col =
                remove ? Color{.86f, .39f, .38f, 1} : Mix(pal[14], pal[2], ui.languageActionTween[0].value);
            char32_t cp = remove ? 0xf2ed : 0xf304;
            float iw = fonts.NativeTextSize(3, 13 * s, std::u32string(1, cp)).w;
            fonts.NativeMergedIcon(c, 13 * s, cp, left + (20 * s - iw) * .5f, ty, col, -dx, -dy, &clip);
            fonts.NativeText(c, 0, 13 * s,
                             ProfileUI::SelectableLabel(
                                 ui.Label(remove ? "menu_user_language_delete" : "menu_user_language_edit")),
                             left + 32 * s, ty, col, -dx, -dy, &clip);
        }
    }
    if (layer == 7)
        for (int i = 0; i < 3; ++i) {
            auto row = ui.PickerModeItem(cfg, i);
            float marker = ui.pickerMetrics.marker;
            auto clip = shift(ui.PickerModesBox(cfg));
            if (i == ui.pickerMode)
                fonts.NativeMergedIcon(c, 12 * s, 0xf00c, row.x + 12 * s, row.y + 7 * s, pal[0], -dx, -dy,
                                       &clip);
            fonts.NativeText(c, 1, 12 * s, PickerFormatLabel(i), row.x + 12 * s + marker, row.y + 7 * s,
                             Mix(pal[14], pal[2], i == ui.pickerMode ? 1.f : ui.modeText[i].value), -dx, -dy,
                             &clip);
        }
    if (layer == 6 && ui.DescriptionRow() == 901) {
        auto b = ui.DescriptionBox(cfg);
        auto ink = pal[0];
        ink.a *= ui.DescriptionAlpha();
        auto clip = shift(b);
        fonts.NativeText(c, 0, 13 * s, ui.Label("window_chat_sendfriendcode"), b.x + 10 * s, b.y + 10 * s,
                         ink, -dx, -dy, &clip);
        return;
    }
    if (layer == 6) {
        int row = ui.DescriptionRow();
        if (row >= 0) {
            auto b = ui.DescriptionBox(cfg);
            auto col = pal[2];
            col.a *= ui.DescriptionAlpha();
            text(ui.Label(ProfileKeys[row]),
                 {b.x + 10 * s, b.y + 10 * s, b.w - 20 * s, ui.RuntimeFontSize(s)}, col, 13, 2);
            float cy = b.y + 20 * s + ui.RuntimeFontSize(s);
            col = pal[14];
            col.a *= ui.DescriptionAlpha();
            std::u32string line;
            for (auto cp : ui.tipLines[row - 6]) {
                if (cp == U'\n') {
                    text(line, {b.x + 10 * s, cy, b.w - 20 * s, ui.RuntimeFontSize(s)}, col);
                    line.clear();
                    cy += ui.RuntimeFontSize(s);
                } else
                    line += cp;
            }
        }
    }

    if (layer == 4) {
        auto b = ui.BaseDropdown(cfg);
        auto ids = ui.BaseLanguages();
        auto clip = shift(b);
        for (int i = 0; i < std::min(6, int(ids.size()) - ui.baseScroll); ++i) {
            int n = ids[ui.baseScroll + i];
            Box row{b.x + 18 * s, b.y + (6 + ui.ItemUnits(s) * i) * s, b.w - 36 * s, ui.ItemUnits(s) * s};
            auto col = Mix(pal[14], pal[2],
                           n < int(ui.baseOptionText.size()) ? ui.baseOptionText[n].value
                           : n == ui.baseLanguage            ? 1.f
                                                             : 0.f);
            fonts.NativeText(c, 0, 13 * s, DecodeUTF8(ui.languages.entries[n].localizedName), row.x,
                             row.y + (row.h - ui.RuntimeFontSize(s)) * .5f, col, -dx, -dy, &clip);
        }
    }
}
inline void RenderProfileCPU(Canvas& c, Fonts& f, const Settings& cfg, const ProfileUI& ui) {
    if (!ui.open)
        return;
    for (int layer : ui.Layers()) {
        if (ui.LayerOpacity(layer) <= 0)
            continue;
        const bool about = layer == 3 && ui.MenuOverlay();
        const float radius = layer == 3 && ui.modal == 4 ? ui.ChatRadius()
                                                         : (about        ? 16
                                                            : layer == 6 ? 10
                                                                         : 15) *
                                                               cfg.scale;
        auto box = ui.LayerBox(cfg, layer);
        if (cfg.blur)
            BlurMenuBackdrop(c, box, radius, ui.BlurSigma(cfg, layer), ui.LayerOpacity(layer),
                             ui.BackdropSkipTop(cfg, layer));
        if (!about)
            DrawMenuShadow(c, box, radius, 18 * cfg.scale, ui.LayerShadowColor(cfg, layer));
        Canvas content(int(std::ceil(box.w)), int(std::ceil(box.h)));

        const bool directChat = (layer == 3 && ui.modal == 4) || (ui.SubmenuRow(layer) == 0);
        if (directChat)
            for (int yy = 0; yy < content.height; ++yy)
                for (int xx = 0; xx < content.width; ++xx) {
                    int gx = int(box.x) + xx, gy = int(box.y) + yy;
                    if (gx >= 0 && gy >= 0 && gx < c.width && gy < c.height)
                        std::copy_n(c.rgba.data() + 4 * (std::size_t(gy) * c.width + gx), 4,
                                    content.rgba.data() + 4 * (std::size_t(yy) * content.width + xx));
                }
        auto contentClip = ui.ContentClip(cfg, layer);
        contentClip.x -= box.x;
        contentClip.y -= box.y;
        for (auto shape : ProfileShapes(cfg, ui, layer, &f)) {
            shape.box.x -= box.x;
            shape.box.y -= box.y;
            content.RoundRect(shape.box, shape.radius, shape.stroke > 0 ? Color{0, 0, 0, 0} : shape.color,
                              shape.color, shape.stroke, 0, shape.corners,
                              shape.contentClip ? &contentClip : nullptr);
        }
        ProfileText(content, f, cfg, ui, -box.x, -box.y, layer);
        for (int y = 0; y < content.height; ++y)
            for (int x = 0; x < content.width; ++x) {
                if (BoxDistance({0, 0, box.w, box.h}, radius, x + .5f, y + .5f) > 0)
                    continue;
                auto p = content.rgba.data() + 4 * (std::size_t(y) * content.width + x);
                float alpha = p[3] / 255.f;
                if (directChat) {
                    int gx = int(box.x) + x, gy = int(box.y) + y;
                    if (gx >= 0 && gy >= 0 && gx < c.width && gy < c.height)
                        std::copy_n(p, 4, c.rgba.data() + 4 * (std::size_t(gy) * c.width + gx));
                } else if (alpha > 0)
                    c.Blend(int(box.x) + x, int(box.y) + y,
                            {p[0] / 255.f / alpha, p[1] / 255.f / alpha, p[2] / 255.f / alpha, alpha});
            }
    }
}
}
