#pragma once
#include "presets_cache.h"
#include "renderer_dx11.h"
namespace menu {

struct PresetsPaintGPUCache {
    static constexpr int Count = 16;
    int firstSlot;
    std::array<PresetGlyphLayer, Count> layers;
    explicit PresetsPaintGPUCache(int slot) : firstSlot(slot) {}
    void Reset() {
        for (auto& layer : layers)
            layer.Reset();
    }
};

struct PresetNativePreviewSink {
    using Draw = void (*)(void*, wm::RendererDX11&, ID3D11RenderTargetView*, int, int, const PresetDraw&,
                          Box);
    Draw draw = nullptr;
    void* context = nullptr;
    inline static thread_local PresetNativePreviewSink* current = nullptr;
};

inline void DrawPresetsGPU(wm::RendererDX11& renderer, ID3D11Texture2D* scene, ID3D11RenderTargetView* target,
                           int w, int h, Fonts& fonts, const Settings& cfg, const PresetsUI& ui, int pass = 0,
                           PresetsPaintGPUCache* cache = nullptr) {
    auto setClip = [&](Box clip) {
        clip = PresetPixelClip(clip);
        renderer.SetClip(clip.x, clip.y, clip.w, clip.h);
    };
    for (std::size_t i = 0; i < ui.layers.size(); ++i) {
        const auto& layer = ui.layers[i];
        if (!PresetLayerInPass(layer, pass))
            continue;
        auto b = layer.box;
        if (layer.nativeHUDScale > 0) {
            renderer.ClearClip();
            renderer.PrepareBackdrop(scene, cfg.sigma * layer.nativeHUDScale, cfg.blur);
        } else if (layer.popup) {
            renderer.ClearClip();
            if (cfg.blur)
                renderer.PrepareBackdrop(scene, 5 * cfg.scale, true);
            if (layer.shadow) {
                auto shadow = CurrentPalette(cfg)[38];
                shadow.a *= layer.opacity;
                renderer.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {0, 0, 0, 0}, layer.radius, 0, 0, false,
                                          false, 18 * cfg.scale, {shadow.r, shadow.g, shadow.b, shadow.a});
            }
            if (cfg.blur)
                renderer.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {1, 1, 1, layer.opacity}, layer.radius,
                                          1, 0, true, true);
        }
        setClip(b);
        for (auto& d : layer.draw)
            if (d.nativePreviewTeam < 0 && d.text.empty() && !d.raster && !d.pixelLine) {
                auto clip = d.clipped ? PresetIntersect(b, d.clip) : b;
                setClip(clip);
                auto c = d.color;
                if (d.indicatorLine) {
                    renderer.DrawOriginalIndicatorLine(target, d.box.x, d.box.y, d.box.w, d.box.h,
                        {c.r, c.g, c.b, c.a}, d.radius, d.indicatorGlow);
                    continue;
                }

                if (d.shadowSize > 0) {
                    auto q = d.shadowColor;
                    renderer.DrawOriginalRect(target, d.box.x, d.box.y, d.box.w, d.box.h, {0, 0, 0, 0},
                                              d.radius, 0, 0, false, false, d.shadowSize,
                                              {q.r, q.g, q.b, q.a}, d.corners, 0, 0, false, 0);
                }
                if (layer.nativeHUDScale > 0 && cfg.blur && d.backdropOpacity > 0)
                    renderer.DrawOriginalRect(target, d.box.x, d.box.y, d.box.w, d.box.h,
                                              {1, 1, 1, d.backdropOpacity}, d.radius, 0, 0, true, true);
                renderer.DrawOriginalRect(target, d.box.x, d.box.y, d.box.w, d.box.h, {c.r, c.g, c.b, c.a},
                                          d.radius, 0, d.stroke, false, false, 0, {}, d.corners);
            }

        if (auto* sink = PresetNativePreviewSink::current)
            for (const auto& d : layer.draw)
                if (d.nativePreviewTeam >= 0 && sink->draw) {
                    auto clip = d.clipped ? PresetIntersect(b, d.clip) : b;
                    if (clip.w > 0 && clip.h > 0 && d.color.a > 0)
                        sink->draw(sink->context, renderer, target, w, h, d, clip);
                }

        bool integerOrigin = layer.nativeHUDScale > 0 || layer.pixelAligned;
        float gx = integerOrigin ? std::floor(b.x) : b.x, gy = integerOrigin ? std::floor(b.y) : b.y;
        int gw = std::max(1, int(std::ceil(b.x + b.w - gx))),
            gh = std::max(1, int(std::ceil(b.y + b.h - gy)));
        setClip(b);
        PresetGlyphLayer fallback;
        auto& entry = cache && i < PresetsPaintGPUCache::Count ? cache->layers[i] : fallback;
        bool upload = entry.Update(fonts, cfg, layer, integerOrigin);
        int slot = cache && i < PresetsPaintGPUCache::Count ? cache->firstSlot + int(i) : 18;
        const auto& glyphs = *entry.glyphs;
        renderer.DrawLayer(target, w, h, glyphs.rgba.data(), gw, gh, gx, gy, float(gw), 0, slot, upload);
        renderer.ClearClip();
    }
    if (cache)
        for (std::size_t i = ui.layers.size(); i < cache->layers.size(); ++i)
            cache->layers[i].Reset();
}
}
