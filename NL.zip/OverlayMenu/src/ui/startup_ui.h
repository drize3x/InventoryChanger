#pragma once
#include "language_catalog.h"
#include "presets_motion.h"
namespace menu {

struct StartupUI {
    static constexpr int Total = 10;
    static constexpr float ExitDuration = .2f;
    static constexpr float CompletedHold = 2.f;
    int current = 0, shown = 0;
    float shownAt = 0;
    bool begun = false, resourcesReady = false, complete = false, failed = false;
    float age = 0, completedAge = 0;
    PresetMotion opacity;
    std::u32string taskBody, taskCounter, errorBody;
    const LanguageCatalog* languages = nullptr;
    void Begin(int ready = 0) {
        current = shown = std::clamp(ready, 0, Total - 1);
        shownAt = 0;
        begun = true;
        resourcesReady = complete = failed = false;
        taskBody.clear();
        taskCounter.clear();
        errorBody.clear();
        age = completedAge = 0;
        opacity.Snap(0);
        opacity.Tick(1, 0);
    }
    void SetProgress(int ready) {
        if (!Loading())
            return;
        current = std::max(current, std::clamp(ready, 0, Total));
        shown = std::min(current, Total - 1);
    }
    void Complete() {
        if (!Loading())
            return;
        current = shown = Total;
        resourcesReady = complete = true;
        completedAge = 0;
        taskBody.clear();
        taskCounter.clear();
    }
    void Fail(const std::u32string& reason = {}) {
        if (!begun)
            return;
        errorBody = reason;
        failed = true;
        resourcesReady = complete = false;
        completedAge = 0;
    }
    void SetTask(const std::u32string& body, std::size_t ready, std::size_t total) {
        if (!Loading())
            return;
        taskBody = body;
        taskCounter = ASCII(std::to_string(ready) + " / " + std::to_string(total));
    }
    void Tick(float dt) {
        if (!begun)
            return;
        dt = std::isfinite(dt) ? std::max(0.f, dt) : 0;
        age += dt;
        if (!complete) {
            opacity.Tick(1.f, dt, ExitDuration);
            return;
        }
        const float before = completedAge;
        completedAge += dt;
        const float holding =
            std::max(0.f, std::min(completedAge, CompletedHold) - std::min(before, CompletedHold));
        if (holding > 0)
            opacity.Tick(1.f, holding, ExitDuration);
        if (completedAge >= CompletedHold) {
            opacity.Tick(0.f, 0, ExitDuration);
            opacity.Tick(0.f, std::max(0.f, completedAge - std::max(before, CompletedHold)), ExitDuration);
        }
    }
    bool MenuReady() const {
        return !begun || (!failed && complete);
    }
    bool BlocksMenu() const {
        return begun && !MenuReady();
    }
    bool Active() const {
        return begun && (!complete || completedAge < CompletedHold || opacity.value > 0.f);
    }
    bool Loading() const {
        return begun && !resourcesReady && !failed;
    }
    std::u32string Body() const {
        if (failed)
            return errorBody.empty() ? U"UI resource initialization failed" : errorBody;
        if (!complete && !taskBody.empty())
            return taskBody;
        const char* key = complete ? "notify_initialization_completed" : "notify_initialization";
        return languages ? languages->Label(key) : DecodeUTF8(DefaultLanguageStrings().at(key));
    }
    std::u32string Counter() const {
        return !taskCounter.empty() ? taskCounter
                                    : ASCII(std::to_string(shown) + " of " + std::to_string(Total));
    }
    float Pulse() const {
        if (!complete || completedAge <= 1)
            return 1;
        float t = std::clamp((completedAge - 1) / .2f, 0.f, 1.f);
        return (1 - t) * (1 - t) * (1 - t);
    }
};

struct StartupPaint {
    Box panel{}, tile{}, logo{}, title{}, body{}, counter{};
    float opacity = 0, radius = 0, shadowSize = 0, offsetX = 0, offsetY = 0;
    Color fill{}, outer{}, inner{}, tileColor{}, titleColor{}, bodyColor{}, counterColor{};
    std::u32string status, count;
};

inline float StartupBlurSigma(float scale) {
    return .5f * 5.f * scale;
}
inline Color StartupHSV(float h, float s, float v) {
    float x = h * 6;
    int i = int(x);
    float f = x - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
    switch (i % 6) {
    case 0:
        return {v, t, p, 1};
    case 1:
        return {q, v, p, 1};
    case 2:
        return {p, v, t, 1};
    case 3:
        return {p, q, v, 1};
    case 4:
        return {t, p, v, 1};
    default:
        return {v, p, q, 1};
    }
}
inline StartupPaint MeasureStartup(Fonts& fonts, const Settings& cfg, const StartupUI& ui,
                                   int viewportWidth) {
    StartupPaint p;
    if (!ui.Active())
        return p;
    float s = cfg.scale, a = std::clamp(ui.opacity.value, 0.f, 1.f);
    p.opacity = a;
    auto pal = CurrentPalette(cfg);
    auto accent = pal[31];
    accent = {Canvas::Byte(accent.r) / 255.f, Canvas::Byte(accent.g) / 255.f, Canvas::Byte(accent.b) / 255.f,
              1};
    float high = std::max({accent.r, accent.g, accent.b}), low = std::min({accent.r, accent.g, accent.b}),
          d = high - low, h = 0, sat = high > 0 ? d / high : 0;
    if (d > 0) {
        if (high == accent.r)
            h = (accent.g - accent.b) / d;
        else if (high == accent.g)
            h = 2 + (accent.b - accent.r) / d;
        else
            h = 4 + (accent.r - accent.g) / d;
        h /= 6;
        if (h < 0)
            h += 1;
    }
    auto background = pal[45];
    float lum = .299f * background.r + .587f * background.g + .114f * background.b;

    float v = lum < .5f ? .094f + 2 * lum * .144f : .92f + 2 * (lum - .5f) * .06f;
    float tintSat = lum < .5f ? .376f + sat * .2f : .05f + sat * .1f;
    p.fill = StartupHSV(h, tintSat, v);
    p.fill.a = .6f * a;
    p.inner = StartupHSV(h, std::clamp(sat * .9f, 0.f, 1.f), high);
    p.inner.a = .35f * a;
    float strength = .8f + .2f * ui.Pulse();
    p.outer = accent;
    p.outer.a = a * strength;
    p.shadowSize = 30 * s * strength;
    const float phase = std::fmod(ui.age, 1.5f) / 1.5f * 6.283185482f;

    p.offsetX = std::cos(phase) * 4 * s * ui.Pulse();
    p.offsetY = std::sin(phase) * 4 * s * ui.Pulse();
    p.status = ui.Body();
    p.count = ui.Counter();
    float F = fonts.PixelHeight(0, 13 * s), titleF = fonts.PixelHeight(2, 14 * s);
    const float textX = 70 * s, textWidth = 310 * s - textX - 14 * s;

    std::u32string wrapped;
    float run = 0;
    std::u32string word;
    auto flush = [&] {
        if (word.empty())
            return;
        float w = fonts.NativeTextSize(0, 13 * s, word).w;
        if (run > 0 && run + w > textWidth) {
            if (!wrapped.empty() && wrapped.back() == U' ')
                wrapped.pop_back();
            wrapped += U'\n';
            run = 0;
        }
        wrapped += word;
        run += w;
        word.clear();
    };
    for (char32_t c : p.status) {
        if (c == U'\n') {
            flush();
            wrapped += c;
            run = 0;
        } else {
            word += c;
            if (c == U' ')
                flush();
        }
    }
    flush();
    p.status = std::move(wrapped);
    float bodyF = F * float(1 + std::count(p.status.begin(), p.status.end(), U'\n')),
          textH = titleF + 2 * s + bodyF;
    float height = std::max(42 * s, textH) + 24 * s;
    p.panel = {float(viewportWidth) - (310 * s + 10 * s) * a, 10 * s, 310 * s, height};
    p.radius = 24 * s;
    p.tile = {p.panel.x + 14 * s, p.panel.y + 12 * s, 42 * s, 42 * s};
    float logoH = 14 * s, logoW = logoH * 79.3f / 46.7f;
    p.logo = {p.tile.x + (p.tile.w - logoW) * .5f, p.tile.y + (p.tile.h - logoH) * .5f, logoW, logoH};
    float y = p.tile.y + std::max(0.f, (42 * s - textH) * .5f);
    p.title = {p.panel.x + textX, y, textWidth, titleF};
    p.body = {p.title.x, y + titleF + 2 * s, textWidth, bodyF};
    float cw = std::trunc(fonts.NativeTextSize(0, 13 * s, p.count).w + .95f);
    p.counter = {p.panel.x + p.panel.w - 14 * s - cw - 2 * s, y, cw, F};
    p.tileColor = pal[42];
    p.tileColor.a *= .75f * a;
    p.titleColor = pal[2];
    p.titleColor.a *= .8f * a;
    p.bodyColor = pal[4];
    p.bodyColor.a *= a;
    p.counterColor = pal[4];
    p.counterColor.a *= .8f * a;
    return p;
}
inline void DrawStartupInk(Canvas& c, Fonts& fonts, const Settings& cfg, const StartupPaint& p,
                           float originX = 0, float originY = 0) {

    for (int y = int(std::floor(p.logo.y)); y < int(std::ceil(p.logo.y + p.logo.h)); ++y)
        for (int x = int(std::floor(p.logo.x)); x < int(std::ceil(p.logo.x + p.logo.w)); ++x) {
            if (x + .5f < p.logo.x || y + .5f < p.logo.y || x + .5f >= p.logo.x + p.logo.w ||
                y + .5f >= p.logo.y + p.logo.h)
                continue;
            float u = (x + .5f - p.logo.x) / p.logo.w * 51 - .5f,
                  v = (y + .5f - p.logo.y) / p.logo.h * 30 - .5f;
            int ix = int(std::floor(u)), iy = int(std::floor(v));
            float fx = u - ix, fy = v - iy, rgba[4]{};
            for (int yy = 0; yy < 2; ++yy)
                for (int xx = 0; xx < 2; ++xx) {
                    int tx = std::clamp(ix + xx, 0, 50), ty = std::clamp(iy + yy, 0, 29);
                    auto* q = wm::LogoRGBA + 4 * (ty * 51 + tx);
                    float weight = (xx ? fx : 1 - fx) * (yy ? fy : 1 - fy), a = q[3] / 255.f;
                    for (int k = 0; k < 3; ++k)
                        rgba[k] += q[k] / 255.f * a * weight;
                    rgba[3] += a * weight;
                }
            if (rgba[3] > 0)
                c.Blend(int(x - originX), int(y - originY),
                        {rgba[0] / rgba[3], rgba[1] / rgba[3], rgba[2] / rgba[3], rgba[3] * p.opacity});
        }
    Box clip{p.panel.x - originX, p.panel.y - originY, p.panel.w, p.panel.h};
    fonts.NativeText(c, 2, 14 * cfg.scale, U"Neverlose", p.title.x, p.title.y, p.titleColor, originX, originY,
                     &clip);
    fonts.NativeText(c, 0, 13 * cfg.scale, p.status, p.body.x, p.body.y, p.bodyColor, originX, originY,
                     &clip);
    fonts.NativeText(c, 0, 13 * cfg.scale, p.count, p.counter.x, p.counter.y, p.counterColor, originX,
                     originY, &clip);
}
inline void RenderStartupCPU(Canvas& c, Fonts& fonts, const Settings& cfg, const StartupUI& ui) {
    auto p = MeasureStartup(fonts, cfg, ui, c.width);
    if (p.opacity <= 0)
        return;
    auto b = p.panel;

    if (cfg.blur)
        BlurMenuBackdrop(c, b, p.radius, StartupBlurSigma(cfg.scale), p.opacity);
    float padx = p.shadowSize * .5f + std::abs(p.offsetX), pady = p.shadowSize * .5f + std::abs(p.offsetY);
    for (int y = std::max(0, int(std::floor(b.y - pady - 1)));
         y < std::min(c.height, int(std::ceil(b.y + b.h + pady + 1))); ++y)
        for (int x = std::max(0, int(std::floor(b.x - padx - 1)));
             x < std::min(c.width, int(std::ceil(b.x + b.w + padx + 1))); ++x) {
            float d = BoxDistance(b, p.radius, x + .5f, y + .5f, 1),
                  fw = std::abs(BoxDistance(b, p.radius, x + 1.5f, y + .5f, 1) - d) +
                       std::abs(BoxDistance(b, p.radius, x + .5f, y + 1.5f, 1) - d);
            float shifted = BoxDistance(b, p.radius, x + .5f - p.offsetX, y + .5f - p.offsetY, 1),
                  fade = 1 - Smooth((shifted + p.shadowSize * .5f) / p.shadowSize);
            c.Blend(x, y, p.outer, Smooth((d + fw) / std::max(.001f, 2 * fw)) * fade);
        }
    for (int y = std::max(0, int(b.y - 1)); y < std::min(c.height, int(std::ceil(b.y + b.h + 1))); ++y)
        for (int x = std::max(0, int(b.x - 1)); x < std::min(c.width, int(std::ceil(b.x + b.w + 1))); ++x) {
            float d = BoxDistance(b, p.radius, x + .5f, y + .5f, 1), coverage = 1 - Smooth((d + 1) * .5f),
                  inner = p.inner.a * (1 - Smooth(-d / (8 * cfg.scale)));
            auto tint = Mix(p.fill, p.inner, inner);
            tint.a = p.fill.a;
            c.Blend(x, y, tint, coverage);
        }
    c.RoundRect(p.tile, 12 * cfg.scale, p.tileColor);
    DrawStartupInk(c, fonts, cfg, p);
}
}
