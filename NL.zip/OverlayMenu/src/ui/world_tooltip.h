#pragma once
#include "presets_ui.h"
namespace menu {

inline PresetLayer WorldDescriptionTooltip(Fonts& fonts, const Settings& cfg, Box item,
                                           const std::u32string& title, const std::u32string& body, int width,
                                           int height, float requestedTextWidth = 0) {
    return PresetDescriptionTooltip(fonts, cfg, item, title, body, width, height, requestedTextWidth);
}

inline PresetLayer WorldCollectionTooltip(Fonts& fonts, const Settings& cfg, Box item,
                                          const std::u32string& title, const std::u32string& group,
                                          const std::u32string& remainder, int width, int height,
                                          PresetDraw icon) {
    const float s = cfg.scale, F = fonts.PixelHeight(0, 13 * s), pad = 10 * s, iconSize = 32 * s, gap = 8 * s;
    const float maxWidth = std::max(1.f, std::min(20 * F, float(width) - 26 * s));
    auto wrap = [&](const std::u32string& text, float available) {
        std::vector<std::u32string> lines;
        std::u32string line, word;
        auto flush = [&] {
            lines.push_back(line);
            line.clear();
        };
        auto append = [&] {
            if (!line.empty() && fonts.NativeTextSize(0, 13 * s, line + U" " + word).w > available)
                flush();
            if (!line.empty() && !word.empty())
                line += U" ";
            line += word;
            word.clear();
        };
        for (char32_t cp : text) {
            if (cp == U' ' || cp == U'\n') {
                append();
                if (cp == U'\n')
                    flush();
            } else
                word += cp;
        }
        append();
        if (!line.empty() || lines.empty())
            flush();
        return lines;
    };
    auto groups = wrap(group, std::max(1.f, maxWidth - iconSize - gap));
    auto lines = remainder.empty() ? std::vector<std::u32string>{} : wrap(remainder, maxWidth);
    float widest = fonts.NativeTextSize(2, 13 * s, title).w;
    for (const auto& t : groups)
        widest = std::max(widest, iconSize + gap + fonts.NativeTextSize(0, 13 * s, t).w);
    for (const auto& t : lines)
        widest = std::max(widest, fonts.NativeTextSize(0, 13 * s, t).w);
    const float w = std::min(std::trunc(widest + .95f) + 2 * pad, std::max(1.f, float(width) - 6 * s));
    const float row = std::max(iconSize, F * float(groups.size()));
    const float h = std::min(3 * pad + F + row + (lines.empty() ? 0.f : pad + F * float(lines.size())),
                             std::max(1.f, float(height) - 6 * s));
    Box b{std::trunc(std::clamp(item.x + item.w + 15 * s, 3 * s, std::max(3 * s, float(width) - w - 3 * s))),
          std::trunc(
              std::clamp(item.y + (item.h - h) * .5f, 3 * s, std::max(3 * s, float(height) - h - 3 * s))),
          w, h};
    auto pal = CurrentPalette(cfg);
    PresetLayer layer{b, 10 * s, true, {}};
    layer.draw.push_back({b, pal[8], 10 * s, 0, 15, {}, false});
    layer.draw.push_back({b, pal[11], 10 * s, s, 15, {}, false});
    auto text = [&](const std::u32string& t, float x, float y, float tw, int font, Color col) {
        if (t.empty())
            return;
        PresetDraw d{{x, y, std::max(0.f, tw), F}, col, 0, 0, 15, t, false};
        d.font = font;
        d.textSize = 13;
        d.clipped = true;
        d.clip = b;
        layer.draw.push_back(std::move(d));
    };
    text(title, b.x + pad, b.y + pad, b.w - 2 * pad, 2, pal[2]);
    const float y = b.y + 2 * pad + F;
    for (std::size_t i = 0; i < groups.size(); ++i)
        text(groups[i], b.x + pad + iconSize + gap, y + (row - F * float(groups.size())) * .5f + F * float(i),
             b.w - 2 * pad - iconSize - gap, 0, pal[14]);
    for (std::size_t i = 0; i < lines.size(); ++i)
        text(lines[i], b.x + pad, y + row + pad + F * float(i), b.w - 2 * pad, 0, pal[14]);
    icon.box.x += b.x + pad;
    icon.box.y += y;
    icon.clipped = true;
    icon.clip = b;
    layer.draw.push_back(std::move(icon));
    return layer;
}

inline PresetLayer WorldNameTooltip(Fonts& fonts, const Settings& cfg, Box item, const std::u32string& name,
                                    int width, int height) {
    const float s = cfg.scale, F = fonts.PixelHeight(0, 13 * s), pad = 10 * s;
    float w = std::min(std::trunc(fonts.NativeTextSize(0, 13 * s, name).w + .95f) + 2 * pad,
                       std::max(1.f, float(width) - 6 * s)),
          h = F + 2 * pad;
    Box b{std::trunc(std::clamp(item.x + item.w + 15 * s, 3 * s, std::max(3 * s, float(width) - w - 3 * s))),
          std::trunc(
              std::clamp(item.y + (item.h - h) * .5f, 3 * s, std::max(3 * s, float(height) - h - 3 * s))),
          w, h};
    auto pal = CurrentPalette(cfg);
    PresetLayer layer{b, 10 * s, true, {}};
    layer.draw.push_back({b, pal[8], 10 * s, 0, 15, {}, false});
    layer.draw.push_back({b, pal[11], 10 * s, s, 15, {}, false});
    PresetDraw text{{b.x + pad, b.y + pad, b.w - 2 * pad, F}, pal[2], 0, 0, 15, name, false};
    text.font = 0;
    text.textSize = 13;
    text.clipped = true;
    text.clip = b;
    layer.draw.push_back(std::move(text));
    return layer;
}
inline void AppendWorldTooltip(PresetsUI& paint, const PresetLayer& cached, float opacity) {
    if (opacity <= 0)
        return;
    auto tip = cached;
    tip.opacity = opacity;
    for (auto& d : tip.draw)
        d.color.a *= opacity;
    paint.layers.push_back(std::move(tip));
}
}
