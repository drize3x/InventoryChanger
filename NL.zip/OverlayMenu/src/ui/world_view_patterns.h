#pragma once

#include "watermark_hud_patterns.h"
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
namespace menu {
struct ViewmodelBindings {
    std::uintptr_t function = 0, localGetter = 0, floatGetter = 0, clamp = 0;
    std::array<std::uintptr_t, 4> convars{};
};
namespace world_view_patterns {
inline constexpr char Params[] =
    "40 55 53 56 41 56 41 57 48 8B EC 48 83 EC 20 4D 8B F8 4C 8B F2 48 8B F1 E8 ? ? ? ? 48 8B D8 "
    "48 85 C0 74 10 48 8B 00 48 8B CB FF 90 B8 0A 00 00 84 C0 75 02 33 DB 48 89 7C 24 58 48 3B F3 74 "
    "66 48 8B 4E 10 8B 41 30 0F BA E0 0B 73 07 C1 E8 06 24 01 EB 26 48 85 C9 74 0F 83 79 10 FF B8 FF "
    "7F 00 00 0F 45 41 10 EB 05 B8 FF FF FF FF 25 FF 7F 00 00 3D 00 40 00 00 0F 92 C0 84 C0 74 28 8B "
    "86 C0 1D 00 00 41 89 06 8B 86 C4 1D 00 00 41 89 46 04 8B 86 C8 1D 00 00 41 89 46 08 8B 86 CC 1D "
    "00 00 41 89 07 EB 46 48 8D 0D ? ? ? ? E8 ? ? ? ? 48 8D 0D ? ? ? ? F3 41 0F 11 06 E8 "
    "? ? ? ? 48 8D 0D ? ? ? ? F3 41 0F 11 46 04 E8 ? ? ? ? 48 8D 0D ? ? ? ? F3 41 0F "
    "11 46 08 E8 ? ? ? ? F3 41 0F 11 07 4C 8D 45 30 C7 45 30 00 00 20 40 48 8D 55 48 C7 45 48 00 "
    "00 00 C0 49 8B CE E8 ? ? ? ? 4C 8D 45 30 F3 41 0F 11 06 48 8D 55 48 C7 45 30 00 00 00 40 49 "
    "8D 4E 04 C7 45 48 00 00 00 C0 E8 ? ? ? ? 4C 8D 45 30 F3 41 0F 11 46 04 48 8D 55 48 C7 45 30 "
    "00 00 00 40 49 8D 4E 08 C7 45 48 00 00 00 C0 E8 ? ? ? ? 4C 8D 45 30 F3 41 0F 11 46 08 48 8D "
    "55 48 C7 45 30 00 00 88 42 49 8B CF C7 45 48 00 00 70 42 E8 ? ? ? ? 48 8B 7C 24 58 F3 41 0F "
    "11 07 48 83 C4 20 41 5F 41 5E 5E 5B 5D C3";

inline constexpr unsigned LocalCall = 0x18, FloatCalls[4] = {0xae, 0xbf, 0xd1, 0xe3},
                          ConvarLeas[4] = {0xa7, 0xb3, 0xc4, 0xd6},
                          ClampCalls[4] = {0x106, 0x12a, 0x14f, 0x173};
inline constexpr unsigned FunctionSize = 0x18e;
inline std::uintptr_t Unique(const HudScanImage& image, const char* pattern) {
    auto hits = image.Find(pattern, true, 2);
    return hits.size() == 1 ? hits[0] : 0;
}
}
inline bool ResolveViewmodelParams(const HudScanImage& image, ViewmodelBindings& out,
                                   std::string& diagnostic) {
    using namespace world_view_patterns;
    out = {};
    ViewmodelBindings b;
    auto fail = [&](const char* reason) {
        diagnostic = std::string("View/Viewmodel disabled: ") + reason;
        return false;
    };
    b.function = Unique(image, Params);
    if (!b.function)
        return fail("missing/ambiguous GetViewmodelParams signature");
    const auto call = [&](unsigned at) { return image.Rip(b.function + at, 1, 5); };

    b.localGetter = call(LocalCall);
    b.floatGetter = call(FloatCalls[0]);
    b.clamp = call(ClampCalls[0]);
    for (unsigned i = 0; i < 4; ++i) {
        if (call(FloatCalls[i]) != b.floatGetter || call(ClampCalls[i]) != b.clamp)
            return fail("shared float getter / clamp helper changed");
        b.convars[i] = image.Rip(b.function + ConvarLeas[i]);
        if (!b.convars[i] || !image.Contains(b.convars[i], 8, 0x40000000, 0x20000000))
            return fail("ConVar object outside image data");
        for (unsigned j = 0; j < i; ++j)
            if (b.convars[j] == b.convars[i])
                return fail("duplicate ConVar object");
    }
    if (!b.localGetter || !b.floatGetter || !b.clamp || !image.Contains(b.localGetter, 1, 0x20000000) ||
        !image.Contains(b.floatGetter, 1, 0x20000000) || !image.Contains(b.clamp, 1, 0x20000000) ||
        b.localGetter == b.floatGetter || b.floatGetter == b.clamp || b.localGetter == b.clamp ||
        !image.Contains(b.function, FunctionSize, 0x20000000))
        return fail("callee outside executable image");
    out = b;
    diagnostic = "View/Viewmodel [params-v1]: GetViewmodelParams verified by full-function signature; game "
                 "clamp stays in place, the override is applied after it";
    return true;
}
}
