#pragma once

inline constexpr std::array<const char*, 11> RageGroupEquipment{
    {"g3sg1|scar20", "ssg08", "awp", "deagle", "revolver",
     "glock|hkp2000|usp_silencer|elite|p250|tec9|fiveseven|cz75a",
     "ak47|aug|famas|galilar|m4a1|m4a1_silencer|sg556", "mac10|mp5sd|mp7|mp9|p90|bizon|ump45",
     "mag7|nova|sawedoff|xm1014", "m249|negev", "taser"}};
inline std::vector<std::string> RageEquipmentNames(unsigned mask) {
    std::vector<std::string> out;
    for (std::size_t g = 0; g < RageGroupEquipment.size(); ++g)
        if (mask & (1u << g)) {
            std::string text = RageGroupEquipment[g];
            std::size_t start = 0;
            for (;;) {
                auto end = text.find('|', start);
                out.push_back(text.substr(start, end - start));
                if (end == std::string::npos)
                    break;
                start = end + 1;
            }
        }
    return out;
}
inline bool RageEquipmentKnown(const std::string& name) {
    auto all = RageEquipmentNames(2047);
    return std::find(all.begin(), all.end(), name) != all.end();
}

inline std::string RageEquipmentLabel(const std::string& name) {
    struct Entry {
        const char* id;
        const char* name;
    };
    static const Entry labels[] = {{"g3sg1", "G3SG1"},
                                   {"scar20", "SCAR-20"},
                                   {"ssg08", "SSG 08"},
                                   {"awp", "AWP"},
                                   {"deagle", "Desert Eagle"},
                                   {"revolver", "R8 Revolver"},
                                   {"glock", "Glock-18"},
                                   {"hkp2000", "P2000"},
                                   {"usp_silencer", "USP-S"},
                                   {"elite", "Dual Berettas"},
                                   {"p250", "P250"},
                                   {"tec9", "Tec-9"},
                                   {"fiveseven", "Five-SeveN"},
                                   {"cz75a", "CZ75-Auto"},
                                   {"ak47", "AK-47"},
                                   {"aug", "AUG"},
                                   {"famas", "FAMAS"},
                                   {"galilar", "Galil AR"},
                                   {"m4a1", "M4A4"},
                                   {"m4a1_silencer", "M4A1-S"},
                                   {"sg556", "SG 553"},
                                   {"mac10", "MAC-10"},
                                   {"mp5sd", "MP5-SD"},
                                   {"mp7", "MP7"},
                                   {"mp9", "MP9"},
                                   {"p90", "P90"},
                                   {"bizon", "PP-Bizon"},
                                   {"ump45", "UMP-45"},
                                   {"mag7", "MAG-7"},
                                   {"nova", "Nova"},
                                   {"sawedoff", "Sawed-Off"},
                                   {"xm1014", "XM1014"},
                                   {"m249", "M249"},
                                   {"negev", "Negev"},
                                   {"taser", "Zeus x27"}};
    for (const auto& e : labels)
        if (name == e.id)
            return e.name;
    return name;
}
