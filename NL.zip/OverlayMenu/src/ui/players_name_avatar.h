#pragma once
#include "players_esp_preview.h"
namespace menu {

struct PlayersNameAvatar {
    struct Metrics {
        float width = 0, height = 0, side = 0, advance = 0, textHeight = 0, fontSize = 0, anchorHeight = 0,
              hitHeight = 0, imageY = 0, textY = 0;
    };
    struct Entry {
        std::shared_ptr<const ProfileImage> source;
        int size = 0;
        std::shared_ptr<const Canvas> raster;
        std::uint64_t stamp = 0;
    };
    std::vector<Entry> entries;
    static bool Valid(const ProfileImage* p) {
        return p && p->width > 0 && p->height > 0 && p->width <= 4096 && p->height <= 4096 &&
               p->rgba.size() == std::size_t(p->width) * p->height * 4;
    }
    static Metrics Measure(float w, float h, float fontSize, int side, const ProfileImage* image) {
        Metrics m{w, h, 0, 0, h, fontSize, h, h, 0, 0};
        if (!Valid(image))
            return m;
        m.side = std::max(fontSize, 11.f);
        m.advance = m.side + 5;
        m.width += m.advance;

        m.hitHeight = h + (side == 3 ? 2.f : 0.f);
        m.height = std::max(m.hitHeight, m.side);

        m.imageY = side == 3 ? 0.f : h - m.side + 1.f;
        m.textY = side == 3 ? (m.side - fontSize) * .5f : 0.f;
        return m;
    }
    const Entry& Raster(std::shared_ptr<const ProfileImage> image, int size) {
        for (auto& entry : entries)
            if (entry.source == image && entry.size == size)
                return entry;
        if (entries.size() >= 128)
            entries.erase(entries.begin());
        auto c = std::make_shared<Canvas>(size, size);
        DrawImage(*c, *image, {0, 0, float(size), float(size)});
        for (int y = 0; y < size; ++y)
            for (int x = 0; x < size; ++x) {
                float dx = std::max(std::abs(x + .5f - size * .5f) - (size * .5f - 3), 0.f),
                      dy = std::max(std::abs(y + .5f - size * .5f) - (size * .5f - 3), 0.f);
                float coverage = std::clamp(3.5f - std::hypot(dx, dy), 0.f, 1.f);
                for (int k = 0; k < 4; ++k) {
                    auto& b = c->rgba[4 * (std::size_t(y) * size + x) + k];
                    b = static_cast<unsigned char>(std::lround(b * coverage));
                }
            }
        std::uint64_t stamp = 14695981039346656037ull;
        for (auto b : c->rgba) {
            stamp ^= b;
            stamp *= 1099511628211ull;
        }
        entries.push_back({std::move(image), size, c, stamp});
        return entries.back();
    }
    void Draw(PresetLayer& layer, Box clip, Box box, const std::u32string& label, Color ink,
              PlayersMainPreview::Font font, float scale, const Metrics& m,
              std::shared_ptr<const ProfileImage> image, int) {
        if (m.side > 0 && Valid(image.get())) {
            const auto& cached = Raster(std::move(image), int(std::ceil(m.side)));
            float y = box.y + m.imageY;
            PresetDraw d{{box.x, std::trunc(y), m.side, m.side},
                         {1, 1, 1, PlayersMainPreview::Packed(ink).a},
                         0,
                         0,
                         15,
                         {},
                         false};
            d.clip = clip;
            d.clipped = true;
            d.previewItem = 1;
            d.raster = cached.raster;
            d.rasterStamp = cached.stamp;
            layer.draw.push_back(std::move(d));
        }
        box.x += m.advance;
        box.y += m.textY;
        box.w -= m.advance;
        box.h = m.textHeight;
        PlayersMainPreview::Text(layer, clip, box, label, ink, font, scale);
    }
};
}
