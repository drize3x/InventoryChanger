#pragma once
#include "watermark_kd.h"
#include <array>
#include <vector>
#include <string>
#include <limits>
#include <algorithm>
namespace menu {

inline constexpr std::array<int, 12> WatermarkKdEntityPattern{
    {0x48, 0x8B, 0x0D, -1, -1, -1, -1, 0x8B, 0xFB, 0xC1, 0xEB, 0x0E}};
inline constexpr std::array<int, 11> WatermarkKdLocalPattern{
    {0x48, 0x39, 0x1D, -1, -1, -1, -1, 0x75, 0x04, 0xB0, 0x01}};
template <std::size_t N>
std::vector<std::size_t> WatermarkKdMatches(const unsigned char* data, std::size_t size,
                                            const std::array<int, N>& pattern) {
    std::vector<std::size_t> hits;
    if (size < N)
        return hits;
    for (std::size_t i = 0; i <= size - N; ++i) {
        bool same = true;
        for (std::size_t j = 0; j < N; ++j)
            if (pattern[j] >= 0 && data[i + j] != pattern[j]) {
                same = false;
                break;
            }
        if (same) {
            hits.push_back(i);
            if (hits.size() == 2)
                break;
        }
    }
    return hits;
}
struct WatermarkKdSection {
    std::uint32_t rva = 0, size = 0, flags = 0;
};
struct WatermarkKdModule {
    std::uintptr_t base = 0;
    std::uint32_t size = 0, timestamp = 0;
    std::vector<WatermarkKdSection> sections;
};
template <class Reader>
bool WatermarkKdLoadModule(Reader&& read, std::uintptr_t base, WatermarkKdModule& out) {
    out = {};
    std::uint16_t magic = 0, machine = 0, count = 0, optSize = 0;
    std::uint32_t peOffset = 0, signature = 0, size = 0, timestamp = 0;
    if (!base || !read(base, magic) || magic != 0x5A4D || !read(base + 0x3C, peOffset) || peOffset < 0x40 ||
        peOffset > 0x100000)
        return false;
    auto pe = base + peOffset;
    if (!read(pe, signature) || signature != 0x4550 || !read(pe + 4, machine) || machine != 0x8664 ||
        !read(pe + 6, count) || count == 0 || count > 96 || !read(pe + 8, timestamp) ||
        !read(pe + 20, optSize) || optSize < 112 || optSize > 4096 || !read(pe + 24, magic) ||
        magic != 0x20B || !read(pe + 24 + 56, size) || size < 0x1000 || size > 0x40000000 ||
        peOffset + 24u + optSize + std::uint32_t(count) * 40 > size ||
        base > std::numeric_limits<std::uintptr_t>::max() - size)
        return false;
    out.base = base;
    out.size = size;
    out.timestamp = timestamp;
    for (unsigned i = 0; i < count; ++i) {
        auto address = pe + 24 + optSize + i * 40;
        WatermarkKdSection section;
        if (!read(address + 8, section.size) || !read(address + 12, section.rva) ||
            !read(address + 36, section.flags) || section.rva > size || section.size > size - section.rva) {
            out = {};
            return false;
        }
        out.sections.push_back(section);
    }
    return true;
}
inline bool WatermarkKdDataAddress(const WatermarkKdModule& module, std::uintptr_t address) {
    if (address < module.base || address - module.base > module.size ||
        module.size - (address - module.base) < sizeof(std::uintptr_t))
        return false;
    auto rva = address - module.base;
    for (const auto& section : module.sections)
        if (!(section.flags & 0x20000000) && (section.flags & 0x80000000) && rva >= section.rva &&
            rva - section.rva <= section.size && section.size - (rva - section.rva) >= sizeof(std::uintptr_t))
            return true;
    return false;
}
template <class Reader>
std::optional<std::uintptr_t> WatermarkKdRipTarget(Reader&& read, const WatermarkKdModule& module,
                                                   std::uintptr_t instruction) {
    std::int32_t displacement = 0;
    if (!read(instruction + 3, displacement))
        return {};
    auto target = std::int64_t(instruction) + 7 + std::int64_t(displacement);
    if (target <= 0 || !WatermarkKdDataAddress(module, std::uintptr_t(target)))
        return {};
    return std::uintptr_t(target);
}

template <class Reader>
bool WatermarkKdStringEquals(Reader&& read, std::uintptr_t address, const char* text) {
    if (!address)
        return false;
    for (std::size_t i = 0; i < 256; ++i) {
        char value = 0;
        if (!read(address + i, value) || value != text[i])
            return false;
        if (value == 0)
            return true;
    }
    return false;
}
template <class Reader>
std::optional<std::uint32_t> WatermarkKdSchemaField(Reader&& read, std::uintptr_t info, const char* className,
                                                    const char* fieldName) {
    std::uintptr_t name = 0, fields = 0;
    std::uint16_t count = 0;
    if (!info || !read(info + 8, name) || !WatermarkKdStringEquals(read, name, className) ||
        !read(info + 0x24, count) || count > 8192 || !read(info + 0x30, fields) || (!fields && count))
        return {};
    for (std::uint32_t i = 0; i < count; ++i) {
        auto field = fields + std::uintptr_t(i) * 0x20;
        std::uintptr_t fieldText = 0;
        if (!read(field, fieldText))
            return {};
        if (!WatermarkKdStringEquals(read, fieldText, fieldName))
            continue;
        std::uint32_t offset = 0;
        if (!read(field + 0x10, offset) || offset > 0x100000)
            return {};
        return offset;
    }
    return {};
}
struct WatermarkKdController {
    bool ok = false;
    std::uintptr_t value = 0;
    const char* route = "none";
    const char* error = "controller not resolved";
};
template <class Reader>
WatermarkKdController WatermarkKdLocalController(Reader&& read, std::uintptr_t entityGlobal,
                                                 std::uintptr_t localGlobal, std::uint32_t localFlag) {

    if (entityGlobal) {
        std::uintptr_t root = 0, page = 0;
        if (read(entityGlobal, root) && root && read(root + 0x10, page) && page) {
            for (std::uintptr_t i = 1; i <= 64; ++i) {
                std::uintptr_t entity = 0;
                std::uint8_t local = 0;
                if (!read(page + i * 0x70, entity) || !entity || !read(entity + localFlag, local) ||
                    local != 1)
                    continue;
                std::uintptr_t current = 0;
                if (!read(page + i * 0x70, current) || current != entity || !read(entityGlobal, current) ||
                    current != root || !read(root + 0x10, current) || current != page)
                    return {false, 0, "entity-list", "entity-list changed during sample"};
                return {true, entity, "entity-list", nullptr};
            }
        }
    }

    if (localGlobal) {
        std::uintptr_t controller = 0;
        std::uint8_t local = 0;
        if (!read(localGlobal, controller))
            return {false, 0, "local-global", "local-global read failed"};
        if (!controller)
            return {true, 0, "local-global", nullptr};
        if (!read(controller + localFlag, local))
            return {false, 0, "local-global", "local-controller flag read failed"};
        if (local != 1)
            return {false, 0, "local-global", "resolved controller is not marked local"};
        return {true, controller, "local-global", nullptr};
    }
    return {false, 0, "none", "no local controller found; local-global signature unavailable"};
}
}
