#pragma once

enum class RageKind { Check, Integer, Decimal, Choice, Multi, Opener, Color, Hotkey };
enum RageField {
    Enabled,
    SilentAim,
    AutomaticFire,
    Limiters,
    AimFov,
    AimSpeed,
    ReactionTime,
    KillDelay,
    MaxWalls,
    Backtrack,
    Selftrack,
    UnknownLimiter,
    RefineShot,
    FieldOfView,
    Hitboxes,
    Extrapolation,
    HitChance,
    ForceShot,
    MinHitChance,
    MinDamage,
    QuickStop,
    QuickStopOptions,
    QuickScope,
    History,
    DelayShot,
    RemoveSpread,
    FutureTicks,
    DuckPeek,
    QuickPeek,
    PeekColor,
    MaxDistance,
    RetreatMode,
    JumpOnRetreat,
    AllowMovement,
    DoublePrecision,
    DoubleTap,
    AntiAimEnabled,
    DisableOnUse,
    FastWeaponSwitch,
    SuppressBreathing,
    LegMovement,
    Pitch,
    PitchMode,
    PitchOffset,
    Yaw,
    YawMode,
    AvoidBackstab,
    AutoAdjust,
    YawOffset,
    Jitter,
    JitterBase,
    JitterDisablers,
    JitterOffset,
    Spin,
    SpinOffset,
    MouseOverride,
    OverrideHotkey,
    OverrideBase,
    Sensitivity,
    Deadzone,
    OverrideColor,
    OverrideStyle,
    RageFieldCount
};
struct RageSpec {
    const char* id;
    const char* key;
    RageKind kind;
    float minimum, maximum, initial;
    int group, popup;
    const char* options;
    const char* tooltip;
};
inline constexpr std::array<RageSpec, 62> RageSpecs{{
    {"Enabled", "enabled", RageKind::Check, 0.f, 1.f, 0.f, 0, 0, "", "enabled_tooltip"},
    {"SilentAim", "ragebot_main_silentaim", RageKind::Check, 0.f, 1.f, 1.f, 0, 0, "",
     "ragebot_main_silentaim_tooltip"},
    {"AutomaticFire", "ragebot_main_automaticfire", RageKind::Check, 0.f, 1.f, 1.f, 0, 0, "",
     "ragebot_main_automaticfire_tooltip"},
    {"Limiters", "ragebot_main_limiters", RageKind::Check, 0.f, 1.f, 0.f, 0, 0, "", ""},
    {"AimFov", "ragebot_main_limiters_aimfov", RageKind::Decimal, 0.f, 180.f, 180.f, 0, 1, "",
     "ragebot_main_limiters_aimfov_tooltip"},
    {"AimSpeed", "ragebot_main_limiters_aimspeed", RageKind::Integer, 0.f, 301.f, 301.f, 0, 1, "",
     "ragebot_main_limiters_aimspeed_tooltip"},
    {"ReactionTime", "ragebot_main_limiters_reactiontime", RageKind::Integer, 0.f, 1000.f, 0.f, 0, 1, "", ""},
    {"KillDelay", "ragebot_main_limiters_killdelay", RageKind::Integer, 0.f, 5000.f, 0.f, 0, 1, "", ""},
    {"MaxWalls", "ragebot_main_limiters_maxwalls", RageKind::Integer, 0.f, 4.f, 4.f, 0, 1, "",
     "ragebot_main_limiters_maxwalls_tooltip"},
    {"Backtrack", "ragebot_main_limiters_backtrack", RageKind::Integer, 0.f, 13.f, 13.f, 0, 1, "",
     "ragebot_main_limiters_backtrack_tooltip"},
    {"Selftrack", "ragebot_main_limiters_selftrack", RageKind::Check, 0.f, 1.f, 1.f, 0, 1, "", ""},
    {"UnknownLimiter", "@Unknown option [9406E384]", RageKind::Check, 0.f, 1.f, 0.f, 0, 1, "", ""},
    {"RefineShot", "ragebot_main_refineshot", RageKind::Check, 0.f, 1.f, 1.f, 0, 0, "",
     "ragebot_main_refineshot_tooltip"},
    {"FieldOfView", "ragebot_main_fieldofview", RageKind::Decimal, 0.f, 180.f, 180.f, 0, 0, "",
     "ragebot_main_fieldofview_tooltip"},
    {"Hitboxes", "ragebot_selection_hitboxes", RageKind::Multi, 0.f, 63.f, 63.f, 1, 0,
     "aimbot_hitboxes_head|aimbot_hitboxes_chest|aimbot_hitboxes_stomach|aimbot_hitboxes_arms|aimbot_"
     "hitboxes_legs|aimbot_hitboxes_feet",
     "ragebot_selection_hitboxes_tooltip"},
    {"Extrapolation", "ragebot_selection_extrapolation", RageKind::Integer, 0.f, 100.f, 50.f, 1, 0, "",
     "ragebot_selection_extrapolation_tooltip"},
    {"HitChance", "ragebot_selection_hitchance", RageKind::Integer, 0.f, 100.f, 65.f, 1, 0, "",
     "ragebot_selection_hitchance_tooltip"},
    {"ForceShot", "ragebot_selection_hitchance_forceshot", RageKind::Check, 0.f, 1.f, 0.f, 1, 7, "",
     "ragebot_selection_hitchance_forceshot_tooltip"},
    {"MinHitChance", "ragebot_selection_minhitchance", RageKind::Integer, 0.f, 100.f, 5.f, 1, 7, "",
     "ragebot_selection_minhitchance_tooltip"},
    {"MinDamage", "ragebot_selection_minimumdamage", RageKind::Integer, 1.f, 101.f, 10.f, 1, 0, "",
     "ragebot_selection_minimumdamage_tooltip"},
    {"QuickStop", "ragebot_selection_quickstop", RageKind::Check, 0.f, 1.f, 0.f, 1, 0, "",
     "ragebot_selection_quickstop_tooltip"},
    {"QuickStopOptions", "ragebot_selection_quickstop_options", RageKind::Multi, 0.f, 7.f, 0.f, 1, 8,
     "ragebot_selection_quickstop_options_inair|ragebot_selection_quickstop_options_onland|ragebot_selection_"
     "quickstop_options_betweenshots",
     ""},
    {"QuickScope", "ragebot_selection_quickscope", RageKind::Check, 0.f, 1.f, 0.f, 1, 0, "",
     "ragebot_selection_quickscope_tooltip"},
    {"History", "ragebot_other_history", RageKind::Choice, 0.f, 3.f, 2.f, 2, 0,
     "ragebot_other_history_low|ragebot_other_history_medium|ragebot_other_history_high|ragebot_other_"
     "history_maximum",
     "ragebot_other_history_tooltip"},
    {"DelayShot", "ragebot_other_delayshot", RageKind::Multi, 0.f, 3.f, 3.f, 2, 0,
     "ragebot_other_delayshot_damage|ragebot_other_delayshot_hitchance", "ragebot_other_delayshot_tooltip"},
    {"RemoveSpread", "ragebot_other_removespread", RageKind::Choice, 0.f, 2.f, 0.f, 2, 0,
     "ragebot_other_removespread_off|ragebot_other_removespread_seeded|ragebot_other_removespread_full",
     "ragebot_other_removespread_tooltip"},
    {"FutureTicks", "ragebot_other_delayshot_futureticks", RageKind::Integer, 1.f, 5.f, 3.f, 2, 9, "", ""},
    {"DuckPeek", "ragebot_other_duckpeekassist", RageKind::Check, 0.f, 1.f, 0.f, 2, 0, "",
     "ragebot_other_duckpeekassist_tooltip"},
    {"QuickPeek", "ragebot_other_quickpeekassist", RageKind::Check, 0.f, 1.f, 0.f, 2, 0, "",
     "ragebot_other_quickpeekassist_tooltip"},
    {"PeekColor", "@Color", RageKind::Color, 0.f, 1.f, 0.f, 2, 2, "", ""},
    {"MaxDistance", "ragebot_other_quickpeekassist_maxdistance", RageKind::Integer, 30.f, 201.f, 201.f, 2, 2,
     "", ""},
    {"RetreatMode", "ragebot_other_quickpeekassist_retreatmode", RageKind::Multi, 0.f, 7.f, 5.f, 2, 2,
     "ragebot_other_quickpeekassist_retreatmode_onshot|ragebot_other_quickpeekassist_retreatmode_"
     "onkeyrelease|ragebot_other_quickpeekassist_retreatmode_ongrenadethrow",
     ""},
    {"JumpOnRetreat", "ragebot_other_quickpeekassist_jumponretreat", RageKind::Choice, 0.f, 2.f, 0.f, 2, 2,
     "ragebot_other_quickpeekassist_jumponretreat_off|ragebot_other_quickpeekassist_jumponretreat_always|"
     "ragebot_other_quickpeekassist_jumponretreat_onlywhilestanding",
     ""},
    {"AllowMovement", "ragebot_other_quickpeekassist_allowmovement", RageKind::Check, 0.f, 1.f, 1.f, 2, 2, "",
     "ragebot_other_quickpeekassist_allowmovement_tooltip"},
    {"DoublePrecision", "ragebot_other_doubleprecision", RageKind::Check, 0.f, 1.f, 0.f, 2, 0, "",
     "ragebot_other_doubleprecision_tooltip"},
    {"DoubleTap", "ragebot_other_doubletap", RageKind::Check, 0.f, 1.f, 0.f, 2, 0, "",
     "ragebot_other_doubletap_tooltip"},
    {"AntiAimEnabled", "enabled", RageKind::Check, 0.f, 1.f, 0.f, 3, 0, "", "ragebot_antiaim_tooltip"},
    {"DisableOnUse", "ragebot_antiaim_disableonuse", RageKind::Check, 0.f, 1.f, 0.f, 3, 10, "",
     "ragebot_antiaim_disableonuse_tooltip"},
    {"FastWeaponSwitch", "ragebot_antiaim_fastweaponswitch", RageKind::Check, 0.f, 1.f, 0.f, 3, 10, "",
     "ragebot_antiaim_fastweaponswitch_tooltip"},
    {"SuppressBreathing", "ragebot_antiaim_suppressbreathinganimations", RageKind::Check, 0.f, 1.f, 0.f, 3,
     10, "", "ragebot_antiaim_suppressbreathinganimations_tooltip"},
    {"LegMovement", "ragebot_antiaim_legmovement", RageKind::Choice, 0.f, 2.f, 0.f, 3, 0,
     "ragebot_antiaim_legmovement_off|ragebot_antiaim_legmovement_sliding|ragebot_antiaim_legmovement_"
     "walking",
     "ragebot_antiaim_legmovement_tooltip"},
    {"Pitch", "ragebot_antiaim_pitch", RageKind::Opener, 0.f, 1.f, 0.f, 3, 0, "",
     "ragebot_antiaim_pitch_tooltip"},
    {"PitchMode", "ragebot_antiaim_pitch", RageKind::Choice, 0.f, 5.f, 0.f, 3, 3,
     "ragebot_antiaim_pitch_value_off|ragebot_antiaim_pitch_value_down|ragebot_antiaim_pitch_value_up|"
     "ragebot_antiaim_pitch_value_zero|ragebot_antiaim_pitch_value_jitter|ragebot_antiaim_pitch_value_custom",
     "ragebot_antiaim_pitch_tooltip"},
    {"PitchOffset", "ragebot_antiaim_pitch_offset", RageKind::Integer, -89.f, 89.f, 0.f, 3, 3, "", ""},
    {"Yaw", "ragebot_antiaim_yaw", RageKind::Opener, 0.f, 1.f, 0.f, 3, 0, "", "ragebot_antiaim_yaw_tooltip"},
    {"YawMode", "ragebot_antiaim_yaw", RageKind::Choice, 0.f, 2.f, 0.f, 3, 4,
     "ragebot_antiaim_yaw_value_off|ragebot_antiaim_yaw_value_attargets|ragebot_antiaim_yaw_value_localview",
     "ragebot_antiaim_yaw_tooltip"},
    {"AvoidBackstab", "ragebot_antiaim_yaw_avoidbackstab", RageKind::Check, 0.f, 1.f, 0.f, 3, 4, "",
     "ragebot_antiaim_yaw_avoidbackstab_tooltip"},
    {"AutoAdjust", "ragebot_antiaim_yaw_autoadjust", RageKind::Check, 0.f, 1.f, 0.f, 3, 4, "",
     "ragebot_antiaim_yaw_autoadjust_tooltip"},
    {"YawOffset", "ragebot_antiaim_yaw_offset", RageKind::Integer, -180.f, 180.f, 0.f, 3, 4, "", ""},
    {"Jitter", "ragebot_antiaim_yaw_jitter", RageKind::Check, 0.f, 1.f, 0.f, 3, 4, "",
     "ragebot_antiaim_yaw_jitter_tooltip"},
    {"JitterBase", "ragebot_antiaim_yaw_jitter_base", RageKind::Choice, 0.f, 3.f, 0.f, 3, 4,
     "ragebot_antiaim_yaw_jitter_base_offset|ragebot_antiaim_yaw_jitter_base_center|ragebot_antiaim_yaw_"
     "jitter_base_random|ragebot_antiaim_yaw_jitter_base_3way",
     ""},
    {"JitterDisablers", "ragebot_antiaim_yaw_jitter_disablers", RageKind::Multi, 0.f, 3.f, 0.f, 3, 4,
     "ragebot_antiaim_yaw_jitter_disablers_inair|ragebot_antiaim_yaw_jitter_disablers_mouseoverride", ""},
    {"JitterOffset", "ragebot_antiaim_yaw_offset", RageKind::Integer, -180.f, 180.f, 0.f, 3, 4, "", ""},
    {"Spin", "ragebot_antiaim_yaw_spin", RageKind::Check, 0.f, 1.f, 0.f, 3, 4, "",
     "ragebot_antiaim_yaw_spin_tooltip"},
    {"SpinOffset", "ragebot_antiaim_yaw_offset", RageKind::Integer, -180.f, 180.f, 0.f, 3, 4, "", ""},
    {"MouseOverride", "ragebot_antiaim_mouseoverride", RageKind::Opener, 0.f, 1.f, 0.f, 3, 0, "", ""},
    {"OverrideHotkey", "ragebot_antiaim_mouseoverride_hotkey", RageKind::Hotkey, 0.f, 255.f, 0.f, 3, 5, "",
     "ragebot_antiaim_mouseoverride_hotkey_tooltip"},
    {"OverrideBase", "ragebot_antiaim_mouseoverride_base", RageKind::Choice, 0.f, 2.f, 0.f, 3, 5,
     "ragebot_antiaim_mouseoverride_base_attargets|ragebot_antiaim_mouseoverride_base_localview|ragebot_"
     "antiaim_mouseoverride_base_static",
     "ragebot_antiaim_mouseoverride_base_tooltip"},
    {"Sensitivity", "ragebot_antiaim_mouseoverride_sensitivity", RageKind::Integer, 5.f, 300.f, 100.f, 3, 5,
     "", ""},
    {"Deadzone", "ragebot_antiaim_mouseoverride_deadzone", RageKind::Integer, 0.f, 99.f, 55.f, 3, 5, "", ""},
    {"OverrideColor", "@Color", RageKind::Color, 0.f, 1.f, 0.f, 3, 5, "", ""},
    {"OverrideStyle", "ragebot_antiaim_mouseoverride_style", RageKind::Choice, 0.f, 1.f, 0.f, 3, 5,
     "ragebot_antiaim_mouseoverride_style_default|ragebot_antiaim_mouseoverride_style_fadeout", ""},
}};
inline constexpr std::array<const char*, 11> RageWeaponKeys{{"autosnipers", "ssg08", "awp", "deagle",
                                                             "revolver", "pistols", "rifles", "smgs",
                                                             "shotguns", "machineguns", "taser"}};
inline std::array<float, RageFieldCount> RageDefaults() {
    std::array<float, RageFieldCount> v{};
    for (std::size_t i = 0; i < v.size(); ++i)
        v[i] = RageSpecs[i].initial;
    return v;
}
#include "rage_weapon_catalog.h"
struct RageWeaponPreset {
    std::string id, name;
    unsigned weaponMask = 0;
    bool builtin = false;
    std::array<float, RageFieldCount> value = RageDefaults();
    bool active = true;
    bool individual = false;
    std::vector<std::string> equipment{};
};
struct RageValues {
    std::array<float, RageFieldCount> value = RageDefaults();
    std::array<Color, 3> colors{
        {{1, 1, 1, 1}, {1, 50.f / 255, 80.f / 255, 200.f / 255}, {90.f / 255, 120.f / 255, 1, 200.f / 255}}};
    std::vector<RageWeaponPreset> weapons;
    int selected = -1;
    unsigned nextCustom = 1;
    RageValues() {
        for (std::size_t i = 0; i < RageWeaponKeys.size(); ++i)
            weapons.push_back({RageWeaponKeys[i], "", 1u << i, true, RageDefaults()});
    }
    float Get(int i) const {
        if (i < 0 || i >= RageFieldCount)
            return 0;
        return RageSpecs[std::size_t(i)].group == 1 && selected >= 0 && std::size_t(selected) < weapons.size()
                   ? weapons[std::size_t(selected)].value[std::size_t(i)]
                   : value[std::size_t(i)];
    }
    void Set(int i, float n) {
        if (i < 0 || i >= RageFieldCount || !std::isfinite(n))
            return;
        const auto& d = RageSpecs[std::size_t(i)];
        n = std::clamp(n, d.minimum, d.maximum);
        if (d.kind != RageKind::Decimal)
            n = std::round(n);
        if (d.group == 1 && selected >= 0 && std::size_t(selected) < weapons.size())
            weapons[std::size_t(selected)].value[std::size_t(i)] = n;
        else
            value[std::size_t(i)] = n;
    }
    bool Create(const std::string& name) {
        if (weapons.size() >= 43)
            return false;
        std::string id;
        do {
            id = "custom" + std::to_string(nextCustom++);
        } while (std::any_of(weapons.begin(), weapons.end(),
                             [&](const RageWeaponPreset& p) { return p.id == id; }));
        auto values = value;
        weapons.push_back({id, name, 0, false, values});
        selected = int(weapons.size()) - 1;
        return true;
    }
    bool DeleteSelected() {
        if (selected < 0 || std::size_t(selected) >= weapons.size())
            return false;
        if (weapons[std::size_t(selected)].builtin) {
            weapons[std::size_t(selected)].active = false;
            selected = -1;
            return true;
        }
        weapons.erase(weapons.begin() + selected);
        selected = -1;
        return true;
    }
};
