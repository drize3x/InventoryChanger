#pragma once
#include "group_row_geometry.h"
#include "presets_ui.h"
#include "world_hud_ui.h"
#include "world_esp_ui.h"
#include "world_misc_ui.h"
#include "keybind_ui.h"
#include "players_ui.h"
#include "rage_ui.h"
#include "inventory_ui.h"
#include "movement_ui.h"
#include "hitsound_ui.h"
#include <iomanip>
#include <sstream>
#include <numeric>
namespace menu {

struct WorldViewHit {
    Box box{};
    int kind = 0, index = -1, option = -1, layer = 0;
    Box control{};
    int key = -1;
};
struct WorldViewUI {
    PresetsUI paint;
    LanguageCatalog* languages = nullptr;
    RageUI rage;
    InventoryUI inventory;
    MovementUI movement;
    HitSoundUI hitSound;
    WorldESPUI esp;
    WorldHudUI hud;
    WorldMiscUI misc;
    PlayersUI players;
    KeybindUI binds;
    bool hudEnabled = true;
    bool PopupOpen() const {
        return rage.Active() || inventory.Active() || movement.Active() || hitSound.Active() ||
               binds.Active() || players.Active() || panel >= 0 ||
               (hudEnabled && (esp.Active() || hud.Active() || misc.Active()));
    }
    bool Capturing() const {
        return rage.Capturing() || inventory.Capturing() || movement.Capturing() || hitSound.Capturing() ||
               players.Capturing() || binds.hotkeyWindow.dragging || binds.spectatorsWindow.dragging ||
               binds.releaseGuard || binds.CapturingKey() || held >= 0 ||
               (hudEnabled && (esp.Capturing() || hud.Capturing() || misc.Capturing()));
    }
    bool Context(float x, float y, Settings& cfg) {
        if (binds.Active())
            return true;
        if (inventory.visible && !inventory.blocked)
            return inventory.Context(x, y, cfg);
        if (rage.visible) {
            int n = rage.HitAt(x, y);
            if (n >= 0) {
                auto h = rage.hits[std::size_t(n)];
                if (RageUI::FieldHit(h.action) && h.field >= 0 && h.field < RageFieldCount &&
                    h.action != RageUI::Open && rage.EnabledField(h.field, cfg)) {
                    const auto& d = RageSpecs[std::size_t(h.field)];
                    std::string id = d.kind == RageKind::Color
                                         ? "ragecolor." + std::to_string(h.field == PeekColor ? 0 : 1)
                                         : "rage." + std::string(d.id);
                    if (FindKeybindTarget(id)) {
                        CancelInput();
                        binds.Open(id, x, y);
                        return true;
                    }
                }
            }
            return rage.Context(x, y, cfg);
        }
        if (movement.visible)
            return movement.Active() || hitSound.Active();
        if (players.visible && !players.blocked) {
            if (players.Context(x, y))
                return true;
            int n = players.HitAt(x, y);
            if (n >= 0) {
                auto h = players.hits[std::size_t(n)];
                if (h.index >= 0 && h.index < int(PlayersSpecs.size()) &&
                    (h.kind == PlayersUI::Toggle || h.kind == PlayersUI::Select ||
                     h.kind == PlayersUI::Slider || h.kind == PlayersUI::Swatch)) {
                    CancelInput();
                    auto id = h.kind == PlayersUI::Swatch
                                  ? "playerscolor." + std::to_string(PlayersSpecs[std::size_t(h.index)].color)
                                  : "players." + std::string(PlayersSpecs[std::size_t(h.index)].id);
                    players.Close();
                    binds.Open(id, x, y);
                    return true;
                }
            }
            return players.Active();
        }
        if (!visible || blocked)
            return false;
        auto open = [&](const std::string& id) {
            CancelInput();
            binds.Open(id, x, y);
            return true;
        };
        if (hudEnabled) {
            if (esp.Context(x, y, cfg))
                return true;
            int en = esp.HitAt(x, y);
            if (en >= 0) {
                const auto& h = esp.hits[std::size_t(en)];
                if (h.kind == WorldESPUI::Swatch && h.index >= 0)
                    return open("espcolor." + std::to_string(WorldESPSpecs[std::size_t(h.index)].color));
                if ((h.kind == WorldESPUI::Toggle || h.kind == WorldESPUI::Slider ||
                     h.kind == WorldESPUI::Select) &&
                    h.index >= 0)
                    return open("esp." + std::string(WorldESPSpecs[std::size_t(h.index)].id));
            }
            if (esp.Active())
                return true;
            int n = misc.HitAt(x, y);
            if (n >= 0) {
                const auto& h = misc.hits[std::size_t(n)];
                if (h.kind == WorldMiscUI::Swatch && h.index >= 0 && h.index < 21)
                    return open("misccolor." + std::to_string(h.index));
                if (h.index >= 0 && h.index < int(WorldMiscSpecs.size()) &&
                    (h.kind == WorldMiscUI::Toggle || h.kind == WorldMiscUI::Slider ||
                     h.kind == WorldMiscUI::Select || h.kind == WorldMiscUI::RowHover))
                    return open("misc." + std::string(WorldMiscSpecs[std::size_t(h.index)].id));
            }
            n = hud.Hit(x, y);
            if (n >= 0) {
                const auto& h = hud.hits[std::size_t(n)];
                if (h.kind == WorldHudUI::Swatch && h.index >= 0 && h.index < 8)
                    return open("hudcolor." + std::to_string(h.index));
                if (h.index >= 0 && h.index < int(WorldHudSpecs.size()) &&
                    (h.kind == WorldHudUI::Toggle || h.kind == WorldHudUI::Slider ||
                     h.kind == WorldHudUI::Select))
                    return open("hud." + std::string(WorldHudSpecs[std::size_t(h.index)].id));
            }
        }
        int n = HoverHit(x, y);
        if (n >= 0) {
            const auto& h = hits[std::size_t(n)];

            if (h.kind == 1 && (h.index == 4 || h.index == 5))
                return open("view." + std::string(WorldViewSpecs[std::size_t(h.index == 4 ? 33 : 34)].id));
            if (h.index >= 0 && h.index < int(WorldViewSpecs.size()) &&
                (h.kind == 2 || h.kind == 3 || h.kind == 4 || h.kind == 8))
                return open("view." + std::string(WorldViewSpecs[std::size_t(h.index)].id));
        }
        if (!hudEnabled || panel >= 0)
            return false;
        if (misc.Active())
            return misc.Context(x, y, cfg);
        return hud.Context(x, y, cfg);
    }
    std::vector<WorldViewHit> hits;
    std::array<PresetMotion, WorldViewSpecs.size()> availability, check, sliderTip;
    std::array<Box, WorldViewSpecs.size()> rows{}, sliders{}, toggles{};
    std::array<Box, 6> groupRows{}, groupControls{}, groupHoverBounds{};
    std::map<int, PresetMotion> hoverMotion, inkMotion, markerMotion;
    PresetMotion popupFade, groupFade, tooltipFade;
    PopupPaintTransition choiceTransition;
    PresetLayer tooltipLast{};
    bool tooltipStored = false;
    int panel = -1, fadedPanel = -1, choice = -1, held = -1, heldKey = -1, hover = -1, focus = -1,
        editing = -1, dragging = -1, activeSlider = -1;
    bool visible = false, blocked = false, selectAll = false, directPosition = false;
    float scroll = 0, maxScroll = 0, mouseX = -1, mouseY = -1, hoverTime = 0;
    std::string numeric;
    Box directAnchor{}, card{}, popup{}, body{}, track{}, thumb{}, anchor{};
    bool searchDetached = false;
    Box searchAnchor{};
    std::size_t searchLayerStart = 0, searchLayerEnd = 0;
    float scale = 1, F = 18, displayAspect = 16.f / 9;

    static Box OptionsHoverBounds(Box row, float s) {
        return GroupRowHoverBounds(row, s);
    }
    static constexpr std::array<const char*, 6> PanelKeys{{"viewoptions", "scopeoptions", "viewmodeloptions",
                                                           "perspectiveoptions", "unlockspectating",
                                                           "visualrecoil"}};
    WorldViewUI() {
        popupFade.Snap(0);
        groupFade.Snap(0);
    }
    std::u32string Label(const std::string& key) const {
        if (languages)
            return languages->Label(key);
        auto& m = DefaultLanguageStrings();
        auto it = m.find(key);
        return DecodeUTF8(it == m.end() ? key : it->second);
    }
    static std::u32string Upper(std::u32string t) {
        for (auto& c : t) {
            if (c >= U'a' && c <= U'z')
                c -= 32;
            else if (c >= 0x430 && c <= 0x44f)
                c -= 32;
            else if (c == 0x451)
                c = 0x401;
        }
        return t;
    }
    static std::vector<std::string> Options(int i) {
        const std::string id = WorldViewSpecs[std::size_t(i)].id;
        if (id == "aspect_scaling")
            return {"visuals_world_view_viewoptions_overrideeaspectratio_scaling_horizontal",
                    "visuals_world_view_viewoptions_overrideeaspectratio_scaling_vertical"};
        if (id == "disablers")
            return {"visuals_world_view_perspectiveoptions_forcethirdperson_disablers_closetowall",
                    "visuals_world_view_perspectiveoptions_forcethirdperson_disablers_holdinggrenade"};
        if (id == "overhead")
            return {"visuals_world_view_perspectiveoptions_disableoverhead_self",
                    "visuals_world_view_perspectiveoptions_disableoverhead_teammates"};
        if (id == "spectating")
            return {"visuals_world_view_unlockspectating_perspective",
                    "visuals_world_view_unlockspectating_enemies"};
        if (id == "recoil")
            return {"visuals_world_view_visualrecoil_noshake", "visuals_world_view_visualrecoil_norecoil",
                    "visuals_world_view_visualrecoil_noviewmodelrecoil",
                    "visuals_world_view_visualrecoil_noburstsway"};
        return {};
    }
    bool Enabled(int i, const Settings& cfg) const {
        int p = WorldViewSpecs[std::size_t(i)].parent;
        return p < 0 || (cfg.worldView.value[std::size_t(p)] != 0 && Enabled(p, cfg));
    }

    std::u32string MultiSummary(int i, const Settings& cfg, bool abbreviate = false) const {
        auto options = Options(i);
        std::u32string value;
        int mask = int(cfg.worldView.value[std::size_t(i)]);
        for (std::size_t j = 0; j < options.size(); ++j)
            if (mask & (1 << j)) {
                if (!value.empty())
                    value += U", ";
                value += Label(options[j]);
            }
        if (abbreviate && value.size() >= 15) {
            value.clear();
            for (std::size_t j = 0; j < options.size(); ++j)
                if (mask & (1 << j)) {
                    auto label = Label(options[j]);
                    if (!label.empty()) {
                        if (!value.empty())
                            value += U", ";
                        value += label.front();
                    }
                }
        }
        return value.empty() ? Label("menu_select") : value;
    }
    float MarkerAmount(int i, const Settings& cfg) const {
        auto it = markerMotion.find(i);
        return it == markerMotion.end() ? (cfg.worldView.value[std::size_t(i)] != 0 ? 1.f : 0.f)
                                        : it->second.value;
    }
    std::string DescriptionTooltipKey() const {
        if (choice >= 0 || editing >= 0 || activeSlider >= 0)
            return {};
        int n = HoverHit(mouseX, mouseY);
        if (n < 0)
            return {};
        const auto& h = hits[std::size_t(n)];
        if (h.kind == 1 && (h.index == 4 || h.index == 5))
            return std::string("visuals_world_view_") + PanelKeys[std::size_t(h.index)] + "_tooltip";
        if (h.kind == 3 && h.index >= 0 && std::string(WorldViewSpecs[std::size_t(h.index)].id) == "force_vm")
            return std::string(WorldViewSpecs[std::size_t(h.index)].key) + "_tooltip";
        return {};
    }
    std::string Number(int i, const Settings& cfg) const {
        std::ostringstream s;
        if (WorldViewSpecs[std::size_t(i)].kind == WorldKind::Decimal)
            s << std::fixed << std::setprecision(1);
        s << cfg.worldView.value[std::size_t(i)];
        return s.str();
    }

    static std::string AspectFormat(int value, float displayRatio) {
        float ratio = displayRatio * float(value) / 100.f;
        for (int den = 1; den <= 120; ++den) {
            int num = int(std::floor(ratio * float(den) + .5f));
            int g = std::gcd(num, den);
            int n = num / g, d = den / g;
            double error = std::floor((double(num) / den - double(ratio)) * 100. + .5);
            if (error >= 0 && error <= 1 && (value == 100 || (n <= 9 && d <= 9)))
                return std::to_string(value) + "% (" + std::to_string(n) + ":" + std::to_string(d) + ")";
        }
        return std::to_string(value) + "%";
    }
    std::u32string ValueLabel(int i, const Settings& cfg) const {
        if (i == 4)
            return DecodeUTF8(AspectFormat(int(cfg.worldView.value[4]), displayAspect));
        auto t = DecodeUTF8(Number(i, cfg));
        if (i == 7 || i == 8 || (i >= 23 && i <= 28))
            t += U"%";
        return t;
    }

    void CancelPageInput() {
        held = heldKey = dragging = activeSlider = -1;
        misc.CancelInput();
        if (hudEnabled) {
            esp.CancelInput();
            hud.CancelInput();
        }
    }
    void CancelInput() {
        rage.CancelInput();
        inventory.CancelInput();
        movement.CancelInput();
        hitSound.CancelInput();
        players.CancelInput();
        binds.CancelInput();
        CancelPageInput();
    }
    void Close(bool animate = true) {
        if (panel >= 0 && animate)
            fadedPanel = panel;
        else if (!animate) {
            fadedPanel = -1;
            popupFade.Snap(0);
            choiceTransition.Clear();
        }
        panel = choice = editing = focus = -1;
        numeric.clear();
        CancelPageInput();
    }
    bool Editing() const {
        return (rage.visible && !rage.blocked && rage.Editing()) || inventory.Editing() ||
               players.Editing() || binds.Active() ||
               ((editing >= 0 || (hudEnabled && (esp.Editing() || hud.Editing() || misc.Editing()))) &&
                visible && !blocked);
    }
    void Open(int p) {
        choiceTransition.Clear();
        esp.Close(true);
        misc.Close();
        hud.Close();
        directPosition = false;
        panel = p;
        fadedPanel = -1;
        choice = editing = focus = -1;
        scroll = 0;
        CancelInput();
        anchor = mouseX >= 0 && mouseY >= 0 ? Box{mouseX + 1, mouseY + 1, 0, 0}
                                            : Box{card.x + card.w + 8 * scale, card.y, 0, 0};
        popupFade.Snap(0);
    }

    int HoverHit(float x, float y) const {
        if (!visible || blocked ||
            (hudEnabled && (esp.Active() || esp.Capturing() || hud.Active() || misc.Active())))
            return -1;
        for (int i = int(hits.size()) - 1; i >= 0; --i) {
            const auto& h = hits[std::size_t(i)];
            if (h.box.Contains(x, y))
                return h.kind == 0 ? -1 : i;
        }
        return -1;
    }
    int HoverKey() const {
        int h = HoverHit(mouseX, mouseY);
        return h >= 0 ? hits[std::size_t(h)].key : -1;
    }
    void Tick(float dt, const Settings& cfg) {
        rage.Tick(dt, cfg);
        inventory.Tick(dt, cfg);
        movement.Tick(dt, cfg);
        hitSound.Tick(dt, cfg);
        players.Tick(dt, cfg);
        binds.Tick(dt);
        if (hudEnabled) {
            esp.Tick(dt, cfg);
            misc.Tick(dt, cfg);
        }
        if (hudEnabled)
            hud.Tick(dt, cfg);
        dt = std::max(0.f, dt);
        groupFade.Tick(visible ? 1.f : 0.f, dt);
        if (visible && !blocked) {
            choiceTransition.Tick(choice >= 0 ? 1.f : 0.f, dt);
            popupFade.Tick(panel >= 0 ? 1.f : 0.f, dt);
            if (panel < 0 && popupFade.value < .001f)
                fadedPanel = -1;
            for (std::size_t i = 0; i < WorldViewSpecs.size(); ++i) {
                availability[i].Tick(Enabled(int(i), cfg) ? 1.f : .5f, dt);
                check[i].Tick(cfg.worldView.value[i] != 0 ? 1.f : 0.f, dt);
                sliderTip[i].Tick((panel >= 0 && choice < 0 && editing < 0 && Enabled(int(i), cfg) &&
                                   (activeSlider == int(i) || sliders[i].Contains(mouseX, mouseY)))
                                      ? 1.f
                                      : 0.f,
                                  dt);
            }
            std::map<int, float> fillTargets, inkTargets;
            int overKey = HoverKey();
            for (const auto& h : hits)
                if (h.key >= 0) {
                    bool usable = h.index < 0 || h.kind == 1 || Enabled(h.index, cfg);
                    bool pressed = usable && (h.key == heldKey ||
                                              (h.index == activeSlider && (h.kind == 2 || h.kind == 8)));
                    bool popupOpen = h.kind == 1 && h.index == panel;
                    float state = pressed || popupOpen ? 1.f : usable && h.key == overKey ? .5f : 0.f;
                    bool selected = false;
                    if (h.index >= 0 && h.kind != 1) {
                        const auto& d = WorldViewSpecs[std::size_t(h.index)];
                        if (h.kind == 3)
                            selected = cfg.worldView.value[std::size_t(h.index)] != 0;
                        else if (h.kind == 5)
                            selected =
                                d.kind == WorldKind::Choice
                                    ? int(cfg.worldView.value[std::size_t(h.index)]) == h.option
                                    : (int(cfg.worldView.value[std::size_t(h.index)]) & (1 << h.option)) != 0;
                    }
                    fillTargets[h.key] = state;
                    inkTargets[h.key] = h.kind == 1 ? (popupOpen ? 1.f : 0.f) : selected ? 1.f : state;

                    hoverMotion.try_emplace(h.key);
                    inkMotion.try_emplace(h.key);
                }
            for (auto& entry : hoverMotion) {
                auto it = fillTargets.find(entry.first);
                entry.second.Tick(it == fillTargets.end() ? 0.f : it->second, dt);
            }
            for (auto& entry : inkMotion) {
                auto it = inkTargets.find(entry.first);
                entry.second.Tick(it == inkTargets.end() ? 0.f : it->second, dt);
            }
            for (std::size_t i = 0; i < WorldViewSpecs.size(); ++i)
                if (WorldViewSpecs[i].kind == WorldKind::Multi)
                    markerMotion[int(i)].Tick(cfg.worldView.value[i] != 0 ? 1.f : 0.f, dt);
            hoverTime += dt;
            tooltipFade.Tick(!DescriptionTooltipKey().empty() && hoverTime >= .3f ? 1.f : 0.f, dt);
        }
    }
    int Hit(float x, float y) const {
        if (!visible || blocked ||
            (hudEnabled && (esp.Active() || esp.Capturing() || hud.Active() || misc.Active())))
            return -1;
        for (int i = int(hits.size()) - 1; i >= 0; --i)
            if (hits[std::size_t(i)].kind != 8 && hits[std::size_t(i)].box.Contains(x, y))
                return i;
        return -1;
    }
    void Drag(const WorldViewHit& h, float x, Settings& cfg) {
        if (h.kind != 2 || !Enabled(h.index, cfg))
            return;
        const auto& d = WorldViewSpecs[std::size_t(h.index)];
        Box b = h.control.w > 0 ? h.control : h.box;
        float t = std::clamp((x - b.x) / std::max(1.f, b.w - 1), 0.f, 1.f);
        cfg.worldView.Set(std::size_t(h.index), d.minimum + t * (d.maximum - d.minimum));
    }
    void Move(float x, float y, Settings& cfg) {
        if (rage.visible && !binds.Active()) {
            rage.Move(x, y, cfg);
            return;
        }
        if (inventory.visible && !binds.Active()) {
            inventory.Move(x, y, cfg);
            return;
        }
        binds.hotkeyWindow.Move(x, y);
        binds.spectatorsWindow.Move(x, y);
        if (binds.hotkeyWindow.dragging || binds.spectatorsWindow.dragging)
            return;
        if (binds.Active()) {
            binds.Move(x, y, cfg);
            return;
        }
        if (movement.visible) {
            if (!movement.Active())
                hitSound.Move(x, y, cfg);
            if (!hitSound.Active())
                movement.Move(x, y, cfg);
            return;
        }
        if (players.visible) {
            players.Move(x, y, cfg);
            return;
        }
        if (hudEnabled) {
            esp.Move(x, y, cfg);
            misc.Move(x, y, cfg);
        }
        if (hudEnabled)
            hud.Move(x, y, cfg);
        mouseX = x;
        mouseY = y;
        int h = HoverHit(x, y);
        if (h != hover) {
            hover = h;
            hoverTime = 0;
        }
        if (x == -1 && y == -1)
            return;
        if (activeSlider >= 0) {
            Box b = sliders[std::size_t(activeSlider)];
            Drag({b, 2, activeSlider}, x, cfg);
        } else if (dragging >= 0)
            scroll = std::clamp((y - track.y - thumb.h * .5f) / std::max(1.f, track.h - thumb.h) * maxScroll,
                                0.f, maxScroll);
    }
    void BeginEdit(int i, const Settings& cfg) {
        if (!Enabled(i, cfg))
            return;
        editing = i;
        numeric = Number(i, cfg);
        selectAll = true;
        dragging = activeSlider = -1;
    }
    bool Commit(Settings& cfg) {
        if (editing < 0)
            return true;
        if (!Enabled(editing, cfg)) {
            editing = -1;
            numeric.clear();
            return true;
        }
        try {
            std::size_t n = 0;
            float v = std::stof(numeric, &n);
            if (n != numeric.size() || !std::isfinite(v))
                return false;
            cfg.worldView.Set(std::size_t(editing), v);
            editing = -1;
            numeric.clear();
            return true;
        } catch (...) {
            return false;
        }
    }
    void Activate(const WorldViewHit& h, Settings& cfg) {
        if (h.kind == 1) {
            if (!Commit(cfg))
                return;
            if (panel == h.index)
                Close();
            else
                Open(h.index);
            return;
        }
        if (h.kind == 3) {
            if (!Enabled(h.index, cfg))
                return;
            cfg.worldView.Set(std::size_t(h.index),
                              cfg.worldView.value[std::size_t(h.index)] == 0 ? 1.f : 0.f);
            if (editing >= 0 && !Enabled(editing, cfg)) {
                editing = -1;
                numeric.clear();
            }
            if (choice >= 0 && !Enabled(choice, cfg))
                choice = -1;
            if (activeSlider >= 0 && !Enabled(activeSlider, cfg))
                CancelInput();
            return;
        }
        if (h.kind == 4) {
            if (Enabled(h.index, cfg))
                choice = choice == h.index ? -1 : h.index;
            return;
        }
        if (h.kind == 5) {
            const auto& d = WorldViewSpecs[std::size_t(h.index)];
            if (!Enabled(h.index, cfg))
                return;
            if (d.kind == WorldKind::Choice) {
                cfg.worldView.Set(std::size_t(h.index), float(h.option));
                choice = -1;
            } else
                cfg.worldView.Set(std::size_t(h.index),
                                  float(int(cfg.worldView.value[std::size_t(h.index)]) ^ (1 << h.option)));
        }
    }
    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl = false) {
        if (rage.visible && !binds.Active())
            return rage.Click(x, y, down, cfg, ctrl);
        if (inventory.visible && !binds.Active())
            return inventory.Click(x, y, down, cfg, ctrl);
        if (!blocked && !binds.Active() && !movement.Active() && !hitSound.Active() && !esp.Active() &&
            !misc.Active() && !hud.Active() &&
            (binds.hotkeyWindow.Pointer(x, y, down) || binds.spectatorsWindow.Pointer(x, y, down)))
            return true;
        if (binds.Active() || binds.releaseGuard)
            return binds.Click(x, y, down, cfg, ctrl);
        if (movement.visible) {
            if (!movement.Active() && (hitSound.Active() || hitSound.Capturing() || hitSound.Hit(x, y) >= 0))
                return hitSound.Click(x, y, down, cfg);
            return movement.Click(x, y, down, cfg);
        }
        if (players.visible)
            return players.Click(x, y, down, cfg, ctrl);
        if (hudEnabled && visible && !blocked &&
            (esp.Active() || esp.Capturing() ||
             (panel < 0 && !misc.Active() && !hud.Active() && esp.HitAt(x, y) >= 0)))
            return esp.Click(x, y, down, cfg, ctrl);
        if (hudEnabled && visible && !blocked &&
            (misc.Active() || misc.Capturing() || (panel < 0 && !hud.Active() && misc.HitAt(x, y) >= 0)))
            return misc.Click(x, y, down, cfg, ctrl);
        if (hudEnabled && !blocked && visible &&
            (hud.Active() || hud.Capturing() || (panel < 0 && hud.Hit(x, y) >= 0)))
            return hud.Click(x, y, down, cfg, ctrl);
        if (!visible || blocked) {
            CancelInput();
            return false;
        }
        mouseX = x;
        mouseY = y;
        int h = Hit(x, y);
        hover = HoverHit(x, y);
        if (down) {
            if (h >= 0 && hits[std::size_t(h)].kind == 0) {
                if (choice >= 0) {
                    choice = -1;
                    return true;
                }
                if (editing >= 0) {
                    Commit(cfg);
                    return true;
                }
                Close();
                return true;
            }
            if (h < 0) {
                if (panel >= 0) {
                    Close();
                    return true;
                }
                focus = -1;
                return false;
            }
            const auto hit = hits[std::size_t(h)];
            if (editing >= 0 && hit.index != editing && !Commit(cfg))
                return true;
            held = h;
            heldKey = hit.key;
            focus = h;
            if (hit.kind == 7) {
                dragging = h;
                Move(x, y, cfg);
                return true;
            }
            if (hit.kind == 2) {
                if (ctrl)
                    BeginEdit(hit.index, cfg);
                else {
                    if (!Commit(cfg))
                        return true;
                    activeSlider = hit.index;
                    Drag(hit, x, cfg);
                }
            }
            return true;
        }
        bool consumed = held >= 0 || dragging >= 0 || activeSlider >= 0;
        if (h >= 0 && heldKey == hits[std::size_t(h)].key && held >= 0 && dragging < 0 && activeSlider < 0 &&
            editing < 0)
            Activate(hits[std::size_t(h)], cfg);
        CancelInput();
        return consumed;
    }
    bool Key(int key, Settings& cfg, bool shift = false, bool ctrl = false) {
        if (rage.visible && !binds.Active())
            return rage.Key(key, cfg, shift, ctrl);
        if (inventory.visible && !binds.Active())
            return inventory.Key(key, cfg, shift, ctrl);
        if (binds.Active())
            return binds.Key(key, cfg, shift, ctrl);
        if (movement.visible) {
            if (hitSound.Active())
                return hitSound.Key(key, cfg);
            return movement.Key(key, cfg);
        }
        if (players.visible)
            return players.Key(key, cfg, shift, ctrl);
        if (hudEnabled && (esp.Active() || (panel < 0 && !misc.Active() && !hud.Active() && esp.focus >= 0)))
            return esp.Key(key, cfg, shift, ctrl);
        if (hudEnabled && (misc.Active() || (panel < 0 && !hud.Active() && misc.focus >= 0)))
            return misc.Key(key, cfg, shift, ctrl);
        if (hudEnabled && (hud.Active() || hud.Editing() || (panel < 0 && hud.focus >= 0)))
            return hud.Key(key, cfg, shift, ctrl);
        if (!visible || blocked)
            return false;
        if (editing >= 0) {
            if (key == 27) {
                editing = -1;
                numeric.clear();
                return true;
            }
            if (key == 13)
                return Commit(cfg), true;
            if (ctrl && key == 'A') {
                selectAll = true;
                return true;
            }
            if (key == 8 || key == 46) {
                if (selectAll)
                    numeric.clear();
                else if (!numeric.empty())
                    numeric.pop_back();
                selectAll = false;
                return true;
            }
            return true;
        }
        if (key == 27 && panel >= 0) {
            if (choice >= 0)
                choice = -1;
            else
                Close();
            return true;
        }
        if (panel >= 0 && (key == 33 || key == 34)) {
            scroll = std::clamp(scroll + (key == 33 ? -1 : 1) * body.h * .8f, 0.f, maxScroll);
            return true;
        }
        if (key == 9) {
            std::vector<int> eligible;
            for (int i = 0; i < int(hits.size()); ++i)
                if (hits[std::size_t(i)].kind > 0 && hits[std::size_t(i)].kind < 6 &&
                    (panel < 0 || hits[std::size_t(i)].layer > 0))
                    eligible.push_back(i);
            if (eligible.empty())
                return false;
            auto it = std::find(eligible.begin(), eligible.end(), focus);
            int n = it == eligible.end()
                        ? (shift ? int(eligible.size()) - 1 : 0)
                        : (int(it - eligible.begin()) + (shift ? -1 : 1) + int(eligible.size())) %
                              int(eligible.size());
            focus = eligible[std::size_t(n)];
            return true;
        }
        if (focus < 0 || focus >= int(hits.size()))
            return panel >= 0;
        const auto h = hits[std::size_t(focus)];
        if (h.index >= 0 && h.kind != 1 && !Enabled(h.index, cfg))
            return true;
        if (h.kind == 2 && (key == 37 || key == 39)) {
            float step = WorldViewSpecs[std::size_t(h.index)].kind == WorldKind::Decimal ? .1f : 1.f;
            if (shift)
                step *= 10;
            cfg.worldView.Set(std::size_t(h.index),
                              cfg.worldView.value[std::size_t(h.index)] + (key == 37 ? -step : step));
            return true;
        }
        if (key == 13 || key == 32) {
            if (h.kind == 2)
                BeginEdit(h.index, cfg);
            else
                Activate(h, cfg);
            return true;
        }
        return panel >= 0;
    }
    bool Character(char16_t c) {
        if (rage.visible && !binds.Active())
            return rage.Character(c);
        if (inventory.visible && !binds.Active())
            return inventory.Character(c);
        if (binds.Active())
            return binds.Character(c);
        if (players.visible)
            return players.Character(c);
        if (hudEnabled && esp.Editing())
            return esp.Character(c);
        if (hudEnabled && misc.Editing())
            return misc.Character(c);
        if (hudEnabled && hud.Editing())
            return hud.Character(c);
        if (!Editing())
            return false;
        if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.') {
            if (selectAll) {
                numeric.clear();
                selectAll = false;
            }
            if (numeric.size() < 20)
                numeric += char(c);
        }
        return true;
    }
    bool Wheel(float steps, Settings& cfg) {
        if (rage.visible && !binds.Active())
            return rage.Wheel(steps, cfg);
        if (inventory.visible && !binds.Active())
            return inventory.Wheel(steps, cfg);
        if (binds.Active())
            return binds.Wheel(steps, cfg);
        if (movement.visible) {
            if (hitSound.Active())
                return hitSound.Wheel(steps, cfg);
            return movement.Wheel(steps, cfg);
        }
        if (players.visible)
            return players.Wheel(steps, cfg);
        if (hudEnabled && esp.Wheel(steps, cfg))
            return true;
        if (hudEnabled && misc.Wheel(steps, cfg))
            return true;
        if (hudEnabled && (hud.Active() || misc.Active()))
            return hud.Wheel(steps, cfg);
        if (!visible || blocked || panel < 0)
            return false;
        if (choice < 0 && editing < 0)
            for (std::size_t i = 0; i < sliders.size(); ++i)
                if (Enabled(int(i), cfg) && (activeSlider == int(i) || sliders[i].Contains(mouseX, mouseY))) {
                    float step = WorldViewSpecs[i].kind == WorldKind::Decimal ? .1f : 1.f;
                    cfg.worldView.Set(i, cfg.worldView.value[i] + steps * step);
                    return true;
                }
        scroll = std::clamp(scroll - steps * 30 * scale, 0.f, maxScroll);
        return true;
    }
    void ConfigureKeybinds() {
        binds.languages = languages;
        binds.options = [this](const KeybindTarget& t) {
            std::vector<std::u32string> result;
            if (t.color)
                return result;
            if (t.domain == 0) {
                for (const auto& k : Options(t.index))
                    result.push_back(Label(k));
            } else if (t.domain == 1) {
                for (const auto& k : WorldHudUI::Options(t.index))
                    result.push_back(hud.Label(k));
            } else if (t.domain == 2)
                result = misc.Options(t.index);
            else if (t.domain == 3) {
                for (const auto& k : PlayersOptions(t.index))
                    result.push_back(players.Label(k));
            } else if (t.domain == 4)
                result = rage.Options(t.index);
            else if (t.domain == 5) {
                for (const auto& k : WorldESPOptions(t.index))
                    result.push_back(esp.Label(k));
            }
            return result;
        };
    }
    void Measure(Fonts& fonts, const Settings& cfg, const State& state, const Layout& l,
                 const Box& headerLine, int width, int height, bool modalBlocked, Box configSelector = {}) {

        auto pageState = state;
        pageState.selected = state.contentTransition.displayed.main;
        pageState.selectedVisual = state.contentTransition.displayed.child;
        auto pageLayout = l;
        auto pageHeader = headerLine;
        const float dy = state.contentTransition.Offset(cfg.scale),
                    alpha = state.contentTransition.renderAlpha;
        pageLayout.content.y += dy;
        pageHeader.y += dy;
        if (configSelector.w > 0)
            configSelector.y += dy;
        const bool blockPage = modalBlocked || state.contentTransition.Outgoing();

        if (pageState.selected == 2 && pageState.selectedVisual == 1) {
            groupFade.Snap(1);
            hud.groupFade.Snap(1);
            misc.groupFade.Snap(1);
        }
        MeasurePage(fonts, cfg, pageState, pageLayout, pageHeader, width, height, blockPage);
        binds.languages = languages;
        players.languages = languages;
        players.Measure(fonts, cfg, pageLayout, pageHeader, width, height,
                        hudEnabled && pageState.selected == 2 && pageState.selectedVisual == 0,
                        blockPage || binds.Active());
        paint.layers.insert(paint.layers.end(), players.paint.layers.begin(), players.paint.layers.end());
        rage.languages = languages;
        rage.bindings = &binds;
        rage.Measure(fonts, cfg, pageLayout, pageHeader, width, height, pageState.selected == 0, blockPage,
                     configSelector);
        if (binds.Active() && binds.directTarget.empty())
            rage.hits.clear();
        paint.layers.insert(paint.layers.end(), rage.paint.layers.begin(), rage.paint.layers.end());

        inventory.languages = languages;
        inventory.Measure(fonts, cfg, pageLayout, pageHeader, width, height, pageState.selected == 3,
                          blockPage || binds.Active());
        paint.layers.insert(paint.layers.end(), inventory.paint.layers.begin(), inventory.paint.layers.end());
        movement.languages = languages;
        movement.Measure(fonts, cfg, pageLayout, pageHeader, width, height, pageState.selected == 4,
                         blockPage || binds.Active());
        hitSound.languages = languages;
        hitSound.Measure(fonts, cfg, pageLayout, pageHeader, width, height, pageState.selected == 4,
                         blockPage || binds.Active() || movement.Active());

        auto appendMiscLayers = [&](const PresetsUI& ui, bool popupLayer) {
            for (const auto& layer : ui.layers)
                if (layer.popup == popupLayer)
                    paint.layers.push_back(layer);
        };
        appendMiscLayers(movement.paint, false);
        appendMiscLayers(hitSound.paint, false);

        if (movement.Active()) {
            appendMiscLayers(hitSound.paint, true);
            appendMiscLayers(movement.paint, true);
        } else {
            appendMiscLayers(movement.paint, true);
            appendMiscLayers(hitSound.paint, true);
        }

        Box pageClip{l.content.x, headerLine.y + headerLine.h, l.content.w,
                     std::max(0.f, l.content.y + l.content.h - headerLine.y - headerLine.h)};
        for (auto& layer : paint.layers) {
            layer.opacity *= alpha;
            if (!layer.popup && layer.clipToPage && alpha < 1)
                layer.box = PresetIntersect(layer.box, pageClip);
            for (auto& d : layer.draw) {
                d.color.a *= alpha;
                d.shadowColor.a *= alpha;
                d.backdropOpacity *= alpha;
            }
        }
        ConfigureKeybinds();
        binds.Measure(fonts, cfg, width, height,
                      modalBlocked || !(visible || players.visible || rage.visible || inventory.visible));
        binds.MeasureHUD(fonts, cfg, width, height, true);
        paint.layers.insert(paint.layers.end(), binds.hudPaint.layers.begin(), binds.hudPaint.layers.end());
        paint.layers.insert(paint.layers.end(), binds.paint.layers.begin(), binds.paint.layers.end());
    }
    void MeasurePage(Fonts& fonts, const Settings& cfg, const State& state, const Layout& l,
                     const Box& headerLine, int width, int height, bool modalBlocked) {
        visible = state.selected == 2 && state.selectedVisual == 1;
        blocked = modalBlocked;
        paint.layers.clear();
        hits.clear();
        rows.fill({});
        sliders.fill({});
        toggles.fill({});
        scale = cfg.scale;
        displayAspect = float(width) / std::max(1, height);
        F = fonts.PixelHeight(0, 13 * scale);
        if (!visible) {
            esp.Measure(fonts, cfg, {}, width, height, false, true);
            misc.Measure(fonts, cfg, {}, width, height, false, true);
            hud.Measure(fonts, cfg, l, {}, headerLine, width, height, false, true);
            Close(false);
            tooltipFade.Snap(0);
            tooltipStored = false;
            return;
        }

        if (blocked) {
            Close(false);
            tooltipFade.Snap(0);
            tooltipStored = false;
            hover = -1;
            hoverTime = 0;
            for (auto& e : hoverMotion)
                e.second.Snap(0);
            for (auto& e : inkMotion)
                e.second.Snap(0);
        }
        if (editing >= 0 && !Enabled(editing, cfg)) {
            editing = -1;
            numeric.clear();
        }
        if (choice >= 0 && !Enabled(choice, cfg))
            choice = -1;
        if (activeSlider >= 0 && !Enabled(activeSlider, cfg))
            CancelInput();
        const float s = scale, H = F + 6 * s, innerH = F + 14 * s, pitch = H + 15 * s;
        const auto pal = CurrentPalette(cfg);
        auto alpha = [](Color c, float a) {
            c.a *= a;
            return c;
        };
        auto layer = [&](Box b, bool pop = false, float radius = 0) {
            paint.layers.push_back({b, radius, pop, {}});
            return int(paint.layers.size()) - 1;
        };
        Box localClip{};
        auto rect = [&](int z, Box b, Color c, float radius = 0, float stroke = 0, Box clip = Box{}) {
            if (b.w <= 0 || b.h <= 0)
                return;
            PresetDraw d{b, c, radius, stroke, 15, {}, false};
            d.clipped = true;
            d.clip = clip.w > 0 ? PresetIntersect(clip, paint.layers[std::size_t(z)].box)
                                : paint.layers[std::size_t(z)].box;
            if (localClip.w > 0)
                d.clip = PresetIntersect(d.clip, localClip);
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto text = [&](int z, Box b, std::u32string t, Color c, int font = 0, float px = 13) {
            PresetDraw d{b, c, 0, 0, 15, std::move(t), font == 3};
            d.font = font;
            d.textSize = px;
            d.clipped = true;
            d.clip = paint.layers[std::size_t(z)].box;
            if (localClip.w > 0)
                d.clip = PresetIntersect(d.clip, localClip);
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto hit = [&](int z, Box b, int kind, int index = -1, int option = -1, Box control = Box{}) {
            if (blocked)
                return;
            b = PresetIntersect(b, paint.layers[std::size_t(z)].box);
            if (localClip.w > 0)
                b = PresetIntersect(b, localClip);
            if (b.w > 0 && b.h > 0)
                hits.push_back(
                    {b, kind, index, option, z, control, kind * 10000 + (index + 1) * 16 + option + 1});
        };
        auto surface = [&](Box b, float radius, bool pop = true) {
            int z = layer(b, pop, radius);
            rect(z, b, pal[8], radius);
            rect(z, b, pal[11], radius, s);
            return z;
        };
        auto cardShape = [&](int z, Box b) {
            rect(z, b, pal[40], 15 * s);
            rect(z, b, pal[11], 15 * s, s);
        };
        auto widthText = [&](const std::u32string& t, int font = 0, float px = 13) {
            return std::trunc(fonts.NativeTextSize(font, px * s, t).w + .95f);
        };
        auto arrow = [&](int z, float right, float y, Color col, char32_t cp = 0xf105) {
            auto run = std::u32string(1, cp);
            float w = widthText(run, 3);
            text(z, {right - w, y + 3 * s, w, F}, run, col, 3);
        };
        auto hv = [&](int kind, int index, int option = -1) {
            int key = kind * 10000 + (index + 1) * 16 + option + 1;
            auto it = hoverMotion.find(key);
            return it == hoverMotion.end() ? 0.f : it->second.value;
        };
        auto iv = [&](int kind, int index, int option = -1) {
            int key = kind * 10000 + (index + 1) * 16 + option + 1;
            auto it = inkMotion.find(key);
            bool selected = false;
            if (index >= 0 && kind == 3)
                selected = cfg.worldView.value[std::size_t(index)] != 0;
            else if (index >= 0 && kind == 5)
                selected = WorldViewSpecs[std::size_t(index)].kind == WorldKind::Choice
                               ? int(cfg.worldView.value[std::size_t(index)]) == option
                               : (int(cfg.worldView.value[std::size_t(index)]) & (1 << option)) != 0;
            return it == inkMotion.end() ? (selected ? 1.f : 0.f) : it->second.value;
        };
        const float top = headerLine.y + headerLine.h + 15 * s;
        Box region{l.content.x + 15 * s, top, std::max(0.f, l.content.w - 30 * s),
                   std::max(0.f, l.content.y + l.content.h - top - 15 * s)};

        float headerF = fonts.PixelHeight(0, 10 * s);
        card = {region.x, top + headerF + 5 * s, std::min(300 * s, region.w), 14 * s + 6 * H + 5 * 15 * s};
        if (hudEnabled) {
            esp.languages = languages;
            Box ep{card.x, card.y + card.h + 15 * s, card.w,
                   std::max(0.f, region.y + region.h - card.y - card.h - 15 * s)};
            esp.Measure(fonts, cfg, ep, width, height, visible,
                        blocked || panel >= 0 || hud.Active() || misc.Active());
            hud.languages = languages;
            hud.Measure(fonts, cfg, l, card, headerLine, width, height, visible,
                        blocked || panel >= 0 || misc.Active() || esp.Active());
        } else {
            esp.Close(true);
            hud.Close();
        }
        if (hudEnabled) {
            misc.languages = languages;
            misc.overlayArea = l.content;
            Box position{hud.card.x, hud.card.y + hud.card.h + 15 * s, hud.card.w,
                         std::max(0.f, l.content.y + l.content.h - hud.card.y - hud.card.h - 30 * s)};
            misc.Measure(fonts, cfg, position, width, height, visible,
                         blocked || panel >= 0 || hud.Active() || esp.Active());
        }
        int z = layer({region.x, region.y, region.w, std::max(region.h, card.h + headerF + 5 * s)});
        text(z, {card.x + 14 * s, top, card.w - 28 * s, headerF}, Upper(Label("group_visuals_world_view")),
             pal[3], 0, 10);
        cardShape(z, card);
        float y = card.y + 7 * s;
        for (int p = 0; p < 6; ++p) {
            Box row{card.x + 14 * s, y, card.w - 28 * s, H};
            groupRows[std::size_t(p)] = row;
            if (p) {
                rect(z, {row.x, y - 8 * s, row.w, s}, pal[34]);
                paint.layers[std::size_t(z)].draw.back().pixelLine = true;
            }

            groupHoverBounds[std::size_t(p)] = OptionsHoverBounds(row, s);
            float motion = hv(1, p);
            if (motion > 0) {
                rect(z, groupHoverBounds[std::size_t(p)], alpha(pal[33], .15f * motion), 15 * s);
                paint.layers[std::size_t(z)].draw.back().corners = p == 0 ? 3u : p == 5 ? 12u : 0u;
            }
            auto col = p < 4 ? pal[0] : Mix(pal[0], pal[2], iv(1, p));
            float right = row.x + row.w - 6 * s;
            Box control{};
            if (p < 4) {
                text(z, {row.x, row.y + 3 * s, row.w - 24 * s, F},
                     Label(std::string("visuals_world_view_") + PanelKeys[std::size_t(p)]), col);
                arrow(z, right, row.y, col);
                hit(z, groupHoverBounds[std::size_t(p)], 1, p);
            } else {
                float cw = std::trunc(row.w / 2.2f) + 12 * s;
                control = {row.x + row.w - cw, row.y, cw, H};
                Color preview = Mix(pal[14], pal[2], motion);
                float aw = widthText(U"\uf107", 3);
                rect(z, control, Mix(pal[12], pal[13], motion), 6 * s);
                rect(z, control, pal[11], 6 * s, s);
                text(z, {row.x, row.y + 3 * s, std::max(0.f, control.x - row.x - 6 * s), F},
                     Label(std::string("visuals_world_view_") + PanelKeys[std::size_t(p)]), col);
                text(z, {control.x + 6 * s, control.y + 3 * s, std::max(0.f, control.w - aw - 18 * s), F},
                     MultiSummary(p == 4 ? 33 : 34, cfg), preview);
                text(z, {control.x + control.w - aw - 6 * s, control.y + (H - F) * .5f + s, aw, F}, U"\uf107",
                     preview, 3);
                hit(z, row, 1, p, -1, control);
            }
            groupControls[std::size_t(p)] = control;
            y += pitch;
        }
        const float ga = groupFade.value;
        for (auto& d : paint.layers[std::size_t(z)].draw)
            d.color.a *= ga;
        int shown = panel >= 0 ? panel : fadedPanel;
        bool interactive = panel >= 0;
        searchLayerStart = searchLayerEnd = paint.layers.size();
        if (searchDetached && shown >= 4 && shown < 6)
            groupControls[std::size_t(shown)] = searchAnchor;
        if (shown >= 0) {
            struct Block {
                int root;
                std::vector<int> fields;
                float height;
            };
            std::vector<Block> blocks;
            float total = 0;
            if (shown < 4) {
                for (std::size_t i = 0; i < WorldViewSpecs.size(); ++i) {
                    const auto& d = WorldViewSpecs[i];
                    if (d.page != shown)
                        continue;
                    if (d.parent < 0)
                        blocks.push_back({int(i), {}, 14 * s});
                    if (blocks.empty())
                        continue;
                    auto& b = blocks.back();
                    b.fields.push_back(int(i));
                    b.height += innerH;
                }
                for (const auto& b : blocks)
                    total += b.height + 7 * s;
            }
            bool direct = shown >= 4;
            float pw = std::min(265 * s, std::max(1.f, float(width) - 12 * s));
            float titleH = F + 18 * s;
            if (direct) {
                auto options = Options(shown == 4 ? 33 : 34);
                pw = groupControls[std::size_t(shown)].w;
                float markerW = (widthText(U"\uf00c", 3) + 12 * s) * MarkerAmount(shown == 4 ? 33 : 34, cfg);
                for (const auto& key : options)
                    pw = std::max(pw, widthText(Label(key)) + 38 * s + markerW);
                total = float(options.size()) * (F + 14 * s);
                titleH = 0;
            }
            float desired = direct ? total + 14 * s : titleH + total;
            float ph = std::min(desired, std::max(1.f, float(height) - 12 * s));
            Box pos = direct ? Box{groupControls[std::size_t(shown)].x +
                                       (groupControls[std::size_t(shown)].w - pw) * .5f,
                                   groupControls[std::size_t(shown)].y + (H - ph) * .5f, pw, ph}
                             : Box{anchor.x, anchor.y, pw, ph};
            if (direct) {
                if (!directPosition) {
                    directAnchor = pos;
                    directPosition = true;
                } else {
                    pos.x = directAnchor.x;
                    pos.y = directAnchor.y;
                }
            }
            popup = PresetPopupFit(pos, width, height);
            body = {popup.x + 7 * s, popup.y + (direct ? 7 * s : titleH), popup.w - 14 * s,
                    std::max(0.f, popup.h - (direct ? 14 * s : titleH + 7 * s))};
            maxScroll = std::max(0.f, (direct ? total : total - 7 * s) - body.h);
            scroll = std::clamp(scroll, 0.f, maxScroll);
            if (interactive)
                hits.push_back({{0, 0, float(width), float(height)}, 0, -1, -1, 0});
            int pz = surface(popup, 15 * s);
            if (interactive)
                hit(pz, popup, 6);
            if (!direct)
                text(pz, {popup.x + 14 * s, popup.y + 7 * s, popup.w - 28 * s, F},
                     Label(std::string("visuals_world_view_") + PanelKeys[std::size_t(shown)]), pal[2], 2);
            int bz = layer(body);
            y = body.y - scroll;
            auto optionRows = [&](int oz, Box b, int i, bool enabled) {
                auto options = Options(i);
                bool multi = WorldViewSpecs[std::size_t(i)].kind == WorldKind::Multi;
                float marker = 0;
                if (multi) {
                    auto it = markerMotion.find(i);
                    marker = it == markerMotion.end() ? (cfg.worldView.value[std::size_t(i)] != 0 ? 1.f : 0.f)
                                                      : it->second.value;
                }
                float markerW = (widthText(U"\uf00c", 3) + 12 * s) * marker;
                float cy = b.y;
                for (std::size_t j = 0; j < options.size(); ++j) {
                    Box row{b.x, cy, b.w, F + 14 * s};
                    bool selected = multi ? (int(cfg.worldView.value[std::size_t(i)]) & (1 << j)) != 0
                                          : int(cfg.worldView.value[std::size_t(i)]) == int(j);
                    rect(oz, row, alpha(pal[33], .4f * hv(5, i, int(j))), (15 * s) / 1.6f);
                    float left = row.x + 12 * s;
                    if (multi && selected && marker > 0)
                        text(oz, {left, row.y + 7 * s, markerW, F}, U"\uf00c", alpha(pal[0], marker), 3);
                    text(oz, {left + markerW, row.y + 7 * s, std::max(0.f, row.w - 24 * s - markerW), F},
                         Label(options[j]), Mix(pal[14], pal[2], iv(5, i, int(j))));
                    if (enabled)
                        hit(oz, row, 5, i, int(j));
                    cy += row.h;
                }
            };
            if (direct)
                optionRows(bz, {body.x, y, body.w, total}, shown == 4 ? 33 : 34, interactive);
            for (const auto& block : blocks) {
                Box cb{body.x, y, body.w, block.height};
                cardShape(bz, cb);
                float cy = cb.y + 7 * s;
                for (int i : block.fields) {
                    const auto& d = WorldViewSpecs[std::size_t(i)];
                    float a = availability[std::size_t(i)].initialized ? availability[std::size_t(i)].value
                                                                       : (Enabled(i, cfg) ? 1.f : .5f);

                    Box row{cb.x + 7 * s, cy, cb.w - 14 * s, innerH};
                    rows[std::size_t(i)] = PresetIntersect(row, body);
                    bool enabled = Enabled(i, cfg) && interactive;
                    int kind = d.kind == WorldKind::Check                                       ? 3
                               : (d.kind == WorldKind::Integer || d.kind == WorldKind::Decimal) ? 2
                                                                                                : 4;
                    localClip = {row.x, row.y, row.w, row.h};
                    float v = Enabled(i, cfg) ? hv(kind, i) : 0.f;

                    rect(bz, row, alpha(pal[33], .4f * v * a), (15 * s) / 1.6f);
                    Color ink = alpha(Enabled(i, cfg) ? Mix(pal[14], pal[2], iv(kind, i)) : pal[14],
                                      a * (Enabled(i, cfg) ? 1.f : .5f));
                    float left = row.x + 12 * s, right = row.x + row.w - 12 * s, labelRight = right;
                    Box control{};
                    if (d.kind == WorldKind::Check) {
                        float nominal = F + 2 * s, center = row.y + row.h * .5f,
                              frac = center - std::trunc(center);
                        control = {right - 32 * s, center - nominal * .5f + frac, 32 * s, nominal - 2 * frac};
                        toggles[std::size_t(i)] = control;
                        float t = check[std::size_t(i)].initialized ? check[std::size_t(i)].value
                                                                    : cfg.worldView.value[std::size_t(i)];
                        rect(bz, control, alpha(pal[22], a), nominal * .5f);
                        rect(bz, control, alpha(pal[23], a * t), nominal * .5f);
                        float r = nominal * .5f - 2 * s,
                              cx = control.x + nominal * .5f + (control.w - nominal) * t;
                        rect(bz, {cx - r, center - r, 2 * r, 2 * r}, alpha(Mix(pal[20], pal[21], t), a), r);
                        labelRight = control.x - 6 * s;
                        if (enabled)
                            hit(bz, row, 3, i, -1, control);
                    } else if (kind == 2) {
                        float w = std::trunc(row.w / 2.5f);
                        control = {right - w, row.y + (row.h - 6 * s) * .5f, w, 6 * s};
                        sliders[std::size_t(i)] = PresetIntersect(PresetIntersect(control, body), localClip);
                        float t = (cfg.worldView.value[std::size_t(i)] - d.minimum) / (d.maximum - d.minimum);
                        rect(bz, control, alpha(pal[24], a), 3 * s);
                        if (t > 0)
                            rect(bz, control, alpha(pal[25], a), 3 * s, 0,
                                 {control.x, control.y, w * t, control.h});
                        labelRight = control.x - 6 * s;
                        if (editing == i) {
                            Box edit{control.x, row.y, control.w, row.h};
                            rect(bz, edit, pal[12], 6 * s);
                            rect(bz, edit, pal[11], 6 * s, s);
                            text(bz, {edit.x + 6 * s, edit.y + 7 * s, edit.w - 12 * s, F},
                                 DecodeUTF8(numeric + "|"), pal[2]);
                        }
                        if (enabled) {
                            hit(bz, row, 8, i);
                            hits.back().key = 2 * 10000 + (i + 1) * 16;
                            hit(bz, {control.x, row.y, control.w, row.h}, 2, i, -1, control);
                        }
                    } else if (d.kind == WorldKind::Choice) {
                        auto options = Options(i);
                        auto value = Label(options[std::size_t(int(cfg.worldView.value[std::size_t(i)]))]);
                        float aw = widthText(U"\uf105", 3), vw = widthText(value);
                        control = {std::max(left, right - vw - aw - 4 * s), row.y,
                                   std::min(row.w - 24 * s, vw + aw + 4 * s), row.h};
                        text(bz, {control.x, row.y + 7 * s, std::max(0.f, control.w - aw - 4 * s), F}, value,
                             alpha(pal[14], a));
                        arrow(bz, right, row.y + 4 * s, alpha(pal[14], a));
                        labelRight = control.x - 8 * s;
                        if (enabled)
                            hit(bz, row, 4, i, -1, control);
                    } else {

                        auto value = MultiSummary(i, cfg, true);
                        float aw = widthText(U"\uf105", 3), vw = widthText(value);
                        control = {std::max(left, right - vw - aw - 3 * s), row.y,
                                   std::min(row.w - 24 * s, vw + aw + 3 * s), row.h};
                        text(bz, {control.x, row.y + 7 * s, std::max(0.f, control.w - aw - 3 * s), F}, value,
                             alpha(pal[14], a));
                        arrow(bz, right, row.y + 4 * s, alpha(pal[14], a));
                        labelRight = control.x;
                        if (enabled)
                            hit(bz, row, 4, i, -1, control);
                    }
                    text(bz, {left, row.y + 7 * s, std::max(0.f, labelRight - left), F}, Label(d.key), ink);
                    localClip = {};
                    cy += row.h;
                }
                y += block.height + 7 * s;
            }
            if (maxScroll > 0) {
                track = {popup.x + popup.w - 6 * s, body.y, 5 * s, body.h};
                float th = std::max(10 * s, body.h * body.h / (body.h + maxScroll));
                thumb = {track.x, track.y + (track.h - th) * scroll / maxScroll, track.w, th};
                rect(pz, track, pal[17], 4 * s);
                rect(pz, thumb, pal[18], 4 * s);
                if (interactive)
                    hit(pz, track, 7);
            }
            auto choiceStart = paint.layers.size();
            if (choice >= 0 && interactive) {
                if (searchDetached) {
                    hits.clear();
                    hits.push_back({searchAnchor, 4, choice, -1, pz, searchAnchor});
                }
                auto found = std::find_if(hits.begin(), hits.end(), [&](const WorldViewHit& h) {
                    return h.kind == 4 && h.index == choice;
                });
                if (found == hits.end() || !Enabled(choice, cfg))
                    choice = -1;
                else {
                    auto options = Options(choice);
                    float w = 140 * s;
                    for (const auto& key : options)
                        w = std::max(w,
                                     widthText(Label(key)) + 38 * s +
                                         (WorldViewSpecs[std::size_t(choice)].kind == WorldKind::Multi
                                              ? (widthText(U"\uf00c", 3) + 12 * s) * MarkerAmount(choice, cfg)
                                              : 0.f));
                    float h = std::min(300 * s, float(options.size()) * (F + 14 * s) + 14 * s);
                    Box b;
                    if (WorldViewSpecs[std::size_t(choice)].kind == WorldKind::Multi) {
                        b = {found->box.x + found->box.w + 7 * s,
                             found->box.y + found->box.h * .5f - h * .25f, w, h};
                        b.x = std::clamp(b.x, 0.f, std::max(0.f, float(width) - b.w - 10 * s));
                        b.y = std::clamp(b.y, 0.f, std::max(0.f, float(height) - b.h - 10 * s));
                    } else
                        b = PresetPopupFit({found->control.x, found->box.y + found->box.h + 5 * s, w, h},
                                           width, height);
                    hits.push_back({{0, 0, float(width), float(height)}, 0, -1, -1, pz});
                    int dz = surface(b, 15 * s);
                    hit(dz, b, 6);
                    optionRows(dz, {b.x + 7 * s, b.y + 7 * s, b.w - 14 * s, b.h - 14 * s}, choice, true);
                }
            }
            if (choice >= 0 && interactive)
                choiceTransition.FinishPaint(paint, choiceStart);
            else
                choiceTransition.AppendClosing(paint);
            if (searchDetached) {
                searchLayerStart = direct ? 1 : choiceStart;
                searchLayerEnd = paint.layers.size();
            }

            if (choice < 0 && editing < 0)
                for (std::size_t i = 0; i < sliders.size(); ++i) {
                    const auto& b = sliders[i];
                    float a = sliderTip[i].value;
                    if (b.w <= 0 || b.h <= 0 || a <= .001f || !Enabled(int(i), cfg))
                        continue;
                    auto value = ValueLabel(int(i), cfg);
                    float tw = widthText(value), t = (cfg.worldView.value[i] - WorldViewSpecs[i].minimum) /
                                                     (WorldViewSpecs[i].maximum - WorldViewSpecs[i].minimum);
                    float tx = b.x + b.w * t - tw * .5f, ty = b.y - F - 10 * s;
                    Box tip = PresetPopupFit({tx - 7 * s, ty - 4 * s, tw + 14 * s, F + 9 * s}, width, height);
                    int tz = surface(tip, 8 * s, false);
                    paint.layers[std::size_t(tz)].opacity = a;
                    text(tz, {tip.x + 7 * s, tip.y + 4 * s, tw, F}, value, pal[0]);
                    for (auto& d2 : paint.layers[std::size_t(tz)].draw)
                        d2.color.a *= a;
                }
            float opacity = popupFade.value;
            for (std::size_t j = 1; j < paint.layers.size(); ++j) {
                paint.layers[j].opacity *= opacity;
                for (auto& d : paint.layers[j].draw)
                    d.color.a *= opacity;
            }
        }

        auto tipKey = DescriptionTooltipKey();
        if (!tipKey.empty() && hoverTime >= .3f) {
            int n = HoverHit(mouseX, mouseY);
            if (n >= 0) {
                const auto& h = hits[std::size_t(n)];
                std::string title = h.kind == 1
                                        ? std::string("visuals_world_view_") + PanelKeys[std::size_t(h.index)]
                                        : WorldViewSpecs[std::size_t(h.index)].key;
                tooltipLast =
                    WorldDescriptionTooltip(fonts, cfg, h.box, Label(title), Label(tipKey), width, height);
                tooltipStored = true;
            }
        }
        if (tooltipStored)
            AppendWorldTooltip(paint, tooltipLast, tooltipFade.value);
        if (focus >= int(hits.size()))
            focus = -1;
        hover = HoverHit(mouseX, mouseY);
        if (hudEnabled && !esp.paint.layers.empty()) {
            paint.layers.insert(paint.layers.begin() + std::min(std::size_t(1), paint.layers.size()),
                                esp.paint.layers.front());
            for (std::size_t i = 1; i < esp.paint.layers.size(); ++i)
                paint.layers.push_back(esp.paint.layers[i]);
        }
        if (hudEnabled && !hud.paint.layers.empty()) {

            paint.layers.insert(paint.layers.begin() + std::min(std::size_t(2), paint.layers.size()),
                                hud.paint.layers.front());
            for (std::size_t i = 1; i < hud.paint.layers.size(); ++i)
                paint.layers.push_back(hud.paint.layers[i]);
        }
        if (hudEnabled && !misc.paint.layers.empty()) {
            paint.layers.insert(paint.layers.begin() + std::min(std::size_t(3), paint.layers.size()),
                                misc.paint.layers.front());
            for (std::size_t i = 1; i < misc.paint.layers.size(); ++i)
                paint.layers.push_back(misc.paint.layers[i]);
        }
    }
};
}
