#pragma once

#include "players_live_data.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <sstream>
#include <string>
#include <vector>
namespace menu {
namespace world_scoreboard {
inline constexpr int DefaultOpacity = 88, DefaultWidth = 100;
inline constexpr std::size_t FirstIndex = 16, CategoryIndex = 21;
inline constexpr std::uint64_t CollectIntervalMs = 200;
inline constexpr std::uint64_t ScriptIntervalMs = 200;
inline constexpr std::uint64_t FrameMaxAgeMs = 1500;
inline constexpr unsigned LeaseMs = 3000;
inline constexpr std::size_t MaxPlayers = 64, MaxItems = 24;

enum WeaponType : int {
    Knife = 0,
    Pistol = 1,
    Submachinegun = 2,
    Rifle = 3,
    Shotgun = 4,
    SniperRifle = 5,
    Machinegun = 6,
    C4 = 7,
    Taser = 8,
    Grenade = 9,
    Equipment = 10,
    StackableItem = 11,
    Fists = 12,
    BreachCharge = 13,
    BumpMine = 14,
    Tablet = 15,
    Melee = 16,
    Shield = 17,
    ZoneRepulsor = 18
};

enum class Category : unsigned {
    Primary = 0,
    Secondary,
    Knife,
    Taser,
    Grenades,
    Bomb,
    DefuseKit,
    Armor,
    Other
};
inline constexpr std::size_t CategoryCount = 9;
inline constexpr std::uint16_t DefTaser = 31, DefC4 = 49, DefArmor = 50, DefArmorHelmet = 51, DefDefuser = 55;
struct WeaponEntry {
    std::uint16_t def;
    const char* name;
    int type;
};

inline constexpr std::array<WeaponEntry, 82> Weapons{{{1, "deagle", Pistol},
                                                      {2, "elite", Pistol},
                                                      {3, "fiveseven", Pistol},
                                                      {4, "glock", Pistol},
                                                      {7, "ak47", Rifle},
                                                      {8, "aug", Rifle},
                                                      {9, "awp", SniperRifle},
                                                      {10, "famas", Rifle},
                                                      {11, "g3sg1", SniperRifle},
                                                      {13, "galilar", Rifle},
                                                      {14, "m249", Machinegun},
                                                      {16, "m4a1", Rifle},
                                                      {17, "mac10", Submachinegun},
                                                      {19, "p90", Submachinegun},
                                                      {20, "zone_repulsor", ZoneRepulsor},
                                                      {23, "mp5sd", Submachinegun},
                                                      {24, "ump45", Submachinegun},
                                                      {25, "xm1014", Shotgun},
                                                      {26, "bizon", Submachinegun},
                                                      {27, "mag7", Shotgun},
                                                      {28, "negev", Machinegun},
                                                      {29, "sawedoff", Shotgun},
                                                      {30, "tec9", Pistol},
                                                      {31, "taser", Taser},
                                                      {32, "hkp2000", Pistol},
                                                      {33, "mp7", Submachinegun},
                                                      {34, "mp9", Submachinegun},
                                                      {35, "nova", Shotgun},
                                                      {36, "p250", Pistol},
                                                      {37, "shield", Shield},
                                                      {38, "scar20", SniperRifle},
                                                      {39, "sg556", Rifle},
                                                      {40, "ssg08", SniperRifle},
                                                      {41, "knifegg", Knife},
                                                      {42, "knife", Knife},
                                                      {43, "flashbang", Grenade},
                                                      {44, "hegrenade", Grenade},
                                                      {45, "smokegrenade", Grenade},
                                                      {46, "molotov", Grenade},
                                                      {47, "decoy", Grenade},
                                                      {48, "incgrenade", Grenade},
                                                      {49, "c4", C4},
                                                      {57, "healthshot", StackableItem},
                                                      {59, "knife_t", Knife},
                                                      {60, "m4a1_silencer", Rifle},
                                                      {61, "usp_silencer", Pistol},
                                                      {63, "cz75a", Pistol},
                                                      {64, "revolver", Pistol},
                                                      {68, "tagrenade", Grenade},
                                                      {69, "fists", Fists},
                                                      {70, "breachcharge", BreachCharge},
                                                      {72, "tablet", Tablet},
                                                      {74, "melee", Melee},
                                                      {75, "axe", Melee},
                                                      {76, "hammer", Melee},
                                                      {78, "spanner", Melee},
                                                      {80, "knife_ghost", Knife},
                                                      {81, "firebomb", Grenade},
                                                      {82, "diversion", Grenade},
                                                      {83, "frag_grenade", Grenade},
                                                      {84, "snowball", Grenade},
                                                      {85, "bumpmine", BumpMine},
                                                      {500, "bayonet", Knife},
                                                      {503, "knife_css", Knife},
                                                      {505, "knife_flip", Knife},
                                                      {506, "knife_gut", Knife},
                                                      {507, "knife_karambit", Knife},
                                                      {508, "knife_m9_bayonet", Knife},
                                                      {509, "knife_tactical", Knife},
                                                      {512, "knife_falchion", Knife},
                                                      {514, "knife_survival_bowie", Knife},
                                                      {515, "knife_butterfly", Knife},
                                                      {516, "knife_push", Knife},
                                                      {517, "knife_cord", Knife},
                                                      {518, "knife_canis", Knife},
                                                      {519, "knife_ursus", Knife},
                                                      {520, "knife_gypsy_jackknife", Knife},
                                                      {521, "knife_outdoor", Knife},
                                                      {522, "knife_stiletto", Knife},
                                                      {523, "knife_widowmaker", Knife},
                                                      {525, "knife_skeleton", Knife},
                                                      {526, "knife_kukri", Knife}}};
inline const WeaponEntry* FindWeapon(std::uint16_t def) {
    for (const auto& w : Weapons)
        if (w.def == def)
            return &w;
    return nullptr;
}

inline const WeaponEntry* FindWeaponByDesigner(const std::string& designer) {
    if (designer.rfind("weapon_", 0) != 0)
        return nullptr;
    const auto name = designer.substr(7);
    for (const auto& w : Weapons)
        if (name == w.name)
            return &w;
    return nullptr;
}

inline Category CategoryOf(int type, bool c4Entity) {
    switch (type) {
    case Knife:
        return Category::Knife;
    case Pistol:
        return Category::Secondary;
    case Submachinegun:
    case Rifle:
    case Shotgun:
    case SniperRifle:
    case Machinegun:
    case Melee:
        return Category::Primary;
    case Taser:
        return Category::Taser;
    case Grenade:
        return Category::Grenades;
    default:
        return c4Entity ? Category::Bomb : Category::Other;
    }
}

inline int RankOf(std::uint16_t def, int type) {
    if (def == DefTaser)
        return 3;
    if (def == DefDefuser)
        return 6;
    if (def == DefC4)
        return 5;
    if (def == DefArmor || def == DefArmorHelmet)
        return 7;
    switch (type) {
    case Knife:
        return 2;
    case Pistol:
        return 1;
    case Submachinegun:
    case Rifle:
    case Shotgun:
    case SniperRifle:
    case Machinegun:
    case Melee:
        return 0;
    case Grenade:
        return 4;
    default:
        return 8;
    }
}
}
struct ScoreboardConfig {
    int opacity = world_scoreboard::DefaultOpacity, width = world_scoreboard::DefaultWidth;
    bool money = false, ranks = false, atSync = false;
    unsigned equipment = 0;
    std::array<bool, world_scoreboard::CategoryCount> show{
        {true, true, false, false, false, false, false, false, false}};
    bool Appearance() const {
        return opacity != world_scoreboard::DefaultOpacity || width != world_scoreboard::DefaultWidth;
    }
    bool Wanted() const {
        return Appearance() || money || ranks || equipment != 0 || atSync;
    }
    bool NeedsPlayers() const {
        return money || equipment != 0 || atSync;
    }
    bool Shows(world_scoreboard::Category c) const {
        return show[std::size_t(c)];
    }
    bool operator==(const ScoreboardConfig& o) const {
        return opacity == o.opacity && width == o.width && money == o.money && ranks == o.ranks &&
               atSync == o.atSync && equipment == o.equipment && show == o.show;
    }
    bool operator!=(const ScoreboardConfig& o) const {
        return !(*this == o);
    }
};
inline ScoreboardConfig ScoreboardReadConfig(const Settings& cfg) {
    static const WorldHudValues defaults;
    const auto& v = cfg.worldHud.value;
    using namespace world_scoreboard;
    auto num = [&](std::size_t i) {
        const auto& d = WorldHudSpecs[i];
        const float x = v[i];
        return std::isfinite(x) ? std::clamp(std::round(x), d.minimum, d.maximum) : defaults.value[i];
    };
    ScoreboardConfig c;
    c.opacity = int(num(FirstIndex));
    c.width = int(num(FirstIndex + 1));
    c.money = num(FirstIndex + 2) >= .5f;
    c.ranks = num(FirstIndex + 3) >= .5f;
    c.equipment = unsigned(num(FirstIndex + 4));
    for (std::size_t i = 0; i < CategoryCount; ++i)
        c.show[i] = num(CategoryIndex + i) >= .5f;
    return c;
}

struct ScoreboardItem {
    std::string name;
    std::uint16_t def = 0;
    int type = -1;
    bool active = false;
    bool operator==(const ScoreboardItem& o) const {
        return name == o.name && def == o.def && type == o.type && active == o.active;
    }
};

struct ScoreboardWeaponFact {
    std::uint16_t def = 0;
    std::string designer;
    bool active = false;
};
struct ScoreboardPlayerFacts {
    bool alive = false;
    int team = 0;
    std::vector<ScoreboardWeaponFact> weapons;
    bool itemServices = false, hasDefuser = false, hasHelmet = false;
    int armor = 0;
};

inline std::vector<ScoreboardItem> ScoreboardBuildItems(const ScoreboardConfig& c,
                                                        const ScoreboardPlayerFacts& f, int localTeam,
                                                        bool hasLocal) {
    using namespace world_scoreboard;
    std::vector<ScoreboardItem> items;
    if (c.equipment == 0 || !f.alive)
        return items;
    const bool teammate = hasLocal && f.team == localTeam;
    if (c.equipment != 2 && hasLocal && teammate)
        return items;
    for (const auto& w : f.weapons) {
        if (items.size() >= MaxItems)
            break;
        const WeaponEntry* entry = w.def ? FindWeapon(w.def) : FindWeaponByDesigner(w.designer);
        if (!entry)
            continue;
        const bool c4 = w.designer.empty() ? entry->def == DefC4 : w.designer == "weapon_c4";
        if (!c.Shows(CategoryOf(entry->type, c4)))
            continue;
        auto same = std::find_if(items.begin(), items.end(),
                                 [&](const ScoreboardItem& i) { return i.name == entry->name; });
        if (same != items.end()) {
            same->active = same->active || w.active;
            continue;
        }
        items.push_back({entry->name, entry->def, entry->type, w.active});
    }
    if (c.Shows(Category::DefuseKit) && f.itemServices && f.hasDefuser && items.size() < MaxItems)
        items.push_back({"defuser", DefDefuser, Equipment, false});
    if (c.Shows(Category::Armor) && items.size() < MaxItems) {
        if (f.itemServices && f.hasHelmet)
            items.push_back({"armor_helmet", DefArmorHelmet, Equipment, false});
        else if (f.armor > 0)
            items.push_back({"armor", DefArmor, Equipment, false});
    }
    std::stable_sort(items.begin(), items.end(), [](const ScoreboardItem& a, const ScoreboardItem& b) {
        return RankOf(a.def, a.type) < RankOf(b.def, b.type);
    });
    return items;
}

struct ScoreboardPlayer {
    std::uint32_t slot = 0;
    std::uint64_t steamID = 0;
    int team = 0;
    std::optional<int> money;
    bool itemsValid = false, atUser = false;
    std::vector<ScoreboardItem> items;
};
struct ScoreboardFrame {
    bool valid = false;
    std::vector<ScoreboardPlayer> players;
    const char* stage = "not sampled";
    unsigned controllers = 0, pawns = 0, weapons = 0, unknown = 0, torn = 0, foreign = 0;
    const char* inventory = "off";
};

struct ScoreboardOffsets {
    std::uint32_t localFlag = 0, pawnHandle = 0, team = 0, life = 0;
    std::uint32_t steamID = 0, moneyServices = 0, money = 0;
    std::uint32_t weaponServices = 0, inventory = 0, activeWeapon = 0, itemDefinition = 0, identity = 0,
                  designerName = 0;
    std::uint32_t itemServices = 0, hasDefuser = 0, hasHelmet = 0, armor = 0;
    std::uint32_t ownerHandle = 0;
    bool inventoryVerified = false;
    bool Valid() const {
        return localFlag && pawnHandle && team && life;
    }

    bool Weapons() const {
        return weaponServices && inventory && (inventoryVerified || ownerHandle) &&
               (itemDefinition || (identity && designerName));
    }
    const char* InventoryProof() const {
        return !(weaponServices && inventory && (itemDefinition || (identity && designerName))) ? "off"
               : inventoryVerified                                                              ? "verified"
               : ownerHandle ? "owner-checked"
                             : "off";
    }
};
struct ScoreboardContext {
    std::uintptr_t entities = 0, localGlobal = 0;
    ScoreboardOffsets offsets{};
    bool valid = false;
};

template <class Reader>
bool ScoreboardReadWeapons(Reader&& read, std::uintptr_t global, std::uintptr_t pawn,
                           std::uint32_t pawnHandle, const ScoreboardOffsets& o,
                           std::vector<ScoreboardWeaponFact>& out, unsigned* foreign = nullptr) {
    out.clear();
    if (!o.Weapons())
        return false;
    const bool ownerCheck = !o.inventoryVerified;
    unsigned resolved = 0, owned = 0;
    if (ownerCheck && (!o.ownerHandle || pawnHandle == 0xFFFFFFFFu || !(pawnHandle & 0x7FFFu)))
        return false;
    std::uintptr_t service = 0;
    if (!read(pawn + o.weaponServices, service))
        return false;
    if (!service)
        return true;
    std::uint32_t activeHandle = 0xFFFFFFFFu;
    if (o.activeWeapon && !read(service + o.activeWeapon, activeHandle))
        return false;
    const auto at = service + o.inventory;
    std::uint32_t count = 0;
    std::uintptr_t data = 0;
    if (!read(at, count) || count > 64 || !read(at + 8, data) || (count && !data))
        return false;
    std::array<std::uint32_t, 64> handles{};
    for (std::uint32_t i = 0; i < count; ++i) {
        if (!read(data + std::uintptr_t(i) * 4, handles[i]))
            return false;
        const auto h = handles[i];
        if (!h || h == 0xFFFFFFFFu || h == 0xFFFFFFFEu)
            continue;
        if (std::find(handles.begin(), handles.begin() + i, h) != handles.begin() + i)
            continue;
        const auto weapon = WatermarkPawn(read, global, h);
        if (!weapon)
            continue;
        if (ownerCheck) {
            ++resolved;
            std::uint32_t owner = 0xFFFFFFFFu;
            if (!read(*weapon + o.ownerHandle, owner) || owner == 0xFFFFFFFFu ||
                (owner & 0x7FFFu) != (pawnHandle & 0x7FFFu)) {
                if (foreign)
                    ++*foreign;
                continue;
            }
            ++owned;
        }
        ScoreboardWeaponFact w;
        if (o.itemDefinition) {
            std::uint16_t def = 0;
            if (read(*weapon + o.itemDefinition, def))
                w.def = def;
        }
        if (o.identity && o.designerName) {
            std::uintptr_t identity = 0, text = 0;
            if (read(*weapon + o.identity, identity) && identity && read(identity + o.designerName, text) &&
                text)
                LiveESPString(read, text, w.designer, 64);
        }
        if (!w.def && w.designer.empty())
            continue;
        w.active = (activeHandle & 0x7FFFu) == (h & 0x7FFFu) && activeHandle != 0xFFFFFFFFu;
        out.push_back(std::move(w));
    }
    std::uint32_t againCount = 0;
    std::uintptr_t againData = 0, againService = 0;
    if (!read(pawn + o.weaponServices, againService) || againService != service || !read(at, againCount) ||
        againCount != count || !read(at + 8, againData) || againData != data)
        return false;
    for (std::uint32_t i = 0; i < count; ++i) {
        std::uint32_t h = 0;
        if (!read(data + std::uintptr_t(i) * 4, h) || h != handles[i])
            return false;
    }
    if (ownerCheck && resolved && !owned) {
        out.clear();
        return false;
    }
    return true;
}

template <class Reader>
ScoreboardFrame ScoreboardCollect(Reader&& read, const ScoreboardContext& c, const ScoreboardConfig& config) {
    ScoreboardFrame frame;
    const auto& o = c.offsets;
    frame.inventory = o.InventoryProof();
    if (!c.valid || !o.Valid() || !c.entities) {
        frame.stage = "context unavailable";
        return frame;
    }
    if (!config.NeedsPlayers()) {
        frame.stage = "nothing to collect";
        return frame;
    }
    frame.stage = "local controller unavailable";
    auto local = WatermarkKdLocalController(read, c.entities, c.localGlobal, o.localFlag);
    if (!local.ok)
        return frame;
    int localTeam = 0;
    bool hasLocal = false;
    if (local.value) {
        std::uint32_t handle = 0;
        std::uint8_t team = 0;
        if (read(local.value + o.pawnHandle, handle)) {
            auto pawn = WatermarkPawn(read, c.entities, handle);
            if (pawn && read(*pawn + o.team, team) && (team == 2 || team == 3)) {
                localTeam = team;
                hasLocal = true;
            }
        }
        if (!hasLocal && read(local.value + o.team, team) && (team == 2 || team == 3)) {
            localTeam = team;
            hasLocal = true;
        }
    }
    frame.stage = "entity root/page unavailable";
    std::uintptr_t root = 0, page = 0;
    if (!read(c.entities, root) || !root || !read(root + 0x10, page) || !page)
        return frame;
    const bool weapons = config.equipment != 0 && o.Weapons();
    for (std::uint32_t index = 1; index <= world_scoreboard::MaxPlayers; ++index) {
        std::uintptr_t controller = 0;
        if (!read(page + std::uintptr_t(index) * 0x70, controller) || !controller)
            continue;
        ++frame.controllers;
        std::uint32_t handle = 0;
        if (!read(controller + o.pawnHandle, handle))
            continue;
        const auto pawn = WatermarkPawn(read, c.entities, handle);
        if (!pawn)
            continue;
        ++frame.pawns;
        ScoreboardPlayer p;
        p.slot = index - 1;
        if (o.steamID) {
            std::uint64_t id = 0;
            if (read(controller + o.steamID, id))
                p.steamID = id;
        }
        std::uint8_t team = 0, life = 255;
        read(*pawn + o.team, team);
        p.team = team;
        if (config.money && o.moneyServices && o.money) {
            std::uintptr_t services = 0;
            int account = 0;
            if (read(controller + o.moneyServices, services) && services &&
                read(services + o.money, account) && account >= 0 && account <= 10000000)
                p.money = account;
        }
        if (config.equipment != 0) {
            ScoreboardPlayerFacts f;
            f.team = team;
            f.alive = read(*pawn + o.life, life) && life == 0;
            bool proven = true;
            if (f.alive && !(config.equipment == 1 && hasLocal && team == localTeam)) {
                if (weapons) {
                    if (!ScoreboardReadWeapons(read, c.entities, *pawn, handle, o, f.weapons,
                                               &frame.foreign)) {
                        proven = false;
                        ++frame.torn;
                    }
                } else
                    proven = false;
                frame.weapons += unsigned(f.weapons.size());
                for (const auto& w : f.weapons)
                    if (!(w.def ? world_scoreboard::FindWeapon(w.def)
                                : world_scoreboard::FindWeaponByDesigner(w.designer)))
                        ++frame.unknown;
                if (o.itemServices) {
                    std::uintptr_t services = 0;
                    if (read(*pawn + o.itemServices, services) && services) {
                        f.itemServices = true;
                        std::uint8_t b = 0;
                        if (o.hasDefuser && read(services + o.hasDefuser, b))
                            f.hasDefuser = b == 1;
                        if (o.hasHelmet && read(services + o.hasHelmet, b))
                            f.hasHelmet = b == 1;
                    }
                }
                if (o.armor) {
                    int armor = 0;
                    if (read(*pawn + o.armor, armor) && armor >= 0 && armor <= 1000)
                        f.armor = armor;
                }
            }
            p.itemsValid = proven;
            if (proven)
                p.items = ScoreboardBuildItems(config, f, localTeam, hasLocal);
        }
        frame.players.push_back(std::move(p));
    }
    std::uintptr_t again = 0;
    if (!read(c.entities, again) || again != root || !read(root + 0x10, again) || again != page) {
        frame.players.clear();
        frame.stage = "frame identity changed";
        return frame;
    }
    auto currentLocal = WatermarkKdLocalController(read, c.entities, c.localGlobal, o.localFlag);
    if (!currentLocal.ok || currentLocal.value != local.value) {
        frame.players.clear();
        frame.stage = "frame identity changed";
        return frame;
    }
    frame.valid = true;
    frame.stage = "collected";
    return frame;
}

inline bool ScoreboardSafeName(const std::string& s) {
    if (s.empty() || s.size() > 48)
        return false;
    for (char ch : s)
        if (!((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '_'))
            return false;
    return true;
}
inline std::string ScoreboardJsonData(const ScoreboardConfig& c, const ScoreboardFrame& f) {
    std::ostringstream s;
    s << "{v:" << (f.valid ? 1 : 0) << ",o:" << c.opacity << ",w:" << c.width << ",m:" << (c.money ? 1 : 0)
      << ",e:" << c.equipment << ",a:" << (c.atSync ? 1 : 0) << ",p:[";
    bool first = true;
    if (f.valid)
        for (const auto& p : f.players) {
            if (!first)
                s << ",";
            first = false;
            s << "{s:" << p.slot << ",x:'" << p.steamID << "',t:" << p.team
              << ",m:" << (p.money ? *p.money : -1) << ",e:" << (p.itemsValid ? 1 : 0)
              << ",a:" << (p.atUser ? 1 : 0) << ",i:[";
            bool firstItem = true;
            for (const auto& i : p.items) {
                if (!ScoreboardSafeName(i.name))
                    continue;
                if (!firstItem)
                    s << ",";
                firstItem = false;
                s << "['" << i.name << "'," << i.def << "," << (i.active ? 1 : 0) << "]";
            }
            s << "]}";
        }
    s << "]}";
    return s.str();
}

inline std::string BuildScoreboardScript(std::uint64_t token, const ScoreboardConfig& c,
                                         const ScoreboardFrame& f, bool cleanup, bool rankEvent) {
    std::ostringstream s;
    s << "(function(){var T='[MenuStudio scoreboard] ';try{var OWNER='" << token
      << "',MODE=" << (cleanup ? 1 : 0) << ",RANK=" << (rankEvent ? 1 : 0)
      << ",LEASE=" << world_scoreboard::LeaseMs
      << ",D=" << (cleanup ? std::string("{v:0,o:88,w:100,m:0,e:0,p:[]}") : ScoreboardJsonData(c, f)) << ";";
    s << R"JS(var G=(typeof globalThis!=='undefined')?globalThis:(function(){return this;})();var root=$.GetContextPanel();if(!G||!root||!root.IsValid())return;
var K='MenuStudioScoreboard',REG='ms_sb_events',S=G[K],BOX='ms_sb_weapons',PFX='ms_sb_',CW='ms-scoreboard-weapons',CI='ms-scoreboard-icon',CM='ms-scoreboard-money',CC='ms-scoreboard-color',CX='ms-scoreboard-width';
var ROWS=[['highlight-row',770],['sb-row',830],['meta-row',860]];
function ok(p){try{return !!p&&p.IsValid();}catch(e){return false;}}
function live(p,id,c){var k=[];try{k=p.Children()||[];}catch(e){}for(var i=0;i<k.length;++i){var q=k[i];if(ok(q)&&q.id===id&&q.BHasClass(c))return q;}return null;} // DeleteAsync keeps a dying panel until the frame ends: ours lose the class first
function all(p,c){try{var r=p.FindChildrenWithClassTraverse(c);return r?r.filter(ok):[];}catch(e){return [];}}
function boards(st,full){var now=Date.now();if(!full&&st.b&&now-(st.bt||0)<1000&&st.b.every(ok))return st.b;st.b=all(root,'sb-main');st.bt=now;return st.b;}
function isRoot(p){return p===root||(!!p.id&&p.id===root.id);}
function scopes(b){var r=[];b.forEach(function(m){var p=null;try{p=m.GetParent();}catch(e){}var u=(ok(p)&&!isRoot(p))?p:m;if(r.indexOf(u)<0)r.push(u);});return r;}
function hex(n){n=Math.max(0,Math.min(255,n|0));return (n<16?'0':'')+n.toString(16);}
function opacity(b,o){b.forEach(function(m){
 if(o===88){if(m.BHasClass(CC)){m.style.backgroundColor='#000000e0';m.RemoveClass(CC);m.SetAttributeString('ms_bg','');}return;}
 var v='#000000'+hex(Math.floor(o*255/100));m.AddClass(CC);m.SetAttributeString('ms_bg',v);m.style.backgroundColor=v;});} // v2.5: every pass - the game puts its own colour back when Tab reopens
function width(sc,w,pass){
 if(w===100){sc.forEach(function(s){all(s,CX).forEach(function(p){var px=860;for(var i=0;i<ROWS.length;++i)if(p.BHasClass(ROWS[i][0])){px=ROWS[i][1];break;}
  p.style.width=px.toFixed(2)+'px';p.RemoveClass(CX);p.SetAttributeString('ms_w','');p.SetAttributeString('ms_pass','');});});return;}
 var extra=(w-100)*960/100;
 ROWS.forEach(function(r){sc.forEach(function(s){all(s,r[0]).forEach(function(p){if(p.GetAttributeString('ms_pass','')===pass)return;p.SetAttributeString('ms_pass',pass);
  var v=(r[1]+extra).toFixed(2)+'px';p.AddClass(CX);p.SetAttributeString('ms_w',v);p.style.width=v;});});});
}
function xuid(p){var x=p.x;try{var a=GameStateAPI.GetPlayerXuidStringFromPlayerSlot(p.s);if(a&&String(a)!=='0')x=String(a);}catch(e){}return (x&&x!=='0')?x:'';}
function row(sc,id){for(var i=0;i<sc.length;++i){var r=null;try{r=sc[i].FindChildTraverse(id);}catch(e){}if(ok(r))return r;}return null;}
function moneyCells(r){var out=[],st=[r],n=0;while(st.length&&n<400){var q=st.pop();++n;var k=[];try{k=q.Children()||[];}catch(e){}
 for(var i=0;i<k.length;++i){var c=k[i];if(!ok(c))continue;var a='';try{a=c.GetAttributeString('data-stat','');}catch(e){}if(a==='money')out.push(c);else st.push(c);}}return out;}
function revealMoney(r,m){moneyCells(r).forEach(function(cell){var l=null;try{l=cell.FindChildTraverse('label');}catch(e){}if(!ok(l))return;
 if(l.BHasClass('hidden')){l.RemoveClass('hidden');l.AddClass(CM);}l.SetDialogVariableInt('stat_d_money',m);});}
function hideMoney(sc){sc.forEach(function(s){all(s,CM).forEach(function(l){l.RemoveClass(CM);l.AddClass('hidden');});});}
function dropWeapons(sc){sc.forEach(function(s){all(s,CW).forEach(function(b){b.RemoveClass(CW);b.DeleteAsync(0);});});}
function image(box,id){var p=null;try{p=$.CreatePanel('ItemImage',box,id);}catch(e){p=null;}
 if(ok(p)&&typeof p.SetImage!=='function'){p.DeleteAsync(0);p=null;}
 if(!ok(p)){try{p=$.CreatePanel('Image',box,id);}catch(e){p=null;}}return ok(p)?p:null;}
function weapons(r,p){
 var icons=null;try{icons=r.FindChildTraverse('id-sb-name__nameicons');}catch(e){}if(!ok(icons))return;
 var box=live(icons,BOX,CW);
 if(!box){if(!p.i.length)return;box=$.CreatePanel('Panel',icons,BOX);if(!ok(box))return;box.AddClass(CW);box.hittest=false;box.hittestchildren=false;
  box.style.height='100%';box.style.flowChildren='right';box.style.textAlign='right';box.style.horizontalAlign='right';
  var mk=null;try{mk=icons.FindChildTraverse('id-sb-name__musickit');}catch(e){}if(ok(mk)){try{icons.MoveChildBefore(box,mk);}catch(e){}}}
 var want={},order=[];p.i.forEach(function(it){var id=PFX+it[0];if(want[id])return;want[id]=it;order.push(id);});
 var kids=[];try{kids=box.Children()||[];}catch(e){}
 kids.forEach(function(k){if(!ok(k)||!k.BHasClass(CI))return;var id=k.id||'';if(id.indexOf(PFX)===0&&!want[id]){k.RemoveClass(CI);k.DeleteAsync(0);}});
 var panels=[];
 order.forEach(function(id){var it=want[id],img=live(box,id,CI);
  if(!img){img=image(box,id);if(!img)return;img.AddClass(CI);img.hittest=false;var s=img.style;s.marginLeft='1px';s.marginRight='1px';s.uiScale='45%';s.verticalAlign='middle';
   s.transitionProperty='opacity';s.transitionDuration='0.1s';s.transitionTimingFunction='ease-in-out';img.SetAttributeInt('data-weapon',-1);}
  if(img.GetAttributeInt('data-weapon',-1)!==it[1]){img.SetAttributeInt('data-weapon',it[1]);try{img.SetImage('s2r://panorama/images/icons/equipment/'+it[0]+'.vsvg');img.SetScaling('stretch-to-fit-preserve-aspect');}catch(e){}}
  var st=(it[2]?'a':'i')+(p.t===3?'3':'2');if(img.GetAttributeString('ms_state','')!==st){img.SetAttributeString('ms_state',st);img.style.opacity=it[2]?'0.85':'0.35';img.style.washColor=p.t===3?'#ccd8e3ff':'#e2d8c4ff';}
  panels.push(img);});
 var cur=[];try{(box.Children()||[]).forEach(function(k){if(ok(k)&&k.BHasClass(CI)&&want[k.id])cur.push(k.id);});}catch(e){}
 var same=cur.length===panels.length;for(var i=0;same&&i<panels.length;++i)if(cur[i]!==panels[i].id)same=false;
 if(!same&&panels.length){try{var first=box.GetChild(0);if(ok(first)&&first.id!==panels[0].id)box.MoveChildBefore(panels[0],first);}catch(e){}
  for(var j=1;j<panels.length;++j){try{box.MoveChildAfter(panels[j],panels[j-1]);}catch(e){}}}
}
// Scoreboard's stat--FLAIR cell is a possible location for the level/medal; the original sync location is not yet verified.
function flairCell(r){var st=[r],n=0;while(st.length&&n<400){var q=st.pop();++n;var k=[];try{k=q.Children()||[];}catch(e){}
 for(var i=0;i<k.length;++i){var c=k[i];if(!ok(c))continue;var a='';try{a=c.GetAttributeString('data-stat','');}catch(e){}if(a==='flair')return c;st.push(c);}}return null;}
function atBadges(sc,d){
 var wanted={};if(d.a&&d.v)d.p.forEach(function(p){if(p.a){var x=xuid(p);if(x&&x===String(p.x))wanted[x]=true;}});
 sc.forEach(function(scope){all(scope,'ms-at-badge').forEach(function(p){var x=p.GetAttributeString('ms-at-xuid','');if(!wanted[x]){p.RemoveClass('ms-at-badge');p.DeleteAsync(0);}});});
 Object.keys(wanted).forEach(function(x){var r=row(sc,'player-'+x);if(!ok(r))return;var flair=flairCell(r);if(!ok(flair))return;
  var p=live(flair,'ms_nl_badge','ms-at-badge');if(!p){p=$.CreatePanel('Panel',flair,'ms_nl_badge');if(!ok(p))return;p.AddClass('ms-at-badge');p.SetAttributeString('ms-at-xuid',x);p.hittest=false;p.hittestchildren=false;
   // Scaled from the dump's startup tile: 42px square, radius12, image14px high, palette42 alpha .75.
   p.style.width='20px';p.style.height='20px';p.style.borderRadius='5.71px';p.style.backgroundColor='#07111fbf';p.style.horizontalAlign='center';p.style.verticalAlign='middle';
   // Asset-free AT logo: broad white forms and cyan/blue relief inspired by the dumped NL, 14x8 pixels.
   // No Image/SetImage: Panorama never needs to load a loose PNG or VTEX.
   var img=$.CreatePanel('Panel',p,'ms_nl_icon');if(!ok(img))return;img.hittest=false;img.hittestchildren=false;
   img.style.width='14px';img.style.height='8px';img.style.horizontalAlign='center';img.style.verticalAlign='middle';
   var pixels=[[2,0,1,"#e0ffffa0"],[3,0,1,"#ffffffc0"],[4,0,1,"#ffffff80"],[6,0,1,"#a0c0e040"],[7,0,6,"#ffffffc0"],[13,0,1,"#ffffffa0"],[1,1,1,"#60a0e040"],[2,1,3,"#ffffffff"],[6,1,1,"#40a0e0a0"],[7,1,2,"#e0ffffff"],[9,1,3,"#ffffffff"],[12,1,1,"#e0ffffff"],[13,1,1,"#e0e0ffe0"],[1,2,1,"#a0c0e0a0"],[2,2,1,"#ffffffff"],[3,2,1,"#a0e0ffff"],[4,2,1,"#ffffffff"],[5,2,1,"#ffffff40"],[6,2,1,"#0040a040"],[7,2,1,"#2080e060"],[8,2,1,"#0060c060"],[9,2,1,"#a0c0e0ff"],[10,2,1,"#ffffffff"],[11,2,1,"#80c0e0a0"],[12,2,1,"#0060c060"],[13,2,1,"#2080c040"],[1,3,1,"#c0e0ffe0"],[2,3,1,"#ffffffe0"],[3,3,1,"#2080c0a0"],[4,3,1,"#ffffffff"],[5,3,1,"#ffffffa0"],[9,3,1,"#a0c0e0e0"],[10,3,1,"#ffffffff"],[11,3,1,"#ffffff40"],[0,4,1,"#60a0c060"],[1,4,1,"#ffffffff"],[2,4,1,"#ffffffe0"],[3,4,1,"#e0e0ffc0"],[4,4,1,"#ffffffff"],[5,4,1,"#ffffffe0"],[8,4,1,"#00208020"],[9,4,1,"#a0c0e0e0"],[10,4,1,"#ffffffff"],[11,4,1,"#e0ffff60"],[0,5,1,"#a0c0e0a0"],[1,5,1,"#ffffffff"],[2,5,1,"#e0ffffff"],[3,5,1,"#ffffffff"],[4,5,1,"#e0ffffff"],[5,5,1,"#ffffffff"],[6,5,1,"#ffffff40"],[8,5,1,"#00008020"],[9,5,1,"#a0c0e0e0"],[10,5,1,"#ffffffff"],[11,5,1,"#ffffff40"],[0,6,1,"#e0e0ffff"],[1,6,1,"#ffffffff"],[2,6,1,"#60a0e080"],[3,6,1,"#0060c060"],[4,6,1,"#40a0e0e0"],[5,6,1,"#ffffffff"],[6,6,1,"#ffffffa0"],[8,6,1,"#00006020"],[9,6,1,"#a0c0e0e0"],[10,6,1,"#ffffffff"],[11,6,1,"#ffffff60"],[0,7,1,"#80c0e0ff"],[1,7,1,"#80c0e0c0"],[4,7,1,"#2060c080"],[5,7,1,"#80c0e0e0"],[6,7,1,"#a0c0e0a0"],[8,7,1,"#00208020"],[9,7,1,"#40a0e0e0"],[10,7,1,"#80c0e0e0"],[11,7,1,"#c0e0ff40"]];
   pixels.forEach(function(a){var bit=$.CreatePanel('Panel',img,'');if(!ok(bit))return;bit.hittest=false;
    bit.style.horizontalAlign='left';bit.style.verticalAlign='top';bit.style.marginLeft=a[0]+'px';bit.style.marginTop=a[1]+'px';
    bit.style.width=a[2]+'px';bit.style.height='1px';bit.style.backgroundColor=a[3];});
  }
 });
}
function apply(st,full){
 var d=st.d;if(!d)return;var b=boards(st,full);if(!b.length)return;var sc=scopes(b);st.pass=(st.pass|0)+1;
 if(d.o!==88||st.tc){opacity(b,d.o);st.tc=d.o!==88;}
 if(d.w!==100||st.tw){width(sc,d.w,OWNER+':'+st.pass);st.tw=d.w!==100;}
 if(!d.m&&st.tm){hideMoney(sc);st.tm=false;}
 if(!d.e&&st.te){dropWeapons(sc);st.te=false;}
 atBadges(sc,d);
 if(!d.v||(!d.m&&!d.e))return;
 d.p.forEach(function(p){var x=xuid(p);if(!x)return;var r=row(sc,'player-'+x);if(!r)return;
  if(d.m&&p.m>=0){revealMoney(r,p.m);st.tm=true;}
  if(d.e&&p.e){weapons(r,p);st.te=true;}});
}
function unregister(ev){ev.forEach(function(e){try{$.UnregisterForUnhandledEvent(e[0],e[1]);}catch(x){}});}
function dispose(st,now){st.d={v:0,o:88,w:100,m:0,e:0,p:[]};st.tc=st.tw=st.tm=st.te=true;st.b=null;try{apply(st,true);}catch(e){$.Msg(T+e);}
 var ev=st.ev||[];st.ev=[];if(ev.length){try{root.SetAttributeString(REG,'');}catch(e){}}
 if(now)unregister(ev);else $.Schedule(0,function(){unregister(ev);});if(G[K]===st)G[K]=undefined;}
function handler(){try{var st=G[K];if(!st||st.owner!==OWNER)return;if(Date.now()-st.lease>LEASE){dispose(st,false);return;}apply(st,false);}catch(e){$.Msg(T+e);}}
function opened(){handler();try{$.Schedule(0.05,handler);$.Schedule(0.3,handler);}catch(e){}} // v2.5: again after the game's own OnOpenScoreboard work (handler order is not ours)
if(S&&S.owner!==OWNER){try{if(typeof S.dispose==='function')S.dispose(S,true);}catch(e){}S=undefined;G[K]=undefined;}
if(MODE===1)dispose(S||{owner:OWNER,ev:[]},true);
else{
 if(!S){S={owner:OWNER,ev:[],b:null,pass:0,tc:true,tw:true,tm:true,te:true};G[K]=S;S.dispose=dispose;
  if(root.GetAttributeString(REG,'')!==OWNER){['Scoreboard_UpdateJob','OnOpenScoreboard'].forEach(function(n){try{var id=$.RegisterForUnhandledEvent(n,n==='OnOpenScoreboard'?opened:handler);S.ev.push([n,id]);}catch(e){}});
   if(S.ev.length)root.SetAttributeString(REG,OWNER);}}
 S.d=D;S.lease=Date.now();apply(S,false);
}
if(RANK){try{$.DispatchEvent('GameState_RankRevealAll');}catch(e){$.Msg(T+e);}}
)JS";
    s << "}catch(e){$.Msg(T+e);}})();";
    return s.str();
}
}
