#pragma once
#include "hud_color_picker.h"

namespace menu {
struct SearchColorEditor {
    HudColorPicker picker;
    MainSearchItem item;
    Box anchor{};
    bool active = false;
    PresetMotion opacity;
    std::vector<PresetLayer> cached;

    void Open(const PresetsUI& ui, const Settings& cfg, LanguageCatalog* languages) {
        const int n = ui.mainSearchColorRequest;
        if (n < 0 || std::size_t(n) >= ui.mainSearchItems.size())
            return;
        item = ui.mainSearchItems[std::size_t(n)];
        if (item.colorSlot < 0 || item.colorCount < 1 || item.colorCount > 3 || !item.enabled)
            return;
        anchor = ui.mainSearchColorAnchor;
        active = true;
        opacity.Snap(0);
        opacity.Tick(1, 0);
        cached.clear();
        picker.Reset(item.colorCount > 1 ? 5 : 4, false, item.colorCount > 1);
        picker.languages = languages;
        std::array<std::string, 3> labels{};
        for (int i = 0; i < item.colorCount; ++i) {
            const int slot = item.colorSlot + i;
            const unsigned scratch = unsigned(item.colorCount > 1 ? 5 + i : 4);
            if (item.source == MainSearchSource::WorldESP && slot >= 0 &&
                std::size_t(slot) < WorldESPColorSpecs.size()) {
                labels[std::size_t(i)] = WorldESPColorSpecs[std::size_t(slot)].key;
                if (WorldESPColorSpecs[std::size_t(slot)].alphaLocked)
                    picker.alphaLockMask |= 1u << scratch;
            } else if (item.source == MainSearchSource::Ambience && slot >= 0 &&
                       std::size_t(slot) < AmbienceColorSpecs.size()) {
                labels[std::size_t(i)] = AmbienceColorSpecs[std::size_t(slot)].label;
                if (!AmbienceColorSpecs[std::size_t(slot)].alpha)
                    picker.alphaLockMask |= 1u << scratch;
            }
        }
        picker.ConfigureEntries(item.colorCount, labels);
        auto proxy = Proxy(cfg);
        picker.Sync(proxy);
    }
    void Close() {
        if (active)
            opacity.Tick(0, 0);
        active = false;
        picker.held = picker.field = -1;
        picker.formatsOpen = picker.headerOpen = false;
    }
    void Tick(float dt) {
        opacity.Tick(active ? 1.f : 0.f, dt);
        if (!active && opacity.value <= .001f)
            cached.clear();
    }
    Settings Proxy(const Settings& cfg) const {
        Settings proxy = cfg;
        for (int i = 0; i < item.colorCount; ++i)
            proxy.worldHud.colors[std::size_t(item.colorCount > 1 ? 5 + i : 4)] =
                PresetsUI::MainSearchColor(cfg, item, i);
        return proxy;
    }
    void Apply(Settings& cfg, const Settings& proxy) const {
        for (int i = 0; i < item.colorCount; ++i)
            PresetsUI::MainSearchSetColor(cfg, item, i,
                proxy.worldHud.colors[std::size_t(item.colorCount > 1 ? 5 + i : 4)]);
    }
    bool Click(float x, float y, bool down, Settings& cfg) {
        if (!active)
            return false;
        if (down && picker.HitAt(x, y) < 0 && !picker.box.Contains(x, y)) {
            Close();
            return true;
        }
        auto proxy = Proxy(cfg);
        picker.Click(x, y, down, proxy);
        Apply(cfg, proxy);
        return true;
    }
    void Move(float x, float y, Settings& cfg) {
        auto proxy = Proxy(cfg);
        picker.Move(x, y, proxy);
        Apply(cfg, proxy);
    }
    bool Key(int key, Settings& cfg, bool ctrl) {
        auto proxy = Proxy(cfg);
        bool consumed = picker.Key(key, proxy, ctrl);
        Apply(cfg, proxy);
        return consumed;
    }
    void Draw(PresetsUI& ui, Fonts& fonts, const Settings& cfg, int width, int height) {
        if (!active) {
            for (auto layer : cached) {
                const float alpha = opacity.value * ui.mainSearchOpacity.value;
                layer.opacity *= alpha;
                for (auto& draw : layer.draw) {
                    draw.color.a *= alpha;
                    draw.shadowColor.a *= alpha;
                    draw.backdropOpacity *= alpha;
                }
                ui.layers.push_back(std::move(layer));
            }
            return;
        }
        const float s = cfg.scale;
        picker.SetMetrics(fonts, s);
        Box b = PresetPopupFit({anchor.x + anchor.w + 7 * s, anchor.y, 265 * s, picker.Height(s)},
                               width, height);
        if (b.x < anchor.x + anchor.w && anchor.x - 265 * s - 7 * s >= 0)
            b.x = anchor.x - 265 * s - 7 * s;
        const auto begin = ui.layers.size();
        auto pal = CurrentPalette(cfg);
        ui.layers.push_back({b, 10 * s, true, {}});
        auto z = int(ui.layers.size() - 1);
        ui.layers[z].draw.push_back({b, pal[8], 10 * s});
        ui.layers[z].draw.push_back({b, pal[11], 10 * s, s});
        auto proxy = Proxy(cfg);
        picker.Draw(ui, z, fonts, proxy, b);
        picker.DrawMenus(ui, fonts, proxy, width, height);
        cached.assign(ui.layers.begin() + std::ptrdiff_t(begin), ui.layers.end());
        for (std::size_t i = begin; i < ui.layers.size(); ++i) {
            const float alpha = opacity.value * ui.mainSearchOpacity.value;
            ui.layers[i].opacity *= alpha;
            for (auto& draw : ui.layers[i].draw) {
                draw.color.a *= alpha;
                draw.shadowColor.a *= alpha;
                draw.backdropOpacity *= alpha;
            }
        }
    }
};
}
