#pragma once

struct WorldHudSpec {
    const char* id;
    const char* key;
    WorldKind kind;
    float minimum, maximum, initial;
    int parent, page, section;
};
inline constexpr std::array<WorldHudSpec, 36> WorldHudSpecs{{
    {"radar", "visuals_world_hud_radar", WorldKind::Multi, 0, 15, 0, -1, -1, 0},
    {"scope", "visuals_world_hud_scopeoptions_scopeoverlay", WorldKind::Choice, 0, 2, 0, -1, -1, 0},
    {"selection", "visuals_world_hud_scopeoptions_scopeoverlay_selection", WorldKind::Multi, 0, 15, 15, -1, 0,
     0},
    {"rotation", "visuals_world_hud_scopeoptions_scopeoverlay_rotation", WorldKind::Choice, 0, 1, 0, -1, 0,
     0},
    {"offset", "visuals_world_hud_scopeoptions_scopeoverlay_offset", WorldKind::Integer, 0, 100, 8, -1, 0, 1},
    {"size", "visuals_world_hud_scopeoptions_scopeoverlay_size", WorldKind::Integer, 0, 100, 30, -1, 0, 1},
    {"aspect", "visuals_world_hud_scopeoptions_scopeoverlay_aspectratio", WorldKind::Integer, 0, 100, 0, -1,
     0, 1},
    {"spread", "visuals_world_hud_scopeoptions_scopeoverlay_spreadscale", WorldKind::Integer, 24, 100, 24, -1,
     0, 1},
    {"glow", "visuals_world_hud_scopeoptions_scopeoverlay_glow", WorldKind::Check, 0, 1, 0, -1, 0, 2},
    {"inaccuracy", "visuals_world_hud_inaccuracyoverlay", WorldKind::Check, 0, 1, 0, -1, -1, 0},
    {"follow", "visuals_world_hud_inaccuracyoverlay_followrecoil", WorldKind::Check, 0, 1, 0, 9, 1, 0},
    {"only_scope", "visuals_world_hud_inaccuracyoverlay_onlyinscope", WorldKind::Check, 0, 1, 0, 9, 1, 0},
    {"invert", "visuals_world_hud_inaccuracyoverlay_invertfade", WorldKind::Check, 0, 1, 0, 9, 1, 0},
    {"fade", "visuals_world_hud_inaccuracyoverlay_fadeoffset", WorldKind::Integer, 5, 100, 45, 9, 1, 0},
    {"preserve", "visuals_world_hud_deathnotices_preservenotices", WorldKind::Choice, 0, 2, 0, -1, 2, 0},
    {"hide_assists", "visuals_world_hud_deathnotices_hideteammatesassists", WorldKind::Check, 0, 1, 0, -1, 2,
     0},
    {"opacity", "visuals_world_hud_scoreboard_appearance_opacity", WorldKind::Integer, 0, 100, 88, -1, 3, 0},
    {"width", "visuals_world_hud_scoreboard_appearance_width", WorldKind::Integer, 100, 175, 100, -1, 3, 0},
    {"money", "visuals_world_hud_scoreboard_revealmoney", WorldKind::Check, 0, 1, 0, -1, 3, 1},
    {"ranks", "visuals_world_hud_scoreboard_revealranks", WorldKind::Check, 0, 1, 0, -1, 3, 1},
    {"equipment", "visuals_world_hud_scoreboard_equipment", WorldKind::Choice, 0, 2, 0, -1, 3, 1},
    {"primary", "visuals_world_hud_scoreboard_equipment_primary", WorldKind::Check, 0, 1, 1, -1, 3, 2},
    {"secondary", "visuals_world_hud_scoreboard_equipment_secondary", WorldKind::Check, 0, 1, 1, -1, 3, 2},
    {"knife", "visuals_world_hud_scoreboard_equipment_knife", WorldKind::Check, 0, 1, 0, -1, 3, 2},
    {"taser", "visuals_world_hud_scoreboard_equipment_taser", WorldKind::Check, 0, 1, 0, -1, 3, 2},
    {"grenades", "visuals_world_hud_scoreboard_equipment_grenades", WorldKind::Check, 0, 1, 0, -1, 3, 2},
    {"bomb", "visuals_world_hud_scoreboard_equipment_bomb", WorldKind::Check, 0, 1, 0, -1, 3, 2},
    {"defusekit", "visuals_world_hud_scoreboard_equipment_defusekit", WorldKind::Check, 0, 1, 0, -1, 3, 2},
    {"armor", "visuals_world_hud_scoreboard_equipment_armor", WorldKind::Check, 0, 1, 0, -1, 3, 2},
    {"other", "visuals_world_hud_scoreboard_equipment_other", WorldKind::Check, 0, 1, 0, -1, 3, 2},
    {"forcesnipercrosshair", "visuals_world_hud_crosshairs_forcesnipercrosshair", WorldKind::Check, 0, 1, 0,
     -1, 4, 0},
    {"forcewhilescoped", "visuals_world_hud_crosshairs_forcewhilescoped", WorldKind::Check, 0, 1, 0, -1, 4,
     0},
    {"forcewhileholdingc4", "visuals_world_hud_crosshairs_forcewhileholdingc4", WorldKind::Check, 0, 1, 0, -1,
     4, 0},
    {"hidewhileholdingknife", "visuals_world_hud_crosshairs_hidewhileholdingknife", WorldKind::Check, 0, 1, 0,
     -1, 4, 0},
    {"hidewhileholdinggrenade", "visuals_world_hud_crosshairs_hidewhileholdinggrenade", WorldKind::Check, 0,
     1, 0, -1, 4, 0},
    {"penetration", "visuals_world_hud_crosshairs_penetration", WorldKind::Check, 0, 1, 0, -1, 4, 1},
}};
struct WorldHudValues {
    std::array<float, WorldHudSpecs.size()> value{};
    int scopeColorMode = 0;
    std::array<Color, 8> colors{{{0, 0, 0, 1},
                                 {70.f / 255, 70.f / 255, 90.f / 255, 170.f / 255},
                                 {45.f / 255, 100.f / 255, 220.f / 255, 1},
                                 {65.f / 255, 55.f / 255, 60.f / 255, 1},
                                 {0, 0, 0, 120.f / 255},
                                 {1, 0, 0, 1},
                                 {0, 1, 0, 1},
                                 {0, 128.f / 255, 1, 1}}};
    std::array<bool, 3> penetrationColorEnabled{{true, true, true}};
    WorldHudValues() {
        for (std::size_t i = 0; i < value.size(); ++i)
            value[i] = WorldHudSpecs[i].initial;
    }
    void Set(std::size_t i, float v) {
        if (i >= value.size() || !std::isfinite(v))
            return;
        const auto& d = WorldHudSpecs[i];
        value[i] = std::round(std::clamp(v, d.minimum, d.maximum));
    }
};
