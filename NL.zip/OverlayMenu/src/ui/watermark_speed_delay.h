#pragma once
#include "watermark_kd_schema.h"
#include <algorithm>
#include <limits>
namespace menu {

struct WatermarkSpeedPeak {
    static constexpr std::int64_t WindowNs = 3001000000LL;
    std::int64_t stamp = 0;
    int peak = 0;
    void Reset() {
        stamp = 0;
        peak = 0;
    }
    std::optional<float> Sample(std::optional<float> speed, std::int64_t now) {
        if (!speed || !std::isfinite(*speed) || *speed < 0 ||
            double(*speed) >= double(std::numeric_limits<int>::max())) {
            peak = 0;
            return {};
        }
        int current = int(*speed);
        if (now < stamp || now - stamp >= WindowNs) {
            stamp = now;
            peak = current;
        } else
            peak = std::max(peak, current);
        return float(peak);
    }
};
inline std::optional<float> WatermarkHorizontalSpeed(float x, float y) {
    float value = std::sqrt(x * x + y * y);
    if (!std::isfinite(value) || double(value) >= double(std::numeric_limits<int>::max()))
        return {};
    return float(int(value));
}

struct WatermarkDelayMotion {
    float value = 0, target = 0, from = 0, elapsed = 0;
    void Reset() {
        value = target = from = elapsed = 0;
    }
    std::optional<float> Tick(std::optional<float> raw, float dt) {
        if (!raw || !std::isfinite(*raw) || *raw < 0) {
            Reset();
            return {};
        }
        if (!std::isfinite(dt) || dt < 0)
            dt = 0;
        if (*raw != target) {
            target = *raw;
            from = value;
            elapsed = 0;
        } else if (std::abs(value - target) <= std::numeric_limits<float>::epsilon()) {
            value = target;
            elapsed = 0;
        } else {
            elapsed += dt;
            float t = std::clamp(elapsed / .2f, 0.f, 1.f);
            value = from + (target - from) * (1 - (1 - t) * (1 - t) * (1 - t));
            if (t >= 1) {
                value = target;
                elapsed = 0;
            }
        }
        return value;
    }
};
inline std::optional<float> WatermarkLatencyMilliseconds(float seconds) {

    float ms = (std::isfinite(seconds) ? std::max(0.f, seconds) : 0.f) * 1000.f;
    if (!std::isfinite(ms) || double(ms) >= double(std::numeric_limits<int>::max()))
        return {};
    return ms;
}
inline std::optional<int> WatermarkDelayInteger(float value) {

    float rounded = std::trunc(value + 0x1.fffffep-2f);
    if (!std::isfinite(rounded) || rounded < 0 || double(rounded) >= double(std::numeric_limits<int>::max()))
        return {};
    return int(rounded);
}

template <class Reader>
std::optional<std::uintptr_t> WatermarkPawn(Reader&& read, std::uintptr_t global, std::uint32_t handle) {
    if (!global || !handle || handle == 0xFFFFFFFFu || handle == 0xFFFFFFFEu)
        return {};
    auto index = handle & 0x7FFFu;
    std::uintptr_t root = 0, page = 0, pawn = 0, current = 0;
    if (!index || !read(global, root) || !root || !read(root + 0x10 + 8 * (index >> 9), page) || !page ||
        !read(page + 0x70 * (index & 511), pawn) || !pawn)
        return {};
    if (!read(global, current) || current != root || !read(root + 0x10 + 8 * (index >> 9), current) ||
        current != page || !read(page + 0x70 * (index & 511), current) || current != pawn)
        return {};
    return pawn;
}

template <class Reader, class Validate, class Query>
std::optional<float> WatermarkReadNetworkDelay(Reader&& read, std::uintptr_t global, Validate&& validate,
                                               Query&& query, const char*& reason) {
    std::uintptr_t client = 0, channel = 0, current = 0;
    float seconds = 0;
    if (!global || !read(global, client) || !client) {
        reason = "hidden (network-client unavailable)";
        return {};
    }
    if (!validate(client)) {
        reason = "unavailable (network-client channel layout not recognized)";
        return {};
    }
    if (!read(client + 0xF0, channel) || !channel) {
        reason = "hidden (channel unavailable)";
        return {};
    }
    if (!query(channel, seconds)) {
        reason = "hidden (channel query failed)";
        return {};
    }
    if (!read(global, current) || current != client || !read(client + 0xF0, current) || current != channel) {
        reason = "hidden (channel changed during sample)";
        return {};
    }
    auto ms = WatermarkLatencyMilliseconds(seconds);
    reason =
        ms ? "available (network channel vslot10, seconds -> ms; UI hides <5ms)" : "hidden (invalid latency)";
    return ms;
}

inline constexpr std::array<int, 36> WatermarkNetworkInGamePattern{
    {0x48, 0x8B, 0x05, -1,   -1,   -1, -1, 0x48, 0x85, 0xC0, 0x74, 0x15, 0x80, 0xB8, -1,   -1,   -1,   -1,
     0,    0x75, 0x0C, 0x83, 0xB8, -1, -1, -1,   -1,   6,    0x7C, 3,    0xB0, 1,    0xC3, 0x32, 0xC0, 0xC3}};
inline bool WatermarkChannelLayout(const unsigned char* code, std::size_t size) {
    static constexpr std::array<int, 4> triples{{0x48, 0x8D, 0x04, 0x40}};
    static constexpr std::array<int, 13> channel{
        {0x48, 0x8D, 0x40, 0x1E, 0x48, 0x83, 0x3C, 0xC1, 0, 0x48, 0x8D, 0x1C, 0xC1}};
    auto a = WatermarkKdMatches(code, size, triples), b = WatermarkKdMatches(code, size, channel);
    return a.size() == 1 && b.size() == 1 && a[0] < b[0] && b[0] - a[0] <= 32;
}
}
