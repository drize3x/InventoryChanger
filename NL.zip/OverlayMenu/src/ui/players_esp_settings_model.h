#pragma once

enum class ESPFieldKind { Toggle, Choice, Multi, Color };
struct ESPField {
    int slot;
    const char* key;
    ESPFieldKind kind;
    std::vector<std::string> options;
    int initial = 0, color = -1;
};
inline bool ESPTextFamily(int i) {
    return i != 0 && i != 3 && i != 4 && i != 5 && i != 22 && i != 23 && i != 24 && i != 25 && i != 26 &&
           i != 28;
}
inline const std::vector<ESPField>& ESPFields(int i) {
    static const auto all = [] {
        std::array<std::vector<ESPField>, 29> a{};
        for (int n = 0; n < 29; ++n) {
            auto& f = a[std::size_t(n)];
            if (ESPTextFamily(n)) {
                f.push_back(
                    {0,
                     "visuals_preview_item_text_font",
                     ESPFieldKind::Choice,
                     {"visuals_preview_item_text_font_default", "visuals_preview_item_text_font_small",
                      "visuals_preview_item_text_font_console", "visuals_preview_item_text_font_bold"},
                     0});
                f.push_back({1,
                             "visuals_preview_item_text_case",
                             ESPFieldKind::Choice,
                             {"visuals_preview_item_text_case_default",
                              "visuals_preview_item_text_case_upper", "visuals_preview_item_text_case_lower"},
                             0});
            }
            if (n == 1)
                f.push_back({2, "visuals_preview_item_name_avatar", ESPFieldKind::Toggle, {}, 0});
            if (n == 3 || n == 4 || n == 23) {
                f.push_back({3, "visuals_preview_item_bar_background", ESPFieldKind::Toggle, {}, 1, 3});
                f.push_back({4, "visuals_preview_item_bar_shadow", ESPFieldKind::Toggle, {}, 0, 4});
                f.push_back(
                    {5,
                     "visuals_preview_item_bar_format",
                     ESPFieldKind::Choice,
                     {"visuals_preview_item_bar_format_hidden", "visuals_preview_item_bar_format_absolute",
                      "visuals_preview_item_bar_format_percentage"},
                     1});
            }
            if (n == 3) {
                f.push_back(
                    {6,
                     "visuals_preview_health_expected_damage",
                     ESPFieldKind::Multi,
                     {"visuals_preview_health_damage_he", "visuals_preview_health_damage_bombs",
                      "visuals_preview_health_damage_molotovs", "visuals_preview_health_damage_infernos"},
                     15});
                f.push_back(
                    {7,
                     "visuals_preview_health_damage_pulse",
                     ESPFieldKind::Choice,
                     {"visuals_preview_health_damage_inherit", "visuals_preview_health_damage_custom"},
                     0});
            }
            if (n == 22 || n == 24 || n == 25 || n == 26)
                f.push_back({8, "visuals_preview_item_icon_inverted", ESPFieldKind::Toggle, {}, 0});
            if (n == 22) {

                f.push_back({15,
                             "visuals_preview_item_icon_selection",
                             ESPFieldKind::Multi,
                             {"visuals_preview_item_icon_selection_weapon",
                              "visuals_preview_item_icon_selection_grenades"},
                             1});
                f.push_back({9,
                             "visuals_preview_item_icon_dimming",
                             ESPFieldKind::Multi,
                             {"visuals_preview_item_icon_dimming_ondeploy",
                              "visuals_preview_item_icon_dimming_onreload",
                              "visuals_preview_item_icon_dimming_onemptyclip"},
                             6});
                f.push_back({10, "visuals_preview_item_icon_ammocliprect", ESPFieldKind::Toggle, {}, 0});
                f.push_back(
                    {11, "visuals_preview_item_icon_shownumbersonlowammo", ESPFieldKind::Toggle, {}, 0});
                f.push_back({12, "visuals_preview_item_icon_showallgrenades", ESPFieldKind::Toggle, {}, 1});
                f.push_back({13, "visuals_preview_item_icon_pinpulled", ESPFieldKind::Color, {}, 0, 5});
            }
            if (n == 26)
                f.push_back({14, "visuals_preview_item_taser_inhandscolor", ESPFieldKind::Color, {}, 0, 5});
        }
        return a;
    }();
    static const std::vector<ESPField> empty;
    return i >= 0 && i < 29 ? all[std::size_t(i)] : empty;
}
inline const ESPField* ESPFindField(int item, int slot) {
    for (const auto& f : ESPFields(item))
        if (f.slot == slot)
            return &f;
    return nullptr;
}
struct ESPItemValues {
    std::array<int, 16> value{};

    std::array<Color, 13> colors{};
    int colorMode = 0;

    int sizeStep = 0;
};
inline int ESPSizeStep(const ESPItemValues& v, float hostScale, bool universal, int globalIndex = 0) {
    return universal ? (globalIndex > 0 ? std::clamp(globalIndex, 1, 5) - 1
                                        : std::clamp(int((hostScale - 1) * 4), 0, 4))
                     : std::clamp(v.sizeStep, 0, 4);
}
inline ESPItemValues ESPInitial(int i) {
    ESPItemValues v;
    for (auto& c : v.colors)
        c = {1, 1, 1, 200.f / 255};
    for (const auto& f : ESPFields(i))
        v.value[std::size_t(f.slot)] = f.initial;
    const Color white{1, 1, 1, 210.f / 255}, pink{1, 50.f / 255, 80.f / 255, 210.f / 255},
        orange{1, 180.f / 255, 50.f / 255, 210.f / 255};
    v.colors[3] = {0, 0, 0, 200.f / 255};
    v.colors[4] = v.colors[3];
    v.colors[5] = i == 22 ? Color{1, 0, 0, 1} : pink;
    v.colors[6] = v.colors[7] = {1, 0, 0, 1};
    v.colors[8] = pink;
    v.colors[9] = orange;
    v.colors[10] = white;
    if (i == 1 || i == 2 || i == 5 || i == 6 || i == 7 || i == 21 || i == 22 || i == 24 || i == 25 ||
        i == 26 || i == 28)
        v.colors[0] = white;
    if (i == 2 || (i >= 6 && i <= 20) || i == 21) {
        v.value[0] = 1;
        v.value[1] = i == 18 ? 0 : 1;
    }
    if (i >= 8 && i <= 11)
        v.colors[0] = {160.f / 255, 200.f / 255, 1, 210.f / 255};
    if (i == 12 || (i >= 13 && i <= 17) || i == 20)
        v.colors[0] = pink;
    if (i == 18)
        v.colors[0] = {145.f / 255, 240.f / 255, 145.f / 255, 210.f / 255};
    if (i == 19)
        v.colors[0] = orange;
    if (i == 4 || i == 23)
        v.colors[0] = {145.f / 255, 170.f / 255, 1, 230.f / 255};
    if (i == 3) {
        v.colors[6] = {1, 128.f / 255, 0, 160.f / 255};
        v.colors[0] = {1, 70.f / 255, 100.f / 255, 200.f / 255};
        v.colors[1] = {100.f / 255, 1, 100.f / 255, 200.f / 255};
        v.colors[10] = v.colors[1];
        v.colors[11] = {1, 70.f / 255, 100.f / 255, 1};
        v.colors[12] = {100.f / 255, 1, 100.f / 255, 1};
    }
    if (i == 28)
        v.colors[1] = pink;
    return v;
}
inline int ESPColorModes(int item) {
    return item == 3 ? 3 : (item == 6 || item == 12 || item == 20) ? 2 : 1;
}
inline int ESPPointCount(int item, int mode) {
    return item == 20 && mode == 1                                                              ? 3
           : ((item == 6 || item == 12) && mode == 1) || (item == 3 && mode != 1) || item == 28 ? 2
                                                                                                : 1;
}
inline int ESPPointColorIndex(int item, int mode, int point) {
    if (item == 3)
        return mode == 1 ? 10 : mode == 2 ? 11 + point : point;
    if ((item == 6 || item == 12 || item == 20) && mode == 1)
        return 8 + point;
    return point;
}

inline bool ESPFieldEnabled(int item, int slot, const ESPItemValues& v) {
    if (item != 22)
        return true;
    if (slot == 9 || slot == 10 || slot == 11)
        return (v.value[15] & 1) != 0;
    if (slot == 12)
        return (v.value[15] & 1) != 0 && (v.value[15] & 2) == 0;
    return true;
}

inline char32_t ESPFieldIcon(int slot) {
    switch (slot) {
    case 0:
        return 0xf031;
    case 1:
        return 0xf866;
    case 2:
        return 0xe2df;
    case 3:
        return 0xe237;
    case 4:
        return 0xe1c0;
    case 5:
        return 0xe1bd;
    case 6:
        return 0xf7a9;
    case 8:
        return 0xe664;
    case 9:
        return 0xe0ca;
    case 10:
        return 0xf0c4;
    case 11:
        return 0xf162;
    case 12:
        return 0xf857;
    case 13:
        return 0xf8c8;
    case 14:
        return 0xe1a7;
    case 15:
        return 0xf550;
    default:
        return 0;
    }
}
