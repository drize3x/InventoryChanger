#pragma once

#include "menu_core.h"
#include "dt_bullet_svg.h"
#include "svg_raster.h"
namespace menu {
struct DTDemoIndicator {
    float alpha = 0, charge = 0, phase = 0, from = 0, demoTime = 0;
    bool last = false;
    void Tick(float elapsed, const Settings& cfg, bool ready = true) {
        const bool enabled = ready && cfg.rage.Get(DoubleTap) != 0 && cfg.worldMisc.value[81] != 0;
        const float dt = std::isfinite(elapsed) ? std::clamp(elapsed, 0.f, .1f) : 0.f;
        if (enabled != last) {
            from = alpha;
            phase = 0;
            last = enabled;
        }
        phase = std::min(1.f, phase + dt / .2f);
        float eased = 1.f - (1.f - phase) * (1.f - phase) * (1.f - phase);
        alpha = from + ((enabled ? 1.f : 0.f) - from) * eased;
        if (enabled) {
            demoTime = std::fmod(demoTime + dt, 2.5f);
            charge = std::min(1.f, demoTime / 1.25f);
        } else {
            demoTime = 0;
            charge = 0;
        }
    }
};
struct DTDemoPaint {
    Box box{};
    float scale = 1, alpha = 0, progress = 0, iconSize = 0, textWidth = 0, textHeight = 0, ringSize = 0;
};
inline DTDemoPaint MeasureDTDemo(Fonts& f, const Settings& cfg, const DTDemoIndicator& ui, int w, int h) {
    DTDemoPaint p;
    p.scale = ScreenWindowScale(cfg);
    p.alpha = ui.alpha;
    p.progress = ui.charge;
    if (w <= 0 || h <= 0 || p.alpha <= 0)
        return p;
    const float s = p.scale, px = 24 * s;
    p.textHeight = f.PixelHeight(9, px);
    p.textWidth = std::trunc(f.NativeTextSize(9, px, U"DT").w + .95f);
    const auto& cap = f.Get(9, px, U'A');
    p.iconSize = std::round(1.35f * cap.h);
    p.ringSize = 19.75f * s;
    const float gap = 5 * s, pad = 10 * s,
                bw = std::min(float(w), 2 * pad + p.iconSize + p.textWidth + p.ringSize + 2 * gap);
    const float bh = std::min(float(h), std::max({p.iconSize, p.textHeight, p.ringSize}) + 6 * s);

    p.box = {std::clamp(18.f * s, 0.f, std::max(0.f, float(w) - bw)),
             std::clamp(.6f * float(h), 0.f, std::max(0.f, float(h) - bh)), bw, bh};
    return p;
}
inline void DrawDTDemoInk(Canvas& canvas, Fonts& f, const Settings& cfg, const DTDemoPaint& p, float ox = 0,
                          float oy = 0, bool drawCircle = true) {
    if (p.box.w <= 0 || p.box.h <= 0)
        return;
    const float s = p.scale;
    const auto& b = p.box;
    auto pal = CurrentPalette(cfg);
    auto fg = pal[31];
    fg.a *= p.alpha;
    const float ix = b.x + 10 * s, iy = b.y + (b.h - p.iconSize) * .5f;

    if (p.iconSize > 0) {
        const int n = std::clamp(int(std::ceil(p.iconSize)), 1, 256);
        static std::map<int, svg::Bitmap> cache;
        auto it = cache.find(n);
        if (it == cache.end()) {
            svg::Bitmap bmp;
            svg::Render(DTBulletSvg, n, n, bmp);
            it = cache.emplace(n, std::move(bmp)).first;
        }
        const auto& bmp = it->second;
        if (bmp.width == n && bmp.height == n) {
            const int x0 = int(std::floor(ix - ox)), y0 = int(std::floor(iy - oy));
            const int x1 = int(std::ceil(ix - ox + p.iconSize)), y1 = int(std::ceil(iy - oy + p.iconSize));
            for (int y = y0; y < y1; ++y)
                for (int x = x0; x < x1; ++x) {
                    const float sx = (x + ox + .5f - ix) * n / p.iconSize - .5f,
                                sy = (y + oy + .5f - iy) * n / p.iconSize - .5f;
                    const int bx = int(std::floor(sx)), by = int(std::floor(sy));
                    float rgba[4] = {};
                    for (int j = 0; j < 2; ++j)
                        for (int i = 0; i < 2; ++i) {
                            int px = bx + i, py = by + j;
                            if (px < 0 || py < 0 || px >= n || py >= n)
                                continue;
                            float weight = (i ? sx - bx : 1 - (sx - bx)) * (j ? sy - by : 1 - (sy - by));
                            for (int ch = 0; ch < 4; ++ch)
                                rgba[ch] += bmp.rgba[4 * (py * n + px) + ch] * weight / 255.f;
                        }
                    if (rgba[3] > .00001f)
                        canvas.Blend(x, y,
                                     {fg.r * rgba[0] / rgba[3], fg.g * rgba[1] / rgba[3],
                                      fg.b * rgba[2] / rgba[3], fg.a * rgba[3]});
                }
        }
    }
    float tx = ix + p.iconSize + 5 * s, ty = b.y + (b.h - p.textHeight) * .5f;
    Box clip{b.x - ox, b.y - oy, b.w, b.h};
    f.NativeText(canvas, 9, 24 * s, U"DT", tx, ty, fg, ox, oy, &clip);
    if (!drawCircle)
        return;
    const float cx = tx + p.textWidth + 5 * s + p.ringSize * .5f - ox, cy = b.y + b.h * .5f - oy,
                radius = (p.ringSize - 5.5f * s) * .5f;
    Color line = pal[31];
    line.a *= p.alpha;
    constexpr float pi = 3.14159265358979323846f;
    const float halfBg = 2.75f * s, halfFg = 1.75f * s;
    int extent = int(std::ceil(radius + halfBg + 1));
    for (int y = int(cy) - extent; y <= int(cy) + extent; ++y)
        for (int x = int(cx) - extent; x <= int(cx) + extent; ++x) {
            float dx = x + .5f - cx, dy = y + .5f - cy, d = std::sqrt(dx * dx + dy * dy),
                  a = std::clamp(halfBg + .5f - std::abs(d - radius), 0.f, 1.f);
            if (a > 0)
                canvas.Blend(x, y, {.0392f, .0392f, .0392f, .502f * p.alpha}, a);
            float angle = std::atan2(-dy, dx);
            float back = std::fmod(pi * .5f - angle + 2 * pi, 2 * pi);
            float aa = std::clamp(halfFg + .5f - std::abs(d - radius), 0.f, 1.f);
            if (back <= 2 * pi * p.progress && aa > 0)
                canvas.Blend(x, y, line, aa);
        }
}
}
