#pragma once
#include "players_esp_settings_ui.h"
#include <cstring>
namespace menu {

struct PlayersMainPreview {
    struct Font {
        int face;
        float px;
    };
    struct Cache {
        std::vector<float> key;
        std::shared_ptr<const Canvas> image;
        std::uint64_t stamp = 0;
    };
    std::array<Cache, 2> bars{};
    double seconds = 0;
    static int Thickness(float s, bool universal) {
        return 2 + (universal ? std::clamp(int((s - 1) * 4), 0, 4) : 0);
    }
    static Font BarFont(int thickness) {
        static constexpr float px[5] = {7, 9, 11, 12, 14};
        int step = std::clamp(thickness - 2, 0, 4);
        return {step ? 5 : 6, px[step]};
    }
    static float Round(float x) {
        return std::trunc(x + std::copysign(.49999997f, x));
    }
    static Color Packed(Color c) {
        return {Canvas::Byte(c.r) / 255.f, Canvas::Byte(c.g) / 255.f, Canvas::Byte(c.b) / 255.f,
                Canvas::Byte(c.a) / 255.f};
    }
    static Box Anchored(Box child, Box b, float s) {
        float cx = std::trunc(child.x + child.w * .5f),
              ay = std::trunc(std::trunc(child.y + child.h * .5f) - 25 * s);
        return {std::trunc(cx + std::trunc(b.x - cx)), std::trunc(ay + std::trunc(b.y - ay)), b.w, b.h};
    }
    static Box BarBox(Box child, Box bbox, int thickness, bool health, float s) {
        return Anchored(child,
                        health ? Box{bbox.x - thickness - 3, bbox.y, float(thickness), Round(bbox.h)}
                               : Box{bbox.x, bbox.y + bbox.h + 3, Round(bbox.w), float(thickness)},
                        s);
    }
    static Box DistanceBox(Box child, Box bbox, float w, float h, float stack, float s) {
        float cx = std::trunc(child.x + child.w * .5f);
        float mx = Round(bbox.x + bbox.w * .5f - cx);
        return Anchored(child, {cx + mx - w * .5f, bbox.y + bbox.h + 2 + stack, w, h}, s);
    }
    static float AmmoStack(int thickness, float fontHeight, bool label) {
        return thickness + 4.f + (label ? Round((fontHeight - thickness - 2) * .5f) : 0.f);
    }
    static std::u32string BarLabel(bool health, int format) {
        return format == 0 ? U"" : format == 2 ? U"50%" : health ? U"50" : U"5";
    }
    static void Text(PresetLayer& layer, Box child, Box b, const std::u32string& label, Color ink, Font f,
                     float s) {
        PresetDraw d{b, Packed(ink), 0, 0, 15, label, false};
        d.font = f.face;
        d.textSize = f.px / s;
        d.espText = true;
        d.clipped = true;
        d.clip = child;
        layer.draw.push_back(std::move(d));
    }

    static float Pulse(double time) {
        float phase = float(std::fmod(std::max(0., time) * 2., 1.));
        float x = phase < .5f ? 2 * phase : 2 * phase - 1, lo = 0, hi = 1;
        for (int k = 0; k < 20; ++k) {
            float t = (lo + hi) * .5f, v = 1.74f * (1 - t) * t * t + t * t * t;
            if (v < x)
                lo = t;
            else
                hi = t;
        }
        float t = (lo + hi) * .5f, y = t * t * (3 - 2 * t);
        return phase < .5f ? y : 1 - y;
    }
    static Color HealthInk(const ESPItemValues& v) {
        return v.colorMode == 1   ? v.colors[10]
               : v.colorMode == 2 ? v.colors[11]
                                  : Mix(v.colors[0], v.colors[1], .5f);
    }
    static Color HealthEnd(const ESPItemValues& v) {
        return v.colorMode == 2 ? Mix(v.colors[11], v.colors[12], .5f) : HealthInk(v);
    }

    static Color DamageStart(const ESPItemValues& v) {
        return v.value[7] == 1 ? v.colors[6] : Mix(HealthInk(v), HealthEnd(v), .5f);
    }
    static Color DamagePeak(const ESPItemValues& v) {
        return v.value[7] == 1 ? v.colors[7] : Color{1, 0, 0, 1};
    }

    const Cache& Raster(int index, Box b, const ESPItemValues& v, float s, int orientation = -1) {
        const bool vertical = orientation < 0 ? index == 0 : orientation != 0;
        const bool health = index == 0;
        const Color low = health ? HealthInk(v) : v.colors[0], end = health ? HealthEnd(v) : low;
        const float pulse = health && v.value[6] ? Pulse(seconds) : 0;
        int pad = 2;
        std::vector<float> key{float(health),
                               b.w,
                               b.h,
                               s,
                               float(vertical),
                               float(v.colorMode),
                               float(v.value[3]),
                               float(health && v.value[6]),
                               float(v.value[7]),
                               pulse,
                               float(pad)};
        for (Color col : {low, end, v.colors[3], v.colors[6], v.colors[7]}) {
            key.push_back(col.r);
            key.push_back(col.g);
            key.push_back(col.b);
            key.push_back(col.a);
        }
        auto& cache = bars[std::size_t(index)];
        if (cache.image && cache.key == key)
            return cache;
        auto image =
            std::make_shared<Canvas>(std::max(1, int(b.w) + 2 * pad), std::max(1, int(b.h) + 2 * pad));
        Box bar{float(pad), float(pad), b.w, b.h};

        if (v.value[3])
            image->RoundRect({bar.x - 1, bar.y - 1, bar.w + 2, bar.h + 2}, 0, Packed(v.colors[3]));
        int length = int(vertical ? b.h : b.w), filled = int(length * .5f);
        for (int n = 0; n < filled; ++n) {
            float t = filled > 1 ? float(n) / float(filled - 1) : 0;
            Color col = Packed(Mix(low, end, t));
            for (int k = 0; k < int(vertical ? b.w : b.h); ++k)
                image->Blend(pad + (vertical ? k : n), pad + (vertical ? length - 1 - n : k), col);
        }
        if (health && v.value[6]) {

            Color base = DamageStart(v), peak = DamagePeak(v);
            Color col = Packed(Mix(base, peak, pulse));
            int from = int(length * .3f), to = int(length * .5f);
            for (int n = from; n < to; ++n)
                for (int k = 0; k < int(vertical ? b.w : b.h); ++k)
                    image->Blend(pad + (vertical ? k : n), pad + (vertical ? length - 1 - n : k), col);
        }

        std::uint64_t hash = 14695981039346656037ull;
        for (float value : key) {
            std::uint32_t bits = 0;
            std::memcpy(&bits, &value, sizeof bits);
            for (int n = 0; n < 4; ++n) {
                hash ^= (bits >> (8 * n)) & 255;
                hash *= 1099511628211ull;
            }
        }
        cache.key = std::move(key);
        cache.image = std::move(image);
        cache.stamp = hash;
        return cache;
    }
    float Bar(PresetLayer& layer, Fonts& fonts, Box child, Box bbox, float s, bool universal, bool health,
              const ESPItemValues& v, int side = -1, int sizeStep = -1) {
        bool vertical = side < 0 ? health : side == 0 || side == 2;
        int thickness = 2 + (sizeStep < 0 ? ESPSizeStep(v, s, universal) : std::clamp(sizeStep, 0, 4));
        auto font = BarFont(thickness);
        Box bar = BarBox(child, bbox, thickness, health, s);
        if (side >= 0) {
            bar.w = vertical ? float(thickness) : Round(bbox.w);
            bar.h = vertical ? Round(bbox.h) : float(thickness);
        }
        const auto& cache = Raster(health ? 0 : 1, bar, v, s, int(vertical));
        int pad = 2;

        if (v.value[4]) {
            PresetDraw shadow{bar, {0, 0, 0, 0}, 0, 0, 15, {}, false};
            shadow.shadowSize = 10 * s;
            shadow.shadowColor = Packed(v.colors[4]);
            shadow.clipped = true;
            shadow.clip = child;
            layer.draw.push_back(std::move(shadow));
        }
        PresetDraw d{{bar.x - pad, bar.y - pad, float(cache.image->width), float(cache.image->height)},
                     {1, 1, 1, 1},
                     0,
                     0,
                     15,
                     {},
                     false};
        d.raster = cache.image;
        d.rasterStamp = cache.stamp;
        d.clipped = true;
        d.clip = child;
        layer.draw.push_back(std::move(d));
        auto label = BarLabel(health, v.value[5]);
        float fh = fonts.PixelHeight(font.face, font.px);
        if (!label.empty()) {
            auto size = fonts.ESPTextSize(font.face, font.px, label);
            float w = std::trunc(size.w + .95f);
            Box b = vertical ? Box{bar.x + thickness - w * .5f - 1,
                                   bar.y + bar.h - std::trunc(bar.h * .5f) - fh * .5f, w, size.h}
                             : Box{bar.x + std::trunc(bar.w * .5f) - w * .5f,
                                   bar.y + std::trunc((thickness - size.h) * .5f), w, size.h};
            b.x = std::trunc(b.x);
            b.y = std::trunc(b.y);
            Text(layer, child, b, label, {1, 1, 1, 1}, font, s);
        }
        return vertical ? thickness + 4.f : AmmoStack(thickness, fh, !label.empty());
    }
};
}
