#pragma once

enum class WorldKind { Check, Integer, Decimal, Choice, Multi };

struct WorldViewSpec {
    const char* id;
    const char* key;
    WorldKind kind;
    float minimum, maximum, initial;
    int parent, page;
};
inline constexpr std::array<WorldViewSpec, 35> WorldViewSpecs{{
    {"view_fov", "visuals_world_view_viewoptions_overridefov", WorldKind::Check, 0, 1, 0, -1, 0},
    {"view_fov_value", "visuals_world_view_viewoptions_overridefov_value", WorldKind::Integer, 30, 135, 90, 0,
     0},
    {"aspect", "visuals_world_view_viewoptions_overrideaspectratio", WorldKind::Check, 0, 1, 0, -1, 0},
    {"aspect_scaling", "visuals_world_view_viewoptions_overrideeaspectratio_scaling", WorldKind::Choice, 0, 1,
     0, 2, 0},
    {"aspect_value", "visuals_world_view_viewoptions_overrideeaspectratio_value", WorldKind::Integer, 20, 250,
     75, 2, 0},
    {"landing", "visuals_world_view_viewoptions_disablelandingbob", WorldKind::Check, 0, 1, 0, -1, 0},
    {"scope_fov", "visuals_world_view_scopeoptions_overridefov", WorldKind::Check, 0, 1, 0, -1, 1},
    {"scope_x1", "visuals_world_view_scopeoptions_overridefov_x1", WorldKind::Integer, 0, 100, 100, 6, 1},
    {"scope_x2", "visuals_world_view_scopeoptions_overridefov_x2", WorldKind::Integer, 0, 100, 100, 6, 1},
    {"instant", "visuals_world_view_scopeoptions_instantscope", WorldKind::Check, 0, 1, 0, -1, 1},
    {"show_vm", "visuals_world_view_scopeoptions_showviewmodel", WorldKind::Check, 0, 1, 1, -1, 1},
    {"force_vm", "visuals_world_view_scopeoptions_forceviewmodelfov", WorldKind::Check, 0, 1, 1, 10, 1},
    {"vm_fov", "visuals_world_view_viewmodeloptions_overridefov", WorldKind::Check, 0, 1, 0, -1, 2},
    {"vm_fov_value", "visuals_world_view_viewmodeloptions_overridefov_value", WorldKind::Integer, 40, 105, 60,
     12, 2},
    {"position", "visuals_world_view_viewmodeloptions_overrideposition", WorldKind::Check, 0, 1, 0, -1, 2},
    {"vm_x", "visuals_world_view_viewmodeloptions_overrideposition_x", WorldKind::Decimal, -30, 30, 0, 14, 2},
    {"vm_y", "visuals_world_view_viewmodeloptions_overrideposition_y", WorldKind::Decimal, -40, 40, 0, 14, 2},
    {"vm_z", "visuals_world_view_viewmodeloptions_overrideposition_z", WorldKind::Decimal, -15, 15, 0, 14, 2},
    {"angles", "visuals_world_view_viewmodeloptions_overrideangles", WorldKind::Check, 0, 1, 0, -1, 2},
    {"vm_pitch", "visuals_world_view_viewmodeloptions_overrideangles_pitch", WorldKind::Decimal, -25, 25, 0,
     18, 2},
    {"vm_yaw", "visuals_world_view_viewmodeloptions_overrideangles_yaw", WorldKind::Decimal, -45, 45, 0, 18,
     2},
    {"vm_roll", "visuals_world_view_viewmodeloptions_overrideangles_roll", WorldKind::Decimal, -45, 45, 0, 18,
     2},
    {"modifiers", "visuals_world_view_viewmodeloptions_overridemodifiers", WorldKind::Check, 0, 1, 0, -1, 2},
    {"bobbing", "visuals_world_view_viewmodeloptions_overridemodifiers_bobbing", WorldKind::Integer, 0, 200,
     100, 22, 2},
    {"rotation", "visuals_world_view_viewmodeloptions_overridemodifiers_rotationsway", WorldKind::Integer, 0,
     200, 100, 22, 2},
    {"velocity", "visuals_world_view_viewmodeloptions_overridemodifiers_velocitysway", WorldKind::Integer, 0,
     200, 100, 22, 2},
    {"air", "visuals_world_view_viewmodeloptions_overridemodifiers_inairoffset", WorldKind::Integer, 0, 100,
     100, 22, 2},
    {"lower", "visuals_world_view_viewmodeloptions_overridemodifiers_lowerweapon", WorldKind::Integer, 0, 200,
     100, 22, 2},
    {"ladder", "visuals_world_view_viewmodeloptions_overridemodifiers_ladderbob", WorldKind::Integer, 0, 200,
     100, 22, 2},
    {"thirdperson", "visuals_world_view_perspectiveoptions_forcethirdperson", WorldKind::Check, 0, 1, 0, -1,
     3},
    {"disablers", "visuals_world_view_perspectiveoptions_forcethirdperson_disablers", WorldKind::Multi, 0, 3,
     1, 29, 3},
    {"distance", "visuals_world_view_perspectiveoptions_forcethirdperson_distance", WorldKind::Integer, 15,
     250, 100, 29, 3},
    {"overhead", "visuals_world_view_perspectiveoptions_disableoverhead", WorldKind::Multi, 0, 3, 0, -1, 3},
    {"spectating", "visuals_world_view_unlockspectating", WorldKind::Multi, 0, 3, 0, -1, 4},
    {"recoil", "visuals_world_view_visualrecoil", WorldKind::Multi, 0, 15, 0, -1, 5},
}};
struct WorldViewValues {
    std::array<float, WorldViewSpecs.size()> value{};
    WorldViewValues() {
        for (std::size_t i = 0; i < value.size(); ++i)
            value[i] = WorldViewSpecs[i].initial;
    }
    void Set(std::size_t i, float v) {
        if (i >= value.size() || !std::isfinite(v))
            return;
        const auto& d = WorldViewSpecs[i];
        v = std::clamp(v, d.minimum, d.maximum);
        value[i] = d.kind == WorldKind::Decimal ? std::round(v * 10) / 10 : std::round(v);
    }
};
