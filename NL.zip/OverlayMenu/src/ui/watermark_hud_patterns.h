#pragma once
#include "watermark_kd_schema.h"
#include <sstream>
#include <cstring>
namespace menu {
namespace hud_patterns {

inline constexpr char HudGlobal[] = "48 89 5C 24 10 48 89 74 24 18 57 48 83 EC 40 48 8B 15 ? ? ? ? 33 FF 48 "
                                    "85 D2 0F 84 ? ? ? ? 48 81 C2 B0 02 00 00";
inline constexpr char BottomCache[] =
    "48 8B 4E 08 48 8D 15 ? ? ? ? 48 89 46 ? 48 8B 01 FF 90 ? ? ? ? 48 85 C0 74 ? 48 8B 10 48 8B C8 FF 52 40 "
    "48 8B 4E 08 48 8D 15 ? ? ? ? 48 89 46 ?";
inline constexpr char Frame[] =
    "48 89 5C 24 10 48 89 6C 24 18 56 57 41 54 41 56 41 57 48 81 EC 80 00 00 00 45 33 F6 48 8B F1 44 89 B1 ? "
    "? ? ? 0F 31 48 C1 E2 20 4C 8D 3D ? ? ? ? 48 0B C2";
inline constexpr char Apply[] =
    "48 89 5C 24 20 44 88 44 24 18 55 56 41 55 41 56 41 57 48 83 EC 20 48 8B 71 ? 4C 8D 3D ? ? ? ? 45 0F B6 "
    "F0 48 8B EA 4C 8B E9 48 85 F6 75 ? 0F B6 42 08 4C 69 C8 ? ? ? ? 4B 8B 84 39 ? ? ? ?";
inline constexpr char PositionSetter[] =
    "4C 8B DC 49 89 5B 08 55 49 8D 6B A9 48 81 EC 90 00 00 00 80 7D 7F 00 48 8B D9 0F B6 05 ? ? ? ? 88 45 E7 "
    "48 8D 05 ? ? ? ? 48 89 45 DF C6 45 E8 00 48 89 55 EF 4C 89 45 F7 4C 89 4D FF 0F 84 ? ? ? ?";
inline constexpr char PositionGetter[] =
    "48 89 5C 24 08 48 89 74 24 10 48 89 7C 24 18 41 56 48 83 EC 70 0F B6 05 ? ? ? ? 49 8B F1 4D 8B F0 48 8B "
    "FA 48 8B D9 3C 40 73 ? 4C 8B 51 10 49 0F A3 C2 73 ? 3C 0C 73 ? 0F B6 54 08 28 48 8B 41 ? 48 03 D2 48 8B "
    "4C D0 08";
inline constexpr char GetStyle[] = "40 53 48 83 EC 20 0F BF 81 ? ? ? ? 48 8B D9 C1 E8 08 A8 01 74 ? 33 D2 E8 "
                                   "? ? ? ? 48 8D 43 ? 48 83 C4 20 5B C3 48 8D 41 ? 48 83 C4 20 5B C3";
inline constexpr char GetHandle[] = "49 8B 80 ? ? ? ? 48 89 02 48 8B C2 C3";
inline constexpr char ResolveHandle[] = "4C 63 0A 4C 8B DA 44 3B 89 ? ? ? ? 73 ? 41 83 F9 FF 74 ? 33 D2 F7 "
                                        "81 ? ? ? ? FF FF FF 7F 44 8B D2 74 ? 4C 8B 91 ? ? ? ?";
}
inline std::vector<int> HudPattern(const char* text) {
    std::vector<int> p;
    std::istringstream in(text);
    std::string token;
    while (in >> token) {
        if (token == "?" || token == "??")
            p.push_back(-1);
        else {
            std::istringstream n(token);
            int v = -1;
            n >> std::hex >> v;
            if (!n || v < 0 || v > 255)
                return {};
            p.push_back(v);
        }
    }
    return p;
}
struct HudScanImage {
    WatermarkKdModule module;
    struct Part {
        std::uintptr_t start = 0;
        std::uint32_t flags = 0;
        std::vector<unsigned char> bytes;
    };
    std::vector<Part> parts;
    bool Contains(std::uintptr_t a, std::size_t n, std::uint32_t required = 0,
                  std::uint32_t forbidden = 0) const {
        for (auto& p : parts)
            if ((p.flags & required) == required && !(p.flags & forbidden) && a >= p.start &&
                a - p.start <= p.bytes.size() && n <= p.bytes.size() - (a - p.start))
                return true;
        return false;
    }
    bool Bytes(std::uintptr_t a, void* out, std::size_t n) const {
        for (auto& p : parts)
            if (a >= p.start && a - p.start <= p.bytes.size() && n <= p.bytes.size() - (a - p.start)) {
                std::memcpy(out, p.bytes.data() + (a - p.start), n);
                return true;
            }
        return false;
    }
    template <class T> bool Read(std::uintptr_t a, T& out) const {
        return Bytes(a, &out, sizeof(out));
    }
    template <class ReadBytes> bool Load(const WatermarkKdModule& m, ReadBytes&& read) {
        module = m;
        parts.clear();
        std::size_t total = 0;
        for (auto s : m.sections) {
            if (!(s.flags & 0x40000000) || !s.size)
                continue;
            if (s.size > 128u * 1024 * 1024 || total + s.size > 256u * 1024 * 1024)
                return false;
            Part p;
            p.start = m.base + s.rva;
            p.flags = s.flags;
            p.bytes.resize(s.size);
            for (std::size_t at = 0; at < s.size;) {
                auto n = std::min<std::size_t>(65536, s.size - at);
                if (!read(p.start + at, p.bytes.data() + at, n))
                    return false;
                at += n;
            }
            total += s.size;
            parts.push_back(std::move(p));
        }
        return !parts.empty();
    }
    std::vector<std::uintptr_t> Find(const std::vector<int>& pattern, bool code = true,
                                     std::size_t limit = 128) const {
        std::vector<std::uintptr_t> hits;
        if (pattern.empty())
            return hits;
        for (auto& part : parts) {
            if (code && !(part.flags & 0x20000000))
                continue;
            if (!code && (part.flags & 0x20000000))
                continue;
            if (part.bytes.size() < pattern.size())
                continue;
            for (std::size_t i = 0; i <= part.bytes.size() - pattern.size(); ++i) {
                if (pattern[0] >= 0 && part.bytes[i] != pattern[0])
                    continue;
                bool match = true;
                for (std::size_t j = 1; j < pattern.size(); ++j)
                    if (pattern[j] >= 0 && part.bytes[i + j] != pattern[j]) {
                        match = false;
                        break;
                    }
                if (match) {
                    hits.push_back(part.start + i);
                    if (hits.size() >= limit)
                        return hits;
                }
            }
        }
        return hits;
    }
    std::vector<std::uintptr_t> Find(const char* pattern, bool code = true, std::size_t limit = 128) const {
        return Find(HudPattern(pattern), code, limit);
    }
    std::uintptr_t Rip(std::uintptr_t a, unsigned displacement = 3, unsigned size = 7) const {
        std::int32_t d = 0;
        if (!Read(a + displacement, d))
            return 0;
        auto t = std::int64_t(a) + size + d;
        return t > 0 ? std::uintptr_t(t) : 0;
    }
    bool Text(std::uintptr_t a, const char* text) const {
        for (std::size_t i = 0; i < 256; ++i) {
            char c = 0;
            if (!Read(a + i, c) || c != text[i])
                return false;
            if (!c)
                return true;
        }
        return false;
    }
    std::vector<std::uintptr_t> Vtables(const char* typeName, std::uint32_t subobjectOffset = 0) const {
        std::vector<int> name;
        for (auto p = typeName;; ++p) {
            name.push_back(static_cast<unsigned char>(*p));
            if (!*p)
                break;
        }
        auto names = Find(name, false);
        std::vector<std::uintptr_t> tables;
        if (names.size() >= 128)
            return tables;

        for (auto n : names) {
            if (n < module.base + 16)
                continue;
            auto td = n - 16;
            for (auto& p : parts) {
                if (p.flags & (0x20000000 | 0x80000000))
                    continue;
                for (std::size_t i = 0; i + 24 <= p.bytes.size(); i += 4) {
                    std::uint32_t v[6]{};
                    std::memcpy(v, p.bytes.data() + i, sizeof(v));
                    auto col = p.start + i;
                    if (v[0] != 1 || v[1] != subobjectOffset || v[2] != 0 ||
                        std::uint64_t(v[3]) != td - module.base || std::uint64_t(v[5]) != col - module.base ||
                        !Contains(module.base + v[4], 16, 0, 0x20000000))
                        continue;
                    for (auto& q : parts) {
                        if (q.flags & (0x20000000 | 0x80000000))
                            continue;
                        for (std::size_t j = 0; j + 16 <= q.bytes.size(); j += 8) {
                            std::uintptr_t x = 0, first = 0;
                            std::memcpy(&x, q.bytes.data() + j, 8);
                            if (x != col)
                                continue;
                            std::memcpy(&first, q.bytes.data() + j + 8, 8);
                            if (Contains(first, 1, 0x20000000))
                                tables.push_back(q.start + j + 8);
                        }
                    }
                }
            }
        }
        std::sort(tables.begin(), tables.end());
        tables.erase(std::unique(tables.begin(), tables.end()), tables.end());
        return tables;
    }
    std::uintptr_t FollowJump(std::uintptr_t fn) const {
        unsigned char op = 0;
        return Read(fn, op) && op == 0xE9 ? Rip(fn, 1, 5) : fn;
    }
    int VirtualMatches(std::uintptr_t vt, std::uintptr_t fn, bool jumps = false) const {
        int matches = 0;
        for (unsigned i = 0; i < 256; ++i) {
            std::uintptr_t f = 0;
            if (!Read(vt + std::uintptr_t(i) * 8, f) || !Contains(f, 1, 0x20000000))
                break;
            if (f == fn || (jumps && FollowJump(f) == fn))
                ++matches;
        }
        return matches;
    }
};
struct HudResolvedBindings {
    std::uintptr_t hudGlobal = 0, frame = 0, apply = 0, getStyle = 0, getHandle = 0, resolveHandle = 0;
    std::uintptr_t engineVtable = 0, panelVtable = 0, styleVtable = 0, positionVtable = 0, positionId = 0,
                   registry = 0;
    std::uint32_t hudBottom = 0, inlineList = 0, computedCount = 0, computedEntries = 0, registryStride = 0;
};
inline bool HudResolveBindings(const HudScanImage& client, const HudScanImage& pano,
                               HudResolvedBindings& result, std::string& diagnostic) {
    result = {};
    HudResolvedBindings b;
    std::ostringstream log;
    auto fail = [&](const char* what) {
        diagnostic = log.str() + "FAIL " + what;
        return false;
    };
    auto unique = [&](const HudScanImage& image, const char* name, const char* pattern,
                      std::uintptr_t& target) {
        auto hits = image.Find(pattern, true, 2);
        log << name << " matches=" << hits.size() << "; ";
        if (hits.size() != 1)
            return false;
        target = hits[0];
        return true;
    };
    if (!unique(client, "hud-global", hud_patterns::HudGlobal, b.hudGlobal))
        return fail("hud-global signature");
    b.hudGlobal = client.Rip(b.hudGlobal + 15);
    if (!client.Contains(b.hudGlobal, 8, 0x80000000, 0x20000000))
        return fail("hud-global RIP target is not writable data");
    auto caches = client.Find(hud_patterns::BottomCache);
    if (caches.size() >= 128)
        return fail("too many cache code matches");
    std::vector<std::uintptr_t> bottom;
    for (auto hit : caches)
        if (client.Text(client.Rip(hit + 4), "HudBottomCenter"))
            bottom.push_back(hit);
    log << "bottom-center-cache matches=" << bottom.size() << "; ";
    if (bottom.size() != 1)
        return fail("BottomCenter string-qualified code pattern");
    std::uint8_t offset = 0;
    if (!client.Read(bottom[0] + 52, offset) || offset < 16 || (offset & 7))
        return fail("BottomCenter cache field");
    b.hudBottom = offset;
    if (!unique(pano, "ui-frame", hud_patterns::Frame, b.frame) ||
        !unique(pano, "style-apply", hud_patterns::Apply, b.apply) ||
        !unique(pano, "get-style", hud_patterns::GetStyle, b.getStyle) ||
        !unique(pano, "panel-handle", hud_patterns::GetHandle, b.getHandle) ||
        !unique(pano, "resolve-panel", hud_patterns::ResolveHandle, b.resolveHandle))
        return fail("native UI function signature");
    std::uintptr_t getter = 0;
    auto setters = pano.Find(hud_patterns::PositionSetter, true, 16);
    log << "position-ABI sources=" << setters.size() << "; ";
    if (setters.empty() || setters.size() >= 16 ||
        !unique(pano, "position-getter", hud_patterns::PositionGetter, getter))
        return fail("position ABI signature");

    b.positionId = pano.Rip(setters[0] + 26);
    b.positionVtable = pano.Rip(setters[0] + 36);
    for (auto candidate : setters)
        if (pano.Rip(candidate + 26) != b.positionId || pano.Rip(candidate + 36) != b.positionVtable)
            return fail("inconsistent Position ABI sources");
    if (b.positionId != pano.Rip(getter + 21) || !pano.Contains(b.positionId, 1, 0x80000000, 0x20000000))
        return fail("position-id cross-check");
    auto choose = [&](const char* name, std::uintptr_t& vt, auto&& accept) {
        auto tables = pano.Vtables(name);
        std::vector<std::uintptr_t> accepted;
        for (auto t : tables)
            if (accept(t))
                accepted.push_back(t);
        log << name << " compatible-vtables=" << accepted.size() << "; ";
        if (accepted.size() != 1)
            return false;
        vt = accepted[0];
        return true;
    };
    if (!choose(".?AVCUIEngineSource2@panorama@@", b.engineVtable, [&](auto t) {
            return pano.VirtualMatches(t, b.frame) == 1 && pano.VirtualMatches(t, b.getHandle) == 1 &&
                   pano.VirtualMatches(t, b.resolveHandle) == 1;
        }))
        return fail("engine RTTI/method cross-check");
    if (!choose(".?AVCUIPanel@panorama@@", b.panelVtable,
                [&](auto t) { return pano.VirtualMatches(t, b.getStyle, true) == 1; }))
        return fail("panel RTTI/GetStyle cross-check");
    if (!choose(".?AVCPanelStyle@panorama@@", b.styleVtable, [&](auto t) {
            if (pano.VirtualMatches(t, getter) != 1)
                return false;
            for (auto setter : setters)
                if (pano.VirtualMatches(t, setter) != 1)
                    return false;
            return true;
        }))
        return fail("style RTTI/position ABI cross-check");
    std::uintptr_t positionTable = 0;
    if (!choose(".?AVCStylePropertyPosition@panorama@@", positionTable,
                [&](auto t) { return t == b.positionVtable; }))
        return fail("Position property RTTI/RIP cross-check");
    std::uint8_t inlineOffset = 0, entriesOffset = 0;
    if (!pano.Read(b.apply + 25, inlineOffset) || !pano.Read(getter + 66, entriesOffset))
        return fail("style layout decode");
    b.inlineList = inlineOffset;
    b.computedEntries = entriesOffset;

    auto countPattern = HudPattern("48 63 4B ? 45 33 C0 85 C9");
    std::vector<unsigned> counts;
    for (unsigned i = 0; i + countPattern.size() <= 256; ++i) {
        bool match = true;
        for (unsigned j = 0; j < countPattern.size(); ++j) {
            std::uint8_t x = 0;
            if (!pano.Read(getter + i + j, x) || (countPattern[j] >= 0 && x != countPattern[j])) {
                match = false;
                break;
            }
        }
        if (match)
            counts.push_back(i);
    }
    std::uint8_t countOffset = 0;
    if (counts.size() != 1 || !pano.Read(getter + counts[0] + 3, countOffset))
        return fail("computed position count layout");
    b.computedCount = countOffset;

    if (b.inlineList != 0x78 || b.computedCount != 0x38 || b.computedEntries != 0x40)
        return fail("unsupported style list ABI");
    std::uint32_t stride = 0, registryOffset = 0;
    if (!pano.Read(b.apply + 55, stride) || !pano.Read(b.apply + 63, registryOffset) || stride != 0x108 ||
        registryOffset != 0x100)
        return fail("property registry ABI");
    b.registry = pano.Rip(b.apply + 26) + registryOffset;
    b.registryStride = stride;
    if (!pano.Contains(b.registry, 8, 0x80000000, 0x20000000))
        return fail("registry RIP target/range");
    log << "resolved by signatures + RIP + RTTI; timestamp is diagnostic only";
    diagnostic = log.str();
    result = b;
    return true;
}
}
