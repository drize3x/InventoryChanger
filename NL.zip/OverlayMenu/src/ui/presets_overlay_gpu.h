#pragma once
#include "presets_cache.h"
#include "renderer_dx11.h"
namespace menu {

class PresetsGPUCache {
    std::array<PresetGlyphLayer, 8> layers;

public:
    void Reset() {
        for (auto& layer : layers)
            layer.Reset();
    }
    void Draw(wm::RendererDX11& renderer, ID3D11Texture2D* scene, ID3D11RenderTargetView* target, int w,
              int h, Fonts& fonts, const Settings& cfg, const PresetsUI& ui, int pass = 0) {
        auto setClip = [&](Box clip) {
            clip = PresetPixelClip(clip);
            renderer.SetClip(clip.x, clip.y, clip.w, clip.h);
        };
        for (std::size_t i = 0; i < ui.layers.size(); ++i) {
            const auto& layer = ui.layers[i];
            if (!PresetLayerInPass(layer, pass))
                continue;
            auto b = layer.box;
            if (layer.popup) {
                renderer.ClearClip();
                if (layer.searchSurface) {
                    auto root = ui.anchor.outer;
                    if (cfg.blur) {
                        renderer.PrepareBackdrop(scene, 5 * cfg.scale, true);
                        renderer.DrawOriginalRect(target, root.x, root.y, root.w, root.h, {1, 1, 1, layer.opacity},
                                                  16 * cfg.scale, 1, 0, true, true);
                    }
                    renderer.DrawOriginalRect(target, root.x, root.y, root.w, root.h, {0, 0, 0, .2f * layer.opacity},
                                              16 * cfg.scale, 1);
                } else
                    renderer.PrepareBackdrop(scene, 5 * cfg.scale, cfg.blur);
                if (layer.shadow) {
                    auto shadow = CurrentPalette(cfg)[38];
                    shadow.a *= layer.opacity;
                    renderer.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {0, 0, 0, 0}, layer.radius, 0, 0,
                                              false, false, 18 * cfg.scale,
                                              {shadow.r, shadow.g, shadow.b, shadow.a});
                }
                if (cfg.blur && !layer.searchSurface)
                    renderer.DrawOriginalRect(target, b.x, b.y, b.w, b.h, {1, 1, 1, layer.opacity},
                                              layer.radius, 1, 0, true, true);
            }
            setClip(b);
            for (const auto& d : layer.draw)
                if (d.text.empty() && !d.raster && !d.pixelLine) {
                    auto clip = d.clipped ? PresetIntersect(b, d.clip) : b;
                    setClip(clip);
                    auto c = d.color;
                    renderer.DrawOriginalRect(target, d.box.x, d.box.y, d.box.w, d.box.h,
                                              {c.r, c.g, c.b, c.a}, d.radius, 0, d.stroke, false, false, 0,
                                              {}, d.corners);
                }
            setClip(b);
            PresetGlyphLayer fallback;
            auto& cache = i < layers.size() ? layers[i] : fallback;
            const bool upload = cache.Update(fonts, cfg, layer);
            const int slot = i < layers.size() ? 10 + int(i) : 18;
            renderer.DrawLayer(target, w, h, cache.glyphs->rgba.data(), cache.glyphs->width,
                               cache.glyphs->height, b.x, b.y, float(cache.glyphs->width), 0, slot, upload);
            renderer.ClearClip();
        }
        for (std::size_t i = ui.layers.size(); i < layers.size(); ++i)
            layers[i].Reset();
    }
};
}
