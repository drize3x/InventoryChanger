#pragma once
#include "hud_color_picker.h"
#include "group_row_geometry.h"
#include <cstdio>
#include <cstring>
#include <functional>
#include <map>
#include <sstream>
#include "world_tooltip.h"
#include "ambience_image_cache.h"
#include "ambience_sky_catalog.h"
namespace menu {

inline void DrawAmbienceMapImage(Canvas& out, Box rect, float radius, const ProfileImage& image, Color card,
                                 float gray, float imageAlpha = .25f) {
    if (image.width <= 0 || image.height <= 0 ||
        image.rgba.size() < std::size_t(image.width) * std::size_t(image.height) * 4 || rect.w <= 0 ||
        rect.h <= 0)
        return;
    const float scaledH = float(image.height) * rect.w / float(image.width),
                v0 = (scaledH - rect.h) * .5f / scaledH, v1 = 1 - v0;
    auto texel = [&](int x, int y, int c) {
        x = std::clamp(x, 0, image.width - 1);
        y = std::clamp(y, 0, image.height - 1);
        return float(image.rgba[(std::size_t(y) * std::size_t(image.width) + std::size_t(x)) * 4 +
                                std::size_t(c)]) /
               255.f;
    };
    auto sample = [&](float u, float v, float* acc) {
        const float fx = u * float(image.width) - .5f, fy = v * float(image.height) - .5f;
        const int x0 = int(std::floor(fx)), y0 = int(std::floor(fy));
        const float tx = fx - float(x0), ty = fy - float(y0);
        for (int k = 0; k < 4; ++k) {
            const int dx = k & 1, dy = k >> 1;
            const float w = (dx ? tx : 1 - tx) * (dy ? ty : 1 - ty), a = texel(x0 + dx, y0 + dy, 3) * w;
            acc[3] += a;
            for (int c = 0; c < 3; ++c)
                acc[c] += texel(x0 + dx, y0 + dy, c) * a;
        }
    };
    for (int y = 0; y < out.height; ++y)
        for (int x = 0; x < out.width; ++x) {
            const float px = float(x) + .5f, py = float(y) + .5f,
                        coverage = std::clamp(.5f - BoxDistance(rect, radius, px, py), 0.f, 1.f);
            if (coverage <= 0)
                continue;
            float acc[4]{};
            for (int k = 0; k < 4; ++k) {
                const float sx = float(x) + .25f + .5f * float(k & 1),
                            sy = float(y) + .25f + .5f * float(k >> 1);
                sample(std::clamp((sx - rect.x) / rect.w, 0.f, 1.f),
                       v0 + (v1 - v0) * std::clamp((sy - rect.y) / rect.h, 0.f, 1.f), acc);
            }
            float a = acc[3] * .25f;
            if (a <= 0)
                continue;
            float r = acc[0] * .25f / a, g = acc[1] * .25f / a, b = acc[2] * .25f / a;
            const float l = .299f * r + .587f * g + .114f * b,
                        t = std::clamp((px - rect.x) / rect.w, 0.f, 1.f);
            r += (l - r) * gray;
            g += (l - g) * gray;
            b += (l - b) * gray;
            r *= card.r + (1 - card.r) * t;
            g *= card.g + (1 - card.g) * t;
            b *= card.b + (1 - card.b) * t;
            a = std::clamp(a * imageAlpha * t * coverage, 0.f, 1.f);
            auto* q = out.rgba.data() + 4 * (std::size_t(y) * std::size_t(out.width) + std::size_t(x));
            q[0] = Canvas::Byte(r * a);
            q[1] = Canvas::Byte(g * a);
            q[2] = Canvas::Byte(b * a);
            q[3] = Canvas::Byte(a);
        }
}
struct WorldAmbienceUI {
    enum {
        Surface,
        Toggle,
        Slider,
        RowHover,
        Select,
        Option,
        Swatch,
        Details,
        Opener,
        Profile,
        Add,
        CloseButton,
        ProfileToggle,
        ProfileMenu,
        MenuItem,
        Overlay,
        SkyOption,
        SkyRefresh,
        SkyFolder
    };
    enum { MenuCopy, MenuPaste, MenuReset, MenuDelete };
    struct Hit {
        Box box;
        int kind, index = -1, option = -1;
        Box control{};
        int Key() const {
            return (kind == RowHover ? Slider : kind) * 100000 + (index + 2) * 64 + option + 1;
        }
    };
    static constexpr std::size_t N = AmbienceSpecs.size();
    struct Card {
        std::string title;
        std::vector<int> rows;
        int separatorAt = -1;
    };
    struct PopupTransition {
        PresetMotion motion;
        std::vector<PresetLayer> cached;
    };
    struct ContextParent {
        int index;
        Box anchor;
        float scroll;
    };

    struct ColorFrame {
        int slot, count;
        Box anchor;
        HudColorPicker picker;
    };

    struct CardView {
        Box box;
        int key;
        float maximum;
    };
    struct MapImage {
        std::shared_ptr<ProfileImage> image;
        std::uint64_t hash = 0, revision = 0, use = 0;
    };
    struct MapRaster {
        std::shared_ptr<Canvas> image;
        std::uint64_t stamp = 0;
    };

    struct RowMotion {
        PresetMotion fill, ink, enabled, toggle, more;
    };
    PresetsUI paint;
    LanguageCatalog* languages = nullptr;
    HudColorPicker picker;
    std::vector<Hit> hits;
    std::array<Box, N> rows{}, sliders{}, toggles{}, details{}, swatches{};

    std::array<int, N> sliderSurface{};

    std::vector<Box> profileRows, profileToggles, profileMenus;
    Box addRow{}, addButton{};
    std::array<PresetMotion, N> available, checked, sliderTip, fieldVisibility;
    std::map<int, PresetMotion> fills, markers;
    std::map<int, float> markerTargets;
    std::map<int, PopupTransition> transitions;
    std::vector<ContextParent> contextParents;
    std::vector<ColorFrame> colorParents;
    std::vector<CardView> cardViews;
    std::map<int, float> cardScroll;
    std::size_t colorHitBegin = 0, searchLayerStart = 0;
    std::map<int, RowMotion> rowMotion;
    PresetMotion popupFade, tipFade, nameTipFade;
    PresetLayer lastTip{}, lastNameTip{};
    bool tipStored = false, nameTipStored = false;
    bool open = false, visible = false, blocked = false, selectAll = false;
    int context = -1, choice = -1, color = -1, colorCount = 1, held = -1, focus = -1, drag = -1, editing = -1,
        hover = -1, profile = 0, menu = -1;
    float scale = 1, F = 18, mouseX = -1, mouseY = -1, scroll = 0, maxScroll = 0, detailScroll = 0,
          detailMaxScroll = 0, listScroll = 0, listMaxScroll = 0, hoverSeconds = 0;

    Box skyHeader{}, skyViewport{}, skyRefreshBox{}, skyFolderBox{};
    float skyScroll = 0, skyMaxScroll = 0;
    bool skyReveal = true;
    std::function<AmbienceImageResult<ProfileImage>(const std::string&)> skyImageQuery;
    std::function<void()> skyRefresh, skyOpenFolder;
    std::function<std::vector<AmbienceSkyCustomEntry>()> skyCustomQuery;
    std::vector<AmbienceSkyCustomEntry> skyCustom;
    std::map<int, MapImage> skyImages;
    std::map<int, MapRaster> skyRasters;
    static bool IsSkybox(int i) {
        return i == Index("overridesky_skybox");
    }
    std::string numeric;

    std::string currentMap;

    std::function<AmbienceImageResult<ProfileImage>(const std::string&)> mapImageQuery;

    std::function<std::shared_ptr<ProfileImage>(const std::string&)> mapImageLoader;
    std::map<std::string, MapImage> mapImages;
    std::map<int, MapRaster> mapRasters;
    std::uint64_t mapImageClock = 0;

    std::string clipboard, clipboardOut;
    bool hostClipboard = false, pasteRequested = false;
    int pasteTarget = -1;
    static constexpr const char* ClipboardHeader = "MenuStudio.Ambience.Effects 1";
    Box overlay{}, closeBox{}, listBox{}, body{}, contextAnchor{}, contextPopup{}, contextBody{}, choiceBox{},
        colorAnchor{}, colorPopup{}, colorBody{}, menuAnchor{}, menuBox{};
    WorldAmbienceUI() {
        popupFade.Snap(0);
        tipFade.Snap(0);
        nameTipFade.Snap(0);
    }

    std::u32string Label(const std::string& k) const {
        if (languages)
            return languages->Label(k);
        auto it = DefaultLanguageStrings().find(k);
        return DecodeUTF8(it == DefaultLanguageStrings().end() ? k : it->second);
    }

    std::u32string RowLabel(int i) const {
        auto t = Label(AmbienceSpecs[std::size_t(i)].key);
        std::u32string r;
        for (char32_t c : t) {
            if (c == U'\n' || c == U'\r')
                c = U' ';
            if (c == U' ' && (r.empty() || r.back() == U' '))
                continue;
            r += c;
        }
        while (!r.empty() && r.back() == U' ')
            r.pop_back();
        return r;
    }
    std::vector<std::u32string> Options(int i) const {
        std::vector<std::u32string> r;
        std::string all = AmbienceSpecs[std::size_t(i)].options, part;
        std::size_t at = 0;
        while (at <= all.size()) {
            auto end = all.find('|', at);
            if (end == std::string::npos)
                end = all.size();
            part = all.substr(at, end - at);
            if (!part.empty())
                r.push_back(Label(std::string(AmbienceSpecs[std::size_t(i)].key) + "_" + part));
            at = end + 1;
        }
        return r;
    }
    static const std::vector<int>& Children(int ctx) {
        static const auto table = [] {
            std::vector<std::vector<int>> t(N + 1);
            for (std::size_t i = 0; i < N; ++i)
                t[std::size_t(AmbienceSpecs[i].parent + 1)].push_back(int(i));
            return t;
        }();
        return table[std::size_t(std::clamp(ctx, -1, int(N) - 1) + 1)];
    }
    static bool HasWindow(int i) {
        return i >= 0 && i < int(N) && !Children(i).empty();
    }

    static bool ColorWindow(int i) {
        return HasWindow(i) && AmbienceSpecs[std::size_t(i)].color >= 0;
    }
    static bool HasDetails(int i) {
        return HasWindow(i) && AmbienceSpecs[std::size_t(i)].kind == AmbienceKind::Switch &&
               AmbienceSpecs[std::size_t(i)].color < 0;
    }
    static int Index(const char* id) {
        return AmbienceIndex(id);
    }

    std::vector<Card> Cards(int ctx) const {
        if (ctx < 0)
            return {{"group_visuals_world_miscellaneous_ambience_effects", Children(-1), -1}};
        std::vector<Card> cards;
        for (int i : Children(ctx)) {
            auto c = std::size_t(std::max(0, AmbienceSpecs[std::size_t(i)].card));
            if (cards.size() <= c)
                cards.resize(c + 1);
            if (AmbienceSpecs[std::size_t(i)].separator)
                cards[c].separatorAt = int(cards[c].rows.size());
            cards[c].rows.push_back(i);
        }
        return cards;
    }

    static const AmbienceProfile& Fallback() {
        static const AmbienceProfile p{};
        return p;
    }
    int ProfileCount(const Settings& cfg) const {
        return int(cfg.worldAmbience.profiles.size());
    }
    int ProfileIndex(const Settings& cfg) const {
        int n = ProfileCount(cfg);
        return n <= 0 ? 0 : std::clamp(profile, 0, n - 1);
    }
    const AmbienceProfile& Values(const Settings& cfg) const {
        return cfg.worldAmbience.profiles.empty()
                   ? Fallback()
                   : cfg.worldAmbience.profiles[std::size_t(ProfileIndex(cfg))];
    }
    AmbienceProfile& Values(Settings& cfg) {
        if (cfg.worldAmbience.profiles.empty())
            cfg.worldAmbience = WorldAmbienceValues{};
        profile = ProfileIndex(cfg);
        return cfg.worldAmbience.profiles[std::size_t(profile)];
    }

    std::u32string MapLabel(const std::string& map) const {
        return !map.empty() && map.front() == '<' ? Label("visuals_world_miscellaneous_ambience_menu")
                                                  : DecodeUTF8(map);
    }
    std::u32string ProfileName(int p, const Settings& cfg) const {
        if (p == 0)
            return Label("visuals_world_miscellaneous_ambience_global");
        return p < ProfileCount(cfg) ? MapLabel(cfg.worldAmbience.profiles[std::size_t(p)].map)
                                     : std::u32string{};
    }

    static std::string MapImageName(const std::string& map) {
        return map.empty() || map.front() == '<' ? std::string("lobby_mapveto") : map;
    }
    const MapImage* FindMapImage(const std::string& map) {
        if (!mapImageLoader && !mapImageQuery)
            return nullptr;
        auto load = [&](const std::string& name) -> const MapImage* {
            auto it = mapImages.find(name);
            if (it != mapImages.end())
                it->second.use = ++mapImageClock;
            AmbienceImageResult<ProfileImage> result;
            if (mapImageQuery) {
                try {
                    result = mapImageQuery(name);
                } catch (...) {
                    result.state = AmbienceImageState::Missing;
                }
                if (it != mapImages.end() && it->second.revision == result.revision &&
                    it->second.image == result.image)
                    return it->second.image ? &it->second : nullptr;
            }
            if (it == mapImages.end() || mapImageQuery) {
                MapImage e;
                e.revision = result.revision;
                e.use = ++mapImageClock;
                if (mapImageQuery)
                    e.image = result.state == AmbienceImageState::Ready ? std::move(result.image) : nullptr;
                else
                    try {
                        e.image = mapImageLoader(name);
                    } catch (...) {
                        e.image.reset();
                    }
                if (e.image &&
                    (e.image->width <= 0 || e.image->height <= 0 || e.image->width > 4096 ||
                     e.image->height > 4096 ||
                     e.image->rgba.size() < std::size_t(e.image->width) * std::size_t(e.image->height) * 4))
                    e.image.reset();
                if (e.image) {
                    std::uint64_t h = 14695981039346656037ull;
                    auto mix = [&](std::uint64_t v) {
                        for (int k = 0; k < 8; ++k) {
                            h ^= (v >> (k * 8)) & 255;
                            h *= 1099511628211ull;
                        }
                    };
                    mix(std::uint64_t(e.image->width));
                    mix(std::uint64_t(e.image->height));
                    for (unsigned char b : e.image->rgba) {
                        h ^= b;
                        h *= 1099511628211ull;
                    }
                    e.hash = h;
                }
                it = mapImages.insert_or_assign(name, std::move(e)).first;

                if (mapImageQuery && mapImages.size() > 80) {
                    auto oldest = mapImages.end();
                    for (auto p = mapImages.begin(); p != mapImages.end(); ++p)
                        if (p != it && (oldest == mapImages.end() || p->second.use < oldest->second.use))
                            oldest = p;
                    if (oldest != mapImages.end())
                        mapImages.erase(oldest);
                }
            }
            return it->second.image ? &it->second : nullptr;
        };
        const auto name = MapImageName(map);
        const MapImage* image = load(name);
        if (!image && name != "lobby_mapveto")
            image = load("lobby_mapveto");
        return image;
    }
    bool CanAdd(const Settings& cfg) const {
        return WorldAmbienceValues::ValidMap(currentMap) && cfg.worldAmbience.Find(currentMap) < 0 &&
               cfg.worldAmbience.profiles.size() < WorldAmbienceValues::MaxProfiles;
    }
    bool ProfileEnabled(int p, const Settings& cfg) const {
        return p >= 0 && p < ProfileCount(cfg) && cfg.worldAmbience.profiles[std::size_t(p)].enabled;
    }

    static std::vector<int> MenuActions(int p) {
        std::vector<int> a{MenuCopy, MenuPaste, -1, MenuReset};
        if (p >= 1)
            a.push_back(MenuDelete);
        return a;
    }
    static const char* MenuKey(int a) {
        return a == MenuCopy    ? "menu_buttons_copy"
               : a == MenuPaste ? "menu_buttons_paste"
               : a == MenuReset ? "menu_buttons_reset"
                                : "menu_buttons_delete";
    }
    static char32_t MenuIcon(int a) {
        return a == MenuCopy ? 0xF0C5 : a == MenuPaste ? 0xF0EA : a == MenuReset ? 0xF2EA : 0xF2ED;
    }

    static std::string ProfileText(const AmbienceProfile& source) {
        WorldAmbienceValues v;
        v.profiles[0].value = source.value;
        v.profiles[0].colors = source.colors;
        v.profiles[0].customSkyMaterial = source.customSkyMaterial;
        std::map<std::string, std::string> keys;
        AmbienceCapture(v, keys);
        std::string out = std::string(ClipboardHeader) + "\n";
        const std::string prefix = "world.ambience.0.";
        for (const auto& kv : keys)
            if (kv.first.rfind(prefix, 0) == 0)
                out += kv.first.substr(prefix.size()) + "=" + kv.second + "\n";
        return out;
    }
    static bool ParseProfileText(const std::string& text, AmbienceProfile& out) {
        std::istringstream in(text);
        std::string line;
        auto trim = [](std::string& l) {
            while (!l.empty() && (l.back() == '\r' || l.back() == ' '))
                l.pop_back();
        };
        if (!std::getline(in, line))
            return false;
        trim(line);
        if (line != ClipboardHeader)
            return false;
        std::map<std::string, std::string> keys{{"world.ambience.profiles", "1"}};
        while (std::getline(in, line)) {
            trim(line);
            if (line.empty())
                continue;
            auto eq = line.find('=');
            if (eq == std::string::npos || eq == 0)
                return false;
            auto key = line.substr(0, eq);
            if (key == "map" || key == "enabled" ||
                (key.find('.') != std::string::npos && key.rfind("color.", 0) != 0))
                return false;
            keys["world.ambience.0." + key] = line.substr(eq + 1);
        }
        WorldAmbienceValues v;
        try {
            AmbienceRead(v, keys);
        } catch (const std::exception&) {
            return false;
        }
        out.value = v.profiles[0].value;
        out.colors = v.profiles[0].colors;
        out.customSkyMaterial = v.profiles[0].customSkyMaterial;
        return true;
    }
    void CopyProfile(int p, const Settings& cfg) {
        if (p < 0 || p >= ProfileCount(cfg))
            return;
        clipboard = ProfileText(cfg.worldAmbience.profiles[std::size_t(p)]);
        clipboardOut = clipboard;
    }
    bool PasteText(const std::string& text, Settings& cfg) {
        int p = pasteTarget;
        pasteTarget = -1;
        pasteRequested = false;
        if (p < 0 || p >= ProfileCount(cfg))
            return false;
        AmbienceProfile parsed;
        if (!ParseProfileText(text, parsed))
            return false;
        auto& t = cfg.worldAmbience.profiles[std::size_t(p)];
        t.value = parsed.value;
        t.colors = parsed.colors;
        t.customSkyMaterial = parsed.customSkyMaterial;
        return true;
    }
    void RequestPaste(int p, Settings& cfg) {
        pasteTarget = p;
        if (hostClipboard)
            pasteRequested = true;
        else
            PasteText(clipboard, cfg);
    }

    void ResetProfile(int p, Settings& cfg) {
        if (p < 0 || p >= ProfileCount(cfg))
            return;
        const AmbienceProfile d;
        auto& t = cfg.worldAmbience.profiles[std::size_t(p)];
        t.value = d.value;
        t.colors = d.colors;
        t.customSkyMaterial.clear();
    }
    void DeleteProfile(int p, Settings& cfg) {
        if (p < 1 || p >= ProfileCount(cfg))
            return;
        cfg.worldAmbience.profiles.erase(cfg.worldAmbience.profiles.begin() + p);
        if (profile == p)
            profile = p - 1;
        else if (profile > p)
            --profile;
        if (pasteTarget == p)
            pasteTarget = -1;
        else if (pasteTarget > p)
            --pasteTarget;
        rowMotion.clear();
    }
    void ToggleProfile(int p, Settings& cfg) {
        if (p < 0 || p >= ProfileCount(cfg))
            return;
        auto& e = cfg.worldAmbience.profiles[std::size_t(p)].enabled;
        e = !e;
    }

    static bool RuleVisible(const AmbienceProfile& v, int i, int depth = 0) {
        const auto& r = AmbienceSpecs[std::size_t(i)].rule;
        if (r.source < 0 || depth > 8)
            return true;
        if (!RuleVisible(v, r.source, depth + 1))
            return false;
        float x = v.value[std::size_t(r.source)];
        int n = int(std::lround(x));
        switch (r.op) {
        case 0:
            return x != 0;
        case 1:
            return x == 0;
        case 2:
            return n == r.arg;
        default:
            return n != r.arg;
        }
    }
    bool Visible(int i, const Settings& cfg) const {
        return i >= 0 && i < int(N) && RuleVisible(Values(cfg), i);
    }

    bool Enabled(int i, const Settings& cfg) const {
        return Visible(i, cfg);
    }
    static bool IsSlider(int i) {
        auto k = AmbienceSpecs[std::size_t(i)].kind;
        return k == AmbienceKind::Integer || k == AmbienceKind::Decimal;
    }
    int KindOf(int i) const {
        switch (AmbienceSpecs[std::size_t(i)].kind) {
        case AmbienceKind::Switch:
        case AmbienceKind::Check:
            return Toggle;
        case AmbienceKind::Choice:
            return Select;
        case AmbienceKind::Opener:
            return Opener;
        default:
            return Slider;
        }
    }

    std::u32string ValueText(int i, const Settings& cfg) const {
        const auto& d = AmbienceSpecs[std::size_t(i)];
        float v = Values(cfg).value[std::size_t(i)];
        if (std::string(d.id) == "weather_wind_direction" && v < 0)
            return Label("visuals_world_miscellaneous_ambience_effects_weather_wind_direction_smooth");
        char b[64]{};
        if (d.kind == AmbienceKind::Decimal)
            std::snprintf(b, sizeof b, *d.format ? d.format : "%.2f", double(v));
        else
            std::snprintf(b, sizeof b, *d.format ? d.format : "%d", int(std::lround(v)));
        return DecodeUTF8(b);
    }
    std::string NumberText(int i, const Settings& cfg) const {
        float v = Values(cfg).value[std::size_t(i)];
        char b[32]{};
        if (AmbienceSpecs[std::size_t(i)].kind == AmbienceKind::Decimal)
            std::snprintf(b, sizeof b,
                          AmbienceStep(std::size_t(i)) < .1f ? "%.2f"
                          : AmbienceStep(std::size_t(i)) < 1 ? "%.1f"
                                                             : "%.0f",
                          double(v));
        else
            std::snprintf(b, sizeof b, "%d", int(std::lround(v)));
        return b;
    }

    bool Active() const {
        return visible && (open || popupFade.value > .001f);
    }
    bool Capturing() const {
        return open && (held >= 0 || drag >= 0 || picker.held >= 0);
    }
    bool Editing() const {
        return open && (editing >= 0 || (color >= 0 && picker.field >= 0));
    }

    bool TransitionActive(int key) const {
        if (!open)
            return false;
        if (key == 3000)
            return menu >= 0;
        if (key >= 2000) {
            if (color == key - 2000)
                return true;
            for (const auto& f : colorParents)
                if (f.slot == key - 2000)
                    return true;
            return false;
        }
        if (key >= 1000)
            return choice == key - 1000;
        if (context == key)
            return true;
        for (const auto& p : contextParents)
            if (p.index == key)
                return true;
        return false;
    }
    void StartTransition(int key) {
        auto& t = transitions[key];
        if (!t.motion.initialized)
            t.motion.Snap(0);
        t.motion.Tick(1, 0);
    }
    void ClearTransient() {
        transitions.clear();
        fills.clear();
        tipStored = nameTipStored = false;
        tipFade.Snap(0);
        nameTipFade.Snap(0);
    }
    void CancelInput() {
        held = drag = -1;
        picker.held = -1;
    }

    void Open() {
        ClearTransient();
        open = true;
        contextParents.clear();
        colorParents.clear();
        cardScroll.clear();
        cardViews.clear();
        context = choice = color = editing = focus = menu = -1;
        numeric.clear();
        scroll = detailScroll = listScroll = 0;
        rowMotion.clear();
        pasteRequested = false;
        pasteTarget = -1;
        popupFade.Snap(0);
        CancelInput();
    }
    void Close(bool animate = true) {
        if (!animate) {
            ClearTransient();
            popupFade.Snap(0);
            paint.layers.clear();
            hits.clear();
            rowMotion.clear();
        }
        open = false;
        contextParents.clear();
        colorParents.clear();
        context = choice = color = editing = focus = menu = -1;
        numeric.clear();
        pasteRequested = false;
        pasteTarget = -1;
        CancelInput();
    }
    void CloseContext() {
        if (context >= 0)
            transitions[context].motion.Tick(0, 0);
        choice = editing = -1;
        CancelInput();
        if (contextParents.empty()) {
            context = -1;
            return;
        }
        auto parent = contextParents.back();
        contextParents.pop_back();
        context = parent.index;
        contextAnchor = parent.anchor;
        detailScroll = parent.scroll;
    }

    void OpenContext(int i, Box at) {
        if (!HasWindow(i))
            return;
        if (context == i) {
            CloseContext();
            return;
        }
        if (context >= 0)
            contextParents.push_back({context, contextAnchor, detailScroll});
        context = i;
        StartTransition(i);
        contextAnchor = at;
        detailScroll = 0;
        for (int n = 0; n < 16; ++n)
            cardScroll.erase(i * 16 + n);
        choice = editing = -1;
        CancelInput();
    }

    void OpenMenu(int p, float x, float y) {
        menu = p;
        menuAnchor = {x + 1, y, 0, 0};
        StartTransition(3000);
        choice = editing = -1;
        numeric.clear();
        CancelInput();
    }
    void CloseMenu() {
        menu = -1;
    }
    int HitAt(float x, float y) const {
        if (!visible || blocked || !open)
            return -1;
        for (int i = int(hits.size()) - 1; i >= 0; --i)
            if (hits[std::size_t(i)].box.Contains(x, y))
                return i;
        return -1;
    }
    float Motion(const Hit& h) const {
        auto it = fills.find(h.Key());
        return it == fills.end() ? 0 : it->second.value;
    }
    float FieldAmount(int i) const {
        return fieldVisibility[std::size_t(i)].initialized ? fieldVisibility[std::size_t(i)].value : 1.f;
    }

    static int ScratchFor(int count, int n) {
        return count > 1 ? 5 + n : 4;
    }
    int Scratch(int n) const {
        return ScratchFor(colorCount, n);
    }
    Settings ColorSettings(const Settings& cfg, int slot, int count) const {
        Settings c = cfg;
        if (slot >= 0) {
            const auto& v = Values(cfg);
            for (int n = 0; n < count; ++n)
                c.worldHud.colors[std::size_t(ScratchFor(count, n))] = v.colors[std::size_t(slot + n)];
        }
        return c;
    }
    Settings ColorSettings(const Settings& cfg) const {
        return ColorSettings(cfg, color, colorCount);
    }
    void SyncColor(Settings& cfg, const Settings& c) {
        if (color < 0)
            return;
        auto& v = Values(cfg);
        for (int n = 0; n < colorCount; ++n)
            v.SetColor(std::size_t(color + n), c.worldHud.colors[std::size_t(Scratch(n))]);
    }

    void OpenColor(int slot, int count, Box at) {
        if (slot < 0 || slot >= int(AmbienceColorSpecs.size()))
            return;
        if (color >= 0) {
            if (color == slot)
                return;
            colorParents.push_back({color, colorCount, colorAnchor, picker});
        }
        choice = editing = -1;
        numeric.clear();
        color = slot;
        colorCount = std::clamp(count, 1, 3);
        StartTransition(2000 + color);
        if (slot == 5) {
            skyReveal = true;
            skyScroll = 0;
        }
        colorAnchor = at;
        picker.Reset(colorCount > 1 ? 5 : 4, false, colorCount > 1);
        if (colorCount > 1) {
            std::array<std::string, 3> labels{};
            for (int n = 0; n < colorCount; ++n)
                labels[std::size_t(n)] = AmbienceColorSpecs[std::size_t(slot + n)].label;
            picker.ConfigureEntries(colorCount, labels);
        }
        for (int n = 0; n < colorCount; ++n)
            if (!AmbienceColorSpecs[std::size_t(slot + n)].alpha)
                picker.alphaLockMask |= 1u << unsigned(Scratch(n));
    }
    void CloseColor() {
        if (color < 0)
            return;
        choice = -1;
        picker.held = picker.field = -1;
        if (colorParents.empty()) {
            color = -1;
            return;
        }
        auto saved = picker.saved;
        auto parent = std::move(colorParents.back());
        colorParents.pop_back();
        color = parent.slot;
        colorCount = parent.count;
        colorAnchor = parent.anchor;
        picker = std::move(parent.picker);
        picker.saved = std::move(saved);
        picker.held = -1;
    }
    void CloseColors() {
        while (color >= 0)
            CloseColor();
    }
    int ColorOwner(int slot) const {
        for (std::size_t i = 0; i < N; ++i) {
            const auto& d = AmbienceSpecs[i];
            if (d.color >= 0 && slot >= d.color && slot < d.color + d.count)
                return int(i);
        }
        return -1;
    }

    static void Exclusive(int i, AmbienceProfile& v) {
        static const int rain = Index("weather_rain"), snow = Index("weather_snow");
        static const int pom2 = Index("ground_snow_pom"), pom40 = Index("ground_snow_pom_40");
        if (i == rain && snow >= 0)
            v.Set(std::size_t(snow), 0);
        if (i == snow && rain >= 0)
            v.Set(std::size_t(rain), 0);
        if (i == pom2 && pom40 >= 0)
            v.Set(std::size_t(pom40), 0);
        if (i == pom40 && pom2 >= 0)
            v.Set(std::size_t(pom2), 0);
    }
    void SyncVisibility(const Settings& cfg, float dt) {
        for (std::size_t i = 0; i < N; ++i)
            fieldVisibility[i].Tick(Visible(int(i), cfg) ? 1.f : 0.f, dt);
        if (choice >= 0 && !Visible(choice, cfg))
            choice = -1;
        if (color >= 0) {
            bool gone = false;
            auto check = [&](int slot) {
                int owner = ColorOwner(slot);
                if (owner >= 0 && !Visible(owner, cfg))
                    gone = true;
            };
            check(color);
            for (const auto& f : colorParents)
                check(f.slot);
            if (gone) {
                CloseColors();
                CancelInput();
            }
        }
        if (editing >= 0 && !Enabled(editing, cfg)) {
            editing = -1;
            numeric.clear();
        }
        if (drag >= 0 && !Enabled(drag, cfg))
            CancelInput();
        while (context >= 0 && !Visible(context, cfg))
            CloseContext();
        if (menu >= ProfileCount(cfg))
            menu = -1;
    }

    int TopSurface() const {
        return color >= 0 ? 1000 + color : context >= 0 ? context : -1;
    }
    Box SurfaceBody() const {
        return color >= 0 ? colorBody : context >= 0 ? contextBody : body;
    }
    static bool RowControl(int kind) {
        return kind == Toggle || kind == Slider || kind == RowHover || kind == Select || kind == Swatch ||
               kind == SkyOption || kind == SkyRefresh || kind == SkyFolder;
    }
    int TipIndex(const Settings& cfg) const {
        if (!open || menu >= 0 || choice >= 0 || editing >= 0 || drag >= 0)
            return -1;
        int n = HitAt(mouseX, mouseY);
        if (n < 0 || (color >= 0 && n < int(colorHitBegin)))
            return -1;
        const auto& h = hits[std::size_t(n)];
        if (h.index < 0 || h.index >= int(N) ||
            (h.kind != Toggle && h.kind != Select && h.kind != Slider && h.kind != RowHover))
            return -1;
        return *AmbienceSpecs[std::size_t(h.index)].tooltip && Visible(h.index, cfg) ? h.index : -1;
    }

    int NameTipIndex() const {
        if (!open || menu >= 0 || color >= 0 || choice >= 0 || editing >= 0 || drag >= 0)
            return -1;
        int n = HitAt(mouseX, mouseY);
        if (n < 0)
            return -1;
        const auto& h = hits[std::size_t(n)];
        return h.kind == ProfileToggle ? h.index : -1;
    }

    bool RowHovered(int p, int top) const {
        if (top < 0 || top >= int(hits.size()))
            return false;
        const auto& h = hits[std::size_t(top)];
        if (p < 0)
            return h.kind == Add;
        return h.index == p && (h.kind == Profile || h.kind == ProfileToggle || h.kind == ProfileMenu);
    }
    bool RowHeld(int p) const {
        return held >= 0 && held == (p < 0 ? Hit{{}, Add, -1, 0} : Hit{{}, Profile, p}).Key();
    }
    RowMotion RowTarget(int p, const Settings& cfg, int top) const {
        const bool hovered = RowHovered(p, top), pressed = RowHeld(p),
                   selected = p >= 0 && p == ProfileIndex(cfg);
        RowMotion t;
        t.fill.target = pressed ? 1.f : hovered ? .5f : 0.f;
        t.ink.target = selected || pressed ? 1.f : hovered ? .5f : 0.f;
        t.enabled.target = p < 0 || ProfileEnabled(p, cfg) ? 1.f : 0.f;
        t.toggle.target = hovered ? 1.f : 0.f;
        t.more.target = p == 0 || hovered || selected ? 1.f : 0.f;
        return t;
    }

    RowMotion& RowState(int p, const Settings& cfg, int top = -1) {
        auto it = rowMotion.find(p);
        if (it == rowMotion.end()) {
            auto t = RowTarget(p, cfg, top);
            RowMotion m;
            m.fill.Snap(t.fill.target);
            m.ink.Snap(t.ink.target);
            m.enabled.Snap(t.enabled.target);
            m.toggle.Snap(t.toggle.target);
            m.more.Snap(t.more.target);
            it = rowMotion.emplace(p, m).first;
        }
        return it->second;
    }
    void TickRows(float dt, const Settings& cfg, int top) {
        for (auto it = rowMotion.begin(); it != rowMotion.end();)
            if (it->first >= ProfileCount(cfg))
                it = rowMotion.erase(it);
            else
                ++it;
        for (int p = -1; p < ProfileCount(cfg); ++p) {
            auto t = RowTarget(p, cfg, top);
            auto& m = RowState(p, cfg, top);
            m.fill.Tick(t.fill.target, dt);
            m.ink.Tick(t.ink.target, dt);
            m.enabled.Tick(t.enabled.target, dt);
            m.toggle.Tick(t.toggle.target, dt);
            m.more.Tick(t.more.target, dt);
        }
    }
    void Tick(float dt, const Settings& cfg) {
        dt = std::max(0.f, dt);
        SyncVisibility(cfg, dt);
        popupFade.Tick(open ? 1.f : 0.f, dt);
        for (auto& e : markers)
            e.second.Tick(markerTargets[e.first], dt);
        for (auto& e : transitions)
            e.second.motion.Tick(TransitionActive(e.first) ? 1.f : 0.f, dt);
        if (!visible)
            return;
        int h = blocked ? -1 : HitAt(mouseX, mouseY), key = h >= 0 ? hits[std::size_t(h)].Key() : -1;
        TickRows(dt, cfg, h);
        if (blocked)
            return;
        for (const auto& t : hits)
            fills.try_emplace(t.Key());
        for (auto& kv : fills)
            kv.second.Tick(kv.first == held ? 1.f : kv.first == key ? .5f : 0.f, dt);
        const auto& v = Values(cfg);
        for (std::size_t i = 0; i < N; ++i) {
            bool enabled = Enabled(int(i), cfg);
            available[i].Tick(enabled ? 1.f : .5f, dt);
            checked[i].Tick(v.value[i] != 0 ? 1.f : 0.f, dt);
            bool over = sliders[i].w > 0 && sliderSurface[i] == TopSurface() &&
                        sliders[i].Contains(mouseX, mouseY) && SurfaceBody().Contains(mouseX, mouseY);
            sliderTip[i].Tick(
                open && menu < 0 && choice < 0 && editing < 0 && enabled && (drag == int(i) || over) ? 1.f
                                                                                                     : 0.f,
                dt);
        }
        if (color >= 0) {
            picker.Tick(dt, choice < 0);
            for (auto& f : colorParents)
                f.picker.Tick(dt, false);
        }
        hoverSeconds += dt;
        tipFade.Tick(TipIndex(cfg) >= 0 && hoverSeconds >= .3f ? 1.f : 0.f, dt);
        nameTipFade.Tick(NameTipIndex() >= 0 && hoverSeconds >= .3f ? 1.f : 0.f, dt);
    }
    void Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        int h = HitAt(x, y), key = h >= 0 ? hits[std::size_t(h)].Key() : -1;
        if (key != hover) {
            hover = key;
            hoverSeconds = 0;
        }
        if (drag >= 0) {
            auto b = sliders[std::size_t(drag)];
            const auto& d = AmbienceSpecs[std::size_t(drag)];
            Values(cfg).Set(std::size_t(drag),
                            d.minimum + (d.maximum - d.minimum) *
                                            std::clamp((x - b.x) / std::max(1.f, b.w - 1), 0.f, 1.f));
        }
        if (color >= 0) {
            auto c = ColorSettings(cfg);
            picker.Move(x, y, c);
            SyncColor(cfg, c);
        }
    }
    bool Commit(Settings& cfg) {
        if (editing < 0)
            return true;
        try {
            std::size_t n = 0;
            float v = std::stof(numeric, &n);
            if (n != numeric.size() || !std::isfinite(v))
                return false;
            if (Enabled(editing, cfg))
                Values(cfg).Set(std::size_t(editing), v);
            editing = -1;
            numeric.clear();
            return true;
        } catch (...) {
            return false;
        }
    }
    void Activate(const Hit& h, Settings& cfg) {
        SyncVisibility(cfg, 0);
        if (h.kind == SkyRefresh) {
            skyImages.clear();
            skyRasters.clear();
            if (skyRefresh)
                skyRefresh();
            return;
        }
        if (h.kind == SkyFolder) {
            if (skyOpenFolder)
                skyOpenFolder();
            return;
        }
        if (h.kind == SkyOption) {
            if (!Enabled(h.index, cfg))
                return;
            if (h.option >= 0 && h.option < int(AmbienceSkyCatalog.size())) {
                Values(cfg).Set(std::size_t(h.index), float(h.option));
                Values(cfg).customSkyMaterial.clear();
            } else if (h.option >= int(AmbienceSkyCatalog.size())) {
                auto n = std::size_t(h.option - int(AmbienceSkyCatalog.size()));
                if (n < skyCustom.size() && AmbienceSkyCustomMaterial(skyCustom[n].material))
                    Values(cfg).customSkyMaterial = skyCustom[n].material;
            }
            return;
        }
        if (h.kind == CloseButton) {
            Close();
            return;
        }
        if (h.kind == Surface || h.kind == Overlay || h.kind == RowHover)
            return;
        if (h.kind == Profile) {
            if (h.index >= 0 && h.index < ProfileCount(cfg)) {
                profile = h.index;
                choice = editing = color = -1;
                numeric.clear();
                CancelInput();
            }
            return;
        }
        if (h.kind == ProfileToggle) {
            ToggleProfile(h.index, cfg);
            return;
        }
        if (h.kind == ProfileMenu) {
            if (h.index >= 0 && h.index < ProfileCount(cfg)) {
                float x = mouseX, y = mouseY;
                if (!h.box.Contains(x, y)) {
                    x = h.box.x + h.box.w * .5f;
                    y = h.box.y + h.box.h * .5f;
                }
                OpenMenu(h.index, x, y);
            }
            return;
        }
        if (h.kind == MenuItem) {
            const int p = h.index, a = h.option;
            CloseMenu();
            if (a == MenuCopy)
                CopyProfile(p, cfg);
            else if (a == MenuPaste)
                RequestPaste(p, cfg);
            else if (a == MenuReset)
                ResetProfile(p, cfg);
            else if (a == MenuDelete)
                DeleteProfile(p, cfg);
            return;
        }

        if (h.kind == Add) {
            if (h.option == 1 && CanAdd(cfg)) {
                int p = cfg.worldAmbience.Add(currentMap);
                if (p >= 0)
                    profile = p;
            }
            return;
        }
        if (h.kind == Swatch) {
            int owner = ColorOwner(h.index);
            if (owner >= 0 && !Enabled(owner, cfg))
                return;
            OpenColor(h.index, h.option, h.box);
            return;
        }
        if (h.index < 0 || h.index >= int(N) || !Visible(h.index, cfg))
            return;
        if (h.kind == Details || h.kind == Opener) {
            OpenContext(h.index, h.box);
            return;
        }
        if (!Enabled(h.index, cfg))
            return;
        auto& v = Values(cfg);
        auto i = std::size_t(h.index);
        if (h.kind == Toggle) {
            bool on = v.value[i] == 0;
            v.Set(i, on ? 1.f : 0.f);
            if (on)
                Exclusive(h.index, v);
        }
        if (h.kind == Select) {
            choice = choice == h.index ? -1 : h.index;
            if (choice >= 0)
                StartTransition(1000 + choice);
            choiceBox = h.control;
        }
        if (h.kind == Option) {
            v.Set(i, float(h.option));
            choice = -1;
        }
    }

    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        if (!open) {
            CancelInput();
            return popupFade.value > .001f && overlay.Contains(x, y);
        }
        mouseX = x;
        mouseY = y;
        int n = HitAt(x, y);
        if (color >= 0) {

            const bool menus = picker.formatsOpen || picker.headerOpen || picker.held >= 0;
            const bool rowsOwn = down ? (choice >= 0 || (!menus && n >= 0 && n >= int(colorHitBegin) &&
                                                         RowControl(hits[std::size_t(n)].kind)))
                                      : (held >= 0 || drag >= 0);
            if (!rowsOwn) {
                auto c = ColorSettings(cfg);
                bool consumed = picker.Click(x, y, down, c);
                SyncColor(cfg, c);
                if (!consumed && down && !colorPopup.Contains(x, y)) {
                    CloseColor();
                    CancelInput();
                }
                return true;
            }
            if (down && picker.field >= 0) {
                auto c = ColorSettings(cfg);
                bool ok = picker.Commit(c);
                SyncColor(cfg, c);
                if (!ok)
                    return true;
            }
        }
        if (down) {
            if (n < 0)
                return false;
            auto h = hits[std::size_t(n)];
            if (h.kind == Surface) {
                if (menu >= 0)
                    CloseMenu();
                else if (choice >= 0)
                    choice = -1;
                else if (context >= 0 && !contextPopup.Contains(x, y))
                    CloseContext();
                return true;
            }
            if (editing >= 0 && !Commit(cfg))
                return true;
            if (h.kind == Overlay)
                return true;
            held = h.Key();
            focus = held;
            if (h.kind == Slider && Enabled(h.index, cfg)) {
                if (ctrl) {
                    editing = h.index;
                    numeric = NumberText(editing, cfg);
                    selectAll = true;
                } else {
                    drag = h.index;
                    Move(x, y, cfg);
                }
            }
            return true;
        }
        bool consumed = held >= 0 || drag >= 0;
        if (n >= 0 && held == hits[std::size_t(n)].Key() && drag < 0 && editing < 0)
            Activate(hits[std::size_t(n)], cfg);
        CancelInput();
        return consumed;
    }
    bool Key(int k, Settings& cfg, bool shift = false, bool ctrl = false) {
        if (!visible || blocked || !open)
            return false;
        if (editing >= 0) {
            if (k == 27) {
                editing = -1;
                numeric.clear();
            } else if (k == 13)
                Commit(cfg);
            else if (ctrl && k == 'A')
                selectAll = true;
            else if (k == 8 || k == 46) {
                if (selectAll)
                    numeric.clear();
                else if (!numeric.empty())
                    numeric.pop_back();
                selectAll = false;
            }
            return true;
        }
        if (color >= 0) {
            if (choice >= 0) {
                if (k == 27)
                    choice = -1;
                return true;
            }
            auto c = ColorSettings(cfg);
            if (picker.Key(k, c, ctrl)) {
                SyncColor(cfg, c);
                return true;
            }
            if (k == 27) {
                CloseColor();
                CancelInput();
            }
            return true;
        }

        if (k == 27) {
            if (menu >= 0)
                CloseMenu();
            else if (choice >= 0)
                choice = -1;
            else if (context >= 0)
                CloseContext();
            else
                Close();
            return true;
        }
        if (k == 9) {
            std::vector<int> keys;
            for (const auto& h : hits)
                if (h.kind != Surface && h.kind != RowHover && h.kind != Overlay &&
                    !(h.kind == Add && h.option != 1))
                    keys.push_back(h.Key());
            if (keys.empty())
                return true;
            auto it = std::find(keys.begin(), keys.end(), focus);
            int i = it == keys.end()
                        ? 0
                        : (int(it - keys.begin()) + (shift ? -1 : 1) + int(keys.size())) % int(keys.size());
            focus = keys[std::size_t(i)];
            return true;
        }
        for (const auto& h : hits)
            if (h.Key() == focus) {
                if (h.kind == Slider && (k == 37 || k == 39) && Enabled(h.index, cfg)) {
                    auto& v = Values(cfg);
                    auto i = std::size_t(h.index);
                    v.Set(i, v.value[i] + (k == 37 ? -1.f : 1.f) * AmbienceStep(i));
                } else if (k == 13 || k == 32)
                    Activate(h, cfg);
                return true;
            }
        return true;
    }
    bool Character(char16_t c) {
        if (!open)
            return false;
        if (editing < 0)
            return color >= 0 ? picker.Character(c) : false;
        if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.') {
            if (selectAll) {
                numeric.clear();
                selectAll = false;
            }
            if (numeric.size() < 24)
                numeric += char(c);
        }
        return true;
    }

    bool Wheel(float delta, Settings& cfg) {
        if (!visible || blocked || !open)
            return false;
        if (color == 5 && skyViewport.Contains(mouseX, mouseY) && !picker.formatsOpen && !picker.headerOpen) {
            skyScroll = std::clamp(skyScroll - delta * 30 * scale, 0.f, skyMaxScroll);
            skyReveal = false;
            return true;
        }
        if (menu >= 0 || choice >= 0)
            return true;
        const Box view = SurfaceBody();
        const int top = TopSurface();
        for (std::size_t i = 0; i < N; ++i)
            if (sliders[i].w > 0 && sliderSurface[i] == top && view.Contains(mouseX, mouseY) &&
                sliders[i].Contains(mouseX, mouseY) && Enabled(int(i), cfg)) {
                auto& v = Values(cfg);
                v.Set(i, v.value[i] + delta * AmbienceStep(i));
                return true;
            }
        if (color >= 0)
            return true;

        if (context >= 0) {
            for (const auto& c : cardViews)
                if (c.box.Contains(mouseX, mouseY) && contextBody.Contains(mouseX, mouseY)) {
                    auto& o = cardScroll[c.key];
                    o = std::clamp(o - delta * 30 * scale, 0.f, c.maximum);
                    return true;
                }
            detailScroll = std::clamp(detailScroll - delta * 30 * scale, 0.f, detailMaxScroll);
            return true;
        }
        if (listBox.Contains(mouseX, mouseY))
            listScroll = std::clamp(listScroll - delta * 30 * scale, 0.f, listMaxScroll);
        else if (body.Contains(mouseX, mouseY))
            scroll = std::clamp(scroll - delta * 30 * scale, 0.f, maxScroll);
        return true;
    }

    bool Context(float x, float y, Settings& cfg) {
        if (!visible || blocked || !open)
            return false;
        if (color >= 0 || menu >= 0)
            return true;
        int n = HitAt(x, y);
        if (n < 0)
            return false;
        const auto h = hits[std::size_t(n)];
        if ((h.kind == Toggle || h.kind == Details || h.kind == Opener) && HasWindow(h.index) &&
            Visible(h.index, cfg)) {
            const auto at = std::size_t(h.index);
            const auto& d = AmbienceSpecs[at];
            if (HasDetails(h.index) || d.kind == AmbienceKind::Opener)
                OpenContext(h.index, details[at].w > 0 ? details[at] : h.box);
            else if (Enabled(h.index, cfg))
                OpenColor(d.color, std::max(1, d.count), swatches[at].w > 0 ? swatches[at] : h.box);
        }
        return true;
    }

    void Measure(Fonts& fonts, const Settings& cfg, Box host, int width, int height, bool shown,
                 bool modalBlocked);
};
inline void WorldAmbienceUI::Measure(Fonts& fonts, const Settings& cfg, Box host, int width, int height,
                                     bool shown, bool modalBlocked) {
    visible = shown;
    blocked = modalBlocked;
    scale = cfg.scale;
    F = fonts.PixelHeight(0, 13 * scale);
    paint.layers.clear();
    hits.clear();
    rows.fill({});
    sliders.fill({});
    toggles.fill({});
    details.fill({});
    swatches.fill({});
    sliderSurface.fill(-2);
    profileRows.clear();
    profileToggles.clear();
    profileMenus.clear();
    addRow = addButton = {};
    cardViews.clear();
    colorPopup = colorBody = {};
    colorHitBegin = 0;
    if (!visible) {
        Close(false);
        hover = -1;
        overlay = {};
        return;
    }
    if (blocked) {
        CancelInput();
        hover = -1;
    }
    SyncVisibility(cfg, 0);
    if (!open && popupFade.value <= .001f) {
        overlay = {};
        return;
    }
    skyHeader = skyViewport = skyRefreshBox = skyFolderBox = {};
    const float s = scale, R = F + 14 * s, H = F + 6 * s;
    auto pal = CurrentPalette(cfg);
    auto alpha = [](Color c, float a) {
        c.a *= a;
        return c;
    };
    const auto& values = Values(cfg);

    Box localClip{};
    bool clipping = false;
    auto clipTo = [&](Box b) {
        localClip = b;
        clipping = true;
    };
    auto unclip = [&] {
        localClip = {};
        clipping = false;
    };
    auto tw = [&](const std::u32string& t, int font = 0, float px = 13) {
        return std::trunc(fonts.NativeTextSize(font, px * s, t).w + .95f);
    };
    auto upper = [](std::u32string t) {
        for (auto& c : t)
            if (c >= U'a' && c <= U'z')
                c -= 32;
        return t;
    };
    auto ellipsize = [&](std::u32string t, float w, int font, float px) {
        if (tw(t, font, px) <= w)
            return t;
        const std::u32string dots = U"...";
        while (!t.empty() && tw(t + dots, font, px) > w)
            t.pop_back();
        return t.empty() ? t : t + dots;
    };

    auto layer = [&](Box b, bool pop = false, float radius = 0) {
        PresetLayer l{b, radius, pop, {}};
        l.clipToPage = false;
        paint.layers.push_back(std::move(l));
        return int(paint.layers.size()) - 1;
    };
    auto finalClip = [&](int z, Box& clip) {
        clip = paint.layers[std::size_t(z)].box;
        if (clipping)
            clip = PresetIntersect(clip, localClip);
        return clip.w > 0 && clip.h > 0;
    };
    auto rect = [&](int z, Box b, Color c, float radius = 0, float stroke = 0) {
        Box clip{};
        if (b.w <= 0 || b.h <= 0 || !finalClip(z, clip))
            return false;
        PresetDraw d{b, c, radius, stroke, 15, {}, false};
        d.clipped = true;
        d.clip = clip;
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        return true;
    };
    auto text = [&](int z, Box b, const std::u32string& t, Color c, int font = 0, float px = 13) {
        Box clip{};
        if (t.empty() || b.w <= 0 || b.h <= 0 || !finalClip(z, clip))
            return;
        PresetDraw d{b, c, 0, 0, 15, t, font == 3};
        d.font = font;
        d.textSize = px;
        d.clipped = true;
        d.clip = clip;
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
    };
    auto hit = [&](Box b, int kind, int i = -1, int opt = -1, Box control = Box{}) {
        if (clipping)
            b = PresetIntersect(b, localClip);
        if (b.w > 0 && b.h > 0)
            hits.push_back({b, kind, i, opt, control});
    };
    auto shape = [&](int z, Box b) {
        rect(z, b, pal[40], 15 * s);
        rect(z, b, pal[11], 15 * s, s);
    };
    auto surface = [&](Box b) {
        int z = layer(b, true, 15 * s);
        rect(z, b, pal[8], 15 * s);
        rect(z, b, pal[11], 15 * s, s);
        return z;
    };
    auto line = [&](int z, float x, float y, float w, bool uniform = false) {
        if (rect(z, {x, y, w, s}, pal[34])) {
            auto& d = paint.layers[std::size_t(z)].draw.back();
            d.pixelLine = true;
            d.uniformSeparator = uniform;
        }
    };
    auto fadeLayers = [&](std::size_t from, float amount) {
        for (std::size_t n = from; n < paint.layers.size(); ++n) {
            paint.layers[n].opacity *= amount;
            for (auto& d : paint.layers[n].draw)
                d.color.a *= amount;
        }
    };
    auto rememberTransition = [&](int key, std::size_t from) {
        auto& t = transitions[key];
        if (!t.motion.initialized)
            t.motion.Snap(0);
        t.cached.assign(paint.layers.begin() + std::ptrdiff_t(from), paint.layers.end());
        fadeLayers(from, t.motion.value);
    };

    auto seen = [&](Box b) { return clipping ? PresetIntersect(b, localClip) : b; };
    bool acceptingColors = false;
    auto sample = [&](int z, float right, float y, int idx, float a, int count, float rowHeight) {
        Box b{right - 16 * s, y + (rowHeight - 16 * s) * .5f, 16 * s, 16 * s};
        Hit h{b, Swatch, idx, count};
        rect(z, {b.x - 3 * s, b.y - 3 * s, b.w + 6 * s, b.h + 6 * s}, alpha(pal[33], .4f * Motion(h) * a),
             6 * s);
        Box clip{};
        if (finalClip(z, clip)) {
            auto image = std::make_shared<Canvas>(int(std::ceil(b.w)), int(std::ceil(b.h)));
            Color c = values.colors[std::size_t(idx)];
            Color last = values.colors[std::size_t(idx + count - 1)];
            bool gradient = count > 1;
            DrawPickerPreview(*image, {0, 0, b.w, b.h}, s, F + 6 * s, c, last, gradient, false);
            PresetDraw d{b, {1, 1, 1, a}, 0, 0, 15, {}, false};
            d.raster = image;
            d.rasterStamp = PickerPreviewStamp(c, last, gradient, false);
            d.clipped = true;
            d.clip = clip;
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        }
        if (acceptingColors)
            hit(b, Swatch, idx, count);
        return b;
    };
    const float hf = fonts.PixelHeight(0, 10 * s), Fh = fonts.PixelHeight(0, 14.5f * s), windowF = F,
                windowR = windowF + 14 * s, marker = tw(U"\uf00c", 3) + 12 * s;
    auto cardRows = [&](const Card& c) {
        float n = 0;
        for (int i : c.rows)
            n += FieldAmount(i);
        return n;
    };
    auto cardHeight = [&](const Card& c) {
        return 14 * s + windowR * cardRows(c) + (c.separatorAt >= 0 ? 14 * s : 0);
    };

    const float cardCap = 355 * s;
    auto cardsTotal = [&](int ctx) {
        float total = 0;
        for (const auto& c : Cards(ctx))
            total += std::min(cardHeight(c), cardCap) + 7 * s;
        return total;
    };

    auto innerRow = [&](int i, int bz, Box row, float amount, bool interactive, int surfaceId, float markerW,
                        float markerValue) {
        const bool fieldVisible = Visible(i, cfg);
        const auto& d = AmbienceSpecs[std::size_t(i)];
        const auto at = std::size_t(i);
        const float cy = row.y;
        if (fieldVisible)
            rows[at] = localClip;
        const bool enabled = Enabled(i, cfg);
        const float a = (available[at].initialized ? available[at].value : enabled ? 1.f : .5f) * amount;
        const int kind = KindOf(i);
        Hit h{row, kind, i};
        const float t = enabled ? Motion(h) : 0;
        const float on = values.value[at];
        rect(bz, row, alpha(pal[33], .4f * t * a), 15 * s / 1.6f);
        float left = row.x + 12 * s, right = row.x + row.w - 12 * s, labelRight = right;
        Color ink = alpha(Mix(pal[14], pal[2],
                              d.kind == AmbienceKind::Switch || d.kind == AmbienceKind::Check
                                  ? std::max(t, on != 0 ? 1.f : 0.f)
                                  : t),
                          a);
        if (d.kind == AmbienceKind::Switch) {

            float nominal = windowF + 2 * s, center = cy + row.h * .5f, frac = center - std::trunc(center);
            h.control = {right - 32 * s, center - nominal * .5f + frac, 32 * s, nominal - 2 * frac};
            if (fieldVisible)
                toggles[at] = PresetIntersect(h.control, localClip);
            float k = checked[at].initialized ? checked[at].value : on;
            rect(bz, h.control, alpha(pal[22], a), nominal * .5f);
            rect(bz, h.control, alpha(pal[23], a * k), nominal * .5f);
            float radius = nominal * .5f - 2 * s,
                  cx = h.control.x + nominal * .5f + (h.control.w - nominal) * k;
            rect(bz, {cx - radius, center - radius, 2 * radius, 2 * radius},
                 alpha(Mix(pal[20], pal[21], k), a), radius);
            labelRight = h.control.x - 6 * s;
        } else if (d.kind == AmbienceKind::Check) {
            h.control = {left, cy + 7 * s, tw(U"\uf00c", 3), windowF};
            if (on != 0)
                text(bz, h.control, U"\uf00c", alpha(pal[0], a * markerValue), 3);
            left += markerW;
        }
        if (d.icon) {
            auto glyph = std::u32string(1, d.icon);
            float iw = tw(glyph, 3);
            text(bz, {left + (20 * s - iw) * .5f, cy + 7 * s, 20 * s, windowF}, glyph, ink, 3);
            left += 32 * s;
        }
        if (d.kind == AmbienceKind::Choice) {
            auto opts = Options(i);
            std::u32string value =
                opts.empty() ? std::u32string{}
                             : opts[std::size_t(std::clamp(int(std::lround(on)), 0, int(opts.size()) - 1))];
            float valueW = tw(value), arrowW = std::max(10 * s, tw(U"\uf105", 3)),
                  w = valueW + arrowW + 6 * s;
            h.control = {right - w, cy, w, row.h};
            text(bz, {right - w, cy + 7 * s, valueW + s, windowF}, value, alpha(pal[14], a));
            text(bz, {right - 10 * s, cy + 7 * s, 10 * s, windowF}, U"\uf105", alpha(pal[14], a), 3);
            labelRight = right - w - 6 * s;
        } else if (d.kind == AmbienceKind::Opener) {
            h.control = {right - 10 * s, cy, 10 * s, row.h};
            float k = context == i ? 1.f : t;
            text(bz, {right - 10 * s, cy + 7 * s, 10 * s, windowF}, U"\uf105",
                 alpha(Mix(pal[14], pal[2], k), a), 3);
            labelRight = right - 16 * s;
        } else if (IsSlider(i)) {
            float w = std::trunc(row.w / 2.5f);
            Box b{right - w, cy + (row.h - 6 * s) * .5f, w, 6 * s};
            sliders[at] = PresetIntersect(b, localClip);
            sliderSurface[at] = surfaceId;
            h.control = b;
            float v = std::clamp((on - d.minimum) / (d.maximum - d.minimum), 0.f, 1.f);
            rect(bz, b, alpha(pal[24], a), 3 * s);

            if (v > 0) {
                const Box saved = localClip;
                const bool was = clipping;
                clipTo(PresetIntersect(was ? saved : paint.layers[std::size_t(bz)].box,
                                       {b.x, b.y, b.w * v, b.h}));
                rect(bz, b, alpha(pal[25], a), 3 * s);
                localClip = saved;
                clipping = was;
            }
            labelRight = b.x - 6 * s;
            if (editing == i) {
                rect(bz, {b.x, cy, b.w, row.h}, pal[12], 6 * s);
                text(bz, {b.x + 6 * s, cy + 7 * s, b.w - 12 * s, windowF}, DecodeUTF8(numeric), pal[2]);
            }
        }
        if (interactive && fieldVisible) {
            if (kind == Slider) {
                hit(row, RowHover, i, -1, h.control);
                hit({h.control.x, cy, h.control.w, row.h}, Slider, i, -1, h.control);
            } else
                hit(row, kind, i, -1, h.control);
        }
        if (HasDetails(i)) {
            Box more{h.control.x - 29 * s, cy, 22 * s, row.h};
            if (fieldVisible)
                details[at] = PresetIntersect(more, localClip);
            Hit mh{more, Details, i};
            bool ancestor = context == i;
            for (const auto& p : contextParents)
                if (p.index == i)
                    ancestor = true;
            float k = ancestor ? 1.f : Motion(mh);
            rect(bz, more, alpha(pal[33], .4f * k * amount), 15 * s / 1.6f);
            float iw = tw(U"\uf141", 3);
            text(bz, {more.x + (more.w - iw) * .5f, cy + 7 * s, iw, windowF}, U"\uf141",
                 alpha(Mix(pal[14], pal[2], k), amount), 3);
            if (interactive && fieldVisible)
                hit(more, Details, i);
            labelRight = more.x - 4 * s;
        }
        acceptingColors = interactive && open && enabled && fieldVisible;
        if (d.color >= 0) {
            auto b = sample(bz, labelRight, cy, d.color, a, std::max(1, d.count), row.h);
            if (fieldVisible)
                swatches[at] = PresetIntersect(b, localClip);
            labelRight = b.x - 3 * s;
        }
        Box viewport =
            PresetIntersect(localClip, {left, cy + 7 * s, std::max(0.f, labelRight - left), windowF});
        Box saved = localClip;
        localClip = viewport;
        auto label = RowLabel(i);
        text(bz, {left, cy + 7 * s, std::max(viewport.w, tw(label)) + s, windowF}, label, ink);
        localClip = saved;
    };

    auto outerRow = [&](int i, int bz, Box row, int n, int count, bool interactive) {
        const auto& d = AmbienceSpecs[std::size_t(i)];
        const auto at = std::size_t(i);
        const Box band = GroupRowHoverBounds(row, s);
        rows[at] = seen(band);
        const bool enabled = Enabled(i, cfg);
        const float a = available[at].initialized ? available[at].value : enabled ? 1.f : .5f;
        const int kind = KindOf(i);
        Hit h{band, kind, i};
        const float t = enabled ? Motion(h) : 0, on = values.value[at];
        if (rect(bz, band, alpha(pal[33], .15f * t * a), 15 * s))
            paint.layers[std::size_t(bz)].draw.back().corners = GroupRowCorners(n, count);
        const float left = row.x, right = row.x + row.w, ty = row.y + (row.h - F) * .5f;
        float labelRight = right;
        const float k = checked[at].initialized ? checked[at].value : on != 0 ? 1.f : 0.f;
        const Color ink = alpha(Mix(pal[0], pal[2], d.kind == AmbienceKind::Switch ? std::max(t, k) : t), a);
        if (d.kind == AmbienceKind::Switch) {
            const float nominal = F + 2 * s, center = row.y + row.h * .5f, frac = center - std::trunc(center);
            h.control = {right - 32 * s, center - nominal * .5f + frac, 32 * s, nominal - 2 * frac};
            toggles[at] = seen(h.control);
            rect(bz, h.control, alpha(pal[22], a), nominal * .5f);
            rect(bz, h.control, alpha(pal[23], a * k), nominal * .5f);
            const float radius = nominal * .5f - 2 * s,
                        cx = h.control.x + nominal * .5f + (h.control.w - nominal) * k;
            rect(bz, {cx - radius, center - radius, 2 * radius, 2 * radius},
                 alpha(Mix(pal[20], pal[21], k), a), radius);
            labelRight = h.control.x - 6 * s;
        } else if (d.kind == AmbienceKind::Opener) {
            h.control = {right - 16 * s, row.y, 16 * s, row.h};
            const float ko = context == i ? 1.f : t;
            text(bz, {right - 16 * s, ty, 10 * s, F}, U"\uf105", alpha(Mix(pal[14], pal[2], ko), a), 3);
            labelRight = right - 22 * s;
        }
        if (interactive)
            hit(band, kind, i, -1, h.control);
        if (HasDetails(i)) {
            const Box more{h.control.x - 29 * s, row.y, 22 * s, row.h};
            details[at] = seen(more);
            Hit mh{more, Details, i};
            bool ancestor = context == i;
            for (const auto& p : contextParents)
                if (p.index == i)
                    ancestor = true;
            const float km = ancestor ? 1.f : Motion(mh);
            rect(bz, more, alpha(pal[33], .4f * km * a), 15 * s / 1.6f);
            const float iw = tw(U"\uf141", 3);
            text(bz, {more.x + (more.w - iw) * .5f, ty, iw, F}, U"\uf141", alpha(Mix(pal[14], pal[2], km), a),
                 3);
            if (interactive)
                hit(more, Details, i);
            labelRight = more.x - 4 * s;
        }
        acceptingColors = interactive && open && enabled;
        if (d.color >= 0) {
            auto b = sample(bz, labelRight, row.y, d.color, a, std::max(1, d.count), row.h);
            swatches[at] = seen(b);
            labelRight = b.x - 3 * s;
        }
        const Box saved = localClip;
        const bool was = clipping;
        clipTo(PresetIntersect(was ? saved : paint.layers[std::size_t(bz)].box,
                               {left, ty, std::max(0.f, labelRight - left), F}));
        auto label = RowLabel(i);
        text(bz, {left, ty, std::max(localClip.w, tw(label)) + s, F}, label, ink);
        localClip = saved;
        clipping = was;
    };

    auto drawCards = [&](int ctx, int bz, Box area, float y, bool interactive) {
        const auto cards = Cards(ctx);
        for (std::size_t n = 0; n < cards.size(); ++n) {
            const auto& card = cards[n];
            const float full = cardHeight(card), ch = std::min(full, cardCap);
            const Box sectionClip = PresetIntersect({area.x, y, area.w, ch}, area);
            int mk = (ctx + 2) * 10 + int(n);
            bool any = false;
            for (int i : card.rows)
                if (AmbienceSpecs[std::size_t(i)].kind == AmbienceKind::Check &&
                    values.value[std::size_t(i)] != 0)
                    any = true;
            markerTargets[mk] = any ? 1.f : 0.f;
            auto mi = markers.try_emplace(mk).first;
            if (!mi->second.initialized)
                mi->second.Snap(markerTargets[mk]);
            const float markerW = marker * mi->second.value;
            const int key = ctx * 16 + int(n);
            const float cardMax = std::max(0.f, full - ch);
            float& offset = cardScroll[key];
            offset = std::clamp(offset, 0.f, cardMax);
            if (sectionClip.w <= 0 || sectionClip.h <= 0) {
                y += ch + 7 * s;
                continue;
            }
            const Box cb{area.x, y, area.w, ch};
            clipTo(sectionClip);
            shape(bz, cb);

            const Box inner =
                PresetIntersect(sectionClip, {cb.x, cb.y + s, cb.w, std::max(0.f, cb.h - 2 * s)});
            if (interactive && cardMax > 0)
                cardViews.push_back({sectionClip, key, cardMax});
            float cy = cb.y + 7 * s - offset;
            int fieldNumber = 0;
            for (int i : card.rows) {
                if (fieldNumber++ == card.separatorAt) {
                    clipTo(inner);
                    line(bz, cb.x + 7 * s, cy + 7 * s, cb.w - 14 * s);
                    cy += 14 * s;
                }
                const float amount = FieldAmount(i);
                if (amount <= .001f)
                    continue;
                const Box row{cb.x + 7 * s, cy, cb.w - 14 * s, windowR};
                clipTo(PresetIntersect(inner, {row.x, row.y, row.w, row.h * amount}));
                if (localClip.w > 0 && localClip.h > 0)
                    innerRow(i, bz, row, amount, interactive, ctx, markerW, mi->second.value);
                cy += windowR * amount;
            }
            if (cardMax > 0) {
                clipTo(sectionClip);
                const float th = std::max(10 * s, ch * ch / full);
                rect(bz, {cb.x + cb.w - 5 * s, cb.y + (ch - th) * offset / cardMax, 4 * s, th}, pal[18],
                     4 * s);
            }
            unclip();
            y += ch + 7 * s;
        }
        unclip();
    };

    auto contentWidth = [&](int ctx) {
        float windowWidth = 265 * s;
        for (const auto& c : Cards(ctx))
            for (int i : c.rows) {
                const auto& d = AmbienceSpecs[std::size_t(i)];
                float label = tw(RowLabel(i)),
                      lead = 24 * s + (d.icon ? 32 * s : 0) + (d.kind == AmbienceKind::Check ? marker : 0);
                if (IsSlider(i)) {
                    float need = label + lead + 6 * s + (d.color >= 0 ? 19 * s : 0);
                    windowWidth = std::max(windowWidth, std::ceil(need / .6f + 28 * s));
                    continue;
                }
                float right = 6 * s;
                if (d.kind == AmbienceKind::Switch)
                    right += 32 * s + (HasDetails(i) ? 29 * s + 4 * s : 0);
                if (d.color >= 0)
                    right += 19 * s;
                if (d.kind == AmbienceKind::Opener)
                    right += 16 * s;
                if (d.kind == AmbienceKind::Choice) {
                    float widest = 0;
                    for (const auto& o : Options(i))
                        widest = std::max(widest, tw(o));
                    right += widest + std::max(10 * s, tw(U"\uf105", 3)) + 6 * s;
                }
                windowWidth = std::max(windowWidth, std::ceil(lead + label + right + 28 * s));
            }
        return windowWidth;
    };

    auto drawWindow = [&](int ctx, Box anchor, bool interactive) {
        const std::size_t transitionBegin = paint.layers.size();
        acceptingColors = interactive && open;
        const bool opener = AmbienceSpecs[std::size_t(ctx)].kind == AmbienceKind::Opener;
        const float total = cardsTotal(ctx);

        float windowWidth = opener ? contentWidth(ctx) : std::trunc(285 * s);
        windowWidth = std::min(windowWidth, std::max(265 * s, float(width) - 24 * s));
        const float titleH = windowF + 21 * s,
                    windowH = std::min(titleH + total, std::max(1.f, float(height) - 12 * s));
        Box box{};
        if (opener)
            box =
                PresetPopupFit({anchor.x + anchor.w + 7 * s, anchor.y, windowWidth, windowH}, width, height);
        else {
            box = {anchor.x + anchor.w + 7 * s, anchor.y + anchor.h * .5f - windowH * .25f, windowWidth,
                   windowH};
            box.x = std::floor(std::clamp(box.x, 0.f, std::max(0.f, float(width) - box.w - 10 * s)));
            box.y = std::floor(std::clamp(box.y, 0.f, std::max(0.f, float(height) - box.h - 10 * s)));
        }
        Box area{box.x + 7 * s, box.y + titleH, box.w - 14 * s, std::max(0.f, box.h - titleH - 7 * s)};
        float ancestorOffset = 0;
        for (const auto& parent : contextParents)
            if (parent.index == ctx)
                ancestorOffset = parent.scroll;
        float maximum = std::max(0.f, total - 7 * s - area.h),
              &offset = ctx == context ? detailScroll : ancestorOffset;
        offset = std::clamp(offset, 0.f, maximum);
        if (ctx == context) {
            contextPopup = box;
            contextBody = area;
            detailMaxScroll = maximum;
        }
        if (interactive) {
            hits.clear();
            hit({0, 0, float(width), float(height)}, Surface);
        }
        int pz = surface(box);
        if (interactive)
            hit(box, Surface);
        text(pz, {box.x + 14 * s, box.y + 7 * s, box.w - 28 * s, fonts.PixelHeight(2, 13 * s)}, RowLabel(ctx),
             pal[2], 2, 13);
        int bz = layer(area);
        drawCards(ctx, bz, area, area.y - offset, interactive);
        if (maximum > 0) {
            float th = std::max(10 * s, area.h * area.h / (area.h + maximum));
            rect(pz, {box.x + box.w - 5 * s, area.y + (area.h - th) * offset / maximum, 4 * s, th}, pal[18],
                 4 * s);
        }
        rememberTransition(ctx, transitionBegin);
    };

    auto drawColor = [&](int slot, int count, Box anchor, HudColorPicker& pk, bool interactive) {
        const std::size_t from = paint.layers.size();
        pk.languages = languages;
        pk.SetMetrics(fonts, s);
        auto c = ColorSettings(cfg, slot, count);
        const int owner = ColorOwner(slot);
        const std::vector<int> kids = owner >= 0 ? Children(owner) : std::vector<int>{};
        const float ph = pk.Height(s),
                    galleryH = std::clamp(float(height) - ph - windowR - 45 * s, 127 * s, 250 * s);
        float rowsH = 0;
        for (int i : kids) {
            if (AmbienceSpecs[std::size_t(i)].separator)
                rowsH += 14 * s;
            rowsH += (IsSkybox(i) ? windowR + 14 * s + galleryH : windowR) * FieldAmount(i);
        }
        const float extra = rowsH > .001f ? 18 * s + rowsH : 0, w = 265 * s, h = ph + extra;
        Box b{anchor.x + anchor.w + 7 * s, anchor.y + anchor.h * .5f - h * .25f, w, h};
        b.x = std::floor(std::clamp(b.x, 0.f, std::max(0.f, float(width) - w - 10 * s)));
        b.y = std::floor(std::clamp(b.y, 0.f, std::max(0.f, float(height) - h - 10 * s)));
        if (interactive) {
            hit({0, 0, float(width), float(height)}, Surface);
            colorPopup = b;
        }
        const int cz = surface(b);
        if (interactive)
            hit(b, Overlay);
        pk.Draw(paint, cz, fonts, c, b);
        if (interactive)
            colorHitBegin = hits.size();
        if (extra > 0) {
            line(cz, b.x + 10 * s, b.y + ph - 3 * s, 245 * s);
            float cy = b.y + ph + 8 * s;
            if (interactive)
                colorBody = {b.x + 10 * s, cy, 245 * s, rowsH};
            for (int i : kids) {
                if (AmbienceSpecs[std::size_t(i)].separator) {
                    clipTo(b);
                    line(cz, b.x + 10 * s, cy + 7 * s, 245 * s);
                    cy += 14 * s;
                }
                const float amount = FieldAmount(i);
                if (amount <= .001f)
                    continue;
                if (IsSkybox(i)) {
                    const Box header{b.x + 10 * s, cy, 245 * s, windowR};
                    const float button = 26 * s;
                    const Box folder{header.x + header.w - button, cy, button, windowR},
                        refresh{folder.x - button - 3 * s, cy, button, windowR};
                    if (interactive) {
                        skyHeader = header;
                        skyFolderBox = folder;
                        skyRefreshBox = refresh;
                        rows[std::size_t(i)] = header;
                    }
                    clipTo(b);
                    const float iconW = tw(U"\uf64f", 3);
                    text(cz, {header.x + 12 * s, cy + 7 * s, iconW, windowF}, U"\uf64f", pal[14], 3);
                    text(cz, {header.x + 12 * s + 32 * s, cy + 7 * s, refresh.x - header.x - 44 * s, windowF},
                         RowLabel(i), pal[14]);
                    for (int n = 0; n < 2; ++n) {
                        Box at = n ? folder : refresh;
                        Hit action{at, n ? SkyFolder : SkyRefresh, i};
                        float hv = Motion(action);
                        rect(cz, at, alpha(pal[33], .4f * hv), 6 * s);
                        const std::u32string icon = n ? U"\uf07c" : U"\uf021";
                        float iw = tw(icon, 3);
                        text(cz, {at.x + (at.w - iw) * .5f, cy + 7 * s, iw, windowF}, icon,
                             Mix(pal[14], pal[2], hv), 3);
                        if (interactive)
                            hit(at, action.kind, i);
                    }
                    line(cz, header.x, cy + windowR + 7 * s, header.w);
                    const Box viewport{header.x, cy + windowR + 14 * s, header.w, galleryH};
                    const float rowH = windowF + 1.8f * 8 * s, pitch = rowH + 7 * s;
                    if (interactive && skyCustomQuery) {
                        try {
                            auto next = skyCustomQuery();
                            if (next.size() > 64)
                                next.resize(64);
                            next.erase(std::remove_if(next.begin(), next.end(),
                                                      [](const auto& e) {
                                                          return !AmbienceSkyCustomMaterial(e.material) ||
                                                                 e.id != AmbienceSkyCustomId(e.material);
                                                      }),
                                       next.end());
                            skyCustom = std::move(next);
                        } catch (...) {
                            skyCustom.clear();
                        }
                    }
                    const int skyCount = int(AmbienceSkyCatalog.size() + skyCustom.size());
                    const float maximum = std::max(0.f, float(skyCount) * pitch - 7 * s - viewport.h);
                    int selected = values.customSkyMaterial.empty()
                                       ? std::clamp(int(std::lround(values.value[std::size_t(i)])), 0, 13)
                                       : -1;
                    for (std::size_t n = 0; n < skyCustom.size(); ++n)
                        if (skyCustom[n].material == values.customSkyMaterial)
                            selected = int(AmbienceSkyCatalog.size() + n);
                    if (interactive) {
                        skyViewport = viewport;
                        skyMaxScroll = maximum;
                        if (skyReveal) {
                            skyScroll =
                                std::clamp(float(selected) * pitch - (viewport.h - rowH) * .5f, 0.f, maximum);
                            skyReveal = false;
                        }
                        skyScroll = std::clamp(skyScroll, 0.f, maximum);
                    }
                    auto opts = Options(i);
                    clipTo(PresetIntersect(b, viewport));
                    for (int n = 0; n < skyCount; ++n) {
                        Box tile{viewport.x, viewport.y + float(n) * pitch - skyScroll, viewport.w - 9 * s,
                                 rowH};
                        if (PresetIntersect(tile, viewport).h <= 0)
                            continue;
                        Hit action{tile, SkyOption, i, n};
                        float hv = interactive ? Motion(action) : 0;
                        rect(cz, tile, pal[40], 12 * s);
                        rect(cz, tile, alpha(pal[33], .2f * hv), 12 * s);

                        if (n > 0 && skyImageQuery) {
                            AmbienceImageResult<ProfileImage> result;
                            try {
                                result = skyImageQuery(
                                    n < int(AmbienceSkyCatalog.size())
                                        ? std::string(AmbienceSkyCatalog[std::size_t(n)].id)
                                        : skyCustom[std::size_t(n - int(AmbienceSkyCatalog.size()))].id);
                            } catch (...) {
                                result.state = AmbienceImageState::Missing;
                            }
                            auto& image = skyImages[n];
                            if (image.revision != result.revision || image.image != result.image) {
                                image.image = result.image;
                                image.revision = result.revision;
                                image.hash = result.revision;
                                skyRasters.erase(n);
                            }
                            if (image.image) {

                                const float border = s, radius = std::max(0.f, 12 * s - border);
                                const Box preview{tile.x + tile.w * .25f + border, tile.y + border,
                                                  tile.w * .75f - 2 * border, tile.h - 2 * border};
                                const Box px{std::floor(preview.x), std::floor(preview.y),
                                             std::ceil(preview.x + preview.w) - std::floor(preview.x),
                                             std::ceil(preview.y + preview.h) - std::floor(preview.y)};
                                std::uint64_t stamp = image.hash ^ 0x534b5945444745ull;
                                auto mix = [&](float v) {
                                    std::uint32_t bits = 0;
                                    std::memcpy(&bits, &v, sizeof bits);
                                    for (int k = 0; k < 4; ++k) {
                                        stamp ^= (bits >> (k * 8)) & 255;
                                        stamp *= 1099511628211ull;
                                    }
                                };
                                for (float v : {px.w, px.h, preview.x - px.x, preview.y - px.y, preview.w,
                                                preview.h, radius, pal[40].r, pal[40].g, pal[40].b})
                                    mix(v);
                                auto& raster = skyRasters[n];
                                if (!raster.image || raster.stamp != stamp) {
                                    auto out = std::make_shared<Canvas>(int(px.w), int(px.h));
                                    DrawAmbienceMapImage(
                                        *out, {preview.x - px.x, preview.y - px.y, preview.w, preview.h},
                                        radius, *image.image, pal[40], 0, .85f);
                                    raster.image = std::move(out);
                                    raster.stamp = stamp;
                                }
                                PresetDraw d{px, {1, 1, 1, 1}, 0, 0, 15, {}, false};
                                d.raster = raster.image;
                                d.rasterStamp = raster.stamp;
                                d.clipped = true;
                                d.clip = localClip;
                                paint.layers[std::size_t(cz)].draw.push_back(std::move(d));
                            }
                        }
                        rect(cz, tile, n == selected ? pal[23] : pal[11], 12 * s, s);
                        const auto label =
                            n < int(opts.size())
                                ? opts[std::size_t(n)]
                                : DecodeUTF8(
                                      skyCustom[std::size_t(n - int(AmbienceSkyCatalog.size()))].label);
                        text(cz, {tile.x + 12 * s, tile.y + (rowH - windowF) * .5f, tile.w - 24 * s, windowF},
                             label, n == selected ? pal[2] : Mix(pal[14], pal[2], hv));
                        if (interactive)
                            hit(tile, SkyOption, i, n);
                    }
                    if (maximum > 0) {
                        float th = std::max(10 * s, viewport.h * viewport.h / (viewport.h + maximum));
                        rect(cz,
                             {viewport.x + viewport.w - 5 * s,
                              viewport.y + (viewport.h - th) * skyScroll / maximum, 5 * s, th},
                             pal[18], 5 * s);
                    }
                    unclip();
                    cy += (windowR + 14 * s + galleryH) * amount;
                    continue;
                }
                const Box row{b.x + 10 * s, cy, 245 * s, windowR};
                clipTo(PresetIntersect(b, {row.x, row.y, row.w, row.h * amount}));
                if (localClip.w > 0 && localClip.h > 0)
                    innerRow(i, cz, row, amount, interactive, 1000 + slot, 0, 1);
                cy += windowR * amount;
            }
            unclip();
        }
        if (interactive && choice < 0)
            pk.DrawMenus(paint, fonts, c, width, height);
        rememberTransition(2000 + slot, from);
    };

    auto mapBackground = [&](int z, Box row, int key, const std::string& map, float enabled) {
        const MapImage* image = FindMapImage(map);
        if (!image)
            return;
        const float border = s;
        const Box r{row.x + row.w / 3 + border, row.y + border, row.w - row.w / 3 - 2 * border,
                    row.h - 2 * border};
        if (r.w < 1 || r.h < 1)
            return;
        Box clip{};
        if (!finalClip(z, clip))
            return;
        const Box px{std::floor(r.x), std::floor(r.y), std::ceil(r.x + r.w) - std::floor(r.x),
                     std::ceil(r.y + r.h) - std::floor(r.y)};
        const float gray = std::round((1 - std::clamp(enabled, 0.f, 1.f)) * 32) / 32;
        const Color card = pal[40];
        std::uint64_t stamp = image->hash ^ 0x4d4150424bull;
        auto mix = [&](float v) {
            std::uint32_t bits = 0;
            std::memcpy(&bits, &v, sizeof bits);
            for (int k = 0; k < 4; ++k) {
                stamp ^= (bits >> (k * 8)) & 255;
                stamp *= 1099511628211ull;
            }
        };
        for (float v : {px.w, px.h, r.x - px.x, r.y - px.y, r.w, r.h, gray, card.r, card.g, card.b, 12 * s})
            mix(v);
        auto& cache = mapRasters[key];
        if (!cache.image || cache.stamp != stamp) {
            auto canvas = std::make_shared<Canvas>(int(px.w), int(px.h));
            DrawAmbienceMapImage(*canvas, {r.x - px.x, r.y - px.y, r.w, r.h}, 12 * s, *image->image, card,
                                 gray);
            cache.image = canvas;
            cache.stamp = stamp;
        }
        PresetDraw d{px, {1, 1, 1, 1}, 0, 0, 15, {}, false};
        d.raster = cache.image;
        d.rasterStamp = stamp;
        d.clipped = true;
        d.clip = clip;
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
    };
    const std::size_t begin = paint.layers.size();

    overlay = {std::floor(host.x), std::floor(host.y), std::max(0.f, std::trunc(host.w - s)),
               std::max(0.f, std::trunc(host.h - s))};
    const int oz = layer(overlay, true, 16 * s);
    paint.layers[std::size_t(oz)].shadow = false;

    {
        auto dim = pal[9];
        dim.a *= .85f * popupFade.value;
        rect(oz, overlay, dim, 16 * s);
        rect(oz, overlay, pal[11], 16 * s, s);
    }
    if (open)
        hit(overlay, Overlay);

    closeBox = {overlay.x + overlay.w - 15 * s - 30 * s, overlay.y + 10 * s, 30 * s, Fh + 6 * s};
    {
        const float t = Motion({closeBox, CloseButton});
        rect(oz, closeBox, alpha(pal[33], .4f * t), 6 * s);
        const std::u32string glyph(1, char32_t(0xF00D));
        const float iw = tw(glyph, 3, 14.5f);
        text(oz, {closeBox.x + std::trunc((closeBox.w - iw) * .5f), closeBox.y + 3 * s, iw + s, Fh}, glyph,
             alpha(pal[30], .7f + .3f * t), 3, 14.5f);
        if (open)
            hit(closeBox, CloseButton);
    }

    const float L = overlay.w - 30 * s, c1 = 10 * s + L / 2.2f, leftX = std::floor(overlay.x + 15 * s),
                leftR = overlay.x + c1 - 5 * s, rightX = std::floor(overlay.x + c1 + 5 * s),
                rightR = overlay.x + overlay.w - 15 * s;
    const float y0 = overlay.y + 10 * s + Fh + 6 * s, bottom = overlay.y + overlay.h - 10 * s;

    {
        const float w = std::max(0.f, leftR - leftX - 14 * s);
        text(oz, {leftX + 14 * s, y0, w, hf},
             ellipsize(Label("visuals_world_miscellaneous_ambience_selection"), w, 0, 10), pal[3], 0, 10);
    }
    const float listTop = y0 + hf + 5 * s;
    listBox = {leftX, listTop, std::max(0.f, std::trunc(leftR - leftX)),
               std::max(0.f, std::trunc(bottom - listTop))};
    {
        const int count = ProfileCount(cfg);
        const bool adding = CanAdd(cfg);
        const float rowH = F + 18 * s, gap = 10 * s, button = 20 * s;
        listMaxScroll = std::max(0.f, float(count + (adding ? 1 : 0)) * (rowH + gap) - gap - listBox.h);
        listScroll = std::clamp(listScroll, 0.f, listMaxScroll);
        profileRows.assign(std::size_t(count), Box{});
        profileToggles.assign(std::size_t(count), Box{});
        profileMenus.assign(std::size_t(count), Box{});
        const int lz = layer(listBox);

        auto rowFrame = [&](Box row, const RowMotion& m, int key, const std::string& map) {
            rect(lz, row, pal[40], 12 * s);
            rect(lz, row, alpha(pal[33], .2f * m.fill.value), 12 * s);
            mapBackground(lz, row, key, map, m.enabled.value);
            rect(lz, row,
                 Mix(pal[11], Mix(alpha(pal[14], .25f), alpha(pal[31], .4f), m.enabled.value), m.ink.value),
                 12 * s, s);
        };
        auto iconButton = [&](Box b, char32_t cp, Color ink, float state, float visibility) {
            if (visibility <= .001f)
                return;
            rect(lz, b, alpha(pal[33], .4f * state * visibility), 6 * s);
            const std::u32string g(1, cp);
            const float iw = tw(g, 3);
            ink.a *= (.7f + .3f * state) * visibility;
            text(lz, {b.x + std::trunc((b.w - iw) * .5f), b.y + std::trunc((b.h - F) * .5f), iw + s, F}, g,
                 ink, 3);
        };
        auto rowLabel = [&](Box row, float right, const std::u32string& name, Color ink) {
            const Box saved = localClip;
            clipTo(PresetIntersect(listBox,
                                   {row.x + 12 * s, row.y, std::max(0.f, right - row.x - 12 * s), row.h}));
            text(lz, {row.x + 12 * s, row.y + 9 * s, tw(name) + s, F}, name, ink);
            clipTo(saved);
        };
        float y = listBox.y - listScroll;
        clipTo(listBox);

        for (int p = 0; p < count; ++p, y += rowH + gap) {
            const Box row{listBox.x, y, listBox.w, rowH}, shown = PresetIntersect(row, listBox);
            if (shown.w <= 0 || shown.h <= 0)
                continue;
            const auto& m = RowState(p, cfg);
            rowFrame(row, m, p, p == 0 ? std::string{} : cfg.worldAmbience.profiles[std::size_t(p)].map);

            const Box toggle{row.x + row.w - 12 * s - 45 * s, row.y + std::trunc((rowH - button) * .5f),
                             button, button},
                more{toggle.x + button + 5 * s, toggle.y, button, button};
            iconButton(toggle, ProfileEnabled(p, cfg) ? 0xF205 : 0xF204,
                       Mix(pal[30], pal[31], m.enabled.value), Motion({toggle, ProfileToggle, p}),
                       m.toggle.value);
            iconButton(more, 0xF141, pal[30], Motion({more, ProfileMenu, p}), m.more.value);
            rowLabel(row, toggle.x - 5 * s, ProfileName(p, cfg), Mix(pal[14], pal[2], m.ink.value));
            profileRows[std::size_t(p)] = shown;
            profileToggles[std::size_t(p)] = PresetIntersect(toggle, listBox);
            profileMenus[std::size_t(p)] = PresetIntersect(more, listBox);
            if (open) {
                hit(row, Profile, p);
                hit(toggle, ProfileToggle, p);
                hit(more, ProfileMenu, p);
            }
        }
        if (adding) {
            const Box row{listBox.x, y, listBox.w, rowH}, shown = PresetIntersect(row, listBox);
            if (shown.w > 0 && shown.h > 0) {
                const auto& m = RowState(-1, cfg);
                rowFrame(row, m, -1, currentMap);

                const std::u32string icon(1, char32_t(0xE5C2)),
                    caption = U"   " + Label("visuals_world_miscellaneous_ambience_add");
                const float iw = tw(icon, 3), cw = tw(caption);
                const Box b{row.x + row.w - 12 * s - (iw + cw + 12 * s),
                            row.y + std::trunc((rowH - button) * .5f), iw + cw + 12 * s, button};
                const float t = Motion({b, Add, -1, 1});
                rect(lz, b, alpha(pal[33], .4f * t), 6 * s);
                const Color ink = alpha(pal[2], .7f + .3f * t);
                const float ty = b.y + std::trunc((b.h - F) * .5f);
                text(lz, {b.x + 6 * s, ty, iw + s, F}, icon, ink, 3);
                text(lz, {b.x + 6 * s + iw, ty, cw + s, F}, caption, ink);
                rowLabel(row, b.x - 5 * s, MapLabel(currentMap), Mix(pal[14], pal[2], m.ink.value));
                addRow = shown;
                addButton = PresetIntersect(b, listBox);
                if (open) {
                    hit(row, Add, -1, 0);
                    hit(b, Add, -1, 1);
                }
            }
        }
        unclip();
        if (listMaxScroll > 0) {
            const float th = std::max(10 * s, listBox.h * listBox.h / (listBox.h + listMaxScroll));
            rect(oz,
                 {listBox.x + listBox.w + 3 * s, listBox.y + (listBox.h - th) * listScroll / listMaxScroll,
                  4 * s, th},
                 pal[18], 4 * s);
        }
    }

    body = {rightX, y0, std::max(0.f, rightR - rightX), std::max(0.f, bottom - y0)};
    std::vector<int> rootRows;
    for (int i : Children(-1))
        if (Visible(i, cfg))
            rootRows.push_back(i);
    const float rootCard = GroupCardHeight(int(rootRows.size()), F, s);
    maxScroll = std::max(0.f, hf + 5 * s + rootCard - body.h);
    scroll = std::clamp(scroll, 0.f, maxScroll);
    acceptingColors = open;
    {
        const int bz = layer(body);
        const float y = body.y - scroll;
        clipTo(body);
        text(bz, {body.x + 14 * s, y, std::max(0.f, body.w - 28 * s), hf},
             upper(Label("group_visuals_world_miscellaneous_ambience_effects")), pal[3], 0, 10);
        const Box card{body.x, y + hf + 5 * s, body.w, rootCard};
        shape(bz, card);
        const Box cardClip = PresetIntersect(body, card);
        for (int n = 0; n < int(rootRows.size()); ++n) {
            const Box row{card.x + 14 * s, card.y + 7 * s + float(n) * GroupRowPitch(F, s), card.w - 28 * s,
                          H};
            clipTo(cardClip);
            if (n) {
                const Box sep = GroupRowSeparator(row, s);
                line(bz, sep.x, sep.y, sep.w);
            }
            outerRow(rootRows[std::size_t(n)], bz, row, n, int(rootRows.size()), open);
        }
        unclip();
    }
    if (maxScroll > 0) {
        const float th = std::max(10 * s, body.h * body.h / (body.h + maxScroll));
        rect(oz, {rightR + 5 * s, body.y + (body.h - th) * scroll / maxScroll, 4 * s, th}, pal[18], 4 * s);
    }
    searchLayerStart = paint.layers.size();
    for (auto& entry : transitions)
        if (entry.first < 1000 && !TransitionActive(entry.first) && entry.second.motion.value > .001f) {
            auto from = paint.layers.size();
            paint.layers.insert(paint.layers.end(), entry.second.cached.begin(), entry.second.cached.end());
            fadeLayers(from, entry.second.motion.value);
        }
    if (open && context >= 0) {
        for (const auto& parent : contextParents)
            drawWindow(parent.index, parent.anchor, false);
        drawWindow(context, contextAnchor, true);
    }

    if (open && color >= 0) {
        for (auto& f : colorParents)
            drawColor(f.slot, f.count, f.anchor, f.picker, false);
        drawColor(color, colorCount, colorAnchor, picker, true);
    }
    if (open && choice >= 0) {
        auto from = paint.layers.size();
        auto opts = Options(choice);
        float w = choiceBox.w;
        for (const auto& t : opts)
            w = std::max(w, tw(t) + 38 * s);
        Box b = PresetPopupFit(
            {choiceBox.x + choiceBox.w + 7 * s, choiceBox.y, w, 14 * s + R * float(opts.size())}, width,
            height);
        hit({0, 0, float(width), float(height)}, Surface);
        int qz = surface(b);
        hit(b, Surface);
        for (int n = 0; n < int(opts.size()); ++n) {
            Box row{b.x + 7 * s, b.y + 7 * s + float(n) * R, b.w - 14 * s, R};
            Hit h{row, Option, choice, n};
            rect(qz, row, alpha(pal[33], .4f * Motion(h)), 15 * s / 1.6f);
            text(qz, {row.x + 12 * s, row.y + 7 * s, row.w - 24 * s, F}, opts[std::size_t(n)],
                 int(std::lround(values.value[std::size_t(choice)])) == n ? pal[2] : pal[14]);
            hit(row, Option, choice, n);
        }
        rememberTransition(1000 + choice, from);
    }
    if (open && menu < 0 && choice < 0 && editing < 0)
        for (std::size_t i = 0; i < N; ++i) {
            auto b = sliders[i];
            float a = sliderTip[i].value;
            if (b.w <= 0 || a <= .001f || !Enabled(int(i), cfg) || sliderSurface[i] != TopSurface() ||
                !SurfaceBody().Contains(b.x, b.y + b.h * .5f))
                continue;
            auto label = ValueText(int(i), cfg);
            float w = tw(label), t = (values.value[i] - AmbienceSpecs[i].minimum) /
                                     (AmbienceSpecs[i].maximum - AmbienceSpecs[i].minimum);
            Box tip = PresetPopupFit(
                {b.x + b.w * t - w * .5f - 7 * s, b.y - F - 14 * s, w + 14 * s, F + 9 * s}, width, height);
            int tz = layer(tip, false, 8 * s);
            rect(tz, tip, alpha(pal[8], a), 8 * s);
            rect(tz, tip, alpha(pal[11], a), 8 * s, s);
            text(tz, {tip.x + 7 * s, tip.y + 4 * s, w, F}, label, alpha(pal[0], a));
        }

    {
        int tip = TipIndex(cfg);
        if (tip >= 0 && hoverSeconds >= .3f && rows[std::size_t(tip)].w > 0) {
            lastTip = WorldDescriptionTooltip(fonts, cfg, rows[std::size_t(tip)], RowLabel(tip),
                                              Label(AmbienceSpecs[std::size_t(tip)].tooltip), width, height);
            tipStored = true;
        }
        if (tipStored && tipFade.value > .001f)
            AppendWorldTooltip(paint, lastTip, tipFade.value);
    }

    {
        int tip = NameTipIndex();
        if (tip >= 0 && hoverSeconds >= .3f && tip < int(profileToggles.size()) &&
            profileToggles[std::size_t(tip)].w > 0) {
            lastNameTip = WorldNameTooltip(fonts, cfg, profileToggles[std::size_t(tip)], Label("enabled"),
                                           width, height);
            nameTipStored = true;
        }
        if (nameTipStored && nameTipFade.value > .001f)
            AppendWorldTooltip(paint, lastNameTip, nameTipFade.value);
    }

    if (open && menu >= 0) {
        const auto from = paint.layers.size();
        const auto actions = MenuActions(menu);
        float w = 0, h = 14 * s;
        for (int a : actions) {
            if (a < 0) {
                h += 7 * s;
                continue;
            }
            w = std::max(w, tw(Label(MenuKey(a))) + 56 * s);
            h += R;
        }
        menuBox = PresetPopupFit({menuAnchor.x, menuAnchor.y, w + 14 * s, h}, width, height);
        hit({0, 0, float(width), float(height)}, Surface);
        const int mz = surface(menuBox);
        hit(menuBox, Overlay);
        const Color red{.86f, .39f, .38f, 1};
        float my = menuBox.y + 7 * s;
        for (int a : actions) {
            if (a < 0) {
                line(mz, menuBox.x + 10 * s, my + 3 * s, menuBox.w - 20 * s, true);
                my += 7 * s;
                continue;
            }
            const Box item{menuBox.x + 7 * s, my, menuBox.w - 14 * s, R};
            const float t = Motion({item, MenuItem, menu, a});
            rect(mz, item, alpha(pal[33], .4f * t), 15 * s / 1.6f);
            const Color ink = a == MenuReset || a == MenuDelete ? red : Mix(pal[14], pal[2], t);
            const std::u32string g(1, MenuIcon(a));
            const float iw = tw(g, 3);
            text(mz, {item.x + 12 * s + std::trunc((20 * s - iw) * .5f), item.y + 7 * s, iw + s, F}, g, ink,
                 3);
            text(mz, {item.x + 44 * s, item.y + 7 * s, std::max(0.f, item.w - 44 * s), F}, Label(MenuKey(a)),
                 ink);
            hit(item, MenuItem, menu, a);
            my += R;
        }
        rememberTransition(3000, from);
    }
    for (std::size_t i = begin; i < paint.layers.size(); ++i) {
        paint.layers[i].opacity *= popupFade.value;
        for (auto& d : paint.layers[i].draw)
            d.color.a *= popupFade.value;
    }
    for (auto& entry : transitions)
        if (entry.first >= 1000 && !TransitionActive(entry.first) && entry.second.motion.value > .001f) {
            auto from = paint.layers.size();
            paint.layers.insert(paint.layers.end(), entry.second.cached.begin(), entry.second.cached.end());
            fadeLayers(from, entry.second.motion.value * popupFade.value);
        }
    for (auto& l : paint.layers)
        l.clipToPage = false;
    if (!open || blocked)
        hits.clear();
}
}
