#pragma once

namespace menu {
inline std::u32string ProfileLabel(const std::string& key) {
    if (key == "menu_user_license")
        return U"Till";
    if (key == "menu_user_license_lifetime")
        return U"Lifetime";
    if (key == "menu_user_license_renew")
        return U"Renew";
    if (key == "menu_user_language")
        return U"Language";
    if (key == "menu_user_language_edit")
        return U"Edit";
    if (key == "menu_user_language_delete")
        return U"Delete";
    if (key == "menu_user_language_delete_prompt_title")
        return U"Delete Language";
    if (key == "menu_user_language_delete_prompt")
        return U"Are you sure you want to remove the {language} language?";
    if (key == "menu_user_language_communitylocalization")
        return U"This localization is maintained by the community and is %s%.0f%%%s complete";
    if (key == "menu_user_language_new")
        return U"Create Custom";
    if (key == "menu_user_language_new_title")
        return U"Create Custom Language";
    if (key == "menu_user_language_new_name")
        return U"Name";
    if (key == "menu_user_language_new_name_cantbeempty")
        return U"Name cannot be empty.";
    if (key == "menu_user_language_new_shortname")
        return U"Short Name";
    if (key == "menu_user_language_new_shortname_cantbemepty")
        return U"Short name cannot be empty.";
    if (key == "menu_user_language_new_shortname_exists")
        return U"Language with this short name already exists.";
    if (key == "menu_user_language_new_localizedname")
        return U"Localized Name";
    if (key == "menu_user_language_new_localizedname_cantbeempty")
        return U"Localized name cannot be empty.";
    if (key == "menu_user_language_new_baselanguage")
        return U"Base Language";
    if (key == "menu_user_language_new_create")
        return U"Create";
    if (key == "menu_user_language_new_cancel")
        return U"Cancel";
    if (key == "menu_user_menuscale")
        return U"Menu Scale";
    if (key == "menu_user_menuscale_auto")
        return U"Auto";
    if (key == "menu_user_menuscale_75")
        return U"75%";
    if (key == "menu_user_menuscale_100")
        return U"100%";
    if (key == "menu_user_menuscale_125")
        return U"125%";
    if (key == "menu_user_menuscale_150")
        return U"150%";
    if (key == "menu_user_menuscale_175")
        return U"175%";
    if (key == "menu_user_menuscale_200")
        return U"200%";
    if (key == "menu_user_espscale")
        return U"ESP Scale";
    if (key == "menu_user_windowsscale")
        return U"Windows Scale";
    if (key == "menu_user_units")
        return U"Units";
    if (key == "menu_user_units_auto")
        return U"Auto";
    if (key == "menu_user_units_metric")
        return U"Metric";
    if (key == "menu_user_units_imperial")
        return U"Imperial";
    if (key == "menu_user_style")
        return U"Style";
    if (key == "menu_user_safemode")
        return U"Safe Mode";
    if (key == "menu_user_safemode_disabled")
        return U"Disabled";
    if (key == "menu_user_safemode_automatic")
        return U"Automatic";
    if (key == "menu_user_safemode_forcedon")
        return U"Forced On";
    if (key == "menu_user_safemode_tooltip")
        return U"Disables unsafe features on Valve servers.\nThis feature will be re-enabled after "
               U"restarting the game.\n\nWarning: We strongly do not recommend disabling this feature to "
               U"avoid getting banned.";
    if (key == "menu_user_synchronization")
        return U"Synchronization";
    if (key == "menu_user_synchronization_tooltip")
        return U"Allows you to recognize other Neverlose users in matches and use a shared skin "
               U"changer.\n\nIf this checkbox is enabled, other Neverlose users will also beable to see "
               U"your skins and cheat.";
    if (key == "menu_user_developermode")
        return U"Developer Mode";
    if (key == "window_about")
        return U"About";
    if (key == "window_chat")
        return U"Chat";
    return ASCII(key);
}
}
