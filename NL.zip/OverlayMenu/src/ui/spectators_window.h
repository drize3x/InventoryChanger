#pragma once
#include "hotkey_window.h"
#include "players_name_avatar.h"
#include "spectators_engine.h"
namespace menu {

struct SpectatorAvatarRasters {
    struct Entry {
        std::shared_ptr<const ProfileImage> source;
        int size = 0, radius = 0;
        std::shared_ptr<const Canvas> raster;
        std::uint64_t stamp = 0;
    };
    std::vector<Entry> entries;

    const Entry* Get(const std::shared_ptr<const ProfileImage>& image, int size, int radius) {
        if (!PlayersNameAvatar::Valid(image.get()) || size < 2 || size > 512)
            return nullptr;
        for (const auto& e : entries)
            if (e.source == image && e.size == size && e.radius == radius)
                return &e;
        if (entries.size() >= 64)
            entries.erase(entries.begin());
        auto c = std::make_shared<Canvas>(size, size);
        DrawImage(*c, *image, {0, 0, float(size), float(size)});
        const float half = float(size) * .5f, r = std::min(float(radius), half);
        for (int y = 0; y < size; ++y)
            for (int x = 0; x < size; ++x) {
                const float qx = std::max(std::abs(float(x) + .5f - half) - (half - r), 0.f),
                            qy = std::max(std::abs(float(y) + .5f - half) - (half - r), 0.f);
                const float coverage = std::clamp(.5f - (std::hypot(qx, qy) - r), 0.f, 1.f);
                for (int k = 0; k < 4; ++k) {
                    auto& b =
                        c->rgba[4 * (std::size_t(y) * std::size_t(size) + std::size_t(x)) + std::size_t(k)];
                    b = static_cast<unsigned char>(std::lround(float(b) * coverage));
                }
            }
        std::uint64_t stamp = 14695981039346656037ull;
        for (auto b : c->rgba) {
            stamp ^= b;
            stamp *= 1099511628211ull;
        }
        entries.push_back({image, size, radius, c, stamp});
        return &entries.back();
    }
};
struct SpectatorsWindow {
    struct Row {
        std::uint32_t slot = 0;
        std::u32string name;
        std::uint8_t team = 0;
        std::uint64_t steamID = 0;
        std::shared_ptr<const ProfileImage> avatar;
        PresetMotion reveal;
        bool live = false;
    };
    std::vector<Row> rows;
    PresetMotion visibility, titleReveal;
    SpectatorAvatarRasters rasters;
    Box header{}, bounds{};
    float delta = 0, stale = 0, sampleElapsed = 0;
    bool menuVisible = false, dragging = false, positioned = false, hasPending = false;
    SpectatorsFrame pending;
    float positionX = 0, positionY = 0, grabX = 0, grabY = 0;
    SpectatorsWindow() {
        visibility.Snap(0);
        titleReveal.Snap(0);
    }

    void Tick(float dt) {
        delta = std::max(0.f, std::isfinite(dt) ? dt : 0.f);
    }

    static Color AccentColor(int team, float alpha) {
        if (team == 2)
            return {235.f / 255.f, 210.f / 255.f, 140.f / 255.f, alpha};
        if (team == 3)
            return {180.f / 255.f, 210.f / 255.f, 240.f / 255.f, alpha};
        return {230.f / 255.f, 230.f / 255.f, 230.f / 255.f, alpha};
    }
    static constexpr float AccentAlpha = .862745f;

    void Update(SpectatorsFrame frame) {
        pending = std::move(frame);
        hasPending = true;
    }

    void Apply(const SpectatorsFrame& frame, float dt) {
        if (!frame.valid && frame.transient && stale < .5f) {
            stale += dt;
            return;
        }
        stale = frame.valid ? 0.f : .5f;
        for (auto& row : rows)
            row.live = false;
        if (!frame.valid)
            return;
        for (const auto& e : frame.entries) {
            auto it =
                std::find_if(rows.begin(), rows.end(), [&](const Row& row) { return row.slot == e.slot; });
            if (it == rows.end()) {
                Row row;
                row.slot = e.slot;
                row.reveal.Snap(0);
                rows.push_back(std::move(row));
                it = std::prev(rows.end());
            }
            const auto name = DecodeUTF8(e.name);
            if (it->steamID != e.steamID || (!e.steamID && it->name != name))
                it->avatar.reset(); // slot reuse must not retain another player's face
            it->live = true;
            it->name = name;
            it->team = e.team;
            it->steamID = e.steamID;
            if (e.avatar)
                it->avatar = e.avatar;
        }
    }
    bool Pointer(float x, float y, bool down) {
        if (!down) {
            const bool consumed = dragging;
            dragging = false;
            return consumed;
        }
        if (!menuVisible || visibility.value <= 0 || titleReveal.value <= 0 || !header.Contains(x, y))
            return false;
        dragging = true;
        positioned = true;
        grabX = x - header.x;
        grabY = y - header.y;
        return true;
    }
    void Move(float x, float y) {
        if (x < 0 || y < 0) {
            dragging = false;
            return;
        }
        if (dragging) {
            positionX = x - grabX;
            positionY = y - grabY;
        }
    }
    std::size_t LiveCount() const {
        std::size_t n = 0;
        for (const auto& row : rows)
            n += row.live ? 1 : 0;
        return n;
    }
    template <class Label>
    void Measure(PresetsUI& paint, Fonts& fonts, const Settings& cfg, int viewportW, int viewportH, bool menu,
                 Label&& label) {
        menuVisible = menu;
        const float dt = delta;
        delta = 0;
        const bool enabled = HotkeySetting(cfg, "spectators") != 0;
        sampleElapsed += dt;
        if (hasPending) {
            if (enabled)
                Apply(pending, sampleElapsed);
            sampleElapsed = 0;
            pending = SpectatorsFrame{};
            hasPending = false;
        }
        if (!enabled)
            for (auto& row : rows)
                row.live = false;
        for (auto& row : rows)
            row.reveal.Tick(row.live ? 1.f : 0.f, dt);
        visibility.Tick(enabled && (menu || LiveCount() > 0) ? 1.f : 0.f, dt);
        titleReveal.Tick(enabled && menu ? 1.f : 0.f, dt);
        rows.erase(std::remove_if(rows.begin(), rows.end(),
                                  [](const Row& row) { return !row.live && row.reveal.value <= 0; }),
                   rows.end());
        if (!menu || !enabled)
            dragging = false;
        if (visibility.value <= 0 || viewportW <= 0 || viewportH <= 0) {
            header = {};
            bounds = {};
            return;
        }
        const float s = ScreenWindowScale(cfg), hp = 13 * s;
        const float fh = fonts.PixelHeight(2, hp), headerH = fh + 8 * s;
        const auto title = label("window_spectatorlist");
        const std::u32string icon(1, char32_t(0xf06e));
        const float iw = HotkeyWindow::TextWidth(fonts, 3, hp, icon),
                    tw = HotkeyWindow::TextWidth(fonts, 2, hp, title);
        const float width = 18 * s + iw + 12 * s + s + tw;
        const float plateH = 6 * s + fh, step = plateH + 8 * s;
        float rowsH = 0;
        for (const auto& row : rows)
            rowsH += step * row.reveal.value;
        const float winH = headerH + 6 * s + rowsH;
        float x = positioned ? positionX : float(viewportW) - 10 * s - width,
              y = positioned ? positionY : (float(viewportH) - winH) * .5f;
        x = std::clamp(x, 0.f, std::max(0.f, float(viewportW) - std::min(width, float(viewportW))));
        y = std::clamp(y, 0.f, std::max(0.f, float(viewportH) - std::min(winH, float(viewportH))));
        x = std::trunc(x);
        y = std::trunc(y);
        if (positioned) {
            positionX = x;
            positionY = y;
        }
        header = {x, y, width, headerH};
        const float a = visibility.value, h = titleReveal.value, right = x + width;
        float minX = x;
        for (const auto& row : rows) {
            const float tw2 = HotkeyWindow::TextWidth(fonts, 2, hp, row.name);
            minX = std::min(minX, right - (plateH + tw2 + 12 * s) - 8 * s - 3 * s);
        }
        const float margin = 24 * s;
        bounds = PresetIntersect({minX - margin, y - margin, right - minX + 2 * margin, winH + 2 * margin},
                                 {0, 0, float(viewportW), float(viewportH)});
        PresetLayer layer{bounds, 0, true, {}};
        layer.opacity = a;
        layer.nativeHUDScale = s;
        auto pal = CurrentPalette(cfg);
        if (h > 0) {

            auto fill = pal[45];
            fill.a *= a * h;
            auto shadow = pal[38];
            shadow.a *= a * h;
            HotkeyWindow::Rect(layer, header, fill, 16 * s, 0, a * h, 18 * s, shadow);
            auto border = fill;
            border.a *= .2f;
            HotkeyWindow::Rect(layer, header, border, 16 * s, 1);
            auto accent = pal[31];
            accent.a *= a * h;
            auto titleColor = pal[4];
            titleColor.a *= a * h;
            HotkeyWindow::Text(layer, cfg, {x + 9 * s, y + 4 * s, iw, fh}, icon, accent, 2, hp, true);
            const float sepX = x + 9 * s + iw + 6 * s;
            HotkeyWindow::Rect(layer, {sepX, y + 4 * s, s, fh}, border);
            HotkeyWindow::Text(layer, cfg, {sepX + 7 * s, y + 4 * s, tw, fh}, title, titleColor, 2, hp);
        }
        float curY = y + headerH + 6 * s;
        for (const auto& row : rows) {
            const float reveal = row.reveal.value, alpha = a * reveal;
            const float tw2 = HotkeyWindow::TextWidth(fonts, 2, hp, row.name), side = plateH,
                        plateW = side + tw2 + 12 * s;
            const float plateX = std::round(right - plateW - 8 * s * (1 - reveal)), py = std::round(curY);
            if (alpha > 0) {

                auto fill = pal[45];
                fill.a *= alpha;
                auto shadow = pal[38];
                shadow.a *= alpha * .75f;
                HotkeyWindow::Rect(layer, {plateX - 1.5f * s, py, plateW + 1.5f * s, plateH}, fill, 10 * s, 0,
                                   alpha, 10, shadow);

                // Dump 0x622490..0x622540 -> helper 0x968F00: 3px gradient
                // line, 8px requested radius, 10px glow and .75 glow alpha.
                HotkeyWindow::Rect(layer, {plateX - 3 * s, py, 3 * s, plateH},
                                   AccentColor(row.team, alpha * AccentAlpha), 8 * s);
                layer.draw.back().indicatorLine = true;
                layer.draw.back().indicatorGlow = 10 * s;
                const float avatarX = plateX + plateW - side;
                if (const auto* raster =
                        rasters.Get(row.avatar, int(std::ceil(side)), int(std::lround(10 * s)))) {
                    PresetDraw d{{avatarX, py, side, side},
                                 {1, 1, 1, std::clamp(alpha, 0.f, 1.f)},
                                 0,
                                 0,
                                 15,
                                 {},
                                 false};
                    d.raster = raster->raster;
                    d.rasterStamp = raster->stamp;
                    d.clipped = true;
                    d.clip = bounds;
                    layer.draw.push_back(std::move(d));
                }
                auto ink = pal[4];
                ink.a *= alpha;
                HotkeyWindow::Text(layer, cfg, {avatarX - 6 * s - tw2, py + 3 * s, tw2, fh}, row.name, ink, 2,
                                   hp);
            }
            curY += step * reveal;
        }
        for (auto& d : layer.draw)
            if (!d.text.empty())
                d.clip = PresetIntersect(d.clip, bounds);
        paint.layers.push_back(std::move(layer));
    }
};
}
