#pragma once
#include "group_row_geometry.h"
#include "weapon_presets_layout.h"
#include "players_remaining_preview.h"
#include "hud_color_picker.h"
#include "world_tooltip.h"
#include "keybind_ui.h"
#include <sstream>
#include <iomanip>
namespace menu {

struct RageUI {
    enum Action {
        Surface = 0,
        Toggle,
        Slider,
        Select,
        Option,
        Open,
        ColorPoint,
        Bind,
        WeaponPanel,
        WeaponSelect,
        CreateGroup,
        RenameGroup,
        DeleteGroup,
        GroupMask,
        MaskOption,
        TextField,
        ResetGroup,
        RowLabel,
        CreateMenu,
        RestoreGroup,
        EquipmentOption,
        NumericValue
    };
    struct Hit {
        Box box{};
        Action action = Surface;
        int field = -1, option = -1;
        Box control{};
        int Key() const {
            return int(action == RowLabel && field >= 0 ? Slider : action) * 100000 + (field + 3) * 64 +
                   option + 1;
        }
    };
    PresetsUI paint;
    LanguageCatalog* languages = nullptr;
    std::size_t searchLayerStart = 0;
    HudColorPicker picker;
    KeybindUI* bindings = nullptr;
    std::vector<Hit> hits;
    std::array<Box, RageFieldCount> rows{}, sliders{}, valueBoxes{};
    std::array<Box, 4> cards{};
    struct Marquee {
        float offset = 0, hoverTime = 0, overflow = 0, fullWidth = 0;
        int stableFrames = 0;
        PresetMotion returning;
    };
    std::map<int, Marquee> marquees;
    int hoverField = -1;
    std::array<PresetMotion, RageFieldCount> markerMotion{};
    std::array<PresetMotion, 11> popupMarkers{};
    int placedChoice = -1;
    Box placedChoiceBox{};

    std::map<int, PresetMotion> buttonFill, buttonInk;
    struct WeaponReveal {
        RageWeaponPreset snapshot;
        PresetMotion amount, height;
        float targetHeight = 0;
        int order = 0;
    };
    struct WeaponChip {
        std::string group, name;
        PresetMotion x, y, amount;
        float tx = 0, ty = 0, w = 0;
        bool active = false;
    };
    std::map<std::string, WeaponChip> weaponChips;
    Box AnimatedChip(const std::string& group, const std::string& name, Box target) {
        auto key = group + "/" + name;
        auto [it, inserted] = weaponChips.try_emplace(key);
        auto& c = it->second;
        if (inserted) {
            c.group = group;
            c.name = name;
            c.x.Snap(target.x);
            c.y.Snap(target.y);
            c.amount.Snap(1);
        }
        c.active = true;
        c.tx = target.x;
        c.ty = target.y;
        c.w = target.w;
        return {c.x.value, c.y.value, target.w, target.h};
    }
    std::map<std::string, WeaponReveal> weaponReveal;
    bool weaponRevealReady = false;
    void SyncWeaponReveal(const Settings& cfg) {
        for (std::size_t i = 0; i < cfg.rage.weapons.size(); ++i) {
            const auto& p = cfg.rage.weapons[i];
            auto [it, inserted] = weaponReveal.try_emplace(p.id);
            auto& r = it->second;
            if (inserted)
                r.amount.Snap(weaponRevealReady && weaponOpen ? 0.f : (p.active ? 1.f : 0.f));
            r.snapshot = p;
            r.order = int(i);
        }
        weaponRevealReady = true;
    }
    bool ButtonOpen(const Hit& h) const {
        return (h.action == WeaponPanel && weaponOpen) ||
               (h.action == CreateMenu && weaponOpen && createMenu) ||
               (h.action == GroupMask && weaponOpen && maskGroup == h.option);
    }
    void TickWeapon(float dt, const Settings& cfg, int over) {
        SyncWeaponReveal(cfg);
        for (auto& kv : weaponReveal) {
            bool active = false;
            for (const auto& p : cfg.rage.weapons)
                if (p.id == kv.first) {
                    active = p.active;
                    break;
                }
            kv.second.amount.Tick(active ? 1.f : 0.f, dt);
            if (kv.second.height.initialized)
                kv.second.height.Tick(kv.second.targetHeight, dt);
        }
        for (auto& kv : weaponChips) {
            auto& c = kv.second;
            c.x.Tick(c.tx, dt);
            c.y.Tick(c.ty, dt);
            c.amount.Tick(c.active ? 1.f : 0.f, dt);
        }
        for (const auto& h : hits)
            if (h.action == CreateMenu || h.action == GroupMask || h.action == DeleteGroup ||
                h.action == WeaponPanel) {
                auto k = h.Key();
                if (!buttonFill[k].initialized)
                    buttonFill[k].Snap(0);
                if (!buttonInk[k].initialized)
                    buttonInk[k].Snap(0);
            }
        for (auto& kv : buttonFill) {
            bool open = false;
            for (const auto& h : hits)
                if (h.Key() == kv.first)
                    open = ButtonOpen(h);
            bool heldHere = !blocked && held == kv.first, hoverHere = !blocked && over == kv.first;
            kv.second.Tick(heldHere ? 1.f : (hoverHere || open) ? .5f : 0.f, dt);
            buttonInk[kv.first].Tick(heldHere || open ? 1.f : hoverHere ? .5f : 0.f, dt);
        }
    }
    std::map<int, PresetMotion> hoverMotion;
    std::array<PresetMotion, RageFieldCount> checkMotion{};
    struct WindowTransition {
        PresetMotion motion;
        std::vector<PresetLayer> cached;
    };
    std::map<int, WindowTransition> transitions;
    std::set<int> drawnWindows;
    std::array<PresetMotion, RageFieldCount> sliderTip{}, availability{};
    PresetMotion popupMotion, choiceMotion, tooltipMotion;
    PresetLayer lastTooltip{};
    bool tooltipStored = false;
    bool visible = false, blocked = false, headerOnly = false, weaponOpen = false, selectAll = false,
         renaming = false;
    bool createMenu = false, weaponFollowEnd = false, weaponPositionReady = false;
    Box weaponOpenPosition{};
    PlayersRemainingPreview weaponIcons;
    int weaponContext = -1;
    Box weaponContextAnchor{};
    int popup = -1, choice = -1, color = -1, editing = -1, capture = -1, focus = -1, held = -1, drag = -1,
        hover = -1, maskGroup = -1, renameGroup = -1;
    unsigned wheelLines = 3;
    float createTarget = 0, maskTarget = 0, weaponTarget = 0;
    Box maskOpenPoint{}, maskBox{}, createBox{};
    float createScroll = 0, createMax = 0;
    float maskScroll = 0, maskMax = 0;
    float scale = 1, F = 13, mouseX = -1, mouseY = -1, hoverTime = 0, scroll = 0, maxScroll = 0,
          popupScroll = 0, popupMax = 0, weaponScroll = 0, weaponMax = 0;
    Box viewport{}, pageBody{}, headerBox{}, popupBox{}, popupBody{}, choiceBox{}, weaponBox{}, weaponBody{},
        anchor{}, choiceAnchor{}, colorAnchor{}, nameBox{};
    std::string numeric;
    std::u32string groupName;
    char16_t highSurrogate = 0;
    PresetEditor nameEditor;
    std::string error;
    std::u32string Label(const std::string& k) const {
        if (k.empty())
            return {};
        if (k[0] == '@')
            return DecodeUTF8(k.substr(1));
        if (languages)
            return languages->Label(k);
        auto it = DefaultLanguageStrings().find(k);
        return DecodeUTF8(it == DefaultLanguageStrings().end() ? k : it->second);
    }
    static std::u32string Upper(std::u32string v) {
        for (auto& c : v)
            if (c >= 'a' && c <= 'z')
                c -= 32;
        return v;
    }
    std::u32string WeaponName(const RageValues& r, int i) const {
        if (i < 0 || std::size_t(i) >= r.weapons.size())
            return Label("aimbot_panel_weaponpresets_group_global");
        const auto& p = r.weapons[std::size_t(i)];
        return p.name.empty() ? Label("aimbot_panel_weaponpresets_group_" + p.id) : DecodeUTF8(p.name);
    }
    std::vector<std::u32string> Options(int i) const {
        std::vector<std::u32string> out;
        std::istringstream stream(RageSpecs[std::size_t(i)].options);
        std::string part;
        while (std::getline(stream, part, '|'))
            out.push_back(Label(part));
        return out;
    }
    static bool FieldHit(Action a) {
        return a == Toggle || a == NumericValue || a == Slider || a == Select || a == Open ||
               a == ColorPoint || a == Bind || a == RowLabel;
    }
    bool searchChoiceAnchor = false;
    Box searchChoiceBox{};
    bool Active() const {
        return popup >= 0 || choice >= 0 || weaponOpen || color >= 0 || capture >= 0;
    }
    bool Capturing() const {
        return held >= 0 || drag >= 0 || capture >= 0 || picker.held >= 0;
    }
    bool Editing() const {
        return editing >= 0 || renaming || capture >= 0 || color >= 0;
    }
    void CancelInput() {
        held = drag = -1;
        picker.held = -1;
    }
    void Close() {
        searchChoiceAnchor = false;
        weaponPositionReady = false;
        placedChoice = -1;
        createMenu = false;
        weaponContext = -1;
        popup = choice = color = editing = capture = maskGroup = -1;
        weaponOpen = renaming = false;
        weaponFollowEnd = false;
        renameGroup = -1;
        numeric.clear();
        error.clear();
        CancelInput();
    }
    void Hide() {
        Close();
        transitions.clear();
        buttonFill.clear();
        buttonInk.clear();
        weaponReveal.clear();
        weaponChips.clear();
        weaponRevealReady = false;
        visible = false;
        hits.clear();
        paint.layers.clear();
        hover = -1;
        hoverTime = 0;
        tooltipStored = false;
        tooltipMotion.Snap(0);
        popupMotion.Snap(0);
        choiceMotion.Snap(0);
    }
    int HitAt(float x, float y) const {
        if (!visible || blocked)
            return -1;
        for (int i = int(hits.size()) - 1; i >= 0; --i)
            if (hits[std::size_t(i)].box.Contains(x, y))
                return i;
        return -1;
    }
    bool FieldVisible(int, const Settings&) const {
        return true;
    }
    bool EnabledField(int i, const Settings& c) const {
        if (!FieldVisible(i, c))
            return false;
        if (i == PitchOffset)
            return c.rage.Get(PitchMode) == 5;
        if (i >= AvoidBackstab && i <= SpinOffset && c.rage.Get(YawMode) == 0)
            return false;
        if (i == MinHitChance)
            return c.rage.Get(ForceShot) != 0;
        if (i == JitterBase || i == JitterDisablers || i == JitterOffset)
            return c.rage.Get(Jitter) != 0;
        if (i == SpinOffset)
            return c.rage.Get(Spin) != 0;
        return true;
    }
    static int Detail(int i) {
        switch (i) {
        case Limiters:
            return 1;
        case QuickPeek:
            return 2;
        case Pitch:
            return 3;
        case Yaw:
            return 4;
        case MouseOverride:
            return 5;
        case HitChance:
            return 7;
        case QuickStop:
            return 8;
        case DelayShot:
            return 9;
        case AntiAimEnabled:
            return 10;
        default:
            return -1;
        }
    }
    static int Root(int p) {
        switch (p) {
        case 1:
            return Limiters;
        case 2:
            return QuickPeek;
        case 3:
            return Pitch;
        case 4:
            return Yaw;
        case 5:
            return MouseOverride;
        case 7:
            return HitChance;
        case 8:
            return QuickStop;
        case 9:
            return DelayShot;
        case 10:
            return AntiAimEnabled;
        default:
            return -1;
        }
    }
    std::string Number(int i, const Settings& c) const {
        std::ostringstream out;
        if (RageSpecs[std::size_t(i)].kind == RageKind::Decimal)
            out << std::fixed << std::setprecision(1);
        out << c.rage.Get(i);
        return out.str();
    }
    std::u32string ValueLabel(int i, const Settings& c) const {
        float n = c.rage.Get(i);
        if (i == AimSpeed && n == 301)
            return Label("ragebot_main_limiters_aimspeed_instant");
        if (i == Extrapolation && n == 0)
            return Label("ragebot_selection_extrapolation_off");
        if (i == MaxDistance && n == 201)
            return Label("ragebot_main_limiters_off");
        if (i == MinDamage && n == 101)
            return U"FL";
        std::string suffix;
        if (i == HitChance || i == MinHitChance)
            suffix = "%";
        else if (i == ReactionTime || i == KillDelay)
            suffix = " ms";
        else if (i == Backtrack)
            suffix = "t";
        else if (i == AimFov || i == FieldOfView || i == PitchOffset || i == YawOffset || i == JitterOffset ||
                 i == SpinOffset)
            suffix = "°";
        return DecodeUTF8(Number(i, c) + suffix);
    }
    void OpenPopup(int p, Box at) {
        if (popup == p) {
            Close();
            return;
        }
        Close();
        popup = p;
        anchor = {at.x + at.w + 7 * scale, at.y, 0, 0};
        popupScroll = 0;
        popupMotion.Snap(0);
    }
    Settings PickerSettings(const Settings& cfg) const {
        Settings c = cfg;
        if (color == 0)
            c.worldHud.colors[4] = cfg.rage.colors[0];
        else if (color == 1) {
            c.worldHud.colors[5] = cfg.rage.colors[1];
            c.worldHud.colors[6] = cfg.rage.colors[2];
        }
        return c;
    }
    void SyncPicker(Settings& cfg, const Settings& c) {
        if (color == 0)
            cfg.rage.colors[0] = c.worldHud.colors[4];
        else if (color == 1) {
            cfg.rage.colors[1] = c.worldHud.colors[5];
            cfg.rage.colors[2] = c.worldHud.colors[6];
        }
    }
    void Tick(float dt, const Settings& cfg) {
        dt = std::max(0.f, dt);
        if (!visible)
            return;
        if (weaponOpen) {
            weaponScroll = WeaponPresetsLayout::ScrollFrame(weaponScroll, weaponTarget, weaponMax, dt);
            if (createMenu)
                createScroll = WeaponPresetsLayout::ScrollFrame(createScroll, createTarget, createMax, dt);
            if (maskGroup >= 0)
                maskScroll = WeaponPresetsLayout::ScrollFrame(maskScroll, maskTarget, maskMax, dt);
        }
        int h = HitAt(mouseX, mouseY);
        int key = h < 0 ? -1 : hits[std::size_t(h)].Key();
        if (key != hover) {
            hover = key;
            hoverTime = 0;
        } else
            hoverTime += dt;
        TickWeapon(dt, cfg, key);
        for (const auto& t : hits)
            hoverMotion.try_emplace(t.Key());
        for (auto& kv : hoverMotion)
            kv.second.Tick(blocked ? 0.f : kv.first == held ? 1.f : kv.first == key ? .5f : 0.f, dt);
        for (int i = 0; i < RageFieldCount; ++i) {
            checkMotion[std::size_t(i)].Tick(cfg.rage.Get(i) != 0 ? 1.f : 0.f, dt);
            markerMotion[std::size_t(i)].Tick(cfg.rage.Get(i) != 0 ? 1.f : 0.f, dt);
        }
        for (int p = 1; p <= 10; ++p) {
            bool any = false;
            for (int i = 0; i < RageFieldCount; ++i)
                if (RageSpecs[std::size_t(i)].popup == p &&
                    RageSpecs[std::size_t(i)].kind == RageKind::Check && cfg.rage.Get(i) != 0)
                    any = true;
            if (p == 8)
                any = cfg.rage.Get(QuickStopOptions) != 0;
            popupMarkers[std::size_t(p)].Tick(any ? 1.f : 0.f, dt);
        }
        int field = h >= 0 ? hits[std::size_t(h)].field : -1;
        if (h >= 0 && (hits[std::size_t(h)].action == Open || hits[std::size_t(h)].action == Surface))
            field = -1;
        for (auto& entry : marquees) {
            auto& m = entry.second;
            bool over = entry.first == field && m.overflow > 0;
            if (over) {
                m.hoverTime = hoverField == field ? m.hoverTime + dt : 0;
                if (m.stableFrames >= 5 && m.hoverTime > .3f) {
                    m.offset += 40 * scale * dt;
                    if (m.offset >= m.fullWidth + 20 * scale)
                        m.offset = m.overflow;
                }
                m.returning.Snap(m.offset);
            } else {
                m.hoverTime = 0;
                m.returning.Tick(0, dt, .25f);
                m.offset = m.returning.value;
            }
        }
        hoverField = field;
        popupMotion.Tick(popup >= 0 || weaponOpen ? 1.f : 0.f, dt);
        choiceMotion.Tick(choice >= 0 ? 1.f : 0.f, dt);
        bool tip = false;
        if (h >= 0) {
            const auto& t = hits[std::size_t(h)];
            tip = (t.action == EquipmentOption && t.field >= 0) || t.action == WeaponPanel ||
                  ((t.action != Open ||
                    RageSpecs[std::size_t(std::max(0, t.field))].kind == RageKind::Opener) &&
                   FieldHit(t.action) && t.field >= 0 && t.field < RageFieldCount &&
                   RageSpecs[std::size_t(t.field)].tooltip[0] != 0);
        }
        tip = tip && hoverTime >= .3f && editing < 0 && color < 0 && choice < 0 && capture < 0;
        tooltipMotion.Tick(tip ? 1.f : 0.f, dt);
        if (color >= 0)
            picker.Tick(dt, !blocked);
        for (auto& w : transitions)
            w.second.motion.Tick(!blocked && TransitionActive(w.first) ? 1.f : 0.f, dt);
        for (int i = 0; i < RageFieldCount; ++i) {
            availability[std::size_t(i)].Tick(EnabledField(i, cfg) ? 1.f : .5f, dt);
            auto b = sliders[std::size_t(i)];
            sliderTip[std::size_t(i)].Tick(!blocked && EnabledField(i, cfg) && choice < 0 && color < 0 &&
                                                   editing < 0 &&
                                                   (drag == i || (b.w > 0 && b.Contains(mouseX, mouseY)))
                                               ? 1.f
                                               : 0.f,
                                           dt);
        }
    }
    void Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        if (!visible || blocked)
            return;
        if (drag >= 0) {
            if (!EnabledField(drag, cfg)) {
                CancelInput();
                return;
            }
            const auto& d = RageSpecs[std::size_t(drag)];
            const auto b = sliders[std::size_t(drag)];
            bool context = d.popup != 0;
            float inset = context ? 0.f
                                  : std::min(std::max(0.f, std::trunc(F * .5f) - 3 * scale),
                                             std::max(0.f, (b.w - 4) * .5f));
            cfg.rage.Set(
                drag, d.minimum +
                          (d.maximum - d.minimum) *
                              std::clamp((x - b.x - inset) / std::max(1.f, b.w - (context ? 1.f : 2 * inset)),
                                         0.f, 1.f));
        }
        if (color >= 0) {
            auto c = PickerSettings(cfg);
            picker.Move(x, y, c);
            SyncPicker(cfg, c);
        }
    }
    bool Commit(Settings& cfg) {
        if (editing < 0)
            return true;
        try {
            std::size_t n = 0;
            float v = std::stof(numeric, &n);
            if (n != numeric.size() || !std::isfinite(v))
                return false;
            if (EnabledField(editing, cfg))
                cfg.rage.Set(editing, v);
            editing = -1;
            numeric.clear();
            return true;
        } catch (...) {
            return false;
        }
    }
    void BeginRename(const Settings& cfg, int i) {
        renameGroup = i;
        groupName = WeaponName(cfg.rage, i);
        renaming = true;
        nameEditor.Reset(groupName, true);
        error.clear();
        highSurrogate = 0;
    }
    bool SaveRename(Settings& cfg) {
        if (renameGroup < 0 || std::size_t(renameGroup) >= cfg.rage.weapons.size()) {
            renaming = false;
            return false;
        }
        if (!PresetName(groupName)) {
            error = "Name must contain 1–128 printable characters";
            return false;
        }
        cfg.rage.weapons[std::size_t(renameGroup)].name = EncodeUTF8(groupName);
        renaming = false;
        renameGroup = -1;
        return true;
    }
    void Activate(const Hit& h, Settings& cfg) {
        if (h.action == Surface) {
            if (createMenu) {
                createMenu = false;
                return;
            }
            if (weaponContext >= 0) {
                weaponContext = -1;
                return;
            }
            if (maskGroup >= 0) {
                maskGroup = -1;
                return;
            }
            if (choice >= 0) {
                choice = -1;
                return;
            }
            Close();
            return;
        }
        if (h.action == WeaponPanel) {
            bool was = weaponOpen;
            Close();
            weaponOpen = !was;
            weaponScroll = weaponTarget = 0;
            popupMotion.Snap(0);
            return;
        }
        if (h.action == WeaponSelect) {
            if (renaming && !SaveRename(cfg))
                return;
            CancelInput();
            editing = capture = choice = -1;
            cfg.rage.selected = h.option;
            return;
        }
        if (h.action == CreateMenu) {
            createMenu = !createMenu;
            createScroll = createTarget = 0;
            maskGroup = -1;
            renaming = false;
            return;
        }
        if (h.action == RestoreGroup) {
            if (h.option >= 0 && std::size_t(h.option) < cfg.rage.weapons.size()) {
                auto& source = cfg.rage.weapons[std::size_t(h.option)];
                if (!source.active) {
                    source.active = true;
                    cfg.rage.selected = h.option;
                } else {
                    unsigned mask = source.weaponMask;
                    std::string name = EncodeUTF8(WeaponName(cfg.rage, h.option));
                    if (cfg.rage.Create(name))
                        cfg.rage.weapons.back().weaponMask = mask;
                }
                weaponScroll = 1e6f;
                weaponFollowEnd = true;
            }
            createMenu = false;
            return;
        }
        if (h.action == EquipmentOption) {
            int group = h.field >= 0 ? h.field : maskGroup;
            if (group >= 0 && std::size_t(group) < cfg.rage.weapons.size()) {
                auto& p = cfg.rage.weapons[std::size_t(group)];
                if (!p.individual) {
                    p.equipment = RageEquipmentNames(p.weaponMask);
                    p.individual = true;
                }
                auto all = RageEquipmentNames(2047);
                if (h.option >= 0 && std::size_t(h.option) < all.size()) {
                    auto it = std::find(p.equipment.begin(), p.equipment.end(), all[std::size_t(h.option)]);
                    if (it == p.equipment.end())
                        p.equipment.push_back(all[std::size_t(h.option)]);
                    else
                        p.equipment.erase(it);
                }
            }
            return;
        }
        if (h.action == CreateGroup) {
            createMenu = false;
            if (cfg.rage.Create(EncodeUTF8(Label("aimbot_panel_weaponpresets_group_defaultname")))) {
                BeginRename(cfg, cfg.rage.selected);
                weaponScroll = 1e6f;
                weaponFollowEnd = true;
            } else
                error = "Maximum 32 custom groups";
            return;
        }
        if (h.action == RenameGroup) {
            weaponContext = -1;
            maskGroup = -1;
            BeginRename(cfg, h.option);
            return;
        }
        if (h.action == DeleteGroup) {
            SyncWeaponReveal(cfg);
            weaponContext = -1;
            cfg.rage.selected = h.option;
            cfg.rage.DeleteSelected();
            renaming = false;
            maskGroup = -1;
            return;
        }
        if (h.action == GroupMask) {
            weaponContext = -1;
            maskGroup = maskGroup == h.option ? -1 : h.option;
            maskScroll = maskTarget = 0;
            maskOpenPoint = {h.box.Contains(mouseX, mouseY) ? mouseX + 1 : h.box.x + h.box.w * .5f + 1,
                             h.box.Contains(mouseX, mouseY) ? mouseY + 1 : h.box.y + h.box.h * .5f + 1, 0, 0};
            return;
        }
        if (h.action == MaskOption) {
            if (maskGroup >= 0 && std::size_t(maskGroup) < cfg.rage.weapons.size()) {
                auto& p = cfg.rage.weapons[std::size_t(maskGroup)];
                p.weaponMask ^= 1u << h.option;
                p.individual = false;
                p.equipment.clear();
            }
            return;
        }
        if (h.action == ResetGroup) {
            if (cfg.rage.selected >= 0)
                for (std::size_t i = 0; i < RageSpecs.size(); ++i)
                    if (RageSpecs[i].group == 1)
                        cfg.rage.weapons[std::size_t(cfg.rage.selected)].value[i] = cfg.rage.value[i];
            return;
        }
        int i = h.field;
        if (i < 0 || i >= RageFieldCount || !EnabledField(i, cfg))
            return;
        if (h.action == NumericValue) {
            editing = i;
            numeric = Number(i, cfg);
            selectAll = true;
            return;
        }
        if (h.action == Open) {
            OpenPopup(h.option, h.box);
            return;
        }
        if (h.action == Toggle)
            cfg.rage.Set(i, cfg.rage.Get(i) == 0 ? 1 : 0);
        if (h.action == Select) {
            searchChoiceAnchor = false;
            choice = choice == i ? -1 : i;
            choiceAnchor = h.control;
            placedChoice = -1;
            choiceMotion.Snap(0);
            return;
        }
        if (h.action == Option) {
            if (RageSpecs[std::size_t(i)].kind == RageKind::Multi)
                cfg.rage.Set(i, float(int(cfg.rage.Get(i)) ^ (1 << h.option)));
            else {
                cfg.rage.Set(i, float(h.option));
                choice = -1;
            }
            return;
        }
        if (h.action == Bind) {
            if (bindings)
                bindings->BeginDirect("rage." + std::string(RageSpecs[std::size_t(i)].id));
            else
                capture = i;
            CancelInput();
            return;
        }
        if (h.action == ColorPoint) {
            color = i == PeekColor ? 0 : 1;
            colorAnchor = h.box;
            picker.Reset(color == 0 ? 4 : 5, false, color == 1);
            if (color == 1)
                picker.ConfigureEntries(2, {{"", "", ""}});
            picker.languages = languages;
            return;
        }
    }
    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        mouseX = x;
        mouseY = y;
        if (capture >= 0)
            return true;
        if (color >= 0) {
            auto c = PickerSettings(cfg);
            bool used = picker.Click(x, y, down, c);
            SyncPicker(cfg, c);
            if (!used && down) {
                color = -1;
                CancelInput();
            }
            return true;
        }
        int n = HitAt(x, y);
        if (down) {
            if (n < 0)
                return false;
            const auto h = hits[std::size_t(n)];
            if (editing >= 0 && !Commit(cfg))
                return true;
            if (renaming && h.action != TextField && !SaveRename(cfg))
                return true;
            held = h.Key();
            focus = held;
            if (h.action == TextField) {
                nameEditor.Mouse(x - nameBox.x - 6 * scale, false);
                return true;
            }
            if ((h.action == Slider || h.action == NumericValue) && EnabledField(h.field, cfg)) {
                if (ctrl || h.action == NumericValue) {
                    editing = h.field;
                    numeric = Number(editing, cfg);
                    selectAll = true;
                } else {
                    drag = h.field;
                    Move(x, y, cfg);
                }
            }
            return true;
        }
        bool used = held >= 0 || drag >= 0;
        if (n >= 0 && held == hits[std::size_t(n)].Key() && drag < 0 && editing < 0)
            Activate(hits[std::size_t(n)], cfg);
        CancelInput();
        return used;
    }
    bool Context(float x, float y, Settings& cfg) {
        if (!visible || blocked)
            return false;
        int n = HitAt(x, y);
        if (n < 0)
            return Active();
        const auto h = hits[std::size_t(n)];
        if (h.action == WeaponSelect && h.option >= 0) {
            BeginRename(cfg, h.option);
            return true;
        }
        int p = Detail(h.field);
        if (p >= 0) {
            OpenPopup(p, h.box);
            return true;
        }
        if (h.field >= 0 && h.field < RageFieldCount &&
            (RageSpecs[std::size_t(h.field)].kind == RageKind::Integer ||
             RageSpecs[std::size_t(h.field)].kind == RageKind::Decimal) &&
            EnabledField(h.field, cfg)) {
            editing = h.field;
            numeric = Number(editing, cfg);
            selectAll = true;
            return true;
        }
        return Active();
    }
    bool Key(int key, Settings& cfg, bool shift = false, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        if (capture >= 0) {
            if (key == 27) {
                capture = -1;
                return true;
            }
            if (key >= 0 && key <= 255) {
                cfg.rage.Set(capture, key == 8 || key == 46 ? 0 : float(key));
                capture = -1;
            }
            return true;
        }
        if (color >= 0) {
            auto c = PickerSettings(cfg);
            if (picker.Key(key, c, ctrl))
                SyncPicker(cfg, c);
            else if (key == 27)
                color = -1;
            return true;
        }
        if (renaming) {
            if (key == 27) {
                renaming = false;
                renameGroup = -1;
                error.clear();
            } else if (key == 13)
                SaveRename(cfg);
            else if (key == 8 || key == 46)
                nameEditor.Delete(groupName, key == 8, ctrl);
            else if (ctrl && key == 'A')
                nameEditor.All(groupName);
            else if (key == 37 || key == 39)
                nameEditor.Move(groupName, key == 37 ? -1 : 1, shift, ctrl);
            else if (key == 36 || key == 35)
                nameEditor.Home(groupName, key == 35, shift);
            return true;
        }
        if (editing >= 0) {
            if (key == 27) {
                editing = -1;
                numeric.clear();
            } else if (key == 13)
                Commit(cfg);
            else if (ctrl && key == 'A')
                selectAll = true;
            else if (key == 8 || key == 46) {
                if (selectAll)
                    numeric.clear();
                else if (!numeric.empty())
                    numeric.pop_back();
                selectAll = false;
            }
            return true;
        }
        if (key == 27 && Active()) {
            if (createMenu)
                createMenu = false;
            else if (weaponContext >= 0)
                weaponContext = -1;
            else if (maskGroup >= 0)
                maskGroup = -1;
            else if (choice >= 0)
                choice = -1;
            else
                Close();
            return true;
        }
        if (key == 9) {
            std::vector<int> v;
            for (const auto& h : hits)
                if (h.action != Surface && h.action != RowLabel && h.action != TextField) {
                    int top = HitAt(h.box.x + h.box.w * .5f, h.box.y + h.box.h * .5f);
                    if (top >= 0 && hits[std::size_t(top)].Key() == h.Key())
                        v.push_back(h.Key());
                }
            if (v.empty())
                return Active();
            auto it = std::find(v.begin(), v.end(), focus);
            int i =
                it == v.end() ? 0 : (int(it - v.begin()) + (shift ? -1 : 1) + int(v.size())) % int(v.size());
            focus = v[std::size_t(i)];
            return true;
        }
        for (const auto& h : hits)
            if (h.Key() == focus) {
                if (h.action == Slider && (key == 37 || key == 39) && EnabledField(h.field, cfg))
                    cfg.rage.Set(
                        h.field,
                        cfg.rage.Get(h.field) +
                            (key == 37 ? -1 : 1) *
                                (RageSpecs[std::size_t(h.field)].kind == RageKind::Decimal ? .1f : 1.f));
                else if (key == 13 || key == 32)
                    Activate(h, cfg);
                else
                    return Active();
                return true;
            }
        return Active();
    }
    bool Character(char16_t c) {
        if (!visible || blocked)
            return false;
        if (color >= 0)
            return picker.Character(c);
        if (renaming) {
            if (c >= 0xd800 && c <= 0xdbff) {
                highSurrogate = c;
                return true;
            }
            char32_t cp = c;
            if (c >= 0xdc00 && c <= 0xdfff) {
                if (!highSurrogate)
                    return true;
                cp = 0x10000 + ((highSurrogate - 0xd800) << 10) + (c - 0xdc00);
            }
            highSurrogate = 0;
            nameEditor.Insert(groupName, std::u32string(1, cp), 513);
            return true;
        }
        if (editing < 0)
            return false;
        if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.') {
            if (selectAll) {
                numeric.clear();
                selectAll = false;
            }
            if (numeric.size() < 24)
                numeric += char(c);
        }
        return true;
    }
    bool Wheel(float delta, Settings& cfg) {
        if (!visible || blocked)
            return false;
        if (color >= 0 || capture >= 0)
            return true;
        if (choice >= 0)
            return true;
        if (maskGroup >= 0) {
            maskTarget = WeaponPresetsLayout::WheelTarget(maskScroll, delta, maskMax, maskBox.h - 14 * scale,
                                                          F, wheelLines);
            return true;
        }
        int over = HitAt(mouseX, mouseY);
        for (int i = 0; i < RageFieldCount; ++i)
            if (over >= 0 && hits[std::size_t(over)].field == i && hits[std::size_t(over)].action == Slider &&
                sliders[std::size_t(i)].w > 0 && sliders[std::size_t(i)].Contains(mouseX, mouseY) &&
                EnabledField(i, cfg)) {
                cfg.rage.Set(i,
                             cfg.rage.Get(i) +
                                 delta * (RageSpecs[std::size_t(i)].kind == RageKind::Decimal ? .1f : 1.f));
                return true;
            }
        if (createMenu) {
            createTarget = WeaponPresetsLayout::WheelTarget(createScroll, delta, createMax,
                                                            createBox.h - 14 * scale, F, wheelLines);
            return true;
        }
        if (weaponOpen) {
            weaponFollowEnd = false;
            weaponTarget =
                WeaponPresetsLayout::WheelTarget(weaponScroll, delta, weaponMax, weaponBody.h, F, wheelLines);
            return true;
        }
        if (popup >= 0) {
            popupScroll = std::clamp(popupScroll - delta * 30 * scale, 0.f, popupMax);
            return true;
        }
        if (pageBody.Contains(mouseX, mouseY) && maxScroll > 0) {
            scroll = std::clamp(scroll - delta * 30 * scale, 0.f, maxScroll);
            return true;
        }
        return false;
    }
    Box drawClip{};
    std::array<Color, 46> palette{};
    int Layer(Box b, bool pop = false, float radius = 0) {
        paint.layers.push_back({b, radius, pop, {}});
        return int(paint.layers.size()) - 1;
    }
    void Rect(int z, Box b, Color c, float radius = 0, float stroke = 0) {
        if (b.w <= 0 || b.h <= 0)
            return;
        PresetDraw d{b, c, radius, stroke, 15, {}, false};
        d.clipped = true;
        d.clip = paint.layers[std::size_t(z)].box;
        if (drawClip.w > 0)
            d.clip = PresetIntersect(d.clip, drawClip);
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
    }
    void Text(int z, Box b, const std::u32string& v, Color c, int font = 0, float px = 13,
              bool standalone = false) {
        if (v.empty() || b.w <= 0 || b.h <= 0)
            return;
        PresetDraw d{b, c, 0, 0, 15, v, font == 3 && !standalone};
        d.font = font;
        d.textSize = px;
        d.clipped = true;
        d.clip = paint.layers[std::size_t(z)].box;
        if (drawClip.w > 0)
            d.clip = PresetIntersect(d.clip, drawClip);
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
    }
    void AddHit(int z, Box b, Action a, int f = -1, int opt = -1, Box ctl = Box{}) {
        if (blocked)
            return;
        b = PresetIntersect(b, paint.layers[std::size_t(z)].box);
        if (drawClip.w > 0)
            b = PresetIntersect(b, drawClip);
        if (b.w > 0 && b.h > 0)
            hits.push_back({b, a, f, opt, ctl});
    }
    int SurfaceLayer(Box b, bool popup = true, float radius = 15) {
        int z = Layer(b, popup, radius * scale);
        Rect(z, b, palette[8], radius * scale);
        Rect(z, b, palette[11], radius * scale, scale);
        return z;
    }
    float Hover(Action a, int f = -1, int opt = -1) const {
        auto it = hoverMotion.find(Hit{{}, a, f, opt}.Key());
        return it == hoverMotion.end() ? 0.f : it->second.value;
    }
    static Color Alpha(Color c, float a) {
        c.a *= a;
        return c;
    }
    float ButtonMotion(const std::map<int, PresetMotion>& map, Action a, int option = -1) const {
        auto it = map.find(Hit{{}, a, -1, option}.Key());
        return it == map.end() ? 0 : it->second.value;
    }
    void WeaponButton(Fonts& fonts, int z, Box b, Action action, int option, const std::u32string& glyph,
                      int font = 3, float px = 13) {
        float fill = ButtonMotion(buttonFill, action, option), ink = ButtonMotion(buttonInk, action, option);
        Rect(z, b, Alpha(palette[33], .4f * fill), 6 * scale);
        float w = fonts.NativeTextSize(font, px * scale, glyph).w, fh = fonts.PixelHeight(font, px * scale);
        Text(z, {b.x + (b.w - w) * .5f, b.y + (b.h - fh) * .5f, w, fh}, glyph,
             Alpha(palette[30], .7f + .3f * ink), font, px, glyph == U"+");
        AddHit(z, b, action, -1, option);
    }

    std::u32string Summary(int i, const Settings& cfg) const {
        auto opts = Options(i);
        int n = int(cfg.rage.Get(i));
        if (RageSpecs[std::size_t(i)].kind == RageKind::Choice)
            return opts[std::size_t(std::clamp(n, 0, int(opts.size()) - 1))];
        std::u32string v;
        for (std::size_t j = 0; j < opts.size(); ++j)
            if (n & (1 << j)) {
                if (!v.empty())
                    v += U", ";
                v += opts[j];
            }
        if (v.empty())
            return Label("menu_select");
        if (RageSpecs[std::size_t(i)].popup != 0 && v.size() >= 15) {
            v.clear();
            for (std::size_t j = 0; j < opts.size(); ++j)
                if ((n & (1 << j)) && !opts[j].empty()) {
                    if (!v.empty())
                        v += U", ";
                    v += opts[j][0];
                }
        }
        return v;
    }
    std::u32string Fit(Fonts& f, const std::u32string& text, float width, int font = 0, float px = 13) const {
        if (width <= 0)
            return {};
        auto out = text;
        if (f.NativeTextSize(font, px * scale, out).w <= width)
            return out;
        while (!out.empty() && f.NativeTextSize(font, px * scale, out + U"…").w > width)
            out.pop_back();
        return out.empty() ? U"" : out + U"…";
    }
    bool TransitionActive(int key) const {
        if (key < 100)
            return key == (weaponOpen ? 50 : popup);
        if (key < 200)
            return choice >= 0 && key == 100 + choice;
        if (key < 300)
            return color >= 0 && key == 200 + color;
        if (key == 300)
            return weaponOpen && createMenu;
        if (key >= 400)
            return weaponOpen && maskGroup >= 0 && key == 400 + maskGroup;
        return false;
    }
    void BeginWindow(int key) {
        drawnWindows.insert(key);
        auto& w = transitions[key];
        if (!w.motion.initialized)
            w.motion.Snap(0);
    }
    void RememberWindow(int key, std::size_t begin) {
        auto& w = transitions[key];
        w.cached.assign(paint.layers.begin() + std::ptrdiff_t(begin), paint.layers.end());
        FadeLayers(begin, w.motion.value);
    }
    void FadeLayers(std::size_t begin, float alpha) {
        for (std::size_t j = begin; j < paint.layers.size(); ++j) {
            auto& l = paint.layers[j];
            l.opacity *= alpha;
            for (auto& d : l.draw) {
                d.color.a *= alpha;
                d.shadowColor.a *= alpha;
                d.backdropOpacity *= alpha;
            }
        }
    }
    void Swatch(int z, Box b, Color c, Color second, bool gradient, float alpha) {
        Box rb{std::floor(b.x) - 1, std::floor(b.y) - 1, std::ceil(b.x + b.w) - std::floor(b.x) + 2,
               std::ceil(b.y + b.h) - std::floor(b.y) + 2};
        auto image = std::make_shared<Canvas>(int(rb.w), int(rb.h));
        DrawPickerPreview(*image, {b.x - rb.x, b.y - rb.y, b.w, b.h}, scale, F + 14 * scale, c, second,
                          gradient, false);
        PresetDraw d{rb, {1, 1, 1, alpha}, 0, 0, 15, {}, false};
        d.raster = image;
        d.rasterStamp = PickerPreviewStamp(c, second, gradient, false);
        d.clipped = true;
        d.clip = paint.layers[std::size_t(z)].box;
        if (drawClip.w > 0)
            d.clip = PresetIntersect(d.clip, drawClip);
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
    }
    void DrawWeaponIcon(int z, const std::string& name, Box slot) {
        int index = LiveEquipmentIconIndex(name);
        auto icon =
            index >= 0 ? weaponIcons.Raster(unsigned(index), 12 * scale, palette[14], false) : nullptr;
        if (!icon)
            return;
        float iw = std::min(slot.w, float(icon->image->width));
        PresetDraw d{{slot.x + (slot.w - iw) * .5f, slot.y + (slot.h - 12 * scale) * .5f, iw, 12 * scale},
                     {1, 1, 1, 1},
                     0,
                     0,
                     15,
                     {},
                     false};
        d.raster = icon->image;
        d.rasterStamp = icon->stamp;
        d.clipped = true;
        d.clip = paint.layers[std::size_t(z)].box;
        if (drawClip.w > 0)
            d.clip = PresetIntersect(d.clip, drawClip);
        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
    }
    void Row(Fonts& fonts, const Settings& cfg, int z, int i, Box row, bool inner, unsigned corners = 15) {
        if (!FieldVisible(i, cfg))
            return;
        const auto& d = RageSpecs[std::size_t(i)];
        rows[std::size_t(i)] =
            PresetIntersect(row, drawClip.w > 0 ? drawClip : paint.layers[std::size_t(z)].box);
        const float s = scale;
        float left = row.x + (inner ? 12 : 0) * s, right = row.x + row.w - (inner ? 12 : 0) * s;
        const float ty = row.y + (row.h - F) * .5f;
        bool enabled = EnabledField(i, cfg);
        float a = availability[std::size_t(i)].initialized ? availability[std::size_t(i)].value
                  : enabled                                ? 1.f
                                                           : .5f;
        Action action = d.kind == RageKind::Check                                      ? Toggle
                        : (d.kind == RageKind::Integer || d.kind == RageKind::Decimal) ? Slider
                        : d.kind == RageKind::Opener                                   ? Open
                        : d.kind == RageKind::Color                                    ? ColorPoint
                        : d.kind == RageKind::Hotkey                                   ? Bind
                                                                                       : Select;
        float motion = enabled ? Hover(action, i, action == Open ? Detail(i) : -1) : 0;
        if (inner)
            Rect(z, row, Alpha(palette[33], .4f * motion * a), 15 * s / 1.6f);
        else {
            Rect(z, GroupRowHoverBounds(row, s), Alpha(palette[33], .15f * motion * a), 15 * s);
            paint.layers[std::size_t(z)].draw.back().corners = corners;
        }
        Color ink = Alpha(Mix(palette[inner ? 14 : 0], palette[2], motion), a);
        float labelRight = right;
        Box ctl{}, more{};
        int detail = Detail(i);
        if (d.kind == RageKind::Check) {
            float t =
                checkMotion[std::size_t(i)].initialized ? checkMotion[std::size_t(i)].value : cfg.rage.Get(i);
            if (inner && i != ForceShot && !(i >= AvoidBackstab && i <= Spin)) {
                if (t > .001f)
                    Text(z, {left, ty, 14 * s, F}, U"\uf00c", Alpha(palette[0], t * a), 3);
                left += 24 * s *
                        (popupMarkers[std::size_t(std::clamp(popup, 0, 10))].initialized
                             ? popupMarkers[std::size_t(std::clamp(popup, 0, 10))].value
                             : 1.f);
            } else {
                float h = F + 2 * s, center = row.y + row.h * .5f, frac = center - std::trunc(center);
                ctl = {right - 32 * s, center - h * .5f + frac, 32 * s, h - 2 * frac};
                Rect(z, ctl, Alpha(palette[22], a), h * .5f);
                Rect(z, ctl, Alpha(palette[23], a * t), h * .5f);
                float r = h * .5f - 2 * s, cx = ctl.x + h * .5f + (ctl.w - h) * t;
                Rect(z, {cx - r, center - r, 2 * r, 2 * r}, Alpha(Mix(palette[20], palette[21], t), a), r);
                labelRight = ctl.x - 6 * s;
            }
        } else if (action == Slider && inner) {

            float w = std::trunc(row.w / 2.5f);
            ctl = {right - w, row.y + (row.h - 6 * s) * .5f, w, 6 * s};
            sliders[std::size_t(i)] =
                PresetIntersect(ctl, drawClip.w > 0 ? drawClip : paint.layers[std::size_t(z)].box);
            float v = std::clamp((cfg.rage.Get(i) - d.minimum) / (d.maximum - d.minimum), 0.f, 1.f);
            Rect(z, ctl, Alpha(palette[24], a), 3 * s);
            Box clip = drawClip;
            drawClip = drawClip.w > 0 ? PresetIntersect(drawClip, {ctl.x, ctl.y, ctl.w * v, ctl.h})
                                      : Box{ctl.x, ctl.y, ctl.w * v, ctl.h};
            if (v > 0)
                Rect(z, ctl, Alpha(palette[25], a), 3 * s);
            drawClip = clip;
            labelRight = ctl.x - 7 * s;

            if (editing == i) {
                Rect(z, {ctl.x, row.y, ctl.w, row.h}, palette[12], 6 * s);
                Rect(z, {ctl.x, row.y, ctl.w, row.h}, palette[11], 6 * s, s);
                Text(z, {ctl.x + 6 * s, ty, ctl.w - 12 * s, F}, DecodeUTF8(numeric + "|"), palette[2]);
            }
        } else if (action == Slider) {

            auto value = ValueLabel(i, cfg);
            float tw = fonts.NativeTextSize(0, 13 * s, value).w;
            float nw = std::min(std::max(24 * s, tw + 12 * s), row.w * .42f), nh = F + 6 * s;
            Box number{right - nw, row.y + (row.h - nh) * .5f, nw, nh};
            valueBoxes[std::size_t(i)] = number;

            float total = std::min((right - left) * .68f, std::trunc((right - left) / 2.2f) + 12 * s);
            ctl = {right - total, row.y + (row.h - 4 * s) * .5f, std::max(1.f, total - nw - 12 * s), 4 * s};
            sliders[std::size_t(i)] =
                PresetIntersect(ctl, drawClip.w > 0 ? drawClip : paint.layers[std::size_t(z)].box);
            float v = std::clamp((cfg.rage.Get(i) - d.minimum) / (d.maximum - d.minimum), 0.f, 1.f);
            float base = std::max(0.f, std::trunc(F * .5f) - 3 * s),
                  inset = std::min(base, std::max(0.f, (ctl.w - 4) * .5f));
            float cx = ctl.x + inset + (ctl.w - 2 * inset) * v, hover = sliderTip[std::size_t(i)].value,
                  r = base + hover * s;
            Rect(z, ctl, Alpha(palette[24], a), 2 * s);
            Rect(z, {ctl.x, ctl.y, std::max(0.f, cx - r - ctl.x), ctl.h}, Alpha(palette[25], a), 2 * s);
            if (enabled && r > 0)
                Rect(z, {cx - r, row.y + row.h * .5f - r, 2 * r, 2 * r},
                     Alpha(Mix(palette[26], palette[27], hover), a), r);
            Rect(z, number, Alpha(Mix(palette[12], palette[13], enabled ? Hover(NumericValue, i) : 0), a),
                 6 * s);
            Rect(z, number, Alpha(palette[11], a), 6 * s, s);
            Text(z, {number.x + 6 * s, ty, std::max(0.f, number.w - 12 * s), F},
                 editing == i ? DecodeUTF8(numeric + "|") : value, Alpha(palette[14], a));
            labelRight = ctl.x - 6 * s;
        } else if (action == Open) {
            float aw = fonts.NativeTextSize(3, 13 * s, U"\uf105").w;
            ctl = {right - aw - 6 * s, row.y, aw, row.h};
            Text(z, {ctl.x, ty, aw, F}, U"\uf105", ink, 3);
            labelRight = ctl.x - 8 * s;
        } else if (action == ColorPoint) {
            int index = i == PeekColor ? 0 : 1;
            ctl = {right - 16 * s, row.y + (row.h - 16 * s) * .5f, 16 * s, 16 * s};
            Swatch(z, ctl, cfg.rage.colors[std::size_t(index)],
                   cfg.rage.colors[std::size_t(index == 1 ? 2 : 0)], index == 1, a);
            labelRight = ctl.x - 8 * s;
        } else if (action == Bind) {
            bool capturing =
                capture == i || (bindings && bindings->directTarget == "rage." + std::string(d.id));
            auto value = capturing              ? U"…"
                         : cfg.rage.Get(i) == 0 ? U"-"
                                                : DecodeUTF8(MenuKeyName(int(cfg.rage.Get(i))));
            int vk = int(cfg.rage.Get(i));
            if (!capturing && (vk == 1 || vk == 2 || (vk >= 4 && vk <= 6)))
                value = DecodeUTF8("M" + std::to_string(vk <= 2 ? vk : vk - 1));

            float w = std::max(10 * s, fonts.NativeTextSize(0, 13 * s, value).w) + 12 * s, bh = F + 6 * s;
            ctl = {right - w, row.y + (row.h - bh) * .5f, w, bh};
            Rect(z, ctl, Alpha(palette[33], (.2f + .2f * (capturing ? 1.f : motion)) * a), 6 * s);
            Text(z, {ctl.x + (w - fonts.NativeTextSize(0, 13 * s, value).w) * .5f, ty, w - 8 * s, F}, value,
                 ink);
            labelRight = ctl.x - 6 * s;
        } else {
            auto value = Summary(i, cfg);
            auto arrow = inner ? U"\uf105" : U"\uf107";
            float aw = fonts.NativeTextSize(3, 13 * s, arrow).w;
            float w = inner ? std::min(row.w * .55f, fonts.NativeTextSize(0, 13 * s, value).w + aw + 12 * s)
                            : std::min(std::trunc(row.w / 2.2f) + 12 * s, row.w * .5f);
            ctl = {right - w, row.y, w, row.h};
            if (!inner) {
                Rect(z, ctl, Mix(palette[12], palette[13], motion), 6 * s);
                Rect(z, ctl, palette[11], 6 * s, s);
            }
            float pad = inner ? 0 : 6 * s;
            float textw = std::max(0.f, w - aw - (inner ? 12 : 18) * s);
            Box previewClip = drawClip, previewBox{ctl.x + pad, ty, textw, F};
            drawClip = drawClip.w > 0 ? PresetIntersect(drawClip, previewBox) : previewBox;
            Text(z, previewBox, value, Alpha(palette[14], a));
            drawClip = previewClip;
            Text(z, {right - aw - 6 * s, ty, aw, F}, arrow, ink, 3);
            labelRight = ctl.x - 8 * s;
        }
        if (choice == i && action == Select)
            choiceAnchor = ctl;
        if (detail >= 0 && action != Open) {
            float x = ctl.w > 0 ? ctl.x - 29 * s : right - 22 * s;
            more = {x, row.y, 22 * s, row.h};
            Rect(z, more, Alpha(palette[33], .4f * Hover(Open, i, detail)), 15 * s / 1.6f);
            float iw = fonts.NativeTextSize(3, 13 * s, U"\uf141").w;
            Text(z, {more.x + (more.w - iw) * .5f, ty, iw, F}, U"\uf141", ink, 3);
            labelRight = std::min(labelRight, more.x - 4 * s);
        }

        char32_t icon = inner && i == OverrideColor ? 0xf53f : inner && i == OverrideStyle ? 0xe600 : 0;
        if (icon) {
            std::u32string glyph(1, icon);
            float iw = fonts.NativeTextSize(3, 13 * s, glyph).w;
            Text(z, {left + (20 * s - iw) * .5f, ty, iw, F}, glyph, ink, 3);
            left += 32 * s;
        }
        auto label = d.kind == RageKind::Color ? Label("color") : Label(d.key);
        float lw = std::max(0.f, labelRight - left), full = fonts.NativeTextSize(0, 13 * s, label).w;
        auto& mq = marquees[i];
        float overflow = std::max(0.f, full - lw);
        if (std::abs(mq.overflow - overflow) > .1f || std::abs(mq.fullWidth - full) > .1f) {
            mq.offset = mq.hoverTime = 0;
            mq.stableFrames = 0;
            mq.returning.Snap(0);
        } else
            mq.stableFrames = std::min(5, mq.stableFrames + 1);
        mq.overflow = overflow;
        mq.fullWidth = full;
        Box savedClip = drawClip;
        Box labelClip{left, ty, lw, F};
        drawClip = savedClip.w > 0 ? PresetIntersect(savedClip, labelClip) : labelClip;
        Text(z, {left - mq.offset, ty, full, F}, label, enabled ? ink : Alpha(ink, .5f));
        if (mq.offset >= overflow && overflow > 0)
            Text(z, {left - mq.offset + full + 20 * s, ty, full, F}, label, ink);
        drawClip = savedClip;
        if (enabled) {
            Box target = inner ? row : GroupRowHoverBounds(row, s);
            if (action == Slider) {
                AddHit(z, target, RowLabel, i);
                AddHit(z, {ctl.x, row.y, ctl.w, row.h}, Slider, i, -1, ctl);
                if (!inner)
                    AddHit(z, valueBoxes[std::size_t(i)], NumericValue, i, -1, valueBoxes[std::size_t(i)]);
            } else
                AddHit(z, target, action, i, action == Open ? detail : -1, ctl);
            if (more.w > 0)
                AddHit(z, more, Open, i, detail, more);
        }
    }
    void Measure(Fonts& fonts, const Settings& cfg, const Layout& layout, Box line, int width, int height,
                 bool shown, bool modalBlocked, Box configSelector = {}) {
        if (!shown) {
            Hide();
            return;
        }
        visible = true;
        blocked = modalBlocked;
        scale = cfg.scale;
        F = fonts.PixelHeight(0, 13 * scale);
        viewport = {0, 0, float(width), float(height)};
        palette = CurrentPalette(cfg);
        paint.layers.clear();
        drawnWindows.clear();
        hits.clear();
        rows.fill({});
        sliders.fill({});
        valueBoxes.fill({});
        cards.fill({});
        drawClip = {};
        if (blocked) {
            Close();
            hover = -1;
            hoverTime = 0;
            tooltipStored = false;
        }
        if (editing >= 0 && !EnabledField(editing, cfg)) {
            editing = -1;
            numeric.clear();
        }
        if (drag >= 0 && !EnabledField(drag, cfg))
            CancelInput();
        if (choice >= 0 && !EnabledField(choice, cfg))
            choice = -1;
        float s = scale, H = F + 6 * s, R = F + 14 * s, hf = fonts.PixelHeight(0, 10 * s);
        float top = line.y + line.h + 15 * s;
        pageBody = {
            layout.content.x + 15 * s, top, std::max(0.f, layout.content.w - 30 * s),
            std::max(0.f,
                     std::min(float(height) - 6 * s, layout.content.y + layout.content.h - 15 * s) - top)};
        float cw = std::max(0.f, std::min(300 * s, (pageBody.w - 7 * s) * .5f)), pitch = GroupRowPitch(F, s);
        float columnY[2] = {top, top};
        float heights[4]{};
        for (int g = 0; g < 4; ++g) {
            int count = 0;
            for (int i = 0; i < RageFieldCount; ++i)
                if (RageSpecs[std::size_t(i)].group == g && RageSpecs[std::size_t(i)].popup == 0 &&
                    FieldVisible(i, cfg))
                    ++count;
            heights[g] = GroupCardHeight(count, F, s);
            int col = g < 2 ? 0 : 1;
            columnY[col] += hf + 5 * s + heights[g] + 15 * s;
        }
        maxScroll = std::max(0.f, std::max(columnY[0], columnY[1]) - 15 * s - top - pageBody.h);
        scroll = std::clamp(scroll, 0.f, maxScroll);
        columnY[0] = columnY[1] = top - scroll;
        int base = Layer(pageBody);
        drawClip = pageBody;
        static constexpr const char* titles[] = {"group_ragebot_main", "group_ragebot_selection",
                                                 "group_ragebot_other", "group_ragebot_antiaim"};
        for (int g = 0; g < 4; ++g) {
            int col = g < 2 ? 0 : 1;
            float x = pageBody.x + col * (cw + 7 * s), y = columnY[col];
            Text(base, {x + 14 * s, y, cw - 28 * s, hf}, Upper(Label(titles[g])), palette[3], 0, 10);
            Box card{x, y + hf + 5 * s, cw, heights[g]};
            cards[std::size_t(g)] = card;
            Rect(base, card, palette[40], 15 * s);
            Rect(base, card, palette[11], 15 * s, s);
            float cy = card.y + 7 * s;
            std::vector<int> fields;
            for (int i = 0; i < RageFieldCount; ++i) {
                const auto& d = RageSpecs[std::size_t(i)];
                if (d.group == g && !d.popup && FieldVisible(i, cfg))
                    fields.push_back(i);
            }
            for (std::size_t n = 0; n < fields.size(); ++n) {
                Box row{x + 14 * s, cy, cw - 28 * s, H};
                if (n) {
                    Rect(base, GroupRowSeparator(row, s), palette[34]);
                    paint.layers[std::size_t(base)].draw.back().pixelLine = true;
                }
                Row(fonts, cfg, base, fields[n], row, false, GroupRowCorners(int(n), int(fields.size())));
                cy += pitch;
            }
            columnY[col] = card.y + card.h + 15 * s;
        }
        drawClip = {};
        if (maxScroll > 0) {
            Box track{pageBody.x + pageBody.w - 3 * s, pageBody.y, 3 * s, pageBody.h};
            float th = std::max(10 * s, pageBody.h * pageBody.h / (pageBody.h + maxScroll));
            Rect(base, {track.x, track.y + (track.h - th) * scroll / maxScroll, track.w, th}, palette[18],
                 2 * s);
        }

        auto header = Label("aimbot_panel_weaponpresets"),
             selectedName = WeaponName(cfg.rage, cfg.rage.selected);
        float hw = WeaponPresetsLayout::HeaderWidth(
            std::trunc(fonts.NativeTextSize(0, 13 * s, selectedName).w + .95f),
            std::trunc(fonts.NativeTextSize(3, 13 * s, U"\uf107").w + .95f), 12 * s, s);
        float headerH = F + 12 * s;

        float hx = configSelector.w > 0
                       ? configSelector.x + configSelector.w + WeaponPresetsLayout::ItemSpacingX * s
                       : layout.content.x + 120 * s;
        hx = std::clamp(hx, layout.content.x,
                        std::max(layout.content.x, layout.content.x + layout.content.w - hw - 11 * s));
        headerBox = {hx,
                     configSelector.w > 0 ? configSelector.y
                                          : layout.content.y + (line.y - layout.content.y - headerH) * .5f,
                     hw, headerH};
        int hz = Layer(
            {layout.content.x, layout.content.y, layout.content.w, std::max(H, line.y - layout.content.y)});
        Rect(hz, headerBox,
             Alpha(palette[33], .2f * std::max(Hover(WeaponPanel), ButtonMotion(buttonFill, WeaponPanel))),
             6 * s);
        Rect(hz, headerBox, palette[11], 6 * s, s);
        Color headerInk = Mix(palette[0], palette[2], ButtonMotion(buttonInk, WeaponPanel));
        Text(hz, {headerBox.x + 12 * s, headerBox.y + (headerH - F) * .5f, std::max(0.f, hw - 36 * s), F},
             Fit(fonts, selectedName, std::max(0.f, hw - 36 * s)), headerInk);
        Text(hz, {headerBox.x + hw - 23 * s, headerBox.y + (headerH - F) * .5f, 11 * s, F}, U"\uf107",
             headerInk, 3);
        AddHit(hz, headerBox, WeaponPanel);
        searchLayerStart = paint.layers.size();
        if (popup >= 0 || weaponOpen) {
            hits.push_back({viewport, Surface});
        }
        if (popup >= 0) {
            auto windowBegin = paint.layers.size();
            BeginWindow(popup);
            auto blockKey = [&](int i) {
                if (popup == 2)
                    return i == PeekColor ? 0 : 1;
                if (popup == 4)
                    return i < Jitter ? 0 : i < Spin ? 1 : 2;
                if (popup == 5)
                    return i <= Deadzone ? 0 : 1;
                return 0;
            };
            std::vector<std::vector<int>> blocks;
            int previous = -1;
            for (int i = 0; i < RageFieldCount; ++i)
                if (RageSpecs[std::size_t(i)].popup == popup && FieldVisible(i, cfg)) {
                    int k = blockKey(i);
                    if (k != previous) {
                        blocks.push_back({});
                        previous = k;
                    }
                    blocks.back().push_back(i);
                }
            float total = 0;
            for (const auto& block : blocks)
                total +=
                    float(popup == 8 ? Options(QuickStopOptions).size() : block.size()) * R + 14 * s + 7 * s;
            if (!blocks.empty())
                total -= 7 * s;
            float titleH = F + 18 * s;
            Box b = PresetPopupFit({anchor.x, anchor.y, std::min(265 * s, float(width) - 12 * s),
                                    std::min(titleH + total + 7 * s, float(height) - 12 * s)},
                                   width, height);
            popupBox = b;
            int z = SurfaceLayer(b);
            AddHit(z, b, RowLabel);
            int root = Root(popup);
            Text(z, {b.x + 14 * s, b.y + 7 * s, b.w - 28 * s, F},
                 Label(root == AntiAimEnabled ? "group_ragebot_antiaim" : RageSpecs[std::size_t(root)].key),
                 palette[2], 2);
            popupBody = {b.x + 7 * s, b.y + titleH, b.w - 14 * s, b.h - titleH - 7 * s};
            popupMax = std::max(0.f, total - popupBody.h);
            popupScroll = std::clamp(popupScroll, 0.f, popupMax);
            int bz = z;
            drawClip = popupBody;
            float by = popupBody.y - popupScroll;
            for (const auto& block : blocks) {
                Box inner{popupBody.x, by, popupBody.w,
                          float(popup == 8 ? Options(QuickStopOptions).size() : block.size()) * R + 14 * s};
                Rect(bz, inner, palette[40], 15 * s);
                Rect(bz, inner, palette[11], 15 * s, s);
                float cy = inner.y + 7 * s;
                if (popup == 8) {
                    auto opts = Options(QuickStopOptions);
                    auto& mm = popupMarkers[8];
                    float mark = 24 * s *
                                 (mm.initialized                        ? mm.value
                                  : cfg.rage.Get(QuickStopOptions) != 0 ? 1.f
                                                                        : 0.f);
                    for (std::size_t j = 0; j < opts.size(); ++j) {
                        Box opt{inner.x + 7 * s, cy, inner.w - 14 * s, R};
                        Rect(bz, opt, Alpha(palette[33], .4f * Hover(Option, QuickStopOptions, int(j))),
                             15 * s / 1.6f);
                        if (int(cfg.rage.Get(QuickStopOptions)) & (1 << j))
                            Text(bz, {opt.x + 12 * s, cy + 7 * s, mark, F}, U"\uf00c", palette[0], 3);
                        Text(bz, {opt.x + 12 * s + mark, cy + 7 * s, opt.w - 24 * s - mark, F}, opts[j],
                             palette[14]);
                        AddHit(bz, opt, Option, QuickStopOptions, int(j));
                        cy += R;
                    }
                } else
                    for (int i : block) {
                        Row(fonts, cfg, bz, i, {inner.x + 7 * s, cy, inner.w - 14 * s, R}, true);
                        cy += R;
                    }
                by += inner.h + 7 * s;
            }
            drawClip = {};
            if (popupMax > 0) {
                float th = std::max(10 * s, popupBody.h * popupBody.h / (popupBody.h + popupMax));
                Rect(
                    z,
                    {b.x + b.w - 5 * s, popupBody.y + (popupBody.h - th) * popupScroll / popupMax, 3 * s, th},
                    palette[18], 2 * s);
            }
            RememberWindow(popup, windowBegin);
        }
        if (weaponOpen) {
            auto windowBegin = paint.layers.size();
            BeginWindow(50);

            float titleH = F + 14 * s, pw = std::min(WeaponPresetsLayout::Width * s, float(width) - 12 * s),
                  available = std::max(1.f, pw - 28 * s);
            auto membership = [&](const RageWeaponPreset& p) {
                return p.individual ? p.equipment : RageEquipmentNames(p.weaponMask);
            };
            auto chipWidth = [&](const std::string& name) {
                int index = LiveEquipmentIconIndex(name);
                auto raster =
                    index >= 0 ? weaponIcons.Raster(unsigned(index), 12 * s, palette[14], false) : nullptr;
                return (raster ? float(raster->image->width)
                               : fonts.NativeTextSize(0, 10 * s, DecodeUTF8(name)).w) +
                       10 * s;
            };
            auto groupHeight = [&](const RageWeaponPreset& p) {
                float x = 0;
                int count = 1;
                for (const auto& name : membership(p)) {
                    float w = std::min(available, chipWidth(name));
                    if (x > 0 && x + w > available) {
                        ++count;
                        x = 0;
                    }
                    x += w + 5 * s;
                }
                float plus = 22 * s;
                if (x > 0 && x + plus > available)
                    ++count;
                return F + 6 * s + count * 22 * s + 10 * s;
            };
            SyncWeaponReveal(cfg);
            struct DisplayGroup {
                const RageWeaponPreset* preset;
                int index, order;
                float reveal;
            };
            std::vector<DisplayGroup> groups;
            for (auto& kv : weaponReveal) {
                auto& state = kv.second;
                int index = -1;
                for (std::size_t i = 0; i < cfg.rage.weapons.size(); ++i)
                    if (cfg.rage.weapons[i].id == kv.first) {
                        index = int(i);
                        break;
                    }
                if (state.amount.value > .001f || (index >= 0 && cfg.rage.weapons[std::size_t(index)].active))
                    groups.push_back({&state.snapshot, index, state.order, state.amount.value});
            }
            std::stable_sort(groups.begin(), groups.end(),
                             [](const DisplayGroup& a, const DisplayGroup& b) { return a.order < b.order; });
            auto animatedHeight = [&](const RageWeaponPreset& p) {
                auto& state = weaponReveal[p.id];
                state.targetHeight = groupHeight(p);
                if (!state.height.initialized)
                    state.height.Snap(state.targetHeight);
                return state.height.value;
            };
            for (auto& kv : weaponChips)
                kv.second.active = false;
            float globalGap = WeaponPresetsLayout::GlobalGap(s);
            float total = R + globalGap;
            for (const auto& g : groups)
                total += (animatedHeight(*g.preset) + 5 * s) * g.reveal;
            float childH = std::min(total, WeaponPresetsLayout::ListMaxHeight * s),
                  ph = std::min(
                      {titleH + childH + 19 * s, WeaponPresetsLayout::MaxHeight * s, float(height) - 12 * s});

            if (!weaponPositionReady) {
                weaponOpenPosition =
                    WeaponPresetsLayout::ComboPopup(headerBox, pw, ph, float(width), float(height), 3 * s);
                weaponPositionReady = true;
            }
            weaponBox = WeaponPresetsLayout::FitNative({weaponOpenPosition.x, weaponOpenPosition.y, pw, ph},
                                                       float(width), float(height), 3 * s);
            int z = SurfaceLayer(weaponBox);
            AddHit(z, weaponBox, RowLabel);
            Text(z, {weaponBox.x + 7 * s, weaponBox.y + 7 * s, pw - 49 * s, F}, header, palette[2], 1, 14);
            Box add{weaponBox.x + pw - 7 * s - (F + 6 * s), weaponBox.y + 7 * s, F + 6 * s, F + 6 * s};
            WeaponButton(fonts, z, add, CreateMenu, -1, U"+");
            Rect(z, {weaponBox.x + 7 * s, weaponBox.y + titleH + 3 * s, pw - 14 * s, s}, palette[34]);
            weaponBody = {weaponBox.x + 7 * s, weaponBox.y + titleH + 9 * s, pw - 14 * s,
                          std::max(0.f, ph - titleH - 16 * s)};
            weaponMax = std::max(0.f, total - weaponBody.h);
            if (weaponFollowEnd) {
                weaponScroll = weaponTarget = weaponMax;
                bool animating = false;
                for (const auto& g : groups)
                    if (std::abs(g.reveal - 1.f) > .001f)
                        animating = true;
                if (!animating)
                    weaponFollowEnd = false;
            }
            weaponScroll = std::clamp(weaponScroll, 0.f, weaponMax);
            weaponTarget = std::clamp(weaponTarget, 0.f, weaponMax);
            drawClip = weaponBody;
            float y = weaponBody.y - weaponScroll;
            Box global{weaponBody.x, y, weaponBody.w, R};
            Rect(z, global, palette[40], 7.5f * s);
            Rect(z, global, Alpha(palette[33], .2f * Hover(WeaponSelect, -1, -1)), 7.5f * s);
            Rect(z, global, Mix(palette[11], Alpha(palette[31], .4f), cfg.rage.selected < 0 ? 1.f : 0.f),
                 7.5f * s, s);
            Text(z, {global.x + 7 * s, y + 7 * s, global.w - 14 * s, F}, WeaponName(cfg.rage, -1),
                 cfg.rage.selected < 0 ? palette[2] : palette[14]);
            AddHit(z, global, WeaponSelect, -1, -1);

            y += R + globalGap;
            for (const auto& display : groups) {
                const auto& p = *display.preset;
                int i = display.index;
                float reveal = display.reveal, gh = animatedHeight(p);
                Box group{weaponBody.x, y, weaponBody.w, gh};
                bool selected = i >= 0 && cfg.rage.selected == i;
                std::size_t firstDraw = paint.layers[std::size_t(z)].draw.size(), firstHit = hits.size();
                Box savedClip = drawClip;
                drawClip = PresetIntersect(savedClip, {group.x, group.y, group.w, gh * reveal});
                Rect(z, group, palette[40], 7.5f * s);
                Rect(z, group, Alpha(palette[33], .2f * Hover(WeaponSelect, -1, int(i))), 7.5f * s);
                Rect(z, group, Mix(palette[11], Alpha(palette[31], .4f), selected ? 1.f : 0.f), 7.5f * s, s);
                AddHit(z, group, WeaponSelect, -1, int(i));
                Box title{group.x + 7 * s, y + 3 * s, group.w - 39 * s, F + 6 * s};
                if (renaming && renameGroup == int(i)) {
                    nameBox = title;
                    Rect(z, title, palette[12], 4 * s);
                    nameEditor.Measure(fonts, 13 * s, groupName, title.w - 8 * s, true, 0);
                    Box saved = drawClip;
                    drawClip = PresetIntersect(saved, title);
                    Text(z,
                         {title.x + 4 * s - nameEditor.scroll, title.y + 3 * s,
                          title.w + nameEditor.scroll - 8 * s, F},
                         groupName, palette[0]);
                    float caret = nameEditor.advance.empty() ? 0 : nameEditor.advance[nameEditor.cursor];
                    Rect(z, {title.x + 4 * s + caret - nameEditor.scroll, title.y + 2 * s, s, F + 2 * s},
                         palette[2]);
                    drawClip = saved;
                    AddHit(z, title, TextField);
                } else {
                    Text(z, {title.x, title.y + 3 * s, title.w, F},
                         Fit(fonts,
                             p.name.empty() ? Label("aimbot_panel_weaponpresets_group_" + p.id)
                                            : DecodeUTF8(p.name),
                             title.w),
                         selected ? palette[2] : palette[14]);
                    AddHit(z, title, RenameGroup, -1, int(i));
                }

                Box remove{group.x + group.w - 27 * s, y + 1 * s, 25 * s, 25 * s};
                WeaponButton(fonts, z, remove, DeleteGroup, int(i), U"\uf00d", 3);
                float cx = group.x + 7 * s, cy = y + F + 9 * s;
                auto allNames = RageEquipmentNames(2047);
                auto drawChip = [&](const std::string& name, Box chip, bool active, float amount) {
                    auto at = std::find(allNames.begin(), allNames.end(), name);
                    int option = at == allNames.end() ? -1 : int(at - allNames.begin());
                    float hover = active ? Hover(EquipmentOption, i, option) : 0;

                    Color ink = Mix(palette[14], {.86f, .39f, .38f, 1}, hover),
                          background = Mix(Alpha(palette[33], 0), {.52f, .23f, .23f, 1}, hover);
                    Rect(z, chip, Alpha(background, amount), 6 * s);

                    Rect(z, chip, Alpha(palette[11], amount), 6 * s, s);
                    int index = LiveEquipmentIconIndex(name);
                    auto raster =
                        index >= 0 ? weaponIcons.Raster(unsigned(index), 12 * s, ink, false) : nullptr;
                    if (raster) {
                        PresetDraw d{{chip.x + 5 * s, chip.y + 5 * s, float(raster->image->width), 12 * s},
                                     {1, 1, 1, amount},
                                     0,
                                     0,
                                     15,
                                     {},
                                     false};
                        d.raster = raster->image;
                        d.rasterStamp = raster->stamp;
                        d.clipped = true;
                        d.clip = PresetIntersect(drawClip, group);
                        paint.layers[std::size_t(z)].draw.push_back(std::move(d));
                    } else
                        Text(z, {chip.x + 5 * s, chip.y + 5 * s, std::max(0.f, chip.w - 10 * s), 12 * s},
                             DecodeUTF8(name), Alpha(ink, amount), 0, 10);
                    if (active && option >= 0)
                        AddHit(z, chip, EquipmentOption, i, option);
                };
                for (const auto& name : membership(p)) {
                    float cw = std::min(available, chipWidth(name));
                    if (cx > group.x + 7 * s && cx + cw > group.x + group.w - 7 * s) {
                        cx = group.x + 7 * s;
                        cy += 22 * s;
                    }
                    auto pos = AnimatedChip(p.id, name, {cx - group.x, cy - group.y, cw, 22 * s});
                    auto& chip = weaponChips[p.id + "/" + name];
                    drawChip(name, {group.x + pos.x, group.y + pos.y, cw, 22 * s}, p.active && i >= 0,
                             chip.amount.value);
                    cx += cw + 5 * s;
                }
                for (const auto& kv : weaponChips) {
                    const auto& c = kv.second;
                    if (c.group == p.id && !c.active && c.name != "+" && c.amount.value > .001f)
                        drawChip(c.name, {group.x + c.x.value, group.y + c.y.value, c.w, 22 * s}, false,
                                 c.amount.value);
                }
                if (cx + 22 * s > group.x + group.w - 7 * s) {
                    cx = group.x + 7 * s;
                    cy += 22 * s;
                }
                auto plusLocal = AnimatedChip(p.id, "+", {cx - group.x, cy - group.y, 22 * s, 22 * s});
                Box plus{group.x + plusLocal.x, group.y + plusLocal.y, 22 * s, 22 * s};
                float plusHover = std::max(Hover(GroupMask, -1, i), ButtonMotion(buttonFill, GroupMask, i));
                Rect(z, plus, Alpha(palette[33], .2f * plusHover), 6 * s);
                Rect(z, plus, palette[11], 6 * s, s);
                float plusWidth = std::trunc(fonts.NativeTextSize(3, 10 * s, U"+").w + .95f),
                      plusHeight = fonts.PixelHeight(3, 10 * s);
                Text(z,
                     {plus.x + (plus.w - plusWidth) * .5f, plus.y + (plus.h - plusHeight) * .5f, plusWidth,
                      plusHeight},
                     U"+", Mix(palette[14], palette[2], plusHover), 3, 10, true);
                AddHit(z, plus, GroupMask, -1, i);
                for (std::size_t j = firstDraw; j < paint.layers[std::size_t(z)].draw.size(); ++j)
                    paint.layers[std::size_t(z)].draw[j].color.a *= reveal;
                if (i < 0 || !p.active)
                    hits.resize(firstHit);
                drawClip = savedClip;
                y += (gh + 5 * s) * reveal;
            }
            drawClip = {};
            if (weaponMax > 0) {
                float th = std::max(10 * s, weaponBody.h * weaponBody.h / (weaponBody.h + weaponMax));
                Rect(z,
                     {weaponBox.x + pw - 5 * s, weaponBody.y + (weaponBody.h - th) * weaponScroll / weaponMax,
                      3 * s, th},
                     palette[18], 2 * s);
            }
            RememberWindow(50, windowBegin);
            if (createMenu) {
                auto windowBegin = paint.layers.size();
                BeginWindow(300);
                float childX = weaponBox.x + pw + 5 * s;
                if (childX + 230 * s > width - 6 * s)
                    childX = weaponBox.x - 235 * s;
                Box b = PresetPopupFit(
                    {childX, weaponBox.y, 230 * s, std::min(250 * s, float(height) - 12 * s)}, width, height);
                createBox = b;
                hits.push_back({viewport, Surface});
                int cz = SurfaceLayer(b);
                AddHit(cz, b, RowLabel);
                drawClip = {b.x + 7 * s, b.y + 7 * s, b.w - 14 * s, b.h - 14 * s};
                createMax = std::max(0.f, 12 * R + 10 * s - drawClip.h);
                createScroll = std::clamp(createScroll, 0.f, createMax);
                Box row{b.x + 7 * s, b.y + 7 * s - createScroll, b.w - 14 * s, R};
                Rect(cz, row, Alpha(palette[33], .4f * Hover(CreateGroup)), 9 * s);
                Text(cz, {row.x + 12 * s, row.y + 7 * s, 30 * s, F}, U"\uf5fd", palette[14], 3);
                Text(cz, {row.x + 56 * s, row.y + 7 * s, row.w - 63 * s, F},
                     Label("aimbot_panel_weaponpresets_group_create"), palette[14]);
                AddHit(cz, row, CreateGroup);
                float cy = row.y + R + 5 * s;
                Rect(cz, {row.x, cy, row.w, s}, palette[34]);
                cy += 5 * s;
                for (std::size_t i = 0; i < RageWeaponKeys.size(); ++i) {
                    Box restore{row.x, cy, row.w, R};
                    Rect(cz, restore, Alpha(palette[33], .4f * Hover(RestoreGroup, -1, int(i))), 9 * s);
                    auto names = RageEquipmentNames(1u << i);
                    if (!names.empty())
                        DrawWeaponIcon(cz, names.front(), {restore.x + 7 * s, cy, 42 * s, R});
                    Text(cz, {restore.x + 56 * s, cy + 7 * s, restore.w - 63 * s, F},
                         Label(std::string("aimbot_panel_weaponpresets_group_") + RageWeaponKeys[i]),
                         palette[14]);
                    AddHit(cz, restore, RestoreGroup, -1, int(i));
                    cy += R;
                }
                drawClip = {};
                if (createMax > 0) {
                    float th = std::max(10 * s, (b.h - 14 * s) * (b.h - 14 * s) / (b.h - 14 * s + createMax));
                    Rect(cz,
                         {b.x + b.w - 5 * s, b.y + 7 * s + (b.h - 14 * s - th) * createScroll / createMax,
                          3 * s, th},
                         palette[18], 2 * s);
                }
                RememberWindow(300, windowBegin);
            }
            if (maskGroup >= 0 && std::size_t(maskGroup) < cfg.rage.weapons.size()) {
                auto windowBegin = paint.layers.size();
                BeginWindow(400 + maskGroup);
                auto all = RageEquipmentNames(2047);
                float mw = WeaponPresetsLayout::WeaponPickerMinWidth * s;
                for (const auto& name : all)
                    mw = std::max(
                        mw, fonts.NativeTextSize(0, 13 * s, DecodeUTF8(RageEquipmentLabel(name))).w + 90 * s);
                Box openPoint = maskOpenPoint;
                if (openPoint.x <= 0 && openPoint.y <= 0)
                    openPoint = {weaponBox.x + pw + 1, weaponBody.y + 1, 0, 0};
                Box b = WeaponPresetsLayout::PointPopup(
                    openPoint, mw,
                    std::min(WeaponPresetsLayout::WeaponPickerMaxHeight * s, float(height) - 6 * s),
                    float(width), float(height), 3 * s);
                maskBox = b;
                hits.push_back({viewport, Surface});
                int mz = SurfaceLayer(b);
                AddHit(mz, b, RowLabel);
                drawClip = {b.x + 7 * s, b.y + 7 * s, b.w - 14 * s, b.h - 14 * s};
                auto assigned = membership(cfg.rage.weapons[std::size_t(maskGroup)]);
                std::size_t remaining = 0, categoryCount = 0;
                for (std::size_t g = 0; g < RageWeaponKeys.size(); ++g) {
                    bool any = false;
                    for (const auto& n : RageEquipmentNames(1u << g))
                        if (std::find(assigned.begin(), assigned.end(), n) == assigned.end()) {
                            ++remaining;
                            any = true;
                        }
                    if (any)
                        ++categoryCount;
                }
                maskMax =
                    std::max(0.f, float(remaining) * R + float(categoryCount) * (F + 12 * s) - drawClip.h);
                maskScroll = std::clamp(maskScroll, 0.f, maskMax);
                float cy = b.y + 7 * s - maskScroll;
                std::size_t j = 0;
                for (std::size_t g = 0; g < RageWeaponKeys.size(); ++g) {
                    bool any = false;
                    for (const auto& n : RageEquipmentNames(1u << g))
                        if (std::find(assigned.begin(), assigned.end(), n) == assigned.end())
                            any = true;
                    if (!any) {
                        j += RageEquipmentNames(1u << g).size();
                        continue;
                    }
                    Text(mz, {b.x + 14 * s, cy + 5 * s, b.w - 28 * s, F},
                         Label(std::string("aimbot_panel_weaponpresets_group_") + RageWeaponKeys[g]),
                         palette[2], 1, 14);
                    cy += F + 12 * s;
                    for (const auto& name : RageEquipmentNames(1u << g)) {
                        if (std::find(assigned.begin(), assigned.end(), name) != assigned.end()) {
                            ++j;
                            continue;
                        }
                        Box row{b.x + 7 * s, cy, b.w - 14 * s, R};
                        Rect(mz, row, Alpha(palette[33], .4f * Hover(EquipmentOption, -1, int(j))), 9 * s);
                        float iconSlot = 42 * s;
                        int index = LiveEquipmentIconIndex(name);
                        auto icon = index >= 0
                                        ? weaponIcons.Raster(unsigned(index), 12 * s, palette[14], false)
                                        : nullptr;
                        if (icon) {
                            float iw = std::min(iconSlot, float(icon->image->width));
                            PresetDraw d{
                                {row.x + 7 * s + (iconSlot - iw) * .5f, cy + (R - 12 * s) * .5f, iw, 12 * s},
                                {1, 1, 1, 1},
                                0,
                                0,
                                15,
                                {},
                                false};
                            d.raster = icon->image;
                            d.rasterStamp = icon->stamp;
                            d.clipped = true;
                            d.clip = PresetIntersect(drawClip, b);
                            paint.layers[std::size_t(mz)].draw.push_back(std::move(d));
                        }
                        Text(mz,
                             {row.x + 7 * s + iconSlot, cy + 7 * s, std::max(0.f, row.w - 14 * s - iconSlot),
                              F},
                             DecodeUTF8(RageEquipmentLabel(name)), palette[14]);
                        AddHit(mz, row, EquipmentOption, -1, int(j));
                        cy += R;
                        ++j;
                    }
                }
                drawClip = {};
                if (maskMax > 0) {
                    float th = std::max(10 * s, (b.h - 14 * s) * (b.h - 14 * s) / (b.h - 14 * s + maskMax));
                    Rect(mz,
                         {b.x + b.w - 5 * s, b.y + 7 * s + (b.h - 14 * s - th) * maskScroll / maskMax, 3 * s,
                          th},
                         palette[18], 2 * s);
                }
                RememberWindow(400 + maskGroup, windowBegin);
            }
        }
        if (choice >= 0) {
            auto windowBegin = paint.layers.size();
            BeginWindow(100 + choice);
            auto opts = Options(choice);
            bool multi = RageSpecs[std::size_t(choice)].kind == RageKind::Multi;
            float fullMarker = fonts.NativeTextSize(3, 13 * s, U"\uf00c").w + 12 * s;
            auto& mm = markerMotion[std::size_t(choice)];
            float marker = multi ? fullMarker * (mm.initialized              ? mm.value
                                                 : cfg.rage.Get(choice) != 0 ? 1.f
                                                                             : 0.f)
                                 : fullMarker;
            float w = 140 * s;
            for (const auto& v : opts)
                w = std::max(w, fonts.NativeTextSize(0, 13 * s, v).w + 38 * s + fullMarker);
            w = std::min(w, float(width) - 12 * s);
            float h = float(opts.size()) * R + 14 * s;
            bool inner = RageSpecs[std::size_t(choice)].popup != 0 && !searchChoiceAnchor;
            Box choiceSource = searchChoiceAnchor ? searchChoiceBox : choiceAnchor;
            Box row = rows[std::size_t(choice)];
            Box requested = inner ? Box{row.x + row.w + 7 * s, row.y + row.h * .5f - h * .25f, w, h}
                                  : Box{choiceSource.x + (choiceSource.w - w) * .5f,
                                        choiceSource.y + (choiceSource.h - h) * .5f, w, h};
            if (inner && requested.x + w > width - 6 * s)
                requested.x = row.x - w - 7 * s;
            placedChoice = choice;
            placedChoiceBox = PresetPopupFit(requested, width, height);
            Box b = placedChoiceBox;
            choiceBox = b;
            hits.push_back({viewport, Surface});
            int z = SurfaceLayer(b);
            AddHit(z, b, RowLabel);
            float y = b.y + 7 * s;
            for (std::size_t j = 0; j < opts.size(); ++j) {
                Box option{b.x + 7 * s, y, b.w - 14 * s, R};
                bool selected =
                    multi ? (int(cfg.rage.Get(choice)) & (1 << j)) != 0 : int(cfg.rage.Get(choice)) == int(j);
                Rect(z, option, Alpha(palette[33], .4f * Hover(Option, choice, int(j))), 15 * s / 1.6f);
                if (selected && marker > .01f)
                    Text(z, {option.x + 12 * s, y + 7 * s, marker, F}, U"\uf00c",
                         Alpha(palette[0], marker / fullMarker), 3);
                Text(z, {option.x + 12 * s + marker, y + 7 * s, option.w - 24 * s - marker, F}, opts[j],
                     selected ? palette[2] : palette[14]);
                AddHit(z, option, Option, choice, int(j));
                y += R;
            }
            RememberWindow(100 + choice, windowBegin);
        }
        if (color >= 0) {
            auto windowBegin = paint.layers.size();
            BeginWindow(200 + color);
            hits.push_back({viewport, Surface});
            auto c = PickerSettings(cfg);
            picker.SetMetrics(fonts, s);
            Box b = PresetPopupFit(
                {colorAnchor.x + colorAnchor.w + 7 * s, colorAnchor.y, 265 * s, picker.Height(s)}, width,
                height);
            if (b.x < colorAnchor.x + colorAnchor.w && colorAnchor.x - 265 * s - 7 * s >= 0)
                b.x = colorAnchor.x - 265 * s - 7 * s;
            int z = SurfaceLayer(b);
            picker.Draw(paint, z, fonts, c, b);
            picker.DrawMenus(paint, fonts, c, width, height);
            RememberWindow(200 + color, windowBegin);
        }

        if (!blocked)
            for (auto& entry : transitions)
                if (!drawnWindows.count(entry.first) && entry.second.motion.value > .001f) {
                    auto begin = paint.layers.size();
                    paint.layers.insert(paint.layers.end(), entry.second.cached.begin(),
                                        entry.second.cached.end());
                    FadeLayers(begin, entry.second.motion.value);
                }

        if (!blocked && choice < 0 && color < 0 && editing < 0 && !weaponOpen) {
            for (int i = 0; i < RageFieldCount; ++i) {
                const auto& b = sliders[std::size_t(i)];
                if (RageSpecs[std::size_t(i)].popup == 0 || b.w <= 0 || b.h <= 0 || !EnabledField(i, cfg) ||
                    sliderTip[std::size_t(i)].value <= .001f)
                    continue;
                auto value = ValueLabel(i, cfg);
                float tw = fonts.NativeTextSize(0, 13 * s, value).w,
                      t = (cfg.rage.Get(i) - RageSpecs[std::size_t(i)].minimum) /
                          (RageSpecs[std::size_t(i)].maximum - RageSpecs[std::size_t(i)].minimum);
                Box tip = PresetPopupFit(
                    {b.x + b.w * t - tw * .5f - 7 * s, b.y - F - 14 * s, tw + 14 * s, F + 9 * s}, width,
                    height);
                int z = SurfaceLayer(tip, false, 8);
                float alpha = sliderTip[std::size_t(i)].value;
                Text(z, {tip.x + 7 * s, tip.y + 4 * s, tw, F}, value, palette[0]);
                FadeLayers(std::size_t(z), alpha);
            }
        }
        int h = HitAt(mouseX, mouseY);
        if (h >= 0 && hoverTime >= .3f && weaponOpen && !createMenu && maskGroup < 0) {
            const auto& hit = hits[std::size_t(h)];
            if (hit.action == EquipmentOption && hit.field >= 0) {
                auto names = RageEquipmentNames(2047);
                if (hit.option >= 0 && std::size_t(hit.option) < names.size()) {
                    lastTooltip = WorldNameTooltip(
                        fonts, cfg, hit.box, DecodeUTF8(RageEquipmentLabel(names[std::size_t(hit.option)])),
                        width, height);
                    tooltipStored = true;
                }
            }
        }
        if (h >= 0 && hoverTime >= .3f && color < 0 && choice < 0 && editing < 0 && capture < 0) {
            const auto& hit = hits[std::size_t(h)];
            std::string key = hit.action == WeaponPanel ? "aimbot_panel_weaponpresets_tooltip"
                              : (hit.action != Open ||
                                 RageSpecs[std::size_t(std::max(0, hit.field))].kind == RageKind::Opener) &&
                                      FieldHit(hit.action) && hit.field >= 0 && hit.field < RageFieldCount
                                  ? RageSpecs[std::size_t(hit.field)].tooltip
                                  : "";
            if (!key.empty()) {
                auto title =
                    hit.action == WeaponPanel ? header : Label(RageSpecs[std::size_t(hit.field)].key);
                lastTooltip = WorldDescriptionTooltip(
                    fonts, cfg, hit.action == WeaponPanel ? hit.box : rows[std::size_t(hit.field)], title,
                    Label(key), width, height);
                tooltipStored = true;
            }
        }
        if (tooltipStored && !blocked && hoverTime >= .3f)
            AppendWorldTooltip(paint, lastTooltip, tooltipMotion.value);

        if (!error.empty()) {
            Box b = PresetPopupFit({pageBody.x, top, 350 * s, R + 14 * s}, width, height);
            int z = SurfaceLayer(b);
            Text(z, {b.x + 14 * s, b.y + 14 * s, b.w - 28 * s, F}, DecodeUTF8(error), palette[0]);
        }
    }
};
}
