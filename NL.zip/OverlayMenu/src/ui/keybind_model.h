#pragma once
#include "menu_core.h"
#include <map>
#include <set>
#include <sstream>
namespace menu {
inline constexpr std::size_t MenuKeybindLimit = 128;

struct KeybindTarget {
    std::string id, label;
    WorldKind kind = WorldKind::Check;
    float minimum = 0, maximum = 1;
    int domain = -1, index = -1;
    bool color = false;
    explicit operator bool() const {
        return domain >= 0;
    }
};
inline KeybindTarget FindKeybindTarget(const std::string& id) {
    for (std::size_t i = 0; i < WorldViewSpecs.size(); ++i) {
        const auto& s = WorldViewSpecs[i];
        if (id == "view." + std::string(s.id))
            return {id, s.key, s.kind, s.minimum, s.maximum, 0, int(i), false};
    }
    for (std::size_t i = 0; i < WorldHudSpecs.size(); ++i) {
        const auto& s = WorldHudSpecs[i];
        if (id == "hud." + std::string(s.id))
            return {id, s.key, s.kind, s.minimum, s.maximum, 1, int(i), false};
    }
    for (std::size_t i = 0; i < WorldMiscSpecs.size(); ++i) {
        const auto& s = WorldMiscSpecs[i];
        if (id == "misc." + std::string(s.id))
            return {id, s.key, s.kind, s.minimum, s.maximum, 2, int(i), false};
    }
    for (std::size_t i = 0; i < PlayersSpecs.size(); ++i) {
        const auto& s = PlayersSpecs[i];
        if (id == "players." + std::string(s.id))
            return {id, s.key, s.kind, s.minimum, s.maximum, 3, int(i), false};
    }
    for (int i = 0; i < 15; ++i)
        if (id == "playerscolor." + std::to_string(i)) {
            for (const auto& d : PlayersSpecs)
                if (d.color == i)
                    return {id, d.key, WorldKind::Decimal, 0, 1, 3, i, true};
        }
    for (int i = 0; i < 8; ++i)
        if (id == "hudcolor." + std::to_string(i))
            return {id,
                    WorldHudSpecs[std::size_t(i <= 2 ? 1 : i <= 4 ? 9 : 35)].key,
                    WorldKind::Decimal,
                    0,
                    1,
                    1,
                    i,
                    true};
    for (int i = 0; i < 21; ++i)
        if (id == "misccolor." + std::to_string(i)) {
            std::string label = "menu_keybinds_value";
            for (const auto& spec : WorldMiscSpecs)
                if (spec.color >= 0 && i >= spec.color && i < spec.color + spec.count) {
                    label = spec.key;
                    break;
                }
            return {id, label, WorldKind::Decimal, 0, 1, 2, i, true};
        }
    for (int i = 0; i < RageFieldCount; ++i) {
        const auto& s = RageSpecs[std::size_t(i)];
        if (id == "rage." + std::string(s.id) && s.kind != RageKind::Opener && s.kind != RageKind::Color) {
            WorldKind kind = s.kind == RageKind::Check     ? WorldKind::Check
                             : s.kind == RageKind::Decimal ? WorldKind::Decimal
                             : s.kind == RageKind::Choice  ? WorldKind::Choice
                             : s.kind == RageKind::Multi   ? WorldKind::Multi
                                                           : WorldKind::Integer;
            return {id, s.key, kind, s.minimum, s.maximum, 4, i, false};
        }
    }
    for (int i = 0; i < 2; ++i)
        if (id == "ragecolor." + std::to_string(i))
            return {id, "color", WorldKind::Decimal, 0, 1, 4, i, true};
    for (std::size_t i = 0; i < WorldESPSpecs.size(); ++i) {
        const auto& d = WorldESPSpecs[i];
        if (d.kind != WorldESPKind::Color && id == "esp." + std::string(d.id))
            return {id, d.key, WorldESPBindKind(d.kind), d.minimum, d.maximum, 5, int(i), false};
    }
    for (int i = 0; i < 30; ++i)
        if (id == "espcolor." + std::to_string(i)) {
            std::string label = "color";
            for (const auto& d : WorldESPSpecs)
                if (d.color >= 0 && i >= d.color && i < d.color + d.count) {
                    label = d.key;
                    break;
                }
            return {id, label, WorldKind::Decimal, 0, 1, 5, i, true};
        }
    return {};
}
inline std::array<float, 4> KeybindGet(const Settings& cfg, const KeybindTarget& t) {
    if (!t)
        throw std::runtime_error("Unknown keybind target");
    if (t.color) {
        const auto& c = t.domain == 5   ? cfg.worldESP.colors.at(std::size_t(t.index))
                        : t.domain == 4 ? cfg.rage.colors.at(std::size_t(t.index))
                        : t.domain == 1 ? cfg.worldHud.colors.at(std::size_t(t.index))
                        : t.domain == 3 ? cfg.players.colors.at(std::size_t(t.index))
                                        : cfg.worldMisc.colors.at(std::size_t(t.index));
        return {{c.r, c.g, c.b, c.a}};
    }
    float n = t.domain == 5   ? cfg.worldESP.value.at(std::size_t(t.index))
              : t.domain == 4 ? cfg.rage.Get(t.index)
              : t.domain == 0 ? cfg.worldView.value.at(std::size_t(t.index))
              : t.domain == 1 ? cfg.worldHud.value.at(std::size_t(t.index))
              : t.domain == 3 ? cfg.players.value.at(std::size_t(t.index))
                              : cfg.worldMisc.value.at(std::size_t(t.index));
    return {{n, 0, 0, 0}};
}
inline bool KeybindValueValid(const KeybindTarget& t, const std::array<float, 4>& v) {
    if (!t)
        return false;
    for (float n : v)
        if (!std::isfinite(n))
            return false;
    if (t.color) {
        if (t.domain == 5 && WorldESPColorSpecs[std::size_t(t.index)].alphaLocked && v[3] != 1)
            return false;
        for (float n : v)
            if (n < 0 || n > 1)
                return false;
        return true;
    }
    return v[0] >= t.minimum && v[0] <= t.maximum &&
           (t.kind == WorldKind::Decimal || v[0] == std::floor(v[0])) && v[1] == 0 && v[2] == 0 && v[3] == 0;
}
inline void KeybindSet(Settings& cfg, const KeybindTarget& t, const std::array<float, 4>& v) {
    if (t.color) {
        auto& c = t.domain == 5   ? cfg.worldESP.colors.at(std::size_t(t.index))
                  : t.domain == 4 ? cfg.rage.colors.at(std::size_t(t.index))
                  : t.domain == 1 ? cfg.worldHud.colors.at(std::size_t(t.index))
                  : t.domain == 3 ? cfg.players.colors.at(std::size_t(t.index))
                                  : cfg.worldMisc.colors.at(std::size_t(t.index));
        c = {v[0], v[1], v[2], v[3]};
    } else if (t.domain == 5)
        cfg.worldESP.Set(std::size_t(t.index), v[0]);
    else if (t.domain == 4)
        cfg.rage.Set(t.index, v[0]);
    else if (t.domain == 0)
        cfg.worldView.Set(std::size_t(t.index), v[0]);
    else if (t.domain == 1)
        cfg.worldHud.Set(std::size_t(t.index), v[0]);
    else if (t.domain == 2)
        cfg.worldMisc.Set(std::size_t(t.index), v[0]);
    else if (t.domain == 3)
        cfg.players.Set(std::size_t(t.index), v[0]);
}
inline bool KeybindIDValid(const std::string& id) {
    return id.size() == 32 && std::all_of(id.begin(), id.end(), [](char c) {
               return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f');
           });
}
inline bool KeybindValid(const MenuKeybind& b) {
    return KeybindIDValid(b.id) && b.key >= 0 && b.key <= 255 && b.mode >= 0 && b.mode <= 1 &&
           KeybindValueValid(FindKeybindTarget(b.target), b.value);
}
inline std::string KeybindPack(const MenuKeybind& b) {
    std::string s = b.id + "|" + b.target + "|" + std::to_string(b.key) + "|" + std::to_string(b.mode) + "|" +
                    (b.shown ? "1" : "0") + "|";
    for (std::size_t i = 0; i < 4; ++i) {
        if (i)
            s += ",";
        s += std::to_string(b.value[i]);
    }
    return s;
}
inline std::vector<std::string> KeybindSplit(const std::string& text, char separator) {
    std::vector<std::string> out;
    std::size_t start = 0;
    for (;;) {
        auto end = text.find(separator, start);
        out.push_back(text.substr(start, end == std::string::npos ? end : end - start));
        if (end == std::string::npos)
            return out;
        start = end + 1;
    }
}
inline int KeybindInteger(const std::string& s, int maximum) {
    if (s.empty() || s.size() > 10 ||
        !std::all_of(s.begin(), s.end(), [](char c) { return c >= '0' && c <= '9'; }))
        throw std::runtime_error("Invalid keybind integer");
    auto n = std::stoul(s);
    if (n > unsigned(maximum))
        throw std::runtime_error("Keybind integer out of range");
    return int(n);
}
inline MenuKeybind KeybindUnpack(const std::string& text) {
    if (text.size() > 512)
        throw std::runtime_error("Keybind record is too large");
    auto f = KeybindSplit(text, '|');
    if (f.size() != 6)
        throw std::runtime_error("Invalid keybind record");
    MenuKeybind b;
    b.id = f[0];
    b.target = f[1];
    b.key = KeybindInteger(f[2], 255);
    b.mode = KeybindInteger(f[3], 1);
    b.shown = KeybindInteger(f[4], 1) != 0;
    auto values = KeybindSplit(f[5], ',');
    if (values.size() != 4)
        throw std::runtime_error("Invalid keybind value");
    for (std::size_t i = 0; i < 4; ++i) {
        std::size_t used = 0;
        b.value[i] = std::stof(values[i], &used);
        if (used != values[i].size())
            throw std::runtime_error("Invalid keybind number");
    }
    if (!KeybindValid(b))
        throw std::runtime_error("Invalid keybind target, key, mode or value");
    return b;
}
inline void KeybindCapture(const Settings& cfg, std::map<std::string, std::string>& values) {
    if (cfg.keybinds.size() > MenuKeybindLimit)
        throw std::runtime_error("Keybind limit: 128");
    std::set<std::string> ids;
    for (const auto& b : cfg.keybinds)
        if (!KeybindValid(b) || !ids.insert(b.id).second)
            throw std::runtime_error("Invalid keybind catalog");
    values["keybinds.version"] = "1";
    values["keybinds.count"] = std::to_string(cfg.keybinds.size());
    for (std::size_t i = 0; i < cfg.keybinds.size(); ++i)
        values["keybinds." + std::to_string(i)] = KeybindPack(cfg.keybinds[i]);
}
inline void KeybindRead(Settings& cfg, const std::map<std::string, std::string>& values) {
    std::vector<MenuKeybind> next;
    std::set<std::string> ids;
    std::size_t fields = 0;
    for (const auto& kv : values)
        if (kv.first.rfind("keybinds.", 0) == 0)
            ++fields;
    if (!fields) {
        cfg.keybinds.clear();
        return;
    }
    if (values.at("keybinds.version") != "1")
        throw std::runtime_error("Unsupported keybind format");
    int count = KeybindInteger(values.at("keybinds.count"), int(MenuKeybindLimit));
    if (fields != std::size_t(count) + 2)
        throw std::runtime_error("Incomplete keybind catalog");
    for (int i = 0; i < count; ++i) {
        auto b = KeybindUnpack(values.at("keybinds." + std::to_string(i)));
        if (!ids.insert(b.id).second)
            throw std::runtime_error("Duplicate keybind ID");
        next.push_back(std::move(b));
    }
    cfg.keybinds = std::move(next);
}
inline std::string MenuKeyName(int key) {
    if (key >= 'A' && key <= 'Z')
        return std::string(1, char(key));
    if (key >= '0' && key <= '9')
        return std::string(1, char(key));
    if (key >= 112 && key <= 135)
        return "F" + std::to_string(key - 111);
    if (key >= 96 && key <= 105)
        return "Num " + std::to_string(key - 96);
    switch (key) {
    case 0:
        return "Unbound";
    case 1:
        return "Mouse 1";
    case 2:
        return "Mouse 2";
    case 4:
        return "Mouse 3";
    case 5:
        return "Mouse 4";
    case 6:
        return "Mouse 5";
    case 8:
        return "Backspace";
    case 9:
        return "Tab";
    case 13:
        return "Enter";
    case 16:
        return "Shift";
    case 17:
        return "Ctrl";
    case 18:
        return "Alt";
    case 19:
        return "Pause";
    case 20:
        return "Caps Lock";
    case 27:
        return "Escape";
    case 32:
        return "Space";
    case 33:
        return "Page Up";
    case 34:
        return "Page Down";
    case 35:
        return "End";
    case 36:
        return "Home";
    case 37:
        return "Left";
    case 38:
        return "Up";
    case 39:
        return "Right";
    case 40:
        return "Down";
    case 44:
        return "Print Screen";
    case 45:
        return "Insert";
    case 46:
        return "Delete";
    case 91:
        return "Left Win";
    case 92:
        return "Right Win";
    case 106:
        return "Num *";
    case 107:
        return "Num +";
    case 109:
        return "Num -";
    case 110:
        return "Num .";
    case 111:
        return "Num /";
    case 144:
        return "Num Lock";
    case 145:
        return "Scroll Lock";
    case 160:
        return "Left Shift";
    case 161:
        return "Right Shift";
    case 162:
        return "Left Ctrl";
    case 163:
        return "Right Ctrl";
    case 164:
        return "Left Alt";
    case 165:
        return "Right Alt";
    case 186:
        return ";";
    case 187:
        return "=";
    case 188:
        return ",";
    case 189:
        return "-";
    case 190:
        return ".";
    case 191:
        return "/";
    case 192:
        return "`";
    case 219:
        return "[";
    case 220:
        return "\\";
    case 221:
        return "]";
    case 222:
        return "'";
    default:
        return "VK " + std::to_string(key);
    }
}
struct KeybindRuntime {
    struct State {
        std::string signature;
        bool down = false, armed = false, toggled = false, active = false;
    };
    std::map<std::string, State> states;
    std::string preset;
    template <class Reader>
    void Poll(const Settings& cfg, Reader&& read, bool focused, bool blocked, const std::string& selection) {
        if (preset != selection) {
            states.clear();
            preset = selection;
        }
        std::set<std::string> present;
        for (const auto& b : cfg.keybinds) {
            if (!KeybindValid(b))
                continue;
            present.insert(b.id);
            auto& s = states[b.id];
            const auto signature = KeybindPack(b);
            bool down = b.key != 0 && focused && read(b.key);
            if (s.signature != signature) {
                s = State{};
                s.signature = signature;
                s.down = down;
                s.armed = !down;
            }
            if (!focused || blocked || !b.key) {
                s.active = s.toggled = false;
                s.down = down;
                s.armed = false;
                continue;
            }
            if (!s.armed) {
                s.armed = !down;
                s.down = down;
                s.active = false;
                continue;
            }
            if (down && !s.down && b.mode == 0)
                s.toggled = !s.toggled;
            s.active = b.mode == 1 ? down : s.toggled;
            s.down = down;
        }
        for (auto it = states.begin(); it != states.end();)
            if (!present.count(it->first))
                it = states.erase(it);
            else
                ++it;
    }
    bool Active(const std::string& id) const {
        auto it = states.find(id);
        return it != states.end() && it->second.active;
    }
};

struct KeybindOverrideGuard {
    Settings& cfg;
    std::vector<std::pair<KeybindTarget, std::array<float, 4>>> saved;
    KeybindOverrideGuard(Settings& settings, const KeybindRuntime& runtime) : cfg(settings) {
        std::vector<std::pair<KeybindTarget, std::array<float, 4>>> pending;
        saved.reserve(cfg.keybinds.size());
        pending.reserve(cfg.keybinds.size());
        for (const auto& b : cfg.keybinds)
            if (runtime.Active(b.id) && KeybindValid(b)) {
                auto t = FindKeybindTarget(b.target);
                if (std::none_of(saved.begin(), saved.end(),
                                 [&](const auto& entry) { return entry.first.id == t.id; }))
                    saved.push_back({t, KeybindGet(cfg, t)});
                pending.push_back({std::move(t), b.value});
            }

        for (const auto& entry : pending)
            KeybindSet(cfg, entry.first, entry.second);
    }
    ~KeybindOverrideGuard() {
        for (auto it = saved.rbegin(); it != saved.rend(); ++it)
            KeybindSet(cfg, it->first, it->second);
    }
    KeybindOverrideGuard(const KeybindOverrideGuard&) = delete;
    KeybindOverrideGuard& operator=(const KeybindOverrideGuard&) = delete;
};
}