#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <optional>
namespace menu {
namespace live_esp_capsule {
struct Vec3 {
    double x, y, z;
};
struct Rect {
    float left, top, right, bottom;
};
inline double Dot(Vec3 a, Vec3 b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}
inline bool Finite(Vec3 p) {
    return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z) && std::abs(p.x) < 1e7 &&
           std::abs(p.y) < 1e7 && std::abs(p.z) < 1e7;
}
inline float PixelRound(float v) {
    return std::trunc(v + std::copysign(.4999999701976776f, v));
}

inline std::optional<std::array<double, 2>> SphereAxis(Vec3 a, double a0, Vec3 b, double b0, Vec3 p,
                                                       double r) {
    const double d = Dot(b, p) + b0, n = Dot(a, p) + a0, along = Dot(a, b);
    const Vec3 lateral{a.x - along * b.x, a.y - along * b.y, a.z - along * b.z};
    const double side = n - along * d, denom = d * d - r * r;
    if (!std::isfinite(denom) || denom <= 0)
        return {};
    const double radicand = side * side + denom * Dot(lateral, lateral);
    if (!std::isfinite(radicand) || radicand < 0)
        return {};
    const double spread = r * std::sqrt(radicand);
    const double lo = along + (side * d - spread) / denom, hi = along + (side * d + spread) / denom;
    if (!std::isfinite(lo) || !std::isfinite(hi))
        return {};
    return std::array<double, 2>{{lo, hi}};
}

inline std::optional<Rect> Project(const std::array<float, 16>& m, Vec3 low, Vec3 high, int width, int height,
                                   bool pixelRound = true) {
    constexpr double radius = 16.0, nearDepth = 17.0;
    if (width <= 0 || height <= 0 || width > 16384 || height > 16384 || !Finite(low) || !Finite(high))
        return {};
    for (float f : m)
        if (!std::isfinite(f))
            return {};
    const Vec3 depthRow{m[12], m[13], m[14]};
    const double norm = std::sqrt(Dot(depthRow, depthRow));

    if (!std::isfinite(norm) || norm < 1e-12)
        return {};
    const Vec3 b{m[12] / norm, m[13] / norm, m[14] / norm};
    const double b0 = m[15] / norm;
    const Vec3 ax{m[0] / norm, m[1] / norm, m[2] / norm}, ay{m[4] / norm, m[5] / norm, m[6] / norm};
    const double ax0 = m[3] / norm, ay0 = m[7] / norm;
    double dl = Dot(b, low) + b0, dh = Dot(b, high) + b0;
    if (!std::isfinite(dl) || !std::isfinite(dh) || (dl < nearDepth && dh < nearDepth))
        return {};
    if (dl < nearDepth || dh < nearDepth) {
        Vec3& outside = dl < nearDepth ? low : high;
        const Vec3 inside = dl < nearDepth ? high : low;
        const double outsideDepth = dl < nearDepth ? dl : dh, insideDepth = dl < nearDepth ? dh : dl;
        const double t = (nearDepth - outsideDepth) / (insideDepth - outsideDepth);
        outside = {outside.x + (inside.x - outside.x) * t, outside.y + (inside.y - outside.y) * t,
                   outside.z + (inside.z - outside.z) * t};
    }
    double left = std::numeric_limits<double>::infinity(), top = left, right = -left, bottom = -left;
    const double halfWidth = width * .5, halfHeight = height * .5;
    for (Vec3 center : {low, high}) {
        auto x = SphereAxis(ax, ax0, b, b0, center, radius), y = SphereAxis(ay, ay0, b, b0, center, radius);
        if (!x || !y)
            return {};
        left = std::min(left, halfWidth + (*x)[0] * halfWidth);
        right = std::max(right, halfWidth + (*x)[1] * halfWidth);
        top = std::min(top, halfHeight - (*y)[1] * halfHeight);
        bottom = std::max(bottom, halfHeight - (*y)[0] * halfHeight);
    }
    if (!std::isfinite(left) || !std::isfinite(top) || !std::isfinite(right) || !std::isfinite(bottom) ||
        std::max({std::abs(left), std::abs(top), std::abs(right), std::abs(bottom)}) > 1e7)
        return {};

    if (right < 0 || bottom < 0 || left > width || top > height)
        return {};
    Rect result{float(left), float(top), float(right), float(bottom)};
    if (pixelRound) {
        result.left = PixelRound(result.left);
        result.top = PixelRound(result.top);
        result.right = PixelRound(result.right);
        result.bottom = PixelRound(result.bottom);
    }
    if (result.right - result.left < 1 || result.bottom - result.top < 1)
        return {};
    return result;
}
}
}
