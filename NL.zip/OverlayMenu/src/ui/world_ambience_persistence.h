#pragma once

inline std::string AmbienceNumberText(float v) {
    char b[32];
    std::snprintf(b, sizeof b, "%.9g", double(v));
    return b;
}
inline float AmbienceNumberParse(const std::string& text) {
    if (text.empty() || text.size() > 32)
        throw std::runtime_error("Invalid Ambience number");
    std::size_t used = 0;
    float v = std::stof(text, &used);
    if (used != text.size() || !std::isfinite(v))
        throw std::runtime_error("Invalid Ambience number");
    return v;
}
inline void AmbienceCapture(const WorldAmbienceValues& a, std::map<std::string, std::string>& values) {
    if (a.profiles.empty() || a.profiles.size() > WorldAmbienceValues::MaxProfiles)
        throw std::runtime_error("Invalid Ambience profiles");
    values["world.ambience.profiles"] = std::to_string(a.profiles.size());
    for (std::size_t p = 0; p < a.profiles.size(); ++p) {
        const auto& profile = a.profiles[p];
        const auto base = "world.ambience." + std::to_string(p) + ".";
        if (p >= 1)
            values[base + "map"] = profile.map;
        if (!profile.enabled)
            values[base + "enabled"] = "0";
        if (!profile.customSkyMaterial.empty()) {
            if (!AmbienceSkyCustomMaterial(profile.customSkyMaterial))
                throw std::runtime_error("Invalid custom Sky material");
            values[base + "custom_sky"] = profile.customSkyMaterial;
        }
        for (std::size_t i = 0; i < AmbienceSpecs.size(); ++i)
            if (AmbienceSpecs[i].kind != AmbienceKind::Opener && profile.value[i] != AmbienceSpecs[i].initial)
                values[base + AmbienceSpecs[i].id] = AmbienceNumberText(profile.value[i]);
        for (std::size_t i = 0; i < profile.colors.size(); ++i) {
            const auto& c = profile.colors[i];
            const auto& d = AmbienceColorSpecs[i].initial;
            if (c.r == d.r && c.g == d.g && c.b == d.b && c.a == d.a)
                continue;
            int j = 0;
            for (float n : {c.r, c.g, c.b, c.a})
                values[base + "color." + std::to_string(i) + "." + std::to_string(j++)] =
                    AmbienceNumberText(n);
        }
    }
}
inline void AmbienceRead(WorldAmbienceValues& out, const std::map<std::string, std::string>& values) {
    const std::string prefix = "world.ambience.";
    bool any = false;
    for (auto it = values.lower_bound(prefix); it != values.end() && it->first.rfind(prefix, 0) == 0; ++it) {
        any = true;
        break;
    }
    WorldAmbienceValues next;
    if (!any) {
        out = next;
        return;
    }
    auto count = values.find("world.ambience.profiles");
    if (count == values.end())
        throw std::runtime_error("Incomplete Ambience profiles");
    float n = AmbienceNumberParse(count->second);
    if (n != std::floor(n) || n < 1 || n > float(WorldAmbienceValues::MaxProfiles))
        throw std::runtime_error("Invalid Ambience profile count");
    next.profiles.clear();
    for (std::size_t p = 0; p < std::size_t(n); ++p) {
        const auto base = prefix + std::to_string(p) + ".";
        AmbienceProfile profile;
        if (p >= 1) {
            auto m = values.find(base + "map");
            std::string name;
            if (m != values.end())
                name = m->second;
            else if (p == 1) {
                bool keys = false;
                for (auto it = values.lower_bound(base); it != values.end() && it->first.rfind(base, 0) == 0;
                     ++it) {
                    keys = true;
                    break;
                }
                if (!keys)
                    continue;
                name = WorldAmbienceValues::MainMenuMap;
            }
            if (!WorldAmbienceValues::ValidMap(name))
                throw std::runtime_error("Invalid Ambience map");
            for (std::size_t q = 1; q < next.profiles.size(); ++q)
                if (next.profiles[q].map == name)
                    throw std::runtime_error("Duplicate Ambience map");
            profile.map = name;
        }
        if (auto e = values.find(base + "enabled"); e != values.end()) {
            if (e->second != "0" && e->second != "1")
                throw std::runtime_error("Invalid Ambience enabled flag");
            profile.enabled = e->second == "1";
        }
        if (auto custom = values.find(base + "custom_sky"); custom != values.end()) {
            if (!AmbienceSkyCustomMaterial(custom->second))
                throw std::runtime_error("Invalid custom Sky material");
            profile.customSkyMaterial = custom->second;
        }
        for (std::size_t i = 0; i < AmbienceSpecs.size(); ++i) {
            const auto& d = AmbienceSpecs[i];
            if (d.kind == AmbienceKind::Opener)
                continue;

            auto it = values.find(base + d.id);
            if (it == values.end())
                continue;
            float v = AmbienceNumberParse(it->second);
            if (v < d.minimum || v > d.maximum)
                throw std::runtime_error("Ambience value out of range");
            if (d.kind != AmbienceKind::Decimal && v != std::floor(v))
                throw std::runtime_error("Invalid Ambience integer");
            profile.Set(i, v);
        }
        for (std::size_t i = 0; i < profile.colors.size(); ++i) {
            int present = 0;
            std::array<float, 4> ch{};
            for (int j = 0; j < 4; ++j) {
                auto it = values.find(base + "color." + std::to_string(i) + "." + std::to_string(j));
                if (it == values.end())
                    continue;
                ++present;
                float v = AmbienceNumberParse(it->second);
                if (v < 0 || v > 1)
                    throw std::runtime_error("Ambience color out of range");
                ch[std::size_t(j)] = v;
            }
            if (present == 0)
                continue;
            if (present != 4)
                throw std::runtime_error("Incomplete Ambience color");
            profile.SetColor(i, {ch[0], ch[1], ch[2], ch[3]});
        }
        next.profiles.push_back(std::move(profile));
    }
    out = std::move(next);
}
