#pragma once
#include "watermark_ui.h"
#include <map>
namespace menu {

struct WatermarkHostSample {
    std::optional<float> memoryUsedGB, memoryTotalGB, cpuLoad, maxCpuLoad, cpuGHz, maxCpuGHz, gpuLoad;
    std::vector<float> cpuCores;
    void Apply(WatermarkData& d) const {
        d.memoryUsedGB = memoryUsedGB;
        d.memoryTotalGB = memoryTotalGB;
        d.cpuLoad = cpuLoad;
        d.maxCpuLoad = maxCpuLoad;
        d.cpuGHz = cpuGHz;
        d.maxCpuGHz = maxCpuGHz;
        d.gpuLoad = gpuLoad;
        d.cpuCores = cpuCores;
    }
};

inline std::optional<std::uint64_t> WatermarkGpuAdapterId(const std::wstring& name) {
    auto at = name.find(L"luid_");
    if (at == std::wstring::npos)
        return {};
    at += 5;
    auto end = name.find(L"_phys_", at);
    if (end == std::wstring::npos)
        return {};
    auto split = name.find(L'_', at);
    if (split == std::wstring::npos || split >= end)
        return {};
    try {
        std::size_t a = 0, b = 0;
        auto hi = std::stoull(name.substr(at, split - at), &a, 16),
             lo = std::stoull(name.substr(split + 1, end - split - 1), &b, 16);
        if (a == split - at && b == end - split - 1 && hi <= 0xffffffffULL && lo <= 0xffffffffULL)
            return (hi << 32) | lo;
    } catch (const std::exception&) {
    }
    return {};
}
inline std::optional<float>
WatermarkGpuEngineLoad(const std::vector<std::pair<std::wstring, double>>& counters,
                       const std::vector<std::uint64_t>* hardwareAdapters = nullptr) {
    std::map<std::uint64_t, double> adapters;
    if (hardwareAdapters)
        for (auto id : *hardwareAdapters)
            adapters.try_emplace(id, 0.);
    for (const auto& entry : counters) {
        std::wstring name = entry.first;
        for (auto& c : name)
            if (c >= L'A' && c <= L'Z')
                c += L'a' - L'A';
        auto luid = name.find(L"luid_"), phys = name.find(L"_phys_", luid),
             engine = name.find(L"_eng_", luid);
        if (luid == std::wstring::npos || phys == std::wstring::npos || engine == std::wstring::npos ||
            phys >= engine || !std::isfinite(entry.second) || entry.second < 0)
            continue;
        auto id = WatermarkGpuAdapterId(name);
        if (!id)
            continue;
        auto key = *id;
        if (hardwareAdapters && adapters.find(key) == adapters.end())
            continue;
        adapters.try_emplace(key, 0.);
        if (name.find(L"engtype_3d") == std::wstring::npos && name.find(L"_3d") == std::wstring::npos)
            continue;
        adapters[key] += entry.second;
    }
    if (adapters.empty())
        return {};
    double load = 0;
    for (const auto& adapter : adapters)
        load = std::max(load, std::clamp(adapter.second, 0., 100.));
    return float(load);
}
struct WatermarkProcessorKey {
    unsigned long group = 0, index = 0;
    bool operator<(const WatermarkProcessorKey& other) const {
        return group != other.group ? group < other.group : index < other.index;
    }
};
inline std::optional<WatermarkProcessorKey> WatermarkProcessorInstance(const std::wstring& name) {
    auto comma = name.find(L',');
    if (comma == std::wstring::npos || name.find(L"_Total") != std::wstring::npos)
        return {};
    try {
        std::size_t a = 0, b = 0;
        auto g = std::stoul(name.substr(0, comma), &a), i = std::stoul(name.substr(comma + 1), &b);
        if (a == comma && b == name.size() - comma - 1 && name[0] != L'-' && name[comma + 1] != L'-')
            return WatermarkProcessorKey{g, i};
    } catch (const std::exception&) {
    }
    return {};
}

inline void WatermarkNativeFrequency(WatermarkHostSample& sample,
                                     const std::vector<std::pair<std::wstring, double>>& frequency,
                                     const std::vector<std::pair<std::wstring, double>>& performance,
                                     unsigned long baseMhz) {
    sample.cpuGHz.reset();
    sample.maxCpuGHz.reset();
    std::map<WatermarkProcessorKey, unsigned long> mhz;
    for (const auto& row : frequency) {
        auto key = WatermarkProcessorInstance(row.first);
        if (key && std::isfinite(row.second) && row.second >= 0 && row.second <= 100000)
            mhz[*key] = static_cast<unsigned long>(row.second);
    }
    if (baseMhz)
        for (const auto& row : performance) {
            auto key = WatermarkProcessorInstance(row.first);
            if (!key || !std::isfinite(row.second) || row.second < 0)
                continue;
            auto it = mhz.find(*key);
            double value = std::floor(row.second * baseMhz / 100. + .5);
            if (it != mhz.end() && value <= 100000)
                it->second = static_cast<unsigned long>(value);
        }
    unsigned long count = 0, peak = 0;
    unsigned long long sum = 0;
    for (const auto& row : mhz)
        if (row.second) {
            sum += row.second;
            ++count;
            peak = std::max(peak, row.second);
        }
    if (count) {
        sample.cpuGHz = float(sum / count) / 1000.f;
        sample.maxCpuGHz = float(peak) / 1000.f;
    }
}
inline void WatermarkCpuSample(WatermarkHostSample& sample, const std::vector<float>& cores) {
    sample.cpuCores.clear();
    sample.cpuLoad.reset();
    sample.maxCpuLoad.reset();
    if (cores.empty())
        return;
    double sum = 0;
    float peak = 0;
    for (float v : cores) {
        if (!std::isfinite(v) || v < 0)
            return;
        v = std::clamp(v, 0.f, 1.f);
        sum += v;
        peak = std::max(peak, v);
    }
    sample.cpuCores = cores;
    for (auto& v : sample.cpuCores)
        v = std::clamp(v, 0.f, 1.f);
    sample.cpuLoad = float(sum / cores.size() * 100);
    sample.maxCpuLoad = peak * 100;
}
}
