#pragma once
#include <windows.h>
#include "presets_storage.h"

namespace menu {
inline PresetStorageChoice PresetStorageForHost(const std::filesystem::path& moduleRoot) {
    namespace fs = std::filesystem;
    const auto ini = moduleRoot / L"MenuStudio.ini";
    wchar_t location[64]{}, overrideRoot[32768]{}, executable[32768]{};
    auto count = GetPrivateProfileStringW(L"Presets", L"Location", L"Neverlose", location, 64, ini.c_str());
    if (count >= 63)
        throw std::runtime_error("Presets Location is too long");
    const bool gameRoot = lstrcmpiW(location, L"GameRoot") == 0;
    if (!gameRoot && lstrcmpiW(location, L"Neverlose") != 0)
        throw std::runtime_error("Presets Location must be Neverlose or GameRoot");
    count = GetPrivateProfileStringW(L"Presets", L"GameRoot", L"", overrideRoot, 32768, ini.c_str());
    if (count >= 32767)
        throw std::runtime_error("Presets GameRoot is too long");
    count = GetModuleFileNameW(nullptr, executable, 32768);
    if (!count || count >= 32768)
        throw std::runtime_error("Host executable path unavailable for preset storage");
    auto portableRoot = overrideRoot[0] ? fs::path(overrideRoot) : PresetGameRoot(fs::path(executable));
    if (!portableRoot.is_absolute())
        throw std::runtime_error("Presets GameRoot must be an absolute directory");
    const fs::path normal = L"C:\\neverlose\\.Nl";
    const auto portable = portableRoot / L".Nl";
    return SelectPresetStorage(gameRoot ? portable : normal, gameRoot ? normal : portable,
                               moduleRoot / L"presets");
}
}