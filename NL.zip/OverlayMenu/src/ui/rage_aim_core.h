#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace menu::rage_aim {
struct Vec3 {
    double x = 0, y = 0, z = 0;
};
struct Angles {
    double pitch = 0, yaw = 0;
};

enum class Hitbox : unsigned { Head = 0, Chest, Stomach, Arms, Legs, Feet };

struct Volume {
    bool valid = false;
    unsigned shape = 0;
    Vec3 lo{}, hi{}, origin{};
    double qx = 0, qy = 0, qz = 0, qw = 1, radius = 0;
};
struct Point {
    Hitbox hitbox = Hitbox::Head;
    Vec3 position{};
    bool visible = false;
    Volume volume{};
};
struct Target {
    std::uint32_t id = 0;
    bool enemy = false, alive = false;
    std::vector<Point> points;
};
struct Config {
    bool enabled = false, silent = false, automaticFire = false;
    double fieldOfView = 0;
    unsigned hitboxes = 0;
    double hitChance = 0;
    bool quickStop = false, betweenShots = false;
    int minDamage = 1;
};
struct Frame {
    bool valid = false, weaponReady = false, manualFire = false;
    Vec3 eye{};
    Angles view{};
    std::vector<Target> targets;
};
struct Plan {
    bool hasTarget = false, setCommandAngles = false, setCameraAngles = false, requestFire = false;
    std::uint32_t target = 0;
    Hitbox hitbox = Hitbox::Head;
    Angles angles{};
    double errorDegrees = 0;
};
inline bool Finite(Vec3 v) {
    return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
}
inline bool Finite(Angles a) {
    return std::isfinite(a.pitch) && std::isfinite(a.yaw);
}
inline Plan Select(const Config& c, const Frame& f) {
    Plan out{};
    if (!c.enabled || !f.valid || !Finite(f.eye) || !Finite(f.view) || !std::isfinite(c.fieldOfView) ||
        c.fieldOfView < 0 || c.fieldOfView > 180 || !(c.hitboxes & 63u))
        return out;
    constexpr double pi = 3.14159265358979323846, rad = pi / 180.0;
    const double cp = std::cos(f.view.pitch * rad);
    const Vec3 forward{cp * std::cos(f.view.yaw * rad), cp * std::sin(f.view.yaw * rad),
                       -std::sin(f.view.pitch * rad)};
    double best = 181;
    for (const auto& target : f.targets) {
        if (!target.id || !target.enemy || !target.alive)
            continue;
        for (const auto& point : target.points) {
            const unsigned bit = static_cast<unsigned>(point.hitbox);
            if (bit >= 6 || !(c.hitboxes & (1u << bit)) || !point.visible || !Finite(point.position))
                continue;
            const double x = point.position.x - f.eye.x, y = point.position.y - f.eye.y,
                         z = point.position.z - f.eye.z;
            const double xy = std::hypot(x, y), length = std::hypot(xy, z);
            if (!std::isfinite(length) || length < 1e-6)
                continue;
            const double dot =
                std::clamp((x * forward.x + y * forward.y + z * forward.z) / length, -1.0, 1.0);
            const double error = std::acos(dot) / rad;
            if (!std::isfinite(error) || error > c.fieldOfView + 1e-9 || error >= best)
                continue;
            best = error;
            out.hasTarget = true;
            out.target = target.id;
            out.hitbox = point.hitbox;
            out.angles = {-std::atan2(z, xy) / rad, std::atan2(y, x) / rad};
            out.errorDegrees = error;
        }
    }
    if (out.hasTarget) {

        out.requestFire = c.automaticFire && f.weaponReady;
        const bool shooting = f.manualFire || out.requestFire;
        out.setCommandAngles = shooting;
        out.setCameraAngles = shooting && !c.silent;
    }
    return out;
}

class SinglePointSelector {
    const Config& c_;
    const Frame& f_;
    Vec3 forward_{};
    bool valid_ = false;
    static constexpr double pi_ = 3.14159265358979323846, rad_ = pi_ / 180.0;

public:
    SinglePointSelector(const Config& c, const Frame& f) : c_(c), f_(f) {
        if (!c.enabled || !f.valid || !Finite(f.eye) || !Finite(f.view) || !std::isfinite(c.fieldOfView) ||
            c.fieldOfView < 0 || c.fieldOfView > 180 || !(c.hitboxes & 63u))
            return;
        const double cp = std::cos(f.view.pitch * rad_);
        forward_ = {cp * std::cos(f.view.yaw * rad_), cp * std::sin(f.view.yaw * rad_),
                    -std::sin(f.view.pitch * rad_)};
        valid_ = true;
    }
    Plan Pick(std::uint32_t id, Hitbox kind, Vec3 pos) const {
        Plan out{};
        const unsigned bit = static_cast<unsigned>(kind);
        if (!valid_ || !id || bit >= 6 || !(c_.hitboxes & (1u << bit)) || !Finite(pos))
            return out;
        const double x = pos.x - f_.eye.x, y = pos.y - f_.eye.y, z = pos.z - f_.eye.z;
        const double xy = std::hypot(x, y), length = std::hypot(xy, z);
        if (!std::isfinite(length) || length < 1e-6)
            return out;
        const double dot = std::clamp((x * forward_.x + y * forward_.y + z * forward_.z) / length, -1.0, 1.0);
        const double error = std::acos(dot) / rad_;
        if (!std::isfinite(error) || error > c_.fieldOfView + 1e-9 || error >= 181.)
            return out;
        out.hasTarget = true;
        out.target = id;
        out.hitbox = kind;
        out.angles = {-std::atan2(z, xy) / rad_, std::atan2(y, x) / rad_};
        out.errorDegrees = error;
        out.requestFire = c_.automaticFire && f_.weaponReady;
        const bool shooting = f_.manualFire || out.requestFire;
        out.setCommandAngles = shooting;
        out.setCameraAngles = shooting && !c_.silent;
        return out;
    }
};

}
