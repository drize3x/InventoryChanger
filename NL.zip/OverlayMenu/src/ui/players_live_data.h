#pragma once

#include "menu_core.h"
#include "language_catalog.h"
#include "watermark_speed_delay.h"
#include <optional>
#include <limits>
#include "players_live_capsule_bounds.h"
#include "players_preview_icons.h"
#include "players_esp_native_rules.h"
#include "rage_esp_hitboxes.h"
namespace menu {
struct LiveESPVec {
    float x = 0, y = 0, z = 0;
};
inline bool operator==(const LiveESPVec& a, const LiveESPVec& b) {
    return a.x == b.x && a.y == b.y && a.z == b.z;
}
inline bool operator!=(const LiveESPVec& a, const LiveESPVec& b) {
    return !(a == b);
}
struct LiveESPMatrix {
    std::array<float, 16> m{};
};
inline bool LiveESPFinite(LiveESPVec p) {
    return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z) && std::abs(p.x) < 1e7f &&
           std::abs(p.y) < 1e7f && std::abs(p.z) < 1e7f;
}
inline std::optional<std::array<float, 2>> LiveESPProject(const LiveESPMatrix& matrix, LiveESPVec p,
                                                          int width, int height, bool pixelRound = true) {
    if (width <= 0 || height <= 0 || width > 16384 || height > 16384 || !LiveESPFinite(p))
        return {};
    for (float f : matrix.m)
        if (!std::isfinite(f))
            return {};
    auto dot = [&](int row) {
        const auto& m = matrix.m;
        return (m[std::size_t(row)] * p.x + m[std::size_t(row + 1)] * p.y) +
               (m[std::size_t(row + 2)] * p.z + m[std::size_t(row + 3)]);
    };
    float w = dot(12);
    if (!std::isfinite(w) || w < .001f)
        return {};
    float inverse = 1.f / w, halfWidth = float(width) * .5f, halfHeight = float(height) * .5f;
    float x = (dot(0) * inverse) * halfWidth + halfWidth, y = (dot(4) * inverse) * (-halfHeight) + halfHeight;
    if (!std::isfinite(x) || !std::isfinite(y) || std::abs(x) > 1e7f || std::abs(y) > 1e7f)
        return {};

    if (pixelRound) {
        x = std::trunc(x + std::copysign(.4999999701976776f, x));
        y = std::trunc(y + std::copysign(.4999999701976776f, y));
    }
    return std::array<float, 2>{{x, y}};
}

inline std::optional<Box> LiveESPBounds(const LiveESPMatrix& matrix, LiveESPVec origin, LiveESPVec lo,
                                        LiveESPVec hi, int width, int height) {
    if (!LiveESPFinite(origin) || !LiveESPFinite(lo) || !LiveESPFinite(hi) || lo.x >= hi.x || lo.y >= hi.y ||
        hi.z - lo.z < 32.f || hi.x - lo.x > 512 || hi.y - lo.y > 512 || hi.z - lo.z > 512)
        return {};
    const live_esp_capsule::Vec3 lower{origin.x, origin.y, double(origin.z) + lo.z + 16.0};
    const live_esp_capsule::Vec3 upper{origin.x, origin.y, double(origin.z) + hi.z - 16.0};
    auto bounds = live_esp_capsule::Project(matrix.m, lower, upper, width, height);
    if (!bounds)
        return {};
    Box b{bounds->left, bounds->top, bounds->right - bounds->left, bounds->bottom - bounds->top};

    if (b.w > width * 4.f || b.h > height * 4.f)
        return {};
    return b;
}
struct LiveESPWeapon {
    std::uint32_t handle = 0;
    std::string designer;
    std::optional<int> icon, clip, maxClip, grenadeQuantity, weaponType;
    std::optional<bool> reloading, pinPulled;
    std::optional<std::uint16_t> gameplayState;
    std::optional<float> nextPrimaryTick;
};
struct LiveESPLine {
    std::array<float, 2> a{}, b{};
};
struct LiveESPPlayer {
    std::uint32_t handle = 0;
    int slot = 0, team = 0, health = 0, maxHealth = 0;
    Box box{};
    float distanceMeters = 0;
    std::uint64_t steamID = 0;
    std::shared_ptr<const ProfileImage> avatar;
    std::u32string name;
    std::array<std::optional<std::u32string>, 29> text{};
    std::optional<int> activeIcon;
    std::optional<LiveESPWeapon> activeWeapon;
    std::vector<LiveESPWeapon> inventory;
    std::vector<LiveESPLine> skeleton;
    std::vector<rage_aim::ESPBoxRecord> aimbotBoxes;
    bool inventoryComplete = false, hasBomb = false, hasTaser = false;
    std::optional<int> pingMs;
    std::optional<float> velocityModifier, slowedColorValue, simulationTime, readiness;
    bool hasDefuser = false;
};
struct LiveESPStats {
    const char* stage = "not sampled";
    unsigned controllers = 0, pawns = 0, alive = 0, positions = 0, collisions = 0, projected = 0,
             published = 0;
    unsigned invalidState = 0, positionRejected = 0, collisionRejected = 0, projectionRejected = 0,
             snapshotChanged = 0;
    std::string Summary() const {
        return std::string(stage) + "; controllers=" + std::to_string(controllers) +
               ", pawns=" + std::to_string(pawns) + ", alive=" + std::to_string(alive) +
               ", positions=" + std::to_string(positions) + ", collision=" + std::to_string(collisions) +
               ", projected=" + std::to_string(projected) + ", published=" + std::to_string(published) +
               "; rejected(state/position/collision/projection/changed)=" + std::to_string(invalidState) +
               "/" + std::to_string(positionRejected) + "/" + std::to_string(collisionRejected) + "/" +
               std::to_string(projectionRejected) + "/" + std::to_string(snapshotChanged);
    }
};
struct LiveESPFrame {
    std::vector<LiveESPPlayer> players;
    bool valid = false;
    LiveESPStats stats{};
};
struct LiveESPOffsets {
    std::uint32_t localFlag = 0, pawnHandle = 0, health = 0, maxHealth = 0, team = 0, life = 0, scene = 0,
                  origin = 0, collision = 0, mins = 0, maxs = 0, name = 0;
    bool nativeLayoutVerified = false;
    std::optional<std::uint32_t> steamID, spawnTimeIndex, inlineCollision, simulationTime;
    std::optional<std::uint32_t> velocity, movementFlags, takesDamage, actualMoveType, hasHelmet,
        flashBuildUp, flashOverlayAlpha, weaponType, gameplayState;
    std::optional<std::uint32_t> movementServices, lastMovementImpulses, jumpGravityScale, jumpDuckAmount;
    std::optional<std::uint32_t> ping, velocityModifier, hostageServices, carriedHostage, inventory, clip,
        reloading, pinPulled, reserveAmmo;
    std::optional<std::uint32_t> subclass, maxClip, modelState, modelHandle, hitboxSet, tickBase,
        nextPrimaryTick, nextPrimaryRatio;
    std::optional<std::uint32_t> bulletDamage, bulletPenetration, bulletRange, bulletRangeModifier,
        bulletHeadMultiplier, bulletArmorRatio, heavyArmor;
    std::optional<std::uint32_t> dormant, armor, scoped, immune, defusing, flashDuration, itemServices,
        hasDefuser, moneyServices, money, weaponServices, activeWeapon, identity, designerName;
    std::optional<std::uint32_t> viewOffsetZ, bulletServices;
    std::optional<std::uint32_t> desiredFov;
    std::optional<std::uint32_t> itemDefinition;
    std::optional<std::uint32_t> zoomLevel, viewPunch, cameraFov, ownerHandle, aimPunchServices;
    std::optional<std::uint32_t> spottedPawn, spottedHostage, spottedC4, spottedPlanted, spottedFlag,
        spottedMask;
    std::optional<std::uint32_t> observerPawn, controllerPawn, observerServices, observerTarget, observerMode,
        moveType;
};

struct LiveESPNeeds {
    bool enabled = true, name = true, skeleton = true, inventory = true, activeWeapon = true,
         vulnerable = true;
};
inline std::array<LiveESPNeeds, 2> LiveESPNeedsFromSettings(const Settings& cfg) {
    std::array<LiveESPNeeds, 2> result{};
    for (std::size_t t = 0; t < 2; ++t) {
        const auto& on = cfg.players.espEnabled[t];
        auto& n = result[t];
        n.enabled = cfg.players.value[std::size_t(t ? 19 : 0)] != 0;
        n.name = on[1];
        n.skeleton = on[5];
        n.vulnerable = on[13];
        n.inventory = on[14] || on[22] || on[24] || on[26];
        n.activeWeapon =
            on[4] || on[10] || on[14] || on[17] || on[21] || on[22] || on[23] || on[24] || on[26];
    }
    return result;
}
template <class Reader>
bool LiveESPString(Reader&& read, std::uintptr_t at, std::string& result, std::size_t maximum = 128) {
    result.clear();
    if (!at)
        return false;
    for (std::size_t i = 0; i < maximum; ++i) {
        char c = 0;
        if (!read(at + i, c))
            return false;
        if (!c)
            return true;
        result.push_back(c);
    }
    return false;
}
template <class Reader>
std::optional<LiveESPVec> LiveESPPosition(Reader&& read, std::uintptr_t pawn, const LiveESPOffsets& o) {
    std::uintptr_t node = 0;
    if (!read(pawn + o.scene, node) || !node)
        return {};
    LiveESPVec p;
    if (!read(node + o.origin, p) || !LiveESPFinite(p))
        return {};
    if (o.dormant) {
        std::uint8_t dormant = 0;
        if (!read(node + *o.dormant, dormant) || dormant != 0)
            return {};
    }
    return p;
}
inline int LiveESPKnownIcon(const std::string& name) {
    if (name == "item_defuser")
        return 2;
    return name.rfind("weapon_", 0) == 0 ? LiveEquipmentIconIndex(name.substr(7)) : -1;
}
template <class Reader>
std::optional<LiveESPWeapon> LiveESPReadWeapon(Reader&& read, std::uintptr_t global, std::uint32_t handle,
                                               const LiveESPOffsets& o) {
    if (!o.identity || !o.designerName)
        return {};
    auto entity = WatermarkPawn(read, global, handle);
    if (!entity)
        return {};
    std::uintptr_t identity = 0, text = 0;
    if (!read(*entity + *o.identity, identity) || !identity || !read(identity + *o.designerName, text))
        return {};
    LiveESPWeapon w;
    w.handle = handle;
    if (!LiveESPString(read, text, w.designer, 64) || w.designer.rfind("weapon_", 0) != 0)
        return {};
    int icon = LiveESPKnownIcon(w.designer);
    if (icon >= 0)
        w.icon = icon;
    if (o.clip) {
        int clip = 0;
        if (read(*entity + *o.clip, clip) && clip >= 0 && clip <= 1000)
            w.clip = clip;
    }
    std::uintptr_t sampledData = 0;
    if (o.nativeLayoutVerified && o.subclass && read(*entity + *o.subclass + 8, sampledData) && sampledData) {
        int value = 0;
        if (o.maxClip && read(sampledData + *o.maxClip, value) && value > 0 && value <= 1000 &&
            (!w.clip || *w.clip <= value))
            w.maxClip = value;
        if (o.weaponType && read(sampledData + *o.weaponType, value) && value >= 0 && value <= 32)
            w.weaponType = value;
    }
    auto boolean = [&](const std::optional<std::uint32_t>& field, std::optional<bool>& value) {
        if (field) {
            std::uint8_t v = 0;
            if (read(*entity + *field, v) && v <= 1)
                value = v == 1;
        }
    };
    boolean(o.reloading, w.reloading);
    if (o.nativeLayoutVerified && o.gameplayState) {
        std::uint16_t value = 0;
        if (read(*entity + *o.gameplayState, value))
            w.gameplayState = value;
    }
    if (w.icon && LiveEquipmentIsGrenade(*w.icon)) {
        boolean(o.pinPulled, w.pinPulled);
        if (o.reserveAmmo) {
            int amount = 0;
            if (read(*entity + *o.reserveAmmo, amount) && amount >= 0 && amount <= 16)
                w.grenadeQuantity = amount;
        }
    }
    if (o.nextPrimaryTick && o.nextPrimaryRatio) {
        int tick = 0;
        float fraction = 0;
        if (read(*entity + *o.nextPrimaryTick, tick) && tick >= 0 && tick < 100000000 &&
            read(*entity + *o.nextPrimaryRatio, fraction) && std::isfinite(fraction) && fraction >= 0 &&
            fraction < 1)
            w.nextPrimaryTick = float(tick) + fraction;
    }
    std::uintptr_t again = 0;
    if (WatermarkPawn(read, global, handle) != entity || !read(*entity + *o.identity, again) ||
        again != identity)
        return {};
    if (sampledData && o.subclass) {
        std::uintptr_t data = 0;
        if (!read(*entity + *o.subclass + 8, data) || data != sampledData) {
            w.maxClip.reset();
            w.weaponType.reset();
        }
    }
    return w;
}

template <class Reader>
std::optional<bool> LiveESPReadVulnerable(Reader&& read, std::uintptr_t global, std::uintptr_t pawn,
                                          const LiveESPOffsets& o, double distanceUnits) {
    if (!o.weaponServices || !std::isfinite(distanceUnits) || distanceUnits < 0)
        return {};
    if (o.nativeLayoutVerified && o.identity) {
        std::uintptr_t identity = 0;
        std::uint32_t flags = 0;
        if (!read(pawn + *o.identity, identity) || !identity || !read(identity + 0x30, flags) ||
            (flags & 0x80))
            return {};
    }
    std::uintptr_t service = 0;
    if (!read(pawn + *o.weaponServices, service))
        return {};
    if (!service) {
        std::uintptr_t again = 0;
        if (!read(pawn + *o.weaponServices, again) || again != service)
            return {};
        return true;
    }
    if (!o.activeWeapon)
        return {};
    std::uint32_t handle = 0;
    if (!read(service + *o.activeWeapon, handle))
        return {};
    auto weapon = WatermarkPawn(read, global, handle);
    if (!weapon) {
        std::uintptr_t again = 0;
        std::uint32_t againHandle = 0;
        if (!read(pawn + *o.weaponServices, again) || again != service ||
            !read(service + *o.activeWeapon, againHandle) || againHandle != handle ||
            WatermarkPawn(read, global, handle))
            return {};
        return true;
    }
    std::optional<bool> result;
    std::optional<std::uintptr_t> sampledData;
    auto boolean = [&](std::uintptr_t entity,
                       const std::optional<std::uint32_t>& field) -> std::optional<bool> {
        std::uint8_t value = 0;
        if (!field || !read(entity + *field, value))
            return {};
        return value != 0;
    };
    const auto defusing = boolean(pawn, o.defusing), reloading = boolean(*weapon, o.reloading);
    if (defusing.value_or(false) || reloading.value_or(false))
        result = true;
    else if (!defusing || !reloading)
        return {};
    else if (!o.nativeLayoutVerified || !o.subclass || !o.weaponType)
        return {};
    else {
        std::uintptr_t data = 0;
        int type = 0;
        if (!read(*weapon + *o.subclass + 8, data))
            return {};
        sampledData = data;
        if (!data)
            result = false;
        else if (!read(data + *o.weaponType, type))
            return {};
        else
            result = (type == 0 || type == 8) && distanceUnits > 350.;
    }
    std::uintptr_t againService = 0;
    std::uint32_t againHandle = 0;
    if (!read(pawn + *o.weaponServices, againService) || againService != service ||
        !read(service + *o.activeWeapon, againHandle) || againHandle != handle ||
        WatermarkPawn(read, global, handle) != weapon)
        return {};
    if (sampledData) {
        std::uintptr_t again = 0;
        if (!read(*weapon + *o.subclass + 8, again) || again != *sampledData)
            return {};
    }
    return result;
}

template <class Reader>
bool LiveESPReadInventory(Reader&& read, std::uintptr_t global, std::uintptr_t service,
                          const LiveESPOffsets& o, std::vector<LiveESPWeapon>& result) {
    result.clear();
    if (!o.inventory || !o.nativeLayoutVerified)
        return false;
    const auto at = service + *o.inventory;
    std::uint32_t count = 0;
    std::uintptr_t data = 0;
    if (!read(at, count) || count > 64 || !read(at + 8, data) || (count && !data))
        return false;
    std::array<std::uint32_t, 64> handles{};
    for (std::uint32_t i = 0; i < count; ++i) {
        if (!read(data + std::uintptr_t(i) * 4, handles[i]))
            return false;
        if (handles[i] == 0xffffffffu || handles[i] == 0)
            continue;
        if (std::find(handles.begin(), handles.begin() + i, handles[i]) != handles.begin() + i)
            return false;
        auto w = LiveESPReadWeapon(read, global, handles[i], o);
        if (!w)
            return false;
        result.push_back(std::move(*w));
    }
    std::uint32_t againCount = 0;
    std::uintptr_t againData = 0;
    if (!read(at, againCount) || againCount != count || !read(at + 8, againData) || againData != data)
        return false;
    for (std::uint32_t i = 0; i < count; ++i) {
        std::uint32_t handle = 0;
        if (!read(data + std::uintptr_t(i) * 4, handle) || handle != handles[i])
            return false;
    }
    return true;
}

template <class Reader>
std::vector<LiveESPLine> LiveESPReadSkeleton(Reader&& read, std::uintptr_t pawn, const LiveESPOffsets& o,
                                             LiveESPVec origin, const LiveESPMatrix& matrix, int width,
                                             int height) {
    std::vector<LiveESPLine> result;
    if (!o.nativeLayoutVerified || !o.modelState || !o.modelHandle)
        return result;
    std::uintptr_t node = 0, bones = 0, handle = 0, model = 0, parents = 0, flags = 0;
    if (!read(pawn + o.scene, node) || !node)
        return result;
    const auto state = node + *o.modelState;
    if (!read(state + 0x80, bones) || !bones || !read(state + *o.modelHandle, handle) || !handle ||
        !read(handle, model) || !model)
        return result;
    int count = 0;
    if (!read(model + 0x178, count) || count < 1 || count > 256 || !read(model + 0x180, parents) ||
        !parents || !read(model + 0x1b0, flags) || !flags)
        return result;
    std::array<LiveESPVec, 256> positions{};
    std::array<std::int16_t, 256> parent{};
    std::array<std::uint32_t, 256> usage{};
    for (int i = 0; i < count; ++i) {
        auto n = std::uintptr_t(i);
        if (!read(bones + n * 32, positions[std::size_t(i)]) || !LiveESPFinite(positions[std::size_t(i)]) ||
            !read(parents + n * 2, parent[std::size_t(i)]) || !read(flags + n * 4, usage[std::size_t(i)]))
            return {};
        if (parent[std::size_t(i)] < -1 || parent[std::size_t(i)] >= count || parent[std::size_t(i)] == i)
            return {};
        auto p = positions[std::size_t(i)];
        if (std::abs(p.x - origin.x) > 512 || std::abs(p.y - origin.y) > 512 ||
            std::abs(p.z - origin.z) > 512)
            return {};
    }
    for (int i = 0; i < count; ++i) {
        int cursor = i;
        for (int hops = 0; cursor >= 0; ++hops) {
            if (hops >= count)
                return {};
            cursor = parent[std::size_t(cursor)];
        }
    }
    for (int i = 0; i < count; ++i) {
        int j = parent[std::size_t(i)];
        if (j < 0 || !(usage[std::size_t(i)] & 0x100))
            continue;
        auto a = LiveESPProject(matrix, positions[std::size_t(i)], width, height, false),
             b = LiveESPProject(matrix, positions[std::size_t(j)], width, height, false);
        if (a && b)
            result.push_back({*a, *b});
    }
    std::uintptr_t again = 0;
    if (!read(state + 0x80, again) || again != bones || !read(handle, again) || again != model)
        return {};
    return result;
}

struct LiveESPReadinessTracker {
    struct State {
        std::uint32_t pawn = 0, weapon = 0;
        float next = 0, span = 0, lastTick = 0;
        bool known = false, seen = false;
    };
    std::array<State, 65> state{};
    void Reset() {
        state = {};
    }
    void Apply(LiveESPFrame& frame, std::optional<float> tick) {
        for (auto& p : frame.players)
            p.readiness.reset();
        if (!frame.valid || !tick || !std::isfinite(*tick) || *tick < 0) {
            Reset();
            return;
        }
        std::array<bool, 65> present{};
        for (auto& p : frame.players) {
            if (p.slot < 1 || p.slot > 64)
                continue;
            auto& st = state[std::size_t(p.slot)];
            present[std::size_t(p.slot)] = true;
            if (!p.activeWeapon || !p.activeWeapon->nextPrimaryTick) {
                st = {};
                continue;
            }
            const auto& w = *p.activeWeapon;
            float next = *w.nextPrimaryTick;
            bool same = st.seen && st.pawn == p.handle && st.weapon == w.handle && *tick >= st.lastTick &&
                        *tick - st.lastTick < 256;
            if (!same)
                st = {p.handle, w.handle, next, 0, *tick, false, true};
            if (same && next != st.next) {
                st.span = next - *tick;
                st.known = st.span > 0 && st.span < 4096;
                st.next = next;
            }
            if (next <= *tick)
                p.readiness = 1.f;
            else if (st.known)
                p.readiness = std::clamp(1.f - (next - *tick) / st.span, 0.f, 1.f);

            if (w.reloading.value_or(false))
                p.readiness.reset();
            st.lastTick = *tick;
        }
        for (std::size_t i = 1; i < state.size(); ++i)
            if (!present[i])
                state[i] = {};
    }
};
template <class Reader>
LiveESPFrame LiveESPCollect(Reader&& read, std::uintptr_t global, std::uintptr_t localGlobal,
                            const LiveESPOffsets& o, const LiveESPMatrix& matrix, int width, int height,
                            std::optional<float> gameTime = {},
                            const std::array<LiveESPNeeds, 2>* needs = nullptr) {
    LiveESPFrame frame;
    frame.stats.stage = "local controller unavailable";
    auto local = WatermarkKdLocalController(read, global, localGlobal, o.localFlag);
    if (!local.ok || !local.value)
        return frame;
    frame.stats.stage = "local pawn unavailable";
    std::uint32_t localHandle = 0;
    if (!read(local.value + o.pawnHandle, localHandle))
        return frame;
    auto localPawn = WatermarkPawn(read, global, localHandle);
    if (!localPawn)
        return frame;
    frame.stats.stage = "local team/origin unavailable";
    std::uint8_t localTeam = 0;
    if (!read(*localPawn + o.team, localTeam) || (localTeam != 2 && localTeam != 3))
        return frame;
    auto localPos = LiveESPPosition(read, *localPawn, o);
    if (!localPos)
        return frame;
    frame.stats.stage = "entity root/page unavailable";
    std::uintptr_t root = 0, page = 0;
    if (!read(global, root) || !root || !read(root + 0x10, page) || !page)
        return frame;
    frame.stats.stage = "collected";
    for (int slot = 1; slot <= 64; ++slot) {
        std::uintptr_t controller = 0;
        std::uint32_t handle = 0;
        if (!read(page + std::uintptr_t(slot) * 0x70, controller) || !controller ||
            controller == local.value || !read(controller + o.pawnHandle, handle))
            continue;
        ++frame.stats.controllers;
        auto pawn = WatermarkPawn(read, global, handle);
        if (!pawn || *pawn == *localPawn)
            continue;
        ++frame.stats.pawns;
        std::uint8_t life = 255, team = 0;
        int health = 0, maximum = 0;
        if (!read(*pawn + o.life, life) || life != 0 || !read(*pawn + o.health, health) || health <= 0 ||
            health > 10000 || !read(*pawn + o.maxHealth, maximum) || maximum <= 0 || maximum > 10000 ||
            !read(*pawn + o.team, team) || (team != 2 && team != 3)) {
            ++frame.stats.invalidState;
            continue;
        }
        ++frame.stats.alive;
        const LiveESPNeeds want = needs ? (*needs)[std::size_t(team == localTeam ? 1 : 0)] : LiveESPNeeds{};
        if (!want.enabled)
            continue;
        std::uintptr_t sampledNode = 0;
        if (!read(*pawn + o.scene, sampledNode) || !sampledNode) {
            ++frame.stats.positionRejected;
            continue;
        }
        auto origin = LiveESPPosition(read, *pawn, o);
        std::uintptr_t nodeAfterOrigin = 0;
        if (!origin || !read(*pawn + o.scene, nodeAfterOrigin) || nodeAfterOrigin != sampledNode) {
            ++frame.stats.positionRejected;
            continue;
        }
        ++frame.stats.positions;
        std::uintptr_t collision = 0;
        LiveESPVec lo, hi;
        if (!read(*pawn + o.collision, collision) || !collision || !read(collision + o.mins, lo) ||
            !read(collision + o.maxs, hi)) {
            ++frame.stats.collisionRejected;
            continue;
        }
        ++frame.stats.collisions;
        auto box = LiveESPBounds(matrix, *origin, lo, hi, width, height);
        if (!box) {
            ++frame.stats.projectionRejected;
            continue;
        }
        ++frame.stats.projected;
        LiveESPPlayer p;
        p.slot = slot;
        p.handle = handle;
        p.team = team == localTeam ? 1 : 0;
        p.health = health;
        p.maxHealth = maximum;
        p.box = *box;
        double dx = double(origin->x) - localPos->x, dy = double(origin->y) - localPos->y,
               dz = double(origin->z) - localPos->z;
        const double distanceUnits = std::sqrt(dx * dx + dy * dy + dz * dz);
        p.distanceMeters = float(distanceUnits * .02539999969303608);
        if (want.name) {
            std::string name;
            if (LiveESPString(read, controller + o.name, name))
                p.name = DecodeUTF8(name);
        }
        if (o.steamID) {
            std::uint64_t id = 0;
            if (read(controller + *o.steamID, id))
                p.steamID = id;
        }
        auto flag = [&](const std::optional<std::uint32_t>& field, int item, const char32_t* text) {
            if (field) {
                std::uint8_t value = 0;
                if (read(*pawn + *field, value) && value == 1)
                    p.text[std::size_t(item)] = text;
            }
        };
        if (o.ping) {
            std::uint32_t ms = 0;
            if (read(controller + *o.ping, ms) && ms <= 60000) {
                p.pingMs = int(ms);
                if (ms)
                    p.text[20] = DecodeUTF8(std::to_string(ms) + " Ms");
            }
        }
        if (o.simulationTime) {
            float value = 0;
            if (read(*pawn + *o.simulationTime, value) && std::isfinite(value) && value >= 0)
                p.simulationTime = value;
        }
        if (o.velocityModifier) {
            float modifier = 0;
            if (read(*pawn + *o.velocityModifier, modifier) && std::isfinite(modifier) && modifier >= 0 &&
                modifier <= 1) {
                p.velocityModifier = modifier;
                p.slowedColorValue = LiveESPSlowedValue(modifier, p.simulationTime, gameTime);
                if (modifier < 1.f)
                    p.text[12] = U"Slow";
            }
        }
        if (o.hostageServices && o.carriedHostage) {
            std::uintptr_t service = 0;
            std::uint32_t hostage = 0;
            if (read(*pawn + *o.hostageServices, service) && service &&
                read(service + *o.carriedHostage, hostage) && hostage && hostage != 0xffffffffu &&
                WatermarkPawn(read, global, hostage))
                p.text[15] = U"Vip";
        }
        if (want.skeleton)
            p.skeleton = LiveESPReadSkeleton(read, *pawn, o, *origin, matrix, width, height);
        flag(o.scoped, 9, U"Zoom");
        flag(o.defusing, 16, U"Defuse");
        std::optional<std::uint8_t> takesDamage, immunity, moveType;
        auto byte = [&](const std::optional<std::uint32_t>& field, std::optional<std::uint8_t>& value) {
            std::uint8_t v = 0;
            if (field && read(*pawn + *field, v))
                value = v;
        };
        byte(o.takesDamage, takesDamage);
        byte(o.immune, immunity);
        byte(o.actualMoveType, moveType);
        p.text[11] = LiveESPImmunityLabel(takesDamage, immunity, moveType);
        std::uintptr_t itemService = 0;
        if (o.itemServices)
            read(*pawn + *o.itemServices, itemService);
        if (o.armor) {
            int armor = 0;
            if (read(*pawn + *o.armor, armor) && armor >= 0 && armor <= 1000) {
                if (!armor)
                    p.text[6] = U"NA";
                else if (itemService && o.hasHelmet) {
                    std::uint8_t helmet = 0;
                    if (read(itemService + *o.hasHelmet, helmet) && helmet == 0)
                        p.text[6] = U"NH";
                }
            }
        }

        bool blind = false;
        if (o.nativeLayoutVerified && o.flashBuildUp) {
            float value = 0;
            if (read(*pawn + *o.flashBuildUp, value) && value != 0.f)
                blind = true;
        }
        if (!blind && o.flashOverlayAlpha) {
            float value = 0;
            if (read(*pawn + *o.flashOverlayAlpha, value) && value > .5f)
                blind = true;
        }
        if (blind)
            p.text[8] = U"Blind";
        if (itemService && o.hasDefuser) {
            std::uint8_t has = 0;
            if (read(itemService + *o.hasDefuser, has) && has == 1) {
                p.hasDefuser = true;
                p.text[7] = U"Kit";
            }
        }
        if (want.vulnerable && LiveESPReadVulnerable(read, global, *pawn, o, distanceUnits).value_or(false))
            p.text[13] = U"Vuln";
        if (o.moneyServices && o.money) {
            std::uintptr_t service = 0;
            int money = 0;
            if (read(controller + *o.moneyServices, service) && service && read(service + *o.money, money) &&
                money >= 0 && money <= 1000000)
                p.text[18] = DecodeUTF8("$" + std::to_string(money));
        }
        std::uintptr_t sampledService = 0;
        std::optional<std::uint32_t> sampledActive;
        const bool weaponGroups = want.activeWeapon || want.inventory;
        if (weaponGroups && o.weaponServices && read(*pawn + *o.weaponServices, sampledService) &&
            sampledService) {
            if (want.activeWeapon && o.activeWeapon) {
                std::uint32_t h = 0;
                if (read(sampledService + *o.activeWeapon, h)) {
                    sampledActive = h;
                    p.activeWeapon = LiveESPReadWeapon(read, global, h, o);
                }
            }
            if (want.inventory) {
                p.inventoryComplete = LiveESPReadInventory(read, global, sampledService, o, p.inventory);
                if (!p.inventoryComplete)
                    p.inventory.clear();
            }
        }
        if (p.activeWeapon) {
            const auto& w = *p.activeWeapon;
            p.text[21] = LiveESPWeaponLabel(w.designer);
            p.activeIcon = w.icon;
            if (w.reloading.value_or(false))
                p.text[10] = U"Reload";
            if (w.pinPulled.value_or(false))
                p.text[17] = U"Pin";
        }
        auto equipment = [&](const LiveESPWeapon& w) {
            if (w.designer == "weapon_c4")
                p.hasBomb = true;
            if (w.designer == "weapon_taser")
                p.hasTaser = true;
        };
        for (const auto& w : p.inventory)
            equipment(w);
        if (p.activeWeapon)
            equipment(*p.activeWeapon);
        if (p.hasBomb)
            p.text[14] = U"C4";
        if (sampledService && o.weaponServices) {
            std::uintptr_t service = 0;
            std::uint32_t active = 0;
            bool stable = read(*pawn + *o.weaponServices, service) && service == sampledService;
            if (stable && sampledActive)
                stable =
                    o.activeWeapon && read(service + *o.activeWeapon, active) && active == *sampledActive;
            if (!stable) {
                p.activeWeapon.reset();
                p.activeIcon.reset();
                p.inventory.clear();
                p.inventoryComplete = p.hasBomb = p.hasTaser = false;
                for (int item : {10, 13, 14, 17, 21})
                    p.text[std::size_t(item)].reset();
            }
        }

        std::uintptr_t current = 0;
        std::uint32_t currentHandle = 0;
        std::uint8_t currentLife = 255, currentTeam = 0;
        int currentHealth = 0;
        std::uintptr_t currentNode = 0;
        std::uint8_t currentDormant = 0;
        if (!read(page + std::uintptr_t(slot) * 0x70, current) || current != controller ||
            !read(controller + o.pawnHandle, currentHandle) || currentHandle != handle ||
            WatermarkPawn(read, global, handle) != pawn || !read(*pawn + o.life, currentLife) ||
            currentLife != 0 || !read(*pawn + o.health, currentHealth) || currentHealth <= 0 ||
            currentHealth > 10000 || !read(*pawn + o.team, currentTeam) || currentTeam != team ||
            !read(*pawn + o.scene, currentNode) || currentNode != sampledNode ||
            (o.dormant && (!read(currentNode + *o.dormant, currentDormant) || currentDormant != 0))) {
            ++frame.stats.snapshotChanged;
            continue;
        }
        if (o.steamID && p.steamID) {
            std::uint64_t id = 0;
            if (!read(controller + *o.steamID, id) || id != p.steamID)
                p.steamID = 0;
        }
        p.health = currentHealth;
        frame.players.push_back(std::move(p));
        ++frame.stats.published;
    }
    std::uintptr_t current = 0;
    std::uint32_t currentHandle = 0;
    if (!read(global, current) || current != root || !read(root + 0x10, current) || current != page ||
        !read(local.value + o.pawnHandle, currentHandle) || currentHandle != localHandle ||
        WatermarkPawn(read, global, localHandle) != localPawn) {
        frame.players.clear();
        frame.stats.stage = "frame identity changed";
        return frame;
    }
    auto currentLocal = WatermarkKdLocalController(read, global, localGlobal, o.localFlag);
    if (!currentLocal.ok || currentLocal.value != local.value) {
        frame.players.clear();
        frame.stats.stage = "frame identity changed";
        return frame;
    }
    frame.valid = true;
    return frame;
}
}
