#pragma once
namespace menu {

inline constexpr char DTBulletSvg[] = R"svg(<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px"
	 height="32px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
<g id="Layer_2">
	<g>
		<path d="M5.19,25.654l5.41,4.32l9.767-12.998c0.204-0.302,0.488-1.203,0.488-1.203s0.132-0.676,0.526-1.37
			c0.394-0.696,1.184-1.691,1.184-1.691l-3.683-3.099c0,0-1.576,1.549-1.784,1.747c-0.713,0.676-1.483,1.014-1.784,1.371
			S5.19,25.654,5.19,25.654z"/>
		<polygon points="19.429,8.881 23.167,11.923 28.068,2.927 26.753,1.837 		"/>
		<path d="M4.533,26.369l5.503,4.375l-0.47,0.547c0,0-1.999,0.035-3.737-1.316c-1.86-1.445-1.728-3.082-1.728-3.082L4.533,26.369z"
			/>
	</g>
	<g>
		<path fill="#FFFFFF" d="M5.023,24.527l5.41,4.32L20.2,15.851c0.204-0.302,0.488-1.203,0.488-1.203s0.132-0.676,0.526-1.37
			c0.394-0.696,1.184-1.691,1.184-1.691l-3.683-3.099c0,0-1.576,1.549-1.784,1.747c-0.713,0.676-1.483,1.014-1.784,1.371
			S5.023,24.527,5.023,24.527z"/>
		<polygon fill="#FFFFFF" points="19.262,7.755 23,10.798 27.901,1.801 26.586,0.711 		"/>
		<path fill="#FFFFFF" d="M4.366,25.242l5.503,4.377l-0.47,0.547c0,0-1.999,0.033-3.737-1.318c-1.86-1.445-1.728-3.08-1.728-3.08
			L4.366,25.242z"/>
	</g>
</g>
</svg>
)svg";
}
