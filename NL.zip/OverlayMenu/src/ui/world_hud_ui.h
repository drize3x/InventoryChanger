#pragma once
#include "presets_ui.h"
#include "hud_color_picker.h"
#include "world_tooltip.h"
#include <iomanip>
#include <sstream>
namespace menu {

struct WorldHudHit {
    Box box{};
    int kind = 0, index = -1, option = -1, layer = 0;
    Box control{};
    int Key() const {
        return kind * 10000 + (index + 2) * 32 + option + 1;
    }
};
struct WorldHudUI {
    enum {
        Surface = 0,
        Toggle = 1,
        Slider = 2,
        Select = 3,
        Option = 4,
        Opener = 5,
        Gear = 6,
        Swatch = 7,
        Mode = 8,
        ColorEnabled = 9,
        Alpha = 10,
        ScopeColor = 11
    };
    PresetsUI paint;
    LanguageCatalog* languages = nullptr;
    std::vector<WorldHudHit> hits;
    std::array<Box, 36> rows{}, sliders{};
    std::array<Box, 6> mainRows{}, controls{};
    std::map<int, PresetMotion> fill, ink, marker;
    std::array<PresetMotion, 36> checks, availability, sliderTip;
    PresetLayer tooltipLast{};
    bool tooltipStored = false;
    PresetMotion groupFade, tooltipFade, equipmentMarker;
    PopupPaintTransition popupFade, choiceTransition, colorTransition;
    float hoverSeconds = 0;
    int page = -1, choice = -1, color = -1, held = -1, focus = -1, drag = -1, editing = -1, hover = -1;
    bool visible = false, blocked = false, selectAll = false, releaseGuard = false, directPosition = false;
    float scale = 1, F = 18, mouseX = -1, mouseY = -1, scroll = 0, maxScroll = 0;
    int viewportW = 1600, viewportH = 1100;
    std::string numeric;
    Box card{}, popup{}, body{}, anchor{}, choiceAnchor{}, alphaBox{}, directAnchor{};
    bool searchDetached = false;
    Layout layout{};
    HudColorPicker picker, parentPicker;
    bool suspendedPicker = false;
    Box pickerArea{};
    HudColorPicker& InlinePicker() {
        return suspendedPicker ? parentPicker : picker;
    }
    void CloseColor() {
        color = -1;
        if (suspendedPicker) {
            picker = parentPicker;
            suspendedPicker = false;
        }
        picker.held = -1;
    }
    static constexpr std::array<const char*, 6> MainKeys{
        {"visuals_world_hud_radar", "visuals_world_hud_scopeoptions_scopeoverlay",
         "visuals_world_hud_inaccuracyoverlay", "visuals_world_hud_deathnotices",
         "visuals_world_hud_scoreboard", "visuals_world_hud_crosshairs"}};
    std::u32string Label(const std::string& k) const {
        if (languages)
            return languages->Label(k);
        auto i = DefaultLanguageStrings().find(k);
        return DecodeUTF8(i == DefaultLanguageStrings().end() ? k : i->second);
    }
    static std::vector<std::string> Options(int i) {
        std::string k = WorldHudSpecs[std::size_t(i)].key;
        std::vector<std::string> suffix;
        switch (i) {
        case 0:
            suffix = {"revealenemies", "revealhostages", "revealbomb", "overrideplayerangles"};
            break;
        case 1:
            suffix = {"default", "lines", "none"};
            break;
        case 2:
            suffix = {"left", "right", "top", "bottom"};
            break;
        case 3:
            suffix = {"none", "tilted"};
            break;
        case 14:
            suffix = {"off", "kills", "killsandassists"};
            break;
        case 20:
            suffix = {"off", "enemyonly", "everyone"};
            break;
        default:
            break;
        }
        for (auto& s : suffix)
            s = k + "_" + s;
        return suffix;
    }
    static constexpr bool EquipmentFilter(int i) {
        return i >= 21 && i <= 29;
    }
    static bool EquipmentSelected(const Settings& cfg) {
        for (int i = 21; i <= 29; ++i)
            if (cfg.worldHud.value[std::size_t(i)] != 0)
                return true;
        return false;
    }
    bool Enabled(int i, const Settings& cfg) const {
        if (EquipmentFilter(i))
            return cfg.worldHud.value[20] != 0;
        if (i >= 2 && i <= 8)
            return cfg.worldHud.value[1] == 1 && cfg.worldHud.scopeColorMode == 1;
        int p = WorldHudSpecs[std::size_t(i)].parent;
        return p < 0 || cfg.worldHud.value[std::size_t(p)] != 0;
    }
    std::u32string Summary(int i, const Settings& cfg, bool abbreviate = false) const {
        auto opts = Options(i);
        if (WorldHudSpecs[std::size_t(i)].kind == WorldKind::Choice)
            return Label(opts.at(std::size_t(cfg.worldHud.value[std::size_t(i)])));
        std::u32string t;
        int mask = int(cfg.worldHud.value[std::size_t(i)]);
        for (std::size_t n = 0; n < opts.size(); ++n)
            if (mask & (1 << n)) {
                if (!t.empty())
                    t += U", ";
                t += Label(opts[n]);
            }
        if (abbreviate && t.size() >= 15) {
            t.clear();
            for (std::size_t n = 0; n < opts.size(); ++n)
                if (mask & (1 << n)) {
                    auto l = Label(opts[n]);
                    if (!l.empty()) {
                        if (!t.empty())
                            t += U", ";
                        t += l.front();
                    }
                }
        }
        return t.empty() ? Label("menu_select") : t;
    }
    bool Active() const {
        return page >= 0 || choice >= 0 || color >= 0;
    }
    bool Capturing() const {
        return held >= 0 || drag >= 0 || releaseGuard || ((PickerActive()) && picker.held >= 0);
    }
    bool Editing() const {
        return editing >= 0 || ((PickerActive()) && picker.Editing());
    }
    void CancelInput() {
        held = drag = -1;
        picker.held = -1;
    }
    void Close(bool animate = true) {
        page = choice = color = editing = focus = -1;
        suspendedPicker = false;
        numeric.clear();
        scroll = 0;
        CancelInput();
        picker.Reset(0);
        if (animate) {
            popupFade.Tick(0, 0);
            choiceTransition.Tick(0, 0);
            colorTransition.Tick(0, 0);
        } else {
            popupFade.Clear();
            choiceTransition.Clear();
            colorTransition.Clear();
        }
    }
    void Open(int p) {
        popupFade.Clear();
        choiceTransition.Clear();
        colorTransition.Clear();
        suspendedPicker = false;
        if (p == 0)
            picker.Reset(0, true);
        if (p == 1)
            picker.Reset(4);
        page = p;
        choice = color = editing = -1;
        scroll = 0;
        anchor = {mouseX >= 0 ? mouseX + 1 : card.x + card.w + 8 * scale, mouseY >= 0 ? mouseY + 1 : card.y,
                  0, 0};
        popupFade.Snap(0);
        CancelInput();
    }
    int Hit(float x, float y) const {
        if (!visible || blocked)
            return -1;
        for (int i = int(hits.size()) - 1; i >= 0; --i)
            if (hits[std::size_t(i)].box.Contains(x, y))
                return i;
        return -1;
    }
    std::string TipKey(const Settings&) const {
        if (color >= 0 || choice >= 0 || Editing() || drag >= 0 || picker.held >= 0)
            return {};
        int h = Hit(mouseX, mouseY);
        if (h < 0)
            return {};
        const auto& t = hits[std::size_t(h)];
        if (t.kind != Toggle && t.kind != Slider && t.kind != Select)
            return {};
        int i = t.index;
        if (i == 9 || i == 30)
            return std::string(WorldHudSpecs[std::size_t(i)].key) + "_tooltip";
        return {};
    }
    void Tick(float dt, const Settings& cfg) {
        dt = std::max(0.f, dt);
        groupFade.Tick(visible ? 1.f : 0.f, dt);
        if (!visible || blocked)
            return;
        popupFade.Tick(Active() ? 1.f : 0.f, dt);
        choiceTransition.Tick(choice >= 0 ? 1.f : 0.f, dt);
        colorTransition.Tick(color >= 0 ? 1.f : 0.f, dt);
        if (PickerActive())
            picker.Tick(dt);
        if (suspendedPicker)
            parentPicker.Tick(dt, false);
        hoverSeconds += dt;
        tooltipFade.Tick(!TipKey(cfg).empty() && hoverSeconds >= .3f ? 1.f : 0.f, dt);
        int h = Hit(mouseX, mouseY), key = h >= 0 ? hits[std::size_t(h)].Key() : -1;
        for (const auto& t : hits) {
            int k = t.Key();
            bool on = t.kind == Opener && t.index == page;
            on = on || (t.kind == Gear && t.index == page) || (t.kind == Select && t.index == choice) ||
                 (t.kind == Swatch && (t.index == color || (t.index == 4 && page == 1))) ||
                 (t.kind == ScopeColor && page == 0);
            bool usable = t.index < 0 || t.index >= 36 || t.kind == Opener || t.kind == Gear ||
                          t.kind == Swatch || t.kind == ScopeColor || Enabled(t.index, cfg);
            float target = usable ? (on || k == held ? 1.f : key == k ? .5f : 0.f) : 0;
            fill[k].Tick(target, dt);
            bool selected = t.kind == Toggle && t.index >= 0 && cfg.worldHud.value[std::size_t(t.index)] != 0;
            ink[k].Tick(selected ? 1.f : target, dt);
        }
        equipmentMarker.Tick(EquipmentSelected(cfg) ? 1.f : 0.f, dt);
        for (std::size_t i = 0; i < 36; ++i) {
            checks[i].Tick(cfg.worldHud.value[i] != 0 ? 1.f : 0.f, dt);
            availability[i].Tick(Enabled(int(i), cfg) ? 1.f : .5f, dt);
            sliderTip[i].Tick(page >= 0 && color < 0 && choice < 0 && editing < 0 && Enabled(int(i), cfg) &&
                                      (drag == int(i) || sliders[i].Contains(mouseX, mouseY))
                                  ? 1.f
                                  : 0.f,
                              dt);
            if (WorldHudSpecs[i].kind == WorldKind::Multi)
                marker[int(i)].Tick(cfg.worldHud.value[i] != 0 ? 1.f : 0.f, dt);
        }
    }
    void OpenColor(int i, Box b, const Settings& cfg) {
        if (color < 0 && (page == 0 || page == 1)) {
            parentPicker = picker;
            suspendedPicker = true;
        }
        color = i;
        choice = editing = -1;
        picker.Reset(i, false, i >= 5);
        picker.Sync(cfg);
        pickerArea = PresetPopupFit({b.x + b.w + 7 * scale, b.y, 265 * scale, picker.Height(scale)},
                                    viewportW, viewportH);
        CancelInput();
    }
    void DragSlider(int i, float x, Settings& cfg) {
        if (i < 0 || i >= 36 || !Enabled(i, cfg))
            return;
        auto b = sliders[std::size_t(i)];
        const auto& d = WorldHudSpecs[std::size_t(i)];
        cfg.worldHud.Set(std::size_t(i), d.minimum + std::clamp((x - b.x) / std::max(1.f, b.w), 0.f, 1.f) *
                                                         (d.maximum - d.minimum));
    }
    void Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        int h = Hit(x, y);
        int key = h >= 0 ? hits[std::size_t(h)].Key() : -1;
        if (key != hover) {
            hover = key;
            hoverSeconds = 0;
        }
        if (x == -1 && y == -1) {
            picker.mouseX = picker.mouseY = -1;
            return;
        }
        if (drag >= 0 && drag < 36)
            DragSlider(drag, x, cfg);
        if (PickerActive())
            picker.Move(x, y, cfg);
    }
    void BeginEdit(int i, const Settings& cfg) {
        if (!Enabled(i, cfg))
            return;
        editing = i;
        numeric = std::to_string(int(cfg.worldHud.value[std::size_t(i)]));
        selectAll = true;
    }
    bool Commit(Settings& cfg) {
        if (editing < 0)
            return true;
        try {
            std::size_t n = 0;
            float v = std::stof(numeric, &n);
            if (n != numeric.size() || !std::isfinite(v))
                return false;
            if (Enabled(editing, cfg))
                cfg.worldHud.Set(std::size_t(editing), v);
            editing = -1;
            numeric.clear();
            return true;
        } catch (...) {
            return false;
        }
    }
    void Activate(const WorldHudHit& h, Settings& cfg) {
        switch (h.kind) {
        case Toggle:
            if (Enabled(h.index, cfg))
                cfg.worldHud.Set(std::size_t(h.index),
                                 cfg.worldHud.value[std::size_t(h.index)] == 0 ? 1.f : 0.f);
            break;
        case Select:
            if (Enabled(h.index, cfg)) {
                choice = choice == h.index ? -1 : h.index;
                choiceAnchor = h.control;
                directPosition = false;
            }
            break;
        case Option: {
            if (!Enabled(h.index, cfg))
                break;
            bool multi = WorldHudSpecs[std::size_t(h.index)].kind == WorldKind::Multi;
            cfg.worldHud.Set(std::size_t(h.index),
                             multi ? float(int(cfg.worldHud.value[std::size_t(h.index)]) ^ (1 << h.option))
                                   : float(h.option));
            if (!multi)
                choice = -1;
            break;
        }
        case Opener:
        case Gear:
            if (page == h.index)
                Close();
            else
                Open(h.index);
            break;
        case ScopeColor:
            Open(0);
            break;
        case Swatch:
            if (h.index == 4 && page < 0)
                Open(1);
            else
                OpenColor(h.index, h.box, cfg);
            break;
        case Mode:
            cfg.worldHud.scopeColorMode = h.option;
            break;
        case ColorEnabled:
            cfg.worldHud.penetrationColorEnabled[std::size_t(h.index)] =
                !cfg.worldHud.penetrationColorEnabled[std::size_t(h.index)];
            break;
        default:
            break;
        }
    }
    bool inlinePickerVisible = false;
    bool PickerActive() const {
        return color >= 0 || page == 1 || (page == 0 && inlinePickerVisible);
    }
    bool Context(float x, float y, Settings& cfg) {
        if (!visible || blocked)
            return false;
        int h = Hit(x, y);
        if (h < 0)
            return Active();
        auto t = hits[std::size_t(h)];
        if (t.index == 1 && t.kind == Select)
            Open(0);
        else if (t.index == 9 && t.kind == Toggle)
            Open(1);
        else if (t.index == 35 && t.kind == Toggle)
            OpenColor(5, t.box, cfg);
        else
            return Active();
        mouseX = x;
        mouseY = y;
        (void)cfg;
        return true;
    }
    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl = false) {
        if (!visible || blocked) {
            CancelInput();
            return false;
        }
        mouseX = x;
        mouseY = y;
        if (!down && releaseGuard) {
            releaseGuard = false;
            CancelInput();
            return true;
        }
        if (PickerActive()) {
            if (picker.Click(x, y, down, cfg))
                return true;
            if (color >= 0) {
                if (down) {
                    CloseColor();
                    releaseGuard = true;
                    CancelInput();
                }
                return true;
            }
        }
        int n = Hit(x, y);
        if (n >= 0 && EquipmentFilter(hits[std::size_t(n)].index) &&
            !Enabled(hits[std::size_t(n)].index, cfg)) {
            CancelInput();
            return true;
        }
        if (down) {
            if (n < 0) {
                if (Active()) {
                    Close();
                    releaseGuard = true;
                    return true;
                }
                return false;
            }
            auto h = hits[std::size_t(n)];
            if (editing >= 0 && !Commit(cfg))
                return true;
            if (h.kind == Surface) {
                if (choice >= 0)
                    choice = -1;
                else if (!popup.Contains(x, y))
                    Close();
                releaseGuard = true;
                return true;
            }
            held = h.Key();
            focus = held;
            if (h.kind == Slider && Enabled(h.index, cfg)) {
                if (ctrl)
                    BeginEdit(h.index, cfg);
                else {
                    drag = h.index;
                    DragSlider(h.index, x, cfg);
                }
            }
            return true;
        }
        bool consumed = held >= 0 || drag >= 0;
        if (n >= 0 && held == hits[std::size_t(n)].Key() && drag < 0 && editing < 0)
            Activate(hits[std::size_t(n)], cfg);
        CancelInput();
        return consumed;
    }
    bool Key(int k, Settings& cfg, bool shift = false, bool ctrl = false) {
        if (!visible || blocked)
            return false;
        if ((PickerActive()) && picker.Key(k, cfg, ctrl))
            return true;
        if (color >= 0) {
            if (k == 27)
                CloseColor();
            return true;
        }
        if (editing >= 0) {
            if (k == 27) {
                editing = -1;
                numeric.clear();
            } else if (k == 13)
                Commit(cfg);
            else if (ctrl && k == 'A')
                selectAll = true;
            else if (k == 8 || k == 46) {
                if (selectAll)
                    numeric.clear();
                else if (!numeric.empty())
                    numeric.pop_back();
                selectAll = false;
            }
            return true;
        }
        if (k == 27 && Active()) {
            if (choice >= 0)
                choice = -1;
            else
                Close();
            return true;
        }
        if (k == 9) {
            std::vector<int> keys;
            for (const auto& h : hits)
                if (h.kind != Surface && (page < 0 || h.layer > 0) &&
                    (!EquipmentFilter(h.index) || Enabled(h.index, cfg)))
                    keys.push_back(h.Key());
            if (keys.empty())
                return false;
            auto i = std::find(keys.begin(), keys.end(), focus);
            int n = i == keys.end()
                        ? (shift ? int(keys.size()) - 1 : 0)
                        : (int(i - keys.begin()) + (shift ? -1 : 1) + int(keys.size())) % int(keys.size());
            focus = keys[std::size_t(n)];
            return true;
        }
        for (const auto& h : hits)
            if (h.Key() == focus) {
                if (h.kind == Slider && (k == 37 || k == 39)) {
                    if (Enabled(h.index, cfg))
                        cfg.worldHud.Set(std::size_t(h.index), cfg.worldHud.value[std::size_t(h.index)] +
                                                                   (k == 37 ? -1 : 1) * (shift ? 10 : 1));
                    return true;
                }
                if (k == 13 || k == 32) {
                    if (h.kind == Slider)
                        BeginEdit(h.index, cfg);
                    else
                        Activate(h, cfg);
                    return true;
                }
            }
        return Active();
    }
    bool Character(char16_t c) {
        if ((PickerActive()) && picker.Character(c))
            return true;
        if (editing < 0)
            return false;
        if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.') {
            if (selectAll) {
                numeric.clear();
                selectAll = false;
            }
            if (numeric.size() < 20)
                numeric += char(c);
        }
        return true;
    }
    bool Wheel(float n, Settings& cfg) {
        if (!visible || blocked || !Active())
            return false;
        if (color >= 0)
            return true;
        if (choice < 0)
            for (std::size_t i = 0; i < 36; ++i)
                if (sliders[i].w > 0 && sliders[i].Contains(mouseX, mouseY) &&
                    body.Contains(mouseX, mouseY) && Enabled(int(i), cfg)) {
                    cfg.worldHud.Set(i, cfg.worldHud.value[i] + n);
                    return true;
                }
        scroll = std::clamp(scroll - n * 30 * scale, 0.f, maxScroll);
        return true;
    }
    void Measure(Fonts& fonts, const Settings& cfg, const Layout& l, Box viewCard, Box headerLine, int width,
                 int height, bool shown, bool modalBlocked) {
        inlinePickerVisible = cfg.worldHud.value[1] == 1;
        picker.languages = parentPicker.languages = languages;
        picker.SetMetrics(fonts, cfg.scale);
        parentPicker.SetMetrics(fonts, cfg.scale);
        visible = shown;
        blocked = modalBlocked;
        layout = l;
        viewportW = width;
        viewportH = height;
        scale = cfg.scale;
        F = fonts.PixelHeight(0, 13 * scale);
        paint.layers.clear();
        hits.clear();
        rows.fill({});
        sliders.fill({});
        if (!visible) {
            Close(false);
            tooltipStored = false;
            tooltipFade.Snap(0);
            return;
        }
        if (blocked) {
            Close(false);
            hoverSeconds = 0;
            hover = -1;
            tooltipFade.Snap(0);
            tooltipStored = false;
            for (auto& e : fill)
                e.second.Snap(0);
        }
        if (editing >= 0 && !Enabled(editing, cfg))
            editing = -1;
        if (choice >= 0 && !Enabled(choice, cfg))
            choice = -1;
        if (drag >= 0 && drag < 36 && !Enabled(drag, cfg))
            CancelInput();
        const float s = scale, H = F + 6 * s, R = F + 14 * s;
        auto pal = CurrentPalette(cfg);
        auto alpha = [](Color c, float a) {
            c.a *= a;
            return c;
        };
        auto layer = [&](Box b, bool pop = false, float radius = 0) {
            paint.layers.push_back({b, radius, pop, {}});
            return int(paint.layers.size()) - 1;
        };
        Box localClip{};
        auto rect = [&](int z, Box b, Color c, float radius = 0, float stroke = 0, unsigned corners = 15) {
            if (b.w <= 0 || b.h <= 0)
                return;
            PresetDraw d{b, c, radius, stroke, corners, {}, false};
            d.clipped = true;
            d.clip = paint.layers[std::size_t(z)].box;
            if (localClip.w > 0)
                d.clip = PresetIntersect(d.clip, localClip);
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto text = [&](int z, Box b, std::u32string t, Color c, int font = 0, float px = 13) {
            if (b.w <= 0 || b.h <= 0)
                return;
            PresetDraw d{b, c, 0, 0, 15, std::move(t), font == 3};
            d.font = font;
            d.textSize = px;
            d.clipped = true;
            d.clip = paint.layers[std::size_t(z)].box;
            if (localClip.w > 0)
                d.clip = PresetIntersect(d.clip, localClip);
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
        };
        auto tw = [&](const std::u32string& t, int font = 0) {
            return std::trunc(fonts.NativeTextSize(font, 13 * s, t).w + .95f);
        };
        auto hit = [&](int z, Box b, int kind, int i = -1, int opt = -1, Box control = Box{}) {
            if (blocked)
                return;
            b = PresetIntersect(b, paint.layers[std::size_t(z)].box);
            if (localClip.w > 0)
                b = PresetIntersect(b, localClip);
            if (b.w > 0 && b.h > 0)
                hits.push_back({b, kind, i, opt, z, control});
        };
        auto surface = [&](Box b) {
            int z = layer(b, true, 15 * s);
            rect(z, b, pal[8], 15 * s);
            rect(z, b, pal[11], 15 * s, s);
            return z;
        };
        auto shape = [&](int z, Box b) {
            rect(z, b, pal[40], 15 * s);
            rect(z, b, pal[11], 15 * s, s);
        };
        auto motion = [&](int kind, int i, int opt = -1) {
            int k = kind * 10000 + (i + 2) * 32 + opt + 1;
            auto it = fill.find(k);
            return it == fill.end() ? 0.f : it->second.value;
        };
        auto chev = [&](int z, float right, float y, Color c, char32_t cp = 0xf105) {
            auto t = std::u32string(1, cp);
            float w = tw(t, 3);
            text(z, {right - w, y, w, F}, t, c, 3);
        };
        auto toggle = [&](int z, Box row, int i, float right, float a) {
            float nominal = F + 2 * s, cy = row.y + row.h * .5f, frac = cy - std::trunc(cy);
            Box b{right - 32 * s, cy - nominal * .5f + frac, 32 * s, nominal - 2 * frac};
            float t = checks[std::size_t(i)].initialized ? checks[std::size_t(i)].value
                                                         : cfg.worldHud.value[std::size_t(i)];
            rect(z, b, alpha(pal[22], a), nominal * .5f);
            rect(z, b, alpha(pal[23], a * t), nominal * .5f);
            float r = nominal * .5f - 2 * s, cx = b.x + nominal * .5f + (b.w - nominal) * t;
            rect(z, {cx - r, cy - r, 2 * r, 2 * r}, alpha(Mix(pal[20], pal[21], t), a), r);
            return b;
        };
        auto swatch = [&](int z, float right, float y, int i, float a = 1.f) {
            Box b{right - 16 * s, y + (R - 16 * s) * .5f, 16 * s, 16 * s};
            float v = motion(Swatch, i);
            bool scopePreview = i == 0 || i == 1 || i == 2;
            if (scopePreview)
                v = std::max(v, motion(ScopeColor, i));
            Color hi = pal[33];
            hi.a *= .4f * v * a;
            float pad = scopePreview ? std::max(0.f, (H - b.h) * .5f) : 3 * s;
            rect(z, {b.x - pad, b.y - pad, b.w + 2 * pad, b.h + 2 * pad}, hi, 6 * s);
            bool gradient = (i == 1 && cfg.worldHud.scopeColorMode != 0) || i == 5;
            int last = gradient ? (i == 1 ? 2 : 7) : i;
            auto firstColor = cfg.worldHud.colors[std::size_t(i)],
                 lastColor = cfg.worldHud.colors[std::size_t(last)];
            auto image = std::make_shared<Canvas>(int(std::ceil(b.w)), int(std::ceil(b.h)));
            DrawPickerPreview(*image, {0, 0, b.w, b.h}, s, H, firstColor, lastColor, gradient, scopePreview);
            PresetDraw d{b, {1, 1, 1, a}, 0, 0, 15, {}, false};
            d.raster = image;
            d.rasterStamp = PickerPreviewStamp(firstColor, lastColor, gradient, scopePreview);
            d.clipped = true;
            d.clip = paint.layers[std::size_t(z)].box;
            if (localClip.w > 0)
                d.clip = PresetIntersect(d.clip, localClip);
            paint.layers[std::size_t(z)].draw.push_back(std::move(d));
            hit(z, b, Swatch, i);
            return b;
        };

        const float headerF = fonts.PixelHeight(0, 10 * s), top = headerLine.y + headerLine.h + 15 * s;

        float x = viewCard.x + viewCard.w + 7 * s, y = top + headerF + 5 * s,
              w = std::min(300 * s, l.content.w - 30 * s);
        if (x + w > l.content.x + l.content.w - 5 * s) {
            x = viewCard.x;
            y = viewCard.y + viewCard.h + headerF + 20 * s;
        }
        card = {x, y, w, 14 * s + 6 * H + 5 * 15 * s};
        int z = layer({card.x, card.y - headerF - 5 * s, card.w, card.h + headerF + 5 * s});
        text(z, {card.x + 14 * s, card.y - headerF - 5 * s, card.w - 28 * s, headerF},
             Label("group_visuals_world_hud"), pal[3], 0, 10);
        shape(z, card);
        y = card.y + 7 * s;
        for (int n = 0; n < 6; ++n) {
            Box row{card.x + 14 * s, y, card.w - 28 * s, H};
            mainRows[std::size_t(n)] = row;
            if (n) {
                rect(z, {row.x, y - 8 * s, row.w, s}, pal[34]);
                paint.layers[std::size_t(z)].draw.back().pixelLine = true;
            }
            int i = n == 0   ? 0
                    : n == 1 ? 1
                    : n == 2 ? 9
                             : -1,
                kind = n < 2    ? Select
                       : n == 2 ? Toggle
                                : Opener,
                idx = i >= 0 ? i : n - 1;
            float v = motion(kind, idx);
            Box band{row.x - 13 * s, row.y - 6 * s, row.w + 26 * s, row.h + 12 * s};
            rect(z, band, alpha(pal[33], .15f * v), 15 * s, 0, n == 0 ? 3u : n == 5 ? 12u : 0u);
            float right = row.x + row.w, labelRight = right;
            if (n < 2) {
                float cw = std::min(std::trunc(row.w / 2.2f) + 12 * s, row.w * .5f);
                Box b{right - cw, row.y, cw, H};
                controls[std::size_t(n)] = b;
                rect(z, b, Mix(pal[12], pal[13], v), 6 * s);
                rect(z, b, pal[11], 6 * s, s);
                auto summary = Summary(i, cfg);
                float aw = tw(U"\uf107", 3);
                text(z, {b.x + 6 * s, b.y + 3 * s, std::max(0.f, b.w - aw - 18 * s), F}, summary,
                     Mix(pal[14], pal[2], v));
                chev(z, right - 6 * s, b.y + 3 * s, Mix(pal[14], pal[2], v), 0xf107);
                labelRight = b.x - 6 * s;
                hit(z, band, Select, i, -1, b);

                if (n == 1 && cfg.worldHud.value[1] == 1) {
                    auto b2 =
                        swatch(z, labelRight, row.y + (H - R) * .5f, cfg.worldHud.scopeColorMode ? 1 : 0);
                    if (!hits.empty() && !blocked)
                        hits.back().kind = ScopeColor;
                    labelRight = b2.x - 3 * s;
                }
            } else if (n == 2) {
                auto b = toggle(z, row, 9, right, 1);
                labelRight = b.x - 6 * s;
                hit(z, band, Toggle, 9, -1, b);
                auto cb = swatch(z, labelRight, row.y + (H - R) * .5f, 4);
                labelRight = cb.x - 6 * s;
            } else {
                chev(z, right - 6 * s, row.y + 3 * s, Mix(pal[14], pal[2], v));
                labelRight = right - 20 * s;
                hit(z, band, Opener, n - 1);
            }
            text(z, {row.x, row.y + 3 * s, std::max(0.f, labelRight - row.x), F},
                 Label(MainKeys[std::size_t(n)]),
                 Mix(pal[0], pal[2],
                     n == 2 ? (checks[9].initialized ? checks[9].value : cfg.worldHud.value[9])
                     : (n < 2 && choice == i) || (n >= 3 && page == n - 1) ? 1.f
                                                                           : 0.f));
            y += H + 15 * s;
        }
        for (auto& d : paint.layers[0].draw)
            d.color.a *= groupFade.value;
        if (page >= 0) {
            struct Block {
                int section;
                std::vector<int> fields;
            };
            std::vector<Block> blocks;
            for (int i = 0; i < 36; ++i)
                if (WorldHudSpecs[std::size_t(i)].page == page) {
                    int sec = WorldHudSpecs[std::size_t(i)].section;
                    if (blocks.empty() || blocks.back().section != sec)
                        blocks.push_back({sec, {}});
                    blocks.back().fields.push_back(i);
                }
            float total = 0;
            for (const auto& b : blocks)
                total +=
                    14 * s + R * float(b.fields.size()) + 7 * s + (page == 0 && b.section > 0 ? 8 * s : 0);
            bool inlinePicker = page == 0 || page == 1;
            bool showInlinePicker = page == 1 || (page == 0 && cfg.worldHud.value[1] == 1);
            float extra = showInlinePicker ? InlinePicker().Height(s) + 7 * s : 0;
            total += extra;
            float titleH = inlinePicker ? 0 : F + 21 * s, pw = 265 * s;
            float desired = titleH + total;
            popup = PresetPopupFit(
                {anchor.x, anchor.y, pw, std::min(desired, std::max(1.f, float(height) - 12 * s))}, width,
                height);
            body = {popup.x + 7 * s, popup.y + titleH, popup.w - 14 * s, popup.h - titleH - 7 * s};
            maxScroll = std::max(0.f, total - 7 * s - body.h);
            scroll = std::clamp(scroll, 0.f, maxScroll);
            if (!blocked)
                hits.push_back({{0, 0, float(width), float(height)}, Surface});
            int pz = surface(popup);
            hit(pz, popup, Surface);
            std::string title = page == 0   ? MainKeys[1]
                                : page == 1 ? MainKeys[2]
                                : page == 2 ? MainKeys[3]
                                : page == 3 ? MainKeys[4]
                                : page == 4 ? MainKeys[5]
                                : page == 5 ? WorldHudSpecs[20].key
                                            : WorldHudSpecs[35].key;
            if (!inlinePicker)
                text(pz, {popup.x + 14 * s, popup.y + 7 * s, popup.w - 28 * s, F}, Label(title), pal[2], 2);
            int bz = layer(inlinePicker ? Box{popup.x, body.y, popup.w, body.h} : body);
            y = body.y - scroll;
            if (showInlinePicker) {
                auto& ip = InlinePicker();
                ip.Draw(paint, bz, fonts, cfg, {popup.x, body.y - scroll, 265 * s, ip.Height(s)});
                y += ip.Height(s) + 7 * s;
            }
            for (const auto& block : blocks) {
                if (page == 0 && block.section > 0) {
                    rect(bz, {popup.x + 10 * s, y, popup.w - 20 * s, s}, pal[34]);
                    paint.layers[std::size_t(bz)].draw.back().pixelLine = true;
                    y += 8 * s;
                }
                Box cb{body.x, y, body.w, 14 * s + R * float(block.fields.size())};
                if (!inlinePicker)
                    shape(bz, cb);
                float cy = cb.y + 7 * s;
                for (int i : block.fields) {
                    const auto& d = WorldHudSpecs[std::size_t(i)];
                    Box row{cb.x + 7 * s, cy, cb.w - 14 * s, R};
                    rows[std::size_t(i)] = PresetIntersect(row, body);
                    localClip = row;
                    bool enabled = Enabled(i, cfg);
                    float a = availability[std::size_t(i)].initialized ? availability[std::size_t(i)].value
                              : enabled                                ? 1.f
                                                                       : .5f;
                    int kind = d.kind == WorldKind::Check     ? Toggle
                               : d.kind == WorldKind::Integer ? Slider
                                                              : Select;
                    float v = enabled ? motion(kind, i) : 0;
                    rect(bz, row, alpha(pal[33], .4f * v * a), 15 * s / 1.6f);
                    float left = row.x + 12 * s, right = row.x + row.w - 12 * s, labelRight = right;
                    float textMotion = kind == Toggle ? std::max(v, checks[std::size_t(i)].initialized
                                                                        ? checks[std::size_t(i)].value
                                                                        : cfg.worldHud.value[std::size_t(i)])
                                                      : v;
                    Color col = alpha(Mix(pal[14], pal[2], textMotion),
                                      a * (enabled || EquipmentFilter(i) ? 1.f : .5f));
                    Box control{};
                    static constexpr std::array<char32_t, 36> icons{
                        {0, 0,      0xe318, 0xf2f9, 0xe0a3, 0xf047, 0xe4ba, 0xe105, 0xe1c0,
                         0, 0xf106, 0xe59f, 0xe665, 0xf042, 0,      0,      0,      0,
                         0, 0,      0,      0,      0,      0,      0,      0,      0,
                         0, 0,      0,      0,      0,      0,      0,      0,      0}};

                    bool switchCheck = !EquipmentFilter(i);
                    char32_t cp = icons[std::size_t(i)];
                    if (cp) {
                        float iw = tw(std::u32string(1, cp), 3);
                        text(bz, {left + (20 * s - iw) * .5f, row.y + 7 * s, 20 * s, F},
                             std::u32string(1, cp), col, 3);
                        left += 32 * s;
                    }

                    if (kind == Toggle) {
                        if (switchCheck) {
                            control = toggle(bz, row, i, right, a);
                            labelRight = control.x - 6 * s;
                        } else {
                            float amount = equipmentMarker.initialized ? equipmentMarker.value
                                           : EquipmentSelected(cfg)    ? 1.f
                                                                       : 0.f;
                            bool checked = cfg.worldHud.value[std::size_t(i)] != 0;
                            float iw = tw(U"\uf00c", 3);
                            control = {left, row.y + 7 * s, iw, F};
                            if (checked && amount > 0)
                                text(bz, control, U"\uf00c", alpha(pal[0], a * amount), 3);
                            left += (iw + 12 * s) * amount;
                        }
                        hit(bz, row, Toggle, i, -1, control);
                        if (i == 8 || i == 35) {
                            auto b = swatch(bz, labelRight, row.y, i == 8 ? 3 : 5, a);
                            labelRight = b.x - 6 * s;
                        }
                    } else if (kind == Slider) {
                        float sw = std::trunc(row.w / 2.5f);
                        control = {right - sw, row.y + (R - 6 * s) * .5f, sw, 6 * s};
                        sliders[std::size_t(i)] = control;
                        float t = (cfg.worldHud.value[std::size_t(i)] - d.minimum) / (d.maximum - d.minimum);
                        rect(bz, control, alpha(pal[24], a), 3 * s);
                        if (t > 0)
                            rect(bz, {control.x, control.y, control.w * t, control.h}, alpha(pal[25], a),
                                 3 * s);
                        labelRight = control.x - 6 * s;
                        hit(bz, {control.x, row.y, control.w, row.h}, Slider, i, -1, control);
                        if (editing == i) {
                            rect(bz, {control.x, row.y, control.w, R}, pal[12], 6 * s);
                            text(bz, {control.x + 6 * s, row.y + 7 * s, control.w - 12 * s, F},
                                 DecodeUTF8(numeric + "|"), pal[2]);
                        }
                    } else {
                        auto summary = Summary(i, cfg, true);
                        float aw = tw(U"\uf105", 3), vw = tw(summary);
                        control = {std::max(left, right - vw - aw - 3 * s), row.y,
                                   std::min(row.w - 24 * s, vw + aw + 3 * s), R};
                        text(bz, {control.x, row.y + 7 * s, control.w - aw - 3 * s, F}, summary,
                             alpha(pal[14], a));
                        chev(bz, right, row.y + 7 * s, alpha(pal[14], a));
                        labelRight = control.x;
                        hit(bz, row, Select, i, -1, control);
                    }
                    text(bz, {left, row.y + 7 * s, std::max(0.f, labelRight - left), F}, Label(d.key), col);
                    localClip = {};
                    cy += R;
                }
                y += cb.h + 7 * s;
            }
            if (maxScroll > 0) {
                float hh = std::max(10 * s, body.h * body.h / (body.h + maxScroll));
                rect(pz, {popup.x + popup.w - 5 * s, body.y + (body.h - hh) * scroll / maxScroll, 4 * s, hh},
                     pal[18], 4 * s);
            }
        } else {
            popup = {};
            body = {};
            maxScroll = 0;
        }
        auto choiceStart = paint.layers.size();
        if (choice >= 0) {
            auto options = Options(choice);
            bool multi = WorldHudSpecs[std::size_t(choice)].kind == WorldKind::Multi;
            float amount = marker[choice].initialized                     ? marker[choice].value
                           : cfg.worldHud.value[std::size_t(choice)] != 0 ? 1.f
                                                                          : 0.f;
            float markerW = multi ? (tw(U"\uf00c", 3) + 12 * s) * amount : 0;
            bool main = choice == 0 || choice == 1;
            float cw = main ? choiceAnchor.w : 140 * s;
            for (const auto& k : options)
                cw = std::max(cw, tw(Label(k)) + 38 * s + markerW);
            float ch = std::min(300 * s, float(options.size()) * R + 14 * s);
            Box b;
            if (main) {
                b = {choiceAnchor.x + (choiceAnchor.w - cw) * .5f,
                     choiceAnchor.y + (choiceAnchor.h - ch) * .5f, cw, ch};
                if (!directPosition) {
                    directAnchor = b;
                    directPosition = true;
                } else {
                    b.x = directAnchor.x;
                    b.y = directAnchor.y;
                }
            } else {
                Box row = searchDetached ? choiceAnchor : rows[std::size_t(choice)];
                b = {row.x + row.w + 7 * s, row.y + row.h * .5f - ch * .25f, cw, ch};
            }
            b.x = std::clamp(b.x, 0.f, std::max(0.f, float(width) - b.w - 10 * s));
            b.y = std::clamp(b.y, 0.f, std::max(0.f, float(height) - b.h - 10 * s));
            if (!blocked)
                hits.push_back({{0, 0, float(width), float(height)}, Surface});
            int dz = surface(b);
            hit(dz, b, Surface);
            y = b.y + 7 * s;
            for (std::size_t j = 0; j < options.size(); ++j) {
                Box row{b.x + 7 * s, y, b.w - 14 * s, R};
                bool selected = multi ? (int(cfg.worldHud.value[std::size_t(choice)]) & (1 << j)) != 0
                                      : int(cfg.worldHud.value[std::size_t(choice)]) == int(j);
                rect(dz, row, alpha(pal[33], .4f * motion(Option, choice, int(j))), 15 * s / 1.6f);
                float left = row.x + 12 * s;
                if (multi && selected)
                    text(dz, {left, row.y + 7 * s, markerW, F}, U"\uf00c", alpha(pal[0], amount), 3);
                text(dz, {left + markerW, row.y + 7 * s, row.w - 24 * s - markerW, F}, Label(options[j]),
                     selected ? pal[2] : Mix(pal[14], pal[2], motion(Option, choice, int(j))));
                hit(dz, row, Option, choice, int(j));
                y += R;
            }
        }
        if (choice >= 0)
            choiceTransition.FinishPaint(paint, choiceStart);
        else if (Active())
            choiceTransition.AppendClosing(paint);
        auto colorStart = paint.layers.size();
        if (color >= 0) {
            pickerArea =
                PresetPopupFit({pickerArea.x, pickerArea.y, 265 * s, picker.Height(s)}, width, height);
            int cz = surface(pickerArea);
            picker.Draw(paint, cz, fonts, cfg, pickerArea);
        }
        if (PickerActive())
            picker.DrawMenus(paint, fonts, cfg, width, height);
        if (color >= 0)
            colorTransition.FinishPaint(paint, colorStart);
        else if (Active())
            colorTransition.AppendClosing(paint);
        if (Active())
            popupFade.FinishPaint(paint, 1);
        else
            popupFade.AppendClosing(paint);
        if (page >= 0 && color < 0 && choice < 0 && editing < 0) {
            for (int i = 0; i < 36; ++i) {
                auto b = sliders[std::size_t(i)];
                if (b.w <= 0 || !Enabled(i, cfg) || sliderTip[std::size_t(i)].value <= .001f)
                    continue;
                auto t = ASCII(std::to_string(int(cfg.worldHud.value[std::size_t(i)])) + "%");
                float w2 = tw(t),
                      fraction =
                          (cfg.worldHud.value[std::size_t(i)] - WorldHudSpecs[std::size_t(i)].minimum) /
                          (WorldHudSpecs[std::size_t(i)].maximum - WorldHudSpecs[std::size_t(i)].minimum);
                Box tip = PresetPopupFit(
                    {b.x + b.w * fraction - w2 * .5f - 7 * s, b.y - F - 14 * s, w2 + 14 * s, F + 9 * s},
                    width, height);
                int tz = layer(tip, true, 8 * s);
                paint.layers[std::size_t(tz)].opacity = sliderTip[std::size_t(i)].value;
                rect(tz, tip, pal[8], 8 * s);
                rect(tz, tip, pal[11], 8 * s, s);
                text(tz, {tip.x + 7 * s, tip.y + 4 * s, w2, F}, t, pal[0]);
                for (auto& d : paint.layers[std::size_t(tz)].draw)
                    d.color.a *= sliderTip[std::size_t(i)].value;
            }
        }
        auto tipKey = TipKey(cfg);
        if (!tipKey.empty() && hoverSeconds >= .3f) {
            int n = Hit(mouseX, mouseY);
            if (n >= 0) {
                const auto& h = hits[std::size_t(n)];
                tooltipLast =
                    WorldDescriptionTooltip(fonts, cfg, h.box, Label(WorldHudSpecs[std::size_t(h.index)].key),
                                            Label(tipKey), width, height);
                tooltipStored = true;
            }
        }
        if (tooltipStored)
            AppendWorldTooltip(paint, tooltipLast, tooltipFade.value);
    }
};
}
