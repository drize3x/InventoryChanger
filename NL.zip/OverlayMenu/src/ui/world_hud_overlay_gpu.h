#pragma once

#include "renderer_dx11.h"
#include "world_hud_overlay.h"
namespace menu {
struct HudOverlayGPU {
    std::array<std::uint64_t, std::size_t(world_hud_overlay::Slots)> uploaded{};
    unsigned long long draws = 0, uploads = 0, skipped = 0;
    void Reset() {
        uploaded.fill(0);
    }
    void Draw(wm::RendererDX11& renderer, ID3D11RenderTargetView* target, int width, int height,
              const std::vector<HudSprite>& sprites) {
        std::array<bool, std::size_t(world_hud_overlay::Slots)> used{};
        for (const auto& s : sprites) {
            if (!s.image || s.slot < 0 || s.slot >= world_hud_overlay::Slots || used[std::size_t(s.slot)] ||
                width < 1 || height < 1)
                continue;
            const Canvas& image = *s.image;
            if (image.width < 1 || image.height < 1 ||
                image.rgba.size() != std::size_t(image.width) * std::size_t(image.height) * 4u)
                continue;
            const long long x0 = std::max<long long>(0, s.x), y0 = std::max<long long>(0, s.y),
                            x1 = std::min<long long>(width, (long long)s.x + image.width),
                            y1 = std::min<long long>(height, (long long)s.y + image.height);
            if (x1 <= x0 || y1 <= y0) {
                ++skipped;
                continue;
            }
            const auto slot = std::size_t(s.slot);
            const bool upload = uploaded[slot] != s.stamp;
            renderer.SetClip(float(x0), float(y0), float(x1 - x0), float(y1 - y0));
            renderer.DrawLayer(target, width, height, image.rgba.data(), image.width, image.height,
                               float(s.x), float(s.y), float(image.width), 0.f,
                               world_hud_overlay::FirstSlot + s.slot, upload);
            renderer.ClearClip();
            used[slot] = true;
            uploaded[slot] = s.stamp;
            ++draws;
            if (upload)
                ++uploads;
        }
        for (std::size_t i = 0; i < used.size(); ++i)
            if (!used[i])
                uploaded[i] = 0;
    }
};
}
