#pragma once
#include "presets_ui.h"
#include "presets_motion.h"
namespace menu {

struct PopupPaintTransition : PresetMotion {
    std::vector<PresetLayer> cached;
    int identity = -1;
    PopupPaintTransition() {
        Snap(0);
    }
    void Clear() {
        cached.clear();
        identity = -1;
        Snap(0);
    }
    void Open(int key) {
        if (identity != key) {
            Clear();
            identity = key;
        }
        Tick(1, 0);
    }
    static void Fade(PresetsUI& paint, std::size_t begin, float alpha) {
        for (std::size_t i = begin; i < paint.layers.size(); ++i) {
            auto& l = paint.layers[i];
            l.opacity *= alpha;
            for (auto& d : l.draw) {
                d.color.a *= alpha;
                d.shadowColor.a *= alpha;
            }
        }
    }
    void FinishPaint(PresetsUI& paint, std::size_t begin) {
        cached.assign(paint.layers.begin() + std::ptrdiff_t(begin), paint.layers.end());
        Fade(paint, begin, value);
    }
    void AppendClosing(PresetsUI& paint) {
        if (value <= .001f) {
            cached.clear();
            return;
        }
        auto begin = paint.layers.size();
        paint.layers.insert(paint.layers.end(), cached.begin(), cached.end());
        Fade(paint, begin, value);
    }
};
}
