#pragma once

#include "world_view_engine.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace menu {
namespace world_camera_layout {

inline constexpr std::uintptr_t CameraServicesPawn = 0x38;

inline constexpr std::uintptr_t SetupFov = 0x498, SetupViewmodelFov = 0x49c, SetupAspect = 0x4d4,
                                SetupFlags = 0x551, RenderViewSetup = 0x10;
inline constexpr std::uint8_t SetupAspectFlag = 2;

inline constexpr std::uintptr_t SwayBlock = 0x1350;
inline constexpr std::size_t SwayBlockBytes = 0x54;
}

namespace world_camera_scope {
inline constexpr std::uint32_t Camera = 1u, Viewmodel = 2u, Burst = 4u, RenderStart = 8u, SetupView = 16u;
}

inline bool CameraFinite(const float* v, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i)
        if (!std::isfinite(v[i]))
            return false;
    return true;
}

inline void CameraAngleVectors(const float* angles, float* forward, float* right, float* up) {
    constexpr float k = 3.14159265358979323846f / 180.f;
    const float sp = std::sin(angles[0] * k), cp = std::cos(angles[0] * k), sy = std::sin(angles[1] * k),
                cy = std::cos(angles[1] * k), sr = std::sin(angles[2] * k), cr = std::cos(angles[2] * k);
    if (forward) {
        forward[0] = cp * cy;
        forward[1] = cp * sy;
        forward[2] = -sp;
    }
    if (right) {
        right[0] = -sr * sp * cy + cr * sy;
        right[1] = -sr * sp * sy - cr * cy;
        right[2] = -sr * cp;
    }
    if (up) {
        up[0] = cr * sp * cy + sr * sy;
        up[1] = cr * sp * sy - sr * cy;
        up[2] = cr * cp;
    }
}

struct AspectPlan {
    bool apply = false;
    float aspect = 0, fov = 0, viewmodelFov = 0, native = 0;
};

inline float AspectConvertFov(float hfov, float native, float target) {
    constexpr float rad = 3.14159265358979323846f / 180.f;
    return std::clamp(2.f * std::atan(std::tan(hfov * .5f * rad) * (target / native)) / rad, 1.f, 175.f);
}

inline AspectPlan AspectCompute(const ViewConfig& c, float native, float fov, float viewmodelFov) {
    AspectPlan p;
    if (!c.aspect || !std::isfinite(c.aspectValue) || !std::isfinite(native) || native < .2f ||
        native > 10.f || !std::isfinite(fov) || fov < 1.f || fov > 175.f)
        return p;
    const float target = std::clamp(native * c.aspectValue * .01f, .2f, 8.f);
    float f = fov, vm = viewmodelFov;
    if (!c.aspectVertical) {
        f = AspectConvertFov(fov, native, target);
        if (std::isfinite(viewmodelFov) && viewmodelFov >= 1.f && viewmodelFov <= 175.f)
            vm = AspectConvertFov(viewmodelFov, native, target);
    }
    if (!std::isfinite(f) || !std::isfinite(target))
        return p;
    p.apply = true;
    p.aspect = target;
    p.fov = f;
    p.viewmodelFov = vm;
    p.native = native;
    return p;
}

struct ScopeFovInput {
    float game = 0, base = 0;
    std::uint32_t instantTarget = 0, zoomLevel = 0;
    bool scoped = false;
};
inline bool FovBaseKnown(float base) {
    return std::isfinite(base) && base >= 1.f && base <= 170.f;
}

inline float FovInstant(const ViewConfig& c, const ScopeFovInput& in) {
    float fov = in.game;
    if (!c.instantScope || !std::isfinite(fov))
        return fov;
    if (in.scoped && in.instantTarget >= 1 && in.instantTarget <= 170)
        fov = float(in.instantTarget);
    else if (!in.scoped && FovBaseKnown(in.base) && fov < in.base)
        fov = in.base;
    return fov;
}

inline float FovScopePercent(const ViewConfig& c, float fov, float base, std::uint32_t zoomLevel) {
    if (c.scopeFov && FovBaseKnown(base) && fov < base - .01f) {
        const float pct = std::clamp(zoomLevel >= 2 ? c.scopeX2 : c.scopeX1, 0.f, 100.f) * .01f;
        fov = base + (fov - base) * pct;
    }
    return fov;
}
inline float ScopeFovMap(const ViewConfig& c, const ScopeFovInput& in) {
    if (!std::isfinite(in.game) || in.game < 1.f || in.game > 179.f)
        return in.game;
    return std::clamp(FovScopePercent(c, FovInstant(c, in), in.base, in.zoomLevel), 1.f, 170.f);
}

inline float FovOverrideMap(float value, float desired, float x) {
    const float shift = value - desired;
    if (x >= desired)
        return x + shift;
    const float x0 = std::min(40.f, value);
    if (x <= x0)
        return x;
    if (desired - x0 < .01f)
        return x + shift;
    return x + shift * (x - x0) / (desired - x0);
}
struct FovInput {
    float game = 0, desired = 0;
    std::uint32_t instantTarget = 0, zoomLevel = 0;
    bool scoped = false;
};

struct FovResult {
    float fov = 0, overrideShift = 0;
    bool changed = false;
};

inline FovResult FovCompute(const ViewConfig& c, const FovInput& in) {
    FovResult r;
    r.fov = in.game;
    if (!std::isfinite(in.game) || in.game < 1.f || in.game > 179.f)
        return r;
    const bool known = FovBaseKnown(in.desired);
    ScopeFovInput s;
    s.game = in.game;
    s.base = known ? in.desired : 0.f;
    s.instantTarget = in.instantTarget;
    s.zoomLevel = in.zoomLevel;
    s.scoped = in.scoped;
    float fov = FovInstant(c, s), base = s.base;
    if (c.fov && known) {
        const float value = float(std::clamp<std::uint32_t>(c.fovValue, ViewFovMin, ViewFovMax));
        const float mapped = FovOverrideMap(value, in.desired, fov);
        if (std::isfinite(mapped)) {
            r.overrideShift = mapped - fov;
            fov = mapped;
            base = value;
        }
    }
    fov = std::clamp(FovScopePercent(c, fov, base, in.zoomLevel), 1.f, 170.f);
    if (!std::isfinite(fov))
        return FovResult{in.game, 0.f, false};
    r.fov = fov;
    r.changed = fov != in.game;
    return r;
}

inline std::uint32_t ScopeZoomLatch(std::uint32_t latched, std::uint32_t published, float game, float base) {
    if (!(std::isfinite(game) && std::isfinite(base)) || game >= base - .01f)
        return 0;
    return published ? published : latched;
}

inline constexpr float FovDefault = 90.f;
inline constexpr std::uint32_t FovRestFrames = 8;
struct FovRestState {
    float rest = 0, last = 0;
    std::uint32_t stable = 0;
};
inline FovRestState FovRestObserve(FovRestState s, float game, bool scoped, std::uint32_t zoomLevel) {
    if (!std::isfinite(game) || game < 1.f || game > 170.f || scoped || zoomLevel) {
        s.stable = 0;
        return s;
    }
    if (s.stable && std::fabs(game - s.last) <= .01f) {
        if (s.stable < FovRestFrames)
            ++s.stable;
    } else {
        s.stable = 1;
        s.last = game;
    }
    if (s.stable >= FovRestFrames)
        s.rest = s.last;
    return s;
}
enum class FovBaseSource : std::uint8_t { Desired = 0, Rest = 1, Default = 2, Game = 3 };
inline const char* FovBaseSourceName(FovBaseSource s) {
    switch (s) {
    case FovBaseSource::Desired:
        return "desired";
    case FovBaseSource::Rest:
        return "rest";
    case FovBaseSource::Default:
        return "default90";
    default:
        return "game";
    }
}
inline float FovBaseFor(std::uint32_t desired, float rest, float game, bool scoped, FovBaseSource& source) {
    if (desired >= 1 && desired <= 170) {
        source = FovBaseSource::Desired;
        return float(desired);
    }
    if (FovBaseKnown(rest)) {
        source = FovBaseSource::Rest;
        return rest;
    }
    if (scoped) {
        source = FovBaseSource::Default;
        return FovDefault;
    }
    source = FovBaseSource::Game;
    return game;
}

struct SwayState {
    float velocity[3]{}, amplitude = 0, bob[3]{}, lag[3]{}, air = 0, lower = 0, ladder = 0;
};
inline bool SwayDecode(const unsigned char* raw, SwayState& s) {
    if (!raw)
        return false;
    const auto f = [&](std::size_t at) {
        float v = 0;
        std::memcpy(&v, raw + at, 4);
        return v;
    };
    s.velocity[0] = f(4);
    s.velocity[1] = f(8);
    s.velocity[2] = f(12);
    s.amplitude = f(0x10);
    s.bob[0] = f(0x14);
    s.bob[1] = f(0x18);
    s.bob[2] = f(0x1c);
    s.lag[0] = f(0x38);
    s.lag[1] = f(0x3c);
    s.lag[2] = f(0x40);
    s.air = f(0x48);
    s.lower = f(0x4c);
    s.ladder = f(0x50);
    return CameraFinite(s.velocity, 3) && CameraFinite(s.bob, 3) && CameraFinite(s.lag, 3) &&
           std::isfinite(s.amplitude) && std::isfinite(s.air) && std::isfinite(s.lower) &&
           std::isfinite(s.ladder);
}

inline bool SwayAdjust(const ViewConfig& c, const SwayState& st, float pawnAbsZ, float* origin,
                       float* angles) {
    if (!origin || !angles || !CameraFinite(origin, 3) || !CameraFinite(angles, 3))
        return false;
    if (!c.ModifiersActive() && !c.viewmodelAngles)
        return false;
    float o[3] = {origin[0], origin[1], origin[2]}, a[3] = {angles[0], angles[1], angles[2]};
    if (c.ModifiersActive()) {
        constexpr float pi = 3.14159265358979323846f;
        const float kBob = c.bobbing * .01f, kVel = c.velocitySway * .01f, kRot = c.rotationSway * .01f,
                    kAir = c.inAir * .01f, kLow = c.lowerWeapon * .01f, kLad = c.ladderBob * .01f;
        float dz = 0, dPitch = 0, dYaw = 0, dRoll = 0;
        dz += .4f * st.air * (1.f - kAir);
        dPitch += .2f * st.air * (1.f - kAir);
        const float tv[3] = {-2.f * std::fabs(st.velocity[0]), .4f * st.velocity[1], 0.f};
        float d[3];
        for (int i = 0; i < 3; ++i)
            d[i] = (kBob - 1.f) * (st.bob[i] - tv[i]) + (kVel - 1.f) * tv[i];
        float f[3], r[3], u[3];
        CameraAngleVectors(a, f, r, u);
        for (int i = 0; i < 3; ++i)
            o[i] += d[0] * f[i] + d[1] * r[i] + d[2] * u[i];
        dRoll += .5f * d[2];
        dPitch -= .4f * d[2];
        dYaw -= .3f * d[1];
        const float lagged[3] = {a[0] - .075f * st.lag[0], a[1] - .075f * st.lag[1],
                                 a[2] - .075f * st.lag[2]};
        float fl[3];
        CameraAngleVectors(lagged, fl, nullptr, nullptr);
        for (int i = 0; i < 3; ++i)
            o[i] += (kRot - 1.f) * (fl[i] - f[i]);
        const float e = .5f * (1.f - std::cos(pi * st.lower));
        dz += (kLow - 1.f) * 2.f * e;
        dPitch += (kLow - 1.f) * 10.f * e;
        if (std::isfinite(pawnAbsZ))
            dz += (kLad - 1.f) * .25f * st.ladder * std::sin(.08f * pawnAbsZ);
        o[2] += dz;
        a[0] += dPitch;
        a[1] += dYaw;
        a[2] += dRoll;
    }
    if (c.viewmodelAngles && std::isfinite(c.pitch) && std::isfinite(c.yaw) && std::isfinite(c.roll)) {
        a[0] += c.pitch;
        a[1] += c.yaw;
        a[2] += c.roll;
    }
    a[0] = std::clamp(a[0], -89.999f, 89.999f);
    if (!CameraFinite(o, 3) || !CameraFinite(a, 3))
        return false;
    std::memcpy(origin, o, sizeof o);
    std::memcpy(angles, a, sizeof a);
    return true;
}

struct CameraFrame {
    std::uintptr_t pawn = 0;
    std::uint32_t pawnHandle = 0, desired = 0, zoomLevel = 0;
    bool scoped = false;
    std::uintptr_t weapon = 0;
    std::uint64_t at = 0;
};

struct CameraLayout {
    std::uint32_t viewPunch = 0, cameraFov = 0, ownerHandle = 0, scene = 0, absOrigin = 0,
                  aimPunchServices = 0;
};
class CameraSharedFrame {
    std::atomic<std::uintptr_t> pawn_{0}, weapon_{0};
    std::atomic<std::uint32_t> handle_{0}, desired_{0}, zoom_{0}, scoped_{0};
    std::atomic<std::uint64_t> at_{0};

public:
    void Store(const CameraFrame& f, std::uint64_t now) {
        handle_.store(f.pawnHandle, std::memory_order_relaxed);
        desired_.store(f.desired, std::memory_order_relaxed);
        zoom_.store(f.zoomLevel, std::memory_order_relaxed);
        scoped_.store(f.scoped ? 1u : 0u, std::memory_order_relaxed);
        weapon_.store(f.weapon, std::memory_order_relaxed);
        at_.store(now, std::memory_order_relaxed);
        pawn_.store(f.pawn, std::memory_order_release);
    }
    void Clear() {
        pawn_.store(0, std::memory_order_release);
    }

    bool Load(CameraFrame& out, std::uint64_t now, std::uint64_t maxAge = 500) const {
        const auto pawn = pawn_.load(std::memory_order_acquire);
        if (!pawn)
            return false;
        const auto at = at_.load(std::memory_order_relaxed);
        if (now < at || now - at > maxAge)
            return false;
        out.pawn = pawn;
        out.pawnHandle = handle_.load(std::memory_order_relaxed);
        out.desired = desired_.load(std::memory_order_relaxed);
        out.zoomLevel = zoom_.load(std::memory_order_relaxed);
        out.scoped = scoped_.load(std::memory_order_relaxed) != 0;
        out.weapon = weapon_.load(std::memory_order_relaxed);
        out.at = at;
        return true;
    }
};

namespace world_camera_hook {
inline constexpr unsigned CalcView = 0, Landing = 1, Projection = 2, AimPunch = 3, Sway = 4, HasBurst = 5,
                          HideViewmodel = 6, ViewmodelFov = 7, PostProcess = 8, SetupView = 9, Count = 10,
                          InaccuracyFn = 10, SpreadFn = 11, Signatures = 12;
}
inline constexpr std::uint32_t CameraAllHooks = (1u << world_camera_hook::Count) - 1u;

namespace world_camera_probe {
inline constexpr std::uintptr_t InaccuracySlot = 0xcf8, SpreadSlot = 0xbd0;
inline constexpr float MaxInaccuracy = 2.f, MaxSpread = 1.f, MaxPunchDegrees = 90.f;
inline constexpr std::uint64_t MaxAgeMs = 250;
}
struct ProbeRequest {
    bool inaccuracy = false, punch = false;
    bool Any() const {
        return inaccuracy || punch;
    }
    bool operator==(const ProbeRequest& o) const {
        return inaccuracy == o.inaccuracy && punch == o.punch;
    }
};
struct ProbeSample {
    bool valid = false, hasPunch = false;
    float inaccuracy = 0, spread = 0, punchPitch = 0, punchYaw = 0;
    std::uintptr_t weapon = 0;
    float Tangent() const {
        return inaccuracy + spread;
    }
};
inline bool ProbePlausible(float inaccuracy, float spread) {
    return std::isfinite(inaccuracy) && std::isfinite(spread) && inaccuracy >= 0.f && spread >= 0.f &&
           inaccuracy <= world_camera_probe::MaxInaccuracy && spread <= world_camera_probe::MaxSpread;
}
inline bool ProbePunchPlausible(const float* v) {
    for (int i = 0; i < 3; ++i)
        if (!std::isfinite(v[i]) || std::fabs(v[i]) > world_camera_probe::MaxPunchDegrees)
            return false;
    return true;
}

class ProbeShared {
    std::atomic<std::uint32_t> seq_{0}, busy_{0}, flags_{0}, inaccuracy_{0}, spread_{0}, pitch_{0}, yaw_{0};
    std::atomic<std::uintptr_t> weapon_{0};
    std::atomic<std::uint64_t> at_{0};
    static std::uint32_t Bits(float f) {
        std::uint32_t u;
        std::memcpy(&u, &f, sizeof u);
        return u;
    }
    static float Float(std::uint32_t u) {
        float f;
        std::memcpy(&f, &u, sizeof f);
        return f;
    }
    void Write(std::uint32_t flags, const ProbeSample& s, std::uint64_t now) {
        if (busy_.exchange(1, std::memory_order_acquire))
            return;
        const auto n = seq_.load(std::memory_order_relaxed);
        seq_.store(n + 1, std::memory_order_release);
        std::atomic_thread_fence(std::memory_order_release);
        inaccuracy_.store(Bits(s.inaccuracy), std::memory_order_relaxed);
        spread_.store(Bits(s.spread), std::memory_order_relaxed);
        pitch_.store(Bits(s.punchPitch), std::memory_order_relaxed);
        yaw_.store(Bits(s.punchYaw), std::memory_order_relaxed);
        weapon_.store(s.weapon, std::memory_order_relaxed);
        at_.store(now, std::memory_order_relaxed);
        flags_.store(flags, std::memory_order_relaxed);
        seq_.store(n + 2, std::memory_order_release);
        busy_.store(0, std::memory_order_release);
    }

public:
    void Store(const ProbeSample& s, std::uint64_t now) {
        Write(1u | (s.hasPunch ? 2u : 0u), s, now);
    }
    void Clear() {
        Write(0u, ProbeSample{}, 0);
    }

    bool Load(ProbeSample& out, std::uint64_t now,
              std::uint64_t maxAge = world_camera_probe::MaxAgeMs) const {
        for (int attempt = 0; attempt < 4; ++attempt) {
            const auto a = seq_.load(std::memory_order_acquire);
            if (a & 1u)
                continue;
            ProbeSample s;
            const auto flags = flags_.load(std::memory_order_relaxed);
            s.inaccuracy = Float(inaccuracy_.load(std::memory_order_relaxed));
            s.spread = Float(spread_.load(std::memory_order_relaxed));
            s.punchPitch = Float(pitch_.load(std::memory_order_relaxed));
            s.punchYaw = Float(yaw_.load(std::memory_order_relaxed));
            s.weapon = weapon_.load(std::memory_order_relaxed);
            const auto at = at_.load(std::memory_order_relaxed);
            std::atomic_thread_fence(std::memory_order_acquire);
            if (seq_.load(std::memory_order_relaxed) != a)
                continue;
            if (!(flags & 1u) || !s.weapon || now < at || now - at > maxAge ||
                !ProbePlausible(s.inaccuracy, s.spread))
                return false;
            s.valid = true;
            s.hasPunch = (flags & 2u) != 0;
            out = s;
            return true;
        }
        return false;
    }
};
}
