#pragma once
#include "hud_color_picker.h"
#include "hotkey_window.h"
#include "spectators_window.h"
namespace menu {

struct KeybindUI {
    enum Action {
        Entry = 1,
        New,
        Capture,
        Mode,
        Boolean,
        Number,
        Shown,
        Delete,
        Option,
        ColorValue,
        Reset,
        CopyPath
    };
    struct Hit {
        Box box;
        int action = 0, option = 0;
        std::string id;
        bool selected = false, disabled = false;
    };
    HotkeyWindow hotkeyWindow;
    SpectatorsWindow spectatorsWindow;
    PresetsUI paint, hudPaint;
    LanguageCatalog* languages = nullptr;
    KeybindRuntime runtime;
    std::function<std::vector<std::u32string>(const KeybindTarget&)> options;
    std::vector<Hit> hits;
    std::string directTarget;
    std::string target, editor, capturing, numericID, colorID, choiceID, dragID;
    bool captureReady = false, selectAll = false, releaseGuard = false, capturedEscape = false;
    int held = -1;
    Box fieldAnchor{};
    std::string numeric, error, clipboardOut;
    Box popup{}, flyout{}, anchor{}, editorAnchor{}, choiceBox{};
    float mouseX = -1, mouseY = -1, scale = 1, rootScroll = 0, maxRoot = 0;

    PresetMotion choiceFade;
    PresetLayer choiceLast{};
    std::string choiceVisualKey;
    bool choiceStored = false;
    PresetMotion fade, tooltipFade;
    std::map<std::string, PresetMotion> hover, ink, badgeMotion, visibleMotion, pillExpand, pillFill,
        valueMotion, entryReveal, sliderTip, multiColumn;
    std::map<std::string, Box> sliderTracks;

    std::map<std::string, MenuKeybind> retiring;
    std::vector<std::string> retiringOrder;
    bool Retiring(const std::string& id) const {
        return retiring.find(id) != retiring.end();
    }
    std::vector<MenuKeybind> VisualBindings(const Settings& cfg) const {
        auto rows = cfg.keybinds;
        for (const auto& item : retiring)
            if (!Find(cfg, item.first))
                rows.push_back(item.second);
        if (retiring.empty())
            return rows;
        std::vector<MenuKeybind> sorted;
        for (const auto& id : retiringOrder)
            for (const auto& row : rows)
                if (row.id == id) {
                    sorted.push_back(row);
                    break;
                }
        for (const auto& row : rows)
            if (std::find(retiringOrder.begin(), retiringOrder.end(), row.id) == retiringOrder.end())
                sorted.push_back(row);
        return sorted;
    }
    void FinishRetiring() {
        for (const auto& item : retiring)
            entryReveal.erase(item.first);
        retiring.clear();
        retiringOrder.clear();
    }
    bool Remove(Settings& cfg, std::string id) {
        auto* b = Find(cfg, id);
        if (!b)
            return false;
        auto copy = *b;
        auto rows = VisualBindings(cfg);
        retiringOrder.clear();
        for (const auto& row : rows)
            retiringOrder.push_back(row.id);
        retiring[id] = copy;
        auto& motion = entryReveal[id];
        if (!motion.initialized)
            motion.Snap(1);

        motion.Tick(0, 0);
        cfg.keybinds.erase(std::remove_if(cfg.keybinds.begin(), cfg.keybinds.end(),
                                          [&](const MenuKeybind& row) { return row.id == id; }),
                           cfg.keybinds.end());
        runtime.states.erase(id);
        if (editor == id)
            editor.clear();
        CancelEdits();
        return true;
    }
    struct PillState {
        Box box;
        std::string key;
        bool selected = false;
    };
    std::vector<PillState> pills;
    float tooltipTime = 0;
    std::string tooltipID;
    Fonts* metrics = nullptr;
    static std::string MotionKey(int action, const std::string& id, int option = 0) {
        return std::to_string(action) + id + ":" + std::to_string(option);
    }
    std::u32string EntryLabel(const MenuKeybind& b) const {
        return b.key ? ModeLabel(b.mode) + U" \"" + KeyLabel(b.key) + U"\"" : Label("menu_keybinds_unbound");
    }
    KeybindUI() {
        fade.Snap(0);
        choiceFade.Snap(0);
    }
    bool Active() const {
        return !target.empty() || !directTarget.empty();
    }
    bool CapturingKey() const {
        return !capturing.empty() || !directTarget.empty();
    }
    void BeginDirect(const std::string& id) {
        Close();
        if (FindKeybindTarget(id)) {
            directTarget = id;
            captureReady = false;
        }
    }
    bool Editing() const {
        return CapturingKey() || !numericID.empty() || (!colorID.empty() && picker.Editing());
    }
    MenuKeybind* Find(Settings& cfg, const std::string& id) const {
        for (auto& b : cfg.keybinds)
            if (b.id == id)
                return &b;
        return nullptr;
    }
    const MenuKeybind* Find(const Settings& cfg, const std::string& id) const {
        for (const auto& b : cfg.keybinds)
            if (b.id == id)
                return &b;
        return nullptr;
    }
    std::u32string Label(const std::string& key) const {
        if (languages)
            return languages->Label(key);
        auto& m = DefaultLanguageStrings();
        auto it = m.find(key);
        return DecodeUTF8(it == m.end() ? key : it->second);
    }
    std::u32string KeyLabel(int key) const {
        return key ? DecodeUTF8(MenuKeyName(key)) : Label("menu_keybinds_unbound");
    }
    std::u32string BadgeLabel(int key) const {
        return key ? DecodeUTF8(MenuKeyName(key)) : U"-";
    }
    std::u32string ModeLabel(int mode) const {
        return Label(mode ? "menu_keybinds_mode_hold" : "menu_keybinds_mode_toggle");
    }
    std::vector<std::u32string> Options(const KeybindTarget& t) const {
        return options ? options(t) : std::vector<std::u32string>{};
    }
    std::u32string ValueLabel(const MenuKeybind& b) const {
        auto t = FindKeybindTarget(b.target);
        if (t.color)
            return ASCII("#" + HudColorPicker::Hex({b.value[0], b.value[1], b.value[2], b.value[3]}));
        if (t.kind == WorldKind::Check)
            return Label(b.value[0] ? "value_on" : "value_off");
        auto names = Options(t);
        if (t.kind == WorldKind::Choice && !names.empty()) {
            int n = int(b.value[0]);
            if (n >= 0 && n < int(names.size()))
                return names[std::size_t(n)];
        }
        if (t.kind == WorldKind::Multi && !names.empty()) {
            std::u32string text;
            for (std::size_t i = 0; i < names.size(); ++i)
                if (int(b.value[0]) & (1 << i)) {
                    if (!text.empty())
                        text += U", ";
                    text += names[i];
                }
            return text.empty() ? Label("menu_select") : text;
        }
        std::ostringstream out;
        if (t.kind == WorldKind::Decimal)
            out << std::fixed << std::setprecision(t.domain == 0 ? 1 : 2);
        out << b.value[0];
        return ASCII(out.str());
    }

    std::u32string EditorValueLabel(const MenuKeybind& b) const {
        auto text = ValueLabel(b);
        const auto t = FindKeybindTarget(b.target);
        if (t.kind != WorldKind::Multi || t.color || b.value[0] == 0 || text.size() < 15)
            return text;
        text.clear();
        const auto names = Options(t);
        for (std::size_t i = 0; i < names.size(); ++i)
            if (int(b.value[0]) & (1 << i)) {
                if (!text.empty())
                    text += U", ";
                if (!names[i].empty())
                    text += names[i].front();
            }
        return text;
    }
    void Open(const std::string& id, float x, float y) {
        FinishRetiring();
        target = id;
        editor.clear();
        CancelEdits();
        anchor = {x + 1, y + 1, 0, 0};
        rootScroll = 0;
        fade.Snap(0);
    }
    void CancelEdits() {
        directTarget.clear();
        tooltipID.clear();
        tooltipTime = 0;
        tooltipFade.Snap(0);
        capturing.clear();
        numericID.clear();
        colorID.clear();
        choiceID.clear();
        dragID.clear();
        numeric.clear();
        captureReady = false;
        capturedEscape = false;
        held = -1;
        picker.held = -1;
    }
    void Close() {
        FinishRetiring();
        target.clear();
        editor.clear();
        CancelEdits();
    }
    void CancelInput() {
        held = -1;
        dragID.clear();
        picker.held = -1;
    }
    bool Commit(Settings& cfg) {
        if (numericID.empty())
            return true;
        auto* b = Find(cfg, numericID);
        if (!b) {
            numericID.clear();
            return true;
        }
        try {
            std::size_t used = 0;
            float v = std::stof(numeric, &used);
            if (used != numeric.size() || !std::isfinite(v))
                return false;
            auto t = FindKeybindTarget(b->target);
            v = std::clamp(v, t.minimum, t.maximum);
            if (t.kind != WorldKind::Decimal)
                v = std::round(v);
            else {
                float precision = t.domain == 0 ? 10.f : 100.f;
                v = std::round(v * precision) / precision;
            }
            b->value[0] = v;
            numericID.clear();
            numeric.clear();
            error.clear();
            return true;
        } catch (...) {
            error = "Invalid value";
            return false;
        }
    }
    void Add(Settings& cfg) {
        if (std::any_of(cfg.keybinds.begin(), cfg.keybinds.end(),
                        [&](const MenuKeybind& b) { return b.target == target && !b.key; }))
            return;
        if (!FindKeybindTarget(target) || cfg.keybinds.size() >= MenuKeybindLimit) {
            error = "Keybind limit: 128";
            return;
        }
        MenuKeybind b;
        b.id = PresetID();
        b.target = target;
        b.value = KeybindGet(cfg, FindKeybindTarget(target));
        cfg.keybinds.push_back(b);
        entryReveal[b.id].Snap(0);
        editor = b.id;
        editorAnchor = popup;
        CancelEdits();
    }
    void Assign(Settings& cfg, int key) {
        if (key == 27)
            capturedEscape = true;
        if (!directTarget.empty()) {
            auto t = FindKeybindTarget(directTarget);
            if (t)
                KeybindSet(cfg, t, {{float(key == 27 ? 0 : std::clamp(key, 0, 255)), 0, 0, 0}});
            directTarget.clear();
        }
        if (auto* b = Find(cfg, capturing))
            b->key = key == 27 ? 0 : std::clamp(key, 0, 255);
        capturing.clear();
        captureReady = false;
    }
    template <class Reader>
    void Poll(Settings& cfg, Reader&& reader, bool focused, bool blocked, const std::string& selection) {
        if (!focused) {
            hotkeyWindow.dragging = false;
            spectatorsWindow.dragging = false;
            CancelInput();
            directTarget.clear();
            capturing.clear();
            captureReady = false;
            runtime.Poll(cfg, reader, false, true, selection);
            return;
        }
        if (CapturingKey()) {
            if (directTarget.empty() && !Find(cfg, capturing)) {
                capturing.clear();
            } else {
                bool any = false;
                for (int key = 1; key <= 255; ++key)
                    if (key != 3 && key != 7 && reader(key)) {
                        any = true;
                        if (captureReady) {
                            Assign(cfg, key);
                            break;
                        }
                    }
                if (!any)
                    captureReady = true;
            }
            runtime.Poll(cfg, reader, true, true, selection);
            return;
        }
        runtime.Poll(cfg, reader, focused, blocked || Active(), selection);
    }
    void Tick(float dt) {
        hotkeyWindow.Tick(dt);
        spectatorsWindow.Tick(dt);
        fade.Tick(Active() ? 1.f : 0.f, dt);
        choiceFade.Tick(!choiceID.empty() ? 1.f : 0.f, dt);

        for (auto& item : entryReveal)
            item.second.Tick(Retiring(item.first) ? 0.f : 1.f, dt);
        for (auto it = retiring.begin(); it != retiring.end();)
            if (entryReveal[it->first].value <= .000001f) {
                entryReveal.erase(it->first);
                it = retiring.erase(it);
            } else
                ++it;
        if (retiring.empty())
            retiringOrder.clear();
        for (auto& item : multiColumn)
            item.second.Tick(item.second.target, dt);
        for (auto& item : sliderTip) {
            auto it = sliderTracks.find(item.first);
            bool over = capturing.empty() && it != sliderTracks.end() && it->second.Contains(mouseX, mouseY);
            item.second.Tick(over || dragID == item.first ? 1.f : 0.f, dt);
        }
        int top = -1;
        for (int i = int(hits.size()) - 1; i >= 0; --i)
            if (hits[std::size_t(i)].box.Contains(mouseX, mouseY)) {
                top = i;
                break;
            }
        std::string tip;
        for (std::size_t i = 0; i < hits.size(); ++i) {
            const auto& h = hits[i];
            auto key = MotionKey(h.action, h.id, h.option);
            bool activeCapture = h.action == Capture && capturing == h.id;
            bool over = int(i) == top && !h.disabled && (capturing.empty() || activeCapture),
                 pressed = over && held == int(i);

            hover[key].Tick(h.disabled ? 0.f : (pressed || activeCapture) ? 1.f : over ? .5f : 0.f, dt);
            ink[key].Tick(h.disabled                ? 0.f
                          : (h.selected || pressed) ? 1.f
                          : (over || activeCapture) ? .5f
                                                    : 0.f,
                          dt);
            if (h.action == Capture)
                badgeMotion[h.id].Tick(capturing == h.id ? 1.f : over ? .7f : 0.f, dt);
            if (h.action == Boolean)
                valueMotion[h.id].Tick(h.selected ? 1.f : 0.f, dt);
            if (h.action == Shown) {
                visibleMotion[h.id].Tick(h.selected ? 1.f : 0.f, dt);
                if (over)
                    tip = h.id;
            }
        }
        for (const auto& p : pills) {
            pillExpand[p.key].Tick(p.selected ? 1.f : 0.f, dt);
            bool over = capturing.empty() && p.box.Contains(mouseX, mouseY);
            pillFill[p.key].Tick(over && held >= 0 ? 1.f : (p.selected || over) ? .5f : 0.f, dt);
        }
        if (tip != tooltipID) {
            tooltipID = tip;
            tooltipTime = 0;
        } else if (!tip.empty())
            tooltipTime += std::max(0.f, dt);

        tooltipFade.Tick(!tip.empty() && tooltipTime >= .35f ? 1.f : 0.f, dt);
        picker.Tick(dt, Active());
    }
    void PrepareColor(const Settings& cfg, const MenuKeybind& b) {
        scratch.theme = cfg.theme;
        scratch.scale = cfg.scale;
        scratch.customAccent = cfg.customAccent;
        scratch.accent = cfg.accent;
        scratch.worldHud.colors[0] = {b.value[0], b.value[1], b.value[2], b.value[3]};
    }
    void StoreColor(Settings& cfg) {
        if (auto* b = Find(cfg, colorID)) {
            auto c = scratch.worldHud.colors[0];
            b->value = {{c.r, c.g, c.b, c.a}};
        }
    }
    void Drag(float x, Settings& cfg) {
        auto* b = Find(cfg, dragID);
        if (!b)
            return;
        auto t = FindKeybindTarget(b->target);
        float n =
            t.minimum +
            std::clamp((x - dragControl.x) / std::max(1.f, dragControl.w - 1.f), 0.f, 1.f) *
                (t.maximum - t.minimum);
        float precision = t.domain == 0 ? 10.f : 100.f;
        b->value[0] = t.kind == WorldKind::Decimal ? std::round(n * precision) / precision : std::round(n);
    }
    void Move(float x, float y, Settings& cfg) {
        mouseX = x;
        mouseY = y;
        if (!dragID.empty())
            Drag(x, cfg);

        if (held < 0 && capturing.empty() && numericID.empty() && colorID.empty())
            for (auto it = hits.rbegin(); it != hits.rend(); ++it)
                if (it->box.Contains(x, y)) {
                    if (it->action == Entry && !it->disabled && editor != it->id) {
                        editor = it->id;
                        editorAnchor = it->box;
                        CancelEdits();
                    } else if (it->action == Option && it->option == -2 && !it->disabled) {
                        choiceID = it->id;
                        fieldAnchor = it->box;
                    } else if (!choiceID.empty() && flyout.Contains(x, y) &&
                               !choiceBox.Contains(x, y) && it->action != Option)
                        choiceID.clear();
                    break;
                }
        if (!colorID.empty()) {
            picker.Move(x, y, scratch);
            StoreColor(cfg);
        }
    }
    bool Click(float x, float y, bool down, Settings& cfg, bool ctrl = false) {
        if (!Active()) {
            if (releaseGuard) {
                if (!down)
                    releaseGuard = false;
                return true;
            }
            return false;
        }
        mouseX = x;
        mouseY = y;
        if (CapturingKey())
            return true;
        if (!colorID.empty()) {
            if (picker.box.Contains(x, y) || picker.menuBox.Contains(x, y) || picker.held >= 0) {
                picker.Click(x, y, down, scratch);
                StoreColor(cfg);
                return true;
            }
            if (down) {
                colorID.clear();
                releaseGuard = true;
                return true;
            }
        }
        if (!down && releaseGuard) {
            releaseGuard = false;
            held = -1;
            return true;
        }
        if (!down && !dragID.empty()) {
            Drag(x, cfg);
            dragID.clear();
            held = -1;
            return true;
        }
        int hit = -1;
        for (int i = int(hits.size()) - 1; i >= 0; --i)
            if (hits[std::size_t(i)].box.Contains(x, y)) {
                hit = i;
                break;
            }
        if (down) {
            if (hit < 0) {
                if (!popup.Contains(x, y) && !flyout.Contains(x, y) && !choiceBox.Contains(x, y)) {
                    Close();
                    releaseGuard = true;
                }
                return true;
            }
            const auto& h = hits[std::size_t(hit)];
            if (h.disabled) {
                held = -1;
                return true;
            }
            if (!numericID.empty() && !Commit(cfg))
                return true;
            held = hit;
            if (h.action != Option)
                choiceID.clear();
            if (h.action == Number && !ctrl) {
                auto track = sliderTracks.find(h.id);
                if (track != sliderTracks.end() && track->second.Contains(x, y)) {
                    dragID = h.id;
                    dragControl = track->second;
                    Drag(x, cfg);
                }
            }
            return true;
        }
        if (hit < 0 || held != hit) {
            held = -1;
            return true;
        }
        auto h = hits[std::size_t(hit)];
        held = -1;
        if (h.disabled)
            return true;
        if (h.action == New) {
            Add(cfg);
            return true;
        }
        if (h.action == CopyPath) {
            clipboardOut = target;
            Close();
            return true;
        }
        if (h.action == Reset) {
            auto t = FindKeybindTarget(target);
            if (t) {
                Settings defaults;
                KeybindSet(cfg, t, KeybindGet(defaults, t));
            }
            Close();
            return true;
        }
        auto* b = Find(cfg, h.id);
        if (!b)
            return true;
        switch (h.action) {
        case Entry:
            editor = h.id;
            editorAnchor = h.box;
            CancelEdits();
            break;
        case Capture:
            capturing = h.id;
            captureReady = false;
            break;
        case Mode:
            b->mode = (b->mode + 1) % 2;
            break;
        case Boolean:
            b->value[0] = b->value[0] ? 0 : 1;
            break;
        case Number:
            if (!ctrl)
                break;
            fieldAnchor = h.box;
            numericID = h.id;
            numeric = EncodeUTF8(ValueLabel(*b));
            selectAll = true;
            break;
        case Shown:
            b->shown = !b->shown;
            break;
        case Delete:
            Remove(cfg, h.id);
            break;
        case Option: {
            auto t = FindKeybindTarget(b->target);
            if (h.option < 0) {
                choiceID = h.option == -2 ? h.id : choiceID == h.id ? "" : h.id;
                fieldAnchor = h.box;
            } else if (t.kind == WorldKind::Multi)
                b->value[0] = float(int(b->value[0]) ^ (1 << h.option));
            else {
                b->value[0] = float(h.option);
                choiceID.clear();
            }
            break;
        }
        case ColorValue:
            fieldAnchor = h.box;
            colorID = h.id;
            PrepareColor(cfg, *b);
            picker.Reset(0);
            break;
        default:
            break;
        }
        return true;
    }
    bool Key(int key, Settings& cfg, bool shift = false, bool ctrl = false) {
        (void)shift;
        if (!Active())
            return false;
        if (key == 27 && capturedEscape) {
            capturedEscape = false;
            return true;
        }
        if (CapturingKey()) {
            if (key == 27)
                Assign(cfg, 0);
            return true;
        }
        if (!colorID.empty()) {
            if (picker.Key(key, scratch, ctrl)) {
                StoreColor(cfg);
                return true;
            }
            if (key == 27) {
                colorID.clear();
                return true;
            }
        }
        if (!numericID.empty()) {
            if (key == 27) {
                numericID.clear();
                numeric.clear();
            } else if (key == 13)
                Commit(cfg);
            else if (ctrl && key == 'A')
                selectAll = true;
            else if (key == 8 || key == 46) {
                if (selectAll)
                    numeric.clear();
                else if (!numeric.empty())
                    numeric.pop_back();
                selectAll = false;
            }
            return true;
        }
        if (key == 27) {
            if (!choiceID.empty())
                choiceID.clear();
            else if (!editor.empty())
                editor.clear();
            else
                Close();
        }
        return true;
    }
    bool Character(char16_t c) {
        if (!Active())
            return false;
        if (!colorID.empty())
            return picker.Character(c);
        if (!numericID.empty() && ((c >= '0' && c <= '9') || c == '.' || c == '-' || c == '+')) {
            if (selectAll) {
                numeric.clear();
                selectAll = false;
            }
            if (numeric.size() < 24)
                numeric += char(c);
        }
        return true;
    }
    bool Wheel(float steps, Settings& cfg) {
        if (!Active())
            return false;
        if (!CapturingKey() && numericID.empty() && colorID.empty())
            for (auto it = hits.rbegin(); it != hits.rend(); ++it)
                if (it->action == Number && it->box.Contains(mouseX, mouseY)) {
                    if (auto* b = Find(cfg, it->id)) {
                        auto t = FindKeybindTarget(b->target);
                        float step = t.kind == WorldKind::Decimal ? (t.domain == 0 ? .1f : .01f) : 1.f;
                        b->value[0] = std::clamp(b->value[0] + steps * step, t.minimum, t.maximum);
                    }
                    return true;
                }
        rootScroll = std::clamp(rootScroll - steps * 30 * scale, 0.f, maxRoot);
        return true;
    }
    void Measure(Fonts& fonts, const Settings& cfg, int width, int height, bool blocked) {
        if (blocked)
            Close();
        Hit pressedHit{};
        bool hadHeld = held >= 0 && held < int(hits.size());
        if (hadHeld)
            pressedHit = hits[std::size_t(held)];
        scale = cfg.scale;
        metrics = &fonts;
        hits.clear();
        pills.clear();
        sliderTracks.clear();
        for (auto it = retiring.begin(); it != retiring.end();)
            if (Find(cfg, it->first)) {
                entryReveal[it->first].Snap(1);
                it = retiring.erase(it);
            } else
                ++it;
        for (auto it = entryReveal.begin(); it != entryReveal.end();)
            if (!Find(cfg, it->first) && !Retiring(it->first))
                it = entryReveal.erase(it);
            else
                ++it;
        choiceBox = {};
        flyout = {};
        if (!directTarget.empty()) {
            paint.layers.clear();
            return;
        }
        if (!Active()) {
            if (fade.value <= .001f)
                paint.layers.clear();
            else
                for (auto& layer : paint.layers) {
                    float old = layer.opacity;
                    layer.opacity = fade.value;
                    if (old > 0)
                        for (auto& d : layer.draw)
                            d.color.a *= fade.value / old;
                }
            return;
        }
        paint.layers.clear();
        const auto visual = VisualBindings(cfg);
        const float s = scale, F = fonts.PixelHeight(0, 13 * s), H = F + 14 * s, pad = 7 * s;
        auto pal = CurrentPalette(cfg);
        auto place = [&](float x, float y, float w, float h) {
            w = std::min(w, std::max(1.f, float(width) - 8 * s));
            h = std::min(h, std::max(1.f, float(height) - 8 * s));
            return Box{std::clamp(x, 4 * s, std::max(4 * s, width - w - 4 * s)),
                       std::clamp(y, 4 * s, std::max(4 * s, height - h - 4 * s)), w, h};
        };

        auto layer = [&](Box box) {
            paint.layers.push_back({box, 15 * s, true, {}});
            int z = int(paint.layers.size()) - 1;
            Rect(paint, z, box, pal[8], 15 * s);
            Rect(paint, z, box, pal[11], 15 * s, s);
            return z;
        };
        auto separator = [&](int z, float x, float y, float w) {
            if (w <= 20 * s)
                return;
            Rect(paint, z, {x + 10 * s, y, w - 20 * s, s}, pal[34]);
            auto& d = paint.layers[std::size_t(z)].draw.back();
            d.pixelLine = true;
            d.uniformSeparator = true;
        };
        auto alpha = [](Color c, float a) {
            c.a *= a;
            return c;
        };
        auto tw = [&](const std::u32string& text, int font = 0) {
            return std::trunc(fonts.NativeTextSize(font, 13 * s, text).w + .95f);
        };
        auto iconDraw = [&](int z, Box box, char32_t cp, Color c) {
            float iw = tw(std::u32string(1, cp), 3);
            Text(paint, z, {box.x + (box.w - iw) * .5f, box.y, iw, box.h}, std::u32string(1, cp), c, 3, 13);
        };
        auto button = [&](int z, Box box, std::u32string label, int action, const std::string& id = "",
                          int option = 0, char32_t icon = 0, bool selected = false, bool disabled = false,
                          bool red = false, float reserve = 0.f) {
            auto k = MotionKey(action, id, option);
            auto& fill = hover[k];
            auto& text = ink[k];
            if (!fill.initialized)
                fill.Snap(0);
            if (!text.initialized)
                text.Snap(selected ? 1.f : 0.f);
            Rect(paint, z, box, alpha(pal[33], .4f * fill.value), 15 * s / 1.6f);
            Color c = red        ? Color{.86f, .39f, .38f, 1}
                      : disabled ? alpha(pal[0], .7f)
                                 : Mix(pal[14], pal[2], text.value);
            float tx = box.x + 12 * s;
            if (icon) {
                iconDraw(z, {tx, box.y, 20 * s, box.h}, icon, c);
                tx += 32 * s;
            }
            Text(paint, z, {tx, box.y, std::max(0.f, box.x + box.w - tx - 12 * s - reserve), box.h},
                 std::move(label), c);
            Box clipped = PresetIntersect(box, paint.layers[std::size_t(z)].box);
            if (clipped.w > 0 && clipped.h > 0)
                hits.push_back({clipped, action, option, id, selected, disabled});
        };
        auto centered = [&](int z, Box box, const std::u32string& text, Color c) {
            float w = std::min(box.w, tw(text));
            Text(paint, z, {box.x + (box.w - w) * .5f, box.y, w, box.h}, text, c);
        };
        auto switchDraw = [&](int z, Box row, int action, const std::string& id, bool selected) {
            auto& motion = action == Boolean ? valueMotion[id] : visibleMotion[id];
            if (!motion.initialized)
                motion.Snap(selected ? 1.f : 0.f);
            float v = motion.value;
            Box track{row.x + row.w - 44 * s, row.y + std::trunc((row.h - F - 2 * s) * .5f), 32 * s,
                      F + 2 * s};
            Rect(paint, z, track, pal[22], track.h * .5f);
            Rect(paint, z, track, alpha(pal[23], v), track.h * .5f);
            float r = std::max(0.f, track.h * .5f - 2 * s);
            Rect(paint, z, {track.x + 2 * s + v * (track.w - 4 * s - 2 * r), track.y + 2 * s, 2 * r, 2 * r},
                 Mix(pal[20], pal[21], v), r);
        };
        std::vector<const MenuKeybind*> list;
        float intrinsic = 150 * s, animatedRows = 0;
        bool unbound = false;
        for (const auto& b : visual)
            if (b.target == target) {
                list.push_back(&b);
                auto& reveal = entryReveal[b.id];
                if (!reveal.initialized)
                    reveal.Snap(1);
                animatedRows += reveal.value;
                unbound |= !Retiring(b.id) && !b.key;
                intrinsic = std::max(intrinsic, tw(EntryLabel(b)) + 56 * s + tw(U"\uf105", 3) + 6 * s);
            }
        for (auto key : {"menu_keybinds_newhotkey",
                         "menu_buttons_copyscriptpath", "menu_buttons_reset"})
            intrinsic = std::max(intrinsic, tw(Label(key)) + 56 * s);
        float room = std::max(0.f, float(height) - 8 * s - 2 * pad - 3 * H - 7 * s);
        float bodyHeight = std::min(animatedRows * H, room);
        popup = place(anchor.x, anchor.y, intrinsic + 2 * pad, 2 * pad + bodyHeight + 3 * H + 7 * s);
        int z = layer(popup);
        Box body{popup.x + pad, popup.y + pad, popup.w - 2 * pad, bodyHeight};
        maxRoot = std::max(0.f, animatedRows * H - bodyHeight);
        rootScroll = std::clamp(rootScroll, 0.f, maxRoot);
        float rowY = body.y - rootScroll;
        for (std::size_t i = 0; i < list.size(); ++i) {
            const auto& b = *list[i];
            float reveal = entryReveal[b.id].value;
            Box row{body.x, rowY, body.w, H};
            rowY += H * reveal;
            if (reveal <= .001f)
                continue;
            Box clip = PresetIntersect(row, body);
            if (clip.w <= 0 || clip.h <= 0)
                continue;
            auto start = paint.layers[std::size_t(z)].draw.size();
            button(z, row, EntryLabel(b), Entry, b.id, 0, 0xe1c0, false, false, false,
                   tw(U"\uf105", 3) + 6 * s);
            if (Retiring(b.id))
                hits.pop_back();
            else
                hits.back().box = clip;
            iconDraw(z, {row.x + row.w - 12 * s - tw(U"\uf105", 3), row.y, tw(U"\uf105", 3), H}, 0xf105,
                     pal[0]);

            auto& draw = paint.layers[std::size_t(z)].draw;
            for (std::size_t j = start; j < draw.size(); ++j) {
                draw[j].clip = PresetIntersect(draw[j].clip, body);
                draw[j].color.a *= reveal;
                if (Retiring(b.id))
                    draw[j].clip = PresetIntersect(draw[j].clip, {row.x, row.y, row.w, H * reveal});
            }
        }
        float y = popup.y + pad + bodyHeight;
        button(z, {popup.x + pad, y, popup.w - 2 * pad, H}, Label("menu_keybinds_newhotkey"), New, "", 0,
               0xf055, false, unbound || cfg.keybinds.size() >= MenuKeybindLimit);
        y += H;
        separator(z, popup.x + pad, y + 3 * s, popup.w - 2 * pad);
        y += 7 * s;

        button(z, {popup.x + pad, y, popup.w - 2 * pad, H}, Label("menu_buttons_copyscriptpath"),
               CopyPath, "", 0, 0xf7ea);
        y += H;
        button(z, {popup.x + pad, y, popup.w - 2 * pad, H}, Label("menu_buttons_reset"), Reset, "", 0,
               0xf2ea, false, false, true);
        const auto* b = Find(cfg, editor);

        if (!b && !editor.empty()) {
            editor.clear();
            CancelEdits();
        }
        if (b) {
            const auto t = FindKeybindTarget(b->target);
            float modeRight = 2 * (F + 12 * s) + std::max(tw(ModeLabel(0)), tw(ModeLabel(1))) + 6 * s;
            float editorW = std::max(
                {220 * s, 56 * s + tw(Label("menu_keybinds_mode")) + modeRight,
                 56 * s + tw(Label("menu_keybinds_key")) + std::max(10 * s, tw(BadgeLabel(b->key))) + 18 * s,
                 56 * s + tw(Label("menu_keybinds_visibility_shown")) + 38 * s,
                 56 * s + tw(Label("menu_buttons_delete"))});
            if ((t.kind == WorldKind::Choice || t.kind == WorldKind::Multi) && !t.color)
                editorW = std::max(editorW, 56 * s + tw(Label("menu_keybinds_value")) +
                                                tw(EditorValueLabel(*b)) + tw(U"\uf105", 3) + 15 * s);
            flyout =
                place(popup.x + popup.w + 4 * s, editorAnchor.y, editorW + 2 * pad, 2 * pad + 5 * H + 14 * s);
            if (popup.x + popup.w + flyout.w + 4 * s > width)
                flyout = place(popup.x - flyout.w - 4 * s, editorAnchor.y, flyout.w, flyout.h);
            int z = layer(flyout);
            float x = flyout.x + pad, y = flyout.y + pad, w = flyout.w - 2 * pad, labelWidth = 55 * s;
            Box keyRow{x, y, w, H};
            auto keyText = BadgeLabel(b->key);
            float keyWidth = std::max(10 * s, tw(keyText)) + 12 * s;
            button(z, keyRow, Label("menu_keybinds_key"), Capture, b->id, 0, 0xe1c0, false, false, false,
                   keyWidth + 6 * s);
            auto& keyMotion = badgeMotion[b->id];
            if (!keyMotion.initialized)
                keyMotion.Snap(0);
            Box keyBadge{x + w - 12 * s - keyWidth, y + std::trunc((H - (F + 6 * s)) * .5f), keyWidth,
                         F + 6 * s};
            Rect(paint, z, keyBadge, alpha(pal[33], .2f + .2f * keyMotion.value), 6 * s);
            Text(paint, z, {keyBadge.x + (keyWidth - tw(keyText)) * .5f, keyBadge.y, tw(keyText), keyBadge.h},
                 keyText, Mix(pal[14], pal[0], keyMotion.value));
            y += H;

            std::array<float, 2> pillWidth{};
            float total = 0;
            for (int i = 0; i < 2; ++i) {
                auto key = b->id + ":" + std::to_string(i);
                auto& e = pillExpand[key];
                auto& f = pillFill[key];
                if (!e.initialized)
                    e.Snap(b->mode == i ? 1.f : 0.f);
                if (!f.initialized)
                    f.Snap(b->mode == i ? .5f : 0.f);
                pillWidth[i] = F + 12 * s + (tw(ModeLabel(i)) + 6 * s) * e.value;
                total += pillWidth[i];
            }
            button(z, {x, y, w, H}, Label("menu_keybinds_mode"), Mode, b->id, 0, 0xf11c, false, false, false,
                   total + 6 * s);
            float px = x + w - 12 * s - total;
            for (int i = 0; i < 2; ++i) {
                auto key = b->id + ":" + std::to_string(i);
                float e = pillExpand[key].value;
                Box pill{px, y + (H - F - 6 * s) * .5f, pillWidth[i], F + 6 * s};
                pills.push_back({pill, key, b->mode == i});
                Rect(paint, z, pill, alpha(pal[33], .4f * pillFill[key].value), 7.8f * s);
                Color c = b->mode == i ? pal[31] : pal[0];
                iconDraw(z, {px + 6 * s, pill.y, F, pill.h}, i ? 0xe1c2 : 0xf205, c);
                if (e > 0) {
                    Text(paint, z,
                         {px + 6 * s + F + 6 * s, pill.y, std::max(0.f, pill.w - F - 18 * s), pill.h},
                         ModeLabel(i), alpha(c, e));
                }
                px += pill.w;
            }
            y += H;
            separator(z, x, y + 3 * s, w);
            y += 7 * s;
            Box value{x + labelWidth, y, w - labelWidth, H};
            int action = t.color                                                       ? ColorValue
                         : t.kind == WorldKind::Check                                  ? Boolean
                         : (t.kind == WorldKind::Choice || t.kind == WorldKind::Multi) ? Option
                                                                                       : Number;
            if (action == Boolean) {

                Box row{x, y, w, H};
                button(z, row, Label("menu_keybinds_value"), Boolean, b->id, 0, 0xf0c1, b->value[0] != 0,
                       false, false, 38 * s);
                switchDraw(z, row, Boolean, b->id, b->value[0] != 0);
            } else if ((t.kind == WorldKind::Choice || t.kind == WorldKind::Multi) && !t.color) {

                value = {x, y, w, H};
                const auto preview = EditorValueLabel(*b);
                float arrowW = tw(U"\uf105", 3), previewW = tw(preview);
                auto labels = Options(t);
                bool unavailable = labels.empty();
                button(z, value, Label("menu_keybinds_value"), Option, b->id, -2, 0xf0c1, false, unavailable,
                       false, previewW + arrowW + 3 * s);
                Color c = unavailable ? alpha(pal[0], .7f) : pal[0];
                float arrowX = x + w - 12 * s - arrowW;
                float previewX = arrowX - 3 * s - previewW,
                      left = x + 44 * s + tw(Label("menu_keybinds_value")) + 6 * s;

                float textX = std::max(left, previewX), textW = std::max(0.f, arrowX - 3 * s - textX);
                Text(paint, z, {textX, y, textW, H}, preview, c);
                iconDraw(z, {arrowX, y, arrowW, H}, 0xf105, c);
                if (choiceID == b->id)
                    fieldAnchor = value;
            } else if (action == Number) {

                value = {x, y, w, H};
                float trackW = std::trunc(w / 2.5f);
                button(z, value, Label("menu_keybinds_value"), Number, b->id, 0, 0xf0c1, false, false, false,
                       trackW);
                Box track{x + w - 12 * s - trackW, y + (H - 6 * s) * .5f, trackW, 6 * s};
                sliderTracks[b->id] = track;
                float fraction = std::clamp(
                    (b->value[0] - t.minimum) / std::max(.000001f, t.maximum - t.minimum), 0.f, 1.f);
                Rect(paint, z, track, pal[24], 3 * s);
                auto start = paint.layers[std::size_t(z)].draw.size();
                Rect(paint, z, track, pal[25], 3 * s);
                for (std::size_t i = start; i < paint.layers[std::size_t(z)].draw.size(); ++i)
                    paint.layers[std::size_t(z)].draw[i].clip =
                        PresetIntersect(paint.layers[std::size_t(z)].draw[i].clip,
                                        {track.x, track.y, track.w * fraction, track.h});
                auto& tip = sliderTip[b->id];
                if (!tip.initialized)
                    tip.Snap(0);
                if (numericID == b->id) {
                    Box edit{track.x, y + (H - F - 6 * s) * .5f, track.w, F + 6 * s};
                    Rect(paint, z, edit, pal[8], 6 * s);
                    centered(z, edit, ASCII(numeric), pal[0]);
                } else if (tip.value > .001f) {
                    auto text = ValueLabel(*b);
                    float textW = tw(text), tipH = F + 9 * s;
                    Box bubble = place(track.x + fraction * track.w - textW * .5f - 7 * s,
                                       track.y - F - 14 * s, textW + 14 * s, tipH);

                    Rect(paint, z, bubble, alpha(pal[8], tip.value), 8 * s);
                    Rect(paint, z, bubble, alpha(pal[11], tip.value), 8 * s, s);
                    Text(paint, z, {bubble.x + 7 * s, bubble.y + 4 * s, textW, F}, text,
                         alpha(pal[0], tip.value));
                }
            } else {
                Text(paint, z, {x + 12 * s, y, labelWidth - 12 * s, H}, Label("menu_keybinds_value"),
                     pal[14]);
                button(z, value, numericID == b->id ? ASCII(numeric) : ValueLabel(*b), action, b->id,
                       action == Option ? -1 : 0);
            }
            y += H;
            Box shownRow{x, y, w, H};
            button(z, shownRow, Label("menu_keybinds_visibility_shown"), Shown, b->id, 0, 0xf06e, b->shown,
                   false, false, 38 * s);
            switchDraw(z, shownRow, Shown, b->id, b->shown);
            y += H;
            separator(z, x, y + 3 * s, w);
            y += 7 * s;
            button(z, {x, y, w, H}, Label("menu_buttons_delete"), Delete, b->id, 0, 0xf2ed, false, false,
                   true);
            if (tooltipID == b->id && tooltipFade.value > .001f) {
                auto text = Label("menu_keybinds_displayhotkey");
                Box tip = place(shownRow.x, shownRow.y + H + 7 * s, tw(text) + 20 * s, F + 20 * s);
                int tz = layer(tip);
                Text(paint, tz, {tip.x + 10 * s, tip.y + 10 * s, tip.w - 20 * s, F}, text, pal[2]);
                for (auto& d : paint.layers[std::size_t(tz)].draw)
                    d.color.a *= tooltipFade.value;
            }
        }
        if (const auto* chosen = Find(cfg, choiceID)) {
            auto t = FindKeybindTarget(chosen->target);
            auto labels = Options(t);
            bool side = (t.kind == WorldKind::Choice || t.kind == WorldKind::Multi) && !t.color;
            if (side) {
                float menuW = 140 * s;
                for (const auto& label : labels)
                    menuW = std::max(menuW, tw(label) + 24 * s + 2 * pad +
                                                (t.kind == WorldKind::Multi ? tw(U"\uf00c", 3) + 6 * s : 0));
                float right = flyout.x + flyout.w + 4 * s, left = flyout.x - menuW - 4 * s;
                bool preferLeft = flyout.x < popup.x;
                float menuX = preferLeft ? (left >= 4 * s ? left : right)
                                         : (right + menuW <= width - 4 * s ? right : left);

                if (left < 4 * s && right + menuW > width - 4 * s)
                    menuX = width - right >= flyout.x ? right : left;
                choiceBox = place(menuX, fieldAnchor.y - pad, menuW, float(labels.size()) * H + 2 * pad);
            } else
                choiceBox = place(fieldAnchor.x, fieldAnchor.y + fieldAnchor.h + 3 * s,
                                  std::max(150 * s, fieldAnchor.w), float(labels.size()) * H + 2 * pad);
            const auto visualKey = choiceID;
            if (visualKey != choiceVisualKey) {
                choiceVisualKey = visualKey;
                choiceFade.Snap(0);
                choiceStored = false;
            }
            choiceFade.Tick(1, 0);
            int zz = layer(choiceBox);
            for (std::size_t i = 0; i < labels.size(); ++i) {
                bool selected = t.kind == WorldKind::Multi ? (int(chosen->value[0]) & (1 << i)) != 0
                                                          : int(chosen->value[0]) == int(i);
                Box row{choiceBox.x + pad, choiceBox.y + pad + float(i) * H, choiceBox.w - 2 * pad, H};
                auto start = paint.layers[std::size_t(zz)].draw.size();
                button(zz, row, labels[i], Option, chosen->id, int(i), 0, selected);
                if (t.kind == WorldKind::Multi) {

                    auto& column = multiColumn[chosen->id];
                    float goal = chosen->value[0] != 0 ? 1.f : 0.f;
                    if (!column.initialized)
                        column.Snap(goal);
                    else
                        column.Tick(goal, 0);
                    float markW = std::trunc(fonts.NativeTextSize(3, 11 * s, U"\uf00c").w + .95f),
                          offset = (markW + 6 * s) * column.value;
                    auto& draw = paint.layers[std::size_t(zz)].draw;
                    for (std::size_t j = start; j < draw.size(); ++j)
                        if (!draw[j].text.empty()) {
                            draw[j].box.x += offset;
                            draw[j].box.w = std::max(0.f, draw[j].box.w - offset);
                        }
                    if (selected && column.value > 0) {
                        auto c = pal[2];
                        c.a *= column.value;
                        Text(paint, zz, {row.x + 12 * s, row.y, markW, row.h}, U"\uf00c", c, 2, 11);
                        auto& marker = paint.layers[std::size_t(zz)].draw.back();
                        marker.icon = true;
                        marker.iconDestination = 2;
                    }
                }
            }
            choiceLast = paint.layers[std::size_t(zz)];
            choiceStored = true;
            auto& child = paint.layers[std::size_t(zz)];
            child.opacity *= choiceFade.value;
            for (auto& d : child.draw)
                d.color.a *= choiceFade.value;
        } else if (choiceStored) {
            choiceFade.Tick(0, 0);
            if (choiceFade.value > 0) {
                auto child = choiceLast;
                child.opacity *= choiceFade.value;
                for (auto& d : child.draw)
                    d.color.a *= choiceFade.value;
                paint.layers.push_back(std::move(child));
            } else {
                choiceStored = false;
                choiceVisualKey.clear();
                choiceBox = {};
            }
        }
        if (const auto* colored = Find(cfg, colorID)) {
            PrepareColor(cfg, *colored);
            picker.languages = languages;
            picker.SetMetrics(fonts, s);
            Box box = place(fieldAnchor.x + fieldAnchor.w + 4 * s, fieldAnchor.y, 265 * s, picker.Height(s));
            int zz = layer(box);
            picker.Draw(paint, zz, fonts, scratch, box);
            picker.DrawMenus(paint, fonts, scratch, width, height);
        }

        if (hadHeld) {
            held = -1;
            for (std::size_t i = 0; i < hits.size(); ++i)
                if (hits[i].action == pressedHit.action && hits[i].id == pressedHit.id &&
                    hits[i].option == pressedHit.option) {
                    held = int(i);
                    break;
                }
        }
        if (b) {
            auto it = entryReveal.find(b->id);
            if (it != entryReveal.end())
                for (std::size_t i = 1; i < paint.layers.size(); ++i) {
                    paint.layers[i].opacity *= it->second.value;
                    for (auto& d : paint.layers[i].draw)
                        d.color.a *= it->second.value;
                }
        }
        for (auto& l : paint.layers) {
            l.opacity *= fade.value;
            for (auto& d : l.draw)
                d.color.a *= fade.value;
        }
    }
    void MeasureHUD(Fonts& fonts, const Settings& cfg, int width, int height, bool menuVisible) {
        hotkeyWindow.Measure(
            hudPaint, fonts, cfg, runtime, width, height, menuVisible,
            [&](const std::string& key) { return Label(key); },
            [&](const MenuKeybind& bind) {
                auto t = FindKeybindTarget(bind.target);
                return t.kind == WorldKind::Multi && bind.value[0] == 0 ? std::u32string{} : ValueLabel(bind);
            });
        spectatorsWindow.Measure(hudPaint, fonts, cfg, width, height, menuVisible,
                                 [&](const std::string& key) { return Label(key); });
    }

private:
    HudColorPicker picker;
    Settings scratch;
    Box dragControl{};
    static void Rect(PresetsUI& ui, int z, Box box, Color c, float radius = 0, float stroke = 0) {
        if (box.w <= 0 || box.h <= 0)
            return;
        PresetDraw d{box, c, radius, stroke, 15, {}, false};
        d.clipped = true;
        d.clip = ui.layers[std::size_t(z)].box;
        ui.layers[std::size_t(z)].draw.push_back(std::move(d));
    }
    void Text(PresetsUI& ui, int z, Box box, std::u32string text, Color c, int font = 0, float px = 13) {
        if (box.w <= 0 || box.h <= 0)
            return;
        PresetDraw d{box, c, 0, 0, 15, std::move(text), font == 3};
        d.font = font;
        d.textSize = px;
        d.box.y += std::max(
            0.f,
            (box.h - (metrics ? metrics->PixelHeight(font == 3 ? 0 : font, px * scale) : px * scale)) * .5f);
        d.clipped = true;
        d.clip = PresetIntersect(box, ui.layers[std::size_t(z)].box);
        ui.layers[std::size_t(z)].draw.push_back(std::move(d));
    }
};
}