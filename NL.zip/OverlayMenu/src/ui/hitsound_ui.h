#pragma once

#include "world_tooltip.h"
#include "group_row_geometry.h"
namespace menu {
struct HitSoundUI {
    PresetsUI paint;
    LanguageCatalog* languages = nullptr;
    Box card{}, row{}, devRow{}, more{}, popupBox{}, body{}, volumeBox{}, volumeGroup{}, scrollTrack{},
        thumb{};
    std::array<Box, 3> actions{};
    std::array<Box, 10> rows{};
    std::array<std::array<Box, 5>, 10> icons{};
    std::array<Box, 5> bars{}, sliderRows{};
    bool visible = false, blocked = false, popup = false, volume = false, held = false, scrollDrag = false;
    int press = -1, drag = -1, hover = -1, pendingPreview = -1;
    bool pendingOpenFolder = false;
    float scale = 1, scroll = 0, maxScroll = 0, mx = -1, my = -1, hoverTime = 0, scrollGrab = 0;
    PresetMotion fade, volumeFade, tooltipMotion, scrollHover, masterHover, masterCheck, devHover, devCheck,
        moreHover;
    std::array<PresetMotion, 10> rowHover{}, rowOutline{};
    std::array<PresetMotion, 3> actionHover{};
    std::array<PresetMotion, 5> sliderTip{};
    std::array<std::array<PresetMotion, 5>, 10> iconHover{};

    struct Marquee {
        float offset = 0, hoverTime = 0, overflow = 0, fullWidth = 0;
        int stableFrames = 0;
        bool hovered = false;
        std::u32string label;
        PresetMotion returning;
    };
    std::array<Marquee, 5> volumeMarquee{};
    std::array<PresetMotion, 5> volumeRowHover{};
    PresetLayer lastPopup{}, lastVolume{}, lastTooltip{};
    bool hasLastPopup = false, hasLastVolume = false, hasLastTooltip = false;
    static constexpr const char* sounds[10] = {"default",   "switch",    "killcard",   "bodydamage",
                                               "bodybreak", "woodplank", "coinpickup", "rankneutral",
                                               "press",     "levelup"};
    static constexpr const char* types[5] = {"headshot", "bodyshot", "lethalshot", "damagereceived",
                                             "missedaimbotshot"};
    static constexpr char32_t glyph[5] = {0xf6e9, 0xf007, 0xf54c, 0xe37a, 0xf06a};
    std::u32string Label(const std::string& k) const {
        if (languages)
            return languages->Label(k);
        const auto& m = DefaultLanguageStrings();
        auto it = m.find(k);
        return DecodeUTF8(it == m.end() ? k : it->second);
    }
    std::string SoundKey(int n) const {
        return std::string("miscellaneous_features_hitsound_sound_") + sounds[n];
    }
    std::string TypeKey(int n) const {
        return std::string("miscellaneous_features_hitsound_") + types[n];
    }
    bool Active() const {
        return visible && !blocked && popup;
    }
    bool Capturing() const {
        return held || drag >= 0 || scrollDrag;
    }
    void CancelInput() {
        held = false;
        press = drag = -1;
        scrollDrag = false;
    }
    int Hit(float x, float y) const {
        if (!visible || blocked)
            return -1;
        if (!popup) {
            if (more.Contains(x, y))
                return 5;
            return row.Contains(x, y) ? 1 : -1;
        }
        if (volume && volumeBox.Contains(x, y)) {
            for (int i = 0; i < 5; ++i) {
                Box target{bars[i].x, sliderRows[i].y, bars[i].w, sliderRows[i].h};
                if (target.Contains(x, y))
                    return 300 + i;
                if (sliderRows[i].Contains(x, y))
                    return 400 + i;
            }
            return 4;
        }
        for (int i = 0; i < 3; ++i)
            if (actions[i].Contains(x, y))
                return 10 + i;
        if (maxScroll > 0) {
            Box target{scrollTrack.x - 4 * scale, scrollTrack.y, scrollTrack.w + 8 * scale, scrollTrack.h};
            if (target.Contains(x, y))
                return y >= thumb.y && y <= thumb.y + thumb.h ? 31 : 30;
        }
        if (body.Contains(x, y))
            for (int i = 0; i < 10; ++i) {
                for (int j = 0; j < 5; ++j)
                    if (icons[i][j].Contains(x, y))
                        return 100 + i * 5 + j;
                if (rows[i].Contains(x, y))
                    return 200 + i;
            }
        return popupBox.Contains(x, y) ? 2 : 3;
    }
    void Move(float x, float y, Settings& c) {
        mx = x;
        my = y;
        int n = Hit(x, y);
        if (n != hover) {
            hover = n;
            hoverTime = 0;
        }
        if (drag >= 0 && drag < 5) {
            auto b = bars[drag];
            if (b.w > 0)
                c.hitSoundVolume[drag] = int(std::lround(std::clamp((x - b.x) / b.w, 0.f, 1.f) * 300));
        }
        if (scrollDrag && scrollTrack.h > thumb.h)
            scroll = std::clamp((y - scrollGrab - scrollTrack.y) / (scrollTrack.h - thumb.h), 0.f, 1.f) *
                     maxScroll;
    }
    void Tick(float dt, const Settings& c) {
        if (!visible)
            return;
        dt = std::max(0.f, dt);
        hoverTime += dt;
        masterHover.Tick(!popup && (hover == 1 || hover == 5) ? .5f : 0.f, dt);
        moreHover.Tick(popup ? 1.f : (!blocked && hover == 5 ? (held && press == 5 ? 1.f : .5f) : 0.f), dt);
        masterCheck.Tick(c.hitSoundEnabled ? 1.f : 0.f, dt);
        devHover.Tick(!popup && hover == 6 ? .5f : 0.f, dt);
        devCheck.Tick(c.devHistorySkeleton ? 1.f : 0.f, dt);
        fade.Tick(popup ? 1.f : 0.f, dt);
        volumeFade.Tick(popup && volume ? 1.f : 0.f, dt);
        bool tip = popup && hoverTime >= .3f &&
                   ((hover >= 100 && hover < 150) || (hover >= 10 && hover <= 12)) && drag < 0 && !scrollDrag;
        tooltipMotion.Tick(tip ? 1.f : 0.f, dt);
        scrollHover.Tick(scrollDrag ? 1.f : (hover == 30 || hover == 31) ? .8f : 0.f, dt);
        for (int i = 0; i < 3; ++i)
            actionHover[i].Tick(held && press == 10 + i ? 1.f : hover == 10 + i ? .5f : 0.f, dt);
        for (int i = 0; i < 10; ++i) {
            bool h = hover == 200 + i || (hover >= 100 && hover < 150 && (hover - 100) / 5 == i);
            bool selected = false;
            for (int j = 0; j < 5; ++j)
                selected |= c.hitSoundForType[j] == i;
            bool down = held && press == 200 + i;
            rowHover[i].Tick((selected || h) ? .5f : 0.f, dt);
            rowOutline[i].Tick(selected || down ? 1.f : h ? .5f : 0.f, dt);
            for (int j = 0; j < 5; ++j) {
                iconHover[i][j].Tick(held && press == 100 + i * 5 + j ? 1.f
                                     : hover == 100 + i * 5 + j       ? .5f
                                                                      : 0.f,
                                     dt);
            }
        }
        for (int i = 0; i < 5; ++i) {
            bool over = popup && volume && volumeBox.Contains(mx, my) && sliderRows[i].Contains(mx, my);
            volumeRowHover[i].Tick(drag == i ? 1.f : over ? .5f : 0.f, dt);
            sliderTip[i].Tick(popup && volume && (drag == i || bars[i].Contains(mx, my)) ? 1.f : 0.f, dt);
            auto& m = volumeMarquee[i];
            bool move = over && m.overflow > 0;
            if (move) {
                m.hoverTime = m.hovered ? m.hoverTime + dt : 0.f;
                if (m.stableFrames >= 5 && m.hoverTime > .3f) {
                    m.offset += 40 * scale * dt;
                    if (m.offset >= m.fullWidth + 20 * scale)
                        m.offset = m.overflow;
                }
                m.returning.Snap(m.offset);
            } else {
                m.hoverTime = 0;
                m.returning.Tick(0, dt, .25f);
                m.offset = m.returning.value;
            }
            m.hovered = move;
        }
    }
    bool Click(float x, float y, bool down, Settings& c) {
        if (!visible || blocked) {
            CancelInput();
            return false;
        }
        Move(x, y, c);
        int h = Hit(x, y);
        if (down) {
            if (h < 0)
                return false;
            press = h;
            held = true;
            if (h >= 300 && h < 305) {
                drag = h - 300;
                Move(x, y, c);
            } else if (h == 31) {
                scrollDrag = true;
                scrollGrab = y - thumb.y;
            } else if (h == 30) {
                scrollGrab = thumb.h * .5f;
                scrollDrag = true;
                Move(x, y, c);
            }
            return true;
        }
        bool used = held;
        int p = press;
        held = false;
        press = -1;
        if (drag >= 0) {
            Move(x, y, c);
            drag = -1;
            return true;
        }
        if (scrollDrag) {
            Move(x, y, c);
            scrollDrag = false;
            return true;
        }
        if (!used)
            return false;
        if (h != p)
            return true;
        if (h == 1) {
            c.hitSoundEnabled = !c.hitSoundEnabled;

        } else if (h == 5) {
            popup = true;
            volume = false;
            scroll = 0;
            fade.Snap(0);
        } else if (h == 3) {
            volume = false;
            popup = false;
        } else if (h == 10) {
            volume = !volume;
            if (volume)
                volumeFade.Snap(0);
        } else if (h >= 100 && h < 150) {
            int k = h - 100;
            auto& selected = c.hitSoundForType[k % 5];
            selected = selected == k / 5 ? -1 : k / 5;
        } else if (h >= 200 && h < 210)
            pendingPreview = h - 200;
        else if (h == 12)
            pendingOpenFolder = true;
        return true;
    }
    bool Key(int k, Settings&) {
        if (!Active())
            return false;
        if (k == 27) {
            if (volume)
                volume = false;
            else
                popup = false;
            CancelInput();
        }
        return true;
    }
    bool Wheel(float steps, Settings&) {
        if (!Active())
            return false;
        if (!volumeBox.Contains(mx, my) || !volume) {
            scroll = std::clamp(scroll - steps * 44 * scale, 0.f, maxScroll);
            hover = -1;
            hoverTime = 0;
        }
        return true;
    }
    void Measure(Fonts& f, const Settings& c, const Layout& l, Box header, int width, int height, bool shown,
                 bool modal) {
        visible = shown;
        blocked = modal;
        scale = c.scale;
        paint.layers.clear();
        card = row = devRow = more = popupBox = body = volumeBox = volumeGroup = scrollTrack = thumb = {};
        actions.fill({});
        rows.fill({});
        bars.fill({});
        sliderRows.fill({});
        for (auto& r : icons)
            r.fill({});
        if (!shown || modal) {
            popup = volume = false;
            CancelInput();
            hover = -1;
            hoverTime = 0;
            hasLastPopup = hasLastVolume = hasLastTooltip = false;
            fade.Snap(0);
            volumeFade.Snap(0);
            tooltipMotion.Snap(0);
            if (!shown)
                return;
        }
        float s = scale, F = f.PixelHeight(0, 13 * s), hf = f.PixelHeight(0, 10 * s),
              top = header.y + header.h + 15 * s, H = F + 6 * s;
        float x = l.content.x + 15 * s, w = GroupTwoColumnWidth(l.content, s);
        if (GroupTwoColumnFits(l.content, s))
            x += w + 15 * s;
        else
            top += hf + 5 * s + GroupCardHeight(1, F, s) + 20 * s;
        card = {x, top + hf + 5 * s, w, GroupCardHeight(1, F, s)};
        row = {x + 14 * s, card.y + 7 * s, std::max(0.f, w - 28 * s), H};
        more = {row.x + row.w - 60 * s, row.y, 22 * s, row.h};
        if (w <= 0 || card.y >= height)
            return;
        auto pal = CurrentPalette(c);
        paint.layers.push_back({l.content, 0, false, {}});
        auto rect = [&](int z, Box b, Color col, float radius = 0, float stroke = 0, Box clip = Box{}) {
            if (b.w <= 0 || b.h <= 0 || col.a <= 0)
                return;
            PresetDraw d{b, col, radius, stroke, 15, {}, false};
            d.clipped = true;
            d.clip = clip.w > 0 ? PresetIntersect(paint.layers[z].box, clip) : paint.layers[z].box;
            paint.layers[z].draw.push_back(std::move(d));
        };
        auto text = [&](int z, Box b, std::u32string t, Color col, int font = 0, float px = 13,
                        Box clip = Box{}) {
            if (b.w <= 0 || b.h <= 0 || t.empty())
                return;
            PresetDraw d{b, col, 0, 0, 15, std::move(t), font == 3};
            d.font = font;
            d.textSize = px;
            d.clipped = true;
            d.clip = clip.w > 0 ? PresetIntersect(paint.layers[z].box, clip) : paint.layers[z].box;
            paint.layers[z].draw.push_back(std::move(d));
        };
        auto alpha = [](Color v, float a) {
            v.a *= a;
            return v;
        };
        auto faded = [&](int z, float a) {
            paint.layers[z].opacity *= a;
            for (auto& d : paint.layers[z].draw) {
                d.color.a *= a;
                d.shadowColor.a *= a;
                d.backdropOpacity *= a;
            }
        };
        auto title = Label("group_miscellaneous_features");
        for (auto& q : title)
            if (q >= U'a' && q <= U'z')
                q -= 32;
            else if (q >= 0x430 && q <= 0x44f)
                q -= 32;
            else if (q == 0x451)
                q = 0x401;
        text(0, {x + 14 * s, top, w - 28 * s, hf}, title, pal[3], 0, 10);
        rect(0, card, pal[40], 15 * s);
        rect(0, card, pal[11], 15 * s, s);
        rect(0, GroupRowHoverBounds(row, s), alpha(pal[33], .15f * masterHover.value), 15 * s);
        float v = masterCheck.initialized ? masterCheck.value : float(c.hitSoundEnabled);
        float center = row.y + row.h * .5f, hh = F + 2 * s;
        Box ctl{row.x + row.w - 32 * s, center - hh * .5f, 32 * s, hh};
        rect(0, ctl, pal[22], hh * .5f);
        rect(0, ctl, alpha(pal[23], v), hh * .5f);
        float rad = hh * .5f - 2 * s, cx = ctl.x + hh * .5f + (ctl.w - hh) * v;
        rect(0, {cx - rad, center - rad, 2 * rad, 2 * rad}, Mix(pal[20], pal[21], v), rad);
        text(0, {row.x, row.y + (H - F) * .5f, std::max(0.f, more.x - row.x - 6 * s), F},
             Label("miscellaneous_features_hitsound"), pal[0]);
        float dot = f.NativeTextSize(3, 13 * s, U"\uf141").w;
        rect(0, more, alpha(pal[33], .4f * moreHover.value), 15 * s / 1.6f);
        text(0, {more.x + (more.w - dot) * .5f, more.y + (H - F) * .5f, dot, F}, U"\uf141",
             Mix(pal[0], pal[2], moreHover.value), 3);

        if (!popup) {
            if (hasLastPopup && fade.value > .001f) {
                auto last = lastPopup;
                last.opacity *= fade.value;
                for (auto& d : last.draw)
                    d.color.a *= fade.value;
                paint.layers.push_back(std::move(last));
            }
            return;
        }
        float pw = std::min(285 * s, std::max(1.f, float(width) - 12 * s)),
              ph = std::min(404 * s, std::max(1.f, float(height) - 12 * s));
        popupBox = PresetPopupFit({more.x + more.w + 7 * s, row.y, pw, ph}, width, height);
        float titleH = 41 * s;
        body = {popupBox.x + 9 * s, popupBox.y + titleH, popupBox.w - 18 * s, popupBox.h - titleH - 8 * s};
        int z = int(paint.layers.size());
        paint.layers.push_back({popupBox, 15 * s, true, {}});
        rect(z, popupBox, pal[8], 15 * s);
        rect(z, popupBox, pal[11], 15 * s, s);
        text(z, {popupBox.x + 15 * s, popupBox.y + 10 * s, popupBox.w - 110 * s, F},
             Label("miscellaneous_features_hitsound"), pal[2], 2);

        constexpr char32_t toolbar[3] = {0xf8c9, 0xf021, 0xf07c};
        float actionH = F + 6 * s, actionW = 1.2f * actionH;
        for (int i = 0; i < 3; ++i) {
            Box b{popupBox.x + popupBox.w - 7 * s - (3 - i) * actionW, popupBox.y + (titleH - actionH) * .5f,
                  actionW, actionH};
            actions[i] = b;
            rect(z, b, alpha(pal[33], .4f * actionHover[i].value), 6 * s);
            Color ink = pal[30];
            ink.a *= .7f + .3f * actionHover[i].value;
            auto g = std::u32string(1, toolbar[i]);
            float gw = f.NativeTextSize(3, 13 * s, g).w;
            text(z, {b.x + std::trunc((b.w - gw) * .5f), b.y + (b.h - F) * .5f, std::max(1.f, gw + 2 * s), F},
                 g, ink, 3);
        }

        rect(z, body, alpha(pal[40], .28f), 9 * s);
        rect(z, body, pal[11], 9 * s, s);

        float rh = F + 21 * s, pitch = rh + 5 * s, total = 10 * pitch - 5 * s + 14 * s;
        maxScroll = std::max(0.f, total - body.h);
        scroll = std::clamp(scroll, 0.f, maxScroll);
        for (int i = 0; i < 10; ++i) {
            Box r{body.x + 7 * s, body.y + 7 * s + i * pitch - scroll,
                  std::max(0.f, std::min(235 * s, body.w - 27 * s)), rh};
            rows[i] = PresetIntersect(r, body);
            if (rows[i].h <= 0)
                continue;

            float rr = std::trunc(15 * s * .5f);
            Color accentBorder = alpha(pal[31], .4f);
            rect(z, r, pal[40], rr, 0, body);
            rect(z, r, Mix(pal[11], accentBorder, rowOutline[i].value), rr, s, body);
            rect(z, r, alpha(pal[33], .2f * rowHover[i].value), rr, 0, body);
            text(z, {r.x + 12 * s, r.y + (rh - F) * .5f, std::max(1.f, r.w - 29 * s - 5 * (F + 6 * s)), F},
                 Label(SoundKey(i)), pal[0], 0, 13, body);

            const float bw = F + 6 * s, bh = F + 3 * s;
            for (int j = 0; j < 5; ++j) {
                Box b{r.x + r.w - 12 * s - (5 - j) * bw, r.y + (rh - bh) * .5f, bw, bh};
                icons[i][j] = PresetIntersect(b, body);
                float motion = iconHover[i][j].value;
                rect(z, b, alpha(pal[33], .4f * motion), 6 * s, 0, body);
                Color color = c.hitSoundForType[j] == i ? pal[31] : pal[30];
                color.a *= .7f + .3f * motion;
                auto g = std::u32string(1, glyph[j]);
                float gw = f.NativeTextSize(3, 13 * s, g).w;
                text(
                    z,
                    {b.x + std::trunc((b.w - gw) * .5f), b.y + (b.h - F) * .5f, std::max(1.f, gw + 2 * s), F},
                    g, color, 3, 13, body);
            }
        }
        if (maxScroll > 0) {

            float right = body.x + body.w, pad = 8 * s, trackRight = right - pad;
            float trackLeft = std::max(body.x, right - 14 * s);
            float inset = std::min(10 * s, body.h * .5f);
            scrollTrack = {trackLeft, body.y + inset, std::max(0.f, trackRight - trackLeft),
                           std::max(0.f, body.h - 2 * inset)};

            float th =
                std::min(scrollTrack.h, std::max(10 * s, scrollTrack.h * body.h / (body.h + maxScroll)));
            thumb = {scrollTrack.x, scrollTrack.y + (scrollTrack.h - th) * scroll / maxScroll, scrollTrack.w,
                     th};
            rect(z, scrollTrack, pal[17], 3 * s);
            rect(z, thumb, Mix(pal[18], pal[19], scrollHover.value), 3 * s);
        }
        lastPopup = paint.layers[z];
        hasLastPopup = true;
        faded(z, fade.value);
        if (volume) {
            float vtitle = F + 18 * s, R = F + 14 * s, totalH = vtitle + 5 * R + 21 * s;
            float vw = std::min(std::trunc(265 * s), std::max(1.f, float(width) - 12 * s)),
                  vh = std::min(totalH, std::max(1.f, float(height) - 12 * s));
            float vx = actions[0].x + actions[0].w + 7 * s;
            if (vx + vw > width - 6 * s)
                vx = actions[0].x - vw - 7 * s;
            volumeBox = PresetPopupFit({vx, actions[0].y, vw, vh}, width, height);
            int vz = int(paint.layers.size());
            paint.layers.push_back({volumeBox, 15 * s, true, {}});
            rect(vz, volumeBox, pal[8], 15 * s);
            rect(vz, volumeBox, pal[11], 15 * s, s);
            text(vz, {volumeBox.x + 14 * s, volumeBox.y + 7 * s, volumeBox.w - 28 * s, F},
                 Label("miscellaneous_features_hitsound_volume"), pal[2], 2);
            volumeGroup = {volumeBox.x + 7 * s, volumeBox.y + vtitle, volumeBox.w - 14 * s,
                           volumeBox.h - vtitle - 7 * s};
            rect(vz, volumeGroup, pal[40], 15 * s);
            rect(vz, volumeGroup, pal[11], 15 * s, s);
            for (int i = 0; i < 5; ++i) {
                Box r{volumeGroup.x + 7 * s, volumeGroup.y + 7 * s + i * R, volumeGroup.w - 14 * s, R};
                sliderRows[i] = PresetIntersect(r, volumeGroup);
                float bw = std::trunc(r.w / 2.5f);
                Box b{r.x + r.w - 12 * s - bw, r.y + (r.h - 6 * s) * .5f, bw, 6 * s};
                bars[i] = PresetIntersect(b, volumeGroup);

                float hv = volumeRowHover[i].value;
                rect(vz, r, alpha(pal[33], .4f * hv), 15 * s / 1.6f, 0, volumeGroup);
                Box labelBox{r.x + 12 * s, r.y + 7 * s, std::max(0.f, b.x - r.x - 18 * s), F};
                auto label = Label(TypeKey(i));
                float full = f.NativeTextSize(0, 13 * s, label).w;
                auto& mq = volumeMarquee[i];
                float overflow = std::max(0.f, full - labelBox.w);
                if (mq.label != label || std::abs(mq.overflow - overflow) > .01f ||
                    std::abs(mq.fullWidth - full) > .01f) {
                    mq.offset = mq.hoverTime = 0;
                    mq.stableFrames = 0;
                    mq.hovered = false;
                    mq.returning.Snap(0);
                } else
                    mq.stableFrames = std::min(5, mq.stableFrames + 1);
                mq.label = label;
                mq.fullWidth = full;
                mq.overflow = overflow;
                Box textClip = PresetIntersect(volumeGroup, labelBox);
                if (textClip.w > 0) {
                    Color ink = Mix(pal[14], pal[2], hv);
                    text(vz, {labelBox.x - mq.offset, labelBox.y, full + s, F}, label, ink, 0, 13, textClip);
                    if (mq.offset > 0 && mq.offset >= overflow)
                        text(vz, {labelBox.x - mq.offset + full + 20 * s, labelBox.y, full + s, F}, label,
                             ink, 0, 13, textClip);
                }
                rect(vz, b, pal[24], 3 * s, 0, volumeGroup);
                Box clip = PresetIntersect(
                    volumeGroup, {b.x, b.y, b.w * std::clamp(c.hitSoundVolume[i] / 300.f, 0.f, 1.f), b.h});
                if (clip.w > 0)
                    rect(vz, b, pal[25], 3 * s, 0, clip);
            }
            lastVolume = paint.layers[vz];
            hasLastVolume = true;
            faded(vz, volumeFade.value);
        } else if (hasLastVolume && volumeFade.value > .001f) {
            auto last = lastVolume;
            last.opacity *= volumeFade.value;
            for (auto& d : last.draw)
                d.color.a *= volumeFade.value;
            paint.layers.push_back(std::move(last));
        }

        if (volume)
            for (int i = 0; i < 5; ++i) {
                auto b = bars[i];
                float a = sliderTip[i].value;
                if (b.w <= 0 || a <= .001f)
                    continue;
                auto value = DecodeUTF8(std::to_string(c.hitSoundVolume[i]) + "%");
                float tw = f.NativeTextSize(0, 13 * s, value).w,
                      t = std::clamp(c.hitSoundVolume[i] / 300.f, 0.f, 1.f);
                Box tip = PresetPopupFit(
                    {b.x + b.w * t - tw * .5f - 7 * s, b.y - F - 14 * s, tw + 14 * s, F + 9 * s}, width,
                    height);
                int tz = int(paint.layers.size());
                paint.layers.push_back({tip, 8 * s, true, {}});
                rect(tz, tip, pal[8], 8 * s);
                rect(tz, tip, pal[11], 8 * s, s);
                text(tz, {tip.x + 7 * s, tip.y + 4 * s, tw, F}, value, pal[0]);
                faded(tz, a);
            }
        if (hoverTime >= .3f && ((hover >= 100 && hover < 150) || (hover >= 10 && hover <= 12))) {
            std::u32string label;
            if (hover >= 100) {
                int k = hover - 100;
                label = Label(TypeKey(k % 5));
            } else {
                static constexpr const char* labels[3] = {"miscellaneous_features_hitsound_volume",
                                                          "miscellaneous_features_hitsound_refresh",
                                                          "miscellaneous_features_hitsound_openfolder"};
                label = Label(labels[hover - 10]);
            }
            Box target = hover >= 100 ? icons[(hover - 100) / 5][(hover - 100) % 5] : actions[hover - 10];
            lastTooltip = WorldNameTooltip(f, c, target, label, width, height);
            hasLastTooltip = true;
        }
        if (hasLastTooltip && tooltipMotion.value > .001f)
            AppendWorldTooltip(paint, lastTooltip, tooltipMotion.value);
    }
};
}
