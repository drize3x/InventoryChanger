#pragma once

struct PlayersSpec {
    const char* id;
    const char* key;
    WorldKind kind;
    float minimum, maximum, initial;
    int parent, group, color;
};
inline constexpr std::array<PlayersSpec, 24> PlayersSpecs{{
    {"enemy_enabled", "enabled", WorldKind::Check, 0.0f, 1.0f, 0.0f, -1, 0, -1},
    {"arrow", "visuals_enemies_options_offscreenarrow", WorldKind::Check, 0.0f, 1.0f, 0.0f, -1, 0, 0},
    {"arrow_size", "visuals_enemies_options_offscreenarrow_size", WorldKind::Integer, 5.0f, 20.0f, 10.0f, 1,
     0, -1},
    {"arrow_radius", "visuals_enemies_options_offscreenarrow_radius", WorldKind::Integer, 1.0f, 100.0f, 55.0f,
     1, 0, -1},
    {"sounds", "visuals_enemies_options_sounds", WorldKind::Check, 0.0f, 1.0f, 0.0f, -1, 0, 1},
    {"enemy_player", "visuals_enemies_model_player", WorldKind::Choice, 0.0f, 7.0f, 0.0f, -1, 1, 2},
    {"enemy_hidden", "visuals_enemies_model_playerbehindwalls", WorldKind::Choice, 0.0f, 7.0f, 0.0f, -1, 1,
     3},
    {"onshot", "visuals_enemies_model_onshot", WorldKind::Choice, 0.0f, 7.0f, 0.0f, -1, 1, 4},
    {"onshot_glow", "visuals_enemies_model_onshot_glow", WorldKind::Check, 0.0f, 1.0f, 0.0f, 7, 1, 5},
    {"onshot_duration", "visuals_common_duration", WorldKind::Decimal, 0.5f, 5.0f, 1.5f, 7, 1, -1},
    {"history", "visuals_enemies_model_history", WorldKind::Choice, 0.0f, 7.0f, 0.0f, -1, 1, 6},
    {"history_glow", "visuals_enemies_model_history_glow", WorldKind::Check, 0.0f, 1.0f, 0.0f, 10, 1, 7},
    {"ragdolls", "visuals_enemies_model_ragdolls", WorldKind::Choice, 0.0f, 7.0f, 0.0f, -1, 1, 8},
    {"ragdoll_glow", "visuals_enemies_model_ragdolls_glow", WorldKind::Check, 0.0f, 1.0f, 0.0f, 12, 1, 9},
    {"ragdoll_visibility", "visuals_enemies_model_ragdolls_visibility", WorldKind::Multi, 0.0f, 3.0f, 1.0f,
     12, 1, -1},
    {"kill_effect", "visuals_enemies_model_kill_effect", WorldKind::Check, 0.0f, 1.0f, 0.0f, -1, 1, 14},
    {"kill_spread", "visuals_enemies_model_kill_effect_spread", WorldKind::Integer, 0.0f, 100.0f, 5.0f, 15, 1,
     -1},
    {"kill_speed", "visuals_enemies_model_kill_effect_speed", WorldKind::Integer, 0.0f, 200.0f, 25.0f, 15, 1,
     -1},
    {"enemy_glow", "visuals_enemies_model_glow", WorldKind::Check, 0.0f, 1.0f, 0.0f, -1, 1, 10},
    {"team_enabled", "enabled", WorldKind::Check, 0.0f, 1.0f, 0.0f, -1, 2, -1},
    {"team_player", "visuals_teammate_model_player", WorldKind::Choice, 0.0f, 7.0f, 0.0f, -1, 3, 11},
    {"team_hidden", "visuals_teammate_model_playerbehindwalls", WorldKind::Choice, 0.0f, 7.0f, 0.0f, -1, 3,
     12},
    {"disable_team", "visuals_teammate_model_disablemodelrendering", WorldKind::Check, 0.0f, 1.0f, 0.0f, -1,
     3, -1},
    {"team_glow", "visuals_teammate_model_glow", WorldKind::Check, 0.0f, 1.0f, 0.0f, -1, 3, 13},
}};
inline constexpr std::array<const char*, 8> PlayersMaterialKeys{
    {"visuals_chams_disabled", "visuals_chams_shaded", "visuals_chams_solid", "visuals_chams_glow",
     "visuals_chams_glowoutline", "visuals_chams_iridescent", "visuals_chams_waterflow",
     "visuals_chams_glossy"}};
inline std::vector<std::string> PlayersOptions(int i) {
    if (i == 14)
        return {"visuals_enemies_model_ragdolls_visibility_visible",
                "visuals_enemies_model_ragdolls_visibility_behindwalls"};
    if (i >= 0 && i < int(PlayersSpecs.size()) && PlayersSpecs[std::size_t(i)].kind == WorldKind::Choice)
        return {PlayersMaterialKeys.begin(), PlayersMaterialKeys.end()};
    return {};
}
#include "players_esp_model.h"
#include "players_esp_layout.h"
struct PlayersValues {
    std::array<PlayersESPLayout, 2> espLayout{};
    std::array<std::array<bool, PlayersESPItems.size()>, 2> espEnabled{};
    std::array<std::array<ESPItemValues, PlayersESPItems.size()>, 2> espSettings{};
    bool universalScaling = true;
    std::array<float, PlayersSpecs.size()> value{};
    std::array<Color, 15> colors{{
        {1.0f, 1.0f, 1.0f, 1.0f},
        {1.0f, 0.3529411852359772f, 0.5882353186607361f, 1.0f},
        {0.5882353186607361f, 0.686274528503418f, 1.0f, 1.0f},
        {0.3921568989753723f, 1.0f, 1.0f, 1.0f},
        {0.45098042488098145f, 1.0f, 0.7647059559822083f, 0.09803922474384308f},
        {0.2549019753932953f, 0.6666666865348816f, 0.5098039507865906f, 0.19607844948768616f},
        {0.1568627506494522f, 0.1568627506494522f, 0.1568627506494522f, 0.19607844948768616f},
        {0.1568627506494522f, 0.19607844948768616f, 0.27450981736183167f, 1.0f},
        {0.43137258291244507f, 0.43137258291244507f, 0.5882353186607361f, 0.7058823704719543f},
        {0.0784313753247261f, 0.09803922474384308f, 0.13725490868091583f, 1.0f},
        {0.6078431606292725f, 0.529411792755127f, 1.0f, 0.3137255012989044f},
        {0.8431373238563538f, 0.8627451658248901f, 1.0f, 1.0f},
        {1.0f, 0.8431373238563538f, 0.7254902124404907f, 1.0f},
        {0.37254902720451355f, 0.37254902720451355f, 0.37254902720451355f, 0.3921568989753723f},
        {1.f, 0.21568629145622253f, 0.29411765933036804f, 1.f},
    }};
    PlayersValues() {
        for (auto& team : espSettings)
            for (std::size_t i = 0; i < team.size(); ++i)
                team[i] = ESPInitial(int(i));
        for (std::size_t i = 0; i < value.size(); ++i)
            value[i] = PlayersSpecs[i].initial;
    }
    void Set(std::size_t i, float v) {
        if (i >= value.size() || !std::isfinite(v))
            return;
        const auto& d = PlayersSpecs[i];
        v = std::clamp(v, d.minimum, d.maximum);
        value[i] = d.kind == WorldKind::Decimal ? std::round(v * 100) / 100 : std::round(v);
    }
};
