#include "keybind_ui.h"
#include <cassert>
#include <iostream>
using namespace menu;
int main(int argc,char** argv) {
    assert(argc>1);
    Fonts fonts(argv[1]);
    Settings cfg;
    KeybindUI ui;
    auto measure=[&]{ui.Measure(fonts,cfg,1100,800,false);};
    auto click=[&](int action){
        KeybindUI::Hit hit{};bool found=false;
        for(const auto& h:ui.hits)if(h.action==action){hit=h;found=true;break;}
        assert(found && !hit.disabled);
        const float x=hit.box.x+hit.box.w*.5f,y=hit.box.y+hit.box.h*.5f;
        ui.Click(x,y,true,cfg);ui.Click(x,y,false,cfg);
    };
    ui.Open("view.view_fov",400,200);ui.Tick(1);measure();
    assert(ui.hits.size()==3); // New, Copy path, Reset; no aggregate-table entry.
    const float H=fonts.PixelHeight(0,13)+14;
    assert(std::abs(ui.popup.h-(14+3*H+7))<.001f);
    click(KeybindUI::New);assert(cfg.keybinds.size()==1);
    ui.Tick(1);measure();
    click(KeybindUI::Capture);assert(ui.CapturingKey());
    ui.Assign(cfg,'K');assert(cfg.keybinds[0].key=='K');measure();
    const bool original=cfg.keybinds[0].value[0]!=0;
    click(KeybindUI::Boolean);assert((cfg.keybinds[0].value[0]!=0)!=original);
    const bool shown=cfg.keybinds[0].shown;
    click(KeybindUI::Shown);assert(cfg.keybinds[0].shown!=shown);
    click(KeybindUI::Delete);assert(cfg.keybinds.empty());
    ui.Close();assert(!ui.Active());
    // Numeric editing still enters only on Ctrl-click (ordinary drag is retained).
    ui.Open("view.view_fov_value",400,200);measure();click(KeybindUI::New);
    ui.Tick(1);measure();assert(!ui.sliderTracks.empty());
    ui.Close();
    std::cout<<"Keybind context tests PASS\n";
}
