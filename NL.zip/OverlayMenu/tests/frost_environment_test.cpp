#include "../src/inventory/inventory_frost_environment.h"
#include <cassert>
#include <cmath>
#include <limits>

int main() {
    using namespace menu::inventory_frost;
    const float pos[3] = {0.f, 0.f, 0.f};
    Environment inside;
    assert(inside.Step(false, pos, 100));
    assert(inside.level == 0.f);
    Environment env;
    assert(env.Step(true, pos, 100));
    assert(env.level == 1.f);
    for (std::uint64_t t = 200; t <= 10200; t += 100)
        assert(env.Step(false, pos, t));
    assert(env.level < 0.001f); // Standing still under cover still fades.
    for (std::uint64_t t = 10300; t <= 20400; t += 100)
        assert(env.Step(true, pos, t));
    assert(env.level > 0.999f);
    assert(FreshLevel(0.7f, 1000, 2000) == 0.7f);
    assert(FreshLevel(0.7f, 1000, 2001) == 0.f);
    assert(FreshLevel(0.7f, 0, 100) == 0.f);
    assert(FreshLevel(0.7f, 1000, 999) == 0.f);
    assert(FreshLevel(std::numeric_limits<float>::quiet_NaN(), 1000, 1001) == 0.f);
}
