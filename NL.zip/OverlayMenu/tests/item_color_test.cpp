#include "menu_core.h"
#include "inventory_knife_plan.h"
#include "inventory_glove_plan.h"
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <map>

using namespace menu;
struct Gloves : glove_inmatch::Adapter {
    int refreshes = 0;
    bool Read(std::uintptr_t p, void* v, std::size_t n) override { std::memcpy(v, (void*)p, n); return true; }
    bool Write(std::uintptr_t p, const void* v, std::size_t n) override { std::memcpy((void*)p, v, n); return true; }
    std::uintptr_t Allocate(std::size_t n) override { return reinterpret_cast<std::uintptr_t>(std::malloc(n)); }
    bool Release(std::uintptr_t p) override { std::free((void*)p); return true; }
    bool Ready(std::uintptr_t, std::uintptr_t) override { return true; }
    bool Refresh(std::uintptr_t, std::uintptr_t) override { ++refreshes; return true; }
};
struct Knives : knife_experiment::Adapter {
    std::map<unsigned, std::uintptr_t> entities;
    inventory_color::Palette seen{}; int skinCalls = 0, restores = 0, rebuilds = 0, colorRefreshes = 0;
    bool refreshOk = true;
    bool Read(std::uintptr_t p, void* v, std::size_t n) override { std::memcpy(v, (void*)p, n); return true; }
    bool Write(std::uintptr_t p, const void* v, std::size_t n) override { std::memcpy((void*)p, v, n); return true; }
    std::uintptr_t Entity(std::uint32_t h) override { return entities[h]; }
    bool Rebuild(std::uintptr_t, const std::string&) override { ++rebuilds; return true; }
    bool Subclass(std::uintptr_t) override { return true; }
    void SetPaintPalette(const inventory_color::Palette& p, int, int) override { seen = p; }
    bool RefreshPaintPalette(std::uintptr_t, std::uintptr_t) override { ++colorRefreshes; return refreshOk; }
    int Skin(std::uintptr_t, std::uintptr_t, const InventoryWeaponTarget&) override { ++skinCalls; return 0; }
    bool RestoreSkin(std::uintptr_t, std::uintptr_t) override { ++restores; return true; }
};
template<class T> void put(std::uintptr_t p, T value) { std::memcpy((void*)p, &value, sizeof(value)); }
int main() {
    InventoryCatalog catalog;
    InventoryPaint paint; paint.id = 321; catalog.paints.push_back(paint); catalog.paintById[321] = 0;
    InventoryDefinition def; def.index = 500; def.model = "weapons/models/knife_bayonet.vmdl"; catalog.definitions[500] = def;
    def.index = 42; def.model = "weapons/models/knife_default.vmdl"; catalog.definitions[42] = def;
    InventoryValues cfg;
    cfg.teams[0].knife = 500; cfg.teams[0].gloves = 5030;
    auto& knife = cfg.teams[0].Edit(500); knife.paintKit = 321; knife.paintColorMask = 1; knife.paintColors[0] = {1, 0, 0, 1};
    auto& glove = cfg.teams[0].Edit(5030); glove.paintKit = 321; glove.paintColorMask = 2; glove.paintColors[1] = {0, 1, 0, 1};
    auto kp = knife_experiment::MakePlan(catalog, cfg);
    auto gp = glove_inmatch::MakePlan(catalog, cfg);
    assert(kp.side[0].palette.mask == 1 && kp.side[0].palette.rgba[0] == 0xff0000ffu);
    assert(gp.side[0].palette.mask == 2 && gp.side[0].palette.rgba[1] == 0xff00ff00u);
    assert(kp.side[1].palette.mask == 0 && gp.side[1].palette.mask == 0);

    alignas(16) unsigned char pawn[1024]{}, controller[64]{}, service[64]{}, entity[1024]{};
    auto pa = reinterpret_cast<std::uintptr_t>(pawn), co = reinterpret_cast<std::uintptr_t>(controller);
    auto sv = reinterpret_cast<std::uintptr_t>(service), en = reinterpret_cast<std::uintptr_t>(entity);
    glove_inmatch::Offsets go{}; go.view=0x100; go.reapply=0x20; go.definition=0x10; go.quality=0x18;
    go.initialized=0x20; go.list=0x30; go.attributes=0x10;
    Gloves gm; glove_inmatch::Controller gc;
    // A palette-only knife refresh preserves the owned attribute allocation.
    alignas(16) unsigned char testObject[256]{};
    auto testBase = reinterpret_cast<std::uintptr_t>(testObject);
    knife_skin::Controller skin; InventoryWeaponTarget target; target.paintKit = 321;
    assert(skin.Apply(gm, testBase, testBase, 0x40, 0x10, target) == 0);
    knife_skin::Vector before{}; assert(gm.Get(testBase + 0x50, before));
    assert(skin.RefreshOwned(gm, testBase, testBase));
    knife_skin::Vector after{}; assert(gm.Get(testBase + 0x50, after));
    assert(before.data == after.data && before.count == after.count);
    assert(!skin.RefreshOwned(gm, testBase + 1, testBase));
    assert(skin.Restore(gm, testBase, testBase));
    gc.Tick(gm, go, 1, pa, 0, gp, true, 100);
    assert(gc.Holding() && std::strcmp(gc.Stage(), "applied") == 0);
    // Finish startup refresh burst before testing palette-only edits.
    for (int i = 1; i < 5; ++i) gc.Tick(gm, go, 1, pa, 0, gp, true, 100 + i);
    int r = gm.refreshes;
    for (int i = 0; i < 30; ++i) {
        gp.side[0].palette.rgba[1] = 0xff000000u + i;
        gc.Tick(gm, go, 1, pa, 0, gp, true, 200 + i);
        assert(gc.AppliedChoice().palette == gp.side[0].palette);
    }
    assert(gc.Holding() && gc.Diag().choiceChanges == 0 && gm.refreshes == r + 30);
    gc.Tick(gm, go, 1, pa, 0, gp, true, 301);
    assert(gm.refreshes == r + 30);
    gc.Tick(gm, go, 1, pa, 0, gp, false, 400);
    assert(!gc.Holding());

    InventoryOffsets o{}; o.pawnHandle=4; o.team=8; o.weaponServices=16; o.myWeapons=8;
    o.attributeManager=0x100; o.item=0x20; o.itemDefinition=0x10; o.fallbackPaintKit=0x50;
    const std::uint32_t ph=1, wh=2; put(co+4, ph); put(pa+8, std::uint8_t(3)); put(pa+16, sv);
    put(sv+8, std::int32_t(1)); put(sv+16, reinterpret_cast<std::uintptr_t>(&wh));
    put(en+0x130, std::uint16_t(42)); put(en+0x60, knife_experiment::Hash(42));
    Knives km; km.entities[1]=pa; km.entities[2]=en; knife_experiment::Controller kc;
    auto result = kc.Tick(km, o, 0x60, co, kp, true);
    assert(result.changes == 1 && km.skinCalls == 1 && km.seen == kp.side[0].palette);
    for (int i = 0; i < 30; ++i) {
        kp.side[0].palette.rgba[0] = 0xff000000u + i;
        result = kc.Tick(km, o, 0x60, co, kp, true, 100 + i);
        assert(km.seen == kp.side[0].palette);
    }
    assert(km.restores == 0 && km.rebuilds == 1 && km.colorRefreshes == 30);
    result = kc.Tick(km, o, 0x60, co, kp, true, 201);
    assert(km.colorRefreshes == 30);
    // Failed refreshes are retried with backoff rather than every frame.
    kp.side[0].palette.rgba[0] = 0xff654321u; km.refreshOk = false;
    result = kc.Tick(km, o, 0x60, co, kp, true, 300);
    assert(km.colorRefreshes == 31 && result.skin == 3);
    kc.Tick(km, o, 0x60, co, kp, true, 301);
    assert(km.colorRefreshes == 31);
    km.refreshOk = true;
    kc.Tick(km, o, 0x60, co, kp, true, 1300);
    assert(km.colorRefreshes == 32 && km.seen == kp.side[0].palette);
    result = kc.Tick(km, o, 0x60, co, kp, false, 1400);
    assert(km.restores == 1);
}
