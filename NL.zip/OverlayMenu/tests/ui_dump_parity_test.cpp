#include "presets_ui.h"
#include "profile_popup.h"
#include <cassert>
#include <iostream>
#include <limits>
using namespace menu;
static bool Near(float a, float b) { return std::abs(a - b) < .0001f; }
static void Same(Color a, Color b) {
    assert(Near(a.r,b.r) && Near(a.g,b.g) && Near(a.b,b.b) && Near(a.a,b.a));
}
static void Save(const Canvas& c, const std::filesystem::path& name) {
    std::ofstream o(name, std::ios::binary);
    o << "P6\n" << c.width << " " << c.height << "\n255\n";
    for (std::size_t i=0; i<c.rgba.size(); i+=4) o.write((const char*)&c.rgba[i],3);
}
int main(int argc, char** argv) {
    // Dump RVA 0x9cccab snapshots 0x2e0 bytes; 0x9cce90 blends 46 RGBA colors.
    Settings cfg;
    assert(!cfg.themePalette.Tick(0, 1));
    for (int i=0;i<46;++i) Same(cfg.themePalette.value[i],BasePalettes[0][i]);
    auto before=CurrentPalette(cfg);
    cfg.theme=1;
    assert(cfg.themePalette.Tick(1,.1f));
    for (int i=0;i<46;++i) Same(CurrentPalette(cfg)[i],before[i]);
    assert(cfg.themePalette.Tick(1,.1f));
    for (int i=0;i<46;++i) Same(cfg.themePalette.value[i],Mix(BasePalettes[0][i],BasePalettes[1][i],.875f));
    before=CurrentPalette(cfg);
    const auto rawFrom=cfg.themePalette.value;
    cfg.theme=0;
    assert(cfg.themePalette.Tick(0,0));
    for (int i=0;i<46;++i) Same(CurrentPalette(cfg)[i],before[i]);
    assert(cfg.themePalette.Tick(0,.1f));
    for (int i=0;i<46;++i) Same(cfg.themePalette.value[i],Mix(rawFrom[i],BasePalettes[0][i],.875f));
    assert(cfg.themePalette.Tick(0,.1f));
    assert(!cfg.themePalette.Tick(0,.1f));
    for (int i=0;i<46;++i) Same(cfg.themePalette.value[i],BasePalettes[0][i]);
    assert(!cfg.themePalette.Tick(0,-1));
    assert(!cfg.themePalette.Tick(0,std::numeric_limits<float>::quiet_NaN()));
    Settings light; light.theme=1;
    assert(!light.themePalette.Tick(1,0)); // no dark flash on initial light startup
    Same(CurrentPalette(light)[0],BasePalettes[1][0]);
    Settings custom=cfg; custom.customAccent=true;custom.accent={.2f,.8f,.1f,1};
    custom.theme=1;custom.themePalette.Tick(1,0);custom.themePalette.Tick(1,.05f);
    for (int i:{23,25,31,39}) Same(CurrentPalette(custom)[i],custom.accent);
    // Animation is presentation only; it must not mark a saved preset dirty every frame.
    Settings still=custom; custom.themePalette.Tick(1,.05f);
    assert(PresetSettingsEqual(still,custom));
    if (argc<2) { std::cout<<"Palette tests PASS (pass fonts directory for geometry/render tests)\n";return 0; }
    Fonts fonts(argv[1]);
    for (float s:{.75f,1.f,1.25f,1.5f,2.f}) {
        Settings c;c.scale=s;c.blur=false;
        auto l=ComputeLayout(2560,1600,c);
        PresetsUI ui;ui.mainSearch=ui.open=ui.searchFocus=true;
        ui.mainSearchOpacity.Snap(1);
        ui.Measure(fonts,c,l,2560,1600);
        const float F=fonts.PixelHeight(1,13*s);
        assert(Near(ui.popup.w,l.content.w-2*std::floor(s)-20*s));
        assert(Near(ui.popup.x,std::trunc(l.content.x+std::floor(s)+10*s)));
        assert(Near(ui.searchBox.h,F+34*s));
        assert(Near(ui.popup.h,ui.searchBox.h));
        bool close=false;
        for (const auto& h:ui.hits) if(h.action==32) {
            close=true;assert(h.box.x>=ui.popup.x && h.box.x+h.box.w<=ui.popup.x+ui.popup.w);
            assert(h.box.y>=ui.popup.y && h.box.y+h.box.h<=ui.popup.y+ui.popup.h);
        }
        assert(close);
        std::cout<<"Scale "<<s<<": F="<<F<<" search="<<ui.popup.w<<"x"<<ui.searchBox.h<<"\n";
        ui.mainSearchText=U"Test";
        for(int n=0;n<30;++n) { MainSearchItem item;item.label=U"Test option";item.group=U"Test group";item.check=true;ui.mainSearchItems.push_back(item); }
        ui.Measure(fonts,c,l,2560,1600);
        assert(Near(ui.mainSearchHeightTarget,450*s));
        ui.mainSearchHeight.Snap(ui.mainSearchHeightTarget);
        ui.Measure(fonts,c,l,2560,1600);
        assert(ui.mainSearchMaximum>0 && ui.popup.h>ui.searchBox.h);
    }
    if(argc>2) {
        std::filesystem::create_directories(argv[2]);
        Settings c;c.blur=false;State st;st.anim[0]=1;
        auto l=ComputeLayout(1100,800,c);
        PresetsUI search;search.mainSearch=search.open=search.searchFocus=true;search.mainSearchOpacity.Snap(1);
        search.Measure(fonts,c,l,1100,800);
        Canvas empty(1100,800);Render(empty,fonts,c,st,l);RenderPresetsCPU(empty,fonts,c,search);
        Save(empty,std::filesystem::path(argv[2])/"search_empty.ppm");
        search.mainSearchText=U"Frost";MainSearchItem item;item.label=U"Frost";item.group=U"World / View";item.check=true;search.mainSearchItems.push_back(item);
        search.Measure(fonts,c,l,1100,800);search.mainSearchHeight.Snap(search.mainSearchHeightTarget);
        search.Measure(fonts,c,l,1100,800);
        Canvas results(1100,800);Render(results,fonts,c,st,l);RenderPresetsCPU(results,fonts,c,search);
        Save(results,std::filesystem::path(argv[2])/"search_results.ppm");
        ProfileUI profile;profile.Measure(fonts,c);profile.Open(l,c,st,1100,800);profile.Tick(.3f);
        c.themePalette.Tick(0,0);
        for(int i=0;i<3;++i) {
            if(i==1) { c.theme=1;c.themePalette.Tick(1,0);c.themePalette.Tick(1,.1f); }
            if(i==2) c.themePalette.Tick(1,.1f);
            Canvas canvas(1100,800);Render(canvas,fonts,c,st,l);RenderProfileCPU(canvas,fonts,c,profile);
            Save(canvas,std::filesystem::path(argv[2])/("theme_"+std::to_string(i)+".ppm"));
        }
    }
    std::cout<<"UI dump parity tests PASS\n";
}
