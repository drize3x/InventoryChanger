#include "watermark_ui.h"
#include <cassert>
#include <iostream>
#include <limits>
using namespace menu;
static bool Near(float a,float b){return std::abs(a-b)<.0001f;}
int main() {
    const float heights[]={26,29,34};
    for(int pos=0;pos<6;++pos) for(int d=0;d<3;++d)
      for(float scale:{.75f,1.f,1.25f,1.5f,2.f})
       for(int h:{720,1080,1440,2160})
        for(float alpha:{0.f,.1f,.25f,.5f,.75f,1.f}) {
            const float expected=pos==4 ? -1080.f/h*std::round((heights[d]+5-8)*scale*std::min(2*alpha,1.f)):0;
            assert(Near(WatermarkHudOffset(pos,d,scale,alpha,h),expected));
        }
    auto nan=std::numeric_limits<float>::quiet_NaN();
    for(float scale:{0.f,-1.f,nan})assert(WatermarkHudOffset(4,1,scale,1,1080)==0);
    assert(WatermarkHudOffset(4,1,1,nan,1080)==0);
    assert(WatermarkHudOffset(4,1,1,1,0)==0);
    Settings cfg;WatermarkUI ui;
    cfg.worldMisc.value[WatermarkSetting("watermark_position")]=4;
    cfg.worldMisc.value[WatermarkSetting("watermark_density")]=1;
    cfg.worldMisc.value[WatermarkSetting("watermark")]=1;
    ui.opacity.Snap(1);
    assert(Near(WatermarkGameHudOffset(cfg,ui,1080,true),-26));
    cfg.scale=2; // Menu scale must not change independent HUD/window scale.
    assert(Near(WatermarkGameHudOffset(cfg,ui,1080,true),-26));
    cfg.windowsScale=3;
    assert(Near(WatermarkGameHudOffset(cfg,ui,1080,true),-39));
    assert(WatermarkGameHudOffset(cfg,ui,1080,false)==0);
    cfg.worldMisc.value[WatermarkSetting("watermark_position")]=3;
    assert(WatermarkGameHudOffset(cfg,ui,1080,true)==0);
    cfg.worldMisc.value[WatermarkSetting("watermark_position")]=4;
    cfg.worldMisc.value[WatermarkSetting("watermark")]=0;
    ui.opacity.Snap(.25f); // Preserve fade-out rather than snapping to origin.
    assert(Near(WatermarkGameHudOffset(cfg,ui,1080,true),-20));
    for(int i=0;i<60;++i)ui.Tick(1.f/60,cfg,true);
    assert(WatermarkGameHudOffset(cfg,ui,1080,true)==0);
    cfg.worldMisc.value[WatermarkSetting("watermark_position")]=nan;
    assert(WatermarkGameHudOffset(cfg,ui,1080,true)==0);
    // Native HUD adds offset to the saved original value, not the last applied
    // value: repeated frames do not accumulate displacement (adapter contract).
    HudPosition original; original.y.value=12;
    auto shifted=original;shifted.y.value+=WatermarkHudOffset(4,1,1,1,1080);
    assert(Near(shifted.y.value,-14)); assert(HudCanOffset(original));
    assert(!HudSamePosition(original,shifted));
    std::cout<<"Watermark HUD tests PASS\n";
}
