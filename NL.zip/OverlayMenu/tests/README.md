# Локальные проверки

Проверки не заменяют сборку Visual Studio и запуск в CS2. Из корня проекта в Linux:

```sh
INCLUDES='-I src/core -I src/inventory -I src/ui -I src/render -I src/preview -I src/platform -I third_party/freetype/include'
g++ -std=c++17 -O2 tests/frost_environment_test.cpp -o /tmp/frost_test && /tmp/frost_test
g++ -std=c++17 -O2 $INCLUDES tests/item_color_test.cpp src/inventory/inventory_model.cpp -o /tmp/color_test && /tmp/color_test
g++ -std=c++17 -O2 $INCLUDES tests/native_signature_test.cpp -o /tmp/signature_test && /tmp/signature_test /путь/к/client.dll
```

`native_signature_test` проверяет сигнатуры и общую функцию добавления параметров материала в указанном модуле. Реальная отрисовка, обновление материалов и совместимость отдельных скинов проверяются в игре.
