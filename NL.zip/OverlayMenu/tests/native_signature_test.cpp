#include "menu_core.h"
#include "inventory_knife_skin_patterns.h"
#include "inventory_glove_builder_patterns.h"
#include "inventory_color_composite.h"
#include "inventory_frost_patterns.h"
#include "players_live_patterns.h"
#include <algorithm>
#include <cassert>
#include <fstream>
#include <iterator>
#include <iostream>
#include <cstring>
#include <stdexcept>
using namespace menu;

template<class T> T read(const std::vector<unsigned char>& b, std::size_t i) {
    if (i + sizeof(T) > b.size()) throw std::runtime_error("truncated PE");
    T v{}; std::memcpy(&v, b.data() + i, sizeof v); return v;
}
int main(int argc, char** argv) {
    if (argc != 2) return 2;
    std::ifstream f(argv[1], std::ios::binary);
    std::vector<unsigned char> b((std::istreambuf_iterator<char>(f)), {});
    if (b.size() < 0x100 || read<std::uint16_t>(b, 0) != 0x5a4d) return 2;
    auto pe = read<std::uint32_t>(b, 0x3c);
    if (read<std::uint32_t>(b, pe) != 0x4550) return 2;
    auto count = read<std::uint16_t>(b, pe+6), opt = read<std::uint16_t>(b, pe+20);
    auto section = pe + 24 + opt; constexpr std::uintptr_t base = 0x180000000;
    menu::HudScanImage image;
    for (unsigned i = 0; i < count; ++i) {
        auto p = section + 40*i;
        auto virtualSize=read<std::uint32_t>(b,p+8), rva=read<std::uint32_t>(b,p+12);
        auto rawSize=read<std::uint32_t>(b,p+16), raw=read<std::uint32_t>(b,p+20);
        auto flags=read<std::uint32_t>(b,p+36);
        if (!(flags & 0x40000000) || !virtualSize) continue;
        if (raw > b.size() || rawSize > b.size()-raw) return 2;
        menu::HudScanImage::Part part; part.start=base+rva; part.flags=flags;
        part.bytes.resize(virtualSize);
        std::memcpy(part.bytes.data(), b.data()+raw, std::min<std::size_t>(virtualSize,rawSize));
        image.parts.push_back(std::move(part));
    }
    LiveESPAddresses liveAddresses; std::string liveDiagnostic;
    assert(LiveESPResolve(image,liveAddresses,liveDiagnostic));
    assert(liveAddresses.entities && liveAddresses.matrix);
    // Client-side native watermark/HUD integration. Panorama ABI still needs
    // the loaded panorama.dll and is verified defensively by HudResolveBindings.
    auto hudGlobals=image.Find(hud_patterns::HudGlobal,true,2);
    assert(hudGlobals.size()==1);
    std::vector<std::uintptr_t> bottomCenters;
    for(auto hit:image.Find(hud_patterns::BottomCache))
        if(image.Text(image.Rip(hit+4),"HudBottomCenter"))bottomCenters.push_back(hit);
    assert(bottomCenters.size()==1);
    std::uint8_t bottomOffset=0;
    assert(image.Read(bottomCenters[0]+52,bottomOffset));
    assert(bottomOffset>=16 && !(bottomOffset&7));
    auto site=image.Find("48 8D 8F 68 12 00 00 48 8B 01 FF 50 18 48 8D 8F 10 06 00 00 B2 01 48 8B D8 E8 ? ? ? ? 48 8D 4B 50 E8 ? ? ? ? 44 0F B6 C8 48 89 74 24 20 45 33 C0 48 8D 53 50 48 8B CF E8 ? ? ? ?",true,2);
    assert(site.size()==1);
    auto append=inventory_color::ResolveAppend(image, image.Rip(site[0]+58,1,5));
    auto builder=glove_builder::Resolve(image);
    assert(append && builder && inventory_color::GloveUsesAppend(image,builder,append));
    assert(!inventory_color::GloveUsesAppend(image,builder,append+1));
    inventory_frost::EnvironmentBindings env;
    assert(inventory_frost::ResolveEnvironment(image,env));
    inventory_frost::Bindings frost;
    assert(inventory_frost::Resolve(image,frost));
    std::cout << "Native signatures: PASS\n";
}
