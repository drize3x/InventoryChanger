// Independent implementation, not original/decompiled Neverlose source.
Texture2D image : register(t0);
Texture2D avatarAtlas : register(t1);
SamplerState linearClamp : register(s0);
cbuffer BlurCB : register(b0) {
    float2 resolution; float direction; int pairs;
    float4 offsets[11]; float4 weights[11];
};
cbuffer PanelCB : register(b1) {
    float4 screen;          // width, height, time, material mode
    float4 rect;            // x, y, width, height (framebuffer pixels)
    float4 topColor;        // RGB tint + tint strength in alpha
    float4 bottomColor;
    float4 radii;           // TL, TR, BR, BL
    float4 fx;             // smoothing, border pixels, use blur 0..1, opacity
    float4 shadow;         // opacity, full fade width, offset x, offset y
    float4 shadowColor;    // RGB; alpha is supplied in shadow.x
};
struct Varying { float4 pos : SV_Position; float4 color : COLOR0; float2 uv : TEXCOORD0; };
Varying FullscreenVS(uint id : SV_VertexID) {
    Varying o;
    o.color=1;
    o.uv = float2((id << 1) & 2, id & 2);
    o.pos = float4(o.uv * float2(2, -2) + float2(-1, 1), 0, 1);
    return o;
}
float4 BlurPS(Varying i) : SV_Target {
    float2 stepUV = direction == 0 ? float2(1 / resolution.x, 0) : float2(0, 1 / resolution.y);
    float4 c = image.Sample(linearClamp, i.uv) * weights[0].x;
    [loop] for (int j = 1; j <= pairs; ++j) {
        c += (image.Sample(linearClamp, i.uv + stepUV * offsets[j].x)
            + image.Sample(linearClamp, i.uv - stepUV * offsets[j].x)) * weights[j].x;
    }
    return c;
}
// Generalized rounded-box pseudo-distance. It is an exact box SDF only at n=2.
float roundedBoxBiased(float2 p, float radiusBias) {
    float smoothing = saturate(fx.x);
    float n = 2 + 3.6 * smoothing;
    float r = p.y < 0 ? (p.x < 0 ? radii.x : radii.y) : (p.x < 0 ? radii.w : radii.z);
    // CPU-side primitive builder clamps the INPUT radius, before smoothing.
    // The old reconstruction incorrectly clamped AFTER dividing by this factor.
    r = min(r, min(rect.z, rect.w) * .5) / max(1 - .6 * smoothing, .01) + radiusBias;
    float2 q = abs(p) - rect.zw * .5 + r;
    float2 z = max(q, 0);
    return pow(pow(z.x, n) + pow(z.y, n), 1 / n) + min(max(q.x, q.y), 0) - r;
}
float roundedBox(float2 p) { return roundedBoxBiased(p, 0); }
// UI PS @F3D2C0, prim_type=2, instructions 345..474, no textures/shadow.
// Separate outer/inner smoothsteps and angular interval, not an abs(radius) SDF.
float sourceAtan2(float y,float x) {
    float t=min(abs(x),abs(y))/max(max(abs(x),abs(y)),1e-20);
    float t2=t*t;
    float angle=t*((((.0208351*t2-.085133)*t2+.180141)*t2-.330299)*t2+.999866);
    if(abs(y)>abs(x))angle=1.57079632679-angle;
    if(x<0)angle=3.14159265359-angle;
    return y<0?-angle:angle;
}
float sourceArc(float2 p,float diameter,float thickness,float progress) {
    const float tau=6.28318530718,halfPi=1.57079632679;
    float2 uv=p/diameter+.5;
    float len=length(uv-.5);
    float lenFW=abs(ddx_coarse(len))+abs(ddy_coarse(len));
    float d=length(uv*2-1)-(1-lenFW);
    float aa=max(abs(ddx_coarse(d))+abs(ddy_coarse(d)),1e-6);
    float outer=1-smoothstep(0,aa,max(d,0));
    float inner=smoothstep(0,aa,-d-2*(thickness-1)/diameter);
    // No angular smoothing centred on an endpoint: source uses [0,aa].
    float angle=sourceAtan2(-p.y,p.x);
    angle=frac((angle+tau)/tau)*tau;
    float start=halfPi-tau*saturate(progress),end=halfPi;
    float turns=ceil((start-angle)/tau);
    float lifted=angle+turns*tau;
    float angular=lifted<=end?smoothstep(0,aa,lifted-start)*smoothstep(0,aa,end-lifted):0;
    if(progress>=1)angular=1;
    if(progress<=0)angular=0;
    // aa<1 matches r5.y test @455; standard HUD scales are in that branch.
    float ring=aa<1&&d<0?outer*(1-inner):outer;
    return ring*angular;
}
float4 PanelPS(Varying i) : SV_Target {
    float2 p = i.pos.xy - rect.xy - rect.zw * .5;
    // The two source circle calls share their centre but have different quads.
    if (screen.w > 8.5 && screen.w < 9.5) {
        float scale=fx.x;
        float track=sourceArc(p,19.75*scale,5.5*scale,1);
        float arc=sourceArc(p,17.75*scale,3.5*scale,bottomColor.x);
        float ta=track*shadowColor.a*saturate(fx.w);
        float a=arc*topColor.a*saturate(fx.w);
        return float4(topColor.rgb*a+shadowColor.rgb*ta*(1-a),a+ta*(1-a));
    }

    // Dedicated outline draw. DXBC @230..238: fixed one-pixel transition,
    // ring = smoothstep(-t-.5,-t+.5,d) - smoothstep(-.5,.5,d).
    // Outlined primitives subtract .5 from the expanded corner radius (@207).
    if (screen.w > 2.5 && screen.w < 3.5) {
        float t = max(fx.y, 0);
        float ringD = roundedBoxBiased(p, -.5);
        float ring = saturate(smoothstep(-t-.5, -t+.5, ringD)
                            -smoothstep(-.5, .5, ringD));
        float a = ring * saturate(topColor.a) * saturate(fx.w);
        return float4(topColor.rgb * a, a);
    }
    float d = roundedBox(p);
    // DXBC uses the full coarse fwidth on EACH side, not half-fwidth.
    float aa = max(abs(ddx_coarse(d)) + abs(ddy_coarse(d)), 1e-5);
    float coverage = 1 - smoothstep(-aa, aa, d);
    float inner = 1 - smoothstep(-aa, aa, d + max(fx.y, 0));
    float edge = saturate(coverage - inner);
    // Spectators @968F00, UI DXBC @F3D2C0: multi-stop type=3 + shadow_type=1.
    // Stops (0,.1,.5,.5,.9,1): transparent, transparent, opaque, opaque,
    // transparent, transparent; identical team RGB at all six stops.
    if (screen.w > 6.5 && screen.w < 7.5) {
        float v = (i.pos.y-rect.y)/rect.w;
        float ramp = 0;
        const float fractions[6]={0,.1,.5,.5,.9,1};
        const float alphaStops[6]={0,0,1,1,0,0};
        [loop] for(int k=0;k<5;++k) {
            if(v >= fractions[k] && v <= fractions[k+1]) {
                ramp=lerp(alphaStops[k],alphaStops[k+1],
                    (v-fractions[k])/(fractions[k+1]-fractions[k]));
                break;
            }
        }
        float colorAlpha = topColor.a * saturate(ramp);
        float sd = roundedBox(p-shadow.zw);
        float fade = 1-smoothstep(-shadow.y*.5,shadow.y*.5,sd);
        float s = 1-coverage;
        float4 fill = float4(topColor.rgb, colorAlpha*coverage);
        float4 glow = float4(shadowColor.rgb, colorAlpha*fade*shadow.x);
        float4 result = lerp(fill,glow,s);
        // opacity is already included in packed team alpha and glow alpha,
        // just as the source primitive setter does. Do not apply fx.w twice.
        return float4(result.rgb*result.a,result.a);
    }
    if (screen.w > 7.5 && screen.w < 8.5) {
        float2 uv=saturate((i.pos.xy-rect.xy)/rect.zw);
        // Atlas texel centres keep bilinear samples within each portrait.
        uv=(float2(topColor.x*32,0)+.5+uv*31)/float2(96,32);
        float4 c=avatarAtlas.Sample(linearClamp,uv);
        float a=c.a*coverage*saturate(fx.w);
        return float4(c.rgb*a,a);
    }
    // Shared HUD material: Hotkeys / Spectators / Indicators. Separate backdrop and fill.
    // mode5: backdrop mask; mode6: half-alpha HUD fill. Same shape, separate AA blends.
    if (screen.w > 4.5) {
        float a = coverage * saturate(fx.w);
        if (screen.w < 5.5) {
            float3 backdrop = image.Sample(linearClamp, i.pos.xy / screen.xy).rgb;
            return float4(backdrop*a, a);
        }
        a *= saturate(topColor.a);
        return float4(topColor.rgb*a, a);
    }
    // Dedicated shadow_type=2 pass, emitted in the source draw order.
    // The exterior gate uses the unshifted shape; fade uses shifted distance.
    if (screen.w > 3.5) {
        float spread = shadow.y;
        if (spread <= 0) return float4(0,0,0,0);
        float sd = roundedBox(p - shadow.zw);
        float fade = 1 - smoothstep(-spread*.5, spread*.5, sd);
        float a = (1-coverage)*fade*saturate(shadow.x)*saturate(fx.w);
        return float4(shadowColor.rgb*a,a);
    }
    float y = saturate((i.pos.y - rect.y) / rect.w);
    float4 tint = lerp(topColor, bottomColor, y);
    float3 blurred = image.Sample(linearClamp, i.pos.xy / screen.xy).rgb;
    float3 glass = lerp(blurred, tint.rgb, tint.a);
    float3 material = lerp(tint.rgb, glass, fx.z);
    // No invented bluish edge-lightening; source fill uses the palette colour.
    float surfaceAlpha = 1;
    // Additional Hotkeys materials; screen.w=0 preserves watermark rendering.
    // Header: solid style colour. Rows: sampled backdrop + half-alpha style fill.
    if (screen.w > 1.5) {
        material = lerp(blurred, tint.rgb, tint.a * .5);
    } else if (screen.w > .5) {
        material = tint.rgb;
        surfaceAlpha = saturate(tint.a);
        // The source outline is now a SEPARATE ring pass, not a fill-alpha tweak.
    }
    float pa = coverage * surfaceAlpha * saturate(fx.w);
    return float4(material * pa, pa);
}
float4 ScenePS(Varying i) : SV_Target {
    float2 p = i.uv * screen.xy;
    float checker = fmod(floor(p.x / 44) + floor(p.y / 44), 2);
    float3 c = lerp(float3(.075, .11, .16), float3(.16, .23, .30), checker);
    float glow = exp(-dot(i.uv - float2(.5 + .23 * sin(screen.z * .3), .4),
                          i.uv - float2(.5 + .23 * sin(screen.z * .3), .4)) * 10);
    return float4(c + glow * float3(.05, .15, .21), 1);
}

cbuffer LayerCB : register(b2) {
    float4 layerRect; // visible destination x,y,w,h
    float4 layerInfo; // texture w,h, horizontal scroll, opacity
};
float4 LayerPS(Varying i) : SV_Target {
    float2 p = i.pos.xy-layerRect.xy;
    clip(p); clip(layerRect.zw-p);
    // Glyph mask already rasterized at final pixel size. Do NOT filter it again.
    int2 pixel = int2(floor(p + float2(layerInfo.z, 0)));
    return image.Load(int3(pixel, 0)) * layerInfo.w;
}

// Host-only compatibility VS. Pixel shaders are loaded as original DXBC.
cbuffer OriginalQuadCB : register(b3) {
 float4 originalRect;
 float4 originalScreen;
};
struct OriginalVarying {
 float4 pos : SV_Position;
 float4 color : COLOR0;
 float2 uv : TEXCOORD0;
};
OriginalVarying OriginalQuadVS(uint id : SV_VertexID) {
 const float2 corners[6]={float2(0,0),float2(1,0),float2(0,1),float2(1,0),float2(1,1),float2(0,1)};
 OriginalVarying o;
 // One-pixel guard band allows the original derivative AA outside the quad edge.
 float2 p=originalRect.xy-1+corners[id]*(originalRect.zw+2);
 o.pos=float4(p/originalScreen.xy*float2(2,-2)+float2(-1,1),0,1);
 o.color=1;
 o.uv=(p-originalRect.xy)/originalRect.zw;
 return o;
}

// New GPU compositing path, not original recovered shader bytecode.
// Captured model alpha encoding must be verified by the capture integration.
cbuffer ExternalTextureCB : register(b4) {
 float4 externalRect;
 float4 externalUV;
 float4 externalOptions;
};
float4 ExternalTexturePS(Varying i) : SV_Target {
 float2 local=(i.pos.xy-externalRect.xy)/externalRect.zw;
 clip(local);clip(1-local);
 float2 uv=lerp(externalUV.xy,externalUV.zw,local);
 // Clamp samples to valid texel centres, not the backing-texture padding.
 uint tw,th;image.GetDimensions(tw,th);
 float2 halfTexel=.5/float2(tw,th);
 uv=clamp(uv,externalUV.xy+halfTexel,externalUV.zw-halfTexel);
 float4 c=image.SampleLevel(linearClamp,uv,0);
 if(externalOptions.z>.5)c.a=1; // backbuffer snapshot is opaque regardless of stored alpha
 else if(externalOptions.y>.5)c.rgb*=c.a;
 return c*externalOptions.x;
}
// Native model preview is captured transparent into an OWNED texture. This
// host-only halo reads its real coverage; it never draws a box/fake player and
// never recolors or changes opacity of the original model.
cbuffer PreviewGlowCB : register(b5) {
 float4 previewModelRect;
 float4 previewSourceUV;
 float4 previewCropRect;
 float4 previewInverseBacking;
 float4 previewGlowColor;
 float4 previewGlowOptions; // UI opacity, contour radius in framebuffer px, RGBA8 coverage scale, blurred-halo gain
};
float PreviewModelAlpha(Texture2D tex,float2 absolutePos) {
 float2 local=(absolutePos-previewModelRect.xy)/previewModelRect.zw;
 if(any(local<0)||any(local>1))return 0;
 uint tw,th;tex.GetDimensions(tw,th);
 float2 halfTexel=.5/float2(tw,th);
 float2 uv=clamp(lerp(previewSourceUV.xy,previewSourceUV.zw,local),
     previewSourceUV.xy+halfTexel,previewSourceUV.zw-halfTexel);
 return saturate(tex.SampleLevel(linearClamp,uv,0).a);
}
float PreviewModelCoverage(Texture2D tex,float2 absolutePos) {
 // Chams/capture opacity is NOT the Glow strength. The RGBA8 nonzero-texel
 // coverage preserves the silhouette; alpha-zero background remains empty.
 return saturate(PreviewModelAlpha(tex,absolutePos)*previewGlowOptions.z);
}
float4 PreviewGlowMaskPS(Varying i) : SV_Target {
 float a=PreviewModelCoverage(image,i.pos.xy+previewCropRect.xy);
 return a.xxxx;
}
float4 PreviewGlowCompositePS(Varying i) : SV_Target {
 float2 local=(i.pos.xy-previewCropRect.xy)/previewCropRect.zw;
 clip(local);clip(1-local);
 float2 uv=(i.pos.xy-previewCropRect.xy)*previewInverseBacking.xy;
 float blurredCoverage=saturate(image.SampleLevel(linearClamp,uv,0).a);
 // t1 is the ORIGINAL model for this pass, not the avatar atlas/backbuffer.
 float modelCoverage=PreviewModelCoverage(avatarAtlas,i.pos.xy);
 float expandedCoverage=modelCoverage;
 // Bright, one-framebuffer-pixel contour, independent of source texture size.
 // Same original texture; no extra render target, pass or CPU readback.
 [unroll] for(int y=-1;y<=1;++y) {
  [unroll] for(int x=-1;x<=1;++x) {
   if(x!=0||y!=0)expandedCoverage=max(expandedCoverage,PreviewModelCoverage(avatarAtlas,
       i.pos.xy+float2(x,y)*previewGlowOptions.y));
  }
 }
 float haloCoverage=max(saturate(blurredCoverage*previewGlowOptions.w),expandedCoverage);
 float a=haloCoverage*(1-modelCoverage)*previewGlowColor.a*previewGlowOptions.x;
 return float4(previewGlowColor.rgb*a,a);
}
